@echo off
chcp 65001 >nul
title Lantify POS

echo ========================================
echo   INICIANDO LANTIFY POS
echo ========================================
echo.

REM Verificar base de datos
if not exist "prisma\dev.db" (
    echo ERROR: No se encontro la base de datos
    echo Ejecuta primero install.bat
    pause
    exit /b 1
)

echo [1/2] Iniciando servidor backend en segundo plano...
start /min "Backend POS" cmd /c "npm run dev"

timeout /t 3 /nobreak >nul

echo [2/2] Iniciando frontend en segundo plano...
start /min "Frontend POS" cmd /c "cd frontend && npm run dev"

timeout /t 2 /nobreak >nul

echo.
echo ========================================
echo   LANTIFY POS INICIADO CON EXITO
echo ========================================
echo.
echo Abriendo aplicacion en tu navegador...
start http://localhost:5173

timeout /t 2 /nobreak >nul
exit