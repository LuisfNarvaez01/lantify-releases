// ============================================
// SHARED - Auth & Role Middleware
// ============================================

import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { prisma } from '../infrastructure/database/prisma';
import { getJwtSecret } from './security/secrets';
import { resolveAccess } from './security/accessPolicy';
import { currentFeatures, requiredFeature, isRemoteClient, isAlwaysReachable } from './cloud/features';

export interface AuthRequest extends Request {
  user?: {
    userId?: string;
    id?: string;
    username: string;
    role: string;
    name?: string;
  };
  mustChangePassword?: boolean;
}

export interface TokenPayload {
  userId: string;
  username: string;
  role: string;
  tv: number; // tokenVersion: al cambiar contraseña, rol o desactivar, los tokens viejos dejan de servir
}

export const signToken = (payload: TokenPayload, expiresIn: string = '12h') =>
  jwt.sign(payload, getJwtSecret(), { expiresIn } as jwt.SignOptions);

// Rutas que se pueden usar aunque el usuario deba cambiar su contraseña
const ALLOWED_WHILE_PASSWORD_CHANGE = [/^\/auth\/verify$/, /^\/auth\/change-password$/];

type AuthResult =
  | { ok: true; user: NonNullable<AuthRequest['user']>; mustChangePassword: boolean }
  | { ok: false; status: number; code: string; error: string };

const authenticate = async (req: Request): Promise<AuthResult> => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ') || authHeader.length <= 7) {
    return { ok: false, status: 401, code: 'AUTH_TOKEN_MISSING', error: 'Token no proporcionado. Inicia sesión para continuar.' };
  }

  let decoded: TokenPayload;
  try {
    decoded = jwt.verify(authHeader.substring(7), getJwtSecret()) as TokenPayload;
  } catch {
    return { ok: false, status: 401, code: 'AUTH_TOKEN_INVALID', error: 'Token inválido o expirado. Vuelve a iniciar sesión.' };
  }
  // Otros permisos firmados con la misma clave (p. ej. exportación) no son sesiones
  if (typeof decoded.userId !== 'string' || (decoded as any).scope) {
    return { ok: false, status: 401, code: 'AUTH_TOKEN_INVALID', error: 'Token inválido o expirado. Vuelve a iniciar sesión.' };
  }

  // El usuario se consulta en cada petición: el rol y el estado vienen de la base de datos, no del token
  const user = await prisma.user.findUnique({
    where: { id: decoded.userId },
    select: { id: true, username: true, name: true, role: true, isActive: true, tokenVersion: true, mustChangePassword: true },
  });

  if (!user || !user.isActive || user.tokenVersion !== decoded.tv) {
    return { ok: false, status: 401, code: 'AUTH_SESSION_REVOKED', error: 'La sesión ya no es válida. Vuelve a iniciar sesión.' };
  }

  return {
    ok: true,
    user: { id: user.id, userId: user.id, username: user.username, role: user.role, name: user.name },
    mustChangePassword: user.mustChangePassword,
  };
};

/**
 * Candados del plan: la función que exige la ruta debe estar en la licencia vigente.
 * Responde 402 para que la interfaz ofrezca el plan que la incluye.
 */
const planBlock = async (req: Request) => {
  if (isAlwaysReachable(req.path)) return null;
  const needed = [requiredFeature(req.method, req.path)];
  if (isRemoteClient(req.socket.remoteAddress)) needed.push('multi_terminal');
  if (!needed.some(Boolean)) return null;
  const features = await currentFeatures();
  if (!features) return null;
  const missing = needed.find((f) => f && !features.includes(f));
  return missing || null;
};

/**
 * Control de acceso global para /api. Aplica la política central (accessPolicy.ts)
 * y los candados del plan (cloud/features.ts).
 */
export const apiAccessControl = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const missingFeature = await planBlock(req);
    if (missingFeature) {
      return res.status(402).json({
        error: 'Esta función no está incluida en el plan del negocio.',
        code: 'PLAN_FEATURE_REQUIRED',
        feature: missingFeature,
      });
    }

    const decision = resolveAccess(req.method, req.path);

    if (decision.kind === 'public') {
      if (req.headers.authorization) {
        const result = await authenticate(req);
        if (result.ok) req.user = result.user;
      }
      return next();
    }

    const result = await authenticate(req);
    if (!result.ok) {
      return res.status(result.status).json({ error: result.error, code: result.code });
    }
    req.user = result.user;
    req.mustChangePassword = result.mustChangePassword;

    if (result.mustChangePassword && !ALLOWED_WHILE_PASSWORD_CHANGE.some(p => p.test(req.path))) {
      return res.status(403).json({
        error: 'Debes cambiar tu contraseña antes de continuar.',
        code: 'AUTH_PASSWORD_CHANGE_REQUIRED',
      });
    }

    if (decision.kind === 'roles' && !decision.roles.includes(result.user.role as any)) {
      return res.status(403).json({
        error: 'No tienes permiso para realizar esta acción.',
        code: 'AUTH_FORBIDDEN',
      });
    }

    return next();
  } catch (err) {
    return next(err);
  }
};

/** Exige sesión. Si el control global ya autenticó la petición, no repite la consulta. */
export const authMiddleware = async (req: AuthRequest, res: Response, next: NextFunction) => {
  if (req.user) return next();
  const result = await authenticate(req);
  if (!result.ok) return res.status(result.status).json({ error: result.error, code: result.code });
  req.user = result.user;
  next();
};

export const requireAuth = authMiddleware;

/** Adjunta el usuario si hay token válido; no bloquea (la política global decide). */
export const optionalAuth = async (req: AuthRequest, _res: Response, next: NextFunction) => {
  if (!req.user && req.headers.authorization) {
    const result = await authenticate(req);
    if (result.ok) req.user = result.user;
  }
  next();
};

export const requireRole = (...allowedRoles: string[]) => {
  return (req: AuthRequest, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Usuario no autenticado', code: 'AUTH_TOKEN_MISSING' });
    }

    const userRole = (req.user.role || '').toUpperCase();
    const normalizedAllowed = allowedRoles.map(r => r.toUpperCase());

    if (!normalizedAllowed.includes(userRole)) {
      return res.status(403).json({
        error: 'No tienes permiso para realizar esta acción.',
        code: 'AUTH_FORBIDDEN',
      });
    }

    next();
  };
};

export const adminOnly = requireRole('ADMIN');
export const cashierOrAdmin = requireRole('ADMIN', 'CASHIER');
