@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

title LantifyPOS - Asistente de Actualizacion Segura
REM Uso: update.bat          (con ventana, espera una tecla al final)
REM      update.bat /auto    (tarea programada: sin pausas)
set AUTO=0
if /i "%~1"=="/auto" set AUTO=1

set RELEASES=https://raw.githubusercontent.com/LuisfNarvaez01/lantify-releases/main

echo ======================================================
echo           LANTIFY POS - ACTUALIZADOR SEGURO
echo ======================================================
echo.

cd /d "%~dp0"

echo [1/6] Respaldo verificado de la base de datos...
node scripts/backup-db.js
if %errorlevel% neq 0 (
    echo.
    echo [ERROR] No se pudo crear el respaldo. La actualizacion se cancela para no arriesgar datos.
    goto :fin_error
)
echo      Respaldo guardado.

echo.
echo [2/6] Descargando la ultima version...
set VIA_PAQUETE=1
if exist ".git" (
    where git >nul 2>&1
    if !errorlevel! equ 0 (
        git pull --ff-only
        if !errorlevel! equ 0 set VIA_PAQUETE=0
    )
)

if !VIA_PAQUETE! equ 1 (
    if exist "update_temp" rmdir /s /q "update_temp"
    mkdir "update_temp"
    powershell -NoProfile -ExecutionPolicy Bypass -Command ^
      "$ErrorActionPreference='Stop'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12;" ^
      "$v = Invoke-RestMethod -UseBasicParsing ('%RELEASES%/version.json?t=' + [DateTimeOffset]::UtcNow.ToUnixTimeSeconds());" ^
      "$l = (Get-Content 'version.json' -Raw | ConvertFrom-Json).version;" ^
      "Write-Host ('     Instalada: ' + $l + '   Publicada: ' + $v.version);" ^
      "if ('%AUTO%' -eq '1' -and [version]$l -ge [version]$v.version) { exit 3 };" ^
      "Invoke-WebRequest -UseBasicParsing ('%RELEASES%/' + $v.package) -OutFile 'update_temp\paquete.zip';" ^
      "$h = (Get-FileHash 'update_temp\paquete.zip' -Algorithm SHA256).Hash.ToLower();" ^
      "if ($h -ne $v.sha256.ToLower()) { throw 'El paquete descargado no coincide con su huella SHA-256.' };" ^
      "Expand-Archive -Path 'update_temp\paquete.zip' -DestinationPath 'update_temp\files' -Force"
    if !errorlevel! equ 3 (
        echo      Ya tienes la ultima version.
        rmdir /s /q "update_temp"
        exit /b 0
    )
    if !errorlevel! neq 0 (
        echo.
        echo [ERROR] No se pudo descargar o verificar el paquete. Revisa la conexion a internet.
        if exist "update_temp" rmdir /s /q "update_temp"
        goto :fin_error
    )
)

echo.
echo [3/6] Deteniendo Lantify POS para aplicar los cambios...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-NetTCPConnection -LocalPort 5000,5173 -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique | ForEach-Object { Stop-Process -Id $_ -Force -ErrorAction SilentlyContinue }"
timeout /t 2 /nobreak >nul

if !VIA_PAQUETE! equ 1 (
    REM Los archivos del programa se reemplazan; la base de datos, .env y respaldos no vienen en el paquete
    REM El paquete trae el actualizador como update.new.bat; el servidor lo pone en su lugar al arrancar
    robocopy "update_temp\files" "." /E /XF update.bat /NFL /NDL /NJH /NJS /NP >nul
    if !errorlevel! geq 8 (
        echo [ERROR] No se pudieron copiar los archivos nuevos.
        goto :reiniciar_error
    )
    echo      Archivos actualizados.
)

echo.
echo [4/6] Instalando dependencias...
call npm install --no-audit --no-fund
if %errorlevel% neq 0 (
    echo [ERROR] Fallo npm install en el servidor.
    goto :reiniciar_error
)
pushd frontend
call npm install --no-audit --no-fund
set FRONT_ERR=%errorlevel%
popd
if %FRONT_ERR% neq 0 (
    echo [ERROR] Fallo npm install en la interfaz.
    goto :reiniciar_error
)

echo.
echo [5/6] Actualizando la estructura de la base de datos (sin borrar datos)...
call npx prisma db push --skip-generate
if %errorlevel% neq 0 (
    echo [ERROR] Prisma no pudo aplicar el cambio. Restaurando el respaldo...
    node scripts/backup-db.js --restore
    goto :reiniciar_error
)
call npx prisma generate
if %errorlevel% neq 0 echo [AVISO] No se pudo regenerar Prisma Client.

echo.
echo [6/6] Iniciando Lantify POS...
start "" wscript.exe "%~dp0iniciar-lantify.vbs"
node scripts/show-changelog.js

echo.
echo ======================================================
echo    Lantify POS quedo actualizado y en marcha.
echo    Tus ventas, clientes y configuraciones estan a salvo.
echo ======================================================
if exist "update_temp" rmdir /s /q "update_temp"
if %AUTO% equ 0 pause
exit /b 0

:reiniciar_error
if exist "update_temp" rmdir /s /q "update_temp"
REM El sistema no puede quedar apagado: se vuelve a abrir con lo que haya
start "" wscript.exe "%~dp0iniciar-lantify.vbs"
:fin_error
echo.
echo La actualizacion no termino. Tu informacion esta a salvo; avisa a soporte de Lantify.
if %AUTO% equ 0 pause
exit /b 1
