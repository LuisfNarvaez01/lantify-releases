// ============================================
// DOMAIN REPOSITORIES - Index
// ============================================

export * from './IProductRepository';
export * from './ISaleRepository';
export * from './ICashSessionRepository';
export * from './ITableRepository';