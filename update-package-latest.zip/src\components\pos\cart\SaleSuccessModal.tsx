// ============================================
// CART - Modal de Venta Exitosa y QR de Sellos
// ============================================
// Muestra el resumen del cobro, el cambio a devolver y el código QR de
// fidelidad en pantalla para que el cliente lo escanee con su celular.

import { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { CheckCircle2, Award, Printer, Copy, Check, X, Sparkles } from 'lucide-react';
import { formatCurrency } from '../../../shared/formatUtils';
import { toast } from '../../../shared/toast';

interface SaleSuccessModalProps {
  isOpen: boolean;
  onClose: () => void;
  sale: any;
  change?: number;
  onPrint?: () => void;
}

export function SaleSuccessModal({
  isOpen,
  onClose,
  sale,
  change = 0,
  onPrint,
}: SaleSuccessModalProps) {
  const [qrUrl, setQrUrl] = useState<string>('');
  const [copied, setCopied] = useState(false);

  const loyalty = sale?.loyaltyInfo;
  const claimUrl = loyalty?.claimUrl || '';

  useEffect(() => {
    if (!claimUrl) {
      setQrUrl('');
      return;
    }
    QRCode.toDataURL(claimUrl, {
      width: 480,
      margin: 1,
      color: { dark: '#1c1917', light: '#ffffff' },
      errorCorrectionLevel: 'M',
    })
      .then(setQrUrl)
      .catch((e) => {
        console.error('Error generating QR:', e);
        setQrUrl('');
      });
  }, [claimUrl]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;
      if (e.key === 'Escape') onClose();
      if (e.key === 'Enter' && onPrint) onPrint();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose, onPrint]);

  if (!isOpen || !sale) return null;

  const copyLink = async () => {
    if (!claimUrl) return;
    try {
      await navigator.clipboard.writeText(claimUrl);
      setCopied(true);
      toast.success('Enlace de reclamo copiado al portapapeles');
      setTimeout(() => setCopied(false), 2500);
    } catch {
      toast.error('No se pudo copiar el enlace');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden text-slate-800">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-600 to-teal-600 p-6 text-white text-center relative">
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-full transition-colors"
            aria-label="Cerrar"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="mx-auto w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center mb-3 shadow-inner">
            <CheckCircle2 className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-2xl font-black font-heading tracking-tight">¡Venta Cobrada con Éxito!</h2>
          <p className="text-emerald-100 text-sm mt-0.5">Venta #{sale.saleNumber || sale.id?.slice(0, 8)}</p>
        </div>

        <div className="p-6 space-y-5">
          {/* Resumen de cobro */}
          <div className="grid grid-cols-2 gap-3 p-4 rounded-2xl bg-slate-50 border border-slate-200/80">
            <div>
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">Total Pagado</span>
              <span className="text-xl font-black text-slate-900 tabular-nums">
                {formatCurrency(sale.total || 0)}
              </span>
            </div>
            {change > 0 && (
              <div className="text-right border-l border-slate-200 pl-3">
                <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider block">Cambio a Devolver</span>
                <span className="text-xl font-black text-emerald-600 tabular-nums">
                  {formatCurrency(change)}
                </span>
              </div>
            )}
          </div>

          {/* Bloque de Fidelidad y QR */}
          {loyalty && loyalty.stampsAdded > 0 && (
            <div className="rounded-2xl border-2 border-amber-300 bg-gradient-to-b from-amber-50/90 to-orange-50/40 p-5 text-center space-y-3 shadow-sm">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500 text-white text-xs font-black tracking-wide shadow-sm">
                <Award className="w-4 h-4" />
                ¡ESTA COMPRA OTORGA {loyalty.stampsAdded} {loyalty.stampsAdded === 1 ? 'SELLO' : 'SELLOS'}!
                <Sparkles className="w-3.5 h-3.5 text-amber-200" />
              </div>
              <p className="text-xs text-amber-950 font-medium">
                Pídele al cliente que escanee este código QR con la cámara de su celular para estampar su tarjeta digital:
              </p>

              {qrUrl ? (
                <div className="inline-block p-3 bg-white rounded-2xl shadow-md border border-amber-200">
                  <img src={qrUrl} alt="QR de fidelidad" className="w-48 h-48 mx-auto object-contain" />
                </div>
              ) : (
                <div className="w-48 h-48 mx-auto bg-white rounded-2xl border border-amber-200 flex items-center justify-center text-xs text-slate-400">
                  Generando QR...
                </div>
              )}

              <div className="flex items-center justify-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={copyLink}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-amber-300 bg-white hover:bg-amber-100 text-amber-900 text-xs font-bold transition-all shadow-xs"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  {copied ? '¡Copiado!' : 'Copiar enlace de reclamo'}
                </button>
              </div>
            </div>
          )}

          {/* Botones de acción */}
          <div className="flex items-center gap-3 pt-2">
            {onPrint && (
              <button
                type="button"
                onClick={onPrint}
                className="flex-1 inline-flex items-center justify-center gap-2 min-h-[46px] rounded-xl border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-sm font-bold transition-all shadow-sm"
              >
                <Printer className="w-4 h-4 text-slate-600" />
                Imprimir Recibo (Enter)
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="flex-1 inline-flex items-center justify-center gap-2 min-h-[46px] rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-sm font-bold transition-all shadow-sm"
            >
              Nueva Venta (Esc)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
