// ============================================
// APPLICATION - Duplicate Cleanup Use Cases
// ============================================

import { ProductRepository } from '../../infrastructure/persistence/repositories/ProductRepository';

export class DuplicateCleanupUseCases {
  constructor(private productRepository: ProductRepository) {}

  async findDuplicates() {
    // Obtener todos los productos (incluyendo inactivos) para ver el panorama completo
    const products = await this.productRepository.getAll(true);
    const groups = new Map<string, any[]>();

    products.forEach(p => {
      // Agrupar por nombre (sin espacios y en minúsculas) y categoría
      const normalizedName = p.name.toLowerCase().trim();
      const key = `${normalizedName}:::${p.categoryId || 'sin-categoria'}`;
      
      if (!groups.has(key)) {
        groups.set(key, []);
      }
      groups.get(key)!.push(p);
    });

    const duplicates = Array.from(groups.entries())
      .filter(([_, items]) => items.length > 1)
      .map(([key, items]) => ({
        key,
        name: items[0].name,
        categoryId: items[0].categoryId,
        categoryName: items[0].category?.name || 'Sin Categoría',
        count: items.length,
        items: items.map(i => ({
          id: i.id,
          isActive: i.isActive,
          variantsCount: i.variants?.length || 0,
          variants: i.variants?.map((v: any) => ({ sku: v.sku, name: v.name, price: v.price })),
          createdAt: i.createdAt
        }))
      }));

    return duplicates;
  }

  async cleanupDuplicates(keys: string[]) {
    const products = await this.productRepository.getAll(true) as any[];
    const results = { count: 0, errors: [] as string[] };

    for (const key of keys) {
      try {
        const [namePart, catId] = key.split(':::');
        const categoryId = catId === 'sin-categoria' ? null : catId;
        
        const group = products.filter(p => 
          p.name.toLowerCase().trim() === namePart && 
          (p.categoryId === categoryId || (!p.categoryId && !categoryId))
        ) as any[];

        if (group.length <= 1) continue;

        // Decidir cuál mantener (Master)
        // Criterios: 1. Activo, 2. Con más variantes, 3. Más reciente
        group.sort((a, b) => {
          if (a.isActive && !b.isActive) return -1;
          if (!a.isActive && b.isActive) return 1;
          const varDiff = (b.variants?.length || 0) - (a.variants?.length || 0);
          if (varDiff !== 0) return varDiff;
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        });

        const master = group[0];
        const duplicates = group.slice(1);

        for (const dup of duplicates) {
          // Si el duplicado tiene variantes, intentar moverlas al master si el SKU no existe allí
          if (dup.variants && dup.variants.length > 0) {
            for (const v of dup.variants) {
              const skuExistsInMaster = master.variants?.some((mv: any) => mv.sku === v.sku);
              
              if (!skuExistsInMaster) {
                // Mover variante al producto master
                await this.productRepository.updateVariant(v.id, { productId: master.id });
              } else {
                // Si el SKU ya existe, esta variante es redundante (o tiene mismo SKU en diferente producto)
                // Primero intentamos borrarla permanentemente. 
                // NOTA: Si tiene ventas asociadas, Prisma podría fallar por FK.
                try {
                  await this.productRepository.permanentDeleteVariant(v.id);
                } catch (e) {
                  // Si falla por FK, simplemente la desactivamos
                  await this.productRepository.deleteVariant(v.id);
                }
              }
            }
          }
          
          // Eliminar el producto duplicado
          try {
            await this.productRepository.permanentDelete(dup.id);
          } catch (e) {
            // Si falla por FK, soft delete
            await this.productRepository.delete(dup.id);
          }
          results.count++;
        }
      } catch (err: any) {
        results.errors.push(`Error procesando grupo "${key}": ${err.message}`);
      }
    }
    
    return results;
  }
}
