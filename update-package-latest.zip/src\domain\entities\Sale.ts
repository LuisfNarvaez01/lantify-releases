// ============================================
// DOMAIN ENTITIES - Sale
// ============================================

export type SaleStatus = 'PENDING' | 'COMPLETED' | 'CANCELLED' | 'REFUNDED';
export type PaymentMethod = 'CASH' | 'CARD' | 'TRANSFER' | 'MIXED';

export interface SaleItem {
  id: string;
  saleId: string;
  productVariantId: string;
  quantity: number;
  unitPrice: number;
  total: number;
  notes: string | null;
  // Campos de anulación
  isCancelled: boolean;
  cancellationReason: string | null;
  cancelledAt: Date | null;
  cancelledBy: string | null;
  createdAt: Date;
}

export interface Sale {
  id: string;
  saleNumber: string;
  tableId: string | null;
  cashSessionId: string | null;
  subtotal: number;
  tax: number;
  discount: number;
  total: number;
  paymentMethod: PaymentMethod;
  status: SaleStatus;
  notes: string | null;
  createdAt: Date;
  updatedAt: Date;
  items?: SaleItem[];
}

// Factory para crear SaleItem
export const createSaleItem = (
  data: Omit<SaleItem, 'id' | 'createdAt' | 'isCancelled' | 'cancellationReason' | 'cancelledAt' | 'cancelledBy'>
): SaleItem => {
  return {
    ...data,
    notes: data.notes ?? null,
    id: crypto.randomUUID(),
    isCancelled: false,
    cancellationReason: null,
    cancelledAt: null,
    cancelledBy: null,
    createdAt: new Date(),
  };
};

// Factory para crear Sale
export const createSale = (
  data: Omit<Sale, 'id' | 'createdAt' | 'updatedAt' | 'saleNumber'>
): Sale => {
  const now = new Date();
  const saleNumber = `SALE-${now.getFullYear()}${(now.getMonth() + 1).toString().padStart(2, '0')}${now.getDate().toString().padStart(2, '0')}-${Math.floor(Math.random() * 10000).toString().padStart(4, '0')}`;
  
  return {
    ...data,
    tableId: data.tableId ?? null,
    cashSessionId: data.cashSessionId ?? null,
    notes: data.notes ?? null,
    id: crypto.randomUUID(),
    saleNumber,
    createdAt: now,
    updatedAt: now,
  };
};

// Calcular total de venta
export const calculateSaleTotal = (
  items: { quantity: number; unitPrice: number }[],
  taxRate: number = 0,
  discount: number = 0
): { subtotal: number; tax: number; total: number } => {
  const subtotal = items.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0);
  const tax = subtotal * taxRate;
  const total = subtotal + tax - discount;
  
  return { subtotal, tax, total };
};