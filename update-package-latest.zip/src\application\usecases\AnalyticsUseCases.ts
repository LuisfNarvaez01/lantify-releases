// ============================================
// APPLICATION USE CASES - Analytics Use Cases
// ============================================

import { prisma } from '../../infrastructure/database/prisma';

export interface CompareMonthResult {
  monthKey: string;
  label: string;
  year: number;
  month: number;
  totalRevenue: number;
  completedCount: number;
  cancelledCount: number;
  avgTicket: number;
  totalItemsSold: number;
  paymentBreakdown: {
    CASH: number;
    CARD: number;
    TRANSFER: number;
    MIXED: number;
  };
  topProducts: {
    name: string;
    variantName: string;
    units: number;
    revenue: number;
  }[];
}

export interface ProductStat {
  productId: string;
  variantId: string;
  productName: string;
  variantName: string;
  categoryName: string;
  unitsSold: number;
  totalRevenue: number;
  unitPrice: number;
  revenueSharePct: number;
  volumeSharePct: number;
}

const MESES = [
  'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
  'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
];

export class AnalyticsUseCases {

  /**
   * Obtiene la lista de meses disponibles con ventas para analítica
   */
  async getAvailableMonths(): Promise<{ year: number; month: number; label: string; count: number; totalRevenue: number }[]> {
    const sales = await prisma.sale.findMany({
      select: { createdAt: true, total: true, status: true },
      orderBy: { createdAt: 'desc' },
    });

    const monthMap = new Map<string, { year: number; month: number; count: number; totalRevenue: number }>();

    for (const sale of sales) {
      const d = new Date(sale.createdAt);
      const year = d.getFullYear();
      const month = d.getMonth() + 1;
      const key = `${year}-${String(month).padStart(2, '0')}`;
      const rev = sale.status === 'COMPLETED' ? (sale.total ?? 0) : 0;

      if (monthMap.has(key)) {
        const item = monthMap.get(key)!;
        item.count++;
        item.totalRevenue += rev;
      } else {
        monthMap.set(key, { year, month, count: 1, totalRevenue: rev });
      }
    }

    return Array.from(monthMap.entries())
      .sort((a, b) => b[0].localeCompare(a[0]))
      .map(([, v]) => ({
        year: v.year,
        month: v.month,
        label: `${MESES[v.month - 1]} ${v.year}`,
        count: v.count,
        totalRevenue: v.totalRevenue,
      }));
  }

  /**
   * Comparativa estadística entre múltiples meses seleccionados
   */
  async compareMonths(monthKeys: string[]): Promise<CompareMonthResult[]> {
    if (!monthKeys || monthKeys.length === 0) return [];

    const results: CompareMonthResult[] = [];

    for (const key of monthKeys) {
      const [yearStr, monthStr] = key.split('-');
      const year = parseInt(yearStr);
      const month = parseInt(monthStr);

      if (isNaN(year) || isNaN(month) || month < 1 || month > 12) continue;

      const startDate = new Date(year, month - 1, 1, 0, 0, 0, 0);
      const endDate   = new Date(year, month, 0, 23, 59, 59, 999);

      const wherePeriod: any = {
        createdAt: { gte: startDate, lte: endDate }
      };

      const completedWhere: any = {
        ...wherePeriod,
        status: 'COMPLETED'
      };

      const [
        completedCount,
        cancelledCount,
        aggregateCompleted,
        cashSales,
        cardSales,
        transferSales,
        mixedSales,
        saleItems
      ] = await Promise.all([
        prisma.sale.count({ where: completedWhere }),
        prisma.sale.count({ where: { ...wherePeriod, status: 'CANCELLED' as any } }),
        prisma.sale.aggregate({ where: completedWhere, _sum: { total: true } }),
        prisma.sale.aggregate({ where: { ...completedWhere, paymentMethod: 'CASH' as any }, _sum: { total: true } }),
        prisma.sale.aggregate({ where: { ...completedWhere, paymentMethod: 'CARD' as any }, _sum: { total: true } }),
        prisma.sale.aggregate({ where: { ...completedWhere, paymentMethod: 'TRANSFER' as any }, _sum: { total: true } }),
        prisma.sale.aggregate({ where: { ...completedWhere, paymentMethod: 'MIXED' as any }, _sum: { total: true } }),
        prisma.saleItem.findMany({
          where: {
            sale: completedWhere,
            isCancelled: false
          },
          include: {
            productVariant: {
              include: { product: true }
            }
          }
        })
      ]);

      const totalRevenue = aggregateCompleted?._sum?.total ?? 0;
      const avgTicket    = completedCount > 0 ? totalRevenue / completedCount : 0;
      const totalItemsSold = saleItems.reduce((sum, item) => sum + item.quantity, 0);

      // Top 3 productos del mes
      const productMap: Record<string, { name: string; variantName: string; units: number; revenue: number }> = {};
      for (const item of saleItems as any[]) {
        const pKey = item.productVariantId;
        const pName = item.productVariant?.product?.name || item.productName || 'Producto';
        const vName = item.productVariant?.name || item.variantName || '';
        if (!productMap[pKey]) {
          productMap[pKey] = { name: pName, variantName: vName, units: 0, revenue: 0 };
        }
        productMap[pKey].units += item.quantity;
        productMap[pKey].revenue += item.total;
      }

      const topProducts = Object.values(productMap)
        .sort((a, b) => b.units - a.units)
        .slice(0, 3);

      results.push({
        monthKey: key,
        label: `${MESES[month - 1]} ${year}`,
        year,
        month,
        totalRevenue,
        completedCount,
        cancelledCount,
        avgTicket,
        totalItemsSold,
        paymentBreakdown: {
          CASH:     cashSales?._sum?.total ?? 0,
          CARD:     cardSales?._sum?.total ?? 0,
          TRANSFER: transferSales?._sum?.total ?? 0,
          MIXED:    mixedSales?._sum?.total ?? 0,
        },
        topProducts
      });
    }

    // Ordenar de más antiguo a más reciente para la gráfica comparativa
    return results.sort((a, b) => a.monthKey.localeCompare(b.monthKey));
  }

  /**
   * Reporte detallado de productos más vendidos y mayor demanda (por mes o Histórico Total)
   */
  async getTopProducts(year: number, month: number, limit: number = 50): Promise<{
    items: ProductStat[];
    periodLabel: string;
    totalRevenue: number;
    totalUnits: number;
  }> {
    let wherePeriod: any = {};
    let periodLabel = 'Histórico Total (Todas las Ventas)';

    if (year > 0 && month > 0 && month <= 12) {
      const startDate = new Date(year, month - 1, 1, 0, 0, 0, 0);
      const endDate   = new Date(year, month, 0, 23, 59, 59, 999);
      wherePeriod.createdAt = { gte: startDate, lte: endDate };
      periodLabel = `${MESES[month - 1]} ${year}`;
    }

    const saleItems = await prisma.saleItem.findMany({
      where: {
        sale: {
          ...wherePeriod,
          status: 'COMPLETED' as any
        },
        isCancelled: false
      },
      include: {
        productVariant: {
          include: {
            product: {
              include: { category: true }
            }
          }
        }
      }
    });

    const productMap: Record<string, {
      productId: string;
      variantId: string;
      productName: string;
      variantName: string;
      categoryName: string;
      unitsSold: number;
      totalRevenue: number;
      unitPrice: number;
    }> = {};

    let grandTotalRevenue = 0;
    let grandTotalUnits = 0;

    for (const item of saleItems as any[]) {
      const vId = item.productVariantId;
      const pName = item.productVariant?.product?.name || item.productName || 'Producto';
      const vName = item.productVariant?.name || item.variantName || '';
      const cName = item.productVariant?.product?.category?.name || 'Sin Categoría';
      const pId = item.productVariant?.productId || '';

      if (!productMap[vId]) {
        productMap[vId] = {
          productId: pId,
          variantId: vId,
          productName: pName,
          variantName: vName,
          categoryName: cName,
          unitsSold: 0,
          totalRevenue: 0,
          unitPrice: 0
        };
      }

      productMap[vId].unitsSold += item.quantity;
      productMap[vId].totalRevenue += item.total;
      grandTotalRevenue += item.total;
      grandTotalUnits += item.quantity;
    }

    // Calculate weighted average unit price per variant for the period
    for (const key of Object.keys(productMap)) {
      const p = productMap[key];
      p.unitPrice = p.unitsSold > 0 ? p.totalRevenue / p.unitsSold : 0;
    }

    const items: ProductStat[] = Object.values(productMap).map(p => ({
      ...p,
      revenueSharePct: grandTotalRevenue > 0 ? (p.totalRevenue / grandTotalRevenue) * 100 : 0,
      volumeSharePct:  grandTotalUnits > 0   ? (p.unitsSold / grandTotalUnits) * 100 : 0,
    }));

    return {
      items: items.slice(0, limit),
      periodLabel,
      totalRevenue: grandTotalRevenue,
      totalUnits: grandTotalUnits
    };
  }
}
