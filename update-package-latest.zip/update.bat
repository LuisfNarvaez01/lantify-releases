@echo off
setlocal enabledelayedexpansion

title LantifyPOS - Asistente de Actualizacion Segura

echo ======================================================
echo           LANTIFY POS - ACTUALIZADOR SEGURO          
echo ======================================================
echo.

cd /d "%~dp0"

echo [1/7] Generando respaldo seguro y verificado de base de datos...
node scripts/backup-db.js
if %errorlevel% neq 0 (
    echo.
    echo ❌ [ERROR CRITICO] Fallo la creacion del respaldo de la base de datos.
    echo Por seguridad, la actualizacion se cancela para evitar riesgo de perdida de datos.
    pause
    exit /b 1
)
echo      Respaldo guardado correctamente.

echo.
echo [2/7] Comprobando y descargando ultimos cambios del sistema...
git pull
if %errorlevel% neq 0 (
    echo.
    echo ❌ [ERROR] No se pudo descargar la actualizacion desde el repositorio.
    echo Comprueba la conexion a internet y que no existan conflictos locales.
    pause
    exit /b 1
)

echo.
echo [3/7] Verificando dependencias del servidor...
call npm install --no-audit --no-fund
if %errorlevel% neq 0 (
    echo.
    echo ❌ [ERROR] Fallo npm install en el servidor.
    pause
    exit /b 1
)

echo.
echo [4/7] Verificando dependencias del frontend...
cd frontend
call npm install --no-audit --no-fund
if %errorlevel% neq 0 (
    echo.
    echo ❌ [ERROR] Fallo npm install en el frontend.
    cd ..
    pause
    exit /b 1
)
cd ..

echo.
echo [5/7] Aplicando cambios en estructura de base de datos (seguro, sin perdida de datos)...
call npx prisma db push
if %errorlevel% neq 0 (
    echo.
    echo ❌ [ERROR EN MIGRACION] Prisma no pudo aplicar la actualizacion de la base de datos.
    echo 🛡️ Iniciando protocolo de restauracion de base de datos previa...
    node scripts/backup-db.js --restore
    echo Tu base de datos ha sido restaurada a su estado original sin perdida de informacion.
    pause
    exit /b 1
)

call npx prisma generate
if %errorlevel% neq 0 (
    echo ⚠️ [ADVERTENCIA] No se pudo regenerar Prisma Client en caliente (puede estar en uso por un proceso activo).
)

echo.
echo [6/7] Compilando sistema optimizado...
call npm run build
cd frontend
call npm run build
cd ..

echo.
echo [7/7] Actualizacion finalizada con exito.
node scripts/show-changelog.js

echo.
echo ======================================================
echo    Tu sistema Lantify POS esta 100% actualizado.       
echo    Tus ventas, clientes y configuraciones estan a salvo.
echo ======================================================
echo.
pause
