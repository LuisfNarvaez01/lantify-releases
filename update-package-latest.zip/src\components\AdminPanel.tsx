import { useState, useEffect, useRef } from 'react';
import { confirmDialog } from '../shared/dialog';
import { productsAPI } from '../services/api';
import { Package, Plus, Upload, Grid, Trash2, ArrowLeft, X, FileUp, Settings, Edit2, Save, Check, LogOut, Info, Download, Users, Truck, Boxes, Shield, Ticket, Globe } from 'lucide-react';
import { CustomersAdmin } from './admin/CustomersAdmin';
import { InventoryModule } from './admin/InventoryModule';
import { UsersAdmin } from './admin/UsersAdmin';
import { SystemConfigAdmin } from './admin/SystemConfigAdmin';
import { TablesManager } from './admin/TablesManager';
import { SuppliersModule } from './admin/SuppliersModule';
import { PageModule } from './admin/PageModule';
import { CouponsAdmin } from './admin/CouponsAdmin';
import { PlanLocked, LockBadge } from './common/PlanLocked';
import { usePlan } from '../shared/plan';
import { DEFAULT_THEME } from '../shared/themeManager';
import { toast } from '../shared/toast';

import { API_URL } from '../config';

import { t } from '../i18n';
import { useBusiness, formatTaxLabel } from '../shared/business';

// Impuesto del producto en el formulario: '' = el del negocio, 'NONE' o 'TIPO:tarifa'
const TAX_OPTIONS = ['', 'INC:8', 'IVA:19', 'IVA:5', 'NONE'];
const encodeTaxOption = (taxType?: string | null, taxRate?: number | null) => {
  if (!taxType) return '';
  if (taxType === 'NONE') return 'NONE';
  return `${taxType}:${taxRate ?? 0}`;
};
const decodeTaxOption = (value: string): { taxType: string | null; taxRate: number | null } => {
  if (!value) return { taxType: null, taxRate: null };
  if (value === 'NONE') return { taxType: 'NONE', taxRate: 0 };
  const [taxType, rate] = value.split(':');
  return { taxType, taxRate: Number(rate) };
};
const getToken = () => localStorage.getItem('token');

interface AdminPanelProps {
  user: any;
  onLogout: () => void;
  onClose?: () => void;
  /** Pestaña con la que abre (p. ej. 'config' para el recorrido de configuración) */
  initialTab?: string;
}

export function AdminPanel({ user, onLogout, onClose, initialTab }: AdminPanelProps) {
  const plan = usePlan();
  const { settings: business } = useBusiness();
  const businessTaxLabel = formatTaxLabel(business?.defaultTaxType, business?.defaultTaxRate) || t('admin:sin_impuesto');
  // 'tables' era la pestaña anterior de mesas: hoy vive en Salón y mesas
  const [activeTab, setActiveTab] = useState(initialTab === 'tables' ? 'salon' : initialTab === 'expense-categories' || initialTab === 'expenses' ? 'suppliers' : initialTab || 'products');
  const [products, setProducts] = useState<any[]>([]);
  const [showProductForm, setShowProductForm] = useState(false);
  
  const toggleProductForm = (val: boolean) => {
    setShowProductForm(val);
    setFormError(null);
    if (!val) setEditingProduct(null);
  };
  
  const [showImportModal, setShowImportModal] = useState(false);
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [csvContent, setCsvContent] = useState('');
  const [importResult, setImportResult] = useState<any>(null);
  const [categories, setCategories] = useState<any[]>([]);
  const [showNewCategoryModal, setShowNewCategoryModal] = useState(false);
  const [newCategoryForm, setNewCategoryForm] = useState({ name: '', description: '' });
  const [formError, setFormError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Estado para limpieza de duplicados
  const [showDuplicatesModal, setShowDuplicatesModal] = useState(false);
  const [duplicateGroups, setDuplicateGroups] = useState<any[]>([]);
  const [isSearchingDuplicates, setIsSearchingDuplicates] = useState(false);
  const [isCleaningDuplicates, setIsCleaningDuplicates] = useState(false);
  const [cleanupResult, setCleanupResult] = useState<any>(null);
  
  // Estado para selección múltiple de productos
  const [selectedProducts, setSelectedProducts] = useState<Set<string>>(new Set());
  const [selectionMode, setSelectionMode] = useState(false);
  
  // Estado para editar producto
  const [editingProduct, setEditingProduct] = useState<any>(null);
  
  // Estado para configuración
  const [config, setConfig] = useState(() => {
    const saved = localStorage.getItem('posConfig');
    return saved ? JSON.parse(saved) : {
      businessName: t('admin:lantify_pos'),
      address: '',
      phone: '',
      taxRate: 19,
      nit: '',
      receiptTemplate: t('admin:businessname_address_phone_mesa_table_fecha_date'),
      kitchenTemplate: t('admin:comanda_mesa_table_hora_time_items'),
      receiptFont: 'sans-serif',
      receiptLogo: '/logo-lantify.svg',
      invoicePrinter: t('admin:impresora_termica'),
      kitchenPrinter: t('admin:impresora_cocina'),
      paperWidth: '80mm',
      receiptMargin: '2mm',
      fontSizeTicket: 'medium',
      ticketFooterText: t('admin:gracias_por_su_visita'),
      theme: DEFAULT_THEME
    };
  });

  
  const [productForm, setProductForm] = useState({
    name: '',
    description: '',
    category: '',
    variantName: '',
    sku: '',
    price: '',
    cost: '',
    stock: '',
    tax: ''
  });
  
  useEffect(() => {
    loadProducts();
    loadCategories();
  }, []);

  const loadCategories = async () => {
    try {
      const data = await productsAPI.getCategories();
      setCategories(data);
    } catch (err) {
      console.error('Error loading categories:', err);
    }
  };

  const handleCreateCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCategoryForm.name.trim()) return;
    try {
      await productsAPI.createCategory(newCategoryForm);
      setNewCategoryForm({ name: '', description: '' });
      setShowNewCategoryModal(false);
      loadCategories();
    } catch (err: any) {
      setFormError(err.message || t('admin:error_al_crear_la_categoria'));
    }
  };

  const loadProducts = async () => {
    try {
      const data = await productsAPI.getAll();
      setProducts(data);
    } catch (err) {
      console.error('Error loading products:', err);
    }
  };

  const handleProductSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    
    // Validación básica
    if (!productForm.name.trim()) {
      setFormError(t('admin:el_nombre_del_producto_es_obligatorio'));
      return;
    }
    if (!productForm.variantName.trim()) {
      setFormError(t('admin:la_variante_ej_regular_grande_es_obligatoria'));
      return;
    }
    if (!productForm.sku.trim()) {
      setFormError(t('admin:el_sku_es_obligatorio'));
      return;
    }
    if (!productForm.price.trim() || isNaN(parseFloat(productForm.price))) {
      setFormError(t('admin:el_precio_debe_ser_un_numero_valido'));
      return;
    }

    try {
      if (editingProduct) {
        await productsAPI.update(editingProduct.id, {
          name: productForm.name,
          description: productForm.description || null,
          categoryId: productForm.category || null,
          ...decodeTaxOption(productForm.tax),
        });
        if (editingProduct.variants?.[0]?.id) {
          await fetch(`${API_URL}/products/variants/${editingProduct.variants[0].id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${getToken()}` },
            body: JSON.stringify({
              name: productForm.variantName,
              sku: productForm.sku,
              price: parseFloat(productForm.price) || 0,
              cost: productForm.cost ? parseFloat(productForm.cost) || 0 : 0,
              stock: parseInt(productForm.stock) || 0
            })
          });
        }
      } else {
        await productsAPI.create({
          name: productForm.name,
          description: productForm.description || null,
          categoryId: productForm.category || null,
          ...decodeTaxOption(productForm.tax),
          variants: [{
            name: productForm.variantName,
            sku: productForm.sku,
            price: parseFloat(productForm.price) || 0,
            cost: productForm.cost ? parseFloat(productForm.cost) || 0 : 0,
            stock: parseInt(productForm.stock) || 0
          }]
        });
      }
      toggleProductForm(false);
      setProductForm({ name: '', description: '', category: '', variantName: '', sku: '', price: '', cost: '', stock: '', tax: '' });
      setEditingProduct(null);
      loadProducts();
    } catch (err: any) {
      console.error('Error saving product:', err);
      setFormError(err.message || t('admin:error_al_guardar_el_producto_por_favor'));
    }
  };

  const handleCSVImport = async () => {
    if (!csvContent && !csvFile) return;
    setImportResult(null);
    try {
      let content = csvContent;
      if (csvFile) {
        content = await csvFile.text();
      }
      const result = await productsAPI.importCSV(content);
      setImportResult(result);
      loadProducts();
      // Solo limpiar si hubo éxito total
      if (result.success > 0 && result.errors.length === 0) {
        setTimeout(() => {
          setShowImportModal(false);
          setCsvFile(null);
          setCsvContent('');
          setImportResult(null);
        }, 2000);
      }
    } catch (err: any) {
      setImportResult({ success: 0, errors: [err.message] });
    }
  };

  const handleDownloadTemplate = async () => {
    try {
      const response = await fetch(`${API_URL}/products/import/template`);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'plantilla_productos.csv';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      toast.success(t('admin:plantilla_csv_descargada'));
    } catch (err) {
      console.error('Error downloading template:', err);
      toast.error('Error al descargar la plantilla CSV');
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setCsvFile(file);
      setCsvContent('');
    }
  };

  const handleDeleteProduct = async (id: string) => {
    if (!(await confirmDialog({ title: t('admin:eliminar_este_producto'), message: t('admin:dejara_de_aparecer_en_el_catalogo_las'), confirmLabel: t('admin:eliminar'), tone: 'danger' }))) return;
    try {
      await productsAPI.delete(id);
      toast.success(t('admin:producto_eliminado'));
      loadProducts();
    } catch (err) {
      console.error('Error deleting product:', err);
      toast.error('Error al eliminar producto');
    }
  };

  const handleFindDuplicates = async () => {
    setIsSearchingDuplicates(true);
    setCleanupResult(null);
    try {
      const data = await productsAPI.getDuplicates();
      setDuplicateGroups(data);
      setShowDuplicatesModal(true);
    } catch (err) {
      console.error('Error finding duplicates:', err);
      toast.error('Error al buscar duplicados');
    } finally {
      setIsSearchingDuplicates(false);
    }
  };

  const handleCleanupDuplicates = async () => {
    if (!(await confirmDialog({ title: t('admin:fusionar_value_productos_duplicados', { value: duplicateGroups.reduce((acc, g) => acc + g.count - 1, 0) }), message: t('admin:se_conservara_la_version_mas_completa_de'), confirmLabel: t('admin:fusionar'), tone: 'danger' }))) return;
    
    setIsCleaningDuplicates(true);
    try {
      const keys = duplicateGroups.map(g => g.key);
      const result = await productsAPI.cleanupDuplicates(keys);
      setCleanupResult(result);
      toast.success(t('admin:limpieza_de_duplicados_completada'));
      loadProducts();
      // Recargar duplicados para mostrar que ya no hay
      const newData = await productsAPI.getDuplicates();
      setDuplicateGroups(newData);
    } catch (err) {
      console.error('Error cleaning up duplicates:', err);
      toast.error('Error al limpiar duplicados');
    } finally {
      setIsCleaningDuplicates(false);
    }
  };

  const toggleSelectionMode = () => {
    setSelectionMode(!selectionMode);
    if (!selectionMode) {
      setSelectedProducts(new Set());
    }
  };

  const toggleProductSelection = (productId: string) => {
    const newSelected = new Set(selectedProducts);
    if (newSelected.has(productId)) {
      newSelected.delete(productId);
    } else {
      newSelected.add(productId);
    }
    setSelectedProducts(newSelected);
  };

  const selectAllProducts = () => {
    if (selectedProducts.size === products.length) {
      setSelectedProducts(new Set());
    } else {
      setSelectedProducts(new Set(products.map(p => p.id)));
    }
  };

  const deleteSelectedProducts = async () => {
    if (!(await confirmDialog({ title: t('admin:eliminar_size_productos', { size: selectedProducts.size }), message: t('admin:dejaran_de_aparecer_en_el_catalogo_las'), confirmLabel: t('admin:eliminar'), tone: 'danger' }))) return;
    try {
      for (const productId of selectedProducts) {
        await productsAPI.delete(productId);
      }
      setSelectedProducts(new Set());
      setSelectionMode(false);
      loadProducts();
    } catch (err) {
      console.error('Error deleting products:', err);
    }
  };

  return (
    <div className="h-screen flex flex-col overflow-hidden bg-slate-100 font-sans">
      {/* Branded Header */}
      <header className="bg-slate-900 shadow-md border-b border-slate-800 z-20">
        <div className="max-w-7xl mx-auto px-4 h-16 flex justify-between items-center">
          <div className="flex items-center gap-4">
            {onClose && (
              <button
                onClick={onClose}
                className="p-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-xl transition-colors"
                title={t('admin:volver_al_pos')}
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
            )}
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-600 rounded-xl text-white shadow-sm">
                <Settings className="w-5 h-5" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-white tracking-wide font-heading">{t('admin:administracion_lantify')}</h1>
                <p className="text-xs text-slate-400 font-medium">{t('admin:gestion_de_catalogo_mesas_y_parametros')}</p>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-slate-800 rounded-xl border border-slate-700/60">
              <div className="w-7 h-7 rounded-full bg-blue-600 flex items-center justify-center">
                <span className="text-white font-bold text-xs">
                  {user.name?.charAt(0)?.toUpperCase()}
                </span>
              </div>
              <span className="text-xs text-slate-200 font-semibold max-w-[150px] truncate">
                {user.name}
              </span>
            </div>
            <button
              onClick={onLogout}
              className="p-2 text-slate-400 hover:text-rose-300 hover:bg-rose-950/40 rounded-xl transition-colors border border-slate-800"
              title={t('admin:cerrar_sesion')}
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Branded Tab Bar */}
      <div className="bg-slate-950 px-4 py-2 flex items-center gap-2 overflow-x-auto border-b border-slate-800">
        <div className="max-w-7xl mx-auto w-full flex gap-1.5">
          <button
            onClick={() => setActiveTab('products')}
            className={`
              flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all duration-150
              ${activeTab === 'products'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'}
            `}
          >
            <Package className="w-4 h-4" />
            {t('admin:productos')}
          </button>
          <button
            onClick={() => setActiveTab('inventory')}
            className={`
              flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all duration-150
              ${activeTab === 'inventory'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'}
            `}
          >
            <Boxes className="w-4 h-4" />
            {t('admin:inventario')}
          </button>
          <button
            onClick={() => setActiveTab('salon')}
            className={`
              flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all duration-150
              ${activeTab === 'salon'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'}
            `}
          >
            <Grid className="w-4 h-4" />
            {t('admin:salon_y_mesas')}
          </button>
          <button
            onClick={() => setActiveTab('customers')}
            className={`
              flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all duration-150
              ${activeTab === 'customers'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'}
            `}
          >
            <Users className="w-4 h-4" />
            {t('admin:clientes')}
            {!plan.has('customers') && <LockBadge />}
          </button>
          <button
            onClick={() => setActiveTab('page')}
            className={`
              flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all duration-150
              ${activeTab === 'page'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'}
            `}
          >
            <Globe className="w-4 h-4" />
            {t('admin:mi_pagina')}
          </button>
          <button
            onClick={() => setActiveTab('coupons')}
            className={`
              flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all duration-150
              ${activeTab === 'coupons'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'}
            `}
          >
            <Ticket className="w-4 h-4" />
            {t('admin:cupones')}
            {!plan.has('coupons') && <LockBadge />}
          </button>
          <button
            onClick={() => setActiveTab('suppliers')}
            className={`
              flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all duration-150
              ${activeTab === 'suppliers'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'}
            `}
          >
            <Truck className="w-4 h-4" />
            {t('admin:proveedores')}
          </button>
          <button
            onClick={() => setActiveTab('users')}
            className={`
              flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all duration-150
              ${activeTab === 'users'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'}
            `}
          >
            <Shield className="w-4 h-4" />
            {t('admin:usuarios_y_roles')}
          </button>
          <button
            onClick={() => setActiveTab('config')}
            className={`
              flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all duration-150
              ${activeTab === 'config'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'}
            `}
          >
            <Settings className="w-4 h-4" />
            {t('admin:configuracion')}
          </button>
        </div>
      </div>

      {/* Main Content Area (Scrollable) */}
      <div className="flex-1 overflow-y-auto custom-scrollbar">
        <div className="max-w-7xl mx-auto px-4 py-8">
          {/* Products Tab */}
          {activeTab === 'products' && (
            <div className="space-y-6">
              <div className="flex flex-wrap gap-4 items-center">
                <button
                  onClick={() => toggleProductForm(true)}
                  className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-2xl font-bold transition-all shadow-sm"
                >
                  <Plus className="w-5 h-5" />
                  {t('admin:nuevo_producto')}
                </button>
                <button
                  onClick={() => setShowImportModal(true)}
                  className="flex items-center gap-2 bg-white text-slate-700 border border-slate-300 px-6 py-3 rounded-2xl font-bold hover:bg-slate-50 transition-all shadow-sm"
                >
                  <Upload className="w-5 h-5 text-slate-500" />
                  {t('admin:importar_csv')}
                </button>
                {products.length > 0 && (
                  <button
                    onClick={toggleSelectionMode}
                    className={`flex items-center gap-2 px-6 py-3 rounded-2xl font-bold transition-all shadow-sm ${
                      selectionMode 
                        ? 'bg-slate-900 text-white' 
                        : 'bg-white text-blue-600 border border-blue-200 hover:bg-blue-50'
                    }`}
                  >
                    {selectionMode ? t('admin:cancelar_seleccion') : t('admin:seleccion_multiple')}
                  </button>
                )}
                {selectionMode && selectedProducts.size > 0 && (
                  <button
                    onClick={deleteSelectedProducts}
                    className="flex items-center gap-2 bg-rose-600 text-white px-6 py-3 rounded-2xl font-bold hover:bg-rose-700 transition-all shadow-sm"
                  >
                    <Trash2 className="w-5 h-5" />
                    {t('admin:eliminar_size', { size: selectedProducts.size })}
                  </button>
                )}
              </div>

              {/* Selection info bar */}
              {selectionMode && (
                <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 flex items-center justify-between shadow-sm">
                  <span className="text-blue-800 font-semibold text-sm">
                    {t('admin:size_de_length_productos_seleccionados', { size: selectedProducts.size, length: products.length })}
                  </span>
                  <button
                    onClick={selectAllProducts}
                    className="text-blue-600 hover:text-blue-800 text-sm font-bold bg-white px-4 py-2 rounded-xl shadow-sm border border-blue-200"
                  >
                    {selectedProducts.size === products.length ? t('admin:deseleccionar_todo') : t('admin:seleccionar_todo')}
                  </button>
                </div>
              )}

              {/* Product Form */}
              {showProductForm && (
                <div className="bg-white rounded-3xl shadow-sm p-8 border border-slate-200/80">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center text-blue-600">
                      <Package className="w-6 h-6" />
                    </div>
                    <h3 className="text-xl font-bold text-slate-900 font-heading">
                      {editingProduct ? t('admin:editar_producto') : t('admin:nuevo_producto')}
                    </h3>
                  </div>

                  {formError && activeTab === 'products' && (
                    <div className="mb-6 p-4 bg-rose-50 border border-rose-200 text-rose-700 rounded-2xl flex items-start gap-3">
                      <X 
                        className="w-5 h-5 mt-0.5 cursor-pointer shrink-0" 
                        onClick={() => setFormError(null)} 
                      />
                      <span className="font-medium text-sm">{formError}</span>
                    </div>
                  )}

                  <form onSubmit={handleProductSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-1">
                      <label className="text-sm font-semibold text-slate-700 ml-1">{t('admin:nombre')}</label>
                      <input
                        type="text"
                        placeholder={t('admin:nombre_del_producto')}
                        value={productForm.name}
                        onChange={(e) => setProductForm({ ...productForm, name: e.target.value })}
                        className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-slate-900 outline-none"
                        required
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-sm font-semibold text-slate-700 ml-1">{t('admin:descripcion')}</label>
                      <input
                        type="text"
                        placeholder={t('admin:descripcion')}
                        value={productForm.description}
                        onChange={(e) => setProductForm({ ...productForm, description: e.target.value })}
                        className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-slate-900 outline-none"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-sm font-semibold text-slate-700 ml-1">{t('admin:categoria')}</label>
                      <div className="flex gap-2">
                        <select
                          value={productForm.category}
                          onChange={(e) => setProductForm({ ...productForm, category: e.target.value })}
                          className="flex-1 px-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-slate-900 outline-none appearance-none"
                        >
                          <option value="">{t('admin:sin_categoria')}</option>
                          {categories.map((cat) => (
                            <option key={cat.id} value={cat.id}>
                              {cat.name}
                            </option>
                          ))}
                        </select>
                        <button
                          type="button"
                          onClick={() => setShowNewCategoryModal(true)}
                          className="p-3 bg-blue-50 text-blue-600 rounded-xl hover:bg-blue-100 transition-colors border border-blue-100"
                          title={t('admin:nueva_categoria')}
                        >
                          <Plus className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                    <div className="space-y-1">
                      <label className="text-sm font-semibold text-slate-700 ml-1">{t('admin:variante_ej_regular')}</label>
                      <input
                        type="text"
                        placeholder={t('admin:nombre_variante')}
                        value={productForm.variantName}
                        onChange={(e) => setProductForm({ ...productForm, variantName: e.target.value })}
                        className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-slate-900 outline-none"
                        required
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-sm font-semibold text-slate-700 ml-1">SKU</label>
                      <input
                        type="text"
                        placeholder="SKU"
                        value={productForm.sku}
                        onChange={(e) => setProductForm({ ...productForm, sku: e.target.value })}
                        className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-slate-900 font-mono outline-none"
                        required
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-sm font-semibold text-slate-700 ml-1">{t('admin:precio')}</label>
                      <input
                        type="number"
                        placeholder={t('admin:precio')}
                        value={productForm.price}
                        onChange={(e) => setProductForm({ ...productForm, price: e.target.value })}
                        className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-slate-900 font-mono outline-none"
                        required
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-sm font-semibold text-slate-700 ml-1">{t('admin:costo')}</label>
                      <input
                        type="number"
                        placeholder={t('admin:costo')}
                        value={productForm.cost}
                        onChange={(e) => setProductForm({ ...productForm, cost: e.target.value })}
                        className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-slate-900 font-mono outline-none"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-sm font-semibold text-slate-700 ml-1">{t('admin:stock')}</label>
                      <input
                        type="number"
                        placeholder={t('admin:stock')}
                        value={productForm.stock}
                        onChange={(e) => setProductForm({ ...productForm, stock: e.target.value })}
                        className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-slate-900 font-mono outline-none"
                      />
                    </div>
                    <div className="space-y-1">
                      <label htmlFor="product-tax" className="text-sm font-semibold text-slate-700 ml-1">{t('admin:impuesto_incluido')}</label>
                      <select
                        id="product-tax"
                        value={productForm.tax}
                        onChange={(e) => setProductForm({ ...productForm, tax: e.target.value })}
                        className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-slate-900 outline-none"
                      >
                        <option value="">{t('admin:impuesto_del_negocio', { tax: businessTaxLabel })}</option>
                        <option value="INC:8">{t('admin:impoconsumo_8')}</option>
                        <option value="IVA:19">{t('admin:iva_19')}</option>
                        <option value="IVA:5">{t('admin:iva_5')}</option>
                        <option value="NONE">{t('admin:sin_impuesto_excluido')}</option>
                        {productForm.tax && !TAX_OPTIONS.includes(productForm.tax) && (
                          <option value={productForm.tax}>{productForm.tax.replace(':', ' ')} %</option>
                        )}
                      </select>
                    </div>
                    <div className="md:col-span-2 flex gap-3 pt-4 border-t border-slate-100">
                      <button 
                        type="submit" 
                        className="flex-1 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3.5 rounded-xl font-bold shadow-sm transition-all"
                      >
                        <Save className="w-5 h-5 inline mr-2" />
                        {t('admin:guardar_cambios')}
                      </button>
                      <button
                        type="button"
                        onClick={() => toggleProductForm(false)}
                        className="flex-1 bg-white text-slate-700 px-6 py-3.5 rounded-xl font-bold hover:bg-slate-50 transition-all border border-slate-300"
                      >
                        {t('admin:cancelar')}
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* Products List */}
              <div className="bg-white rounded-3xl shadow-sm overflow-hidden border border-slate-200/80">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-slate-900 text-slate-200 text-xs font-semibold uppercase tracking-wider">
                        {selectionMode && (
                          <th className="px-6 py-4 text-left w-16">
                            <button 
                              onClick={selectAllProducts}
                              className="w-6 h-6 border-2 border-slate-600 rounded-lg flex items-center justify-center hover:border-slate-400"
                            >
                              {selectedProducts.size === products.length && products.length > 0 && (
                                <Check className="w-4 h-4 text-blue-400" />
                              )}
                            </button>
                          </th>
                        )}
                        <th className="px-6 py-4 text-left">{t('admin:producto')}</th>
                        <th className="px-6 py-4 text-left">{t('admin:categoria')}</th>
                        <th className="px-6 py-4 text-left">SKU</th>
                        <th className="px-6 py-4 text-left">{t('admin:precio')}</th>
                        <th className="px-6 py-4 text-left">{t('admin:stock')}</th>
                        <th className="px-6 py-4 text-center w-28">{t('admin:acciones')}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-sm">
                      {products.map((product) => (
                        <tr 
                          key={product.id} 
                          className={`hover:bg-slate-50/80 transition-colors ${selectedProducts.has(product.id) ? 'bg-blue-50/40' : ''}`}
                        >
                          {selectionMode && (
                            <td className="px-6 py-4">
                              <button 
                                onClick={() => toggleProductSelection(product.id)}
                                className={`w-6 h-6 border-2 rounded-lg flex items-center justify-center transition-all ${
                                  selectedProducts.has(product.id) 
                                    ? 'bg-blue-600 border-blue-600' 
                                    : 'border-slate-300'
                                }`}
                              >
                                {selectedProducts.has(product.id) && <Check className="w-4 h-4 text-white" />}
                              </button>
                            </td>
                          )}
                          <td className="px-6 py-4">
                            <div className="font-bold text-slate-900">{product.name}</div>
                            <div className="text-xs text-slate-500 truncate max-w-xs">{product.description}</div>
                          </td>
                          <td className="px-6 py-4">
                            <span className="px-2.5 py-1 bg-slate-100 text-slate-700 text-xs font-semibold rounded-lg">
                              {product.category?.name || t('admin:varios')}
                            </span>
                          </td>
                          <td className="px-6 py-4 font-mono text-xs text-slate-600">{product.variants?.[0]?.sku || '-'}</td>
                          <td className="px-6 py-4 font-bold text-emerald-600 font-mono tabular-nums">${product.variants?.[0]?.price?.toFixed(2) || '0.00'}</td>
                          <td className="px-6 py-4 font-mono tabular-nums">
                            <span className={`font-bold ${product.variants?.[0]?.stock < 10 ? 'text-rose-500' : 'text-slate-700'}`}>
                              {product.variants?.[0]?.stock || 0}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex items-center justify-center gap-2">
                              <button
                                onClick={() => {
                                  setEditingProduct(product);
                                  setProductForm({
                                    name: product.name,
                                    description: product.description || '',
                                    category: product.categoryId || '',
                                    variantName: product.variants?.[0]?.name || '',
                                    sku: product.variants?.[0]?.sku || '',
                                    price: product.variants?.[0]?.price?.toString() || '',
                                    cost: product.variants?.[0]?.cost?.toString() || '',
                                    stock: product.variants?.[0]?.stock?.toString() || '0',
                                    tax: encodeTaxOption(product.taxType, product.taxRate)
                                  });
                                  toggleProductForm(true);
                                }}
                                className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                                title={t('admin:editar')}
                              >
                                <Edit2 className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => handleDeleteProduct(product.id)}
                                className="p-2 text-rose-500 hover:bg-rose-50 rounded-lg transition-colors"
                                title={t('admin:eliminar')}
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {products.length === 0 && (
                  <div className="p-12 text-center text-slate-400">
                    <Package className="w-16 h-16 mx-auto mb-4 opacity-20" />
                    <p className="text-base font-medium">{t('admin:no_hay_productos_en_catalogo_agrega_uno')}</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Salón y mesas: crear, numerar y acomodar en el mismo plano */}
          {activeTab === 'salon' && <TablesManager />}

          {/* Configuration Tab - Modular Subtabs */}
          {activeTab === 'config' && (
            <SystemConfigAdmin
              config={config}
              setConfig={setConfig}
              onFindDuplicates={handleFindDuplicates}
              isSearchingDuplicates={isSearchingDuplicates}
            />
          )}

          {activeTab === 'customers' && (plan.has('customers') ? <CustomersAdmin /> : <PlanLocked feature="customers" />)}
          {activeTab === 'suppliers' && <SuppliersModule />}
          {activeTab === 'coupons' && <CouponsAdmin />}
          {activeTab === 'page' && <PageModule />}
          {activeTab === 'inventory' && <InventoryModule />}
          {activeTab === 'users' && <UsersAdmin currentUser={user} />}
        </div>
      </div>

      {/* Import Modal Implementation */}
      {showImportModal && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center z-[100] p-4">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl overflow-hidden border border-slate-200">
            <div className="bg-slate-900 px-8 py-5 flex justify-between items-center text-white">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-600 rounded-xl text-white shadow-sm">
                  <Upload className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold font-heading">{t('admin:importar_productos')}</h3>
              </div>
              <button
                onClick={() => {
                  setShowImportModal(false);
                  setCsvFile(null);
                  setCsvContent('');
                  setImportResult(null);
                }}
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-8 space-y-6">
              <div className="bg-blue-50/60 border border-blue-200/80 p-5 rounded-2xl space-y-3">
                <h4 className="font-bold text-slate-900 flex items-center gap-2 text-sm">
                  <Info className="w-4 h-4 text-blue-600" />
                  {t('admin:instrucciones_del_formato')}
                </h4>
                <p className="text-xs text-slate-700 leading-relaxed">
                  {t('admin:el_archivo_debe_ser_un')}{' '}<strong>CSV</strong> con los siguientes encabezados (en cualquier orden):
                </p>
                <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs font-mono bg-white p-3 rounded-xl border border-blue-100">
                  <div className="text-slate-800">{t('admin:nombre_2')}{' '}<span className="text-xs text-rose-500 font-bold">{t('admin:req')}</span></div>
                  <div className="text-slate-800">{t('admin:sku')}{' '}<span className="text-xs text-rose-500 font-bold">{t('admin:req')}</span></div>
                  <div className="text-slate-800">{t('admin:precio_2')}{' '}<span className="text-xs text-rose-500 font-bold">{t('admin:req')}</span></div>
                  <div className="text-slate-500">{t('admin:variante')}</div>
                  <div className="text-slate-500">{t('admin:categoria_2')}</div>
                  <div className="text-slate-500">{t('admin:descripcion_2')}</div>
                  <div className="text-slate-500">{t('admin:costo_2')}</div>
                  <div className="text-slate-500">{t('admin:stock_2')}</div>
                </div>
                <div className="flex justify-between items-center pt-1">
                  <p className="text-xs text-slate-500 font-medium italic">
                    {t('admin:soporta_comas_punto_y_coma_y_decimales')}
                  </p>
                  <button 
                    onClick={handleDownloadTemplate}
                    className="text-blue-600 text-xs font-bold hover:underline flex items-center gap-1 bg-white px-2.5 py-1 rounded-lg border border-blue-200 shadow-sm"
                  >
                    <Download className="w-3 h-3" />
                    {t('admin:descargar_plantilla')}
                  </button>
                </div>
              </div>
              
              {/* File Upload Area */}
              <div 
                className={`
                  border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all duration-200
                  ${csvFile 
                    ? 'border-emerald-400 bg-emerald-50/50' 
                    : 'border-slate-300 bg-slate-50/50 hover:bg-blue-50/30 hover:border-blue-500'}
                `}
                onClick={() => fileInputRef.current?.click()}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".csv,.txt"
                  onChange={handleFileSelect}
                  className="hidden"
                />
                <div className={`w-14 h-14 mx-auto rounded-2xl flex items-center justify-center mb-3 ${csvFile ? 'bg-emerald-100 text-emerald-700' : 'bg-blue-50 text-blue-600'}`}>
                  <FileUp className="w-7 h-7" />
                </div>
                
                {csvFile ? (
                  <div>
                    <p className="text-base font-bold text-slate-900">{csvFile.name}</p>
                    <p className="text-xs text-emerald-600 font-bold mt-1">{t('admin:archivo_preparado_para_importar')}</p>
                  </div>
                ) : (
                  <div>
                    <p className="text-base font-bold text-slate-800">{t('admin:seleccionar_archivo_csv')}</p>
                    <p className="text-xs text-slate-500 font-medium mt-1">{t('admin:o_arrastra_y_suelta_el_archivo_aqui')}</p>
                  </div>
                )}
              </div>
              
              {!csvFile && (
                <div className="space-y-3">
                  <div className="flex items-center gap-4">
                    <div className="h-px flex-1 bg-slate-200"></div>
                    <span className="text-slate-400 font-bold text-xs uppercase tracking-wider">{t('admin:o_pegar_contenido')}</span>
                    <div className="h-px flex-1 bg-slate-200"></div>
                  </div>
                  <textarea
                    value={csvContent}
                    onChange={(e) => setCsvContent(e.target.value)}
                    placeholder="name,description,category,variantName,sku,price,cost,stock&#10;Hamburguesa,Deliciosa,Comidas,Normal,HAM001,10.00,5.00,100"
                    className="w-full h-28 px-4 py-3 bg-white border border-slate-200 rounded-xl font-mono text-xs focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none resize-none"
                  />
                </div>
              )}
              
              {importResult && (
                <div className={`p-4 rounded-xl flex items-start gap-4 ${importResult.success > 0 ? 'bg-emerald-50 border border-emerald-200' : 'bg-rose-50 border border-rose-200'}`}>
                  <div className={`p-1.5 rounded-lg ${importResult.success > 0 ? 'bg-emerald-600 text-white' : 'bg-rose-600 text-white'}`}>
                    <Check className="w-4 h-4" />
                  </div>
                  <div>
                    <p className={`font-bold text-sm ${importResult.success > 0 ? 'text-emerald-900' : 'text-rose-900'}`}>
                      {importResult.success > 0 ? t('admin:exito_success_productos_importados', { success: importResult.success }) : t('admin:hubo_un_problema_con_la_importacion')}
                    </p>
                    {importResult.errors?.map((err: string, i: number) => (
                      <p key={i} className="text-xs text-rose-600 font-semibold mt-1">• {err}</p>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex gap-4 pt-2">
                <button
                  onClick={handleCSVImport}
                  disabled={!csvContent && !csvFile}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white px-8 py-3.5 rounded-xl font-bold text-sm shadow-sm transition-all disabled:opacity-50"
                >
                  {t('admin:iniciar_importacion')}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* New Category Modal */}
      {showNewCategoryModal && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center z-[110] p-4">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden border border-slate-200">
            <div className="bg-slate-900 px-6 py-4 flex justify-between items-center text-white">
              <h3 className="text-base font-bold font-heading">{t('admin:nueva_categoria')}</h3>
              <button 
                onClick={() => {
                  setShowNewCategoryModal(false);
                  setFormError(null);
                }}
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleCreateCategory} className="p-6 space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 ml-1">{t('admin:nombre')}</label>
                <input
                  type="text"
                  placeholder={t('admin:ej_bebidas_comida_postres')}
                  value={newCategoryForm.name}
                  onChange={(e) => setNewCategoryForm({ ...newCategoryForm, name: e.target.value })}
                  className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-slate-900 outline-none text-sm"
                  required
                  autoFocus
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 ml-1">{t('admin:descripcion_opcional')}</label>
                <input
                  type="text"
                  placeholder={t('admin:breve_descripcion')}
                  value={newCategoryForm.description}
                  onChange={(e) => setNewCategoryForm({ ...newCategoryForm, description: e.target.value })}
                  className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-slate-900 outline-none text-sm"
                />
              </div>
              <div className="flex gap-3 pt-3">
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl font-bold shadow-sm transition-all flex items-center justify-center gap-2 text-sm"
                >
                  <Save className="w-4 h-4" />
                  {t('admin:crear_categoria')}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowNewCategoryModal(false);
                    setFormError(null);
                  }}
                  className="flex-1 bg-white text-slate-700 py-3 rounded-xl font-bold border border-slate-300 hover:bg-slate-50 transition-all text-sm"
                >
                  {t('admin:cancelar')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Duplicates Modal */}
      {showDuplicatesModal && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center z-[120] p-4">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden border border-slate-200 flex flex-col">
            <div className="bg-slate-900 px-8 py-5 flex justify-between items-center text-white shrink-0">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-rose-600 rounded-xl text-white shadow-sm">
                  <Trash2 className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold font-heading">{t('admin:gestion_de_duplicados_en_inventario')}</h3>
              </div>
              <button
                onClick={() => setShowDuplicatesModal(false)}
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-8 space-y-6">
              {cleanupResult && (
                <div className="p-5 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center gap-4">
                  <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center text-white shrink-0">
                    <Check className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="font-bold text-emerald-900 text-base">{t('admin:limpieza_completada')}</p>
                    <p className="text-emerald-700 text-xs font-medium">{t('admin:se_han_fusionado_eliminado_count_productos_repetid', { count: cleanupResult.count })}</p>
                  </div>
                </div>
              )}

              {duplicateGroups.length === 0 ? (
                <div className="text-center py-20 bg-slate-50 rounded-3xl border-2 border-dashed border-slate-200">
                  <Check className="w-16 h-16 text-emerald-500 mx-auto mb-3 opacity-60" />
                  <p className="text-xl font-bold text-slate-900">{t('admin:no_se_encontraron_duplicados')}</p>
                  <p className="text-slate-500 text-xs font-medium mt-1">{t('admin:el_catalogo_esta_limpio_y_optimizado')}</p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="bg-amber-50 border border-amber-200 p-4 rounded-2xl text-amber-900 font-medium text-xs flex items-start gap-3">
                    <Info className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                    <span>{t('admin:se_han_detectado_length_grupos_de_productos', { length: duplicateGroups.length })}</span>
                  </div>
                  
                  <div className="space-y-3">
                    {duplicateGroups.map((group) => (
                      <div key={group.key} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div>
                          <div className="flex items-center gap-2">
                             <h5 className="font-bold text-base text-slate-900">{group.name}</h5>
                             <span className="bg-slate-100 text-slate-700 text-xs px-2 py-0.5 rounded-lg font-bold uppercase">{group.categoryName}</span>
                          </div>
                          <p className="text-xs text-slate-500 font-medium mt-1">
                            {t('admin:count_versiones_encontradas', { count: group.count })}{' '}{group.items.reduce((acc: number, item: any) => acc + item.variantsCount, 0)}{' '}{t('admin:variantes_totales')}
                          </p>
                          <div className="flex gap-2 mt-3 overflow-x-auto pb-1">
                            {group.items.map((item: any, _idx: number) => (
                              <div key={item.id} className={`text-xs px-2.5 py-1 rounded-lg border shrink-0 font-mono ${item.isActive ? 'bg-emerald-50 border-emerald-200 text-emerald-700' : 'bg-slate-50 border-slate-200 text-slate-400'}`}>
                                {t('admin:id')}{item.id.slice(-6)} {item.isActive ? t('admin:activo') : t('admin:oculto')}
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="p-6 bg-slate-50 border-t border-slate-200 flex justify-between gap-4 shrink-0">
               <button
                onClick={() => setShowDuplicatesModal(false)}
                className="px-6 py-3 bg-white text-slate-700 rounded-xl font-bold hover:bg-slate-100 transition-all border border-slate-300 text-sm"
              >
                {t('admin:cerrar')}
              </button>
              {duplicateGroups.length > 0 && (
                <button
                  onClick={handleCleanupDuplicates}
                  disabled={isCleaningDuplicates}
                  className="flex-1 bg-rose-600 text-white px-6 py-3 rounded-xl font-bold text-sm shadow-sm hover:bg-rose-700 active:scale-95 transition-all disabled:opacity-50"
                >
                  {isCleaningDuplicates ? t('admin:procesando') : t('admin:fusionar_y_limpiar_length_grupos', { length: duplicateGroups.length })}
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
