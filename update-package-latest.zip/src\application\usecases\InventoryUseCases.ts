// ============================================
// APPLICATION USE CASES - Inventory Use Cases
// ============================================

import { prisma } from '../../infrastructure/database/prisma';

export class InventoryUseCases {

  /**
   * Get inventory status for all variants (optionally filtered by trackInventory)
   */
  async getInventoryStatus(onlyTracked: boolean = true) {
    const where: any = onlyTracked ? { trackInventory: true } : {};
    
    const variants = await prisma.productVariant.findMany({
      where: { ...where, isActive: true },
      include: {
        product: {
          include: { category: true }
        }
      },
      orderBy: { product: { name: 'asc' } }
    });

    return variants.map(v => ({
      variantId: v.id,
      productId: v.productId,
      productName: (v as any).product?.name || 'Producto',
      variantName: v.name,
      sku: v.sku,
      categoryName: (v as any).product?.category?.name || 'Sin Categoría',
      stock: v.stock,
      trackInventory: v.trackInventory,
      cost: v.cost,
      price: v.price,
      lowStock: v.trackInventory && v.stock <= 5,
      outOfStock: v.trackInventory && v.stock <= 0,
    }));
  }

  /**
   * Toggle inventory tracking ON/OFF for a variant
   */
  async toggleTrackInventory(variantId: string, enabled: boolean) {
    const variant = await prisma.productVariant.findUnique({ where: { id: variantId } });
    if (!variant) throw new Error('Variante no encontrada');

    return prisma.productVariant.update({
      where: { id: variantId },
      data: { trackInventory: enabled },
      include: { product: true }
    });
  }

  /**
   * Manual stock adjustment (+/-)
   */
  async adjustStock(variantId: string, quantity: number, type: 'MANUAL_ADD' | 'MANUAL_REMOVE', notes?: string) {
    const variant = await prisma.productVariant.findUnique({ where: { id: variantId } });
    if (!variant) throw new Error('Variante no encontrada');

    const previousStock = variant.stock;
    const delta = type === 'MANUAL_ADD' ? Math.abs(quantity) : -Math.abs(quantity);
    const newStock = Math.max(0, previousStock + delta);

    return prisma.$transaction(async (tx) => {
      // Update stock
      await tx.productVariant.update({
        where: { id: variantId },
        data: { stock: newStock }
      });

      // Record movement
      await tx.stockMovement.create({
        data: {
          productVariantId: variantId,
          type,
          quantity: delta,
          previousStock,
          newStock,
          notes
        }
      });

      return { variantId, previousStock, newStock, delta };
    });
  }

  /**
   * Submit a physical inventory count
   * If difference != 0 and no justification, rejects
   * Otherwise updates stock and records the count
   */
  async submitInventoryCount(variantId: string, countedStock: number, justification?: string, userId?: string) {
    const variant = await prisma.productVariant.findUnique({ where: { id: variantId } });
    if (!variant) throw new Error('Variante no encontrada');

    const previousStock = variant.stock;
    const difference = countedStock - previousStock;

    // If there's a difference, justification is required
    if (difference !== 0 && (!justification || !justification.trim())) {
      throw new Error(`Hay una diferencia de ${difference > 0 ? '+' : ''}${difference} unidades. Debe proporcionar un motivo para justificar la diferencia.`);
    }

    return prisma.$transaction(async (tx) => {
      // Create inventory count record
      const count = await tx.inventoryCount.create({
        data: {
          productVariantId: variantId,
          previousStock,
          countedStock,
          difference,
          justification: difference !== 0 ? justification : null,
          createdBy: userId
        }
      });

      // Update stock to counted value
      await tx.productVariant.update({
        where: { id: variantId },
        data: { stock: countedStock }
      });

      // Record stock movement
      await tx.stockMovement.create({
        data: {
          productVariantId: variantId,
          type: 'COUNT',
          quantity: difference,
          previousStock,
          newStock: countedStock,
          reference: count.id,
          notes: justification || 'Conteo sin diferencia'
        }
      });

      return {
        variantId,
        previousStock,
        countedStock,
        difference,
        justification,
        appliedAt: count.appliedAt
      };
    });
  }

  /**
   * Get stock movements for a variant
   */
  async getStockMovements(variantId: string, limit: number = 50) {
    return prisma.stockMovement.findMany({
      where: { productVariantId: variantId },
      orderBy: { createdAt: 'desc' },
      take: limit
    });
  }

  /**
   * Get inventory count history for a variant
   */
  async getInventoryCountHistory(variantId: string, limit: number = 20) {
    return prisma.inventoryCount.findMany({
      where: { productVariantId: variantId },
      orderBy: { appliedAt: 'desc' },
      take: limit
    });
  }

  /**
   * Deduct stock when a sale is made (called from SaleUseCases)
   */
  async deductStockForSale(variantId: string, quantity: number, saleId: string) {
    const variant = await prisma.productVariant.findUnique({ where: { id: variantId } });
    if (!variant || !variant.trackInventory) return null;

    const previousStock = variant.stock;
    const newStock = Math.max(0, previousStock - quantity);

    return prisma.$transaction(async (tx) => {
      await tx.productVariant.update({
        where: { id: variantId },
        data: { stock: newStock }
      });

      await tx.stockMovement.create({
        data: {
          productVariantId: variantId,
          type: 'SALE',
          quantity: -quantity,
          previousStock,
          newStock,
          reference: saleId,
          notes: `Venta ${saleId.substring(0, 8)}`
        }
      });

      return { variantId, previousStock, newStock };
    });
  }
}
