// ============================================
// APPLICATION - Auth Use Cases
// ============================================

import { UserRepository } from '../../infrastructure/persistence/repositories/UserRepository';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { signToken } from '../../shared/authMiddleware';
import { getJwtSecret } from '../../shared/security/secrets';
import { issueAdminOverride } from '../../shared/security/adminOverride';
import { cloudConfig } from '../../shared/cloud/config';
import type { CloudAuthService } from './CloudAuthService';

const VALID_ROLES = ['ADMIN', 'CASHIER', 'WAITER'];
const MIN_PASSWORD_LENGTH = 8;
// Hash de relleno: el login compara siempre contra un hash para no revelar por tiempo si el usuario existe
const DUMMY_HASH = bcrypt.hashSync('lantify-timing-guard', 10);

// Credenciales que venían precargadas en versiones anteriores.
// Si una instalación todavía las usa, se obliga a cambiarlas.
const LEGACY_DEFAULT_CREDENTIALS: Record<string, string> = {
  admin: 'admin123',
  cajero: 'cajero123',
  mesero: 'mesero123',
};

export class AuthError extends Error {
  constructor(public statusCode: number, public code: string, message: string, public details?: Record<string, unknown>) {
    super(message);
    this.name = 'AuthError';
  }
}

export const publicUser = (user: { id: string; username: string; name: string; role: string; mustChangePassword?: boolean }) => ({
  id: user.id,
  username: user.username,
  name: user.name,
  role: user.role,
  mustChangePassword: !!user.mustChangePassword,
});

const assertPassword = (password: string | undefined, username?: string) => {
  if (!password || password.length < MIN_PASSWORD_LENGTH) {
    throw new AuthError(400, 'AUTH_WEAK_PASSWORD', `La contraseña debe tener al menos ${MIN_PASSWORD_LENGTH} caracteres.`);
  }
  if (username && password.toLowerCase().includes(username.toLowerCase())) {
    throw new AuthError(400, 'AUTH_WEAK_PASSWORD', 'La contraseña no puede contener el nombre de usuario.');
  }
  if (Object.values(LEGACY_DEFAULT_CREDENTIALS).includes(password)) {
    throw new AuthError(400, 'AUTH_WEAK_PASSWORD', 'Esa contraseña es pública. Elige otra.');
  }
};

const assertRole = (role: string) => {
  if (!VALID_ROLES.includes(role)) {
    throw new AuthError(400, 'AUTH_INVALID_ROLE', 'Rol de usuario no válido.');
  }
};

export class AuthUseCases {
  constructor(private userRepository: UserRepository, private cloud?: CloudAuthService) {}

  /** Instalación vinculada a un negocio de Lantify Cloud: identidades y licencia vienen de la nube */
  private async isLinked() {
    return !!(this.cloud && (await this.cloud.linkedTenant()));
  }

  private activationRequired(): never {
    throw new AuthError(403, 'CLOUD_ACTIVATION_REQUIRED', 'Vincula este equipo con tu negocio en Lantify Cloud.');
  }

  async login(username: string, password: string) {
    if (!username || !password) {
      throw new AuthError(401, 'AUTH_INVALID_CREDENTIALS', 'Usuario o contraseña incorrectos');
    }
    if (await this.isLinked()) return this.cloud!.login(username, password);
    if (cloudConfig().licenseRequired) this.activationRequired();

    const user = (await this.userRepository.findByUsername(username.trim()))
      ?? (await this.userRepository.findByUsername(username.trim().toLowerCase()));
    const isValidPassword = await bcrypt.compare(password, user?.password || DUMMY_HASH);

    if (!user || !user.isActive || !isValidPassword) {
      throw new AuthError(401, 'AUTH_INVALID_CREDENTIALS', 'Usuario o contraseña incorrectos');
    }

    await this.userRepository.update(user.id, { lastLoginAt: new Date() } as any);

    const token = signToken({ userId: user.id, username: user.username, role: user.role, tv: user.tokenVersion });
    return { token, user: publicUser(user) };
  }

  // ── Primer arranque: crear la cuenta administradora ─────────
  async getSetupStatus() {
    const cloud = this.cloud ? await this.cloud.status() : { licenseRequired: false, linked: false, tenant: null, aiAvailable: false };
    const count = await this.userRepository.countAll();
    return {
      // Con licencia obligatoria o negocio vinculado, el administrador se crea en la nube
      needsSetup: count === 0 && !cloud.linked && !cloud.licenseRequired,
      needsActivation: cloud.licenseRequired && !cloud.linked,
      linked: cloud.linked,
      tenant: cloud.tenant,
    };
  }

  async setupFirstAdmin(data: { name: string; username: string; password: string }) {
    if (cloudConfig().licenseRequired || (await this.isLinked())) this.activationRequired();
    const count = await this.userRepository.countAll();
    if (count > 0) {
      throw new AuthError(409, 'AUTH_SETUP_DONE', 'El sistema ya tiene usuarios configurados.');
    }
    const username = (data.username || '').trim().toLowerCase();
    if (!/^[a-z0-9._-]{3,32}$/.test(username)) {
      throw new AuthError(400, 'AUTH_INVALID_USERNAME', 'El usuario debe tener entre 3 y 32 caracteres (letras, números, punto o guion).');
    }
    if (!data.name?.trim()) {
      throw new AuthError(400, 'AUTH_NAME_REQUIRED', 'El nombre es obligatorio.');
    }
    assertPassword(data.password, username);

    const user = await this.userRepository.create({
      username,
      password: await bcrypt.hash(data.password, 10),
      name: data.name.trim(),
      role: 'ADMIN',
    });
    return this.login(user.username, data.password);
  }

  /**
   * Valida y prepara un usuario nuevo sin guardarlo (la configuración inicial
   * crea varios dentro de una sola transacción).
   */
  async prepareNewUser(username: string, password: string, name: string, role: string) {
    const normalized = (username || '').trim().toLowerCase();
    if (!/^[a-z0-9._-]{3,32}$/.test(normalized)) {
      throw new AuthError(400, 'AUTH_INVALID_USERNAME', 'El usuario debe tener entre 3 y 32 caracteres (letras, números, punto o guion).');
    }
    if (!name?.trim()) {
      throw new AuthError(400, 'AUTH_NAME_REQUIRED', 'El nombre es obligatorio.');
    }
    assertRole(role);
    assertPassword(password, normalized);
    if (await this.userRepository.findByUsername(normalized)) {
      throw new AuthError(409, 'AUTH_USER_EXISTS', 'El usuario ya existe');
    }
    return { username: normalized, password: await bcrypt.hash(password, 10), name: name.trim(), role };
  }

  async register(username: string, password: string, name: string, role: string = 'CASHIER', actorId?: string) {
    if (await this.isLinked()) return this.cloud!.createUser(actorId, { username: (username || '').trim().toLowerCase(), password, name, role });
    const normalized = (username || '').trim().toLowerCase();
    if (!/^[a-z0-9._-]{3,32}$/.test(normalized)) {
      throw new AuthError(400, 'AUTH_INVALID_USERNAME', 'El usuario debe tener entre 3 y 32 caracteres (letras, números, punto o guion).');
    }
    if (!name?.trim()) {
      throw new AuthError(400, 'AUTH_NAME_REQUIRED', 'El nombre es obligatorio.');
    }
    assertRole(role);
    assertPassword(password, normalized);

    const existingUser = await this.userRepository.findByUsername(normalized);
    if (existingUser) {
      throw new AuthError(409, 'AUTH_USER_EXISTS', 'El usuario ya existe');
    }

    const user = await this.userRepository.create({
      username: normalized,
      password: await bcrypt.hash(password, 10),
      name: name.trim(),
      role,
    });
    return publicUser(user);
  }

  async getAllUsers(actorId?: string) {
    if (await this.isLinked()) return this.cloud!.listUsers(actorId);
    return this.userRepository.getAll();
  }

  async updateUser(id: string, data: { name?: string; role?: string; password?: string }, actorId?: string) {
    if (await this.isLinked()) {
      return this.cloud!.updateUser(actorId, id, { ...data, password: data.password?.trim() ? data.password : undefined });
    }
    const user = await this.userRepository.findById(id);
    if (!user) throw new AuthError(404, 'AUTH_USER_NOT_FOUND', 'Usuario no encontrado');

    const updatePayload: any = {};
    let revokeSessions = false;

    if (data.name) updatePayload.name = data.name.trim();
    if (data.role && data.role !== user.role) {
      assertRole(data.role);
      if (user.role === 'ADMIN') await this.assertNotLastAdmin(user.id);
      updatePayload.role = data.role;
      revokeSessions = true;
    }
    if (data.password && data.password.trim() !== '') {
      assertPassword(data.password, user.username);
      updatePayload.password = await bcrypt.hash(data.password, 10);
      // Si un admin resetea la clave de otro usuario, ese usuario debe elegir una propia
      updatePayload.mustChangePassword = actorId !== undefined && actorId !== user.id;
      revokeSessions = true;
    }
    if (revokeSessions) updatePayload.tokenVersion = user.tokenVersion + 1;

    const updated = await this.userRepository.update(id, updatePayload);
    return publicUser(updated);
  }

  async changeOwnPassword(userId: string, currentPassword: string, newPassword: string) {
    if (await this.isLinked()) {
      if (currentPassword === newPassword) throw new AuthError(400, 'AUTH_WEAK_PASSWORD', 'La nueva contraseña debe ser distinta de la actual.');
      return this.cloud!.changeOwnPassword(userId, currentPassword, newPassword);
    }
    const user = await this.userRepository.findById(userId);
    if (!user || !user.isActive) throw new AuthError(404, 'AUTH_USER_NOT_FOUND', 'Usuario no encontrado');

    const ok = await bcrypt.compare(currentPassword || '', user.password);
    if (!ok) throw new AuthError(401, 'AUTH_INVALID_CREDENTIALS', 'La contraseña actual no es correcta.');
    if (currentPassword === newPassword) {
      throw new AuthError(400, 'AUTH_WEAK_PASSWORD', 'La nueva contraseña debe ser distinta de la actual.');
    }
    assertPassword(newPassword, user.username);

    const updated = await this.userRepository.update(user.id, {
      password: await bcrypt.hash(newPassword, 10),
      mustChangePassword: false,
      tokenVersion: user.tokenVersion + 1,
    } as any);

    // Se entrega un token nuevo: los anteriores quedan invalidados
    const token = signToken({ userId: updated.id, username: updated.username, role: updated.role, tv: updated.tokenVersion });
    return { token, user: publicUser(updated) };
  }

  async deleteUser(id: string, actorId?: string) {
    const user = await this.userRepository.findById(id);
    if (!user) throw new AuthError(404, 'AUTH_USER_NOT_FOUND', 'Usuario no encontrado');
    if (actorId && actorId === id) {
      throw new AuthError(400, 'AUTH_CANNOT_DELETE_SELF', 'No puedes desactivar tu propio usuario.');
    }
    if (await this.isLinked()) {
      await this.cloud!.updateUser(actorId, id, { isActive: false });
      return { success: true };
    }
    if (user.role === 'ADMIN') await this.assertNotLastAdmin(user.id);
    await this.userRepository.update(id, { isActive: false, tokenVersion: user.tokenVersion + 1 } as any);
    return { success: true };
  }

  private async assertNotLastAdmin(adminId: string) {
    const admins = (await this.userRepository.getAll()).filter(u => u.role === 'ADMIN' && u.isActive);
    if (admins.length <= 1 && admins[0]?.id === adminId) {
      throw new AuthError(400, 'AUTH_LAST_ADMIN', 'Debe existir al menos un administrador activo.');
    }
  }

  /**
   * Se ejecuta al arrancar. Ya NO crea usuarios por defecto: el primer administrador
   * se crea desde la pantalla de configuración inicial. Las cuentas antiguas que
   * todavía usan las claves de fábrica quedan obligadas a cambiarlas.
   */
  async enforceNoDefaultCredentials() {
    for (const [username, legacyPassword] of Object.entries(LEGACY_DEFAULT_CREDENTIALS)) {
      const user = await this.userRepository.findByUsername(username);
      if (user && user.isActive && !user.mustChangePassword && (await bcrypt.compare(legacyPassword, user.password))) {
        await this.userRepository.update(user.id, { mustChangePassword: true } as any);
        console.warn(`⚠️  El usuario "${username}" usa la clave de fábrica: deberá cambiarla al ingresar.`);
      }
    }
    const { needsSetup } = await this.getSetupStatus();
    if (needsSetup) {
      console.log('ℹ️  No hay usuarios: el sistema mostrará la configuración inicial para crear el administrador.');
    }
  }

  async verifyAdminPassword(password: string) {
    if (!password || password.trim() === '') {
      throw new AuthError(400, 'AUTH_ADMIN_PASSWORD_REQUIRED', 'La clave de administrador es requerida');
    }

    const allUsers = await this.userRepository.getAll();
    // Vinculado a la nube, solo cuentan los administradores que existen en la nube
    const linked = await this.isLinked();
    const activeAdmins = allUsers.filter(u => u.role === 'ADMIN' && u.isActive && (!linked || (u as any).cloudUserId));

    for (const admin of activeAdmins) {
      const isMatch = await bcrypt.compare(password, admin.password);
      if (isMatch) {
        return {
          valid: true,
          adminId: admin.id,
          adminName: admin.name,
          username: admin.username,
          // Autorización de un solo uso práctico (2 minutos) que el servidor exige
          overrideToken: issueAdminOverride({ adminId: admin.id, adminName: admin.name }),
        };
      }
    }

    throw new AuthError(401, 'AUTH_ADMIN_PASSWORD_INVALID', 'Clave de administrador incorrecta');
  }

  verifyToken(token: string) {
    return jwt.verify(token, getJwtSecret());
  }
}
