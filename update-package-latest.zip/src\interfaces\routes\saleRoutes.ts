// ============================================
// INTERFACES - Sale Routes (Role Protected)
// ============================================

import { Router } from 'express';
import { SaleController } from '../controllers';
import { authMiddleware, requireRole, adminOnly, cashierOrAdmin, optionalAuth } from '../../shared/authMiddleware';
import { AuditLogger } from '../../infrastructure/services/AuditLogger';

export const createSaleRoutes = (controller: SaleController) => {
  const router = Router();

  // Crear venta (requiere autenticación de mesero, cajero o admin)
  router.post('/', optionalAuth, controller.createSale.bind(controller));
  
  // Consultas de ventas (cajero o admin para ver ventas e historial)
  router.get('/', optionalAuth, controller.getAllSales.bind(controller));
  router.get('/summary', optionalAuth, controller.getDailySummary.bind(controller));
  router.get('/date-range', optionalAuth, controller.getSalesByDateRange.bind(controller));

  // ── Rutas paginadas por mes (colocadas antes de /:id para evitar conflictos) ──
  router.get('/available-months', optionalAuth, controller.getAvailableMonths.bind(controller));
  router.get('/by-month', optionalAuth, controller.getSalesByMonth.bind(controller));

  // Bitácora de auditoría (solo Administradores)
  router.get('/audit/logs', authMiddleware, adminOnly, async (_req, res) => {
    try {
      const logs = await AuditLogger.getRecentLogs(100);
      res.json(logs);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Error cargando auditoría' });
    }
  });

  // Corregir la propina (ADMIN). No cambia el valor de la venta; queda quién, cuándo y por qué
  router.patch('/:id/tip', authMiddleware, adminOnly, controller.adjustTip.bind(controller));
  // Asignar o cambiar el cliente (cliente sin registrar al cobrar, o "Cliente común" por error)
  router.patch('/:id/customer', authMiddleware, cashierOrAdmin, controller.changeCustomer.bind(controller));

  router.get('/table/:tableId', optionalAuth, controller.getSalesByTable.bind(controller));
  router.get('/:id', optionalAuth, controller.getSaleById.bind(controller));
  router.get('/:id/payments', optionalAuth, controller.getSalePayments.bind(controller));
  router.get('/:id/paid-total', optionalAuth, controller.getSalePaidTotal.bind(controller));
  router.put('/:id', authMiddleware, cashierOrAdmin, controller.updateSale.bind(controller));
  router.patch('/:id/complete', authMiddleware, cashierOrAdmin, controller.completeSale.bind(controller));
  
  // Cancelación de venta (Cajero o Admin)
  router.patch('/:id/cancel', authMiddleware, cashierOrAdmin, controller.cancelSale.bind(controller));
  
  // Anulación de items (Cajero o Admin)
  router.patch('/items/:itemId/cancel', authMiddleware, cashierOrAdmin, controller.cancelSaleItem.bind(controller));
  
  // Pagos y abonos (Cajero o Admin)
  router.post('/payments', authMiddleware, cashierOrAdmin, controller.addPayment.bind(controller));
  
  // Eliminación destructiva (EXCLUSIVO Administrador)
  router.delete('/:id', authMiddleware, adminOnly, controller.deleteSale.bind(controller));

  return router;
};