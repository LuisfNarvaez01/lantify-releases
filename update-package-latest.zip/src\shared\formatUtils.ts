/**
 * Utilities for formatting values in the POS system.
 */

/**
 * Formats a number as currency using the Colombian locale (es-CO).
 * This ensures dots are used as thousands separators.
 * @param value The numeric value to format
 * @param includeSymbol Whether to include the $ symbol (default: true)
 * @returns Formatted string
 */
export const formatCurrency = (value: number | undefined | null, includeSymbol: boolean = true): string => {
  if (value === undefined || value === null) return includeSymbol ? '$0' : '0';
  
  const formatter = new Intl.NumberFormat('es-CO', {
    style: includeSymbol ? 'currency' : 'decimal',
    currency: 'COP',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  });

  return formatter.format(value);
};

/**
 * Formats a number with dots as thousands separators.
 * @param value The numeric value to format
 * @returns Formatted string
 */
export const formatNumber = (value: number | undefined | null): string => {
  if (value === undefined || value === null) return '0';
  
  return new Intl.NumberFormat('es-CO', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(value);
};
