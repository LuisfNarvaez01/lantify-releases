// ============================================
// SCRIPT - Cuentas de prueba (solo desarrollo)
// ============================================
// Crea o restablece admin.prueba / cajero.prueba / mesero.prueba con claves
// aleatorias nuevas y las guarda en docs/private/CUENTAS_PRUEBA.md
// (carpeta excluida de Git). Nunca usar en un equipo de un cliente.
//
// Uso:  npm run accounts:test

import 'dotenv/config';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import { PrismaClient } from '@prisma/client';

if (process.env.NODE_ENV === 'production') {
  console.error('❌ Este script no se ejecuta en producción.');
  process.exit(1);
}

const ACCOUNTS = [
  { username: 'admin.prueba', name: 'Admin de Prueba', role: 'ADMIN' },
  { username: 'cajero.prueba', name: 'Cajero de Prueba', role: 'CASHIER' },
  { username: 'mesero.prueba', name: 'Mesero de Prueba', role: 'WAITER' },
] as const;

// Clave legible de 12 caracteres sin caracteres ambiguos (0/O, 1/l)
const generatePassword = () => {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
  const bytes = crypto.randomBytes(12);
  const chars = Array.from(bytes, b => alphabet[b % alphabet.length]).join('');
  return `${chars.slice(0, 4)}-${chars.slice(4, 8)}-${chars.slice(8, 12)}`;
};

const main = async () => {
  const prisma = new PrismaClient();
  const rows: string[] = [];

  for (const acc of ACCOUNTS) {
    const password = generatePassword();
    const hash = await bcrypt.hash(password, 10);
    const existing = await prisma.user.findUnique({ where: { username: acc.username } });
    if (existing) {
      await prisma.user.update({
        where: { id: existing.id },
        data: { password: hash, role: acc.role, isActive: true, mustChangePassword: false, tokenVersion: existing.tokenVersion + 1 },
      });
    } else {
      await prisma.user.create({ data: { username: acc.username, name: acc.name, role: acc.role, password: hash } });
    }
    rows.push(`| ${acc.role} | \`${acc.username}\` | \`${password}\` |`);
  }
  await prisma.$disconnect();

  const dir = path.resolve(__dirname, '..', 'docs', 'private');
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, 'CUENTAS_PRUEBA.md');
  fs.writeFileSync(file, `# Cuentas de prueba — Lantify POS (PRIVADO)

> Documento personal. Está en \`docs/private/\`, que Git ignora: **no se sube al repositorio**.
> Estas cuentas son solo para desarrollo y demostraciones. **No crearlas en equipos de clientes.**
> Generado: ${new Date().toLocaleString('es-CO')} · Base de datos: \`${process.env.DATABASE_URL}\`

| Rol | Usuario | Contraseña |
|---|---|---|
${rows.join('\n')}

Para regenerar las claves (las anteriores dejan de funcionar): \`npm run accounts:test\`
`, 'utf-8');

  console.log(`✅ Cuentas de prueba listas. Credenciales guardadas en ${file}`);
};

main().catch(err => {
  console.error(err);
  process.exit(1);
});
