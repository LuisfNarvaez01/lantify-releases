import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    // El diseño de Mi página usa el mismo dominio que el servidor (src/domain/pageTheme.ts)
    fs: { allow: ['..'] },
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://localhost:5000',
        changeOrigin: true,
      },
    },
  },
});