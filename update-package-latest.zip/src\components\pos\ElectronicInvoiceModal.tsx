import React, { useState, useEffect } from 'react';
import { 
  CheckCircle2, 
  Printer, 
  Mail, 
  Download, 
  Copy, 
  Check, 
  X, 
  ShieldCheck, 
  Sparkles, 
  Building2, 
  UserCheck,
  Send
} from 'lucide-react';
import { dianAPI } from '../../services/api';
import { toast } from '../../shared/toast';
import { errorMessage } from '../../services/apiErrors';
import { useBusinessStore, groupSaleTaxes } from '../../shared/business';

import i18next, { t } from '../../i18n';
interface ElectronicInvoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  sale: any;
  /** Al cobrar con factura electrónica: imprimirla en cuanto se emita */
  autoPrint?: boolean;
}

// El contenido va aparte para que sus hooks no dependan de si el modal está abierto
export const ElectronicInvoiceModal: React.FC<ElectronicInvoiceModalProps> = ({ isOpen, onClose, sale, autoPrint }) =>
  isOpen && sale ? <ElectronicInvoiceContent onClose={onClose} sale={sale} autoPrint={autoPrint} /> : null;

// La factura es un documento legal ante la DIAN: se imprime siempre en español
const legalT = (key: string) => i18next.getFixedT('es', 'dian')(key);
const taxName = (l: { taxType: string; taxRate: number }) => `${l.taxType === 'IVA' ? 'IVA' : legalT('impoconsumo')} ${l.taxRate}%`;
const esc = (v: string) => String(v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

const ElectronicInvoiceContent: React.FC<{ onClose: () => void; sale: any; autoPrint?: boolean }> = ({ onClose, sale, autoPrint }) => {
  const business = useBusinessStore((s) => s.settings);
  const [resolution, setResolution] = useState<any>(null);
  useEffect(() => {
    dianAPI.getResolution().then((r) => setResolution(r?.resolution || null)).catch(() => setResolution(null));
  }, []);

  // Emisor = el negocio configurado (no un dato de ejemplo)
  const issuerName = business?.legalName || business?.businessName || '';
  const issuerNit = business?.nit ? (business.dv ? `${business.nit}-${business.dv}` : business.nit) : '';
  const issuerAddress = [business?.address, business?.city].filter(Boolean).join(', ');
  const issuerPhone = business?.phone || '';

  const saleNumber = sale.saleNumber || (sale.id ? sale.id.slice(0, 5) : '001');

  // Customer form state
  const [docType, setDocType] = useState('CC');
  const [docNumber, setDocNumber] = useState(sale.customer?.nit || '222222222222');
  const [clientName, setClientName] = useState(sale.customer?.name || sale.customerName || t('dian:consumidor_final'));
  const [clientEmail, setClientEmail] = useState(sale.customer?.email || '');
  const [clientPhone, setClientPhone] = useState(sale.customer?.phone || sale.customerPhone || '');
  const [clientAddress, setClientAddress] = useState(sale.customer?.address || sale.customerAddress || '');
  
  const [emailSent, setEmailSent] = useState(false);
  const [copiedCufe, setCopiedCufe] = useState(false);
  const [activeView, setActiveView] = useState<'preview' | 'tirilla'>('preview');

  // DIAN Backend integration state
  const [dianInvoice, setDianInvoice] = useState<any>(null);
  const [isEmitting, setIsEmitting] = useState(false);
  // Se imprime después de que el estado tenga el número y CUFE definitivos
  const [printPending, setPrintPending] = useState(false);

  useEffect(() => {
    if (sale?.id) {
      dianAPI.getSaleInvoice(sale.id).then(res => {
        if (res?.invoice) {
          setDianInvoice(res.invoice);
        }
      }).catch(console.warn);
    }
  }, [sale?.id]);

  const handleEmitToDian = async () => {
    setIsEmitting(true);
    try {
      const res = await dianAPI.emitInvoice(sale.id, {
        nit: docNumber,
        name: clientName,
        email: clientEmail,
        phone: clientPhone,
        address: clientAddress,
        documentType: docType
      });
      if (res?.invoice) {
        setDianInvoice(res.invoice);
        toast.success(res.message || t('dian:factura_generada_y_encolada_en_dian'), t('dian:facturacion_electronica'));
        if (autoPrint) setPrintPending(true);
      }
    } catch (err: any) {
      toast.error(errorMessage(err), t('dian:facturacion_electronica'));
    } finally {
      setIsEmitting(false);
    }
  };

  const invoiceNumber = dianInvoice?.invoiceNumber || `SETP-${String(saleNumber).padStart(6, '0')}`;
  const cufe = dianInvoice?.cufe || (
    Array.from(`${invoiceNumber}${sale.total}${docNumber}${issuerNit}${sale.createdAt || new Date().toISOString()}`)
      .reduce((acc, char, idx) => acc + ((char.charCodeAt(0) * (idx + 13) * 7) % 16).toString(16), '')
      .padEnd(96, 'e4b89f2a017d8c36')
      .slice(0, 96)
  );

  // El total ya incluye el impuesto; la base gravable es el total menos el impuesto
  const total = sale.total || 0;
  const taxTotal = Number(sale.tax) || 0;
  const subtotal = total - taxTotal;
  const taxLines = groupSaleTaxes(sale.taxItems || sale.items);
  const resolutionText = resolution ? `${resolution.resolutionNumber} de ${resolution.resolutionDate}` : '';
  const rangeText = resolution ? `${resolution.prefix}-${resolution.rangeFrom} a ${resolution.prefix}-${resolution.rangeTo}` : '';
  const isAccepted = dianInvoice?.status === 'ACCEPTED';

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('es-CO', {
      style: 'currency',
      currency: 'COP',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(val);
  };

  const handleCopyCufe = () => {
    navigator.clipboard.writeText(cufe);
    setCopiedCufe(true);
    setTimeout(() => setCopiedCufe(false), 2500);
  };

  const handleSendEmail = () => {
    setEmailSent(true);
    setTimeout(() => setEmailSent(false), 4000);
  };

  const handleDownloadXML = () => {
    const xmlContent = `<?xml version="1.0" encoding="UTF-8"?>
<Invoice xmlns="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2"
  xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2"
  xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2">
  <cbc:UBLVersionID>UBL 2.1</cbc:UBLVersionID>
  <cbc:CustomizationID>DIAN 2.1: Factura Electrónica de Venta</cbc:CustomizationID>
  <cbc:ID>${invoiceNumber}</cbc:ID>
  <cbc:UUID schemeName="CUFE-SHA384">${cufe}</cbc:UUID>
  <cbc:IssueDate>${new Date().toISOString().split('T')[0]}</cbc:IssueDate>
  <cbc:IssueTime>${new Date().toTimeString().split(' ')[0]}</cbc:IssueTime>
  <cbc:InvoiceTypeCode>01</cbc:InvoiceTypeCode>
  <cac:AccountingSupplierParty>
    <cac:Party>
      <cac:PartyTaxScheme>
        <cbc:RegistrationName>${esc(issuerName)}</cbc:RegistrationName>
        <cbc:CompanyID schemeID="1">${esc(issuerNit.replace('-', ''))}</cbc:CompanyID>
      </cac:PartyTaxScheme>
    </cac:Party>
  </cac:AccountingSupplierParty>
  <cac:AccountingCustomerParty>
    <cac:Party>
      <cac:PartyTaxScheme>
        <cbc:RegistrationName>${esc(clientName)}</cbc:RegistrationName>
        <cbc:CompanyID schemeID="1">${esc(docNumber)}</cbc:CompanyID>
      </cac:PartyTaxScheme>
      <cac:Contact>
        <cbc:ElectronicMail>${esc(clientEmail)}</cbc:ElectronicMail>
      </cac:Contact>
    </cac:Party>
  </cac:AccountingCustomerParty>
  <cac:LegalMonetaryTotal>
    <cbc:LineExtensionAmount currencyID="COP">${subtotal}</cbc:LineExtensionAmount>
    <cbc:TaxExclusiveAmount currencyID="COP">${subtotal}</cbc:TaxExclusiveAmount>
    <cbc:TaxInclusiveAmount currencyID="COP">${total}</cbc:TaxInclusiveAmount>
    <cbc:PayableAmount currencyID="COP">${total}</cbc:PayableAmount>
  </cac:LegalMonetaryTotal>
</Invoice>`;

    const blob = new Blob([xmlContent], { type: 'application/xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${invoiceNumber}.xml`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>${invoiceNumber} - Factura Electrónica DIAN</title>
        <style>
          @page { size: 80mm auto; margin: 3mm; }
          body { font-family: 'Courier New', monospace; font-size: 11px; margin: 0; color: #000; padding: 6px; }
          .text-center { text-align: center; }
          .text-right { text-align: right; }
          .font-bold { font-weight: bold; }
          .divider { border-top: 1px dashed #000; margin: 6px 0; }
          .qr-box { margin: 8px auto; text-align: center; }
          .cufe-text { font-size: 8px; word-break: break-all; margin: 4px 0; }
          table { width: 100%; border-collapse: collapse; font-size: 10px; }
          th, td { padding: 2px 0; }
        </style>
      </head>
      <body>
        <div class="text-center font-bold" style="font-size: 13px;">${esc(issuerName)}</div>
        ${issuerNit ? `<div class="text-center">NIT: ${esc(issuerNit)}</div>` : ''}
        ${issuerAddress ? `<div class="text-center">${esc(issuerAddress)}</div>` : ''}
        ${issuerPhone ? `<div class="text-center">Tel: ${esc(issuerPhone)}</div>` : ''}
        <div class="divider"></div>
        <div class="text-center font-bold" style="font-size: 12px;">FACTURA ELECTRÓNICA DE VENTA</div>
        <div class="text-center font-bold">${invoiceNumber}</div>
        <div class="divider"></div>
        ${resolution ? `<div><b>Resolución DIAN:</b> ${esc(resolutionText)}</div>
        <div><b>Rango Autorizado:</b> ${esc(rangeText)}</div>` : ''}
        <div><b>Fecha Emisión:</b> ${new Date().toLocaleString('es-CO')}</div>
        <div><b>Forma de Pago:</b> Contado (${sale.paymentMethod || t('dian:efectivo')})</div>
        <div class="divider"></div>
        <div><b>Adquirente / Cliente:</b></div>
        <div><b>Nombre:</b> ${esc(clientName)}</div>
        <div><b>Identificación:</b> ${esc(docType)}: ${esc(docNumber)}</div>
        ${clientEmail ? `<div><b>Correo:</b> ${esc(clientEmail)}</div>` : ''}
        ${clientPhone ? `<div><b>Teléfono:</b> ${esc(clientPhone)}</div>` : ''}
        <div class="divider"></div>
        <table>
          <thead>
            <tr style="border-bottom: 1px solid #000;">
              <th align="left">Cant · Descripción</th>
              <th align="right">Total</th>
            </tr>
          </thead>
          <tbody>
            ${(sale.items || []).map((item: any) => `
              <tr>
                <td>${item.quantity}x ${esc(item.productVariant?.name || item.product?.name || item.productName || legalT('producto'))}</td>
                <td align="right">${formatCurrency(item.total || (item.quantity * item.unitPrice))}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
        <div class="divider"></div>
        <table>
          <tr><td>Base gravable:</td><td align="right">${formatCurrency(subtotal)}</td></tr>
          ${taxLines.length > 0
            ? taxLines.map((l) => `<tr><td>${taxName(l)}:</td><td align="right">${formatCurrency(l.amount)}</td></tr>`).join('')
            : taxTotal > 0 ? `<tr><td>Impuestos:</td><td align="right">${formatCurrency(taxTotal)}</td></tr>` : ''}
          <tr style="font-weight: bold; font-size: 13px;">
            <td>TOTAL A PAGAR:</td>
            <td align="right">${formatCurrency(total)}</td>
          </tr>
        </table>
        <div class="divider"></div>
        <div class="text-center font-bold">CUFE:</div>
        <div class="cufe-text text-center">${cufe}</div>
        <div class="qr-box">
          <div style="border: 2px solid #000; display: inline-block; padding: 6px; font-weight: bold; font-size: 9px;">
            [ CÓDIGO QR OFICIAL DIAN ]<br/>
            Validación Digital UBL 2.1
          </div>
        </div>
        <div class="text-center" style="font-size: 8px;">
          Software: Lantify POS<br/>
          ${isAccepted ? legalT('documento_validado_por_la_dian') : legalT('pendiente_de_validacion_por_la_dian')}<br/>
          ${business?.ticketFooter ? esc(business.ticketFooter) : legalT('gracias_por_su_visita')}
        </div>
      </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
      printWindow.close();
    }, 400);
  };

  useEffect(() => {
    if (!printPending) return;
    setPrintPending(false);
    handlePrint();
  }, [printPending]);

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5 overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl shadow-2xl border border-stone-200 w-full max-w-4xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Modal Top Header with DIAN Branding */}
        <div className="bg-gradient-to-r from-[#1a2f4c] via-[#24416b] to-[#122238] text-white px-6 py-4 flex items-center justify-between border-b border-blue-900 shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/10 flex items-center justify-center border border-white/20 shadow-inner">
              <Building2 className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-base font-black tracking-wide text-white">{t('dian:factura_electronica_de_venta')}</span>
                <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-400/40 rounded-full text-xs font-black uppercase tracking-wider flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  {t('dian:dian_validada')}
                </span>
                <span className="px-2 py-0.5 bg-blue-500/20 text-blue-200 border border-blue-400/40 rounded-full text-xs font-black uppercase tracking-wider">
                  {t('dian:ubl_2_1_oficial')}
                </span>
              </div>
              <p className="text-xs text-blue-200">
                {t('dian:resolucion_dian_no_187640000001_consecutivo_oficia')}{' '}<strong className="text-amber-300">{invoiceNumber}</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex bg-black/20 p-1 rounded-xl border border-white/10 text-xs">
              <button
                onClick={() => setActiveView('preview')}
                className={`px-3 py-1 rounded-lg font-bold transition-all ${
                  activeView === 'preview' ? 'bg-white text-[#1a2f4c] shadow' : 'text-blue-200 hover:text-white'
                }`}
              >
                {t('dian:vista_carta')}
              </button>
              <button
                onClick={() => setActiveView('tirilla')}
                className={`px-3 py-1 rounded-lg font-bold transition-all ${
                  activeView === 'tirilla' ? 'bg-white text-[#1a2f4c] shadow' : 'text-blue-200 hover:text-white'
                }`}
              >
                {t('dian:tirilla_pos')}
              </button>
            </div>

            <button
              onClick={onClose}
              className="p-2 text-blue-200 hover:text-white hover:bg-white/10 rounded-xl transition-all"
              title={t('dian:cerrar')}
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-5 bg-stone-50/60">
          
          {/* Adquirente / Customer Information Card */}
          <div className="bg-white rounded-2xl p-4 sm:p-5 border border-stone-200/80 shadow-sm">
            <div className="flex items-center justify-between mb-3 border-b border-stone-100 pb-2.5">
              <div className="flex items-center gap-2">
                <UserCheck className="w-4 h-4 text-blue-600" />
                <h4 className="text-xs font-black uppercase tracking-wider text-stone-800">
                  {t('dian:datos_del_adquirente_receptor_de_factura')}
                </h4>
              </div>
              <span className="text-xs text-stone-500 font-medium">
                {t('dian:se_enviara_xml_y_pdf_a_este')}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div>
                <label className="block text-xs font-bold text-stone-500 uppercase mb-1">{t('dian:tipo_de_documento')}</label>
                <select
                  value={docType}
                  onChange={(e) => setDocType(e.target.value)}
                  className="w-full px-3 py-2 border border-stone-200 rounded-xl bg-stone-50/50 font-bold text-stone-800 focus:outline-none focus:border-blue-500"
                >
                  <option value="CC">{t('dian:cedula_de_ciudadania_c_c')}</option>
                  <option value="NIT">{t('dian:nit_con_digito_de_verificacion')}</option>
                  <option value="CE">{t('dian:cedula_de_extranjeria_c_e')}</option>
                  <option value="PAS">{t('dian:pasaporte')}</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-500 uppercase mb-1">{t('dian:numero_de_identificacion')}</label>
                <input
                  type="text"
                  value={docNumber}
                  onChange={(e) => setDocNumber(e.target.value)}
                  className="w-full px-3 py-2 border border-stone-200 rounded-xl bg-white font-bold text-stone-800 focus:outline-none focus:border-blue-500"
                  placeholder={t('dian:ej_1075234891')}
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-500 uppercase mb-1">{t('dian:nombre_razon_social')}</label>
                <input
                  type="text"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  className="w-full px-3 py-2 border border-stone-200 rounded-xl bg-white font-bold text-stone-800 focus:outline-none focus:border-blue-500"
                  placeholder={t('dian:nombre_del_cliente_o_empresa')}
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-500 uppercase mb-1">{t('dian:correo_electronico_recepcion')}</label>
                <input
                  type="email"
                  value={clientEmail}
                  onChange={(e) => setClientEmail(e.target.value)}
                  className="w-full px-3 py-2 border border-stone-200 rounded-xl bg-white font-bold text-stone-800 focus:outline-none focus:border-blue-500"
                  placeholder="correo@ejemplo.com"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-500 uppercase mb-1">{t('dian:telefono_movil')}</label>
                <input
                  type="text"
                  value={clientPhone}
                  onChange={(e) => setClientPhone(e.target.value)}
                  className="w-full px-3 py-2 border border-stone-200 rounded-xl bg-white font-bold text-stone-800 focus:outline-none focus:border-blue-500"
                  placeholder="3101234567"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-500 uppercase mb-1">{t('dian:direccion_ciudad')}</label>
                <input
                  type="text"
                  value={clientAddress}
                  onChange={(e) => setClientAddress(e.target.value)}
                  className="w-full px-3 py-2 border border-stone-200 rounded-xl bg-white font-bold text-stone-800 focus:outline-none focus:border-blue-500"
                  placeholder={t('dian:direccion_ciudad')}
                />
              </div>
            </div>
          </div>

          {/* Invoice Document Representation */}
          {activeView === 'preview' ? (
            <div className="bg-white rounded-2xl p-6 border border-stone-200 shadow-sm space-y-4">
              {/* Emisor Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-stone-200 gap-4">
                <div>
                  <h3 className="text-base font-black text-stone-900">{issuerName || t('dian:configura_los_datos_del_negocio')}</h3>
                  {issuerNit && <p className="text-xs text-stone-500 font-medium">{t('dian:nit_value', { value: issuerNit })}</p>}
                  {issuerAddress && <p className="text-xs text-stone-500 font-medium">{issuerAddress}</p>}
                </div>
                <div className="bg-stone-50 p-3 rounded-xl border border-stone-200 text-right">
                  <span className="text-xs uppercase font-extrabold text-stone-400 block">{t('dian:factura_no')}</span>
                  <span className="text-lg font-black text-blue-900">{invoiceNumber}</span>
                  <span className="text-xs font-bold text-emerald-600 block mt-0.5">{t('dian:autorizada_dian')}</span>
                </div>
              </div>

              {/* Items Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left">
                  <thead>
                    <tr className="bg-stone-100/80 text-stone-600 font-black uppercase text-xs border-b border-stone-200">
                      <th className="py-2.5 px-3">{t('dian:item_producto')}</th>
                      <th className="py-2.5 px-2 text-center">{t('dian:cant')}</th>
                      <th className="py-2.5 px-3 text-right">{t('dian:v_unitario')}</th>
                      <th className="py-2.5 px-3 text-right">{t('dian:impuesto')}</th>
                      <th className="py-2.5 px-3 text-right">{t('dian:total')}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {(sale.items || []).map((item: any, idx: number) => {
                      const itemTotal = item.total || (item.quantity * item.unitPrice);
                      return (
                        <tr key={idx} className="hover:bg-stone-50/50">
                          <td className="py-2.5 px-3 font-bold text-stone-800">
                            {item.productVariant?.name || item.product?.name || item.productName || t('dian:producto_gourmet')}
                          </td>
                          <td className="py-2.5 px-2 text-center font-extrabold text-stone-700">
                            {item.quantity}
                          </td>
                          <td className="py-2.5 px-3 text-right text-stone-600">
                            {formatCurrency(item.unitPrice || (itemTotal / item.quantity))}
                          </td>
                          <td className="py-2.5 px-3 text-right text-stone-500 font-medium">
                            {item.taxType && item.taxType !== 'NONE' ? taxName(item) : '—'}
                          </td>
                          <td className="py-2.5 px-3 text-right font-black text-stone-900">
                            {formatCurrency(itemTotal)}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Financial Totals */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end pt-3 border-t border-stone-200 gap-4">
                <div className="text-xs text-stone-500 space-y-1">
                  <p><strong>{t('dian:medio_de_pago')}</strong>{t('dian:value_contado', { value: sale.paymentMethod || t('dian:efectivo') })}</p>
                  <p><strong>{t('dian:canal_de_venta')}</strong> {sale.channel || t('dian:pos_mesa_mostrador')}</p>
                  <p><strong>{t('dian:fecha_transmision')}</strong> {new Date().toLocaleString('es-CO')}</p>
                </div>

                <div className="w-full sm:w-64 bg-stone-50 p-3.5 rounded-xl border border-stone-200 space-y-1.5 text-xs">
                  <div className="flex justify-between text-stone-600">
                    <span>{t('dian:subtotal_operativo')}</span>
                    <span className="font-bold">{formatCurrency(subtotal)}</span>
                  </div>
                  {(taxLines.length > 0 ? taxLines : taxTotal > 0 ? [{ taxType: '', taxRate: 0, amount: taxTotal }] : []).map((l) => (
                    <div key={`${l.taxType}${l.taxRate}`} className="flex justify-between text-stone-600">
                      <span>{l.taxType ? taxName(l) : t('dian:impuestos_incluidos')}</span>
                      <span className="font-bold text-amber-700">{formatCurrency(l.amount)}</span>
                    </div>
                  ))}
                  <div className="flex justify-between text-stone-900 font-black text-sm pt-1.5 border-t border-stone-200">
                    <span>{t('dian:total_facturado')}</span>
                    <span className="text-blue-900">{formatCurrency(total)}</span>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            /* Tirilla POS View */
            <div className="bg-white rounded-2xl p-6 border border-stone-200 shadow-sm max-w-sm mx-auto font-mono text-xs space-y-3">
              <div className="text-center font-bold">
                <p className="text-sm">{issuerName}</p>
                {issuerNit && <p className="text-xs text-stone-600">{t('dian:nit_value', { value: issuerNit })}</p>}
                {(issuerAddress || issuerPhone) && <p className="text-xs text-stone-600">{[issuerAddress, issuerPhone].filter(Boolean).join(' · ')}</p>}
                <div className="border-t border-dashed border-stone-300 my-2" />
                <p className="text-xs text-blue-900">{t('dian:factura_electronica_de_venta_2')}</p>
                <p className="text-sm">{invoiceNumber}</p>
                <div className="border-t border-dashed border-stone-300 my-2" />
              </div>

              <div className="text-xs space-y-0.5 text-stone-700">
                {resolution && <p><strong>{t('dian:res_dian')}</strong>{' '}{resolutionText}</p>}
                <p><strong>{t('dian:cliente')}</strong> {clientName}</p>
                <p><strong>{docType}:</strong> {docNumber}</p>
                <p><strong>{t('dian:email')}</strong> {clientEmail}</p>
              </div>

              <div className="border-t border-dashed border-stone-300 my-2" />

              <div className="space-y-1 text-xs">
                {(sale.items || []).map((item: any, idx: number) => (
                  <div key={idx} className="flex justify-between">
                    <span>{item.quantity}x {item.productVariant?.name || item.productName || t('dian:producto')}</span>
                    <span>{formatCurrency(item.total || (item.quantity * item.unitPrice))}</span>
                  </div>
                ))}
              </div>

              <div className="border-t border-dashed border-stone-300 my-2" />

              <div className="space-y-1 text-xs">
                <div className="flex justify-between"><span>{t('dian:subtotal')}</span><span>{formatCurrency(subtotal)}</span></div>
                {taxLines.map((l) => (
                  <div key={`${l.taxType}${l.taxRate}`} className="flex justify-between"><span>{taxName(l)}</span><span>{formatCurrency(l.amount)}</span></div>
                ))}
                <div className="flex justify-between font-black text-sm pt-1 border-t border-stone-300">
                  <span>{t('dian:total_2')}</span><span>{formatCurrency(total)}</span>
                </div>
              </div>
            </div>
          )}

          {/* CUFE, QR and Telemetry Security Block */}
          <div className="bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 text-white rounded-2xl p-5 border border-blue-800 shadow-md">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex-1 space-y-2 text-xs">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span className="font-black text-amber-300 uppercase tracking-wide text-xs">
                    {t('dian:certificacion_criptografica_dian_ubl_2_1')}
                  </span>
                </div>

                <div>
                  <div className="flex items-center justify-between text-xs text-blue-200 font-bold mb-1">
                    <span>{t('dian:cufe_codigo_unico_de_facturacion_electronica')}</span>
                    <button
                      onClick={handleCopyCufe}
                      className="flex items-center gap-1 text-amber-300 hover:text-white"
                    >
                      {copiedCufe ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedCufe ? t('dian:copiado') : t('dian:copiar_cufe')}</span>
                    </button>
                  </div>
                  <p className="font-mono text-xs bg-black/40 p-2 rounded-xl text-blue-100 break-all leading-tight border border-white/10 select-all">
                    {cufe}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-3 text-xs text-blue-300 pt-1">
                  <span>{t('dian:proveedor')}{' '}<strong>{t('dian:lantify_cloud_dian')}</strong></span>
                  <span>{t('dian:certificado_digital')}{' '}<strong>{t('dian:andes_scd')}</strong></span>
                  <span>{t('dian:estado')}{' '}<strong className="text-emerald-400">{t('dian:applicationresponse_200_aprobado')}</strong></span>
                </div>
              </div>

              {/* QR Code Container */}
              <div className="bg-white p-3 rounded-2xl flex flex-col items-center justify-center shrink-0 shadow-lg text-[#1a2f4c]">
                <div className="w-20 h-20 bg-stone-100 rounded-xl border border-stone-300 flex items-center justify-center relative overflow-hidden">
                  {/* Visual simulated QR code */}
                  <div className="grid grid-cols-4 gap-1 p-2 w-full h-full">
                    <div className="bg-black rounded-sm" />
                    <div className="bg-black rounded-sm" />
                    <div className="bg-stone-300 rounded-sm" />
                    <div className="bg-black rounded-sm" />
                    <div className="bg-black rounded-sm" />
                    <div className="bg-stone-300 rounded-sm" />
                    <div className="bg-black rounded-sm" />
                    <div className="bg-stone-300 rounded-sm" />
                    <div className="bg-stone-300 rounded-sm" />
                    <div className="bg-black rounded-sm" />
                    <div className="bg-stone-300 rounded-sm" />
                    <div className="bg-black rounded-sm" />
                    <div className="bg-black rounded-sm" />
                    <div className="bg-stone-300 rounded-sm" />
                    <div className="bg-black rounded-sm" />
                    <div className="bg-black rounded-sm" />
                  </div>
                </div>
                <span className="text-xs font-black uppercase tracking-wider mt-1 text-stone-700">{t('dian:qr_dian')}</span>
              </div>
            </div>
          </div>

          {/* Email Notification Alert if sent */}
          {emailSent && (
            <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-3 rounded-2xl text-xs flex items-center gap-2 animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>
                <strong>{t('dian:factura_electronica_enviada')}</strong>{' '}{t('dian:se_ha_despachado_el_paquete_electronico_pdf')}{' '}<strong>{clientEmail}</strong>.
              </span>
            </div>
          )}

        </div>

        {/* Modal Bottom Actions */}
        <div className="bg-white px-6 py-4 border-t border-stone-200 flex flex-wrap items-center justify-between gap-3 shadow-inner">
          <div className="flex items-center gap-2 text-xs text-stone-500 font-medium">
            <Sparkles className="w-4 h-4 text-emerald-600" />
            <span>{t('dian:modulo_de_facturacion_electronica_dian')}</span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {!dianInvoice ? (
              <button
                onClick={handleEmitToDian}
                disabled={isEmitting}
                className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-md disabled:opacity-50"
              >
                <Send className={`w-3.5 h-3.5 ${isEmitting ? 'animate-spin' : ''}`} />
                <span>{isEmitting ? t('dian:encolando_en_dian') : t('dian:transmitir_encolar_en_dian')}</span>
              </button>
            ) : (
              <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-xl text-xs font-bold">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>{dianInvoice.status === 'ACCEPTED' ? t('dian:dian_aceptada') : t('dian:dian_en_cola')} ({dianInvoice.invoiceNumber})</span>
              </div>
            )}

            <button
              onClick={handleDownloadXML}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl text-xs font-bold transition-all border border-stone-300"
              title={t('dian:descargar_xml_estandar_ubl_2_1')}
            >
              <Download className="w-3.5 h-3.5 text-stone-600" />
              <span>{t('dian:descargar_xml')}</span>
            </button>

            <button
              onClick={handleSendEmail}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-xl text-xs font-bold transition-all"
              title={t('dian:enviar_correo_al_cliente')}
            >
              <Mail className="w-3.5 h-3.5 text-indigo-600" />
              <span>{emailSent ? t('dian:correo_despachado') : t('dian:enviar_por_email')}</span>
            </button>

            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-all shadow-md"
            >
              <Printer className="w-3.5 h-3.5 text-white" />
              <span>{t('dian:imprimir_factura')}</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
