// ============================================
// INFRASTRUCTURE - Product Repository Implementation
// ============================================

import { PrismaClient, Category, Product, ProductVariant } from '@prisma/client';
import { IProductRepository } from '../../../domain/repositories/IProductRepository';

export class ProductRepository implements IProductRepository {
  constructor(private prisma: PrismaClient) {}

  // Category
  async createCategory(data: Omit<Category, 'id' | 'createdAt' | 'updatedAt'>): Promise<Category> {
    return this.prisma.category.create({ data });
  }

  async getCategoryById(id: string): Promise<Category | null> {
    return this.prisma.category.findUnique({ where: { id } });
  }

  async getAllCategories(): Promise<Category[]> {
    return this.prisma.category.findMany({
      where: { isActive: true },
      orderBy: { name: 'asc' },
    });
  }

  async updateCategory(id: string, data: Partial<Category>): Promise<Category> {
    return this.prisma.category.update({ where: { id }, data });
  }

  async deleteCategory(id: string): Promise<void> {
    await this.prisma.category.update({ where: { id }, data: { isActive: false } });
  }

  // Product
  async create(data: any): Promise<Product> {
    const { variants, ...productData } = data;
    
    return this.prisma.product.create({
      data: {
        ...productData,
        variants: variants ? {
          create: variants
        } : undefined
      },
      include: { variants: true, category: true }
    });
  }

  async getById(id: string): Promise<Product | null> {
    return this.prisma.product.findUnique({
      where: { id },
      include: { variants: true, category: true },
    });
  }

  async getAll(includeInactive: boolean = false): Promise<Product[]> {
    return this.prisma.product.findMany({
      where: includeInactive ? {} : { isActive: true },
      include: { variants: true, category: true },
      orderBy: { name: 'asc' },
    });
  }

  async getByCategory(categoryId: string): Promise<Product[]> {
    return this.prisma.product.findMany({
      where: { categoryId, isActive: true },
      include: { variants: true },
      orderBy: { name: 'asc' },
    });
  }

  async update(id: string, data: Partial<Product>): Promise<Product> {
    return this.prisma.product.update({ where: { id }, data });
  }

  async delete(id: string): Promise<void> {
    await this.prisma.product.update({ where: { id }, data: { isActive: false } });
  }

  async createVariant(data: Omit<ProductVariant, 'id' | 'createdAt' | 'updatedAt' | 'trackInventory'> & { trackInventory?: boolean }): Promise<ProductVariant> {
    return this.prisma.productVariant.create({
      data: {
        trackInventory: false,
        ...data,
      }
    });
  }

  async getVariantById(id: string): Promise<ProductVariant | null> {
    return this.prisma.productVariant.findUnique({
      where: { id },
      include: { product: true },
    });
  }

  async getVariantBySku(sku: string): Promise<ProductVariant | null> {
    return this.prisma.productVariant.findUnique({ where: { sku } });
  }

  async getVariantsByProduct(productId: string): Promise<ProductVariant[]> {
    return this.prisma.productVariant.findMany({
      where: { productId, isActive: true },
      orderBy: { name: 'asc' },
    });
  }

  async updateVariant(id: string, data: Partial<ProductVariant>): Promise<ProductVariant> {
    return this.prisma.productVariant.update({ where: { id }, data });
  }

  async deleteVariant(id: string): Promise<void> {
    await this.prisma.productVariant.update({ where: { id }, data: { isActive: false } });
  }

  async updateStock(id: string, quantity: number): Promise<ProductVariant> {
    return this.prisma.productVariant.update({
      where: { id },
      data: { stock: { increment: quantity } },
    });
  }

  async permanentDelete(id: string): Promise<void> {
    await this.prisma.product.delete({ where: { id } });
  }

  async permanentDeleteVariant(id: string): Promise<void> {
    await this.prisma.productVariant.delete({ where: { id } });
  }
}