// ============================================
// INTERFACES - CashSession Routes
// ============================================

import { Router } from 'express';
import { CashSessionController } from '../controllers';

export const createCashSessionRoutes = (controller: CashSessionController) => {
  const router = Router();

  // Rutas principales
  router.post('/', controller.openSession.bind(controller));
  router.get('/open', controller.getOpenSession.bind(controller));
  router.get('/', controller.getAllSessions.bind(controller));
  router.get('/date-range', controller.getSessionsByDateRange.bind(controller));
  router.get('/:id', controller.getSessionById.bind(controller));
  
  // Operaciones sobre una sesión específica
  router.post('/:id/income', controller.addIncome.bind(controller));
  router.post('/:id/expense', controller.addExpense.bind(controller));
  router.put('/:id/income/cancel', controller.cancelIncome.bind(controller));
  router.put('/:id/expense/cancel', controller.cancelExpense.bind(controller));
  router.post('/:id/close', controller.closeSession.bind(controller));

  return router;
};