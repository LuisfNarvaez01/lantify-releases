// ============================================
// APPLICATION DTOs - CashSession
// ============================================

export interface OpenCashSessionDTO {
  initialBalance: number;
  notes?: string;
}

export interface CloseCashSessionDTO {
  countedBalance: number;
  notes?: string;
}

export interface CashSessionResponseDTO {
  id: string;
  sessionNumber: string;
  openedAt: Date;
  closedAt?: Date;
  initialBalance: number;
  income: number;
  expenses: number;
  finalBalance?: number;
  expectedBalance?: number;
  difference?: number;
  status: 'OPEN' | 'CLOSED';
  notes?: string;
}

export interface AddTransactionDTO {
  amount: number;
  description?: string;
}