// ============================================
// COMPONENTS - Función fuera del plan (candado + plan que la incluye)
// ============================================

import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { Lock, X } from 'lucide-react';
import { FEATURE_PLAN, PLAN_PRICE, PLAN_LOCK_EVENT, PlanCode } from '../../shared/plan';
import { formatCurrency } from '../../shared/formatUtils';
import { t } from '../../i18n';

const isAdmin = () => {
  try {
    return JSON.parse(localStorage.getItem('user') || '{}')?.role === 'ADMIN';
  } catch {
    return false;
  }
};

/** Candado pequeño para pestañas y botones */
export function LockBadge({ className = '' }: { className?: string }) {
  return <Lock className={`w-3.5 h-3.5 shrink-0 opacity-70 ${className}`} aria-label={t('plan:no_incluido')} />;
}

interface PlanLockedProps {
  feature: string;
  /** Dentro de un modal o un panel pequeño */
  compact?: boolean;
}

/** Explica qué hace la función, en qué plan está y cómo obtenerla */
export function PlanLocked({ feature, compact = false }: PlanLockedProps) {
  const plan: PlanCode = FEATURE_PLAN[feature] || 'pro';
  return (
    <section
      className={`${compact ? '' : 'max-w-xl mx-auto my-10 bg-surface border border-line rounded-2xl shadow-sm'} p-6 sm:p-8 text-center`}
      aria-labelledby={`plan-lock-${feature}`}
    >
      <div className="mx-auto mb-4 w-12 h-12 rounded-full bg-primary-soft text-primary-text flex items-center justify-center">
        <Lock className="w-5 h-5" aria-hidden />
      </div>
      <p className="text-xs font-semibold uppercase tracking-wider text-primary-text">
        {t('plan:disponible_en', { plan: t(`plan:plan_${plan}`) })}
      </p>
      <h2 id={`plan-lock-${feature}`} className="mt-2 text-xl font-bold text-fg">
        {t(`plan:f_${feature}`)}
      </h2>
      <p className="mt-2 text-sm text-fg-secondary leading-relaxed">{t(`plan:f_${feature}_desc`)}</p>
      <p className="mt-4 text-sm font-semibold text-fg tabular-nums">
        {t('plan:desde_al_mes', { price: formatCurrency(PLAN_PRICE[plan]) })}
      </p>
      <p className="mt-4 text-xs text-fg-muted leading-relaxed">
        {isAdmin() ? t('plan:como_cambiar') : t('plan:pidele_al_admin')}
      </p>
    </section>
  );
}

/** Modal global: cualquier pantalla puede pedirlo con showPlanLock('dian') */
export function PlanLockHost() {
  const [feature, setFeature] = useState<string | null>(null);

  useEffect(() => {
    const open = (e: Event) => setFeature((e as CustomEvent<{ feature: string }>).detail?.feature || null);
    window.addEventListener(PLAN_LOCK_EVENT, open);
    return () => window.removeEventListener(PLAN_LOCK_EVENT, open);
  }, []);

  useEffect(() => {
    if (!feature) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setFeature(null);
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [feature]);

  if (!feature) return null;
  return createPortal(
    <div className="fixed inset-0 z-[90] flex items-center justify-center p-4 bg-black/50" onClick={() => setFeature(null)}>
      <div
        role="dialog"
        aria-modal="true"
        className="relative w-full max-w-md bg-surface border border-line rounded-2xl shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          type="button"
          onClick={() => setFeature(null)}
          className="absolute top-3 right-3 p-2 rounded-lg text-fg-muted hover:text-fg hover:bg-surface-muted"
          aria-label={t('plan:cerrar')}
        >
          <X className="w-4 h-4" />
        </button>
        <PlanLocked feature={feature} compact />
        <div className="px-6 pb-6">
          <button
            type="button"
            onClick={() => setFeature(null)}
            className="w-full min-h-[42px] rounded-lg bg-primary hover:bg-primary-hover text-white text-sm font-semibold"
          >
            {t('plan:entendido')}
          </button>
        </div>
      </div>
    </div>,
    document.body,
  );
}
