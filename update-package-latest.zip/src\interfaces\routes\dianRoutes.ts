// ============================================
// ROUTES - DIAN Electronic Invoicing & Offline Queue
// Modo de Operación: Software Propio / Habilitación / Producción
// ============================================

import { Router, Request, Response } from 'express';
import { dianService } from '../../infrastructure/services/DianElectronicBillingService';
import { factusService } from '../../infrastructure/services/FactusService';
import { prisma } from '../../infrastructure/database/prisma';
import { maskDianConfig, stripUnchangedSecrets, SECRET_MASK } from '../../shared/security/secretCipher';

// Un campo secreto que llega con la máscara o vacío significa "usar el guardado"
const keepIfMasked = (incoming: any, stored: any) =>
  incoming && incoming !== SECRET_MASK ? incoming : stored || '';

export function createDianRoutes(): Router {
  const router = Router();

  // 1. Obtener Configuración DIAN
  router.get('/config', async (_req: Request, res: Response) => {
    try {
      const config = await dianService.getConfig();
      return res.json({ success: true, config: maskDianConfig(config) });
    } catch (error: any) {
      console.error('Error fetching DIAN config:', error);
      return res.status(500).json({ error: error.message || 'Error al obtener configuración DIAN' });
    }
  });

  // 2. Actualizar Configuración DIAN
  router.put('/config', async (req: Request, res: Response) => {
    try {
      const { id: _id, createdAt: _c, updatedAt: _u, ...data } = req.body || {};
      const updated = await dianService.updateConfig(stripUnchangedSecrets(data));
      return res.json({
        success: true,
        message: 'Configuración DIAN actualizada correctamente',
        config: maskDianConfig(updated)
      });
    } catch (error: any) {
      console.error('Error updating DIAN config:', error);
      return res.status(500).json({ error: error.message || 'Error al guardar configuración DIAN' });
    }
  });

  // 3. Asociar Software Propio en el catálogo DIAN
  router.post('/associate', async (req: Request, res: Response) => {
    try {
      const { softwareName, softwarePin, softwareId, providerName } = req.body;
      const updated = await dianService.updateConfig({
        softwareName: softwareName || 'LANTIFY POS',
        softwarePin: softwarePin && softwarePin !== SECRET_MASK ? softwarePin : undefined,
        softwareId: softwareId || '4424e8ce-107e-403c-90c9-7023e70cae7d',
        providerName: providerName || 'NARVAEZ LOPEZ LUIS FELIPE',
        isAssociated: true
      });

      return res.json({
        success: true,
        message: '¡Software Propio asociado exitosamente con el catálogo de habilitación de la DIAN!',
        config: maskDianConfig(updated)
      });
    } catch (error: any) {
      console.error('Error associating DIAN software:', error);
      return res.status(500).json({ error: error.message || 'Error al asociar software con DIAN' });
    }
  });

  // 4. Estadísticas y Monitoreo de Conectividad / Cola DIAN
  router.get('/stats', async (_req: Request, res: Response) => {
    try {
      const stats = await dianService.getQueueStats();
      return res.json({ success: true, ...stats });
    } catch (error: any) {
      console.error('Error fetching DIAN queue stats:', error);
      return res.status(500).json({ error: 'Error al consultar estado de la cola DIAN' });
    }
  });

  // 5. Listar Facturas en Cola
  router.get('/queue', async (req: Request, res: Response) => {
    try {
      const { status } = req.query;
      const where: any = {};
      if (status && typeof status === 'string') {
        where.status = status;
      }

      const invoices = await prisma.dianInvoice.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        include: {
          sale: {
            select: {
              saleNumber: true,
              total: true,
              paymentMethod: true,
              createdAt: true
            }
          }
        }
      });

      return res.json({ success: true, count: invoices.length, invoices });
    } catch (error: any) {
      console.error('Error fetching DIAN queue:', error);
      return res.status(500).json({ error: 'Error al listar cola de facturas' });
    }
  });

  // 6. Disparar Procesamiento Manual de la Cola
  router.post('/queue/process', async (_req: Request, res: Response) => {
    try {
      const result = await dianService.processQueue();
      return res.json({
        success: true,
        message: `Cola procesada: ${result.processed} analizadas, ${result.success} aceptadas, ${result.failed} pendientes/fallidas`,
        result
      });
    } catch (error: any) {
      console.error('Error processing DIAN queue:', error);
      return res.status(500).json({ error: error.message || 'Error al procesar cola DIAN' });
    }
  });

  // 7. Reintentar Envío de una Factura Específica
  router.post('/queue/:id/retry', async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const result = await dianService.retryInvoice(id);
      return res.json({
        success: true,
        message: 'Factura reenviada a procesamiento de cola',
        result
      });
    } catch (error: any) {
      console.error('Error retrying invoice:', error);
      return res.status(500).json({ error: error.message || 'Error al reintentar factura' });
    }
  });

  // 8. Emitir / Encolar Factura Electrónica para una Venta
  router.post('/emit', async (req: Request, res: Response) => {
    try {
      const { saleId, customer } = req.body;
      if (!saleId) {
        return res.status(400).json({ error: 'El ID de la venta es obligatorio' });
      }

      const invoice = await dianService.enqueueInvoice(saleId, {
        nit: customer?.nit || '222222222222',
        name: customer?.name || 'Consumidor Final',
        email: customer?.email,
        phone: customer?.phone,
        address: customer?.address,
        documentType: customer?.documentType || 'CC'
      });

      return res.json({
        success: true,
        message: invoice.status === 'ACCEPTED' 
          ? 'Factura electrónica transmitida y aceptada por la DIAN'
          : 'Factura electrónica generada y encolada (se sincronizará automáticamente)',
        invoice
      });
    } catch (error: any) {
      console.error('Error emitting electronic invoice:', error);
      return res.status(500).json({ error: error.message || 'Error al emitir factura electrónica' });
    }
  });

  // Datos de la resolución de facturación (se imprimen en cada factura; no incluye secretos)
  router.get('/resolution', async (_req: Request, res: Response) => {
    try {
      const config = await dianService.getConfig();
      return res.json({
        success: true,
        resolution: config ? {
          resolutionNumber: config.resolutionNumber,
          resolutionDate: config.resolutionDate,
          prefix: config.prefix,
          rangeFrom: config.rangeFrom,
          rangeTo: config.rangeTo,
          operationMode: config.operationMode,
        } : null,
      });
    } catch (error: any) {
      console.error('Error fetching DIAN resolution:', error);
      return res.status(500).json({ error: 'Error al consultar la resolución DIAN' });
    }
  });

  // 9. Consultar Factura Electrónica por Venta
  router.get('/sale/:saleId', async (req: Request, res: Response) => {
    try {
      const { saleId } = req.params;
      const invoice = await prisma.dianInvoice.findUnique({
        where: { saleId }
      });

      return res.json({ success: true, invoice });
    } catch (error: any) {
      console.error('Error fetching invoice for sale:', error);
      return res.status(500).json({ error: 'Error al buscar factura de la venta' });
    }
  });

  // 10. Disparar Lote de Habilitación DIAN Automático
  router.post('/test-set/run', async (_req: Request, res: Response) => {
    try {
      const result = await dianService.runHabilitationTestSet(29);
      return res.json({
        message: '¡Set de Pruebas de Habilitación DIAN generado y transmitido exitosamente!',
        ...result
      });
    } catch (error: any) {
      console.error('Error running test set:', error);
      return res.status(500).json({ error: error.message || 'Error al ejecutar set de pruebas' });
    }
  });

  // 11. Descargar XML UBL 2.1
  router.get('/invoice/:id/xml', async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const invoice = await prisma.dianInvoice.findUnique({
        where: { id }
      });

      if (!invoice || !invoice.xmlContent) {
        return res.status(404).json({ error: 'XML no disponible para esta factura' });
      }

      res.setHeader('Content-Type', 'application/xml');
      res.setHeader('Content-Disposition', `attachment; filename="${invoice.invoiceNumber}.xml"`);
      return res.send(invoice.xmlContent);
    } catch (error: any) {
      console.error('Error downloading XML:', error);
      return res.status(500).json({ error: 'Error al descargar XML' });
    }
  });

  // 12. Probar Conexión con Factus API
  router.post('/factus/test-connection', async (req: Request, res: Response) => {
    try {
      const { clientId, clientSecret, username, password, environment } = req.body;
      const config = await dianService.getConfig();

      const testResult = await factusService.testConnection({
        clientId: clientId || config.factusClientId || '',
        clientSecret: keepIfMasked(clientSecret, config.factusClientSecret),
        username: username || config.factusUsername || '',
        password: keepIfMasked(password, config.factusPassword),
        environment: environment || config.factusEnvironment || 'SANDBOX'
      });

      return res.json(testResult);
    } catch (error: any) {
      console.error('Error testing Factus connection:', error);
      return res.status(500).json({ success: false, message: error.message || 'Error al conectar con Factus API' });
    }
  });

  // 13. Obtener Rangos de Numeración Factus
  router.get('/factus/ranges', async (_req: Request, res: Response) => {
    try {
      const ranges = await factusService.getNumberingRanges();
      return res.json({ success: true, ranges });
    } catch (error: any) {
      console.error('Error fetching Factus ranges:', error);
      return res.status(500).json({ success: false, message: error.message || 'Error al obtener rangos Factus' });
    }
  });

  return router;
}
