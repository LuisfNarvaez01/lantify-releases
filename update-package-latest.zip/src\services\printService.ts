/**
 * Service for handling POS printing via hidden iframes to avoid new tabs.
 * Supports configurable paper widths (58mm / 80mm), margins, font sizing, and kiosk printing.
 */

import { formatCurrency } from '../shared/formatUtils';
import i18next from '../i18n';

// Los tickets se imprimen en el idioma configurado para el negocio (por defecto español),
// independiente del idioma de la pantalla de cada usuario.
const ticketT = (config: PrintConfig) => {
  const lang = config.ticketLanguage === 'en' ? 'en' : 'es';
  return { tt: i18next.getFixedT(lang, 'ticket') as (key: string, opts?: Record<string, unknown>) => string, locale: lang === 'en' ? 'en-US' : 'es-CO' };
};

export interface PrintConfig {
  businessName?: string;
  address?: string;
  phone?: string;
  receiptTemplate?: string;
  kitchenTemplate?: string;
  receiptFont?: string;
  receiptLogo?: string;
  invoicePrinter?: string;
  kitchenPrinter?: string;
  taxRate?: number;
  nit?: string;
  paperWidth?: '58mm' | '80mm';
  receiptMargin?: '0mm' | '2mm' | '4mm';
  fontSizeTicket?: 'compact' | 'medium' | 'large';
  ticketFooterText?: string;
  ticketLanguage?: 'es' | 'en';
  autoPrintReceipt?: boolean;
}

const createPrintIframe = (content: string) => {
  // Remove existing iframes if any
  const existingFrame = document.getElementById('pos-print-iframe');
  if (existingFrame) {
    document.body.removeChild(existingFrame);
  }

  const iframe = document.createElement('iframe');
  iframe.id = 'pos-print-iframe';
  iframe.style.position = 'fixed';
  iframe.style.right = '0';
  iframe.style.bottom = '0';
  iframe.style.width = '0';
  iframe.style.height = '0';
  iframe.style.border = '0';
  document.body.appendChild(iframe);

  const doc = iframe.contentWindow?.document || iframe.contentDocument;
  if (doc) {
    doc.write(content);
    doc.close();
  }
};

const esc = (v: unknown) =>
  String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

export const printService = {
  printReceipt: (config: PrintConfig, saleData: any) => {
    const { items, subtotal, total, tableNumber, isPartialPayment, selectedItemsForPayment } = saleData;
    const { tt, locale } = ticketT(config);
    // Los precios traen el impuesto incluido: se informa cuánto corresponde a cada impuesto
    const taxLines: { label: string; amount: number }[] = (saleData.taxLines || [])
      .filter((l: any) => l.amount > 0)
      .map((l: any) => ({ label: `${l.taxType === 'IVA' ? tt('iva') : tt('inc')} ${l.taxRate}%`, amount: l.amount }));
    // Pre-cuenta: se entrega antes de cobrar y sugiere la propina. El recibo final no la incluye.
    const isPreBill = saleData.kind === 'prebill';
    const suggestedTip = Number(saleData.suggestedTip) || 0;
    const tipPercent = Number(saleData.tipPercent) || 0;
    const methodLabel = (m: string) => (m === 'CASH' ? tt('efectivo') : m === 'CARD' ? tt('tarjeta') : m === 'TRANSFER' ? tt('transferencia') : tt('mixto'));
    const itemsToPrint = isPartialPayment
      ? items.filter((item: any) => selectedItemsForPayment.has(item.id))
      : items;

    let itemsContent = '';
    itemsToPrint.forEach((item: any) => {
      itemsContent += `\n${item.quantity}x ${item.productName}\n${item.variantName}\n${formatCurrency(item.unitPrice)} ${tt('cada_uno')} - ${formatCurrency(item.total)}`;
    });

    const businessName = config.businessName || 'LANTIFY POS';
    const address = config.address || '';
    const phone = config.phone || '';
    const date = new Date().toLocaleString(locale);
    const table = tableNumber || tt('mostrador');
    const is58mm = config.paperWidth === '58mm';
    const paperWidthStyle = is58mm ? '205px' : '290px';
    const pageMargin = config.receiptMargin || '2mm';

    // Font size scaling
    const baseFontSize = config.fontSizeTicket === 'compact' ? '12px' : config.fontSizeTicket === 'large' ? '16px' : '14px';
    const titleFontSize = config.fontSizeTicket === 'compact' ? '18px' : config.fontSizeTicket === 'large' ? '24px' : '20px';
    const totalFontSize = config.fontSizeTicket === 'compact' ? '20px' : config.fontSizeTicket === 'large' ? '28px' : '24px';

    const receiptFont = config.receiptFont || 'sans-serif';
    const receiptLogo = config.receiptLogo || '';
    const nit = config.nit || '';
    const footerMsg = config.ticketFooterText || tt('gracias');

    // Transform itemsContent to HTML for precision alignment
    let itemsHtml = '';
    itemsToPrint.forEach((item: any) => {
      const name = item.productName || item.productVariant?.product?.name || tt('producto');
      const variant = item.variantName || item.productVariant?.name || '';
      itemsHtml += `
        <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 4px;">
          <div style="text-align: left; flex: 1; padding-right: 6px;">
            <div style="font-weight: 700; word-break: break-word;">${item.quantity}x ${esc(name)}</div>
            ${variant ? `<div style="font-size: 0.85em; opacity: 0.75;">${esc(variant)}</div>` : ''}
          </div>
          <div style="text-align: right; font-weight: 900; white-space: nowrap; font-variant-numeric: tabular-nums;">
            ${formatCurrency(item.total)}
          </div>
        </div>
      `;
    });

    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>${isPreBill ? tt('precuenta') : tt('recibo')} - ${saleData.saleNumber || table}</title>
        <meta charset="utf-8" />
        <style>
          @page {
            size: ${is58mm ? '58mm' : '80mm'} auto;
            margin: ${pageMargin};
          }
          * {
            box-sizing: border-box;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
          }
          body { 
            margin: 0; 
            padding: ${pageMargin}; 
            font-family: ${receiptFont}; 
            font-size: ${baseFontSize}; 
            width: ${paperWidthStyle}; 
            max-width: ${paperWidthStyle};
            height: auto; 
            color: #000;
            line-height: 1.35;
          }
          .center { text-align: center; }
          .header { text-align: center; margin-bottom: 8px; }
          .logo { max-width: 65px; height: auto; margin: 0 auto 6px; display: block; filter: grayscale(100%); }
          .business-name { font-weight: 950; font-size: ${titleFontSize}; margin: 2px 0; text-transform: uppercase; letter-spacing: 0.5px; }
          .nit { font-size: 0.9em; font-weight: 700; margin-bottom: 3px; }
          .info { font-size: 0.88em; margin-bottom: 2px; }
          .divider { border-top: 1.5px dashed #000; margin: 8px 0; }
          .totals-section { width: 100%; margin-top: 8px; }
          .footer-msg { margin-top: 14px; text-align: center; font-style: italic; font-size: 0.9em; font-weight: 700; }
        </style>
      </head>
      <body>
        <div class="header">
          ${receiptLogo ? `<img src="${receiptLogo}" class="logo" />` : ''}
          <div class="business-name">${esc(businessName)}</div>
          ${nit ? `<div class="nit">NIT: ${nit}</div>` : ''}
          ${address ? `<div class="info">${address}</div>` : ''}
          ${phone ? `<div class="info">${tt('tel')}: ${phone}</div>` : ''}
          <div class="divider"></div>
          ${isPreBill ? `<div style="font-weight: 950; font-size: 1.05em; letter-spacing: 1px;">${tt('precuenta').toUpperCase()}</div>
          <div class="info" style="font-size: 0.8em;">${tt('no_valida_como_factura')}</div>
          <div class="divider"></div>` : ''}
          <div class="info" style="font-weight: 800;">${tt('lugar')}: <strong>${table}</strong></div>
          <div class="info">${tt('fecha')}: ${date}</div>
          ${saleData.saleNumber ? `<div class="info" style="font-size: 0.8em; opacity: 0.8;">${tt('ref')}: ${saleData.saleNumber}</div>` : ''}
          ${saleData.customer ? `
            <div class="info" style="margin-top: 5px; font-size: 0.85em; background: #f1f5f9; padding: 4px; border-radius: 6px; text-align: left; border: 1px solid #cbd5e1;">
              <strong>${tt('cliente')}:</strong> ${esc(saleData.customer.name)}<br/>
              ${saleData.customer.nit ? `<strong>${tt('nit_cc')}:</strong> ${esc(saleData.customer.nit)}<br/>` : ''}
              ${saleData.customer.phone ? `<strong>${tt('tel')}:</strong> ${esc(saleData.customer.phone)}` : ''}
            </div>
          ` : ''}
        </div>

        <div class="divider"></div>
        <div class="items-container">
          ${itemsHtml}
        </div>
        <div class="divider"></div>

        <div class="totals-section">
          <div style="display: flex; justify-content: space-between; margin-bottom: 3px;">
            <span>${tt('subtotal')}:</span>
            <span>${formatCurrency(subtotal)}</span>
          </div>
          ${saleData.discountAmount > 0 ? `
            <div style="display: flex; justify-content: space-between; margin-bottom: 3px; font-weight: bold;">
              <span>${tt('descuento_pct', { pct: saleData.discountPct })}:</span>
              <span>-${formatCurrency(saleData.discountAmount)}</span>
            </div>
          ` : ''}
          <div style="display: flex; justify-content: space-between; font-size: ${totalFontSize}; font-weight: 950; margin-top: 6px; border-top: 2px solid #000; padding-top: 4px;">
            <span>${tt('total')}:</span>
            <span>${formatCurrency(total)}</span>
          </div>
          ${taxLines.length > 0 ? `
            <div style="font-size: 0.82em; margin-top: 3px;">
              ${taxLines.map((l: { label: string; amount: number }) => `
                <div style="display: flex; justify-content: space-between;">
                  <span>${tt('incluye_impuesto', { tax: l.label })}:</span>
                  <span>${formatCurrency(l.amount)}</span>
                </div>
              `).join('')}
            </div>
          ` : ''}
          ${isPreBill && suggestedTip > 0 ? `
            <div class="divider"></div>
            <div style="display: flex; justify-content: space-between; margin-top: 2px;">
              <span>${tt('propina_sugerida_pct', { pct: tipPercent })}:</span>
              <span>${formatCurrency(suggestedTip)}</span>
            </div>
            <div style="display: flex; justify-content: space-between; font-weight: 900; margin-top: 2px;">
              <span>${tt('total_con_propina')}:</span>
              <span>${formatCurrency(total + suggestedTip)}</span>
            </div>
            <div style="font-size: 0.78em; margin-top: 4px; text-align: center;">${tt('propina_es_voluntaria')}</div>
          ` : ''}
          ${isPreBill ? '' : `
          
          ${saleData.payments && saleData.payments.length > 0 ? `
            <div class="divider"></div>
            <div style="font-size: 0.88em;">
              <div style="font-weight: bold; margin-bottom: 3px;">${tt('pago_realizado')}:</div>
              ${saleData.payments.map((p: any) => `
                <div style="display: flex; justify-content: space-between; margin-bottom: 2px;">
                  <span>${methodLabel(p.method)}:</span>
                  <span>${formatCurrency(p.amount)}</span>
                </div>
              `).join('')}
              ${saleData.change > 0 ? `
                <div style="display: flex; justify-content: space-between; font-weight: 800; margin-top: 3px;">
                  <span>${tt('cambio_devuelto')}:</span>
                  <span>${formatCurrency(saleData.change)}</span>
                </div>
              ` : ''}
            </div>
          ` : `
            <div class="divider"></div>
            <div style="display: flex; justify-content: space-between; font-size: 0.9em;">
              <span>${tt('metodo_pago')}:</span>
              <span>${methodLabel(saleData.paymentMethod)}</span>
            </div>
            ${saleData.change > 0 ? `
              <div style="display: flex; justify-content: space-between; font-size: 0.9em; font-weight: 800; margin-top: 2px;">
                <span>${tt('cambio')}:</span>
                <span>${formatCurrency(saleData.change)}</span>
              </div>
            ` : ''}
          `}
          `}
        </div>

        ${!isPreBill && saleData.loyaltyInfo?.eligible && saleData.loyaltyInfo?.token ? `
          <div class="divider"></div>
          <div style="text-align: center; margin: 8px 0; border: 1.5px dashed #000; padding: 8px 4px; border-radius: 6px;">
            <div style="font-weight: 950; font-size: 0.95em; text-transform: uppercase;">
              ¡TIENES ${saleData.loyaltyInfo.stamps} ${saleData.loyaltyInfo.stamps === 1 ? 'SELLO' : 'SELLOS'} EN ESTA COMPRA!
            </div>
            <div style="font-size: 0.8em; margin: 4px 0;">
              Escanea este código QR con tu celular para estampar tu tarjeta digital:
            </div>
            <div style="margin: 6px auto;">
              <img src="https://api.qrserver.com/v1/create-qr-code/?size=140x140&margin=2&data=${encodeURIComponent(saleData.loyaltyInfo.token.claimUrl)}" style="width: 120px; height: 120px; margin: 0 auto; display: block;" alt="QR Sellos" />
            </div>
            <div style="font-size: 0.72em; opacity: 0.85;">Válido por 24 horas · Reclama tus premios</div>
          </div>
        ` : ''}

        <div class="footer-msg">
          ${footerMsg}
        </div>

        <script>
          window.onload = () => {
            setTimeout(() => {
              window.print();
            }, 300);
          };
        </script>
      </body>
      </html>
    `;

    createPrintIframe(html);
  },

  printKitchenTicket: (config: PrintConfig, orderData: any) => {
    const { items, tableNumber } = orderData;
    const { tt, locale } = ticketT(config);
    
    let itemsHtml = '';
    items.forEach((item: any) => {
      itemsHtml += `
        <div style="margin-bottom: 6px; padding-bottom: 4px; border-bottom: 1px dotted #ccc;">
          <div style="display: flex; justify-content: space-between; font-size: 1.1em; font-weight: 900;">
            <span>${item.quantity}× ${esc(item.productName)}</span>
          </div>
          ${item.variantName ? `<div style="font-size: 0.9em; font-weight: 600; padding-left: 10px;">• ${esc(item.variantName)}</div>` : ''}
          ${item.notes ? `<div style="font-size: 0.85em; font-weight: bold; background: #000; color: #fff; padding: 2px 4px; border-radius: 3px; margin-top: 2px;">${tt('nota')}: ${esc(item.notes)}</div>` : ''}
        </div>
      `;
    });

    const time = new Date().toLocaleTimeString(locale, { hour: '2-digit', minute: '2-digit' });
    const table = tableNumber || tt('mostrador');
    const is58mm = config.paperWidth === '58mm';
    const paperWidthStyle = is58mm ? '205px' : '290px';
    const pageMargin = config.receiptMargin || '2mm';

    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>${tt('comanda')} - ${table}</title>
        <meta charset="utf-8" />
        <style>
          @page {
            size: ${is58mm ? '58mm' : '80mm'} auto;
            margin: ${pageMargin};
          }
          * { box-sizing: border-box; }
          body { 
            margin: 0; 
            padding: ${pageMargin}; 
            font-family: monospace; 
            font-size: 13px; 
            width: ${paperWidthStyle}; 
            max-width: ${paperWidthStyle};
            height: auto; 
            color: #000;
          }
          .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 6px; margin-bottom: 8px; }
          .title { font-weight: 900; font-size: 18px; text-transform: uppercase; letter-spacing: 1px; }
          .meta { font-size: 14px; font-weight: 800; margin-top: 2px; }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="title">🍳 ${tt('comanda_de_cocina')}</div>
          <div class="meta" style="font-size: 16px;">${tt('destino')}: <strong>${table}</strong> ${orderData.roundNumber ? `• ${tt('ronda', { round: orderData.roundNumber })}` : ''}</div>
          <div class="meta">${tt('hora')}: ${time}</div>
        </div>
        <div class="items">
          ${itemsHtml}
        </div>
        <script>
          window.onload = () => {
            setTimeout(() => {
              window.print();
            }, 300);
          };
        </script>
      </body>
      </html>
    `;

    createPrintIframe(html);
  }
};
