// ============================================
// DOMAIN REPOSITORIES - CashSession Repository Interface
// ============================================

export interface ICashSessionRepository {
  create(data: any): Promise<any>;
  getById(id: string): Promise<any | null>;
  getAll(): Promise<any[]>;
  getOpenSession(): Promise<any | null>;
  getByDateRange(startDate: Date, endDate: Date): Promise<any[]>;
  update(id: string, data: any): Promise<any>;
  closeSession(id: string, countedBalance: number, notes?: string): Promise<any>;
  addIncome(id: string, amount: number, motive: string, description?: string): Promise<any>;
  addExpense(id: string, amount: number, motive: string, description?: string, categoryId?: string): Promise<any>;
  cancelIncome(sessionId: string, incomeId: string, reason: string): Promise<any>;
  cancelExpense(sessionId: string, expenseId: string, reason: string): Promise<any>;
  delete(id: string): Promise<void>;
}