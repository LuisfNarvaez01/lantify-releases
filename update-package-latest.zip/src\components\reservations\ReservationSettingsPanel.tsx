// ============================================
// RESERVAS - Configuración (ADMIN)
// ============================================
// Qué mesas se pueden reservar (solo mesas que existen en Salón y mesas), en
// qué horario se reciben llegadas, cuánto se aparta la mesa y las reglas de la
// página pública (anticipación, días hacia adelante, tamaño del grupo).

import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { X, Plus, Trash2, Copy, Globe, ExternalLink, Loader2, Download } from 'lucide-react';
import QRCode from 'qrcode';
import { reservationsAPI, BookingConfig, BookingSettings, BookingScheduleBlock } from '../../services/api';
import { errorMessage } from '../../services/apiErrors';
import { toast } from '../../shared/toast';
import { Toggle } from '../common/Choice';
import { t } from '../../i18n';

const PUBLIC_BASE = 'https://lantifypos.dpdns.org/m/';
const DAYS = [1, 2, 3, 4, 5, 6, 0];
const inputCls = 'min-h-[40px] px-3 rounded-xl border border-slate-200 bg-white text-sm text-slate-900 focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20';

/** QR de la página para imprimir (mesas, vitrina, carta) y el enlace para compartir por WhatsApp o redes */
export function PublicLink({ url }: { url: string }) {
  const [qr, setQr] = useState('');
  useEffect(() => {
    QRCode.toDataURL(url, { width: 480, margin: 1, errorCorrectionLevel: 'M' }).then(setQr).catch(() => setQr(''));
  }, [url]);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(url);
      toast.success(t('reservations:enlace_copiado'));
    } catch {
      toast.info(url);
    }
  };
  return (
    <div className="flex flex-col sm:flex-row gap-4 rounded-2xl bg-slate-50 border border-slate-200 p-4">
      {qr && <img src={qr} alt={t('reservations:qr_alt')} className="w-36 h-36 rounded-xl bg-white p-1.5 border border-slate-200 self-center" />}
      <div className="flex-1 min-w-0 space-y-2">
        <p className="text-xs font-bold text-slate-600">{t('reservations:pagina_publica')}</p>
        <a href={url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-sm font-black text-blue-700 hover:underline break-all">
          {url.replace('https://', '')} <ExternalLink className="w-3.5 h-3.5 shrink-0" aria-hidden />
        </a>
        <p className="text-xs text-slate-500">{t('reservations:qr_desc')}</p>
        <div className="flex flex-wrap gap-2 pt-1">
          <button type="button" onClick={copy} className="inline-flex items-center gap-1.5 min-h-[36px] px-3 rounded-xl border border-slate-200 bg-white text-xs font-bold text-slate-700 hover:bg-slate-50">
            <Copy className="w-3.5 h-3.5" aria-hidden /> {t('reservations:copiar_enlace')}
          </button>
          {qr && (
            <a href={qr} download="reservas-qr.png" className="inline-flex items-center gap-1.5 min-h-[36px] px-3 rounded-xl border border-slate-200 bg-white text-xs font-bold text-slate-700 hover:bg-slate-50">
              <Download className="w-3.5 h-3.5" aria-hidden /> {t('reservations:descargar_qr')}
            </a>
          )}
        </div>
      </div>
    </div>
  );
}

function NumberField({ label, value, onChange, min, max, suffix }: { label: string; value: number; onChange: (n: number) => void; min: number; max: number; suffix: string }) {
  return (
    <label className="block">
      <span className="text-xs font-bold text-slate-600">{label}</span>
      <span className="mt-1 flex items-center gap-2">
        <input type="number" min={min} max={max} value={value} onChange={(e) => onChange(Math.min(max, Math.max(min, Number(e.target.value) || 0)))} className={`${inputCls} w-24 tabular-nums`} />
        <span className="text-xs text-slate-500">{suffix}</span>
      </span>
    </label>
  );
}

export function ReservationSettingsPanel({ onClose, onSaved }: { onClose: () => void; onSaved: (c: BookingConfig) => void }) {
  const [config, setConfig] = useState<BookingConfig | null>(null);
  const [s, setS] = useState<BookingSettings | null>(null);
  const [reservable, setReservable] = useState<Set<string>>(new Set());
  const [slug, setSlug] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    reservationsAPI.settings().then((c) => {
      setConfig(c);
      setS(c.settings);
      setReservable(new Set(c.tables.filter((tb) => tb.reservable).map((tb) => tb.id)));
      setSlug(c.slug || '');
    }).catch((e) => toast.error(errorMessage(e)));
  }, []);

  if (!config || !s) {
    return createPortal(
      <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/50"><Loader2 className="w-8 h-8 animate-spin text-white" aria-hidden /></div>,
      document.body,
    );
  }

  const set = <K extends keyof BookingSettings>(k: K, v: BookingSettings[K]) => setS({ ...s, [k]: v });
  const blocksOf = (day: number) => s.schedule.filter((b) => b.day === day);
  const setBlocks = (day: number, blocks: BookingScheduleBlock[]) => set('schedule', [...s.schedule.filter((b) => b.day !== day), ...blocks]);
  const copyToAll = (day: number) => set('schedule', DAYS.flatMap((d) => blocksOf(day).map((b) => ({ ...b, day: d }))));
  const toggleTable = (id: string) => {
    const next = new Set(reservable);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setReservable(next);
  };

  const zones = [...new Set(config.tables.map((tb) => tb.zone || t('reservations:sin_zona')))];

  const save = async () => {
    setSaving(true);
    try {
      const saved = await reservationsAPI.saveSettings({ settings: s, reservableTableIds: [...reservable], slug });
      if (saved.publish && !saved.publish.ok) toast.warning(t(`reservations:publicar_${saved.publish.code || 'error'}`, { defaultValue: t('reservations:publicar_error') }), t('reservations:guardado_local'));
      else toast.success(t('reservations:config_guardada'));
      onSaved(saved);
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setSaving(false);
    }
  };

  const publicUrl = config.slug ? `${PUBLIC_BASE}${config.slug}` : null;

  return createPortal(
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/50 p-4" role="dialog" aria-modal="true" aria-labelledby="booking-settings-title">
      <div className="w-full max-w-3xl max-h-[94vh] overflow-y-auto rounded-3xl bg-white shadow-2xl">
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-slate-100 bg-white px-6 py-4">
          <div>
            <h3 id="booking-settings-title" className="text-lg font-black text-slate-900">{t('reservations:config_titulo')}</h3>
            <p className="text-xs text-slate-500">{t('reservations:config_desc')}</p>
          </div>
          <button type="button" onClick={onClose} className="p-2 rounded-xl text-slate-400 hover:bg-slate-100 hover:text-slate-700" aria-label={t('common:cerrar')}>
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-7">
          <Toggle id="bk-enabled" checked={s.enabled} onChange={(v) => set('enabled', v)} label={t('reservations:activar_modulo')} description={t('reservations:activar_modulo_desc')} />

          {/* Mesas */}
          <section>
            <div className="flex items-end justify-between gap-3">
              <div>
                <h4 className="text-sm font-black text-slate-900">{t('reservations:mesas_reservables')}</h4>
                <p className="text-xs text-slate-500">{t('reservations:mesas_reservables_desc')}</p>
              </div>
              {config.tables.length > 0 && (
                <div className="flex gap-2 text-xs font-bold">
                  <button type="button" onClick={() => setReservable(new Set(config.tables.map((tb) => tb.id)))} className="text-blue-700 hover:underline">{t('reservations:todas')}</button>
                  <button type="button" onClick={() => setReservable(new Set())} className="text-slate-500 hover:underline">{t('reservations:ninguna')}</button>
                </div>
              )}
            </div>
            {config.tables.length === 0 ? (
              <p className="mt-3 rounded-xl bg-amber-50 border border-amber-200 px-3 py-2 text-xs text-amber-900">{t('reservations:sin_mesas')}</p>
            ) : (
              zones.map((zone) => (
                <div key={zone} className="mt-3">
                  <p className="text-[11px] font-black uppercase tracking-wider text-slate-500 mb-1.5">{zone}</p>
                  <div className="flex flex-wrap gap-1.5">
                    {config.tables.filter((tb) => (tb.zone || t('reservations:sin_zona')) === zone).map((tb) => {
                      const on = reservable.has(tb.id);
                      return (
                        <button
                          key={tb.id}
                          type="button"
                          role="checkbox"
                          aria-checked={on}
                          onClick={() => toggleTable(tb.id)}
                          className={`min-w-[4.5rem] px-3 py-2 rounded-xl border text-left ${on ? 'border-blue-600 bg-blue-50' : 'border-slate-200 hover:border-slate-300'}`}
                        >
                          <span className={`block text-sm font-black ${on ? 'text-blue-800' : 'text-slate-700'}`}>{t('reservations:mesa_n', { table: tb.number })}</span>
                          <span className="block text-[11px] text-slate-500">{t('reservations:personas', { count: tb.capacity })}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))
            )}
          </section>

          {/* Horario */}
          <section>
            <h4 className="text-sm font-black text-slate-900">{t('reservations:horario')}</h4>
            <p className="text-xs text-slate-500">{t('reservations:horario_desc')}</p>
            <div className="mt-3 divide-y divide-slate-100 rounded-2xl border border-slate-200">
              {DAYS.map((day) => {
                const blocks = blocksOf(day);
                return (
                  <div key={day} className="flex flex-col sm:flex-row sm:items-center gap-2 px-3 py-2.5">
                    <span className="w-24 shrink-0 text-sm font-bold text-slate-800">{t(`reservations:dia_${day}`)}</span>
                    <div className="flex-1 flex flex-wrap items-center gap-2">
                      {blocks.length === 0 && <span className="text-xs text-slate-400">{t('reservations:cerrado')}</span>}
                      {blocks.map((b, i) => (
                        <span key={i} className="inline-flex items-center gap-1 rounded-xl bg-slate-50 border border-slate-200 px-1.5 py-1">
                          <input type="time" value={b.from} onChange={(e) => setBlocks(day, blocks.map((x, j) => (j === i ? { ...x, from: e.target.value } : x)))} className="bg-transparent text-sm font-bold" aria-label={t('reservations:desde')} />
                          <span className="text-slate-400">–</span>
                          <input type="time" value={b.to} onChange={(e) => setBlocks(day, blocks.map((x, j) => (j === i ? { ...x, to: e.target.value } : x)))} className="bg-transparent text-sm font-bold" aria-label={t('reservations:hasta_label')} />
                          <button type="button" onClick={() => setBlocks(day, blocks.filter((_, j) => j !== i))} className="p-1 text-slate-400 hover:text-rose-600" aria-label={t('reservations:quitar_franja')}>
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </span>
                      ))}
                      <button type="button" onClick={() => setBlocks(day, [...blocks, { day, from: '19:00', to: '21:00' }])} className="p-1.5 rounded-lg text-blue-700 hover:bg-blue-50" aria-label={t('reservations:agregar_franja')}>
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                    {blocks.length > 0 && (
                      <button type="button" onClick={() => copyToAll(day)} className="self-start sm:self-auto inline-flex items-center gap-1 text-[11px] font-bold text-slate-500 hover:text-blue-700">
                        <Copy className="w-3 h-3" aria-hidden /> {t('reservations:copiar_a_todos')}
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </section>

          {/* Reglas */}
          <section>
            <h4 className="text-sm font-black text-slate-900">{t('reservations:reglas')}</h4>
            <div className="mt-3 grid grid-cols-2 sm:grid-cols-3 gap-4">
              <NumberField label={t('reservations:duracion')} value={s.durationMinutes} min={30} max={360} suffix={t('reservations:minutos')} onChange={(v) => set('durationMinutes', v)} />
              <label className="block">
                <span className="text-xs font-bold text-slate-600">{t('reservations:intervalo')}</span>
                <select value={s.slotMinutes} onChange={(e) => set('slotMinutes', Number(e.target.value))} className={`${inputCls} mt-1 w-full`}>
                  {[15, 30, 60].map((m) => <option key={m} value={m}>{t('reservations:cada_min', { count: m })}</option>)}
                </select>
              </label>
              <NumberField label={t('reservations:max_personas')} value={s.maxPartySize} min={1} max={100} suffix={t('reservations:personas_label').toLowerCase()} onChange={(v) => set('maxPartySize', v)} />
              <NumberField label={t('reservations:anticipacion')} value={Math.round(s.minAdvanceMinutes / 60)} min={0} max={168} suffix={t('reservations:horas_antes')} onChange={(v) => set('minAdvanceMinutes', v * 60)} />
              <NumberField label={t('reservations:dias_adelante')} value={s.maxDaysAhead} min={1} max={180} suffix={t('reservations:dias')} onChange={(v) => set('maxDaysAhead', v)} />
              <NumberField label={t('reservations:cancelar_hasta')} value={Math.round(s.cancelUntilMinutes / 60)} min={0} max={168} suffix={t('reservations:horas_antes')} onChange={(v) => set('cancelUntilMinutes', v * 60)} />
            </div>
          </section>

          {/* En línea */}
          <section className="rounded-3xl border border-slate-200 p-4 space-y-4">
            <div className="flex items-start gap-3">
              <span className="w-10 h-10 shrink-0 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center"><Globe className="w-5 h-5" aria-hidden /></span>
              <div>
                <h4 className="text-sm font-black text-slate-900">{t('reservations:en_linea')}</h4>
                <p className="text-xs text-slate-500">{t('reservations:en_linea_desc')}</p>
              </div>
            </div>
            <Toggle id="bk-online" checked={s.online} onChange={(v) => set('online', v)} label={t('reservations:recibir_en_linea')} description={t('reservations:recibir_en_linea_desc')} />
            {s.online && (
              <>
                <label className="block">
                  <span className="text-xs font-bold text-slate-600">{t('reservations:direccion')}</span>
                  <span className="mt-1 flex items-center rounded-xl border border-slate-200 overflow-hidden focus-within:border-blue-600">
                    <span className="px-3 text-xs text-slate-500 bg-slate-50 self-stretch flex items-center">lantifypos.dpdns.org/m/</span>
                    <input value={slug} maxLength={40} onChange={(e) => setSlug(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, '-'))} placeholder="mi-restaurante" className="flex-1 min-h-[40px] px-2 text-sm font-bold outline-none" />
                  </span>
                </label>
                <Toggle id="bk-confirm" checked={s.requireConfirmation} onChange={(v) => set('requireConfirmation', v)} label={t('reservations:requiere_confirmacion')} description={t('reservations:requiere_confirmacion_desc')} />
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <label className="block">
                    <span className="text-xs font-bold text-slate-600">{t('reservations:whatsapp_negocio')}</span>
                    <input value={s.whatsapp || ''} inputMode="tel" maxLength={20} onChange={(e) => set('whatsapp', e.target.value || null)} placeholder="+57 300 000 0000" className={`${inputCls} mt-1 w-full`} />
                  </label>
                  <label className="block">
                    <span className="text-xs font-bold text-slate-600">{t('reservations:mensaje_publico')}</span>
                    <input value={s.message || ''} maxLength={280} onChange={(e) => set('message', e.target.value || null)} placeholder={t('reservations:mensaje_publico_ej')} className={`${inputCls} mt-1 w-full`} />
                  </label>
                </div>
                {publicUrl && config.publishedAt ? (
                  <PublicLink url={publicUrl} />
                ) : (
                  <p className="text-xs text-slate-500">{t('reservations:se_publica_al_guardar')}</p>
                )}
              </>
            )}
          </section>

          <div className="flex gap-3">
            <button type="button" onClick={onClose} className="flex-1 min-h-[48px] rounded-xl border border-slate-200 font-bold text-slate-700 hover:bg-slate-50">
              {t('common:cancelar')}
            </button>
            <button type="button" onClick={save} disabled={saving} className="flex-[2] min-h-[48px] rounded-xl bg-blue-600 font-bold text-white shadow-sm hover:bg-blue-700 disabled:opacity-50">
              {saving ? t('reservations:guardando') : t('reservations:guardar_config')}
            </button>
          </div>
        </div>
      </div>
    </div>,
    document.body,
  );
}
