// ============================================
// ADMIN - DIAN Electronic Invoicing & Offline Queue
// Modo de Operación: Software Propio DIAN
// ============================================

import { useState, useEffect } from 'react';
import { 
  ShieldCheck, RefreshCw, CheckCircle2, AlertCircle, 
  Clock, Download, Send, Wifi, WifiOff, Copy,
  Check, CheckCircle, ExternalLink, Key, Cloud, Sparkles
} from 'lucide-react';
import { dianAPI } from '../../services/api';
import { toast } from '../../shared/toast';
import { formatCurrency } from '../../shared/formatUtils';
import { useBusinessStore } from '../../shared/business';

import { t, getLocale } from '../../i18n';
export function DianBillingAdmin() {
  // El emisor es el negocio configurado; el servidor sobrescribe con lo guardado
  const business = useBusinessStore((s) => s.settings);
  const [config, setConfig] = useState<any>({
    billingProvider: 'FACTUS', // 'FACTUS' o 'DIAN_DIRECT'
    factusEnvironment: 'SANDBOX',
    factusClientId: '',
    factusClientSecret: '',
    factusUsername: '',
    factusPassword: '',
    operationMode: 'SOFTWARE_PROPIO',
    providerName: t('dian:narvaez_lopez_luis_felipe'),
    softwareName: t('dian:lantify_pos'),
    softwarePin: '12345',
    softwareId: 'edce5592-1856-407e-acd4-e4269f7333b5',
    testSetId: '1f64e353-a8ff-488e-b2c2-bc4e05265c92',
    wsdlUrl: 'https://vpfe-hab.dian.gov.co/WcfDianCustomerServices.svc?wsdl',
    nit: business?.nit || '',
    dv: business?.dv || '',
    businessName: business?.legalName || business?.businessName || '',
    resolutionNumber: '18760000001',
    resolutionDate: '2019-01-19',
    prefix: 'SETP',
    rangeFrom: 990000000,
    rangeTo: 995000000,
    currentNumber: 990000002,
    technicalKey: 'fc8eac422eba16e22f8f8b8f94b3f40a6e38162c',
    isAssociated: true,
    autoSync: true
  });

  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isAssociating, setIsAssociating] = useState(false);
  const [isProcessingQueue, setIsProcessingQueue] = useState(false);
  const [isRunningTestSet, setIsRunningTestSet] = useState(false);
  const [isTestingFactus, setIsTestingFactus] = useState(false);
  const [factusTestResult, setFactusTestResult] = useState<any>(null);
  const [stats, setStats] = useState<any>(null);
  const [invoices, setInvoices] = useState<any[]>([]);
  const [activeFilter, setActiveFilter] = useState<string>('ALL');
  const [selectedCufe, setSelectedCufe] = useState<string | null>(null);
  const [copiedCufe, setCopiedCufe] = useState(false);

  // Cargar configuración y estado de la cola
  const loadData = async () => {
    setIsLoading(true);
    try {
      const [configRes, statsRes, queueRes] = await Promise.all([
        dianAPI.getConfig(),
        dianAPI.getStats(),
        dianAPI.getQueue()
      ]);

      if (configRes?.config) {
        setConfig(configRes.config);
      }
      if (statsRes) {
        setStats(statsRes);
      }
      if (queueRes?.invoices) {
        setInvoices(queueRes.invoices);
      }
    } catch (err: any) {
      console.warn('Error cargando módulo DIAN:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 30000); // Refrescar cada 30 segundos
    return () => clearInterval(interval);
  }, []);

  // Guardar cambios de configuración
  const handleSaveConfig = async () => {
    setIsSaving(true);
    try {
      const res = await dianAPI.updateConfig(config);
      toast.success(t('dian:parametros_dian_actualizados_correctamente'), t('dian:configuracion_guardada'));
      if (res?.config) {
        setConfig(res.config);
      }
    } catch (err: any) {
      toast.error(err.message || 'Error al guardar configuración', 'Error DIAN');
    } finally {
      setIsSaving(false);
    }
  };

  // Botón "Asociar" (exacto a la captura de la DIAN)
  const handleAssociate = async () => {
    setIsAssociating(true);
    try {
      const res = await dianAPI.associate({
        softwareName: config.softwareName,
        softwarePin: config.softwarePin,
        softwareId: config.softwareId,
        providerName: config.providerName
      });
      toast.success(res.message || t('dian:software_propio_asociado_exitosamente_ante_la_dian'), t('dian:asociacion_dian'));
      if (res?.config) {
        setConfig(res.config);
      }
    } catch (err: any) {
      toast.error(err.message || 'Error al asociar con la DIAN', 'Fallo de Asociación');
    } finally {
      setIsAssociating(false);
    }
  };

  // Procesar cola de facturación manualmente
  const handleProcessQueue = async () => {
    setIsProcessingQueue(true);
    try {
      const res = await dianAPI.processQueue();
      toast.info(res.message || 'Cola sincronizada', 'Worker DIAN');
      await loadData();
    } catch (err: any) {
      toast.error(err.message || 'Error al procesar cola', 'Error');
    } finally {
      setIsProcessingQueue(false);
    }
  };

  // Reintentar factura específica
  const handleRetryInvoice = async (id: string) => {
    try {
      await dianAPI.retryInvoice(id);
      toast.success(t('dian:factura_puesta_en_reintento_prioritario'), t('dian:cola_dian'));
      await loadData();
    } catch (err: any) {
      toast.error(err.message || 'Error al reintentar', 'Error');
    }
  };

  // Disparar lote de pruebas de habilitación hacia la DIAN
  const handleRunTestSet = async () => {
    setIsRunningTestSet(true);
    try {
      const res = await dianAPI.runTestSet();
      toast.success(res.message || t('dian:lote_de_habilitacion_transmitido_a_la_dian'), t('dian:set_de_pruebas'));
      await loadData();
    } catch (err: any) {
      toast.error(err.message || 'Error al transmitir set de pruebas', 'Error DIAN');
    } finally {
      setIsRunningTestSet(false);
    }
  };

  // Probar Conexión en Vivo con Factus Cloud
  const handleTestFactus = async () => {
    setIsTestingFactus(true);
    setFactusTestResult(null);
    try {
      const res = await dianAPI.testFactusConnection({
        clientId: config.factusClientId,
        clientSecret: config.factusClientSecret,
        username: config.factusUsername,
        password: config.factusPassword,
        environment: config.factusEnvironment
      });
      setFactusTestResult(res);
      if (res.success) {
        toast.success(res.message || t('dian:conexion_exitosa_con_factus_api'), t('dian:factus_cloud_conectado'));
      } else {
        toast.error(res.message || 'Fallo de autenticación con Factus', 'Error Factus');
      }
    } catch (err: any) {
      const errMsg = err.message || t('dian:error_de_red_con_factus_api');
      setFactusTestResult({ success: false, message: errMsg });
      toast.error(errMsg, 'Error');
    } finally {
      setIsTestingFactus(false);
    }
  };

  const filteredInvoices = invoices.filter(inv => {
    if (activeFilter === 'ALL') return true;
    return inv.status === activeFilter;
  });

  return (
    <div className="space-y-6 pb-20">
      {/* ── HEADER BANNER ────────────────────────────────────────── */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 text-white p-6 sm:p-8 rounded-3xl shadow-sm border border-slate-800">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="flex items-start gap-4">
            <div className="w-14 h-14 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-2xl flex items-center justify-center shrink-0 shadow-inner">
              <ShieldCheck className="w-8 h-8" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h2 className="text-xl sm:text-2xl font-bold font-heading">{t('dian:facturacion_electronica_dian')}</h2>
                <span className="px-3 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-full text-xs font-bold uppercase tracking-wider">
                  {t('dian:modo_software_propio')}
                </span>
                <span className="px-3 py-1 bg-blue-500/20 text-blue-300 border border-blue-500/30 rounded-full text-xs font-bold">
                  {t('dian:cola_offline_first')}
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
                {t('dian:emision_directa_gratuita_ante_la_dian_segun')}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={handleProcessQueue}
              disabled={isProcessingQueue || isLoading}
              className="flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white rounded-2xl font-bold text-xs shadow-sm transition-all disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 ${isProcessingQueue || isLoading ? 'animate-spin' : ''}`} />
              <span>{isLoading ? t('dian:consultando_dian') : isProcessingQueue ? t('dian:transmitiendo') : t('dian:sincronizar_cola_ahora')}</span>
            </button>
            <button
              onClick={handleSaveConfig}
              disabled={isSaving}
              className="flex items-center gap-2 px-5 py-2.5 bg-white text-slate-900 hover:bg-slate-100 active:scale-95 rounded-2xl font-bold text-xs shadow-sm transition-all"
            >
              <Check className="w-4 h-4 text-emerald-600" />
              <span>{isSaving ? t('dian:guardando') : t('dian:guardar_parametros')}</span>
            </button>
          </div>
        </div>

        {/* Status Metrics Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 pt-6 border-t border-slate-800">
          <div className="bg-slate-800/60 p-4 rounded-2xl border border-slate-700/60">
            <div className="flex items-center justify-between text-xs text-slate-400 font-bold mb-1">
              <span>{t('dian:estado_conexion')}</span>
              {stats?.isOnline ? (
                <Wifi className="w-4 h-4 text-emerald-400" />
              ) : (
                <WifiOff className="w-4 h-4 text-amber-400" />
              )}
            </div>
            <div className="flex items-center gap-2">
              <span className={`w-2.5 h-2.5 rounded-full ${stats?.isOnline ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
              <span className="text-sm font-bold text-white">
                {stats?.isOnline ? t('dian:dian_conectada') : t('dian:modo_offline_en_cola')}
              </span>
            </div>
          </div>

          <div className="bg-slate-800/60 p-4 rounded-2xl border border-slate-700/60">
            <span className="text-xs text-slate-400 font-bold block mb-1">{t('dian:en_cola_pendientes')}</span>
            <div className="flex items-baseline gap-2">
              <span className="text-xl font-extrabold text-amber-400">
                {stats?.queue?.pending || 0}
              </span>
              <span className="text-xs text-slate-400">{t('dian:facturas')}</span>
            </div>
          </div>

          <div className="bg-slate-800/60 p-4 rounded-2xl border border-slate-700/60">
            <span className="text-xs text-slate-400 font-bold block mb-1">{t('dian:aprobadas_por_dian')}</span>
            <div className="flex items-baseline gap-2">
              <span className="text-xl font-extrabold text-emerald-400">
                {stats?.queue?.accepted || 0}
              </span>
              <span className="text-xs text-slate-400">{t('dian:validadas')}</span>
            </div>
          </div>

          <div className="bg-slate-800/60 p-4 rounded-2xl border border-slate-700/60">
            <span className="text-xs text-slate-400 font-bold block mb-1">{t('dian:total_registradas')}</span>
            <div className="flex items-baseline gap-2">
              <span className="text-xl font-extrabold text-white">
                {stats?.queue?.total || 0}
              </span>
              <span className="text-xs text-slate-400">{t('dian:consecutivos')}</span>
            </div>
          </div>
        </div>
      </div>

      {/* ── SELECTOR DE MODALIDAD: FACTUS CLOUD vs SOFTWARE PROPIO DIRECTO ── */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <button
          type="button"
          onClick={() => setConfig({ ...config, billingProvider: 'FACTUS' })}
          className={`p-5 rounded-3xl border text-left transition-all relative ${
            (config.billingProvider || 'FACTUS') === 'FACTUS'
              ? 'bg-emerald-50/80 border-emerald-500 shadow-sm ring-2 ring-emerald-500/20'
              : 'bg-white border-slate-200 hover:border-slate-300'
          }`}
        >
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-emerald-500" />
              <h4 className="font-bold text-slate-900 text-base font-heading flex items-center gap-2">
                <Cloud className="w-5 h-5 text-emerald-600" />
                {t('dian:factus_api_cloud')}
              </h4>
            </div>
            <span className="px-2.5 py-0.5 bg-emerald-100 text-emerald-800 text-xs font-extrabold rounded-full flex items-center gap-1">
              <Sparkles className="w-3 h-3" />
              {t('dian:recomendado')}
            </span>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed mb-3">
            <strong>{t('dian:100_sin_certificado_digital_local')}</strong>{' '}{t('dian:factus_firma_y_valida_tus_facturas_en')}
          </p>
          <div className="flex items-center gap-2 text-xs font-bold text-emerald-700">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>{t('dian:sandbox_ilimitado_gratis_costo_por_folio_ultra')}</span>
          </div>
        </button>

        <button
          type="button"
          onClick={() => setConfig({ ...config, billingProvider: 'DIAN_DIRECT' })}
          className={`p-5 rounded-3xl border text-left transition-all ${
            config.billingProvider === 'DIAN_DIRECT'
              ? 'bg-slate-900 text-white border-slate-900 shadow-sm ring-2 ring-slate-900/20'
              : 'bg-white border-slate-200 hover:border-slate-300'
          }`}
        >
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-slate-400" />
              <h4 className={`font-bold text-base font-heading ${config.billingProvider === 'DIAN_DIRECT' ? 'text-white' : 'text-slate-900'}`}>
                {t('dian:software_propio_directo')}
              </h4>
            </div>
            <span className={`px-2.5 py-0.5 text-xs font-bold rounded-full ${config.billingProvider === 'DIAN_DIRECT' ? 'bg-slate-800 text-slate-300' : 'bg-slate-100 text-slate-600'}`}>
              {t('dian:requiere_certificado_p12')}
            </span>
          </div>
          <p className={`text-xs leading-relaxed mb-3 ${config.billingProvider === 'DIAN_DIRECT' ? 'text-slate-300' : 'text-slate-600'}`}>
            {t('dian:conexion_soap_directa_al_ws_de_la')}
          </p>
          <div className={`flex items-center gap-2 text-xs font-bold ${config.billingProvider === 'DIAN_DIRECT' ? 'text-slate-300' : 'text-slate-500'}`}>
            <AlertCircle className="w-3.5 h-3.5" />
            <span>{t('dian:set_de_pruebas_de_50_documentos_dian')}</span>
          </div>
        </button>
      </div>

      {/* ── SECCIÓN FACTUS CLOUD (MODO RECOMENDADO) ── */}
      {(config.billingProvider || 'FACTUS') === 'FACTUS' && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-xs border border-slate-200/80 space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 flex-wrap gap-3">
              <div>
                <h3 className="text-lg font-bold text-slate-900 font-heading flex items-center gap-2">
                  <Key className="w-5 h-5 text-emerald-600" />
                  {t('dian:credenciales_de_factus_api_v2')}
                </h3>
                <p className="text-xs text-slate-500">
                  {t('dian:obten_tus_credenciales_registrandote_en')}{' '}<a href="https://developers.factus.com.co/" target="_blank" rel="noreferrer" className="text-emerald-600 font-bold hover:underline">developers.factus.com.co</a>{' '}{t('dian:o_en_la_plataforma_factus')}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-600">{t('dian:ambiente')}</span>
                <select
                  value={config.factusEnvironment || 'SANDBOX'}
                  onChange={(e) => setConfig({ ...config, factusEnvironment: e.target.value })}
                  className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 outline-none"
                >
                  <option value="SANDBOX">{t('dian:pruebas_sandbox_gratuito')}</option>
                  <option value="PRODUCTION">{t('dian:produccion_operacion_real')}</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider">
                  {t('dian:client_id')}{' '}<span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={config.factusClientId || ''}
                  onChange={(e) => setConfig({ ...config, factusClientId: e.target.value })}
                  placeholder={t('dian:tu_client_id_entregado_por_factus')}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider">
                  {t('dian:client_secret')}{' '}<span className="text-rose-500">*</span>
                </label>
                <input
                  type="password"
                  value={config.factusClientSecret || ''}
                  onChange={(e) => setConfig({ ...config, factusClientSecret: e.target.value })}
                  placeholder="••••••••••••••••••••••••••••••"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider">
                  {t('dian:correo_electronico_username')}
                </label>
                <input
                  type="email"
                  value={config.factusUsername || ''}
                  onChange={(e) => setConfig({ ...config, factusUsername: e.target.value })}
                  placeholder="usuario@nativos.com"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider">
                  {t('dian:contrasena_password')}
                </label>
                <input
                  type="password"
                  value={config.factusPassword || ''}
                  onChange={(e) => setConfig({ ...config, factusPassword: e.target.value })}
                  placeholder="••••••••••••"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 outline-none"
                />
              </div>
            </div>

            {/* Test Connection Button & Result */}
            <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <button
                type="button"
                onClick={handleTestFactus}
                disabled={isTestingFactus || !config.factusClientId || !config.factusClientSecret}
                className="flex items-center gap-2 px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-bold text-xs rounded-xl shadow-sm transition-all disabled:opacity-50"
              >
                <RefreshCw className={`w-4 h-4 ${isTestingFactus ? 'animate-spin' : ''}`} />
                <span>{isTestingFactus ? t('dian:validando_con_factus') : t('dian:probar_conexion_factus_en_vivo')}</span>
              </button>

              <div className="flex items-center gap-3">
                <label className="text-xs font-bold text-slate-700 flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={config.autoSync ?? true}
                    onChange={(e) => setConfig({ ...config, autoSync: e.target.checked })}
                    className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-slate-300"
                  />
                  <span>{t('dian:despachar_facturas_automaticamente_cada_60s')}</span>
                </label>
              </div>
            </div>

            {factusTestResult && (
              <div className={`p-4 rounded-2xl border text-xs ${factusTestResult.success ? 'bg-emerald-50 border-emerald-200 text-emerald-900' : 'bg-rose-50 border-rose-200 text-rose-900'}`}>
                <div className="flex items-center gap-2 font-bold mb-1">
                  {factusTestResult.success ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <AlertCircle className="w-4 h-4 text-rose-600" />}
                  <span>{factusTestResult.message}</span>
                </div>
                {factusTestResult.numberingRanges && factusTestResult.numberingRanges.length > 0 && (
                  <div className="mt-2 pt-2 border-t border-emerald-200/60 font-mono text-xs">
                    <span className="font-bold block">{t('dian:rangos_de_numeracion_detectados_en_factus')}</span>
                    <ul className="list-disc pl-5 mt-1 space-y-0.5">
                      {factusTestResult.numberingRanges.map((r: any, idx: number) => (
                        <li key={idx}>
                          {t('dian:prefijo')}{' '}<strong>{r.prefix || t('dian:sin_prefijo')}</strong>{' '}{t('dian:rango_from_to_id_rango_id', { from: r.from, to: r.to, id: r.id })}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* ── TARJETAS EXPLICATIVAS DE COSTOS Y CÓMO EMPEZAR ── */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-2">
              <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-black">
                1
              </div>
              <h4 className="font-bold text-slate-900 text-sm font-heading">{t('dian:cuanto_cuesta_factus')}</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                • <strong>{t('dian:ambiente_de_pruebas')}</strong>{' '}{t('dian:0_cop_gratis_e_ilimitado_para_desarrolladores')}<br />
                • <strong>{t('dian:en_produccion')}</strong>{' '}{t('dian:se_compran_paquetes_de_folios_aprox')}{' '}<strong>{t('dian:150_a_200_cop_por_factura')}</strong>{t('dian:un_paquete_de_100_facturas_cuesta_20')}
              </p>
            </div>

            <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-2">
              <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center font-black">
                2
              </div>
              <h4 className="font-bold text-slate-900 text-sm font-heading">{t('dian:sin_certificado_digital')}</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                {t('dian:factus_esta_autorizado_como')}{' '}<strong>{t('dian:proveedor_tecnologico')}</strong>{' '}{t('dian:ante_la_dian_ellos_firman_todas_las')}{' '}<strong>{t('dian:150_000_cop_anuales')}</strong>{' '}{t('dian:de_certicamara')}
              </p>
            </div>

            <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-2">
              <div className="w-10 h-10 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center font-black">
                3
              </div>
              <h4 className="font-bold text-slate-900 text-sm font-heading">{t('dian:como_empezar')}</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                {t('dian:1_crea_tu_cuenta_en')}{' '}<strong>factus.com.co</strong>.<br />
                {t('dian:2_copia_tu')}{' '}<code>client_id</code> y <code>client_secret</code>{' '}{t('dian:y_pegalos_aqui')}<br />
                {t('dian:3_en_el_portal_de_la_dian')}{' '}<em>{t('dian:modos_de_operacion')}</em>{t('dian:asocia_a')}{' '}<strong>{t('dian:factus')}</strong>{' '}{t('dian:como_proveedor_tecnologico')}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* ── FORMULARIO SOFTWARE PROPIO DIAN (SI SE SELECCIONA DIAN_DIRECT) ── */}
      {config.billingProvider === 'DIAN_DIRECT' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-xs border border-slate-200/80 space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100 flex-wrap gap-3">
            <div>
              <h3 className="text-lg font-bold text-slate-900 font-heading">{t('dian:datos_de_empresa_y_software_propio')}</h3>
              <p className="text-xs text-slate-500">{t('dian:parametros_registrados_en_el_catalogo_de_participa')}</p>
            </div>
            {config.isAssociated && (
              <div className="flex items-center gap-2 bg-emerald-50 text-emerald-700 px-3 py-1.5 rounded-xl border border-emerald-200 text-xs font-bold">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
                <span>{t('dian:software_asociado_en_dian')}</span>
              </div>
            )}
          </div>

          {/* Top bar: Modo de operación y URL de recepción */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                {t('dian:seleccione_el_modo_de_operacion')}
              </label>
              <select
                value={config.operationMode || 'SOFTWARE_PROPIO'}
                onChange={(e) => setConfig({ ...config, operationMode: e.target.value })}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-sm text-slate-900 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 outline-none"
              >
                <option value="SOFTWARE_PROPIO">{t('dian:software_propio')}</option>
                <option value="HABILITACION">{t('dian:habilitacion_dian_set_de_pruebas')}</option>
                <option value="PRODUCCION">{t('dian:produccion_dian_operacion_real')}</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                {t('dian:url_de_recepcion_de_facturas_en_habilitacion')}
              </label>
              <input
                type="text"
                value={config.wsdlUrl || 'https://vpfe-hab.dian.gov.co/WcfDianCustomerServices.svc?wsdl'}
                onChange={(e) => setConfig({ ...config, wsdlUrl: e.target.value })}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono text-slate-800 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 outline-none"
              />
            </div>
          </div>

          {/* Casillas exactas de la captura de la DIAN */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-2">
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider">
                {t('dian:nombre_empresa_proveedora')}
              </label>
              <input
                type="text"
                value={config.providerName || ''}
                onChange={(e) => setConfig({ ...config, providerName: e.target.value })}
                placeholder={t('dian:narvaez_lopez_luis_felipe')}
                className="w-full px-3.5 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 outline-none uppercase"
              />
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider">
                {t('dian:nombre_del_software')}
              </label>
              <input
                type="text"
                value={config.softwareName || ''}
                onChange={(e) => setConfig({ ...config, softwareName: e.target.value })}
                placeholder={t('dian:lantify_pos')}
                className="w-full px-3.5 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 outline-none uppercase"
              />
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider">
                {t('dian:pin_del_sw')}
              </label>
              <input
                type="text"
                value={config.softwarePin || ''}
                onChange={(e) => setConfig({ ...config, softwarePin: e.target.value })}
                placeholder="12345"
                className="w-full px-3.5 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-mono text-slate-900 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 outline-none"
              />
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider">
                {t('dian:id_del_sw')}
              </label>
              <input
                type="text"
                value={config.softwareId || ''}
                onChange={(e) => setConfig({ ...config, softwareId: e.target.value })}
                placeholder="edce5592-1856-407e-acd4-e4269f7333b5"
                className="w-full px-3.5 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-mono text-slate-900 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 outline-none"
              />
            </div>

            <div className="space-y-1.5 sm:col-span-2 lg:col-span-4 bg-emerald-50/60 p-4 rounded-2xl border border-emerald-200/80 mt-2">
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-bold text-emerald-950 uppercase tracking-wider">
                  {t('dian:id_del_set_de_pruebas_testsetid_dian')}
                </label>
                <span className="text-xs font-bold text-emerald-700 bg-emerald-100/70 px-2.5 py-0.5 rounded-full">
                  {t('dian:requerido_para_habilitacion')}
                </span>
              </div>
              <input
                type="text"
                value={config.testSetId || ''}
                onChange={(e) => setConfig({ ...config, testSetId: e.target.value })}
                placeholder="1f64e353-a8ff-488e-b2c2-bc4e05265c92"
                className="w-full px-3.5 py-2.5 bg-white border border-emerald-300 rounded-xl text-xs font-mono font-bold text-emerald-950 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 outline-none"
              />
              <p className="text-xs text-emerald-700/90 mt-1">
                {t('dian:identificador_unico_entregado_por_la_dian_en')}
              </p>
            </div>
          </div>

          {/* Botón verde idéntico al de la DIAN: Asociar */}
          <div className="pt-2 flex items-center justify-between flex-wrap gap-4">
            <button
              type="button"
              onClick={handleAssociate}
              disabled={isAssociating}
              className="px-8 py-2.5 bg-[#00a86b] hover:bg-[#008f5b] active:scale-95 text-white font-bold text-xs rounded-xl shadow-sm transition-all disabled:opacity-50"
            >
              {isAssociating ? t('dian:asociando_con_dian') : t('dian:asociar')}
            </button>
          </div>
        </div>
      )}

      {/* ── SET DE PRUEBAS DE HABILITACIÓN DIAN (SOLO SOFTWARE PROPIO) ──── */}
      {config.billingProvider === 'DIAN_DIRECT' && (
        <div className="bg-gradient-to-br from-indigo-950 via-slate-900 to-indigo-900 rounded-3xl p-6 sm:p-8 text-white shadow-md border border-indigo-800/60 space-y-5">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-indigo-800/50">
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-lg font-bold font-heading text-white">{t('dian:set_de_pruebas_de_habilitacion_dian')}</h3>
                <span className="px-2.5 py-0.5 bg-amber-400/20 text-amber-300 border border-amber-400/30 rounded-full text-xs font-black uppercase">
                  {t('dian:50_documentos_requeridos')}
                </span>
              </div>
              <p className="text-xs text-indigo-200 mt-1 max-w-2xl">
                {t('dian:la_dian_exige_validar_30_facturas_electronicas')}{' '}<strong>{config.prefix || 'SETP'}</strong>{' '}{t('dian:y_rango')}{' '}<strong>{t('dian:990000000_al_995000000')}</strong>{t('dian:pulsa_el_boton_para_que_el_sistema')}
              </p>
            </div>

            <button
              type="button"
              onClick={handleRunTestSet}
              disabled={isRunningTestSet}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 active:scale-95 text-white font-black text-xs rounded-2xl shadow-lg transition-all shrink-0 disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 ${isRunningTestSet ? 'animate-spin' : ''}`} />
              <span>{isRunningTestSet ? t('dian:transmitiendo_set_a_dian') : t('dian:transmitir_set_de_pruebas_a_la_dian')}</span>
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="bg-indigo-900/40 p-3 rounded-xl border border-indigo-700/50">
              <span className="text-xs text-indigo-300 font-bold block uppercase">{t('dian:facturas_exigidas')}</span>
              <span className="text-lg font-black text-white">{t('dian:30_facturas')}</span>
            </div>
            <div className="bg-indigo-900/40 p-3 rounded-xl border border-indigo-700/50">
              <span className="text-xs text-indigo-300 font-bold block uppercase">{t('dian:notas_credito')}</span>
              <span className="text-lg font-black text-white">{t('dian:10_notas')}</span>
            </div>
            <div className="bg-indigo-900/40 p-3 rounded-xl border border-indigo-700/50">
              <span className="text-xs text-indigo-300 font-bold block uppercase">{t('dian:notas_debito')}</span>
              <span className="text-lg font-black text-white">{t('dian:10_notas')}</span>
            </div>
            <div className="bg-indigo-900/40 p-3 rounded-xl border border-indigo-700/50">
              <span className="text-xs text-indigo-300 font-bold block uppercase">{t('dian:testsetid_activo')}</span>
              <span className="text-xs font-mono font-bold text-amber-300 truncate block" title={config.testSetId}>
                {config.testSetId ? `${config.testSetId.slice(0, 8)}...` : t('dian:1f64e353')}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* ── RESOLUCIÓN, PREFIJO Y RANGOS AUTORIZADOS ────────────── */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-xs border border-slate-200/80 space-y-4">
        <h3 className="text-base font-bold text-slate-900 font-heading">{t('dian:resolucion_de_facturacion_y_rangos')}</h3>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-slate-600 uppercase">{t('dian:n_resolucion_dian')}</label>
            <input
              type="text"
              value={config.resolutionNumber || ''}
              onChange={(e) => setConfig({ ...config, resolutionNumber: e.target.value })}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900"
            />
          </div>

          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-slate-600 uppercase">{t('dian:prefijo_autorizado')}</label>
            <input
              type="text"
              value={config.prefix || 'SETP'}
              onChange={(e) => setConfig({ ...config, prefix: e.target.value.toUpperCase() })}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 uppercase"
            />
          </div>

          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-slate-600 uppercase">{t('dian:consecutivo_actual')}</label>
            <input
              type="number"
              value={config.currentNumber || 1}
              onChange={(e) => setConfig({ ...config, currentNumber: parseInt(e.target.value) || 1 })}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 font-mono"
            />
          </div>

          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-slate-600 uppercase">{t('dian:rango_autorizado')}</label>
            <div className="flex items-center gap-2">
              <input
                type="number"
                value={config.rangeFrom || 1}
                onChange={(e) => setConfig({ ...config, rangeFrom: parseInt(e.target.value) || 1 })}
                className="w-1/2 px-2.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono text-center text-slate-900"
              />
              <span className="text-slate-400 text-xs">{t('dian:al')}</span>
              <input
                type="number"
                value={config.rangeTo || 100000}
                onChange={(e) => setConfig({ ...config, rangeTo: parseInt(e.target.value) || 1 })}
                className="w-1/2 px-2.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono text-center text-slate-900"
              />
            </div>
          </div>
        </div>

        <div className="pt-2">
          <label className="block text-xs font-bold text-slate-600 uppercase mb-1">{t('dian:clave_tecnica_dian')}</label>
          <input
            type="password"
            value={config.technicalKey || ''}
            onChange={(e) => setConfig({ ...config, technicalKey: e.target.value })}
            className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono text-slate-900"
          />
        </div>
      </div>

      {/* ── MONITOR DE COLA DE FACTURACIÓN (OFFLINE-FIRST) ────────── */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-xs border border-slate-200/80 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <h3 className="text-base font-bold text-slate-900 font-heading">{t('dian:monitor_de_facturas_electronicas_y_cola_de')}</h3>
            <p className="text-xs text-slate-500">{t('dian:historial_completo_con_cufe_oficial_sha_384')}</p>
          </div>

          <div className="flex items-center gap-2">
            {[
              { id: 'ALL', label: t('dian:todas') },
              { id: 'PENDING_QUEUE', label: t('dian:en_cola') },
              { id: 'ACCEPTED', label: t('dian:aceptadas_dian') },
              { id: 'REJECTED', label: t('dian:rechazadas') }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveFilter(tab.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  activeFilter === tab.id
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200/80'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Tabla de Facturas */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 text-xs font-bold uppercase tracking-wider text-slate-500">
                <th className="py-3 px-3">{t('dian:factura')}</th>
                <th className="py-3 px-3">{t('dian:fecha')}</th>
                <th className="py-3 px-3">{t('dian:adquiriente_nit')}</th>
                <th className="py-3 px-3">{t('dian:total')}</th>
                <th className="py-3 px-3">{t('dian:estado_dian')}</th>
                <th className="py-3 px-3 text-right">{t('dian:acciones')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {filteredInvoices.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center py-8 text-slate-400">
                    {t('dian:no_hay_facturas_registradas_en_este_estado')}
                  </td>
                </tr>
              ) : (
                filteredInvoices.map((inv) => (
                  <tr key={inv.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-3 font-mono font-bold text-slate-900">
                      {inv.invoiceNumber}
                    </td>
                    <td className="py-3 px-3 text-slate-500 whitespace-nowrap">
                      {new Date(inv.issueDate || inv.createdAt).toLocaleString(getLocale(), {
                        dateStyle: 'short',
                        timeStyle: 'short'
                      })}
                    </td>
                    <td className="py-3 px-3">
                      <div className="font-bold text-slate-800">{inv.customerName}</div>
                      <div className="text-xs font-mono text-slate-400">{t('dian:nit')}{' '}{inv.customerNit}</div>
                    </td>
                    <td className="py-3 px-3 font-bold text-slate-900">
                      {formatCurrency(inv.total)}
                    </td>
                    <td className="py-3 px-3">
                      {inv.status === 'ACCEPTED' && (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          {t('dian:aceptada_dian')}
                        </span>
                      )}
                      {inv.status === 'PENDING_QUEUE' && (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-50 text-amber-700 border border-amber-200">
                          <Clock className="w-3 h-3 text-amber-600" />
                          {t('dian:en_cola_offline')}
                        </span>
                      )}
                      {inv.status === 'TRANSMITTING' && (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200">
                          <RefreshCw className="w-3 h-3 text-blue-600 animate-spin" />
                          {t('dian:transmitiendo_2')}
                        </span>
                      )}
                      {inv.status === 'REJECTED' && (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-red-50 text-red-700 border border-red-200">
                          <AlertCircle className="w-3 h-3 text-red-600" />
                          {t('dian:rechazada')}
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-3 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => setSelectedCufe(inv.cufe)}
                          title={t('dian:ver_y_copiar_cufe')}
                          className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
                        >
                          <Copy className="w-4 h-4" />
                        </button>

                        <a
                          href={dianAPI.getXmlUrl(inv.id)}
                          download={`${inv.invoiceNumber}.xml`}
                          title={t('dian:descargar_xml_ubl_2_1')}
                          className="p-1.5 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded-lg transition-colors"
                        >
                          <Download className="w-4 h-4" />
                        </a>

                        {inv.publicUrl && (
                          <a
                            href={inv.publicUrl}
                            target="_blank"
                            rel="noreferrer"
                            title={t('dian:ver_factura_pdf_en_factus_cloud')}
                            className="p-1.5 text-emerald-600 hover:text-emerald-800 hover:bg-emerald-50 rounded-lg transition-colors"
                          >
                            <ExternalLink className="w-4 h-4" />
                          </a>
                        )}

                        {inv.status !== 'ACCEPTED' && (
                          <button
                            onClick={() => handleRetryInvoice(inv.id)}
                            title={t('dian:reintentar_transmision')}
                            className="p-1.5 text-emerald-600 hover:text-emerald-800 hover:bg-emerald-50 rounded-lg transition-colors"
                          >
                            <Send className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal visor de CUFE */}
      {selectedCufe && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-100 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h4 className="font-bold text-slate-900 text-sm">{t('dian:cufe_oficial_sha_384')}</h4>
              <button
                onClick={() => setSelectedCufe(null)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold"
              >
                ✕
              </button>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <p className="font-mono text-xs break-all text-slate-800 select-all">{selectedCufe}</p>
            </div>
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => {
                  navigator.clipboard.writeText(selectedCufe);
                  setCopiedCufe(true);
                  setTimeout(() => setCopiedCufe(false), 2000);
                }}
                className="px-4 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold flex items-center gap-2"
              >
                {copiedCufe ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                <span>{copiedCufe ? t('dian:copiado_2') : t('dian:copiar_cufe')}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
