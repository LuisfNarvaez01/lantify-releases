// ============================================
// INFRASTRUCTURE - Sale Repository Implementation
// ============================================

import { PrismaClient, Sale, SaleItem, SaleStatus } from '@prisma/client';
import { ISaleRepository } from '../../../domain/repositories/ISaleRepository';

export class SaleRepository implements ISaleRepository {
  constructor(private prisma: PrismaClient) {}

  async create(data: Omit<Sale, 'id' | 'createdAt' | 'updatedAt' | 'saleNumber'>): Promise<Sale> {
    const now = new Date();
    const saleNumber = `SALE-${now.getFullYear()}${(now.getMonth() + 1).toString().padStart(2, '0')}${now.getDate().toString().padStart(2, '0')}-${Math.floor(Math.random() * 10000).toString().padStart(4, '0')}`;
    
    return this.prisma.sale.create({
      data: { ...data, saleNumber },
      include: { 
        items: { 
          include: { 
            productVariant: { 
              include: { 
                product: true 
              } 
            } 
          } 
        },
        table: true,
        customer: true,
      },
    });
  }

  async getById(id: string): Promise<Sale | null> {
    return this.prisma.sale.findUnique({
      where: { id },
      include: { 
        items: { 
          include: { 
            productVariant: { 
              include: { 
                product: true 
              } 
            } 
          } 
        },
        table: true,
        customer: true,
      },
    });
  }

  async getAll(): Promise<Sale[]> {
    return this.prisma.sale.findMany({
      include: { 
        items: { 
          include: { 
            productVariant: { 
              include: { 
                product: true 
              } 
            } 
          } 
        },
        table: true,
        customer: true,
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getByDateRange(startDate: Date, endDate: Date): Promise<Sale[]> {
    return this.prisma.sale.findMany({
      where: {
        createdAt: { gte: startDate, lte: endDate },
      },
      include: { 
        items: { 
          include: { 
            productVariant: { 
              include: { 
                product: true 
              } 
            } 
          } 
        },
        table: true,
        customer: true,
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getByTable(tableId: string): Promise<Sale[]> {
    return this.prisma.sale.findMany({
      where: { tableId },
      include: { 
        items: { 
          include: { 
            productVariant: { 
              include: { 
                product: true 
              } 
            } 
          } 
        },
        table: true,
        customer: true,
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getByCashSession(cashSessionId: string): Promise<Sale[]> {
    return this.prisma.sale.findMany({
      where: { cashSessionId },
      include: { 
        items: { 
          include: { 
            productVariant: { 
              include: { 
                product: true 
              } 
            } 
          } 
        },
        table: true,
        customer: true,
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getByStatus(status: SaleStatus): Promise<Sale[]> {
    return this.prisma.sale.findMany({
      where: { status },
      include: { 
        items: { 
          include: { 
            productVariant: { 
              include: { 
                product: true 
              } 
            } 
          } 
        },
        table: true,
        customer: true,
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async update(id: string, data: Partial<Sale>): Promise<Sale> {
    return this.prisma.sale.update({
      where: { id },
      data,
      include: { 
        items: { 
          include: { 
            productVariant: { 
              include: { 
                product: true 
              } 
            } 
          } 
        },
        table: true,
        customer: true,
      },
    });
  }

  async updateStatus(id: string, status: SaleStatus): Promise<Sale> {
    return this.prisma.sale.update({
      where: { id },
      data: { status },
      include: { 
        items: { 
          include: { 
            productVariant: { 
              include: { 
                product: true 
              } 
            } 
          } 
        },
        table: true,
        customer: true,
      },
    });
  }

  async delete(id: string): Promise<void> {
    await this.prisma.sale.delete({ where: { id } });
  }

  // SaleItem
  async createItem(data: Omit<SaleItem, 'id' | 'createdAt'>): Promise<SaleItem> {
    return this.prisma.saleItem.create({ data });
  }

  async getItemsBySale(saleId: string): Promise<SaleItem[]> {
    return this.prisma.saleItem.findMany({
      where: { saleId },
      include: { productVariant: true },
    });
  }

  async deleteItem(id: string): Promise<void> {
    await this.prisma.saleItem.delete({ where: { id } });
  }

  // Aggregations
  async getTotalSalesByDate(date: Date): Promise<number> {
    const startOfDay = new Date(date.setHours(0, 0, 0, 0));
    const endOfDay = new Date(date.setHours(23, 59, 59, 999));

    const result = await this.prisma.sale.aggregate({
      where: {
        createdAt: { gte: startOfDay, lte: endOfDay },
        status: 'COMPLETED',
      },
      _sum: { total: true },
    });

    return result._sum.total ?? 0;
  }

  async getDailySalesSummary(date: Date): Promise<{ count: number; total: number }> {
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);

    const result = await this.prisma.sale.aggregate({
      where: {
        createdAt: { gte: startOfDay, lte: endOfDay },
        status: 'COMPLETED',
      },
      _count: true,
      _sum: { total: true },
    });

    return {
      count: result._count,
      total: result._sum.total ?? 0,
    };
  }

  // ============================================
  // PAGINACIÓN POR MES — Para el historial rápido
  // No modifica ningún método existente
  // ============================================

  async getAvailableMonths(): Promise<{ year: number; month: number; label: string; count: number; totalRevenue: number }[]> {
    const sales = await this.prisma.sale.findMany({
      select: { createdAt: true, total: true, status: true },
      orderBy: { createdAt: 'desc' },
    });

    const monthMap = new Map<string, { year: number; month: number; count: number; totalRevenue: number }>();
    const MESES = [
      'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
      'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
    ];

    for (const sale of sales) {
      const d = new Date(sale.createdAt);
      const year = d.getFullYear();
      const month = d.getMonth() + 1;
      const key = `${year}-${String(month).padStart(2, '0')}`;
      const rev = sale.status === 'COMPLETED' ? (sale.total ?? 0) : 0;

      if (monthMap.has(key)) {
        const item = monthMap.get(key)!;
        item.count++;
        item.totalRevenue += rev;
      } else {
        monthMap.set(key, { year, month, count: 1, totalRevenue: rev });
      }
    }

    return Array.from(monthMap.entries())
      .sort((a, b) => b[0].localeCompare(a[0]))
      .map(([, v]) => ({
        year: v.year,
        month: v.month,
        label: `${MESES[v.month - 1]} ${v.year}`,
        count: v.count,
        totalRevenue: v.totalRevenue,
      }));
  }

  async getByMonth(
    year: number,
    month: number,
    page: number = 1,
    limit: number = 50,
    filters?: { cashSessionId?: string; status?: string }
  ): Promise<{
    data: Sale[];
    total: number;
    page: number;
    totalPages: number;
    stats: {
      totalRevenue: number;
      completedCount: number;
      cancelledCount: number;
      totalItems: number;
      avgTicket: number;
      totalTips: number;
      paymentBreakdown: {
        CASH: number;
        CARD: number;
        TRANSFER: number;
        MIXED: number;
      };
    };
  }> {
    const where: any = {};

    // Si year y month son válidos (>0), filtramos por la fecha de ese mes
    if (year > 0 && month > 0) {
      const startDate = new Date(year, month - 1, 1, 0, 0, 0, 0);
      const endDate   = new Date(year, month, 0, 23, 59, 59, 999);
      where.createdAt = { gte: startDate, lte: endDate };
    }

    if (filters?.cashSessionId) where.cashSessionId = filters.cashSessionId;
    if (filters?.status)        where.status = filters.status;

    // Clausula para ventas completadas en este filtro
    const completedWhere = { ...where, status: 'COMPLETED' };

    const [
      total,
      data,
      aggregateCompleted,
      aggregateCancelled,
      totalItemsAggregate,
      cashSales,
      cardSales,
      transferSales,
      mixedSales
    ] = await Promise.all([
      this.prisma.sale.count({ where }),
      this.prisma.sale.findMany({
        where,
        include: {
          items: {
            include: {
              productVariant: {
                include: { product: true }
              }
            }
          },
          table: true,
          customer: true,
        },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      this.prisma.sale.aggregate({
        where: completedWhere,
        _sum: { total: true, tip: true },
        _count: true,
      }),
      this.prisma.sale.count({
        where: { ...where, status: 'CANCELLED' },
      }),
      this.prisma.saleItem.aggregate({
        where: {
          sale: completedWhere,
          isCancelled: false,
        },
        _sum: { quantity: true },
      }),
      this.prisma.sale.aggregate({
        where: { ...completedWhere, paymentMethod: 'CASH' },
        _sum: { total: true },
      }),
      this.prisma.sale.aggregate({
        where: { ...completedWhere, paymentMethod: 'CARD' },
        _sum: { total: true },
      }),
      this.prisma.sale.aggregate({
        where: { ...completedWhere, paymentMethod: 'TRANSFER' },
        _sum: { total: true },
      }),
      this.prisma.sale.aggregate({
        where: { ...completedWhere, paymentMethod: 'MIXED' },
        _sum: { total: true },
      }),
    ]);

    const totalRevenue   = aggregateCompleted._sum.total ?? 0;
    const completedCount = aggregateCompleted._count ?? 0;
    const cancelledCount = aggregateCancelled ?? 0;
    const totalItems     = totalItemsAggregate._sum.quantity ?? 0;
    const avgTicket      = completedCount > 0 ? totalRevenue / completedCount : 0;

    return {
      data: data as Sale[],
      total,
      page,
      totalPages: Math.ceil(total / limit) || 1,
      stats: {
        totalRevenue,
        completedCount,
        cancelledCount,
        totalItems,
        avgTicket,
        totalTips: aggregateCompleted._sum.tip ?? 0,
        paymentBreakdown: {
          CASH:     cashSales._sum.total ?? 0,
          CARD:     cardSales._sum.total ?? 0,
          TRANSFER: transferSales._sum.total ?? 0,
          MIXED:    mixedSales._sum.total ?? 0,
        },
      },
    };
  }
}