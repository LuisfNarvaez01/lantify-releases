// ============================================
// APPLICATION USE CASES - ExpenseCategory Use Cases
// ============================================

import { prisma } from '../../infrastructure/database/prisma';

const DEFAULT_CATEGORIES = [
  { name: 'Aseo', color: '#3b82f6', description: 'Productos de limpieza y aseo' },
  { name: 'Hielo', color: '#06b6d4', description: 'Compra de hielo' },
  { name: 'Insumos', color: '#f59e0b', description: 'Insumos y materiales' },
  { name: 'Servicios', color: '#8b5cf6', description: 'Servicios públicos y otros' },
  { name: 'Transporte', color: '#f97316', description: 'Gastos de transporte' },
  { name: 'Otros', color: '#6b7280', description: 'Otros gastos' },
];

export class ExpenseCategoryUseCases {

  async getAll() {
    return prisma.expenseCategory.findMany({
      where: { isActive: true },
      orderBy: { name: 'asc' },
      include: { _count: { select: { expenses: true } } }
    });
  }

  async create(data: { name: string; description?: string; color?: string }) {
    if (!data.name) throw new Error('El nombre de la categoría es obligatorio');
    return prisma.expenseCategory.create({ data });
  }

  async update(id: string, data: { name?: string; description?: string; color?: string }) {
    return prisma.expenseCategory.update({ where: { id }, data });
  }

  async deactivate(id: string) {
    return prisma.expenseCategory.update({ where: { id }, data: { isActive: false } });
  }

  async ensureDefaults() {
    for (const cat of DEFAULT_CATEGORIES) {
      const existing = await prisma.expenseCategory.findUnique({ where: { name: cat.name } });
      if (!existing) {
        await prisma.expenseCategory.create({ data: cat });
      }
    }
  }
}
