' ============================================================
' Lantify POS - Iniciador Silencioso en Segundo Plano
' Ejecuta el backend y frontend sin ventanas de consola visibles
' ============================================================
Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
currentDir = fso.GetParentFolderName(WScript.ScriptFullName)

' Iniciar backend en segundo plano oculto (0 = ventana oculta)
WshShell.Run "cmd /c cd """ & currentDir & """ && npm run dev", 0, False

' Iniciar frontend en segundo plano oculto (0 = ventana oculta)
WshShell.Run "cmd /c cd """ & currentDir & "\frontend"" && npm run dev", 0, False

' Esperar 3.5 segundos para que los servicios inicialicen
WScript.Sleep 3500

' Abrir el navegador en la interfaz de Lantify POS
WshShell.Run "http://localhost:5173"
