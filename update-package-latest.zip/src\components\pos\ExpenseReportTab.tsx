// ============================================
// COMPONENTS - Expense Report Tab (Arqueo & Gastos)
// ============================================

import React, { useState, useMemo } from 'react';
import {
  TrendingDown, FileSpreadsheet, Search,
  Layers, Tag, DollarSign,
  CheckCircle2, XCircle
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { formatCurrency } from '../../shared/formatUtils';

import { t, getLocale } from '../../i18n';
interface ExpenseItem {
  id: string;
  cashSessionId: string;
  amount: number;
  motive: string;
  description?: string;
  categoryId?: string;
  category?: { id: string; name: string; color?: string };
  paymentSource?: string;
  isCancelled?: boolean;
  cancellationReason?: string;
  createdAt: string;
  sessionNumber?: string;
}

interface ExpenseReportTabProps {
  sessions: any[];
  selectedMonth: string; // e.g. "2026-09"
  config?: any;
}

export const ExpenseReportTab: React.FC<ExpenseReportTabProps> = ({
  sessions,
  selectedMonth,
  config = {}
}) => {
  const [selectedSessionId, setSelectedSessionId] = useState<string>('all');
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [includeCancelled, setIncludeCancelled] = useState<boolean>(false);

  // 1. Extraer todos los gastos de las sesiones del mes seleccionado (o todas si no hay seleccionado)
  const monthSessions = useMemo(() => {
    if (!selectedMonth) return sessions;
    return sessions.filter((s: any) => {
      const date = new Date(s.openedAt);
      const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      return key === selectedMonth;
    });
  }, [sessions, selectedMonth]);

  // Lista de todos los gastos con metadata de sesión
  const allExpenses: ExpenseItem[] = useMemo(() => {
    const list: ExpenseItem[] = [];
    monthSessions.forEach((sess: any) => {
      (sess.expensesDetails ?? []).forEach((exp: any) => {
        list.push({
          ...exp,
          sessionNumber: sess.sessionNumber || t('cash:s_n')
        });
      });
    });
    return list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [monthSessions]);

  // Categorías únicas encontradas
  const availableCategories = useMemo(() => {
    const map = new Map<string, { id: string; name: string; color?: string }>();
    allExpenses.forEach(exp => {
      if (exp.category) {
        map.set(exp.category.id, exp.category);
      } else if (exp.categoryId) {
        map.set(exp.categoryId, { id: exp.categoryId, name: t('cash:categoria') + exp.categoryId.slice(0, 6) });
      }
    });
    return Array.from(map.values());
  }, [allExpenses]);

  // 2. Filtrado interactivo
  const filteredExpenses = useMemo(() => {
    return allExpenses.filter(exp => {
      // Filtro por sesión
      if (selectedSessionId !== 'all' && exp.cashSessionId !== selectedSessionId) {
        return false;
      }
      // Filtro por categoría
      if (selectedCategoryId !== 'all') {
        if (selectedCategoryId === 'uncategorized') {
          if (exp.categoryId || exp.category) return false;
        } else {
          if (exp.categoryId !== selectedCategoryId && exp.category?.id !== selectedCategoryId) {
            return false;
          }
        }
      }
      // Filtro anulados
      if (!includeCancelled && exp.isCancelled) {
        return false;
      }
      // Búsqueda de texto
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase();
        const motiveMatch = exp.motive?.toLowerCase().includes(q);
        const descMatch = exp.description?.toLowerCase().includes(q);
        const catMatch = exp.category?.name?.toLowerCase().includes(q);
        const sessMatch = exp.sessionNumber?.toLowerCase().includes(q);
        if (!motiveMatch && !descMatch && !catMatch && !sessMatch) {
          return false;
        }
      }
      return true;
    });
  }, [allExpenses, selectedSessionId, selectedCategoryId, includeCancelled, searchTerm]);

  // 3. Métricas y KPIs
  const metrics = useMemo(() => {
    const activeItems = filteredExpenses.filter(e => !e.isCancelled);
    const totalAmount = activeItems.reduce((acc, curr) => acc + (curr.amount || 0), 0);
    const count = activeItems.length;
    const avg = count > 0 ? totalAmount / count : 0;

    // Desglose por categoría
    const catMap = new Map<string, { name: string; total: number; count: number; color?: string }>();
    activeItems.forEach(exp => {
      const catKey = exp.category?.id || exp.categoryId || 'uncategorized';
      const catName = exp.category?.name || t('cash:sin_categoria');
      const catColor = exp.category?.color || '#2563eb';

      const existing = catMap.get(catKey) || { name: catName, total: 0, count: 0, color: catColor };
      existing.total += exp.amount || 0;
      existing.count += 1;
      catMap.set(catKey, existing);
    });

    const categoryBreakdown = Array.from(catMap.entries()).map(([id, data]) => ({
      id,
      name: data.name,
      total: data.total,
      count: data.count,
      color: data.color,
      pct: totalAmount > 0 ? (data.total / totalAmount) * 100 : 0
    })).sort((a, b) => b.total - a.total);

    const topCategory = categoryBreakdown.length > 0 ? categoryBreakdown[0] : null;

    return {
      totalAmount,
      count,
      avg,
      categoryBreakdown,
      topCategory,
      cancelledCount: filteredExpenses.filter(e => e.isCancelled).length
    };
  }, [filteredExpenses]);

  // 4. Exportar a Excel (.xlsx)
  const handleExportExcel = () => {
    const businessName = config.businessName || t('cash:lantify_pos');
    const periodName = selectedMonth || t('cash:todos_los_periodos');

    // Hoja 1: Resumen por Categoría
    const summaryRows = [
      [t('cash:informe_de_gastos_resumen_por_categoria')],
      [t('cash:negocio_businessname', { businessName })],
      [t('cash:periodo_periodname', { periodName })],
      [t('cash:generado_value', { value: new Date().toLocaleString(getLocale()) })],
      [],
      [t('cash:categoria_2'), t('cash:cantidad_de_gastos'), t('cash:total_gastado_cop'), t('cash:de_participacion')],
      ...metrics.categoryBreakdown.map(c => [
        c.name,
        c.count,
        c.total,
        `${c.pct.toFixed(1)}%`
      ]),
      [],
      [t('cash:total_general'), metrics.count, metrics.totalAmount, '100%']
    ];

    // Hoja 2: Detalle de Gastos
    const detailRows = [
      [t('cash:informe_de_gastos_detalle_individual')],
      [t('cash:negocio_businessname', { businessName })],
      [t('cash:periodo_periodname', { periodName })],
      [t('cash:generado_value', { value: new Date().toLocaleString(getLocale()) })],
      [],
      [t('cash:fecha_y_hora'), t('cash:arqueo'), t('cash:categoria_2'), t('cash:motivo'), t('cash:descripcion'), t('cash:monto_cop'), t('cash:estado')],
      ...filteredExpenses.map(exp => [
        new Date(exp.createdAt).toLocaleString(getLocale()),
        exp.sessionNumber || t('cash:s_n'),
        exp.category?.name || t('cash:sin_categoria'),
        exp.motive || '',
        exp.description || '',
        exp.isCancelled ? 0 : exp.amount,
        exp.isCancelled ? `ANULADO (${exp.cancellationReason || t('cash:s_m')})` : t('cash:valido')
      ]),
      [],
      [t('cash:total_valido'), '', '', '', '', metrics.totalAmount, '']
    ];

    const wb = XLSX.utils.book_new();

    const wsSummary = XLSX.utils.aoa_to_sheet(summaryRows);
    wsSummary['!cols'] = [{ wch: 30 }, { wch: 20 }, { wch: 22 }, { wch: 20 }];
    XLSX.utils.book_append_sheet(wb, wsSummary, 'Resumen por Categoría');

    const wsDetail = XLSX.utils.aoa_to_sheet(detailRows);
    wsDetail['!cols'] = [
      { wch: 22 }, { wch: 18 }, { wch: 22 }, { wch: 28 }, { wch: 35 }, { wch: 18 }, { wch: 20 }
    ];
    XLSX.utils.book_append_sheet(wb, wsDetail, 'Detalle de Gastos');

    const fileName = `Informe_Gastos_${periodName.replace('-', '_')}_${Date.now()}.xlsx`;
    XLSX.writeFile(wb, fileName);
  };

  return (
    <div className="space-y-6">
      {/* Barra de Filtros y Acción de Exportación */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-50 flex items-center justify-center text-rose-600">
              <TrendingDown className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-black text-slate-900">{t('cash:informe_detallado_de_gastos')}</h3>
              <p className="text-xs text-slate-500">
                {t('cash:analisis_y_desglose_de_egresos_registrados_en')}
              </p>
            </div>
          </div>

          <button
            onClick={handleExportExcel}
            className="flex items-center justify-center gap-2 px-6 py-3 rounded-2xl font-black text-white text-sm shadow-sm shadow-emerald-600/20 bg-emerald-600 hover:bg-emerald-700 active:scale-[0.98] transition-all"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>{t('cash:exportar_excel_xlsx')}</span>
          </button>
        </div>

        {/* Controles de Filtro */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2 border-t border-slate-100">
          {/* Arqueo específico */}
          <div className="space-y-1">
            <label className="text-xs font-black uppercase tracking-wider text-slate-500">
              {t('cash:arqueo_sesion')}
            </label>
            <select
              value={selectedSessionId}
              onChange={(e) => setSelectedSessionId(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none transition-all"
            >
              <option value="all">{t('cash:todos_los_arqueos_length', { length: monthSessions.length })}</option>
              {monthSessions.map((s: any) => (
                <option key={s.id} value={s.id}>
                  {s.sessionNumber || t('cash:sesion')} ({new Date(s.openedAt).toLocaleDateString(getLocale())})
                </option>
              ))}
            </select>
          </div>

          {/* Categoría */}
          <div className="space-y-1">
            <label className="text-xs font-black uppercase tracking-wider text-slate-500">
              {t('cash:categoria_2')}
            </label>
            <select
              value={selectedCategoryId}
              onChange={(e) => setSelectedCategoryId(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none transition-all"
            >
              <option value="all">{t('cash:todas_las_categorias')}</option>
              <option value="uncategorized">{t('cash:sin_categoria')}</option>
              {availableCategories.map(c => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Buscador */}
          <div className="space-y-1">
            <label className="text-xs font-black uppercase tracking-wider text-slate-500">
              {t('cash:buscar_en_motivo_nota')}
            </label>
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder={t('cash:ej_mercado_luz_bolsas')}
                className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none transition-all"
              />
            </div>
          </div>

          {/* Checkbox Anulados */}
          <div className="flex items-center gap-2 pt-6">
            <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-slate-700 select-none">
              <input
                type="checkbox"
                checked={includeCancelled}
                onChange={(e) => setIncludeCancelled(e.target.checked)}
                className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-slate-300"
              />
              <span>{t('cash:incluir_anulados_cancelledcount', { cancelledCount: metrics.cancelledCount })}</span>
            </label>
          </div>
        </div>
      </div>

      {/* KPI Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Gastos */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl text-white shadow-xl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-black uppercase tracking-widest text-blue-400">{t('cash:total_gastos')}</span>
            <DollarSign className="w-4 h-4 text-blue-400" />
          </div>
          <p className="text-2xl font-black tabular-nums">{formatCurrency(metrics.totalAmount)}</p>
          <p className="text-xs text-slate-400 mt-1 font-medium">
            {t('cash:count_transacciones_validas', { count: metrics.count })}
          </p>
        </div>

        {/* Cantidad de Gastos */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-stone-500 mb-2">
            <span className="text-xs font-black uppercase tracking-widest">{t('cash:transacciones')}</span>
            <Layers className="w-4 h-4 text-amber-600" />
          </div>
          <p className="text-2xl font-black text-stone-800">{metrics.count}</p>
          <p className="text-xs text-stone-400 mt-1 font-medium">
            {t('cash:registros_en_este_filtro')}
          </p>
        </div>

        {/* Promedio por Gasto */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-black uppercase tracking-widest">{t('cash:gasto_promedio')}</span>
            <TrendingDown className="w-4 h-4 text-rose-500" />
          </div>
          <p className="text-2xl font-black text-rose-700 tabular-nums">{formatCurrency(metrics.avg)}</p>
          <p className="text-xs text-slate-400 mt-1 font-medium">
            {t('cash:por_registro_activo')}
          </p>
        </div>

        {/* Categoría Mayor Gasto */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-black uppercase tracking-widest">{t('cash:mayor_categoria')}</span>
            <Tag className="w-4 h-4 text-indigo-500" />
          </div>
          <p className="text-lg font-black text-slate-800 truncate">
            {metrics.topCategory ? metrics.topCategory.name : t('cash:n_a')}
          </p>
          <p className="text-xs text-slate-500 mt-1 font-medium">
            {metrics.topCategory ? `${formatCurrency(metrics.topCategory.total)} (${metrics.topCategory.pct.toFixed(0)}%)` : t('cash:sin_datos')}
          </p>
        </div>
      </div>

      {/* Desglose por Categoría con Barras */}
      {metrics.categoryBreakdown.length > 0 && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
          <h4 className="text-sm font-black text-slate-900 uppercase tracking-wider">
            {t('cash:distribucion_de_gastos_por_categoria')}
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {metrics.categoryBreakdown.map((cat) => (
              <div key={cat.id} className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="flex items-center justify-between text-xs font-bold">
                  <div className="flex items-center gap-2">
                    <span
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: cat.color || '#2563eb' }}
                    />
                    <span className="text-slate-800 font-extrabold">{cat.name}</span>
                    <span className="text-xs font-medium text-slate-400">{t('cash:count_reg', { count: cat.count })}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-rose-700 font-black tabular-nums">{formatCurrency(cat.total)}</span>
                    <span className="text-slate-400 ml-1 text-xs tabular-nums">({cat.pct.toFixed(1)}%)</span>
                  </div>
                </div>
                {/* Progress bar */}
                <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${Math.min(100, Math.max(2, cat.pct))}%`,
                      backgroundColor: cat.color || '#2563eb'
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tabla Detallada de Gastos */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h4 className="font-black text-slate-900">{t('cash:lista_detallada_de_egresos')}</h4>
            <p className="text-xs text-slate-500">
              {t('cash:length_egresos_encontrados_en_el_periodo', { length: filteredExpenses.length })}
            </p>
          </div>
        </div>

        {filteredExpenses.length === 0 ? (
          <div className="p-12 text-center text-slate-400">
            <TrendingDown className="w-8 h-8 mx-auto mb-2 opacity-30" />
            <p className="font-bold text-sm">{t('cash:no_se_encontraron_egresos_con_los_filtros')}</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-xs uppercase font-black tracking-wider text-slate-600">
                <tr>
                  <th className="py-3 px-4">{t('cash:fecha_arqueo')}</th>
                  <th className="py-3 px-4">{t('cash:categoria_2')}</th>
                  <th className="py-3 px-4">{t('cash:motivo')}</th>
                  <th className="py-3 px-4">{t('cash:descripcion')}</th>
                  <th className="py-3 px-4 text-right">{t('cash:monto')}</th>
                  <th className="py-3 px-4 text-center">{t('cash:estado')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredExpenses.map((exp) => (
                  <tr
                    key={exp.id}
                    className={`hover:bg-slate-50 transition-colors ${
                      exp.isCancelled ? 'opacity-50 bg-slate-50/50' : ''
                    }`}
                  >
                    <td className="py-3 px-4">
                      <p className="font-bold text-stone-800">
                        {new Date(exp.createdAt).toLocaleDateString(getLocale(), {
                          day: '2-digit',
                          month: 'short',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </p>
                      <span className="text-xs font-semibold text-stone-400">
                        {t('cash:arqueo_sessionnumber', { sessionNumber: exp.sessionNumber })}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      {exp.category ? (
                        <span
                          className="px-2.5 py-1 rounded-xl text-xs font-bold inline-block"
                          style={{
                            backgroundColor: (exp.category.color || '#2563eb') + '18',
                            color: exp.category.color || '#2563eb'
                          }}
                        >
                          {exp.category.name}
                        </span>
                      ) : (
                        <span className="text-stone-400 italic text-xs">{t('cash:sin_categoria')}</span>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      <p className={`font-bold ${exp.isCancelled ? 'line-through text-stone-400' : 'text-stone-800'}`}>
                        {exp.motive}
                      </p>
                      {exp.paymentSource && exp.paymentSource !== 'CASH_DRAWER' && (
                        <p className="text-xs font-semibold text-slate-500">{t(`expenses:fuente_${exp.paymentSource}`)} · {t('expenses:no_sale_del_cajon')}</p>
                      )}
                    </td>
                    <td className="py-3 px-4 text-stone-500 max-w-xs truncate">
                      {exp.description || '—'}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <span className={`font-black text-sm ${exp.isCancelled ? 'text-stone-400 line-through' : 'text-rose-700'}`}>
                        -{formatCurrency(exp.amount)}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center">
                      {exp.isCancelled ? (
                        <span className="inline-flex items-center gap-1 text-xs font-bold text-red-600 bg-red-50 px-2 py-0.5 rounded-full">
                          <XCircle className="w-3 h-3" />
                          {t('cash:anulado')}
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
                          <CheckCircle2 className="w-3 h-3" />
                          {t('cash:valido_2')}
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default ExpenseReportTab;
