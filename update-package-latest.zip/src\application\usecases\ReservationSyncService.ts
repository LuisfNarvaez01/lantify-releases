// ============================================
// APPLICATION - Mi página y reservas en línea ⇄ Lantify Cloud
// ============================================
// Publicar: la página lantifypos.dpdns.org/m/<slug> con la carta (productos
// activos), el perfil, el juego y sus premios, las mesas reservables y el horario.
// Se vuelve a publicar sola si algo cambia (huella), p. ej. un precio.
// Sincronizar (cada minuto y tras cada cambio en la caja):
//   · sube las reservas de la caja SIN datos personales (mesa, horas, estado),
//   · trae las de la página (nuevas o canceladas por el cliente) y las agenda aquí;
//     el cliente que reservó queda en Clientes con su autorización de datos,
//   · trae quienes se registraron en la página (Clientes) y los premios que ganaron
//     (Cupones de un solo uso a su nombre); quien pide borrar sus datos, se borra aquí.
// Sin internet no pasa nada: la caja sigue funcionando y se pone al día al volver.

import crypto from 'crypto';
import { prisma } from '../../infrastructure/database/prisma';
import { cloudConfig } from '../../shared/cloud/config';
import { allStoredLicenses, storedLicenseFor } from '../../shared/cloud/license';
import { normalizeBooking } from '../../domain/booking';
import { normalizePageConfig, normalizePhone } from '../../domain/businessPage';
import { CloudAuthService } from './CloudAuthService';
import { slugify } from './ReservationUseCases';
import { PageUseCases, birthDateFrom } from './PageUseCases';
import { OnlineOrderUseCases } from './OnlineOrderUseCases';

const SETTINGS_ID = 'default';
const TICK_MS = 60_000;

export interface PublishResult {
  ok: boolean;
  code?: 'NOT_LINKED' | 'OFFLINE' | 'SLUG_TAKEN' | 'NO_ADMIN_LICENSE' | 'DISABLED' | 'ERROR';
  slug?: string;
}

const digits = (v: unknown) => (typeof v === 'string' ? v.replace(/\D/g, '') : '');
const parse = (raw: string | null | undefined) => {
  try {
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
};

export class ReservationSyncService {
  private running = false;
  private kickTimer: NodeJS.Timeout | null = null;
  private started = false;

  constructor(private cloud: CloudAuthService, private onlineOrders = new OnlineOrderUseCases()) {}

  // ── Publicar la página ────────────────────────────────────
  private async siteBody() {
    const row = await prisma.businessSettings.findUnique({ where: { id: SETTINGS_ID } });
    const settings = normalizeBooking(row?.bookingSettings ? JSON.parse(row.bookingSettings) : {});
    const tables = (await prisma.table.findMany({ where: { reservable: true } }))
      .sort((a, b) => a.number.localeCompare(b.number, 'es', { numeric: true }))
      .map((t) => ({ id: t.id, label: t.number, capacity: t.capacity, zone: t.zone }));
    const slug = row?.bookingSlug || slugify(row?.businessName || row?.cloudTenantName || '') || 'mi-restaurante';
    const bookingOn = settings.enabled && settings.online;
    // La página (carta, registro, juego) solo existe si el ADMIN la configuró en Mi página
    const page = row?.pageSettings ? normalizePageConfig(parse(row.pageSettings)) : null;
    const sections = {
      menu: !!page?.sections.menu,
      booking: bookingOn,
      signup: !!page?.sections.signup,
      games: !!page?.sections.games,
      orders: !!page?.sections.orders,
    };
    const pageOn = sections.menu || sections.signup || sections.games || sections.orders;
    const body = {
      slug,
      businessName: row?.businessName || row?.cloudTenantName || 'Lantify',
      settings,
      tables,
      sections,
      menu: sections.menu || sections.orders ? await new PageUseCases().menu() : [],
      profile: page?.profile ?? {},
      games: page?.games ?? {},
      legal: page?.legal ?? {},
      ordering: page?.ordering ?? {},
      theme: page?.theme ?? {},
      loyalty: page?.loyalty ?? {},
      social: page?.social ?? {},
    };
    const hash = crypto.createHash('sha256').update(JSON.stringify(body)).digest('hex');
    return { row, settings, body, hash, bookingOn, pageOn, sections };
  }

  private async request(method: string, path: string, token: string, body: unknown) {
    const { apiUrl, timeoutMs } = cloudConfig();
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const res = await fetch(`${apiUrl}${path}`, {
        method,
        signal: controller.signal,
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(body),
      });
      return { status: res.status, body: (await res.json().catch(() => ({}))) as any };
    } catch {
      return null; // sin conexión
    } finally {
      clearTimeout(timer);
    }
  }

  /** Licencia de un ADMIN del negocio (la de quien guardó, o cualquiera guardada en este equipo) */
  private async adminLicense(localUserId?: string) {
    if (localUserId) {
      const user = await prisma.user.findUnique({ where: { id: localUserId } });
      const own = user?.cloudUserId ? storedLicenseFor(user.cloudUserId) : null;
      if (own?.claims.role === 'ADMIN') return own.token;
    }
    return allStoredLicenses().filter((l) => l.claims.role === 'ADMIN').sort((a, b) => b.claims.exp - a.claims.exp)[0]?.token || null;
  }

  async publish(localUserId?: string): Promise<PublishResult> {
    if (!(await this.cloud.linkedTenant())) return { ok: false, code: 'NOT_LINKED' };
    const { body, hash } = await this.siteBody();
    const token = await this.adminLicense(localUserId);
    if (!token) return { ok: false, code: 'NO_ADMIN_LICENSE' };
    const res = await this.request('PUT', '/v1/site', token, body);
    if (!res) return { ok: false, code: 'OFFLINE' };
    if (res.status === 409) return { ok: false, code: 'SLUG_TAKEN' };
    if (res.status !== 200) return { ok: false, code: 'ERROR' };
    await prisma.businessSettings.update({
      where: { id: SETTINGS_ID },
      data: { bookingSlug: res.body.slug, bookingPublishedAt: new Date(), bookingPublishedHash: hash },
    });
    return { ok: true, slug: res.body.slug };
  }

  // ── Sincronizar ───────────────────────────────────────────
  async sync(): Promise<{ ok: boolean; imported?: number; pushed?: number; members?: number; prizes?: number; orders?: number; reason?: string }> {
    if (this.running) return { ok: false, reason: 'BUSY' };
    this.running = true;
    try {
      if (!(await this.cloud.linkedTenant())) return { ok: false, reason: 'NOT_LINKED' };
      const { row, hash, bookingOn, pageOn, sections } = await this.siteBody();
      if (!bookingOn && !pageOn) {
        // Se apagó todo: la página publicada se cierra una vez
        if (row?.bookingPublishedAt && row.bookingPublishedHash !== hash) await this.publish();
        return { ok: false, reason: 'DISABLED' };
      }
      // Carta, mesas, horario, juego o nombre cambiaron desde la última publicación
      if (row?.bookingPublishedHash !== hash) await this.publish();

      const license = allStoredLicenses().sort((a, b) => b.claims.exp - a.claims.exp)[0]?.token;
      if (!license) return { ok: false, reason: 'NO_LICENSE' };

      let members = 0;
      let prizes = 0;
      if (sections.signup || sections.games) {
        const inbox = await this.pullInbox(license, row?.pageSyncCursors);
        if (inbox) ({ members, prizes } = inbox);
        await this.syncStampTokens(license);
      }
      // Pedidos: también cuando se apagaron, para cerrar los que quedaron abiertos
      const orders = sections.orders || (await this.onlineOrders.dirty()).length ? await this.syncOrders(license, row?.ordersSyncCursor) : 0;
      if (!bookingOn) {
        await prisma.businessSettings.update({ where: { id: SETTINGS_ID }, data: { bookingSyncAt: new Date() } });
        return { ok: true, imported: 0, pushed: 0, members, prizes, orders };
      }

      let cursor = row?.bookingSyncCursor || undefined;
      let imported = 0;
      let pushed = 0;
      for (let round = 0; round < 5; round++) {
        const dirty = await prisma.reservation.findMany({ where: { dirty: true }, take: 300, orderBy: { updatedAt: 'asc' } });
        const res = await this.request('POST', '/v1/reservations/sync', license, {
          cursor,
          // Solo mesa, horas y estado: los datos del cliente se quedan en el negocio
          changes: dirty.map((r) => ({ id: r.id, code: r.code, tableId: r.tableId, partySize: r.partySize, startsAt: r.startsAt, endsAt: r.endsAt, status: r.status })),
        });
        if (!res) return { ok: false, reason: 'OFFLINE' };
        if (res.status !== 200) return { ok: false, reason: res.body?.code || `HTTP_${res.status}` };

        // Lo subido queda limpio, salvo que lo hayan vuelto a cambiar mientras tanto
        for (const r of dirty) {
          await prisma.reservation.updateMany({ where: { id: r.id, updatedAt: r.updatedAt }, data: { dirty: false } });
        }
        pushed += dirty.length;
        for (const incoming of res.body.reservations || []) {
          if (await this.importOnline(incoming)) imported++;
        }
        if (Array.isArray(res.body.conflicts) && res.body.conflicts.length) {
          await prisma.reservation.updateMany({ where: { id: { in: res.body.conflicts } }, data: { cloudConflict: true } });
        }
        cursor = res.body.cursor;
        if (!res.body.more && dirty.length < 300) break;
      }
      await prisma.businessSettings.update({ where: { id: SETTINGS_ID }, data: { bookingSyncCursor: cursor ?? null, bookingSyncAt: new Date() } });
      if (imported) console.log(`📅 Reservas: ${imported} nueva(s) o actualizada(s) desde la página`);
      return { ok: true, imported, pushed, members, prizes, orders };
    } catch (err: any) {
      console.warn('[reservas] sincronización:', err?.message || err);
      return { ok: false, reason: 'ERROR' };
    } finally {
      this.running = false;
    }
  }

  // ── Pedidos en línea ──────────────────────────────────────
  /** Sube los estados que cambió la caja y trae los pedidos nuevos; devuelve cuántos llegaron */
  private async syncOrders(license: string, cursor: string | null | undefined) {
    let count = 0;
    for (let round = 0; round < 5; round++) {
      const dirty = await this.onlineOrders.dirty();
      const res = await this.request('POST', '/v1/site/orders/sync', license, {
        cursor: cursor || undefined,
        updates: dirty.map((o) => ({ id: o.id, status: o.status, note: o.statusNote })),
      });
      if (!res || res.status !== 200) break; // sin conexión o sin el plan: se intenta en la próxima vuelta
      await this.onlineOrders.markClean(dirty);
      for (const o of res.body.orders || []) if (await this.onlineOrders.importFromCloud(o, (r) => this.customerFor(r))) count++;
      cursor = res.body.cursor;
      await prisma.businessSettings.update({ where: { id: SETTINGS_ID }, data: { ordersSyncCursor: cursor ?? null } });
      if (!res.body.more && dirty.length < 300) break;
    }
    if (count) console.log(`🛵 Pedidos web: ${count} nuevo(s) desde la página`);
    return count;
  }

  // ── Tokens de Sellos QR para clientes ─────────────────────
  private async syncStampTokens(license: string) {
    try {
      const pending = await prisma.stampToken.findMany({
        where: { synced: false },
        take: 50,
      });
      if (!pending.length) return 0;

      const res = await this.request('POST', '/v1/site/stamps/tokens', license, {
        tokens: pending.map((t) => ({
          id: t.id,
          saleId: t.saleId,
          stamps: t.stamps,
          gamePlays: t.gamePlays,
          totalAmount: t.totalAmount,
          expiresAt: t.expiresAt.toISOString(),
        })),
      });

      if (res && res.status === 200) {
        await prisma.stampToken.updateMany({
          where: { id: { in: pending.map((t) => t.id) } },
          data: { synced: true },
        });
        return pending.length;
      }
    } catch (e) {
      console.warn('[SyncStampTokens] Error al sincronizar sellos:', e);
    }
    return 0;
  }

  async pushManualStamps(data: { customerId: string; phone?: string; deltaStamps: number; stampsBalance: number; lifetimeStamps: number }) {
    try {
      const token = await this.adminLicense();
      if (!token) return;
      await this.request('POST', '/v1/site/stamps/manual', token, data);
    } catch (e) {
      console.warn('[SyncManualStamps] Error al sincronizar sellos manuales:', e);
    }
  }

  // ── Registros y premios de la página ──────────────────────
  private async pullInbox(license: string, rawCursors: string | null | undefined) {
    let cursors = parse(rawCursors) as { customersCursor?: string; playsCursor?: string };
    let members = 0;
    let prizes = 0;
    for (let round = 0; round < 5; round++) {
      const res = await this.request('POST', '/v1/site/inbox', license, cursors);
      if (!res || res.status !== 200) break; // sin conexión o sin el plan: se intenta en la próxima vuelta
      for (const c of res.body.customers || []) if (await this.importMember(c)) members++;
      for (const p of res.body.prizes || []) if (await this.importPrize(p)) prizes++;
      cursors = { customersCursor: res.body.customersCursor, playsCursor: res.body.playsCursor };
      await prisma.businessSettings.update({ where: { id: SETTINGS_ID }, data: { pageSyncCursors: JSON.stringify(cursors) } });
      if (!res.body.more) break;
    }
    if (members || prizes) console.log(`🎉 Mi página: ${members} registro(s) y ${prizes} premio(s) nuevos`);
    return { members, prizes };
  }

  /** Quien se registró en la página queda en Clientes (o se borra si lo pidió) */
  private async importMember(c: any): Promise<boolean> {
    const existing = await prisma.customer.findUnique({ where: { cloudId: c.id } });
    if (c.deleted) {
      if (!existing) return false;
      // Ley 1581: se suprimen sus datos personales; las ventas quedan sin nombre
      await prisma.customer.update({
        where: { id: existing.id },
        data: { name: 'Cliente que pidió borrar sus datos', phone: null, email: null, birthDate: null, marketingOptIn: false, isActive: false, consentAt: null },
      });
      return true;
    }
    if (!c.name || !c.consentAt) return false;
    const data = {
      name: String(c.name).slice(0, 120),
      phone: c.phone || null,
      ...(c.email ? { email: String(c.email).slice(0, 120) } : {}),
      ...(birthDateFrom(c.birthDay, c.birthMonth) ? { birthDate: birthDateFrom(c.birthDay, c.birthMonth) } : {}),
      consentAt: new Date(c.consentAt),
      consentVersion: c.consentVersion || null,
      marketingOptIn: !!c.marketingOptIn,
    };
    if (existing) {
      await prisma.customer.update({ where: { id: existing.id }, data: { ...data, isActive: true } });
      return true;
    }
    // ¿Ya era cliente del negocio con ese celular? Se enlaza en vez de duplicarlo
    const phone = normalizePhone(c.phone);
    const match = phone.length >= 7
      ? await prisma.customer.findFirst({ where: { isActive: true, isDefault: false, cloudId: null, phone: { contains: phone.slice(-10) } }, orderBy: { updatedAt: 'desc' } })
      : null;
    if (match) await prisma.customer.update({ where: { id: match.id }, data: { ...data, cloudId: c.id } });
    else await prisma.customer.create({ data: { ...data, cloudId: c.id, source: 'ONLINE' } });
    return true;
  }

  /** Un premio ganado es un cupón de un solo uso a nombre del cliente */
  private async importPrize(p: any): Promise<boolean> {
    if (!p.code || (await prisma.coupon.findUnique({ where: { code: p.code } }))) return false;
    const owner = p.customerId ? await prisma.customer.findUnique({ where: { cloudId: p.customerId } }) : null;
    await prisma.coupon.create({
      data: {
        code: String(p.code).slice(0, 20),
        description: `Premio de la página: ${String(p.label || '').slice(0, 80)}`,
        type: p.kind === 'AMOUNT' ? 'AMOUNT' : 'PERCENT',
        value: Number(p.value) || 0,
        minPurchase: p.minPurchase ? Number(p.minPurchase) : null,
        startsAt: p.createdAt ? new Date(p.createdAt) : null,
        endsAt: p.expiresAt ? new Date(p.expiresAt) : null,
        maxUses: 1,
        source: 'GAME',
        customerId: owner?.id ?? null,
        createdBy: 'Página del negocio',
      },
    });
    return true;
  }

  /** Agenda (o actualiza) una reserva hecha en la página; devuelve true si cambió algo */
  private async importOnline(r: any): Promise<boolean> {
    const existing = await prisma.reservation.findUnique({ where: { id: r.id } });
    const tableId = r.tableId && (await prisma.table.findUnique({ where: { id: r.tableId } })) ? r.tableId : null;
    const common = {
      tableId,
      partySize: Math.max(1, Number(r.partySize) || 1),
      startsAt: new Date(r.startsAt),
      endsAt: new Date(r.endsAt),
      status: r.status,
      cancelReason: r.cancelReason || null,
      cloudConflict: !!r.conflict,
      dirty: false,
    };
    if (existing) {
      // Si alguien la cambió en la caja y aún no subió, gana el cambio de la caja
      if (existing.dirty) return false;
      await prisma.reservation.update({ where: { id: r.id }, data: common });
      return existing.status !== r.status || existing.startsAt.getTime() !== common.startsAt.getTime();
    }
    if (!r.customerName) return false; // datos ya borrados de la nube (reserva vieja)
    const customerId = await this.customerFor(r);
    try {
      await prisma.reservation.create({
        data: {
          id: r.id,
          code: r.code,
          ...common,
          customerId,
          customerName: String(r.customerName).slice(0, 120),
          customerPhone: r.customerPhone || null,
          customerEmail: r.customerEmail || null,
          notes: r.notes || null,
          channel: 'ONLINE',
          createdBy: 'Página de reservas',
          consentAt: r.consentAt ? new Date(r.consentAt) : null,
          marketingOptIn: !!r.marketingOptIn,
        },
      });
      return true;
    } catch (err: any) {
      console.warn('[reservas] no se pudo agendar la reserva de la página', r.code, err?.code || err?.message);
      return false;
    }
  }

  /** Quien reservó en la página queda en Clientes (lo autorizó al reservar) */
  private async customerFor(r: any) {
    const phone = digits(r.customerPhone);
    if (phone.length >= 7) {
      const match = await prisma.customer.findFirst({
        where: { isActive: true, isDefault: false, phone: { contains: phone.slice(-10) } },
        orderBy: { updatedAt: 'desc' },
      });
      if (match) {
        // Aceptar promociones al reservar se respeta; nunca se apaga por una reserva
        if (r.marketingOptIn && !match.marketingOptIn) await prisma.customer.update({ where: { id: match.id }, data: { marketingOptIn: true } });
        return match.id;
      }
    }
    if (!r.consentAt) return null;
    const created = await prisma.customer.create({
      data: {
        name: String(r.customerName).slice(0, 120),
        phone: r.customerPhone || null,
        email: r.customerEmail || null,
        source: 'ONLINE',
        consentAt: new Date(r.consentAt),
        consentVersion: r.consentVersion || null,
        marketingOptIn: !!r.marketingOptIn,
      },
    });
    return created.id;
  }

  // ── Programación ──────────────────────────────────────────
  start() {
    if (this.started) return;
    this.started = true;
    setTimeout(() => this.sync(), 15_000);
    setInterval(() => this.sync(), TICK_MS);
  }

  /** Tras un cambio en la caja: sube pronto (agrupa cambios seguidos) */
  kick() {
    if (!this.started) return;
    if (this.kickTimer) clearTimeout(this.kickTimer);
    this.kickTimer = setTimeout(() => {
      this.kickTimer = null;
      this.sync();
    }, 1500);
  }
}

