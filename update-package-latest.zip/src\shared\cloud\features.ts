// ============================================
// SHARED - Funciones del plan (candados del servidor local)
// ============================================
// Una sola tabla dice qué función del plan exige cada endpoint. Las funciones
// salen de la licencia VERIFICADA (firmada por Lantify Cloud): editar el archivo
// o la base de datos no habilita nada. Sin negocio vinculado no hay candados
// (instalaciones de desarrollo o anteriores a las licencias).

import fs from 'fs';
import path from 'path';
import { prisma } from '../../infrastructure/database/prisma';
import { getDataDir } from '../security/secrets';
import { allStoredLicenses } from './license';

export type FeatureCode =
  | 'customers' | 'dian' | 'analytics_adv' | 'inventory' | 'ai_copilot'
  | 'multi_terminal' | 'delivery' | 'whatsapp' | 'webstore' | 'expense_ocr' | 'ai_agents' | 'suppliers' | 'coupons' | 'reservations' | 'business_page' | 'loyalty';

interface FeatureRule {
  methods: string[] | '*';
  path: RegExp;
  feature: FeatureCode | null; // null = excepción: del plan base aunque una regla posterior coincida
}

const rule = (methods: string | string[], p: RegExp, feature: FeatureCode | null): FeatureRule => ({
  methods: methods === '*' ? '*' : Array.isArray(methods) ? methods : [methods],
  path: p,
  feature,
});

// Rutas relativas a /api. Gana la primera regla que coincide; lo que no aparece es del plan base.
export const FEATURE_RULES: FeatureRule[] = [
  // El cliente genérico de la venta (consumidor final) existe en todos los planes
  rule('GET', /^\/customers\/default$/, null),
  rule('*', /^\/customers(\/.*)?$/, 'customers'),
  rule('PATCH', /^\/sales\/[^/]+\/customer$/, 'customers'),
  rule('*', /^\/dian(\/.*)?$/, 'dian'),
  rule('*', /^\/analytics(\/.*)?$/, 'analytics_adv'),
  // Conteos físicos de inventario: plan Pro en adelante (el ajuste de stock es básico)
  rule('*', /^\/inventory\/[^/]+\/counts?$/, 'inventory'),
  rule('POST', /^\/ai\/chat$/, 'ai_copilot'),
  rule('POST', /^\/expenses\/scan$/, 'expense_ocr'),
  rule('*', /^\/suppliers(\/.*)?$/, 'suppliers'),
  rule('*', /^\/coupons(\/.*)?$/, 'coupons'),
  rule('*', /^\/agents(\/.*)?$/, 'ai_agents'),
  rule('*', /^\/reservations(\/.*)?$/, 'reservations'),
  rule('*', /^\/page(\/.*)?$/, 'business_page'),
  rule('*', /^\/online-orders(\/.*)?$/, 'webstore'),
  rule('*', /^\/prototype\/(rappi\/.*|channels\/stats|channel-stats)$/, 'delivery'),
  rule('*', /^\/prototype\/whatsapp\/.*$/, 'whatsapp'),
  rule('*', /^\/prototype\/web\/.*$/, 'webstore'),
  rule('GET', /^\/public\/catalog$/, 'webstore'),
];

/** Función que exige la ruta, o null si es del plan base */
export const requiredFeature = (method: string, rawPath: string): FeatureCode | null => {
  const m = method.toUpperCase();
  const p = rawPath.split('?')[0].replace(/\/+$/, '') || '/';
  for (const r of FEATURE_RULES) {
    if (r.methods !== '*' && !r.methods.includes(m)) continue;
    if (!r.path.test(p)) continue;
    return r.feature;
  }
  return null;
};

// ── Funciones vigentes del negocio ──────────────────────────
// Se leen de la licencia más reciente guardada en este equipo. Se cachean y se
// releen cuando cambia el archivo de licencias o pasan 30 s (vinculación).

const LINK_TTL_MS = 30_000;
let linkCache: { at: number; linked: boolean } | null = null;
let featureCache: { mtime: number; features: string[] } | null = null;

export const invalidateFeatureCache = () => {
  linkCache = null;
  featureCache = null;
};

const isLinked = async () => {
  if (linkCache && Date.now() - linkCache.at < LINK_TTL_MS) return linkCache.linked;
  const s = await prisma.businessSettings.findUnique({ where: { id: 'default' }, select: { cloudTenantCode: true } });
  linkCache = { at: Date.now(), linked: !!s?.cloudTenantCode };
  return linkCache.linked;
};

const licenseMtime = () => {
  try {
    return fs.statSync(path.join(getDataDir(), 'license.dat')).mtimeMs;
  } catch {
    return 0;
  }
};

/**
 * null = sin candados (no hay negocio vinculado).
 * Vinculado pero sin licencia en este equipo = solo el plan base (borrar el archivo no habilita nada).
 */
export const currentFeatures = async (): Promise<string[] | null> => {
  if (!(await isLinked())) return null;
  const mtime = licenseMtime();
  if (featureCache && featureCache.mtime === mtime) return featureCache.features;
  const newest = allStoredLicenses().sort((a, b) => b.claims.iat - a.claims.iat)[0];
  const features = newest ? newest.claims.features : [];
  featureCache = { mtime, features };
  return features;
};

/** Petición desde otro equipo de la red local (tablets de meseros) */
export const isRemoteClient = (ip: string | undefined) => {
  if (!ip) return false;
  const clean = ip.replace(/^::ffff:/, '');
  return !(clean === '127.0.0.1' || clean === '::1' || clean === 'localhost');
};

// Rutas que la pantalla de inicio necesita aunque el equipo no pueda usar el plan
const ALWAYS_REACHABLE = [/^\/cloud\/status$/, /^\/version$/, /^\/auth\/setup-status$/];
export const isAlwaysReachable = (p: string) => ALWAYS_REACHABLE.some((r) => r.test(p.split('?')[0]));
