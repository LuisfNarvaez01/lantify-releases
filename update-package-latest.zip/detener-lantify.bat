@echo off
chcp 65001 >nul
title Detener Lantify POS

echo ========================================
echo   DETENIENDO LANTIFY POS
echo ========================================
echo.
echo Deteniendo servicios en segundo plano (puertos 5000 y 5173)...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-NetTCPConnection -LocalPort 5000,5173 -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique | ForEach-Object { Stop-Process -Id $_ -Force -ErrorAction SilentlyContinue }"
echo.
echo [OK] Servicios detenidos correctamente.
timeout /t 2 /nobreak >nul
exit
