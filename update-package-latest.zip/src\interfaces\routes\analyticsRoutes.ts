// ============================================
// INTERFACES - Analytics Routes
// ============================================

import { Router } from 'express';
import { AnalyticsController } from '../controllers/AnalyticsController';

export const createAnalyticsRoutes = (controller: AnalyticsController) => {
  const router = Router();

  router.get('/compare-months', controller.compareMonths.bind(controller));
  router.get('/monthly-comparison', controller.compareMonths.bind(controller));
  router.get('/monthly-comparison/available-months', controller.getAvailableMonths.bind(controller));
  router.get('/available-months', controller.getAvailableMonths.bind(controller));
  router.get('/top-products', controller.getTopProducts.bind(controller));

  return router;
};
