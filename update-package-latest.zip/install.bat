@echo off
chcp 65001 >nul
title Instalador - Sistema POS

echo ========================================
echo   INSTALADOR DEL SISTEMA POS
echo ========================================
echo.

if not exist "package.json" (
    echo ERROR: No se encontro package.json
    echo Asegurate de ejecutar este archivo desde la carpeta del proyecto
    pause
    exit /b 1
)

echo [1/5] Instalando dependencias del servidor...
call npm install
if errorlevel 1 (
    echo ERROR: Fallo al instalar dependencias del servidor
    pause
    exit /b 1
)
echo.

echo [2/5] Instalando dependencias del frontend...
cd frontend
call npm install
if errorlevel 1 (
    echo ERROR: Fallo al instalar dependencias del frontend
    pause
    exit /b 1
)
cd ..
echo.

echo [3/5] Generando cliente de base de datos...
call npx prisma generate
if errorlevel 1 (
    echo ERROR: Fallo al generar cliente Prisma
    pause
    exit /b 1
)
echo.

echo [4/5] Creando base de datos...
call npx prisma db push --force-reset
if errorlevel 1 (
    echo ERROR: Fallo al crear base de datos
    pause
    exit /b 1
)
echo.

echo [5/5] Verificando instalacion...
timeout /t 2 /nobreak >nul
if not exist "prisma\dev.db" (
    echo ADVERTENCIA: La base de datos se creara automaticamente al iniciar
) else (
    echo Base de datos creada correctamente
)
echo.

echo ========================================
echo   INSTALACION COMPLETADA!
echo ========================================
echo.
echo Ahora podes ejecutar el sistema con:
echo   start.bat
echo.
pause