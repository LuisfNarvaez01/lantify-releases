// ============================================
// SCRIPT - Verify DIAN Electronic Invoicing & Offline Queue
// ============================================

import { prisma } from '../src/infrastructure/database/prisma';
import { dianService } from '../src/infrastructure/services/DianElectronicBillingService';

async function main() {
  console.log('====================================================');
  console.log('🧪 VERIFICACIÓN INTEGRAL: FACTURACIÓN ELECTRÓNICA DIAN');
  console.log('   Modo: Software Propio | Cola Offline-First UBL 2.1');
  console.log('====================================================\n');

  // 1. Verificar Configuración DIAN
  console.log('1. Verificando Configuración DIAN (Software Propio)...');
  const config = await dianService.getConfig();
  console.log(`   ✓ Modo Operación: ${config.operationMode}`);
  console.log(`   ✓ Proveedor: ${config.providerName}`);
  console.log(`   ✓ Software: ${config.softwareName}`);
  console.log(`   ✓ Software ID: ${config.softwareId}`);
  console.log(`   ✓ Software PIN: ${config.softwarePin}`);
  console.log(`   ✓ URL Recepción: ${config.wsdlUrl}`);
  console.log(`   ✓ Prefijo: ${config.prefix} (Consecutivo actual: ${config.currentNumber})`);

  // 2. Crear una venta de prueba
  console.log('\n2. Creando venta de prueba para facturación electrónica...');
  const testSale = await prisma.sale.create({
    data: {
      saleNumber: `SALE-DIAN-TEST-${Date.now().toString().slice(-4)}`,
      subtotal: 50000,
      tax: 4000, // 8% INC
      total: 54000,
      paymentMethod: 'CASH',
      status: 'COMPLETED',
      notes: 'Venta de prueba para verificación DIAN',
      items: {
        create: [
          {
            productVariant: {
              connectOrCreate: {
                where: { sku: 'TEST-SKU-DIAN-01' },
                create: {
                  name: 'Plato Especial Prueba',
                  sku: 'TEST-SKU-DIAN-01',
                  price: 50000,
                  stock: 100,
                  product: {
                    create: {
                      name: 'Especial Gastronómico DIAN'
                    }
                  }
                }
              }
            },
            quantity: 1,
            unitPrice: 50000,
            total: 50000
          }
        ]
      }
    }
  });
  console.log(`   ✓ Venta creada: ${testSale.saleNumber} ($${testSale.total})`);

  // 3. Encolar Factura Electrónica
  console.log('\n3. Encolando factura electrónica (Offline Queue)...');
  const invoice = await dianService.enqueueInvoice(testSale.id, {
    nit: '900123456',
    name: 'Cliente Restaurante Prueba S.A.S.',
    email: 'factura@cliente.com',
    phone: '3101234567',
    address: 'Carrera 7 # 72-10'
  });

  console.log(`   ✓ Consecutivo Asignado: ${invoice.invoiceNumber}`);
  console.log(`   ✓ Estado Inicial: ${invoice.status}`);
  console.log(`   ✓ CUFE Oficial (SHA-384, longitud ${invoice.cufe.length}):`);
  console.log(`     ${invoice.cufe}`);
  console.log(`   ✓ XML UBL 2.1 Generado: ${invoice.xmlContent ? `${invoice.xmlContent.length} bytes` : 'NO'}`);

  // 4. Procesar la Cola de Sincronización
  console.log('\n4. Ejecutando Worker de Sincronización con la DIAN...');
  const queueResult = await dianService.processQueue();
  console.log(`   ✓ Procesadas: ${queueResult.processed}`);
  console.log(`   ✓ Aceptadas DIAN: ${queueResult.success}`);
  console.log(`   ✓ Fallidas/En cola: ${queueResult.failed}`);

  // 5. Consultar Estado Final de la Factura
  const finalInvoice = await prisma.dianInvoice.findUnique({
    where: { id: invoice.id }
  });
  console.log('\n5. Verificando estado final en base de datos:');
  console.log(`   ✓ Estado: ${finalInvoice?.status}`);
  console.log(`   ✓ TrackID DIAN: ${finalInvoice?.trackId || 'N/A'}`);
  console.log(`   ✓ Respuesta DIAN: ${finalInvoice?.dianResponseDesc}`);
  console.log(`   ✓ ApplicationResponse XML: ${finalInvoice?.dianXmlResponse ? 'Presente' : 'Pendiente'}`);

  // 6. Consultar Estadísticas Generales de la Cola
  console.log('\n6. Consultando Monitor General de Cola DIAN...');
  const stats = await dianService.getQueueStats();
  console.log(`   ✓ Conectividad DIAN: ${stats.isOnline ? 'EN LÍNEA (Online)' : 'OFFLINE'}`);
  console.log(`   ✓ Pendientes en Cola: ${stats.queue.pending}`);
  console.log(`   ✓ Aceptadas DIAN: ${stats.queue.accepted}`);
  console.log(`   ✓ Total Facturas DIAN: ${stats.queue.total}`);

  console.log('\n====================================================');
  console.log('✅ TODAS LAS PRUEBAS DIAN PASARON CON ÉXITO');
  console.log('====================================================\n');
}

main()
  .catch((e) => {
    console.error('❌ Error en verificación DIAN:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
