import { AnalyticsUseCases } from '../src/application/usecases/AnalyticsUseCases';
import { prisma } from '../src/infrastructure/database/prisma';

async function testAnalytics() {
  const analytics = new AnalyticsUseCases();
  const months = await analytics.getAvailableMonths();
  console.log('[OK] Available Months:', months.length, months.map((m: any) => m.label));

  const keys = months.map((m: any) => `${m.year}-${String(m.month).padStart(2, '0')}`);
  const compare = await analytics.compareMonths(keys);
  console.log('[OK] Compare Months:', compare.length, compare.map((c: any) => ({ month: c.label, revenue: c.totalRevenue, sales: c.completedCount })));

  const top = await analytics.getTopProducts(0, 0, 5);
  console.log('[OK] Top Products:', top.items.length, 'Total revenue:', top.totalRevenue);
}

testAnalytics()
  .then(() => process.exit(0))
  .catch(err => {
    console.error('Error in test:', err);
    process.exit(1);
  });
