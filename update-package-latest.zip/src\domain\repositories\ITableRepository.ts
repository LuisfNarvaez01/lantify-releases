// ============================================
// DOMAIN REPOSITORIES - Table Repository Interface
// ============================================

export interface ITableRepository {
  create(data: any): Promise<any>;
  getById(id: string): Promise<any | null>;
  getAll(): Promise<any[]>;
  getByStatus(status: any): Promise<any[]>;
  getAvailable(): Promise<any[]>;
  update(id: string, data: any): Promise<any>;
  updateStatus(id: string, status: any): Promise<any>;
  delete(id: string): Promise<void>;
}