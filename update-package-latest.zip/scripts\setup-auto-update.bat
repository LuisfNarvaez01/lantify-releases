@echo off
setlocal

echo ======================================================
echo    LANTIFY POS - CONFIGURADOR DE TAREA PROGRAMADA    
echo ======================================================
echo.

set TASK_NAME=LantifyPOS_AutoUpdate
set BAT_PATH=%~dp0..\update.bat

echo Registrando tarea programada en Windows para ejecutarse diariamente a las 5:00 AM...
schtasks /create /tn "%TASK_NAME%" /tr "\"%BAT_PATH%\"" /sc daily /st 05:00 /f /rl HIGHEST

if %errorlevel% equ 0 (
    echo.
    echo ✅ Tarea programada '%TASK_NAME%' registrada con exito.
    echo El sistema buscara actualizaciones todos los dias a las 5:00 AM.
) else (
    echo.
    echo ❌ Se requieren permisos de Administrador para registrar la tarea programada.
    echo Por favor ejecuta este script haciendo click derecho y "Ejecutar como Administrador".
)

echo.
pause
