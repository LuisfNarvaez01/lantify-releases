# Changelog — Lantify POS

Todas las modificaciones notables de este proyecto están documentadas en este archivo.
El formato se basa en [Keep a Changelog](https://keepachangelog.com/es-ES/1.0.0/) y este proyecto se adhiere a [Semantic Versioning](https://semver.org/lang/es/).

---

## [3.0.1] - 2026-11-13

### Añadido
- **Logo animado de Lantify**: se dibuja al abrir el sistema, en la pantalla de carga del programa de escritorio, al entrar a la página web (fondo azul que se abre desde la mitad) y antes de descargar el instalador.

### Corregido
- **Varios pagos en un cobro**: "Varios pagos" deja agregar los pagos que hagan falta, aunque sean del mismo medio (por ejemplo, tres transferencias), y los va sumando. El cambio sale solo del efectivo y la venta queda con el medio que se usó.
- **Mesa abierta sin pedido**: si no se envió nada a cocina, "Cerrar mesa" la deja libre con una confirmación, sin motivo ni clave de administrador, y no queda "por limpiar".

## [3.0.0] - 2026-11-12

### Añadido
- **Pantalla de Funciones Activables**:
  - Panel centralizado en Administración para activar o desactivar módulos según las necesidades del negocio.
  - Ocultamiento completo de menús, pestañas y botones de las funciones desactivadas para evitar saturación de la interfaz.
  - Al actualizar a la versión 3.0, las funciones existentes se mantienen encendidas y las nuevas llegan apagadas por defecto.
- **Vista Móvil para Celulares y Meseros**:
  - Disposición optimizada para pantallas táctiles angostas con objetivos táctiles de 48 px.
  - Barra inferior fija con accesos rápidos a Mesas, Pedidos y Avisos.
  - Filtro "Mis mesas" para ver únicamente las mesas atendidas por el mesero en sesión.
  - Envío ágil de comandas a cocina y solicitud de pre-cuenta desde el celular en la red WiFi local.
  - Instalación directa en la pantalla de inicio del dispositivo como acceso rápido.
- **Mesa por Limpiar y Alertas de Mesa**:
  - Estado intermedio "Por limpiar" tras cobrar o liberar una mesa, que se marca lista con un solo toque.
  - Alerta de mesa inactiva cuando transcurren 20 minutos desde la última ronda sin pedir cuenta.
  - Alerta de cuenta pendiente cuando transcurren 7 minutos desde la solicitud de cuenta sin registrar el cobro.
  - Umbrales de tiempo editables desde la pantalla de Funciones.
  - Preparación para la alerta "Lista para cuenta", que se activará en una próxima entrega junto con la pantalla de cocina.
- **Ingredientes y Comentarios por Producto**:
  - Configuración de ingredientes removibles por producto desde el catálogo de Productos.
  - Retiro de ingredientes con un solo toque al tomar pedidos en caja o celular.
  - Impresión destacada en mayúsculas de los ingredientes excluidos ("SIN CEBOLLA") en la comanda térmica de cocina.
  - Frases rápidas predefinidas y editables por el negocio, junto con campo de comentario libre.
- **Lista de Compras por Proveedor**:
  - Parámetros de reposición por producto: stock mínimo (5 unidades por defecto), cantidad sugerida a pedir, unidad de compra y proveedor preferido.
  - Botón "Lista de compras" en Inventario que consolida productos en o por debajo del mínimo, agrupados por proveedor.
  - Edición previa de cantidades y eliminación de renglones antes del envío.
  - Opciones para copiar el pedido al portapapeles o despacharlo directamente al chat de WhatsApp del proveedor.
- **Corrección de Medio de Pago**:
  - Ajuste de métodos de pago y montos desde el detalle de la venta en el historial de ventas, sin modificar el total cobrado.
  - Validación de seguridad: solo aplicable mientras el turno de caja de la venta permanezca abierto y cuando no cuente con factura electrónica transmitida a la DIAN.
  - Justificación obligatoria con motivo registrado en la auditoría del sistema.
  - Permiso dedicado para autorizar a cajeros a realizar correcciones de pago.
- **Reporte Automático de Cierre de Caja al Dueño**:
  - Botón "Enviar al dueño" al completar el arqueo para compartir el resumen del cierre por WhatsApp con un solo toque.
  - Transmisión automática del cierre a la plataforma en la nube (visible en Mi cuenta → Cierres de caja) y envío por correo electrónico.
  - Cola de sincronización local que envía el reporte automáticamente tan pronto se restablece la conexión a internet.
- **Gestión de Personal, Turnos y Pagos**:
  - Menú Personal que integra Usuarios y permisos, Equipo, Turnos y Pagos.
  - Registro de empleados con o sin cuenta de usuario (incluyendo cocina y apoyo operativo).
  - Marcación de entrada y salida desde la sesión del trabajador o gestionada por el administrador/cajero.
  - Control de adelantos y descuentos, liquidación periódica del colaborador y opción de registrar el pago como gasto.
  - Módulo diseñado para control operativo interno, sin reemplazar la nómina legal colombiana.
- **Reparto Configurable de Propinas**:
  - Distribución del pozo de propinas por porcentajes por grupo (meseros, caja, cocina, barra, otros) sumando 100 %.
  - Reparto entre meseros configurable en partes iguales o proporcional al aporte de propinas recaudado.
  - Soporte de periodos de liquidación por semana, por arqueo de caja o por mes.
  - Posibilidad de realizar ajustes manuales antes de confirmar, con reasignación obligatoria de montos en grupos sin turnos registrados.
- **Páginas Legales y Términos por Negocio**:
  - Generación automática de páginas de Términos y Condiciones y Política de Privacidad a partir de la información registrada (razón social, NIT, correo, dirección y teléfono).
  - Enlaces de consulta en el pie de página del negocio y en flujos de pedidos y reservas en línea.
  - Validación que exige completar la información legal antes de autorizar la primera publicación de la página web.
- **Pantallas de Cocina, Entregas y Salón**:
  - Visualización de comandas en TV para cocina con orden de llegada, tiempos, filtro por estación, tachado de productos y botones Listo y Deshacer.
  - Pantalla de entregas para clientes con columnas de preparación y retiro de pedidos.
  - Pantalla de salón con plano de mesas, estados operativos y platos listos para recoger.
  - Conexión rápida mediante código de 6 dígitos sin contraseña en la red WiFi local (plan Pro).
- **Aviso de Recoger en el Celular**:
  - Notificación en la sección de Avisos del celular del mesero cuando la cocina marca un pedido listo.
  - Botón Entregado para confirmar la entrega a la mesa y activar la alerta "Lista para cuenta".
- **Agentes Especializados con Tareas**:
  - Tres roles con tareas predefinidas: Administración (analista de ventas, márgenes y horarios), Compras (pedidos e insumos) y Marketing (campañas y promociones).
  - Estructura fija de respuestas con cifras clave, explicaciones claras y botones de acción directa como pedidos por WhatsApp o creación de cupones (plan Premium).
- **Perfil del Negocio para la IA**:
  - Tarjeta de configuración para registrar qué ofrece el negocio, público objetivo, elementos diferenciadores, tono de comunicación y colores de marca.
  - Adaptación contextual de las sugerencias y respuestas de los agentes al tipo de negocio real.
- **Respuesta en Vivo para Asistentes de IA**:
  - Generación y visualización progresiva del texto en pantalla (streaming) mientras el modelo analiza la información del negocio.
  - Indicadores visuales de avance por etapas durante el procesamiento.
- **Estudio de Flyers de Marketing**:
  - Creación de piezas publicitarias con plantillas Claro, Oscuro y Foto en formatos Publicación, Historia y Cuadrado.
  - Textos redactados por IA con datos de contacto automáticos y soporte para foto del catálogo, foto generada con IA o imagen subida por el usuario.
  - Descarga directa en formato PNG y botón para compartir por WhatsApp.
- **Tipo de Negocio Servicios**:
  - Incorporación de la categoría Servicios (talleres, lavanderías, peluquerías y afines) en la configuración inicial y catálogo.
  - Adaptación de vocabulario y opciones del sistema a empresas de servicios.
- **Mensajes de Error con Solución Guiada**:
  - Textos descriptivos y pasos claros de resolución para errores comunes de conexión local, sincronización entre versiones, cuotas de imágenes y autorizaciones de IA.
- **Motor de Menú e Ingeniería de Carta**:
  - Clasificación de productos en cinco clases según ventas y margen (Estrellas, Caballos de batalla, Rompecabezas, Para revisar y Sin costo) sobre los últimos 60 días.
  - Diagnóstico con acción sugerida por producto, tendencia de ventas de los últimos 14 días y análisis de productos pedidos juntos en la misma comanda.
  - Medición de tiempos típicos de preparación en cocina (mediana y percentil 80) al trabajar con la pantalla de cocina.
- **Sugerencias al Mesero en Pedidos**:
  - Bloque "Ofrece primero" en caja y celular con 2 o 3 recomendaciones explicadas en una línea.
  - Sugerencias automáticas por productos que se piden juntos, o favoritos y platos de alto margen si el pedido está vacío.
  - Exclusión de productos agotados o pausados, adición con un solo toque y soporte para priorizar platos rápidos en horas de alta demanda.
- **Autopilot Operativo en el Local**:
  - Comparación en tiempo real de la operación frente a lo normal del negocio para ese día y hora sobre 8 semanas de historia.
  - Diagnóstico automático de seis situaciones operativas: saturación de cocina, picos de pedidos, productos por agotarse, sobrecarga de meseros, horas flojas y mesas en espera.
  - Propuestas de intervención con parámetros ajustables (minutos y porcentaje), botón Hacerlo para ejecución automática, reversión al vencer el plazo y opción Deshacer.
  - Vista adaptada por rol (administrador con métricas, cajero operativo sin cifras de ventas ni cupones, mesero solo con avisos) y cálculo 100 % local sin internet (plan Premium).
- **Autopilot en Mi Cuenta para el Dueño**:
  - Notificación de situaciones de gravedad alta por correo electrónico y opción de avisar al dueño por WhatsApp con enlace directo desde la caja.
  - Panel en Mi cuenta → Autopilot para revisar diagnósticos y tomar decisiones (Hacerlo o Descartar) de forma remota, con vencimiento a los 30 minutos.
  - Sincronización automática que recoge la decisión del dueño y la ejecuta en el equipo del local en menos de un minuto cuando hay internet.
- **Interruptores Compactos con Ayuda**:
  - Rediseño de selectores y conmutadores en tarjetas compactas en cuadrícula, incorporando botón de ayuda rápida que despliega la explicación detallada sin sobrecargar la pantalla.
- **Horario Semanal del Personal**:
  - Subpestaña en Personal con cuadrícula semanal interactiva para planificar turnos por colaborador, consultar horas trabajadas y registrar entradas y salidas.
- **Guía para Instalar Pantallas**:
  - Instructivo interactivo dentro de Salón y mesas → Pantallas con recomendaciones de ubicación, requisitos técnicos, emparejamiento con código y solución a fallas de conexión.
- **Probar Conexión de Celulares**:
  - Herramienta de diagnóstico en Usuarios y roles que verifica la conectividad local, detecta bloqueos de Firewall de Windows, perfiles de red pública o múltiples adaptadores, y ofrece el botón Reparar ahora.
- **Ventana al Abrir Mesa**:
  - Diálogo rápido configurable para registrar comensales (1 a 8 o personalizado), descripción de la orden y cliente al tocar una mesa libre, con opción Omitir y edición posterior desde el pedido.
- **Editor del Plano con Kit Completo**:
  - Editor interactivo para Salón y mesas con rejilla magnética (movimiento libre con Shift), guías de alineación, rotación con tecla R, duplicación con Ctrl+D, selección múltiple, elementos estructurales (paredes, puertas, barras, baños) y guardado en un solo paso.
- **3 Flyers con Imagen**:
  - Generación automática de tres conceptos publicitarios listos (Claro, Oscuro y Foto) por solicitud al agente de marketing, incorporando fotos del catálogo o generadas con IA.
- **Ingredientes, Recetas y Kardex**:
  - Control de insumos por gramaje, volumen o unidades, vinculación de recetas a productos con cálculo de costo y margen bruto, deducción automática al cobrar y auditoría en kardex ante compras, ventas, mermas y ajustes.
- **Facturas al Inventario con Cuentas por Pagar**:
  - Digitalización de facturas de compra mediante foto, conciliación asistida de insumos con factores de conversión y actualización de costos promedio ponderados, junto con gestión de pagos a crédito y vencimientos.
- **Pruebas de Carga**:
  - Verificación exhaustiva de estabilidad, tiempos de respuesta y concurrencia en la sincronización de pedidos y pantallas en red local.
- **Campanita de Avisos**:
  - Indicador de avisos en la barra superior en computador y celular, con contador de avisos sin ver y lista de los últimos 7 días (pedidos de la página, reservas, platos listos, cuenta pedida, mesas que esperan y Autopilot).
  - Botón "Borrar todo", almacenamiento local en cada equipo, filtrado de mesas asignadas para meseros y sonido de alerta para platos listos y cuenta pedida.
- **Avisos al Instante**:
  - Actualización inmediata y en tiempo real del plano de mesas, cocina y avisos apenas ocurre cualquier cambio, sin esperas ni recargas.
- **Mesa Ocupada al Abrirla con Colores por Alerta**:
  - Ocupación inmediata de la mesa al tocarla en estado libre, mostrando quién la abrió y etiqueta azul "Abierta" hasta el primer envío a cocina.
  - Colores de alerta con texto descriptivo: verde azulado con "Listo en cocina", rosado/rojo para cuenta pedida (más intenso al doble del tiempo configurado), ámbar/naranja tras tiempo sin pedir y azul claro cuando fue servida hace rato.
- **Receta con "Se puede quitar" y Modo Sin Receta**:
  - Pestaña "Con receta" con ingredientes de inventario y casilla "Se puede quitar" para pedir "sin" en los comentarios, con costo bloqueado calculado desde la receta.
  - Pestaña "Sin receta" para negocios sin inventario de ingredientes, con lista de lo que se puede quitar en comentarios, costo manual en Editar producto y borrado de receta anterior al guardar.

### Corregido
- **Montos en Pago por Turno**:
  - Corrección en la validación de montos en pesos que impedía ingresar valores como 8.500 al exigir pasos de 1.000, permitiendo ahora cualquier valor entero o paso estándar.
- **Pantalla de Cocina con Pedidos Viejos**:
  - Corrección para mostrar únicamente pedidos enviados en las últimas 6 horas y ocultar de inmediato mesas ya cobradas, dejando pedidos de mostrador cobrados hasta 90 minutos o hasta marcarlos listos.
- **Aviso de Listo en la Mesa**:
  - Corrección en la notificación y distintivo de platos listos en cocina para que se actualice correctamente en la mesa correspondiente.
- **Pago por Productos que Dejaba el Producto en la Mesa**:
  - Corrección en el cobro individual de productos para descontar de inmediato de la mesa los ítems que ya fueron pagados.
- **Botón de Enviar Cortado en el Celular**:
  - Corrección visual en la vista móvil para celulares donde el botón de enviar comanda se mostraba recortado.
- **Productos Pausados que Seguían en la Página**:
  - Corrección para ocultar de inmediato de la página web del negocio los productos pausados por Autopilot, impidiendo que continúen vendiéndose.

---

## [2.0.0] - 2026-10-21

### Añadido
- **Histórico de Comandas por Rondas**:
  - Control secuencial de rondas (`Ronda #1`, `Ronda #2`, etc.) al enviar pedidos a cocina desde mesas y mostrador.
  - Registro de hora fija de comanda (`HH:mm`) y cálculo automático de tiempo transcurrido en vivo.
  - Semáforo de cocina: verde (<15 min: a tiempo), amarillo (15-30 min: en espera) y rojo pulsante (>30 min: demorado).
  - Identificación de ronda y hora en la impresión de comandas térmicas.
- **Anulación Parcial de Productos con Clave de Administrador**:
  - Bloqueo de cancelación en productos ya comandados (`isOrdered = true`) requiriendo autenticación administrativa (`POST /api/auth/verify-admin`).
  - Selección flexible de unidades a cancelar (anulación parcial o total sin eliminar la comanda completa).
  - Catálogo de motivos predefinidos ("El cliente lo cancela", "Error de digitación", etc.) y comentarios opcionales.
  - Selector de destino de inventario ("Desechar / Merma" vs "Reintegrar a Stock").
  - Auditoría visual en la cuenta y registro auditable en base de datos.
- **Módulo de Facturación Electrónica DIAN y Factus Cloud**:
  - Emisión de facturas electrónicas con generación reglamentaria de CUFE (SHA-384) y código QR.
  - Integración desacoplada y modo de hibernación sin costos fijos para API Factus Cloud.
- **Plano de Mesas y Ergonomía Visual**:
  - Plano de planta interactivo con editor de zonas, layout táctil y split-screen de mostrador.
  - Sistema de temas y diseño corporativo Lantify POS.

---

## [1.0.0] - 2026-09-10

### Añadido
- **Módulo de Inventario**:
  - Control de seguimiento (toggle ON/OFF) por producto y variante.
  - Conteo físico de inventario con detección de diferencias de stock.
  - Justificación obligatoria para cualquier discrepancia en el conteo físico.
  - Ajustes manuales rápidos de stock (+ / -).
  - Descuento automático de stock al completar una venta (`SALE`).
  - Reversión automática de stock al cancelar una venta o anular un item (`ADJUSTMENT`).
  - Historial completo de movimientos de stock auditable.
  - Integrado de forma intuitiva en el panel de administración.
- **Pestaña de Gastos en Arqueo Mensual**:
  - Filtros avanzados por mes, por arqueo/sesión específica, por categoría y por texto.
  - Tarjetas KPI con total de gastos, gasto promedio y categoría de mayor impacto.
  - Gráfica/barras de distribución de gastos por categoría con porcentajes de participación.
  - Exportación profesional en formato Excel (`.xlsx`) con múltiples hojas formateadas (Resumen por Categoría y Detalle Individual).
- **Sub-pestaña de Movimientos de Caja**:
  - Cronología unificada de todas las operaciones financieras (ventas, entradas manuales, egresos).
  - Filtros por tipo de movimiento, método de pago (efectivo, tarjeta, transferencia, mixto) y sesión.
  - Métricas de flujo neto de caja (entradas vs. salidas).
  - Exportación a Excel (`.xlsx`) con balance consolidado.
- **Sistema de Actualización y Versionamiento**:
  - Script `update.bat` con migración de base de datos segura, respaldo automático y rollback en caso de fallos.
  - Respaldo rotativo de base de datos SQLite en `scripts/backup-db.js` (conserva hasta 5 backups históricos).
  - Visor interactivo de notas de versión en consola (`scripts/show-changelog.js`).
  - Indicador visual de versión `v1.0.0` en la barra superior del POS con modal de novedades.

### Corregido
- **Precios Históricos en Top Productos**:
  - Se corrigió el cálculo en `AnalyticsUseCases` para calcular el precio promedio ponderado a partir del recaudo histórico real de cada venta, evitando que cambios futuros de precio distorsionen reportes anteriores.
- **Detalle de Ingresos y Egresos en Arqueos**:
  - Se añadieron las relaciones `incomesDetails` y `expensesDetails` en las consultas de `CashSessionRepository` (`getAll`, `getById`, `getByDateRange`), solucionando el bug donde no figuraban los movimientos en los KPIs, secciones expandibles ni en la exportación CSV.
- **Márgenes y Layout**:
  - Se corrigió el estiramiento horizontal en vistas con pocos elementos como Caja, Reportes y Ventas mediante contenedores centrados (`max-w-2xl`, `max-w-6xl mx-auto`).
  - Se mantuvo el modo de pantalla completa para la toma de órdenes y comandas de mesas.
