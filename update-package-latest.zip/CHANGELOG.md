# Changelog — Lantify POS

Todas las modificaciones notables de este proyecto están documentadas en este archivo.
El formato se basa en [Keep a Changelog](https://keepachangelog.com/es-ES/1.0.0/) y este proyecto se adhiere a [Semantic Versioning](https://semver.org/lang/es/).

---

## [2.0.0] - 2026-10-21

### Añadido
- **Histórico de Comandas por Rondas**:
  - Control secuencial de rondas (`Ronda #1`, `Ronda #2`, etc.) al enviar pedidos a cocina desde mesas y mostrador.
  - Registro de hora fija de comanda (`HH:mm`) y cálculo automático de tiempo transcurrido en vivo.
  - Semáforo de cocina: verde (<15 min: a tiempo), amarillo (15-30 min: en espera) y rojo pulsante (>30 min: demorado).
  - Identificación de ronda y hora en la impresión de comandas térmicas.
- **Anulación Parcial de Productos con Clave de Administrador**:
  - Bloqueo de cancelación en productos ya comandados (`isOrdered = true`) requiriendo autenticación administrativa (`POST /api/auth/verify-admin`).
  - Selección flexible de unidades a cancelar (anulación parcial o total sin eliminar la comanda completa).
  - Catálogo de motivos predefinidos ("El cliente lo cancela", "Error de digitación", etc.) y comentarios opcionales.
  - Selector de destino de inventario ("Desechar / Merma" vs "Reintegrar a Stock").
  - Auditoría visual en la cuenta y registro auditable en base de datos.
- **Módulo de Facturación Electrónica DIAN y Factus Cloud**:
  - Emisión de facturas electrónicas con generación reglamentaria de CUFE (SHA-384) y código QR.
  - Integración desacoplada y modo de hibernación sin costos fijos para API Factus Cloud.
- **Plano de Mesas y Ergonomía Visual**:
  - Plano de planta interactivo con editor de zonas, layout táctil y split-screen de mostrador.
  - Sistema de temas y diseño corporativo Lantify POS.

---

## [1.0.0] - 2026-09-10

### Añadido
- **Módulo de Inventario**:
  - Control de seguimiento (toggle ON/OFF) por producto y variante.
  - Conteo físico de inventario con detección de diferencias de stock.
  - Justificación obligatoria para cualquier discrepancia en el conteo físico.
  - Ajustes manuales rápidos de stock (+ / -).
  - Descuento automático de stock al completar una venta (`SALE`).
  - Reversión automática de stock al cancelar una venta o anular un item (`ADJUSTMENT`).
  - Historial completo de movimientos de stock auditable.
  - Integrado de forma intuitiva en el panel de administración.
- **Pestaña de Gastos en Arqueo Mensual**:
  - Filtros avanzados por mes, por arqueo/sesión específica, por categoría y por texto.
  - Tarjetas KPI con total de gastos, gasto promedio y categoría de mayor impacto.
  - Gráfica/barras de distribución de gastos por categoría con porcentajes de participación.
  - Exportación profesional en formato Excel (`.xlsx`) con múltiples hojas formateadas (Resumen por Categoría y Detalle Individual).
- **Sub-pestaña de Movimientos de Caja**:
  - Cronología unificada de todas las operaciones financieras (ventas, entradas manuales, egresos).
  - Filtros por tipo de movimiento, método de pago (efectivo, tarjeta, transferencia, mixto) y sesión.
  - Métricas de flujo neto de caja (entradas vs. salidas).
  - Exportación a Excel (`.xlsx`) con balance consolidado.
- **Sistema de Actualización y Versionamiento**:
  - Script `update.bat` con migración de base de datos segura, respaldo automático y rollback en caso de fallos.
  - Respaldo rotativo de base de datos SQLite en `scripts/backup-db.js` (conserva hasta 5 backups históricos).
  - Visor interactivo de notas de versión en consola (`scripts/show-changelog.js`).
  - Indicador visual de versión `v1.0.0` en la barra superior del POS con modal de novedades.

### Corregido
- **Precios Históricos en Top Productos**:
  - Se corrigió el cálculo en `AnalyticsUseCases` para calcular el precio promedio ponderado a partir del recaudo histórico real de cada venta, evitando que cambios futuros de precio distorsionen reportes anteriores.
- **Detalle de Ingresos y Egresos en Arqueos**:
  - Se añadieron las relaciones `incomesDetails` y `expensesDetails` en las consultas de `CashSessionRepository` (`getAll`, `getById`, `getByDateRange`), solucionando el bug donde no figuraban los movimientos en los KPIs, secciones expandibles ni en la exportación CSV.
- **Márgenes y Layout**:
  - Se corrigió el estiramiento horizontal en vistas con pocos elementos como Caja, Reportes y Ventas mediante contenedores centrados (`max-w-2xl`, `max-w-6xl mx-auto`).
  - Se mantuvo el modo de pantalla completa para la toma de órdenes y comandas de mesas.
