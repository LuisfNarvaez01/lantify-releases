// ============================================
// CONFIG - Dirección única del backend
// ============================================
// Se puede cambiar con VITE_API_URL (por ejemplo, para una tablet en la red local).

const DEFAULT_API_URL = 'http://localhost:5000/api';

// Versiones anteriores traían frontend/.env con el puerto 3000, que nunca se usó
// (el backend corre en 5000). Se ignora para no romper terminales ya instaladas.
const LEGACY_UNUSED_URLS = new Set(['http://localhost:3000/api']);

const fromEnv: string | undefined = (import.meta as any).env?.VITE_API_URL;

export const API_URL: string = fromEnv && !LEGACY_UNUSED_URLS.has(fromEnv) ? fromEnv : DEFAULT_API_URL;

