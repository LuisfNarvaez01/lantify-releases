// ============================================
// SCRIPT - Database Backup & Safe Recovery Protocol
// ============================================

const fs = require('fs');
const path = require('path');

const ROOT_DIR = path.resolve(__dirname, '..');
const POTENTIAL_DB_PATHS = [
  path.join(ROOT_DIR, 'prisma', 'prisma', 'dev.db'),
  path.join(ROOT_DIR, 'prisma', 'dev.db'),
];
const BACKUP_DIR = path.join(ROOT_DIR, 'backups');
const MAX_BACKUPS = 15;

/**
 * Obtiene todas las rutas de base de datos activas existentes.
 */
function getActiveDbFiles() {
  const found = [];
  for (const dbPath of POTENTIAL_DB_PATHS) {
    if (fs.existsSync(dbPath)) {
      found.push(dbPath);
    }
  }
  return found;
}

/**
 * Genera un respaldo seguro verificado de la base de datos SQLite y archivos WAL.
 * Valida tamaño del archivo y consistencia antes y después de la copia.
 */
function runBackup() {
  const activeFiles = getActiveDbFiles();
  if (activeFiles.length === 0) {
    console.log('⚠️ [Backup] No se encontró dev.db en prisma/ ni prisma/prisma/, saltando respaldo.');
    return null;
  }

  if (!fs.existsSync(BACKUP_DIR)) {
    fs.mkdirSync(BACKUP_DIR, { recursive: true });
  }

  const now = new Date();
  const timestamp = now.toISOString().replace(/[:.]/g, '-');
  const backedUp = [];

  for (const dbPath of activeFiles) {
    const stat = fs.statSync(dbPath);
    const relPrefix = dbPath.includes(path.join('prisma', 'prisma')) ? 'nested' : 'root';
    const backupFileName = `dev.db.${relPrefix}.${timestamp}`;
    const targetPath = path.join(BACKUP_DIR, backupFileName);

    try {
      fs.copyFileSync(dbPath, targetPath);

      // Copiar también archivos WAL y SHM si existen
      const walPath = `${dbPath}-wal`;
      const shmPath = `${dbPath}-shm`;
      if (fs.existsSync(walPath)) fs.copyFileSync(walPath, `${targetPath}-wal`);
      if (fs.existsSync(shmPath)) fs.copyFileSync(shmPath, `${targetPath}-shm`);

      // Validación estricta de consistencia en bytes
      const targetStat = fs.statSync(targetPath);
      if (targetStat.size !== stat.size) {
        fs.unlinkSync(targetPath);
        throw new Error(`Inconsistencia en el respaldo: origen (${stat.size} bytes) vs destino (${targetStat.size} bytes).`);
      }

      console.log(`✅ [Backup] Respaldo verificado con éxito: ${backupFileName} (${(stat.size / 1024).toFixed(1)} KB)`);
      backedUp.push(targetPath);
    } catch (err) {
      console.error(`❌ [Backup] ERROR CRÍTICO al respaldar ${dbPath}:`, err);
      throw err;
    }
  }

  try {
    // Rotación de backups: conservar los MAX_BACKUPS más recientes
    const files = fs.readdirSync(BACKUP_DIR)
      .filter(f => f.startsWith('dev.db.'))
      .map(f => ({
        name: f,
        fullPath: path.join(BACKUP_DIR, f),
        time: fs.statSync(path.join(BACKUP_DIR, f)).mtime.getTime()
      }))
      .sort((a, b) => b.time - a.time);

    if (files.length > MAX_BACKUPS) {
      const toDelete = files.slice(MAX_BACKUPS);
      for (const f of toDelete) {
        fs.unlinkSync(f.fullPath);
        console.log(`🧹 [Backup] Depurado backup antiguo: ${f.name}`);
      }
    }

    return backedUp;
  } catch (err) {
    console.error('❌ [Backup] Error en rotación de respaldos:', err);
    return backedUp;
  }
}

/**
 * Restaura automáticamente el respaldo más reciente en caso de fallo crítico.
 */
function restoreLatestBackup() {
  if (!fs.existsSync(BACKUP_DIR)) {
    console.error('❌ [Rollback] No existe carpeta de respaldos.');
    return false;
  }

  const files = fs.readdirSync(BACKUP_DIR)
    .filter(f => f.startsWith('dev.db.'))
    .map(f => ({
      name: f,
      fullPath: path.join(BACKUP_DIR, f),
      time: fs.statSync(path.join(BACKUP_DIR, f)).mtime.getTime(),
      size: fs.statSync(path.join(BACKUP_DIR, f)).size
    }))
    .filter(f => f.size > 0)
    .sort((a, b) => b.time - a.time);

  if (files.length === 0) {
    console.error('❌ [Rollback] No hay respaldos válidos disponibles para restaurar.');
    return false;
  }

  const latest = files[0];
  console.log(`🔄 [Rollback] Restaurando base de datos desde el respaldo: ${latest.name}...`);

  const activeFiles = getActiveDbFiles();
  const targetDbs = activeFiles.length > 0 ? activeFiles : [path.join(ROOT_DIR, 'prisma', 'dev.db')];

  try {
    for (const target of targetDbs) {
      fs.copyFileSync(latest.fullPath, target);
      console.log(`✅ [Rollback] Base de datos restaurada exitosamente en ${path.relative(ROOT_DIR, target)}.`);
    }
    return true;
  } catch (err) {
    console.error('❌ [Rollback] Error al restaurar respaldo:', err);
    return false;
  }
}

if (require.main === module) {
  const arg = process.argv[2];
  if (arg === '--restore') {
    restoreLatestBackup();
  } else {
    runBackup();
  }
}

module.exports = { runBackup, restoreLatestBackup };
