// ============================================
// SCRIPT - Show Changelog in Console
// ============================================

const fs = require('fs');
const path = require('path');

const ROOT_DIR = path.resolve(__dirname, '..');
const VERSION_PATH = path.join(ROOT_DIR, 'version.json');
const CHANGELOG_PATH = path.join(ROOT_DIR, 'CHANGELOG.md');

function showChangelog() {
  console.log('\n======================================================');
  console.log('            LANTIFY POS — ACTUALIZACIÓN              ');
  console.log('======================================================\n');

  if (fs.existsSync(VERSION_PATH)) {
    try {
      const vData = JSON.parse(fs.readFileSync(VERSION_PATH, 'utf-8'));
      console.log(`🚀 Versión instalada: v${vData.version} (${vData.buildDate})`);
      if (vData.releaseName) console.log(`📦 Release: ${vData.releaseName}`);
      if (vData.changelog) console.log(`📝 Resumen: ${vData.changelog}\n`);

      if (vData.features && Array.isArray(vData.features)) {
        console.log('✨ Novedades principales:');
        vData.features.forEach((feat, idx) => {
          console.log(`   ${idx + 1}. ${feat}`);
        });
      }
    } catch (e) {
      console.error('Error al leer version.json:', e.message);
    }
  }

  console.log('\n======================================================');
  console.log('       Sistema listo y actualizado con éxito.        ');
  console.log('======================================================\n');
}

if (require.main === module) {
  showChangelog();
}

module.exports = { showChangelog };
