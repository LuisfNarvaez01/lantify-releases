// ============================================
// COMPONENTS - Monthly Arqueo Report
// ============================================

import { useState, useEffect, useMemo } from 'react';
import {
  BarChart2, TrendingUp, TrendingDown, DollarSign,
  Banknote, CreditCard, Smartphone, FileDown, RefreshCw,
  CalendarDays, ChevronDown, ChevronRight, CheckCircle2,
  XCircle, Wallet, ArrowLeft, Receipt, AlertCircle, Scale
} from 'lucide-react';
import { formatCurrency } from '../../shared/formatUtils';
import { ExpenseReportTab } from './ExpenseReportTab';
import { CashMovementsTab } from './CashMovementsTab';

import { API_URL } from '../../config';
import { t, getLocale } from '../../i18n';
const getToken = () => localStorage.getItem('token');



interface MonthlyArqueoReportProps {
  onClose: () => void;
}

// ── helpers ──────────────────────────────────────────────────

function monthKey(date: Date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
}

function monthLabel(key: string) {
  const [y, m] = key.split('-');
  const label = new Date(parseInt(y), parseInt(m) - 1, 1).toLocaleDateString(getLocale(), { month: 'long', year: 'numeric' });
  return label.charAt(0).toUpperCase() + label.slice(1);
}

/** Compute full stats for one month given its sessions and their sales */
function buildMonthStats(sessions: any[], allSales: any[]) {
  // Sales in this set of sessions (by cashSessionId)
  const sessionIds = new Set(sessions.map((s: any) => s.id));
  const sales = allSales.filter((s: any) => sessionIds.has(s.cashSessionId));
  const completedSales = sales.filter((s: any) => s.status === 'COMPLETED');

  const salesTotal  = completedSales.reduce((n: number, s: any) => n + (s.total ?? 0), 0);
  const salesCash   = completedSales.filter((s: any) => s.paymentMethod === 'CASH').reduce((n: number, s: any) => n + (s.total ?? 0), 0);
  const salesCard   = completedSales.filter((s: any) => s.paymentMethod === 'CARD').reduce((n: number, s: any) => n + (s.total ?? 0), 0);
  const salesTransfer = completedSales.filter((s: any) => s.paymentMethod === 'TRANSFER').reduce((n: number, s: any) => n + (s.total ?? 0), 0);

  // Manual movements (active only)
  let manualIncome = 0;
  let manualExpense = 0;
  const allIncomes: any[] = [];
  const allExpenses: any[] = [];

  sessions.forEach((sess: any) => {
    (sess.incomesDetails ?? []).forEach((inc: any) => {
      allIncomes.push({ ...inc, sessionNumber: sess.sessionNumber });
      if (!inc.isCancelled) manualIncome += inc.amount ?? 0;
    });
    (sess.expensesDetails ?? []).forEach((exp: any) => {
      allExpenses.push({ ...exp, sessionNumber: sess.sessionNumber });
      // Lo pagado por banco, tarjeta o Nequi queda en el arqueo pero no sale del cajón
      if (!exp.isCancelled && (exp.paymentSource ?? 'CASH_DRAWER') === 'CASH_DRAWER') manualExpense += exp.amount ?? 0;
    });
  });

  const initialBalance = sessions.reduce((n: number, s: any) => n + (s.initialBalance ?? 0), 0);
  const netCash = salesCash + manualIncome - manualExpense + initialBalance;

  return {
    sessions,
    sales,
    completedSales,
    salesTotal,
    salesCash,
    salesCard,
    salesTransfer,
    manualIncome,
    manualExpense,
    initialBalance,
    netCash,
    allIncomes,
    allExpenses,
  };
}

// ── Sub-components ────────────────────────────────────────────

const StatCard = ({ icon, label, value, sub, accent = '#0f172a', light = false }:
  { icon: React.ReactNode; label: string; value: string; sub?: string; accent?: string; light?: boolean }) => (
  <div
    className="rounded-2xl p-5 flex flex-col gap-2 shadow-sm relative overflow-hidden group border"
    style={{ background: light ? '#fff' : accent, borderColor: light ? '#e2e8f0' : 'transparent' }}
  >
    <div className="absolute -right-3 -top-3 w-16 h-16 rounded-full opacity-10 group-hover:opacity-20 transition-opacity"
      style={{ background: light ? accent : '#fff' }} />
    <div className="flex items-center justify-between relative z-10">
      <span className="text-xs font-black uppercase tracking-widest" style={{ color: light ? '#64748b' : '#94a3b8' }}>{label}</span>
      <span style={{ color: light ? accent : '#60a5fa' }}>{icon}</span>
    </div>
    <p className="text-2xl font-black tracking-tight relative z-10 tabular-nums" style={{ color: light ? '#0f172a' : '#fff' }}>{value}</p>
    {sub && <p className="text-xs font-medium relative z-10" style={{ color: light ? '#64748b' : '#94a3b8' }}>{sub}</p>}
  </div>
);

const MovementRow = ({ item, type }: { item: any; type: 'INCOME' | 'EXPENSE' }) => (
  <div className={`flex items-center gap-3 px-4 py-2.5 rounded-xl border transition-all text-sm
    ${item.isCancelled
      ? 'bg-gray-50 border-gray-100 opacity-50'
      : type === 'INCOME'
        ? 'bg-emerald-50/60 border-emerald-100 hover:bg-emerald-50'
        : 'bg-red-50/60 border-red-100 hover:bg-red-50'
    }`}>
    <div className={`w-2 h-2 rounded-full flex-shrink-0 ${item.isCancelled ? 'bg-gray-300' : type === 'INCOME' ? 'bg-emerald-500' : 'bg-red-500'}`} />
    <div className="flex-1 min-w-0">
      <p className={`font-bold truncate ${item.isCancelled ? 'line-through text-gray-400' : 'text-gray-800'}`}>{item.motive}</p>
      {item.description && !item.isCancelled && (
        <p className="text-xs text-gray-500 italic truncate">{item.description}</p>
      )}
      <p className="text-xs text-gray-400 mt-0.5">
        {t('cash:arqueo_sessionnumber_value', { sessionNumber: item.sessionNumber, value: new Date(item.createdAt).toLocaleDateString(getLocale(), { day: '2-digit', month: 'short' }) })}
        {item.isCancelled && <span className="ml-2 text-red-400 font-bold">{t('cash:anulado_2')}</span>}
      </p>
    </div>
    <span className={`font-black text-sm flex-shrink-0 ${item.isCancelled ? 'text-gray-300 line-through' : type === 'INCOME' ? 'text-emerald-700' : 'text-red-700'}`}>
      {type === 'INCOME' ? '+' : '-'}{formatCurrency(item.amount)}
    </span>
  </div>
);

// ── Main Component ────────────────────────────────────────────

export const MonthlyArqueoReport: React.FC<MonthlyArqueoReportProps> = ({ onClose }) => {
  const [sessions, setSessions] = useState<any[]>([]);
  const [sales, setSales] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedMonth, setSelectedMonth] = useState<string>('');
  const [subTab, setSubTab] = useState<'summary' | 'expenses' | 'movements'>('summary');
  const [expandedSection, setExpandedSection] = useState<string | null>('movements');
  const [config, setConfig] = useState<any>({});

  useEffect(() => {
    const savedConfig = localStorage.getItem('posConfig');
    if (savedConfig) setConfig(JSON.parse(savedConfig));
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const token = getToken();
      const [sessRes, salesRes] = await Promise.all([
        fetch(`${API_URL}/cash-sessions`, { headers: { Authorization: `Bearer ${token}` } }),
        fetch(`${API_URL}/sales`,          { headers: { Authorization: `Bearer ${token}` } }),
      ]);
      if (sessRes.ok)  setSessions(await sessRes.json());
      if (salesRes.ok) setSales(await salesRes.json());
    } catch (err) {
      console.error('Error loading report data:', err);
    }
    setLoading(false);
  };

  // ── Group sessions by month ──────────────────────────────
  const monthGroups = useMemo(() => {
    const groups: Record<string, any[]> = {};
    sessions.forEach(s => {
      const key = monthKey(new Date(s.openedAt));
      if (!groups[key]) groups[key] = [];
      groups[key].push(s);
    });
    return Object.entries(groups).sort((a, b) => b[0].localeCompare(a[0]));
  }, [sessions]);

  // Auto-select most recent month
  useEffect(() => {
    if (monthGroups.length > 0 && !selectedMonth) {
      setSelectedMonth(monthGroups[0][0]);
    }
  }, [monthGroups]);

  const currentMonthSessions = useMemo(
    () => monthGroups.find(([k]) => k === selectedMonth)?.[1] ?? [],
    [monthGroups, selectedMonth]
  );

  const stats = useMemo(
    () => buildMonthStats(currentMonthSessions, sales),
    [currentMonthSessions, sales]
  );

  // ── Export CSV ─────────────────────────────────────────────
  const handleExport = () => {
    const businessName = config.businessName || t('cash:lantify_pos');
    const SEP = ';';
    const line = (...cols: (string | number)[]) => cols.map(c => String(c ?? '')).join(SEP);
    const rows: string[] = [];

    const mLabel = monthLabel(selectedMonth);

    rows.push(line('', '', '', '', '', ''));
    rows.push(line(`INFORME MENSUAL DE CAJA — ${businessName}`, '', '', '', '', ''));
    rows.push(line(t('cash:periodo_mlabel', { mLabel }), '', '', '', '', ''));
    if (config.address) rows.push(line(t('cash:direccion_address', { address: config.address }), '', '', '', '', ''));
    if (config.nit)     rows.push(line(`NIT: ${config.nit}`, '', '', '', '', ''));
    rows.push(line(t('cash:generado_value', { value: new Date().toLocaleString(getLocale()) }), '', '', '', '', ''));
    rows.push(line('', '', '', '', '', ''));

    // ── KPI summary ──
    rows.push(line(t('cash:resumen_financiero_del_mes'), '', '', '', '', ''));
    rows.push(line(t('cash:concepto'), t('cash:monto_cop'), '', '', '', ''));
    rows.push(line(t('cash:saldo_inicial_de_caja_acumulado'), stats.initialBalance.toFixed(0), '', '', '', ''));
    rows.push(line(t('cash:ventas_completadas'), stats.salesTotal.toFixed(0), '', '', '', ''));
    rows.push(line(t('cash:efectivo_2'), stats.salesCash.toFixed(0), '', '', '', ''));
    rows.push(line(t('cash:tarjeta_2'), stats.salesCard.toFixed(0), '', '', '', ''));
    rows.push(line(t('cash:transferencia_2'), stats.salesTransfer.toFixed(0), '', '', '', ''));
    rows.push(line(t('cash:ingresos_manuales_activos'), stats.manualIncome.toFixed(0), '', '', '', ''));
    rows.push(line(t('cash:egresos_manuales_activos'), stats.manualExpense.toFixed(0), '', '', '', ''));
    rows.push(line(t('cash:balance_neto_de_caja_efectivo'), stats.netCash.toFixed(0), '', '', '', ''));
    rows.push(line('', '', '', '', '', ''));

    // ── Sessions ──
    rows.push(line(t('cash:arqueos_del_mes'), '', '', '', '', ''));
    rows.push(line(t('cash:arqueo'), t('cash:apertura'), t('cash:cierre'), t('cash:saldo_inicial'), t('cash:estado'), t('cash:ventas_en_sesion')));
    stats.sessions.forEach((sess: any) => {
      const sesssSales = stats.completedSales.filter((s: any) => s.cashSessionId === sess.id);
      const sesssTotal = sesssSales.reduce((n: number, s: any) => n + (s.total ?? 0), 0);
      rows.push(line(
        sess.sessionNumber,
        new Date(sess.openedAt).toLocaleString(getLocale()),
        sess.closedAt ? new Date(sess.closedAt).toLocaleString(getLocale()) : 'ABIERTO',
        (sess.initialBalance ?? 0).toFixed(0),
        sess.status === 'OPEN' ? t('cash:abierto') : t('cash:cerrado'),
        sesssTotal.toFixed(0)
      ));
    });
    rows.push(line('', '', '', '', '', ''));

    // ── Manual Incomes ──
    rows.push(line(t('cash:ingresos_manuales'), '', '', '', '', ''));
    rows.push(line(t('cash:tipo'), t('cash:monto'), t('cash:motivo'), t('cash:descripcion'), t('cash:fecha'), t('cash:arqueo')));
    stats.allIncomes.forEach((inc: any) => {
      rows.push(line(
        inc.isCancelled ? t('cash:ingreso_anulado') : 'INGRESO',
        inc.isCancelled ? '0' : inc.amount.toFixed(0),
        inc.motive || '',
        inc.description || '',
        new Date(inc.createdAt).toLocaleString(getLocale()),
        inc.sessionNumber
      ));
    });
    if (stats.allIncomes.length === 0) rows.push(line(t('cash:sin_ingresos_manuales_registrados'), '', '', '', '', ''));
    rows.push(line('', '', '', '', '', ''));

    // ── Manual Expenses ──
    rows.push(line(t('cash:egresos_manuales'), '', '', '', '', ''));
    rows.push(line(t('cash:tipo'), t('cash:monto'), t('cash:motivo'), t('cash:descripcion'), t('cash:fecha'), t('cash:arqueo')));
    stats.allExpenses.forEach((exp: any) => {
      rows.push(line(
        exp.isCancelled ? t('cash:egreso_anulado') : 'EGRESO',
        exp.isCancelled ? '0' : exp.amount.toFixed(0),
        exp.motive || '',
        exp.description || '',
        new Date(exp.createdAt).toLocaleString(getLocale()),
        exp.sessionNumber
      ));
    });
    if (stats.allExpenses.length === 0) rows.push(line(t('cash:sin_egresos_registrados'), '', '', '', '', ''));
    rows.push(line('', '', '', '', '', ''));

    // ── Sales detail ──
    rows.push(line(t('cash:detalle_de_ventas'), '', '', '', '', ''));
    rows.push(line(t('cash:venta_2'), t('cash:fecha'), t('cash:metodo'), t('cash:estado'), t('cash:total'), t('cash:arqueo')));
    stats.sales.forEach((s: any) => {
      const sessNum = stats.sessions.find((ss: any) => ss.id === s.cashSessionId)?.sessionNumber ?? '-';
      rows.push(line(
        s.saleNumber,
        new Date(s.createdAt).toLocaleString(getLocale()),
        s.paymentMethod,
        s.status,
        (s.total ?? 0).toFixed(0),
        sessNum
      ));
    });
    rows.push(line('', '', '', '', '', ''));
    rows.push(line(t('cash:fin_del_informe_businessname', { businessName }), '', '', '', '', ''));

    const csv = '\uFEFF' + rows.join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `informe_mensual_caja_${mLabel.replace(' ', '_')}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // ── Loading ────────────────────────────────────────────────
  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-64 gap-4">
        <div className="w-10 h-10 border-4 border-slate-200 border-t-blue-600 rounded-full animate-spin" />
        <p className="text-sm font-bold text-slate-700 animate-pulse">{t('cash:cargando_informe_mensual')}</p>
      </div>
    );
  }

  if (monthGroups.length === 0) {
    return (
      <div className="space-y-6">
        <button onClick={onClose} className="flex items-center gap-2 text-slate-500 hover:text-slate-800 font-bold text-sm transition-colors">
          <ArrowLeft className="w-4 h-4" />{' '}{t('cash:volver_a_caja')}
        </button>
        <div className="bg-white rounded-3xl border-2 border-dashed border-slate-200 text-center py-24">
          <AlertCircle className="w-14 h-14 text-slate-300 mx-auto mb-4" />
          <p className="text-xl font-black text-slate-800">{t('cash:sin_historial_de_arqueos')}</p>
          <p className="text-slate-400 mt-2 font-medium">{t('cash:abre_y_cierra_tu_primer_arqueo_de')}</p>
        </div>
      </div>
    );
  }

  const toggle = (s: string) => setExpandedSection(expandedSection === s ? null : s);

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-12">

      {/* ── Header ── */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            onClick={onClose}
            className="p-2 rounded-xl hover:bg-slate-100 text-slate-700 transition-colors"
            title={t('cash:volver')}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-2xl font-black text-slate-900 tracking-tight">{t('cash:informe_mensual_de_caja')}</h2>
            <p className="text-xs text-slate-500 font-medium">{t('cash:ingresos_egresos_ventas_por_mes')}</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Month selector */}
          <div className="flex flex-col gap-0.5">
            <label className="text-xs font-black uppercase tracking-widest text-slate-500 px-1 flex items-center gap-1">
              <CalendarDays className="w-3 h-3 text-blue-600" />{' '}{t('cash:mes')}
            </label>
            <select
              value={selectedMonth}
              onChange={e => setSelectedMonth(e.target.value)}
              className="text-sm font-bold px-4 py-2.5 border border-slate-200 rounded-xl bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 focus:outline-none text-slate-800 cursor-pointer transition-all"
            >
              {monthGroups.map(([key]) => (
                <option key={key} value={key}>{monthLabel(key)}</option>
              ))}
            </select>
          </div>

          <button
            onClick={loadData}
            className="p-2.5 rounded-xl bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 transition-all mt-4"
            title={t('cash:recargar')}
          >
            <RefreshCw className="w-4 h-4" />
          </button>

          <button
            onClick={handleExport}
            disabled={!selectedMonth}
            className="flex items-center gap-2 text-white px-5 py-2.5 rounded-xl font-bold shadow-sm shadow-emerald-600/20 hover:bg-emerald-700 bg-emerald-600 transition-all disabled:opacity-50 mt-4 active:scale-[0.98]"
          >
            <FileDown className="w-4 h-4" />
            {t('cash:exportar_informe')}
          </button>
        </div>
      </div>

      {/* ── Sub-Tabs Navigation ── */}
      <div className="flex flex-wrap items-center gap-2 bg-slate-100 p-1.5 rounded-2xl border border-slate-200">
        <button
          onClick={() => setSubTab('summary')}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs transition-all ${
            subTab === 'summary'
              ? 'bg-slate-900 text-white shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <BarChart2 className="w-4 h-4" />
          <span>{t('cash:resumen_de_arqueos')}</span>
        </button>

        <button
          onClick={() => setSubTab('expenses')}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs transition-all ${
            subTab === 'expenses'
              ? 'bg-slate-900 text-white shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <TrendingDown className="w-4 h-4" />
          <span>{t('cash:informe_de_gastos')}</span>
        </button>

        <button
          onClick={() => setSubTab('movements')}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs transition-all ${
            subTab === 'movements'
              ? 'bg-slate-900 text-white shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Wallet className="w-4 h-4" />
          <span>{t('cash:movimientos_de_caja')}</span>
        </button>
      </div>

      {/* ── Sub-Tab Views ── */}
      {subTab === 'expenses' && (
        <ExpenseReportTab
          sessions={sessions}
          selectedMonth={selectedMonth}
          config={config}
        />
      )}

      {subTab === 'movements' && (
        <CashMovementsTab
          sessions={sessions}
          sales={sales}
          selectedMonth={selectedMonth}
          config={config}
        />
      )}

      {subTab === 'summary' && selectedMonth && (
        <>
          {/* ── Month title banner ── */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl px-8 py-5 flex items-center justify-between shadow-xl relative overflow-hidden">
            <div className="absolute inset-0 opacity-5"
              style={{ backgroundImage: 'repeating-linear-gradient(45deg, #fff 0, #fff 1px, transparent 0, transparent 50%)', backgroundSize: '10px 10px' }} />
            <div className="relative z-10">
              <p className="text-blue-400 text-xs font-black uppercase tracking-[0.2em] mb-1">{t('cash:periodo_analizado')}</p>
              <h3 className="text-3xl font-black text-white">{monthLabel(selectedMonth)}</h3>
              <p className="text-slate-400 text-xs font-medium mt-1">
                {t('cash:sesiones_count', { count: stats.sessions.length })}{' '}
                {t('cash:ventas_registradas_count', { count: stats.sales.length })}
              </p>
            </div>
            <BarChart2 className="w-16 h-16 text-white/10 relative z-10" />
          </div>

          {/* ── KPI Grid ── */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard
              icon={<DollarSign className="w-5 h-5" />}
              label={t('cash:total_ventas')}
              value={formatCurrency(stats.salesTotal)}
              sub={`${stats.completedSales.length} completadas`}
            />
            <StatCard
              icon={<TrendingUp className="w-5 h-5" />}
              label={t('cash:ingresos_manuales_2')}
              value={formatCurrency(stats.manualIncome)}
              sub={`${stats.allIncomes.filter((i: any) => !i.isCancelled).length} movimientos`}
              accent="#166534"
            />
            <StatCard
              icon={<TrendingDown className="w-5 h-5" />}
              label={t('cash:egresos_manuales_2')}
              value={formatCurrency(stats.manualExpense)}
              sub={`${stats.allExpenses.filter((e: any) => !e.isCancelled).length} movimientos`}
              accent="#991b1b"
            />
            <StatCard
              icon={<Scale className="w-5 h-5" />}
              label={t('cash:balance_neto_caja')}
              value={formatCurrency(stats.netCash)}
              sub="Efectivo esperado"
              accent="#1e40af"
            />
          </div>

          {/* ── Payment breakdown ── */}
          <div className="grid grid-cols-3 gap-3">
            <StatCard icon={<Banknote className="w-4 h-4 text-emerald-600" />} label={t('cash:efectivo')} value={formatCurrency(stats.salesCash)} light />
            <StatCard icon={<CreditCard className="w-4 h-4 text-blue-600" />} label={t('cash:tarjeta')} value={formatCurrency(stats.salesCard)} light />
            <StatCard icon={<Smartphone className="w-4 h-4 text-indigo-600" />} label={t('cash:transferencia')} value={formatCurrency(stats.salesTransfer)} light />
          </div>

          {/* ── Contrast table: Ventas vs Movimientos ── */}
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="bg-slate-900 px-6 py-4 flex items-center gap-3">
              <Scale className="w-5 h-5 text-blue-400" />
              <h4 className="font-black text-white text-base tracking-wide">{t('cash:contraste_financiero_del_mes')}</h4>
            </div>
            <div className="p-6">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-200">
                    <th className="text-left py-3 px-2 font-black text-slate-800 text-xs uppercase tracking-wider">{t('cash:concepto')}</th>
                    <th className="text-right py-3 px-2 font-black text-slate-800 text-xs uppercase tracking-wider">{t('cash:monto')}</th>
                    <th className="text-right py-3 px-2 font-black text-slate-800 text-xs uppercase tracking-wider">{t('cash:del_total')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {[
                    { label: t('cash:saldo_inicial_acumulado'), value: stats.initialBalance, color: 'text-slate-600', bg: 'bg-slate-100' },
                    { label: t('cash:ventas_en_efectivo'), value: stats.salesCash, color: 'text-emerald-700', bg: 'bg-emerald-50' },
                    { label: t('cash:ventas_con_tarjeta'), value: stats.salesCard, color: 'text-blue-700', bg: 'bg-blue-50' },
                    { label: t('cash:ventas_por_transferencia'), value: stats.salesTransfer, color: 'text-indigo-700', bg: 'bg-indigo-50' },
                    { label: t('cash:ingresos_manuales_2'), value: stats.manualIncome, color: 'text-green-700', bg: 'bg-green-50' },
                    { label: t('cash:egresos_manuales_2'), value: -stats.manualExpense, color: 'text-rose-700', bg: 'bg-rose-50' },
                  ].map((row) => {
                    const base = stats.salesTotal + stats.manualIncome + stats.initialBalance || 1;
                    const pct = Math.abs((row.value / base) * 100).toFixed(1);
                    return (
                      <tr key={row.label} className="hover:bg-slate-50 transition-colors">
                        <td className="py-3 px-2">
                          <span className={`inline-flex items-center gap-2 px-2.5 py-1 rounded-lg text-xs font-bold ${row.bg} ${row.color}`}>
                            {row.label}
                          </span>
                        </td>
                        <td className={`py-3 px-2 text-right font-black tabular-nums ${row.color}`}>
                          {row.value < 0 ? '-' : ''}{formatCurrency(Math.abs(row.value))}
                        </td>
                        <td className="py-3 px-2 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <div className="w-16 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                              <div
                                className="h-full rounded-full bg-blue-600"
                                style={{ width: `${Math.min(100, parseFloat(pct))}%` }}
                              />
                            </div>
                            <span className="text-xs font-bold text-slate-500 w-10 text-right tabular-nums">{pct}%</span>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                  <tr className="border-t-2 border-slate-900 bg-slate-50">
                    <td className="py-4 px-2 font-black text-slate-900">{t('cash:balance_neto_de_caja')}</td>
                    <td className="py-4 px-2 text-right font-black text-slate-900 text-base tabular-nums">{formatCurrency(stats.netCash)}</td>
                    <td className="py-4 px-2 text-right text-xs font-bold text-slate-500">{t('cash:efectivo_esperado')}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* ── Arqueos del mes ── */}
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <button
              onClick={() => toggle('sessions')}
              className="w-full flex items-center justify-between px-6 py-4 hover:bg-slate-50 transition-colors"
            >
              <div className="flex items-center gap-3">
                <Wallet className="w-5 h-5 text-blue-600" />
                <span className="font-black text-slate-800">{t('cash:arqueos_del_mes_length', { length: stats.sessions.length })}</span>
              </div>
              {expandedSection === 'sessions'
                ? <ChevronDown className="w-5 h-5 text-slate-400" />
                : <ChevronRight className="w-5 h-5 text-slate-400" />}
            </button>
            {expandedSection === 'sessions' && (
              <div className="px-6 pb-6 space-y-3 border-t border-slate-100">
                {stats.sessions.length === 0 ? (
                  <p className="text-center text-slate-400 py-8 font-medium">{t('cash:sin_arqueos_en_este_mes')}</p>
                ) : stats.sessions.map((sess: any) => {
                  const sessSales = stats.completedSales.filter((s: any) => s.cashSessionId === sess.id);
                  const sessTotal = sessSales.reduce((n: number, s: any) => n + (s.total ?? 0), 0);
                  return (
                    <div key={sess.id} className="flex items-center gap-4 p-4 rounded-2xl border border-slate-200 bg-slate-50/50 hover:bg-blue-50/20 transition-colors">
                      <div className="w-12 h-12 rounded-2xl bg-slate-900 flex items-center justify-center text-blue-400 font-black text-sm flex-shrink-0">
                        #{sess.sessionNumber}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-black text-slate-800 text-sm">{t('cash:arqueo')}{sess.sessionNumber}</span>
                          {sess.status === 'OPEN'
                            ? <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full font-bold">{t('cash:abierto_2')}</span>
                            : <span className="text-xs bg-slate-200 text-slate-700 px-2 py-0.5 rounded-full font-bold">{t('cash:cerrado_2')}</span>}
                        </div>
                        <p className="text-xs text-slate-500 font-medium">
                          {new Date(sess.openedAt).toLocaleDateString(getLocale(), { day: '2-digit', month: 'short', year: 'numeric' })}
                          {sess.closedAt && ` → ${new Date(sess.closedAt).toLocaleDateString(getLocale(), { day: '2-digit', month: 'short' })}`}
                        </p>
                      </div>
                      <div className="text-right flex-shrink-0">
                        <p className="text-xs text-slate-400 font-bold uppercase">{t('cash:ventas')}</p>
                        <p className="font-black text-emerald-600 text-sm tabular-nums">{formatCurrency(sessTotal)}</p>
                        <p className="text-xs text-slate-400 tabular-nums">{sessSales.length}{' '}{t('cash:ventas_2')}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* ── Movements ── */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Incomes */}
            <div className="bg-white rounded-3xl border border-emerald-100 shadow-sm overflow-hidden">
              <button
                onClick={() => toggle('incomes')}
                className="w-full flex items-center justify-between px-6 py-4 hover:bg-emerald-50/30 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <TrendingUp className="w-5 h-5 text-emerald-600" />
                  <span className="font-black text-emerald-800">
                    {t('cash:ingresos_manuales_2')}
                    <span className="ml-2 text-xs font-bold bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full">
                      {formatCurrency(stats.manualIncome)}
                    </span>
                  </span>
                </div>
                {expandedSection === 'incomes'
                  ? <ChevronDown className="w-4 h-4 text-emerald-400" />
                  : <ChevronRight className="w-4 h-4 text-emerald-400" />}
              </button>
              {expandedSection === 'incomes' && (
                <div className="px-4 pb-4 space-y-2 border-t border-emerald-50 pt-2 max-h-72 overflow-y-auto">
                  {stats.allIncomes.length === 0 ? (
                    <div className="text-center py-8 text-slate-400 font-medium">
                      <CheckCircle2 className="w-8 h-8 mx-auto mb-2 opacity-30" />
                      {t('cash:sin_ingresos_manuales')}
                    </div>
                  ) : stats.allIncomes.map((inc: any) => (
                    <MovementRow key={inc.id} item={inc} type="INCOME" />
                  ))}
                </div>
              )}
            </div>

            {/* Expenses */}
            <div className="bg-white rounded-3xl border border-rose-100 shadow-sm overflow-hidden">
              <button
                onClick={() => toggle('expenses')}
                className="w-full flex items-center justify-between px-6 py-4 hover:bg-rose-50/30 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <TrendingDown className="w-5 h-5 text-rose-600" />
                  <span className="font-black text-rose-800">
                    {t('cash:egresos_manuales_2')}
                    <span className="ml-2 text-xs font-bold bg-rose-100 text-rose-700 px-2 py-0.5 rounded-full">
                      {formatCurrency(stats.manualExpense)}
                    </span>
                  </span>
                </div>
                {expandedSection === 'expenses'
                  ? <ChevronDown className="w-4 h-4 text-rose-400" />
                  : <ChevronRight className="w-4 h-4 text-rose-400" />}
              </button>
              {expandedSection === 'expenses' && (
                <div className="px-4 pb-4 space-y-2 border-t border-rose-50 pt-2 max-h-72 overflow-y-auto">
                  {stats.allExpenses.length === 0 ? (
                    <div className="text-center py-8 text-slate-400 font-medium">
                      <XCircle className="w-8 h-8 mx-auto mb-2 opacity-30" />
                      {t('cash:sin_egresos_registrados')}
                    </div>
                  ) : stats.allExpenses.map((exp: any) => (
                    <MovementRow key={exp.id} item={exp} type="EXPENSE" />
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* ── Sales summary ── */}
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <button
              onClick={() => toggle('sales')}
              className="w-full flex items-center justify-between px-6 py-4 hover:bg-slate-50 transition-colors"
            >
              <div className="flex items-center gap-3">
                <Receipt className="w-5 h-5 text-blue-600" />
                <span className="font-black text-slate-800">
                  {t('cash:ventas_del_mes')}
                  <span className="ml-2 text-xs font-bold bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full border border-blue-200">
                    {t('cash:length_registros', { length: stats.sales.length })}
                  </span>
                </span>
              </div>
              {expandedSection === 'sales'
                ? <ChevronDown className="w-5 h-5 text-slate-400" />
                : <ChevronRight className="w-5 h-5 text-slate-400" />}
            </button>
            {expandedSection === 'sales' && (
              <div className="border-t border-slate-100">
                <div className="max-h-72 overflow-y-auto">
                  <table className="w-full text-sm">
                    <thead className="sticky top-0 bg-slate-50 border-b border-slate-200">
                      <tr>
                        <th className="text-left px-4 py-3 font-black text-slate-700 text-xs uppercase">{t('cash:venta_2')}</th>
                        <th className="text-left px-4 py-3 font-black text-slate-700 text-xs uppercase">{t('cash:fecha')}</th>
                        <th className="text-left px-4 py-3 font-black text-slate-700 text-xs uppercase">{t('cash:metodo')}</th>
                        <th className="text-left px-4 py-3 font-black text-slate-700 text-xs uppercase">{t('cash:estado')}</th>
                        <th className="text-right px-4 py-3 font-black text-slate-700 text-xs uppercase">{t('cash:total')}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {stats.sales.length === 0 ? (
                        <tr><td colSpan={5} className="text-center py-8 text-slate-400 font-medium">{t('cash:sin_ventas_en_este_mes')}</td></tr>
                      ) : stats.sales.map((sale: any) => (
                        <tr key={sale.id} className={`hover:bg-slate-50 transition-colors ${sale.status === 'CANCELLED' ? 'opacity-50' : ''}`}>
                          <td className="px-4 py-2.5 font-bold text-slate-800">#{sale.saleNumber}</td>
                          <td className="px-4 py-2.5 text-slate-600">
                            {new Date(sale.createdAt).toLocaleDateString(getLocale(), { day: '2-digit', month: 'short' })}
                          </td>
                          <td className="px-4 py-2.5">
                            <span className="text-xs font-bold bg-slate-100 text-slate-700 px-2 py-0.5 rounded-lg">
                              {sale.paymentMethod === 'CASH' ? t('cash:efectivo') : sale.paymentMethod === 'CARD' ? t('cash:tarjeta') : t('cash:transferencia')}
                            </span>
                          </td>
                          <td className="px-4 py-2.5">
                            {sale.status === 'COMPLETED' && <span className="flex items-center gap-1 text-xs font-bold text-emerald-700"><CheckCircle2 className="w-3 h-3" />{t('cash:completada')}</span>}
                            {sale.status === 'CANCELLED' && <span className="flex items-center gap-1 text-xs font-bold text-rose-600"><XCircle className="w-3 h-3" />{t('cash:anulada')}</span>}
                            {sale.status === 'PENDING'   && <span className="text-xs font-bold text-amber-600">{t('cash:pendiente')}</span>}
                          </td>
                          <td className={`px-4 py-2.5 text-right font-black tabular-nums ${sale.status === 'CANCELLED' ? 'text-slate-300 line-through' : 'text-emerald-700'}`}>
                            {formatCurrency(sale.total ?? 0)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {stats.completedSales.length > 0 && (
                  <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex justify-between items-center">
                    <span className="text-xs font-black text-slate-500 uppercase tracking-wider">{t('cash:total_ventas_completadas')}</span>
                    <span className="font-black text-slate-900 text-base tabular-nums">{formatCurrency(stats.salesTotal)}</span>
                  </div>
                )}
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
};

export default MonthlyArqueoReport;
