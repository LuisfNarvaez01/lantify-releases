import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig(({ mode }) => {
  // LAN_ACCESS vive en el .env del backend (carpeta superior): con true, las tablets
  // de los meseros entran por http://<IP-del-equipo>:5173
  const lanAccess = loadEnv(mode, '..', '').LAN_ACCESS === 'true';

  return {
    plugins: [react()],
    server: {
      // El diseño de Mi página usa el mismo dominio que el servidor (src/domain/pageTheme.ts)
      fs: { allow: ['..'] },
      host: lanAccess ? true : 'localhost',
      port: 5173,
      proxy: {
        '/api': {
          target: 'http://localhost:5000',
          changeOrigin: true,
          // IP real de la tablet para los límites de intentos (el backend confía solo en localhost)
          xfwd: true,
        },
      },
    },
  };
});
