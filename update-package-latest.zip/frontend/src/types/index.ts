// ============================================
// TYPES - Domain Types for POS Frontend
// ============================================

export type TableStatus = 'AVAILABLE' | 'ORDERED' | 'PENDING';
export type CashSessionStatus = 'OPEN' | 'CLOSED';
export type SaleStatus = 'PENDING' | 'COMPLETED' | 'CANCELLED' | 'REFUNDED';
export type PaymentMethod = 'CASH' | 'CARD' | 'TRANSFER' | 'MIXED' | 'RAPPI_PAY' | 'NEQUI' | 'DAVIPLATA';
export type UserRole = 'ADMIN' | 'CASHIER' | 'WAITER';

export interface User {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  isActive?: boolean;
}

// ============================================
// CUSTOMER & loyalty TYPES
// ============================================

export interface Customer {
  id: string;
  name: string;
  nit?: string;
  phone?: string;
  email?: string;
  address?: string;
  birthDate?: string;
  notes?: string;
  totalSpent: number;
  visitCount: number;
  stampsCount?: number;
  lifetimeStamps?: number;
  isDefault: boolean;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface ExpenseCategory {
  id: string;
  name: string;
  description?: string;
  color?: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

// ============================================
// PRODUCT TYPES
// ============================================

export interface Category {
  id: string;
  name: string;
  description?: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Product {
  id: string;
  name: string;
  description?: string;
  categoryId?: string;
  category?: Category;
  imageUrl?: string;
  isActive: boolean;
  variants: ProductVariant[];
  createdAt: string;
  updatedAt: string;
  taxType?: 'IVA' | 'INC' | 'NONE' | null; // null = impuesto del negocio
  taxRate?: number | null;
}

export interface ProductVariant {
  id: string;
  productId: string;
  name: string;
  sku: string;
  barcode?: string;
  price: number;
  cost?: number;
  stock: number;
  trackInventory?: boolean;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

// ============================================
// SALE TYPES
// ============================================

export interface SaleItem {
  id: string;
  saleId: string;
  productVariantId: string;
  productVariant?: ProductVariant;
  productName?: string;
  variantName?: string;
  quantity: number;
  unitPrice: number;
  total: number;
  notes?: string;
  // Campos de anulación
  isCancelled?: boolean;
  cancellationReason?: string;
  cancelledAt?: string;
  cancelledBy?: string;
  createdAt: string;
  taxType?: string;
  taxRate?: number;
  taxAmount?: number;
}

export interface Payment {
  id: string;
  saleId: string;
  amount: number;
  paymentMethod: PaymentMethod;
  cashSessionId?: string;
  notes?: string;
  createdAt: string;
}

export interface Sale {
  id: string;
  saleNumber: string;
  tableId?: string;
  table?: Table;
  customerId?: string;
  customer?: Customer;
  cashSessionId?: string;
  channel?: 'POS' | 'RAPPI' | 'WHATSAPP' | 'WEB';
  customerName?: string;
  customerPhone?: string;
  customerAddress?: string;
  deliveryNotes?: string;
  discountPct?: number;
  subtotal: number;
  tax: number;
  discount: number;
  total: number;
  paymentMethod: PaymentMethod;
  status: SaleStatus;
  notes?: string;
  items: SaleItem[];
  payments?: Payment[];
  createdAt: string;
  updatedAt: string;
  tip?: number; // propina voluntaria (fuera del total)
}

// ============================================
// CASH SESSION TYPES
// ============================================

export interface Expense {
  id: string;
  cashSessionId: string;
  amount: number;
  motive: string;
  description?: string;
  categoryId?: string;
  category?: ExpenseCategory;
  /** CASH_DRAWER descuenta del saldo esperado; BANK, CARD, NEQUI, OTHER solo quedan en el arqueo */
  paymentSource?: string;
  supplierName?: string | null;
  invoiceNumber?: string | null;
  imageFile?: string | null;
  captureMode?: 'MANUAL' | 'AI_REVIEWED' | 'AI_AUTO';
  isCancelled?: boolean;
  cancellationReason?: string;
  cancelledAt?: string;
  createdAt: string;
}

export interface Income {
  id: string;
  cashSessionId: string;
  amount: number;
  motive: string;
  description?: string;
  isCancelled?: boolean;
  cancellationReason?: string;
  cancelledAt?: string;
  createdAt: string;
}

export interface CashSession {
  id: string;
  sessionNumber: string;
  openedAt: string;
  closedAt?: string;
  initialBalance: number;
  income: number;
  expenses: number;
  expensesDetails?: Expense[];
  incomesDetails?: Income[];
  finalBalance?: number;
  expectedBalance?: number;
  difference?: number;
  status: CashSessionStatus;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

// ============================================
// TABLE TYPES
// ============================================

export interface Table {
  id: string;
  number: string;
  capacity: number;
  status: TableStatus;
  positionX?: number;
  positionY?: number;
  zone?: string | null;
  width?: number | null;
  height?: number | null;
  createdAt: string;
  updatedAt: string;
  currentSale?: Sale;
}

// ============================================
// CART TYPES
// ============================================

export interface ItemCancellation {
  id: string;
  quantity: number;
  reason: string;
  comments?: string;
  cancelledAt: string;
  cancelledBy: string;
  wasteDestination?: 'waste' | 'restock';
}

export interface CartItem {
  id: string;
  productId: string;
  productName: string;
  variantId: string;
  variantName: string;
  sku: string;
  quantity: number;
  unitPrice: number;
  total: number;
  notes?: string;
  isOrdered?: boolean;
  orderedAt?: string;
  roundNumber?: number;
  cancellations?: ItemCancellation[];
}

// ============================================
// API RESPONSE TYPES
// ============================================

export interface DailySummary {
  count: number;
  total: number;
}