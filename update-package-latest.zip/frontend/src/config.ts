// ============================================
// CONFIG - Dirección única del backend
// ============================================
// Por defecto, la misma dirección por la que se abrió el POS: Vite reenvía /api al
// backend, así una tablet de mesero que entra por la IP del equipo principal llega
// al servidor correcto ("localhost" en la tablet sería la propia tablet).
// Se puede cambiar con VITE_API_URL si el backend vive en otro equipo.

const DEFAULT_API_URL = '/api';

// Versiones anteriores traían frontend/.env apuntando a localhost (3000 nunca se usó;
// 5000 solo funciona en el equipo principal). Se ignoran para no romper las tablets.
const LEGACY_UNUSED_URLS = new Set(['http://localhost:3000/api', 'http://localhost:5000/api']);

const fromEnv: string | undefined = (import.meta as any).env?.VITE_API_URL;

export const API_URL: string = fromEnv && !LEGACY_UNUSED_URLS.has(fromEnv) ? fromEnv : DEFAULT_API_URL;

