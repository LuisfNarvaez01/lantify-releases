// ============================================
// SERVICES - Informe de ventas
// ============================================
// Trae TODAS las ventas del periodo (no solo la página que se ve) y responde lo que
// pregunta un dueño: cuánto vendí, cómo me pagaron, qué días y qué productos, y
// qué se anuló. Las propinas se muestran aparte: no son ingreso del negocio.
// También lo usa el informe de cada arqueo (productos y pagos).

import { API_URL } from '../config';
import { getLocale, t } from '../i18n';
import { int, money, moneyText, pct, ReportCell, ReportDoc, ReportTable } from './reportDocument';

const PAGE = 200;

export interface SalesQuery {
  /** 0 = sin filtro de fecha (p. ej. todas las ventas de un arqueo) */
  year: number;
  month: number;
  cashSessionId?: string;
  status?: string;
}

export const fetchAllSales = async (q: SalesQuery): Promise<any[]> => {
  const out: any[] = [];
  for (let page = 1; page <= 100; page++) {
    const params = new URLSearchParams({ year: String(q.year), month: String(q.month), page: String(page), limit: String(PAGE) });
    if (q.cashSessionId) params.set('cashSessionId', q.cashSessionId);
    if (q.status) params.set('status', q.status);
    const res = await fetch(`${API_URL}/sales/by-month?${params}`, { headers: { Authorization: `Bearer ${localStorage.getItem('token') || ''}` } });
    if (!res.ok) throw new Error(t('reports:no_se_cargaron'));
    const body = await res.json();
    out.push(...(body.data || []));
    if (page >= (body.totalPages || 1)) break;
  }
  return out;
};

export const methodLabel = (m: string) => t(`reports:metodo_${m}`, { defaultValue: m });
const statusLabel = (s: string) => t(`reports:estado_${s}`, { defaultValue: s });
export const placeLabel = (s: any) => (s.table?.number ? `${t('reports:mesa')} ${s.table.number}` : s.channel && s.channel !== 'POS' ? s.channel : t('reports:mostrador'));
const itemName = (i: any) => i.productVariant?.product?.name || i.productName || t('reports:producto');
const variantName = (i: any) => i.productVariant?.name || i.variantName || '';
const when = (d: string | Date) => new Date(d).toLocaleString(getLocale(), { dateStyle: 'short', timeStyle: 'short' });

/** Lo que una venta recibió en un método (con sus pagos; ventas antiguas sin pagos: su método) */
export const paidBy = (sale: any, method: string) =>
  sale.payments?.length
    ? sale.payments.filter((p: any) => p.paymentMethod === method).reduce((n: number, p: any) => n + (p.amount ?? 0), 0)
    : sale.paymentMethod === method ? sale.total ?? 0 : 0;

// ── Tablas que comparten el informe del mes y el de cada arqueo ──

export const methodsTable = (done: any[]): ReportTable => {
  const byMethod = new Map<string, { count: number; amount: number }>();
  for (const s of done) {
    const pays = s.payments?.length ? s.payments.map((p: any) => ({ m: p.paymentMethod, a: p.amount })) : [{ m: s.paymentMethod, a: s.total }];
    for (const p of pays) {
      const e = byMethod.get(p.m) || { count: 0, amount: 0 };
      e.count++;
      e.amount += p.a || 0;
      byMethod.set(p.m, e);
    }
  }
  const total = [...byMethod.values()].reduce((n, e) => n + e.amount, 0);
  return {
    title: t('reports:por_metodo'),
    sheet: t('reports:hoja_pagos'),
    note: t('reports:por_metodo_nota'),
    columns: [{ label: t('reports:col_metodo'), width: 2 }, { label: t('reports:col_pagos'), align: 'right' }, { label: t('reports:col_valor'), align: 'right', width: 1.5 }, { label: t('reports:col_participacion'), align: 'right' }],
    rows: [...byMethod.entries()].sort((a, b) => b[1].amount - a[1].amount).map(([m, e]) => [methodLabel(m), int(e.count), money(e.amount), pct(e.amount, total)]),
    totals: [t('reports:total'), int([...byMethod.values()].reduce((n, e) => n + e.count, 0)), money(total), pct(total, total)],
  };
};

export const productsTable = (done: any[]): ReportTable => {
  const byProduct = new Map<string, { name: string; qty: number; amount: number }>();
  for (const s of done) {
    for (const i of s.items || []) {
      if (i.isCancelled) continue;
      const v = variantName(i);
      const name = v && !/^(normal|única|unica)$/i.test(v) ? `${itemName(i)} · ${v}` : itemName(i);
      const e = byProduct.get(name) || { name, qty: 0, amount: 0 };
      e.qty += i.quantity || 0;
      e.amount += i.total ?? i.subtotal ?? (i.quantity || 0) * (i.unitPrice || 0);
      byProduct.set(name, e);
    }
  }
  const products = [...byProduct.values()].sort((a, b) => b.amount - a.amount);
  const total = products.reduce((n, p) => n + p.amount, 0);
  return {
    title: t('reports:productos'),
    sheet: t('reports:hoja_productos'),
    note: t('reports:productos_nota'),
    columns: [{ label: '#', align: 'right', width: 0.4 }, { label: t('reports:col_producto'), width: 3 }, { label: t('reports:col_cantidad'), align: 'right' }, { label: t('reports:col_valor'), align: 'right', width: 1.4 }, { label: t('reports:col_participacion'), align: 'right' }],
    rows: products.map((p, i) => [i + 1, p.name, int(p.qty), money(p.amount), pct(p.amount, total)]),
    totals: ['', t('reports:total'), int(products.reduce((n, p) => n + p.qty, 0)), money(total), pct(total, total)],
  };
};

export const cancelledTable = (cancelled: any[]): ReportTable => ({
  title: t('reports:anuladas_titulo'),
  sheet: t('reports:hoja_anuladas'),
  note: t('reports:anuladas_nota'),
  columns: [{ label: t('reports:col_venta') }, { label: t('reports:col_fecha'), width: 1.4 }, { label: t('reports:col_lugar') }, { label: t('reports:col_motivo'), width: 2 }, { label: t('reports:col_valor'), align: 'right' }],
  rows: cancelled.map((s) => [s.saleNumber, when(s.createdAt), placeLabel(s), s.notes || '—', money(s.total)]),
  totals: ['', '', '', t('reports:total'), money(cancelled.reduce((n, s) => n + (s.total || 0), 0))],
  empty: t('reports:sin_anuladas'),
});

/** Detalle: compacto en el PDF; completo (una fila por venta, todas las columnas) en Excel */
export const detailTables = (sales: any[], done: any[]): ReportTable[] => {
  const sorted = (list: any[]) => list.slice().sort((a, b) => +new Date(a.createdAt) - +new Date(b.createdAt));
  const sum = (list: any[], k: string) => list.reduce((n, s) => n + (s[k] || 0), 0);
  return [
    {
      title: t('reports:detalle'),
      only: 'pdf',
      columns: [{ label: t('reports:col_venta') }, { label: t('reports:col_fecha'), width: 1.3 }, { label: t('reports:col_lugar') }, { label: t('reports:col_cajero') }, { label: t('reports:col_metodo') }, { label: t('reports:col_descuento'), align: 'right' }, { label: t('reports:col_valor'), align: 'right' }],
      rows: sorted(done).map((s) => [s.saleNumber, when(s.createdAt), placeLabel(s), s.cashierName || '—', methodLabel(s.paymentMethod), s.discount ? money(s.discount) : '—', money(s.total)]),
      totals: ['', '', '', '', t('reports:total'), money(sum(done, 'discount')), money(sum(done, 'total'))],
    },
    {
      title: t('reports:detalle_completo'),
      sheet: t('reports:hoja_ventas'),
      only: 'xlsx',
      note: t('reports:detalle_completo_nota'),
      columns: [
        { label: t('reports:col_venta') }, { label: t('reports:col_fecha') }, { label: t('reports:col_hora') }, { label: t('reports:col_estado') },
        { label: t('reports:col_lugar') }, { label: t('reports:col_cajero') }, { label: t('reports:col_mesero') }, { label: t('reports:col_cliente') },
        { label: t('reports:col_metodo') }, { label: t('reports:metodo_CASH') }, { label: t('reports:metodo_CARD') }, { label: t('reports:metodo_TRANSFER') },
        { label: t('reports:col_subtotal') }, { label: t('reports:col_descuento') }, { label: t('reports:col_impuestos') }, { label: t('reports:col_total') },
        { label: t('reports:col_propina') }, { label: t('reports:col_productos') },
      ],
      rows: sorted(sales).map((s) => {
        const d = new Date(s.createdAt);
        const ok = s.status === 'COMPLETED';
        return [
          s.saleNumber,
          d.toLocaleDateString(getLocale()),
          d.toLocaleTimeString(getLocale(), { hour: '2-digit', minute: '2-digit' }),
          statusLabel(s.status),
          placeLabel(s),
          s.cashierName || '',
          s.waiterName || '',
          s.customer && !s.customer.isDefault ? s.customer.name : s.customerName || '',
          methodLabel(s.paymentMethod),
          money(ok ? paidBy(s, 'CASH') : 0),
          money(ok ? paidBy(s, 'CARD') : 0),
          money(ok ? paidBy(s, 'TRANSFER') : 0),
          money(s.subtotal),
          money(s.discount),
          money(s.tax),
          money(s.total),
          money(s.tip),
          (s.items || []).filter((i: any) => !i.isCancelled).map((i: any) => `${i.quantity}x ${itemName(i)}`).join(' | '),
        ] as ReportCell[];
      }),
    },
  ];
};

export const buildSalesReport = (sales: any[], periodLabel: string, scope?: string): ReportDoc => {
  const locale = getLocale();
  const done = sales.filter((s) => s.status === 'COMPLETED');
  const cancelled = sales.filter((s) => s.status === 'CANCELLED');
  const net = done.reduce((n, s) => n + (s.total || 0), 0);
  const discounts = done.reduce((n, s) => n + (s.discount || 0), 0);
  const taxes = done.reduce((n, s) => n + (s.tax || 0), 0);
  const tips = done.reduce((n, s) => n + (s.tip || 0), 0);
  const avg = done.length ? net / done.length : 0;
  const units = done.reduce((n, s) => n + (s.items || []).filter((i: any) => !i.isCancelled).reduce((m: number, i: any) => m + (i.quantity || 0), 0), 0);

  const byDay = new Map<string, { date: Date; count: number; amount: number }>();
  for (const s of done) {
    const d = new Date(s.createdAt);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    const e = byDay.get(key) || { date: d, count: 0, amount: 0 };
    e.count++;
    e.amount += s.total || 0;
    byDay.set(key, e);
  }
  const days = [...byDay.entries()].sort((a, b) => a[0].localeCompare(b[0])).map(([, e]) => e);
  const best = days.reduce<{ date: Date; amount: number } | null>((m, e) => (!m || e.amount > m.amount ? e : m), null);

  return {
    title: t('reports:ventas_titulo'),
    period: periodLabel,
    scope,
    kpis: [
      { label: t('reports:ventas_netas'), value: money(net), hint: t('reports:ventas_netas_hint'), tone: 'good' },
      { label: t('reports:num_ventas'), value: int(done.length), hint: t('reports:num_ventas_hint', { units }) },
      { label: t('reports:ticket_promedio'), value: money(avg), hint: t('reports:ticket_promedio_hint') },
      { label: t('reports:descuentos'), value: money(discounts), hint: t('reports:descuentos_hint') },
      { label: t('reports:impuestos'), value: money(taxes), hint: t('reports:impuestos_hint') },
      { label: t('reports:propinas'), value: money(tips), hint: t('reports:propinas_hint') },
      { label: t('reports:anuladas'), value: int(cancelled.length), hint: moneyText(cancelled.reduce((n, s) => n + (s.total || 0), 0)), tone: cancelled.length ? 'bad' : 'neutral' },
    ],
    tables: [
      methodsTable(done),
      {
        title: t('reports:por_dia'),
        sheet: t('reports:hoja_dias'),
        note: best ? t('reports:mejor_dia', { day: best.date.toLocaleDateString(locale, { weekday: 'long', day: 'numeric', month: 'long' }), amount: moneyText(best.amount) }) : undefined,
        columns: [{ label: t('reports:col_dia'), width: 2 }, { label: t('reports:col_ventas'), align: 'right' }, { label: t('reports:col_valor'), align: 'right', width: 1.5 }, { label: t('reports:col_promedio'), align: 'right', width: 1.5 }],
        rows: days.map((e) => [e.date.toLocaleDateString(locale, { weekday: 'short', day: '2-digit', month: 'short' }), int(e.count), money(e.amount), money(e.amount / e.count)]),
        totals: [t('reports:total'), int(done.length), money(net), money(avg)],
      },
      productsTable(done),
      cancelledTable(cancelled),
      ...detailTables(sales, done),
    ],
    notes: [t('reports:nota_netas'), t('reports:nota_propinas')],
  };
};
