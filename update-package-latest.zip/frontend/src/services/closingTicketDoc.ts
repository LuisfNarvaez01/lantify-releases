// ============================================
// SERVICES - Informe de cierre de caja en la tirilla (estilo cierre de datáfono)
// ============================================
// Rango de ventas, una línea por venta, impuestos, medios de pago, movimientos,
// arqueo y firmas. Es un documento de control interno: no reemplaza la factura.

import type { TicketBlock, TicketDoc } from '../../../src/domain/ticketDoc';
import type { ClosingTicket } from '../../../src/domain/v3/closingTicket';
import { header, methodLabel, money, ticketT, TicketContext } from './ticketBuilder';

const SHORT: Record<string, string> = { CASH: 'EF', CARD: 'TJ', TRANSFER: 'TR', NEQUI: 'NQ', DAVIPLATA: 'DV', RAPPI_PAY: 'RP' };

export const buildClosingDoc = (data: ClosingTicket, ctx: TicketContext, copy = false): TicketDoc => {
  const { tt, locale } = ticketT(ctx.settings);
  const narrow = ctx.settings.paperWidth === '58mm';
  const dt = (d: string | null) =>
    d ? new Date(d).toLocaleString(locale, { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—';
  const hm = (d: string) => new Date(d).toLocaleTimeString(locale, { hour: '2-digit', minute: '2-digit' });
  const blocks: TicketBlock[] = [...header(ctx, tt), { t: 'rule' }];

  blocks.push({ t: 'text', text: tt('cierre_titulo'), align: 'center', bold: true, size: 2 });
  if (copy) blocks.push({ t: 'text', text: tt('copia'), align: 'center', bold: true, invert: true });
  blocks.push({ t: 'feed' });
  blocks.push({ t: 'row', left: tt('cierre_n'), right: data.sessionNumber, bold: true });
  blocks.push({ t: 'row', left: tt('cierre_caja'), right: data.registerCode });
  blocks.push({ t: 'row', left: tt('cierre_apertura'), right: dt(data.openedAt) });
  blocks.push({ t: 'row', left: tt('cierre_cierre'), right: data.closedAt ? dt(data.closedAt) : tt('cierre_abierta') });
  if (data.openedBy) blocks.push({ t: 'row', left: tt('cierre_abrio'), right: data.openedBy });
  if (data.closedBy) blocks.push({ t: 'row', left: tt('cierre_cerro'), right: data.closedBy });

  blocks.push({ t: 'rule' });
  blocks.push({ t: 'text', text: tt('cierre_rango'), bold: true });
  blocks.push({ t: 'row', left: tt('cierre_desde'), right: data.range.first || '—' });
  blocks.push({ t: 'row', left: tt('cierre_hasta'), right: data.range.last || '—' });
  blocks.push({ t: 'row', left: tt('cierre_documentos'), right: String(data.range.count) });

  blocks.push({ t: 'rule' });
  blocks.push({ t: 'text', text: tt('cierre_detalle'), bold: true });
  blocks.push({ t: 'text', text: tt('cierre_leyenda'), small: true });
  for (const s of data.sales) {
    const voided = s.status === 'CANCELLED';
    const place = narrow ? '' : ` ${s.place}`;
    blocks.push({
      t: 'row',
      left: `${s.code} ${hm(s.createdAt)}${place} ${SHORT[s.method] ?? 'MX'}`,
      right: voided ? `(${money(s.total)})` : money(s.total),
      small: narrow,
    });
    if (voided) blocks.push({ t: 'text', text: `  ${tt('cierre_anulada')}${s.note ? `: ${s.note}` : ''}`, small: true });
  }
  if (!data.sales.length) blocks.push({ t: 'text', text: tt('cierre_sin_ventas'), align: 'center', small: true });

  blocks.push({ t: 'rule' });
  blocks.push({ t: 'row', left: tt('cierre_ventas_n', { count: data.completedCount }), right: money(data.grossTotal + data.discounts) });
  if (data.discounts > 0) blocks.push({ t: 'row', left: tt('cierre_descuentos'), right: `-${money(data.discounts)}` });
  blocks.push({ t: 'row', left: tt('cierre_total_vendido'), right: money(data.grossTotal), bold: true, size: 2 });
  for (const tx of data.taxes) {
    const label = `${tx.taxType === 'IVA' ? tt('iva') : tt('inc')} ${tx.taxRate}%`;
    blocks.push({ t: 'row', left: tt('cierre_base', { tax: label }), right: money(tx.base), small: true });
    blocks.push({ t: 'row', left: tt('cierre_impuesto', { tax: label }), right: money(tx.amount), small: true });
  }
  if (data.tips > 0) blocks.push({ t: 'row', left: tt('cierre_propinas'), right: money(data.tips) });
  if (data.cancelled.count > 0) blocks.push({ t: 'row', left: tt('cierre_anuladas_n', { count: data.cancelled.count }), right: money(data.cancelled.total) });

  blocks.push({ t: 'rule' });
  blocks.push({ t: 'text', text: tt('cierre_medios'), bold: true });
  for (const m of data.byMethod) blocks.push({ t: 'row', left: methodLabel(tt, m.method), right: money(m.amount) });
  if (!data.byMethod.length) blocks.push({ t: 'text', text: '—', align: 'center' });

  blocks.push({ t: 'rule' });
  blocks.push({ t: 'text', text: tt('cierre_movimientos'), bold: true });
  blocks.push({ t: 'row', left: tt('cierre_base_inicial'), right: money(data.initialBalance) });
  for (const x of data.incomes) blocks.push({ t: 'row', left: `+ ${x.motive}`, right: money(x.amount), small: true });
  for (const x of data.expenses) blocks.push({ t: 'row', left: `- ${x.motive}`, right: `-${money(x.amount)}`, small: true });
  blocks.push({ t: 'row', left: tt('cierre_entradas'), right: money(data.incomesTotal) });
  blocks.push({ t: 'row', left: tt('cierre_salidas'), right: `-${money(data.expensesTotal)}` });

  blocks.push({ t: 'rule', style: 'double' });
  blocks.push({ t: 'text', text: tt('cierre_arqueo'), bold: true });
  blocks.push({ t: 'row', left: tt('cierre_esperado'), right: money(data.expected) });
  blocks.push({ t: 'row', left: tt('cierre_contado'), right: data.counted === null ? '—' : money(data.counted) });
  if (data.difference !== null) {
    const label = data.difference === 0 ? tt('cierre_cuadra') : data.difference > 0 ? tt('cierre_sobrante') : tt('cierre_faltante');
    blocks.push({ t: 'row', left: label, right: money(data.difference), bold: true, size: 2 });
  }

  blocks.push({ t: 'feed', lines: 3 });
  blocks.push({ t: 'text', text: '______________________', align: 'center' });
  blocks.push({ t: 'text', text: tt('cierre_firma_cajero'), align: 'center', small: true });
  blocks.push({ t: 'feed', lines: 2 });
  blocks.push({ t: 'text', text: '______________________', align: 'center' });
  blocks.push({ t: 'text', text: tt('cierre_firma_admin'), align: 'center', small: true });
  blocks.push({ t: 'feed' });
  blocks.push({ t: 'text', text: tt('cierre_impreso', { when: dt(new Date().toISOString()) }), align: 'center', small: true });
  blocks.push({ t: 'text', text: tt('cierre_no_factura'), align: 'center', small: true });
  blocks.push({ t: 'text', text: tt('software'), align: 'center', small: true });
  return { title: `${tt('cierre_titulo')} ${data.sessionNumber}`, blocks };
};
