// ============================================
// SERVICES - Avisos de transferencia del celular del negocio → la caja (Fase 4 · D · 3)
// ============================================
// La app Android (con el acceso a notificaciones que activó el dueño) analiza los avisos
// de Nequi, Daviplata, Bancolombia y Bre‑B y deja en cola solo monto, remitente y hora.
// Aquí se envían a la caja por el mismo camino de todo lo demás (red local o relevo),
// con la sesión del celular vinculado; solo ADMIN o CASHIER. Un aviso que la caja ya
// recibió (o rechazó por inválido) sale de la cola; si no hay conexión, se reintenta.

import { androidBridge } from './androidBridge';
import { transfersAPI, type BankApp, type BankNotice } from './v3Api';

const APPS: BankApp[] = ['NEQUI', 'DAVIPLATA', 'BANCOLOMBIA', 'BREB'];
const RETRY_MS = 30_000;

const valid = (n: any): n is BankNotice =>
  n && typeof n.ref === 'string' && APPS.includes(n.app) && Number.isFinite(n.amount) && n.amount > 0 && Number.isFinite(n.postedAt);

let sending = false;
let timer: ReturnType<typeof setInterval> | null = null;

const flush = async () => {
  const bridge = androidBridge();
  if (sending || !bridge?.pendingBankNotices || !bridge.ackBankNotice) return;
  sending = true;
  try {
    let list: unknown = [];
    try { list = JSON.parse(bridge.pendingBankNotices() || '[]'); } catch { list = []; }
    for (const raw of Array.isArray(list) ? list : []) {
      if (!valid(raw)) {
        if (raw && typeof (raw as any).ref === 'string') bridge.ackBankNotice((raw as any).ref);
        continue;
      }
      try {
        await transfersAPI.incoming({ ref: raw.ref, app: raw.app, amount: raw.amount, sender: raw.sender ?? null, postedAt: raw.postedAt });
        bridge.ackBankNotice(raw.ref);
      } catch (err: any) {
        const status = Number(err?.status || 0);
        // 400/403/404: la caja no lo quiere (función apagada, aviso viejo, rol sin permiso): se descarta
        if (status >= 400 && status < 500 && ![401, 408, 429].includes(status)) bridge.ackBankNotice(raw.ref);
        else break; // sin conexión: se reintenta después
      }
    }
  } finally {
    sending = false;
  }
};

/** Empieza a enviar avisos (app Android, usuario ADMIN o CASHIER). Devuelve cómo detenerlo. */
export const startBankNoticeRelay = (): (() => void) => {
  if (!androidBridge()?.pendingBankNotices) return () => undefined;
  window.__lantifyBankNotice = () => { void flush(); };
  const onVisible = () => { if (document.visibilityState === 'visible') void flush(); };
  document.addEventListener('visibilitychange', onVisible);
  window.addEventListener('online', onVisible);
  timer = setInterval(() => void flush(), RETRY_MS);
  void flush();
  return () => {
    delete window.__lantifyBankNotice;
    document.removeEventListener('visibilitychange', onVisible);
    window.removeEventListener('online', onVisible);
    if (timer) clearInterval(timer);
    timer = null;
  };
};
