import { API_URL } from '../config';
import type { PageTheme } from '../../../src/domain/pageTheme';
import type { Customer } from '../types';

import { responseError } from './apiErrors';

const getToken = () => localStorage.getItem('token');

const headers = () => ({
  'Content-Type': 'application/json',
  'Authorization': `Bearer ${getToken() || ''}`
});

// Helper para manejar respuestas: los errores salen con un mensaje claro para el usuario
const handleResponse = async (res: Response) => {
  if (!res.ok) {
    const body = await res.json().catch(() => null);
    throw responseError(res.status, body);
  }
  // Manejar respuestas sin contenido (204)
  if (res.status === 204) {
    return null;
  }
  return res.json();
};

export const authAPI = {
  login: async (username: string, password: string) => {
    const res = await fetch(`${API_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    return handleResponse(res);
  },
  
  register: async (usernameOrData: string | { username: string; password: string; name: string; role?: string }, password?: string, name?: string, role?: string) => {
    const payload = typeof usernameOrData === 'object' 
      ? usernameOrData 
      : { username: usernameOrData, password, name, role };
    const res = await fetch(`${API_URL}/auth/register`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify(payload)
    });
    return handleResponse(res);
  },
  
  getUsers: async () => {
    const res = await fetch(`${API_URL}/auth/users`, { headers: headers() });
    return handleResponse(res);
  },

  verifyAdminPassword: async (password: string): Promise<{ valid: boolean; adminName: string; adminId: string; overrideToken: string }> => {
    const res = await fetch(`${API_URL}/auth/verify-admin`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify({ password })
    });
    return handleResponse(res);
  },

  updateUser: async (id: string, data: any) => {
    const res = await fetch(`${API_URL}/auth/users/${id}`, {
      method: 'PUT',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },

  deleteUser: async (id: string) => {
    const res = await fetch(`${API_URL}/auth/users/${id}`, {
      method: 'DELETE',
      headers: headers()
    });
    return handleResponse(res);
  },
  
  verify: async () => {
    const res = await fetch(`${API_URL}/auth/verify`, { headers: headers() });
    return handleResponse(res);
  },

  getSetupStatus: async (): Promise<{ needsSetup: boolean; needsActivation?: boolean; linked?: boolean; canLink?: boolean; tenant?: { code: string; name: string } | null }> => {
    const res = await fetch(`${API_URL}/auth/setup-status`);
    return handleResponse(res);
  },

  /** Vincula este equipo con el negocio en Lantify Cloud (con el código que entrega el operador) */
  activateCloud: async (code: string, localAdmin?: { username: string; password: string }): Promise<{ code: string; name: string }> => {
    const res = await fetch(`${API_URL}/cloud/activate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code, adminUsername: localAdmin?.username, adminPassword: localAdmin?.password }),
    });
    return handleResponse(res);
  },

  /** Plan, funciones y estado de pago de la licencia del usuario actual */
  getLicense: async () => {
    const res = await fetch(`${API_URL}/license`, { headers: headers() });
    return handleResponse(res);
  },

  setupFirstAdmin: async (data: { name: string; username: string; password: string }) => {
    const res = await fetch(`${API_URL}/auth/setup`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },

  changePassword: async (currentPassword: string, newPassword: string) => {
    const res = await fetch(`${API_URL}/auth/change-password`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify({ currentPassword, newPassword })
    });
    return handleResponse(res);
  }
};

// Menú público de la tienda web (sin costos ni inventario)
export const publicAPI = {
  getCatalog: async (): Promise<{ products: any[]; categories: any[] }> => {
    const res = await fetch(`${API_URL}/public/catalog`);
    return handleResponse(res);
  }
};

export const productsAPI = {
  getAll: async () => {
    const res = await fetch(`${API_URL}/products`, { headers: headers() });
    return handleResponse(res);
  },
  
  create: async (data: any) => {
    const res = await fetch(`${API_URL}/products`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },
  
  update: async (id: string, data: any) => {
    const res = await fetch(`${API_URL}/products/${id}`, {
      method: 'PUT',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },
  
  delete: async (id: string) => {
    const res = await fetch(`${API_URL}/products/${id}`, {
      method: 'DELETE',
      headers: headers()
    });
    return handleResponse(res);
  },
  
  importCSV: async (csvContent: string) => {
    const res = await fetch(`${API_URL}/products/import`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify({ csvContent })
    });
    return handleResponse(res);
  },
  
  getCategories: async () => {
    const res = await fetch(`${API_URL}/products/categories`, { headers: headers() });
    return handleResponse(res);
  },
  
  createCategory: async (data: any) => {
    const res = await fetch(`${API_URL}/products/categories`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },
  
  getDuplicates: async () => {
    const res = await fetch(`${API_URL}/products/duplicates/find`, { headers: headers() });
    return handleResponse(res);
  },
  
  cleanupDuplicates: async (keys: string[]) => {
    const res = await fetch(`${API_URL}/products/duplicates/cleanup`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify({ keys })
    });
    return handleResponse(res);
  }
};

export const tablesAPI = {
  getAll: async () => {
    const res = await fetch(`${API_URL}/tables`, { headers: headers() });
    return handleResponse(res);
  },
  
  create: async (data: any) => {
    const res = await fetch(`${API_URL}/tables`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },
  
  update: async (id: string, data: any) => {
    const res = await fetch(`${API_URL}/tables/${id}`, {
      method: 'PUT',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },
  
  updateStatus: async (id: string, status: string) => {
    const res = await fetch(`${API_URL}/tables/${id}/status`, {
      method: 'PATCH',
      headers: headers(),
      body: JSON.stringify({ status })
    });
    return handleResponse(res);
  },
  
  occupy: async (id: string) => {
    const res = await fetch(`${API_URL}/tables/${id}/occupy`, {
      method: 'PATCH',
      headers: headers()
    });
    return handleResponse(res);
  },
  
  // Nuevo: poner mesa en pendiente (para cobrar)
  setPending: async (id: string) => {
    const res = await fetch(`${API_URL}/tables/${id}/pending`, {
      method: 'PATCH',
      headers: headers()
    });
    return handleResponse(res);
  },
  
  // Nuevo: cerrar mesa (de pendiente a libre)
  closeTable: async (id: string) => {
    const res = await fetch(`${API_URL}/tables/${id}/close`, {
      method: 'PATCH',
      headers: headers()
    });
    return handleResponse(res);
  },
  
  release: async (id: string, cancellation?: { reason: string; adminAuthToken?: string }) => {
    const res = await fetch(`${API_URL}/tables/${id}/release`, {
      method: 'PATCH',
      headers: headers(),
      body: JSON.stringify(cancellation || {})
    });
    return handleResponse(res);
  },
  
  delete: async (id: string) => {
    const res = await fetch(`${API_URL}/tables/${id}`, {
      method: 'DELETE',
      headers: headers()
    });
    return handleResponse(res);
  }
};

export const salesAPI = {
  getAll: async () => {
    const res = await fetch(`${API_URL}/sales`, { headers: headers() });
    return handleResponse(res);
  },
  
  create: async (data: any) => {
    const res = await fetch(`${API_URL}/sales`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },

  getAuditLogs: async () => {
    const res = await fetch(`${API_URL}/sales/audit/logs`, { headers: headers() });
    return handleResponse(res);
  },
  
  getByTable: async (tableId: string) => {
    const res = await fetch(`${API_URL}/sales/table/${tableId}`, { headers: headers() });
    return handleResponse(res);
  },
  
  getById: async (id: string) => {
    const res = await fetch(`${API_URL}/sales/${id}`, { headers: headers() });
    return handleResponse(res);
  },
  
  complete: async (id: string) => {
    const res = await fetch(`${API_URL}/sales/${id}/complete`, {
      method: 'PATCH',
      headers: headers()
    });
    return handleResponse(res);
  },
  
  cancel: async (id: string) => {
    const res = await fetch(`${API_URL}/sales/${id}/cancel`, {
      method: 'PATCH',
      headers: headers()
    });
    return handleResponse(res);
  },

  /** Asigna o cambia el cliente de la venta (null = Cliente común) */
  changeCustomer: async (id: string, customerId: string | null) => {
    const res = await fetch(`${API_URL}/sales/${id}/customer`, { method: 'PATCH', headers: headers(), body: JSON.stringify({ customerId }) });
    return handleResponse(res);
  },

  /** ADMIN: corrige la propina sin cambiar el valor de la venta (queda quién y por qué) */
  adjustTip: async (id: string, tip: number, reason: string) => {
    const res = await fetch(`${API_URL}/sales/${id}/tip`, { method: 'PATCH', headers: headers(), body: JSON.stringify({ tip, reason }) });
    return handleResponse(res);
  },
  
  // Anulación de items
  cancelItem: async (itemId: string, reason: string) => {
    const res = await fetch(`${API_URL}/sales/items/${itemId}/cancel`, {
      method: 'PATCH',
      headers: headers(),
      body: JSON.stringify({ reason })
    });
    return handleResponse(res);
  },
  
  // Pagos/abonos
  addPayment: async (data: {
    saleId: string;
    amount: number;
    paymentMethod: string;
    cashSessionId: string;
    notes?: string;
  }) => {
    const res = await fetch(`${API_URL}/sales/payments`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },
  
  getPayments: async (saleId: string) => {
    const res = await fetch(`${API_URL}/sales/${saleId}/payments`, { headers: headers() });
    return handleResponse(res);
  },
  
  getPaidTotal: async (saleId: string) => {
    const res = await fetch(`${API_URL}/sales/${saleId}/paid-total`, { headers: headers() });
    return handleResponse(res);
  },
  
  getAvailableMonths: async () => {
    const res = await fetch(`${API_URL}/sales/available-months`, { headers: headers() });
    return handleResponse(res);
  },
  
  getByMonth: async (
    year: number,
    month: number,
    page: number = 1,
    limit: number = 50,
    filters?: { cashSessionId?: string; status?: string }
  ) => {
    const params = new URLSearchParams({
      year: String(year),
      month: String(month),
      page: String(page),
      limit: String(limit),
    });
    if (filters?.cashSessionId) params.set('cashSessionId', filters.cashSessionId);
    if (filters?.status)        params.set('status', filters.status);
    const res = await fetch(`${API_URL}/sales/by-month?${params}`, { headers: headers() });
    return handleResponse(res);
  }
};

export const ordersAPI = {
  getActive: async () => {
    const res = await fetch(`${API_URL}/orders/active`, { headers: headers() });
    return handleResponse(res);
  },
  getByTable: async (tableId: string) => {
    const res = await fetch(`${API_URL}/orders/table/${tableId}`, { headers: headers() });
    return handleResponse(res);
  },
  save: async (data: any) => {
    const res = await fetch(`${API_URL}/orders`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },
  sendToKitchen: async (orderId: string) => {
    const res = await fetch(`${API_URL}/orders/${orderId}/send`, {
      method: 'POST',
      headers: headers()
    });
    return handleResponse(res);
  },
  cancelItem: async (itemId: string, reason: string) => {
    const res = await fetch(`${API_URL}/orders/items/${itemId}/cancel`, {
      method: 'PATCH',
      headers: headers(),
      body: JSON.stringify({ reason })
    });
    return handleResponse(res);
  },
  cancelItemPartial: async (itemId: string, data: { quantity: number; reason: string; comments?: string; wasteDestination?: 'waste' | 'restock'; adminAuthToken?: string }) => {
    const res = await fetch(`${API_URL}/orders/items/${itemId}/cancel-partial`, {
      method: 'PATCH',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },
  close: async (orderId: string, status = 'COMPLETED') => {
    const res = await fetch(`${API_URL}/orders/${orderId}/close`, {
      method: 'PATCH',
      headers: headers(),
      body: JSON.stringify({ status })
    });
    return handleResponse(res);
  }
};

export const cashSessionAPI = {
  getOpen: async () => {
    const res = await fetch(`${API_URL}/cash-sessions/open`, { headers: headers() });
    return handleResponse(res);
  },
  
  open: async (data: { initialBalance: number; notes?: string }) => {
    const res = await fetch(`${API_URL}/cash-sessions`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },
  
  close: async (id: string, data: { countedBalance: number; notes?: string }) => {
    const res = await fetch(`${API_URL}/cash-sessions/${id}/close`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },
  
  addIncome: async (id: string, amount: number, motive: string, description?: string) => {
    const res = await fetch(`${API_URL}/cash-sessions/${id}/income`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify({ amount, motive, description })
    });
    return handleResponse(res);
  },
  
  addExpense: async (id: string, amount: number, motive: string, description?: string, categoryId?: string) => {
    const res = await fetch(`${API_URL}/cash-sessions/${id}/expense`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify({ amount, motive, description, categoryId })
    });
    return handleResponse(res);
  },
  
  cancelIncome: async (sessionId: string, incomeId: string, reason: string) => {
    const res = await fetch(`${API_URL}/cash-sessions/${sessionId}/income/cancel`, {
      method: 'PUT',
      headers: headers(),
      body: JSON.stringify({ incomeId, reason })
    });
    return handleResponse(res);
  },
  
  cancelExpense: async (sessionId: string, expenseId: string, reason: string) => {
    const res = await fetch(`${API_URL}/cash-sessions/${sessionId}/expense/cancel`, {
      method: 'PUT',
      headers: headers(),
      body: JSON.stringify({ expenseId, reason })
    });
    return handleResponse(res);
  }
};

export const customersAPI = {
  getAll: async () => {
    const res = await fetch(`${API_URL}/customers`, { headers: headers() });
    return handleResponse(res);
  },
  search: async (q: string) => {
    const res = await fetch(`${API_URL}/customers/search?q=${encodeURIComponent(q)}`, { headers: headers() });
    return handleResponse(res);
  },
  getDefault: async () => {
    const res = await fetch(`${API_URL}/customers/default`, { headers: headers() });
    return handleResponse(res);
  },
  getBirthdays: async () => {
    const res = await fetch(`${API_URL}/customers/birthdays`, { headers: headers() });
    return handleResponse(res);
  },
  getById: async (id: string) => {
    const res = await fetch(`${API_URL}/customers/${id}`, { headers: headers() });
    return handleResponse(res);
  },
  getRecommended: async (id: string) => {
    const res = await fetch(`${API_URL}/customers/${id}/recommended`, { headers: headers() });
    return handleResponse(res);
  },
  create: async (data: any) => {
    const res = await fetch(`${API_URL}/customers`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },
  update: async (id: string, data: any) => {
    const res = await fetch(`${API_URL}/customers/${id}`, {
      method: 'PUT',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },
  delete: async (id: string) => {
    const res = await fetch(`${API_URL}/customers/${id}`, {
      method: 'DELETE',
      headers: headers()
    });
    return handleResponse(res);
  },
  adjustStamps: async (id: string, delta: number, reason?: string) => {
    const res = await fetch(`${API_URL}/customers/${id}/stamps`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify({ delta, reason })
    });
    return handleResponse(res);
  }
};

// Tarjeta de sellos del cliente (en vivo hacia su tarjeta digital; sin internet queda en cola)
export interface LoyaltyStatus {
  stampsCount: number;
  lifetimeStamps: number;
  stampsRequired: number;
  rewardText: string;
  enabled: boolean;
  hasCard: boolean;
  /** Equipo conectado a Lantify Cloud (sin eso no hay tarjeta digital) */
  linked: boolean;
  hasPhone: boolean;
  /** Movimientos que aún no llegan a la nube (sin internet) */
  queued: number;
  /** Sellos guardados que recibirá al registrarse en la página con su celular */
  waitingSignup: number;
  lastEvent: { id: string; stamps: number; status: StampEventStatus; createdAt: string; syncedAt: string | null } | null;
}
export type StampEventStatus = 'QUEUED' | 'APPLIED' | 'WAITING_SIGNUP';

export const loyaltyAPI = {
  status: async (customerId: string): Promise<LoyaltyStatus> =>
    handleResponse(await fetch(`${API_URL}/loyalty/customers/${customerId}`, { headers: headers() })),
  adjust: async (customerId: string, delta: number, reason?: string): Promise<Customer & { stampEventId: string }> =>
    handleResponse(await fetch(`${API_URL}/loyalty/customers/${customerId}/stamps`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify({ delta, reason }),
    })),
  event: async (id: string): Promise<{ id: string; status: StampEventStatus; stamps: number; syncedAt: string | null }> =>
    handleResponse(await fetch(`${API_URL}/loyalty/events/${id}`, { headers: headers() })),
  cardLink: async (customerId: string): Promise<{ url: string; expiresAt: string; phone: string | null }> =>
    handleResponse(await fetch(`${API_URL}/loyalty/customers/${customerId}/card-link`, { method: 'POST', headers: headers() })),
};

export const expenseCategoriesAPI = {
  getAll: async () => {
    const res = await fetch(`${API_URL}/expense-categories`, { headers: headers() });
    return handleResponse(res);
  },
  create: async (data: any) => {
    const res = await fetch(`${API_URL}/expense-categories`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },
  update: async (id: string, data: any) => {
    const res = await fetch(`${API_URL}/expense-categories/${id}`, {
      method: 'PUT',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },
  delete: async (id: string) => {
    const res = await fetch(`${API_URL}/expense-categories/${id}`, {
      method: 'DELETE',
      headers: headers()
    });
    return handleResponse(res);
  }
};

export const analyticsAPI = {
  /** Ventas por canal (salón, página, Rappi, WhatsApp) */
  getChannelStats: async () => handleResponse(await fetch(`${API_URL}/analytics/channels`, { headers: headers() })),
  compareMonths: async (monthKeys: string[]) => {
    const params = new URLSearchParams({ months: monthKeys.join(',') });
    const res = await fetch(`${API_URL}/analytics/compare-months?${params}`, { headers: headers() });
    return handleResponse(res);
  },
  getTopProducts: async (year?: number, month?: number, limit: number = 50) => {
    const params = new URLSearchParams();
    if (year) params.append('year', String(year));
    if (month) params.append('month', String(month));
    if (limit) params.append('limit', String(limit));
    const res = await fetch(`${API_URL}/analytics/top-products?${params}`, { headers: headers() });
    return handleResponse(res);
  }
};

export const inventoryAPI = {
  getStatus: async (onlyTracked: boolean = true) => {
    const res = await fetch(`${API_URL}/inventory?onlyTracked=${onlyTracked}`, { headers: headers() });
    return handleResponse(res);
  },
  toggleTrack: async (variantId: string, enabled: boolean) => {
    const res = await fetch(`${API_URL}/inventory/${variantId}/toggle`, {
      method: 'PUT',
      headers: headers(),
      body: JSON.stringify({ enabled })
    });
    return handleResponse(res);
  },
  adjustStock: async (variantId: string, quantity: number, type: 'MANUAL_ADD' | 'MANUAL_REMOVE', notes?: string) => {
    const res = await fetch(`${API_URL}/inventory/${variantId}/adjust`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify({ quantity, type, notes })
    });
    return handleResponse(res);
  },
  submitCount: async (variantId: string, countedStock: number, justification?: string, userId?: string) => {
    const res = await fetch(`${API_URL}/inventory/${variantId}/count`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify({ countedStock, justification, userId })
    });
    return handleResponse(res);
  },
  getMovements: async (variantId: string) => {
    const res = await fetch(`${API_URL}/inventory/${variantId}/movements`, { headers: headers() });
    return handleResponse(res);
  },
  getCounts: async (variantId: string) => {
    const res = await fetch(`${API_URL}/inventory/${variantId}/counts`, { headers: headers() });
    return handleResponse(res);
  }
};

export const versionAPI = {
  get: async () => {
    const res = await fetch(`${API_URL}/version`, { headers: headers() });
    return handleResponse(res);
  },
  checkUpdate: async () => {
    const res = await fetch(`${API_URL}/version/check`, { headers: headers() });
    return handleResponse(res);
  },
  applyUpdate: async () => {
    const res = await fetch(`${API_URL}/version/apply-update`, {
      method: 'POST',
      headers: headers()
    });
    return handleResponse(res);
  }
};

export type BusinessType = 'RESTAURANT' | 'CAFE' | 'BAR' | 'FAST_FOOD' | 'FOOD_TRUCK' | 'RETAIL';
export type TaxType = 'IVA' | 'INC' | 'NONE';
export type TaxRegime = 'NO_RESPONSABLE' | 'RESPONSABLE_INC' | 'RESPONSABLE_IVA';

export interface BusinessSettings {
  businessType: BusinessType;
  businessName: string;
  legalName: string | null;
  nit: string | null;
  dv: string | null;
  taxRegime: TaxRegime;
  address: string | null;
  city: string | null;
  phone: string | null;
  email: string | null;
  ticketFooter: string | null;
  usesTables: boolean;
  deliveryEnabled: boolean;
  /** Canales de venta del plan Premium (se encienden en Configuración) */
  whatsappEnabled?: boolean;
  rappiEnabled?: boolean;
  inventoryEnabled: boolean;
  tipEnabled: boolean;
  tipPercent: number;
  defaultTaxType: TaxType;
  defaultTaxRate: number;
  wantsElectronicInvoice: boolean;
  onboardingCompletedAt: string | null;
  onboardingDismissedAt?: string | null;
}

export interface OnboardingPayload {
  settings: Partial<Omit<BusinessSettings, 'onboardingCompletedAt'>> & { businessType: BusinessType; businessName: string };
  zones?: { name: string; tables: number }[];
  staff?: { name: string; username: string; password: string; role: 'CASHIER' | 'WAITER' }[];
  loadSampleMenu?: boolean;
  /** Carta leída con IA de una foto (reemplaza al menú de ejemplo) */
  menu?: MenuCategory[];
  language?: 'es' | 'en';
}

export interface MenuCategory {
  name: string;
  items: { name: string; price: number }[];
}

export interface SetupSuggestion {
  businessType: BusinessType;
  businessName: string | null;
  city: string | null;
  usesTables: boolean;
  zones: { name: string; tables: number }[];
  tipEnabled: boolean;
  tipPercent: number;
  taxRegime: TaxRegime;
  inventoryEnabled: boolean;
  deliveryEnabled: boolean;
  summary: string;
}

/** Asistente de configuración inicial (ADMIN): descripción → configuración; foto → carta */
export const setupAIAPI = {
  suggest: async (description: string, lang: string): Promise<SetupSuggestion> => {
    const res = await fetch(`${API_URL}/ai/setup`, { method: 'POST', headers: headers(), body: JSON.stringify({ description, lang }) });
    return handleResponse(res);
  },
  readMenu: async (image: string, mimeType: string, lang: string): Promise<{ categories: MenuCategory[] }> => {
    const res = await fetch(`${API_URL}/ai/menu`, { method: 'POST', headers: headers(), body: JSON.stringify({ image, mimeType, lang }) });
    return handleResponse(res);
  },
};

export const businessAPI = {
  get: async (): Promise<BusinessSettings> => {
    const res = await fetch(`${API_URL}/business`, { headers: headers() });
    return handleResponse(res);
  },

  update: async (data: Partial<Omit<BusinessSettings, 'onboardingCompletedAt'>>): Promise<BusinessSettings> => {
    const res = await fetch(`${API_URL}/business`, {
      method: 'PUT',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },

  dismissOnboarding: async (): Promise<BusinessSettings> => {
    const res = await fetch(`${API_URL}/business/onboarding/dismiss`, { method: 'POST', headers: headers() });
    return handleResponse(res);
  },

  completeOnboarding: async (data: OnboardingPayload): Promise<{ settings: BusinessSettings; tablesCreated: number; staffCreated: number; sampleProducts: number }> => {
    const res = await fetch(`${API_URL}/business/onboarding`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },
};

// ── Gastos y lectura de facturas ────────────────────────────

export type PaymentSource = 'CASH_DRAWER' | 'BANK' | 'CARD' | 'NEQUI' | 'OTHER';

export interface ExpenseRecord {
  id: string;
  amount: number;
  motive: string;
  description: string | null;
  categoryId: string | null;
  category: { id: string; name: string; color: string | null } | null;
  paymentSource: PaymentSource;
  cashSessionId: string | null;
  cashSession?: { sessionNumber: string } | null;
  supplierName: string | null;
  supplierNit: string | null;
  invoiceNumber: string | null;
  invoiceDate: string | null;
  subtotal: number | null;
  taxAmount: number | null;
  captureMode: 'MANUAL' | 'AI_REVIEWED' | 'AI_AUTO';
  aiConfidence: number | null;
  createdBy: string | null;
  isCancelled: boolean;
  cancellationReason: string | null;
  createdAt: string;
  hasImage: boolean;
}

export interface ExpenseList {
  total: number;
  count: number;
  tax: number;
  byCategory: { id: string | null; name: string; color: string | null; total: number; count: number }[];
  bySource: { source: PaymentSource; total: number }[];
  expenses: ExpenseRecord[];
}

export interface InvoiceReading {
  isInvoice: boolean;
  supplierName: string | null;
  supplierNit: string | null;
  invoiceNumber: string | null;
  invoiceDate: string | null;
  subtotal: number | null;
  tax: number | null;
  total: number | null;
  paymentMethod: 'CASH' | 'CARD' | 'TRANSFER' | null;
  category: string | null;
  items: { description: string; quantity: number | null; total: number | null }[];
  confidence: number;
}

export type ScanResult =
  | { mode: 'auto'; reading: InvoiceReading; categoryId: string | null; paymentSource: PaymentSource; expense: ExpenseRecord }
  | { mode: 'review'; reading: InvoiceReading; categoryId: string | null; paymentSource: PaymentSource };

export const expensesAPI = {
  list: async (from?: string, to?: string): Promise<ExpenseList> => {
    const q = new URLSearchParams();
    if (from) q.set('from', from);
    if (to) q.set('to', to);
    const res = await fetch(`${API_URL}/expenses${q.toString() ? `?${q}` : ''}`, { headers: headers() });
    return handleResponse(res);
  },
  create: async (data: Record<string, unknown>): Promise<ExpenseRecord> => {
    const res = await fetch(`${API_URL}/expenses`, { method: 'POST', headers: headers(), body: JSON.stringify(data) });
    return handleResponse(res);
  },
  scan: async (image: string, mimeType: string, lang: string): Promise<ScanResult> => {
    const res = await fetch(`${API_URL}/expenses/scan`, { method: 'POST', headers: headers(), body: JSON.stringify({ image, mimeType, lang }) });
    return handleResponse(res);
  },
  cancel: async (id: string, reason: string) => {
    const res = await fetch(`${API_URL}/expenses/${id}/cancel`, { method: 'PATCH', headers: headers(), body: JSON.stringify({ reason }) });
    return handleResponse(res);
  },
  /** La foto se pide con la sesión (no puede ir en un <img src>): se devuelve como URL local */
  imageUrl: async (id: string) => {
    const res = await fetch(`${API_URL}/expenses/${id}/image`, { headers: headers() });
    if (!res.ok) throw responseError(res.status, await res.json().catch(() => null));
    return URL.createObjectURL(await res.blob());
  },
};

export interface AiSettings {
  consent: boolean;
  consentAt: string | null;
  consentBy: string | null;
  expenseAutoRegister: boolean;
}

export const aiSettingsAPI = {
  get: async (): Promise<AiSettings> => handleResponse(await fetch(`${API_URL}/ai/settings`, { headers: headers() })),
  update: async (data: Partial<Pick<AiSettings, 'consent' | 'expenseAutoRegister'>>): Promise<AiSettings> =>
    handleResponse(await fetch(`${API_URL}/ai/settings`, { method: 'PUT', headers: headers(), body: JSON.stringify(data) })),
};

// ── Proveedores y cupones ───────────────────────────────────

export interface SupplierPrice {
  id: string;
  itemName: string;
  unit: string | null;
  price: number;
  source: 'MANUAL' | 'INVOICE';
  updatedAt: string;
}

export interface Supplier {
  id: string;
  name: string;
  nit: string | null;
  phone: string | null;
  email: string | null;
  contactName: string | null;
  notes: string | null;
  isActive: boolean;
  prices: SupplierPrice[];
}

export const suppliersAPI = {
  list: async (): Promise<Supplier[]> => handleResponse(await fetch(`${API_URL}/suppliers`, { headers: headers() })),
  create: async (data: Partial<Supplier>): Promise<Supplier> =>
    handleResponse(await fetch(`${API_URL}/suppliers`, { method: 'POST', headers: headers(), body: JSON.stringify(data) })),
  update: async (id: string, data: Partial<Supplier>): Promise<Supplier> =>
    handleResponse(await fetch(`${API_URL}/suppliers/${id}`, { method: 'PUT', headers: headers(), body: JSON.stringify(data) })),
  savePrices: async (id: string, prices: { itemName: string; unit?: string | null; price: number }[]): Promise<Supplier> =>
    handleResponse(await fetch(`${API_URL}/suppliers/${id}/prices`, { method: 'PUT', headers: headers(), body: JSON.stringify({ prices }) })),
  deletePrice: async (id: string, priceId: string) =>
    handleResponse(await fetch(`${API_URL}/suppliers/${id}/prices/${priceId}`, { method: 'DELETE', headers: headers() })),
};

export interface Coupon {
  id: string;
  code: string;
  description: string | null;
  type: 'PERCENT' | 'AMOUNT';
  value: number;
  minPurchase: number | null;
  startsAt: string | null;
  endsAt: string | null;
  maxUses: number | null;
  uses: number;
  isActive: boolean;
  source: 'MANUAL' | 'AGENT';
  createdAt: string;
}

export const couponsAPI = {
  list: async (): Promise<Coupon[]> => handleResponse(await fetch(`${API_URL}/coupons`, { headers: headers() })),
  create: async (data: Record<string, unknown>): Promise<Coupon> =>
    handleResponse(await fetch(`${API_URL}/coupons`, { method: 'POST', headers: headers(), body: JSON.stringify(data) })),
  update: async (id: string, data: Record<string, unknown>): Promise<Coupon> =>
    handleResponse(await fetch(`${API_URL}/coupons/${id}`, { method: 'PUT', headers: headers(), body: JSON.stringify(data) })),
  validate: async (code: string, subtotal: number): Promise<{ code: string; type: string; value: number; description: string | null; discount: number }> =>
    handleResponse(await fetch(`${API_URL}/coupons/validate?code=${encodeURIComponent(code)}&subtotal=${Math.round(subtotal)}`, { headers: headers() })),
};

// ── Agentes ─────────────────────────────────────────────────

export type AgentId = 'backoffice' | 'purchasing' | 'marketing';

export interface AgentChart {
  type: 'bar' | 'line';
  title: string;
  unit: 'COP' | 'units' | '%';
  labels: string[];
  series: { name: string; values: number[] }[];
}

export type AgentAction =
  | { type: 'purchase_order'; supplierId: string; supplierName: string; phone: string | null; items: { itemName: string; quantity: number; unit: string | null; price: number | null }[]; note: string | null }
  | { type: 'create_coupon'; code: string; description: string | null; discountType: 'PERCENT' | 'AMOUNT'; value: number; minPurchase: number | null; days: number };

export interface AgentMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  chart: AgentChart | null;
  actions: AgentAction[];
  userName: string | null;
  createdAt: string;
}

export const agentsAPI = {
  messages: async (agent: AgentId): Promise<AgentMessage[]> => handleResponse(await fetch(`${API_URL}/agents/${agent}/messages`, { headers: headers() })),
  clear: async (agent: AgentId) => handleResponse(await fetch(`${API_URL}/agents/${agent}/messages`, { method: 'DELETE', headers: headers() })),
  context: async (agent: AgentId): Promise<unknown> => handleResponse(await fetch(`${API_URL}/agents/${agent}/context`, { headers: headers() })),
  ask: async (agent: AgentId, question: string, lang: string): Promise<AgentMessage> =>
    handleResponse(await fetch(`${API_URL}/agents/${agent}/ask`, { method: 'POST', headers: headers(), body: JSON.stringify({ question, lang }) })),
  createCoupon: async (action: Extract<AgentAction, { type: 'create_coupon' }>): Promise<Coupon> =>
    handleResponse(await fetch(`${API_URL}/agents/marketing/coupons`, { method: 'POST', headers: headers(), body: JSON.stringify(action) })),
};

// ── Propinas ────────────────────────────────────────────────

export interface TipsSummary {
  total: number;
  count: number;
  cash: number;
  salesCount: number;
  avgPercent: number;
  tipRate: number;
}

export interface TipsReportData {
  enabled: boolean;
  tipPercent: number;
  summary: TipsSummary;
  allTime: { total: number; count: number };
  byMonth: (TipsSummary & { month: string })[];
  bySession: (TipsSummary & { id: string; sessionNumber: string; openedAt: string; closedAt: string | null; status: string; byWaiter: { name: string; total: number; count: number }[] })[];
  byWaiter: { name: string; total: number; count: number }[];
  recent: { id: string; saleNumber: string; createdAt: string; tip: number; total: number; paymentMethod: string; cash: boolean; waiterName: string | null; cashierName: string | null; table: string | null }[];
}

export const tipsAPI = {
  report: async (from?: string, to?: string): Promise<TipsReportData> => {
    const q = new URLSearchParams();
    if (from) q.set('from', from);
    if (to) q.set('to', to);
    const res = await fetch(`${API_URL}/tips${q.toString() ? `?${q}` : ''}`, { headers: headers() });
    return handleResponse(res);
  },
  session: async (id: string): Promise<TipsSummary & { byWaiter: { name: string; total: number; count: number }[] }> => {
    const res = await fetch(`${API_URL}/tips/session/${id}`, { headers: headers() });
    return handleResponse(res);
  },
};

/**
 * Exportar ventas y facturas (CSV). Usa un permiso de 15 minutos: el ADMIN lo pide
 * con su sesión, o lo recibe al intentar entrar con la cuenta suspendida.
 */
export const exportAPI = {
  token: async (): Promise<{ exportToken: string }> => {
    const res = await fetch(`${API_URL}/export/token`, { method: 'POST', headers: headers() });
    return handleResponse(res);
  },
  download: async (kind: 'sales' | 'invoices', exportToken: string) => {
    const res = await fetch(`${API_URL}/export/${kind}.csv`, { headers: { Authorization: `Bearer ${exportToken}` } });
    if (!res.ok) throw responseError(res.status, await res.json().catch(() => null));
    const name = /filename="([^"]+)"/.exec(res.headers.get('Content-Disposition') || '')?.[1] || `lantify-${kind}.csv`;
    const url = URL.createObjectURL(await res.blob());
    const link = document.createElement('a');
    link.href = url;
    link.download = name;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  },
};

export const systemAPI = {
  getBackups: async () => {
    const res = await fetch(`${API_URL}/system/backups`, { headers: headers() });
    return handleResponse(res);
  },
  createBackup: async () => {
    const res = await fetch(`${API_URL}/system/backups`, {
      method: 'POST',
      headers: headers(),
    });
    return handleResponse(res);
  },
};

export const dianAPI = {
  getConfig: async () => {
    const res = await fetch(`${API_URL}/dian/config`, { headers: headers() });
    return handleResponse(res);
  },
  updateConfig: async (data: any) => {
    const res = await fetch(`${API_URL}/dian/config`, {
      method: 'PUT',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },
  getStats: async () => {
    const res = await fetch(`${API_URL}/dian/stats`, { headers: headers() });
    return handleResponse(res);
  },
  getQueue: async (status?: string) => {
    const query = status ? `?status=${status}` : '';
    const res = await fetch(`${API_URL}/dian/queue${query}`, { headers: headers() });
    return handleResponse(res);
  },
  processQueue: async () => {
    const res = await fetch(`${API_URL}/dian/queue/process`, {
      method: 'POST',
      headers: headers()
    });
    return handleResponse(res);
  },
  retryInvoice: async (id: string) => {
    const res = await fetch(`${API_URL}/dian/queue/${id}/retry`, {
      method: 'POST',
      headers: headers()
    });
    return handleResponse(res);
  },
  emitInvoice: async (saleId: string, customer?: any) => {
    const res = await fetch(`${API_URL}/dian/emit`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify({ saleId, customer })
    });
    return handleResponse(res);
  },
  getResolution: async (): Promise<{ resolution: { resolutionNumber: string; resolutionDate: string; prefix: string; rangeFrom: number; rangeTo: number; operationMode: string } | null }> => {
    const res = await fetch(`${API_URL}/dian/resolution`, { headers: headers() });
    return handleResponse(res);
  },
  getSaleInvoice: async (saleId: string) => {
    const res = await fetch(`${API_URL}/dian/sale/${saleId}`, { headers: headers() });
    return handleResponse(res);
  },
  testFactusConnection: async (credentials?: any) => {
    const res = await fetch(`${API_URL}/dian/factus/test-connection`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify(credentials || {})
    });
    return handleResponse(res);
  },
  getFactusRanges: async () => {
    const res = await fetch(`${API_URL}/dian/factus/ranges`, { headers: headers() });
    return handleResponse(res);
  },
  getXmlUrl: (invoiceId: string) => `${API_URL}/dian/invoice/${invoiceId}/xml`
};



// ============================================
// RESERVAS
// ============================================

export type ReservationStatus = 'PENDING' | 'CONFIRMED' | 'SEATED' | 'CANCELLED' | 'NO_SHOW';
export type ReservationChannel = 'POS' | 'WHATSAPP' | 'PHONE' | 'WALK_IN' | 'ONLINE';

export interface Reservation {
  id: string;
  code: string;
  tableId: string | null;
  table: { id: string; number: string; zone: string | null; capacity: number } | null;
  customerId: string | null;
  customer: { id: string; name: string; phone: string | null } | null;
  customerName: string;
  customerPhone: string | null;
  customerEmail: string | null;
  partySize: number;
  startsAt: string;
  endsAt: string;
  date: string;
  time: string;
  endTime: string;
  status: ReservationStatus;
  channel: ReservationChannel;
  notes: string | null;
  cancelReason: string | null;
  createdBy: string | null;
  cloudConflict: boolean;
  marketingOptIn: boolean;
}

export interface BookingScheduleBlock {
  day: number;
  from: string;
  to: string;
}

export interface BookingSettings {
  enabled: boolean;
  online: boolean;
  slotMinutes: number;
  durationMinutes: number;
  minAdvanceMinutes: number;
  maxDaysAhead: number;
  maxPartySize: number;
  requireConfirmation: boolean;
  cancelUntilMinutes: number;
  schedule: BookingScheduleBlock[];
  utcOffsetMinutes: number;
  whatsapp: string | null;
  message: string | null;
}

export interface BookingConfig {
  settings: BookingSettings;
  slug: string | null;
  publishedAt: string | null;
  syncAt: string | null;
  tables: { id: string; number: string; zone: string | null; capacity: number; reservable: boolean }[];
  /** Resultado de publicar en Lantify Cloud al guardar (si hay reservas en línea) */
  publish?: { ok: boolean; code?: string; url?: string; slug?: string };
}

export const reservationsAPI = {
  list: async (date: string): Promise<Reservation[]> => {
    const res = await fetch(`${API_URL}/reservations?date=${date}`, { headers: headers() });
    return handleResponse(res);
  },
  summary: async (): Promise<{ pending: number; conflicts: number; upcoming: number; latest: string }> => {
    const res = await fetch(`${API_URL}/reservations/summary`, { headers: headers() });
    return handleResponse(res);
  },
  availability: async (date: string, party: number): Promise<{ time: string; minutes: number; available: boolean }[]> => {
    const res = await fetch(`${API_URL}/reservations/availability?date=${date}&party=${party}`, { headers: headers() });
    return handleResponse(res);
  },
  create: async (data: Record<string, unknown>): Promise<Reservation> => {
    const res = await fetch(`${API_URL}/reservations`, { method: 'POST', headers: headers(), body: JSON.stringify(data) });
    return handleResponse(res);
  },
  update: async (id: string, data: Record<string, unknown>): Promise<Reservation> => {
    const res = await fetch(`${API_URL}/reservations/${id}`, { method: 'PATCH', headers: headers(), body: JSON.stringify(data) });
    return handleResponse(res);
  },
  settings: async (): Promise<BookingConfig> => {
    const res = await fetch(`${API_URL}/reservations/settings`, { headers: headers() });
    return handleResponse(res);
  },
  saveSettings: async (data: { settings: BookingSettings; reservableTableIds: string[]; slug?: string }): Promise<BookingConfig> => {
    const res = await fetch(`${API_URL}/reservations/settings`, { method: 'PUT', headers: headers(), body: JSON.stringify(data) });
    return handleResponse(res);
  },
};

// ============================================
// MI PÁGINA (página pública del negocio)
// ============================================

export interface PagePrize {
  id: string;
  label: string;
  kind: 'PERCENT' | 'AMOUNT';
  value: number;
  minPurchase: number | null;
  weight: number;
  dailyLimit: number | null;
  totalLimit: number | null;
  validDays: number;
}

export type OrderPayment = 'CASH' | 'NEQUI' | 'DAVIPLATA' | 'CARD' | 'TRANSFER';

export interface PageOrdering {
  delivery: boolean;
  pickup: boolean;
  deliveryFee: number;
  minOrder: number;
  payments: OrderPayment[];
  eta: string | null;
  notice: string | null;
}

export interface LoyaltyConfig {
  enabled: boolean;
  minSpendPerStamp: number;
  spendPerGamePlay: number;
  stampsRequired: number;
  rewardText: string;
}

export interface SocialConfig {
  googleReviewUrl: string | null;
  instagram: string | null;
  tiktok: string | null;
  facebook: string | null;
  whatsapp: string | null;
}

export interface PageCatalogProduct {
  id: string;
  name: string;
  categoryName: string;
  price: number;
  visible: boolean;
  imageUrl: string | null;
}

export interface PageConfigData {
  sections: { menu: boolean; booking: boolean; signup: boolean; games: boolean; orders: boolean };
  profile: { tagline: string | null; address: string | null; city: string | null; hours: string | null; whatsapp: string | null; instagram: string | null };
  games: {
    type: 'wheel' | 'scratch' | 'trivia'; title: string; noPrizeWeight: number; tryAgainSlots: number;
    prizes: PagePrize[]; trivia: { q: string; options: string[]; answer: number }[];
  };
  legal: { owner: string | null; nit: string | null; email: string | null };
  ordering: PageOrdering;
  theme: PageTheme;
  loyalty: LoyaltyConfig;
  social: SocialConfig;
  hiddenProductIds: string[];
}

export type { PageTheme };

export interface DesignSuggestion {
  theme: PageTheme;
  tagline: string | null;
  why: string;
}

export interface PageState extends PageConfigData {
  slug: string | null;
  suggestedSlug: string;
  url: string | null;
  publishedAt: string | null;
  syncAt: string | null;
  linked: boolean;
  menuSummary: { categories: number; items: number };
  catalog?: PageCatalogProduct[];
  business: { name: string; type: string; city: string | null };
  menuNames: { categories: string[]; items: string[] };
  stats: { members: number; marketing: number; prizesAwarded: number; prizesRedeemed: number };
  activity: {
    members: { id: string; name: string; phone: string | null; createdAt: string; marketingOptIn: boolean }[];
    prizes: { code: string; description: string | null; redeemed: boolean; endsAt: string | null; createdAt: string; customer: string | null }[];
  };
  publish?: { ok: boolean; code?: string; slug?: string };
}

export interface BirthdayRow {
  id: string;
  name: string;
  phone: string | null;
  marketingOptIn: boolean;
  inDays: number;
  day: number;
  month: number;
  favorite: string | null;
}

// ============================================
// PEDIDOS EN LÍNEA (desde la página del negocio)
// ============================================

export type OnlineOrderStatus = 'PENDING' | 'ACCEPTED' | 'READY' | 'COMPLETED' | 'REJECTED' | 'CANCELLED';

export interface OnlineOrder {
  id: string;
  code: string;
  kind: 'DELIVERY' | 'PICKUP';
  status: OnlineOrderStatus;
  statusNote: string | null;
  customerId: string | null;
  customerName: string;
  customerPhone: string | null;
  address: string | null;
  notes: string | null;
  paymentMethod: OrderPayment;
  items: { id: string; name: string; price: number; qty: number; note: string | null }[];
  subtotal: number;
  deliveryFee: number;
  total: number;
  saleId: string | null;
  placedAt: string;
  acceptedBy: string | null;
}

export const onlineOrdersAPI = {
  list: async (date?: string): Promise<OnlineOrder[]> => {
    const res = await fetch(`${API_URL}/online-orders${date ? `?date=${date}` : ''}`, { headers: headers() });
    return handleResponse(res);
  },
  summary: async (): Promise<{ pending: number; open: number; latest: string; latestOrder: { id: string; code: string; customerName: string; total: number; kind: string } | null }> => {
    const res = await fetch(`${API_URL}/online-orders/summary`, { headers: headers() });
    return handleResponse(res);
  },
  act: async (id: string, action: 'accept' | 'reject' | 'ready' | 'complete', body: Record<string, unknown> = {}): Promise<OnlineOrder> => {
    const res = await fetch(`${API_URL}/online-orders/${id}/${action}`, { method: 'POST', headers: headers(), body: JSON.stringify(body) });
    return handleResponse(res);
  },
};

export const pageAPI = {
  get: async (): Promise<PageState> => {
    const res = await fetch(`${API_URL}/page`, { headers: headers() });
    return handleResponse(res);
  },
  save: async (data: PageConfigData & { slug: string }): Promise<PageState> => {
    const res = await fetch(`${API_URL}/page`, { method: 'PUT', headers: headers(), body: JSON.stringify(data) });
    return handleResponse(res);
  },
  publish: async (): Promise<PageState> => {
    const res = await fetch(`${API_URL}/page/publish`, { method: 'POST', headers: headers() });
    return handleResponse(res);
  },
  /** Diseño recomendado por la IA (solo nombres del negocio y de la carta) */
  designAI: async (data: Record<string, unknown>): Promise<DesignSuggestion> => {
    const res = await fetch(`${API_URL}/ai/design`, { method: 'POST', headers: headers(), body: JSON.stringify(data) });
    return handleResponse(res);
  },
  birthdays: async (): Promise<BirthdayRow[]> => {
    const res = await fetch(`${API_URL}/page/birthdays?days=7`, { headers: headers() });
    return handleResponse(res);
  },
};
