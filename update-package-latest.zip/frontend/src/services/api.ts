import { API_URL } from '../config';
import type { PageTheme } from '../../../src/domain/pageTheme';
import type { PrintSettings, PrinterTarget } from '../../../src/domain/printSettings';
import type { TicketDoc } from '../../../src/domain/ticketDoc';
import type { RolePermissions } from '../../../src/domain/rolePermissions';
import type { Customer } from '../types';

import { ApiError, responseError } from './apiErrors';

const getToken = () => localStorage.getItem('token');

const headers = () => ({
  'Content-Type': 'application/json',
  'Authorization': `Bearer ${getToken() || ''}`
});

// Helper para manejar respuestas: los errores salen con un mensaje claro para el usuario
const handleResponse = async (res: Response) => {
  if (!res.ok) {
    const body = await res.json().catch(() => null);
    throw responseError(res.status, body);
  }
  // Manejar respuestas sin contenido (204)
  if (res.status === 204) {
    return null;
  }
  return res.json();
};

export const authAPI = {
  login: async (username: string, password: string) => {
    const res = await fetch(`${API_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    return handleResponse(res);
  },
  
  register: async (usernameOrData: string | { username: string; password: string; name: string; role?: string }, password?: string, name?: string, role?: string) => {
    const payload = typeof usernameOrData === 'object' 
      ? usernameOrData 
      : { username: usernameOrData, password, name, role };
    const res = await fetch(`${API_URL}/auth/register`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify(payload)
    });
    return handleResponse(res);
  },
  
  getUsers: async () => {
    const res = await fetch(`${API_URL}/auth/users`, { headers: headers() });
    return handleResponse(res);
  },

  verifyAdminPassword: async (password: string): Promise<{ valid: boolean; adminName: string; adminId: string; overrideToken: string }> => {
    const res = await fetch(`${API_URL}/auth/verify-admin`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify({ password })
    });
    return handleResponse(res);
  },

  updateUser: async (id: string, data: any) => {
    const res = await fetch(`${API_URL}/auth/users/${id}`, {
      method: 'PUT',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },

  deleteUser: async (id: string) => {
    const res = await fetch(`${API_URL}/auth/users/${id}`, {
      method: 'DELETE',
      headers: headers()
    });
    return handleResponse(res);
  },
  
  verify: async () => {
    const res = await fetch(`${API_URL}/auth/verify`, { headers: headers() });
    return handleResponse(res);
  },

  getSetupStatus: async (): Promise<{ needsSetup: boolean; needsActivation?: boolean; linked?: boolean; canLink?: boolean; tenant?: { code: string; name: string } | null }> => {
    const res = await fetch(`${API_URL}/auth/setup-status`);
    return handleResponse(res);
  },

  /** Vincula este equipo con el negocio en Lantify Cloud (con el código que entrega el operador) */
  activateCloud: async (code: string, localAdmin?: { username: string; password: string }): Promise<{ code: string; name: string }> => {
    const res = await fetch(`${API_URL}/cloud/activate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code, adminUsername: localAdmin?.username, adminPassword: localAdmin?.password }),
    });
    return handleResponse(res);
  },

  /** Plan, funciones y estado de pago de la licencia del usuario actual */
  getLicense: async () => {
    const res = await fetch(`${API_URL}/license`, { headers: headers() });
    return handleResponse(res);
  },

  setupFirstAdmin: async (data: { name: string; username: string; password: string }) => {
    const res = await fetch(`${API_URL}/auth/setup`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },

  changePassword: async (currentPassword: string, newPassword: string) => {
    const res = await fetch(`${API_URL}/auth/change-password`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify({ currentPassword, newPassword })
    });
    return handleResponse(res);
  }
};

// Menú público de la tienda web (sin costos ni inventario)
export const publicAPI = {
  getCatalog: async (): Promise<{ products: any[]; categories: any[] }> => {
    const res = await fetch(`${API_URL}/public/catalog`);
    return handleResponse(res);
  }
};

export const productsAPI = {
  getAll: async () => {
    const res = await fetch(`${API_URL}/products`, { headers: headers() });
    return handleResponse(res);
  },
  
  create: async (data: any) => {
    const res = await fetch(`${API_URL}/products`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },
  
  update: async (id: string, data: any) => {
    const res = await fetch(`${API_URL}/products/${id}`, {
      method: 'PUT',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },
  
  delete: async (id: string) => {
    const res = await fetch(`${API_URL}/products/${id}`, {
      method: 'DELETE',
      headers: headers()
    });
    return handleResponse(res);
  },
  
  importCSV: async (csvContent: string) => {
    const res = await fetch(`${API_URL}/products/import`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify({ csvContent })
    });
    return handleResponse(res);
  },
  
  getCategories: async () => {
    const res = await fetch(`${API_URL}/products/categories`, { headers: headers() });
    return handleResponse(res);
  },
  
  createCategory: async (data: any) => {
    const res = await fetch(`${API_URL}/products/categories`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },
  
  /** Cambia datos de una categoría (nombre, estación de la comanda...) */
  updateCategory: async (id: string, data: { name?: string; description?: string; printStation?: string | null }) =>
    handleResponse(await fetch(`${API_URL}/products/categories/${encodeURIComponent(id)}`, { method: 'PUT', headers: headers(), body: JSON.stringify(data) })),

  /** Productos sueltos que parecen presentaciones del mismo producto */
  variantGroups: async (): Promise<VariantGroup[]> => handleResponse(await fetch(`${API_URL}/products/variant-groups`, { headers: headers() })),
  mergeVariants: async (body: { base: string; productIds: string[]; labels: Record<string, string> }): Promise<{ productId: string; variants: number; deactivated: number }> =>
    handleResponse(await fetch(`${API_URL}/products/variant-groups/merge`, { method: 'POST', headers: headers(), body: JSON.stringify(body) })),

  getDuplicates: async () => {
    const res = await fetch(`${API_URL}/products/duplicates/find`, { headers: headers() });
    return handleResponse(res);
  },
  
  cleanupDuplicates: async (keys: string[]) => {
    const res = await fetch(`${API_URL}/products/duplicates/cleanup`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify({ keys })
    });
    return handleResponse(res);
  },

  createVariant: async (data: { productId: string; name: string; sku: string; price: number; cost?: number | null; stock?: number }) => {
    const res = await fetch(`${API_URL}/products/variants`, { method: 'POST', headers: headers(), body: JSON.stringify(data) });
    return handleResponse(res);
  },

  updateVariant: async (id: string, data: { name?: string; sku?: string; price?: number; cost?: number | null; stock?: number }) => {
    const res = await fetch(`${API_URL}/products/variants/${id}`, { method: 'PUT', headers: headers(), body: JSON.stringify(data) });
    return handleResponse(res);
  },

  /** La variante deja de venderse (las ventas pasadas la conservan) */
  deleteVariant: async (id: string) => {
    const res = await fetch(`${API_URL}/products/variants/${id}`, { method: 'DELETE', headers: headers() });
    return handleResponse(res);
  },
};

export const tablesAPI = {
  getAll: async () => {
    const res = await fetch(`${API_URL}/tables`, { headers: headers() });
    return handleResponse(res);
  },
  
  create: async (data: any) => {
    const res = await fetch(`${API_URL}/tables`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },
  
  update: async (id: string, data: any) => {
    const res = await fetch(`${API_URL}/tables/${id}`, {
      method: 'PUT',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },
  
  updateStatus: async (id: string, status: string) => {
    const res = await fetch(`${API_URL}/tables/${id}/status`, {
      method: 'PATCH',
      headers: headers(),
      body: JSON.stringify({ status })
    });
    return handleResponse(res);
  },
  
  occupy: async (id: string) => {
    const res = await fetch(`${API_URL}/tables/${id}/occupy`, {
      method: 'PATCH',
      headers: headers()
    });
    return handleResponse(res);
  },
  
  // Nuevo: poner mesa en pendiente (para cobrar)
  setPending: async (id: string) => {
    const res = await fetch(`${API_URL}/tables/${id}/pending`, {
      method: 'PATCH',
      headers: headers()
    });
    return handleResponse(res);
  },
  
  // Nuevo: cerrar mesa (de pendiente a libre)
  closeTable: async (id: string) => {
    const res = await fetch(`${API_URL}/tables/${id}/close`, {
      method: 'PATCH',
      headers: headers()
    });
    return handleResponse(res);
  },
  
  release: async (id: string, cancellation?: { reason: string; adminAuthToken?: string }) => {
    const res = await fetch(`${API_URL}/tables/${id}/release`, {
      method: 'PATCH',
      headers: headers(),
      body: JSON.stringify(cancellation || {})
    });
    return handleResponse(res);
  },
  
  delete: async (id: string) => {
    const res = await fetch(`${API_URL}/tables/${id}`, {
      method: 'DELETE',
      headers: headers()
    });
    return handleResponse(res);
  }
};

export const salesAPI = {
  /** Resumen del día para el inicio de Administración (hoy vs. ayer a la misma hora, 7 días) */
  getDaySummary: async () => handleResponse(await fetch(`${API_URL}/sales/day-summary`, { headers: headers() })),
  getAll: async () => {
    const res = await fetch(`${API_URL}/sales`, { headers: headers() });
    return handleResponse(res);
  },
  
  create: async (data: any) => {
    const res = await fetch(`${API_URL}/sales`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },

  getAuditLogs: async () => {
    const res = await fetch(`${API_URL}/sales/audit/logs`, { headers: headers() });
    return handleResponse(res);
  },
  
  getByTable: async (tableId: string) => {
    const res = await fetch(`${API_URL}/sales/table/${tableId}`, { headers: headers() });
    return handleResponse(res);
  },
  
  getById: async (id: string) => {
    const res = await fetch(`${API_URL}/sales/${id}`, { headers: headers() });
    return handleResponse(res);
  },
  
  complete: async (id: string) => {
    const res = await fetch(`${API_URL}/sales/${id}/complete`, {
      method: 'PATCH',
      headers: headers()
    });
    return handleResponse(res);
  },
  
  cancel: async (id: string) => {
    const res = await fetch(`${API_URL}/sales/${id}/cancel`, {
      method: 'PATCH',
      headers: headers()
    });
    return handleResponse(res);
  },

  /** Asigna o cambia el cliente de la venta (null = Cliente común) */
  changeCustomer: async (id: string, customerId: string | null) => {
    const res = await fetch(`${API_URL}/sales/${id}/customer`, { method: 'PATCH', headers: headers(), body: JSON.stringify({ customerId }) });
    return handleResponse(res);
  },

  /** ADMIN: corrige la propina sin cambiar el valor de la venta (queda quién y por qué) */
  adjustTip: async (id: string, tip: number, reason: string) => {
    const res = await fetch(`${API_URL}/sales/${id}/tip`, { method: 'PATCH', headers: headers(), body: JSON.stringify({ tip, reason }) });
    return handleResponse(res);
  },
  
  // Anulación de items
  cancelItem: async (itemId: string, reason: string) => {
    const res = await fetch(`${API_URL}/sales/items/${itemId}/cancel`, {
      method: 'PATCH',
      headers: headers(),
      body: JSON.stringify({ reason })
    });
    return handleResponse(res);
  },
  
  // Pagos/abonos
  addPayment: async (data: {
    saleId: string;
    amount: number;
    paymentMethod: string;
    cashSessionId: string;
    notes?: string;
  }) => {
    const res = await fetch(`${API_URL}/sales/payments`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },
  
  getPayments: async (saleId: string) => {
    const res = await fetch(`${API_URL}/sales/${saleId}/payments`, { headers: headers() });
    return handleResponse(res);
  },
  
  getPaidTotal: async (saleId: string) => {
    const res = await fetch(`${API_URL}/sales/${saleId}/paid-total`, { headers: headers() });
    return handleResponse(res);
  },
  
  getAvailableMonths: async () => {
    const res = await fetch(`${API_URL}/sales/available-months`, { headers: headers() });
    return handleResponse(res);
  },
  
  getByMonth: async (
    year: number,
    month: number,
    page: number = 1,
    limit: number = 50,
    filters?: { cashSessionId?: string; status?: string }
  ) => {
    const params = new URLSearchParams({
      year: String(year),
      month: String(month),
      page: String(page),
      limit: String(limit),
    });
    if (filters?.cashSessionId) params.set('cashSessionId', filters.cashSessionId);
    if (filters?.status)        params.set('status', filters.status);
    const res = await fetch(`${API_URL}/sales/by-month?${params}`, { headers: headers() });
    return handleResponse(res);
  }
};

export const ordersAPI = {
  getActive: async () => {
    const res = await fetch(`${API_URL}/orders/active`, { headers: headers() });
    return handleResponse(res);
  },
  getByTable: async (tableId: string) => {
    const res = await fetch(`${API_URL}/orders/table/${tableId}`, { headers: headers() });
    return handleResponse(res);
  },
  save: async (data: any) => {
    const res = await fetch(`${API_URL}/orders`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },
  sendToKitchen: async (orderId: string) => {
    const res = await fetch(`${API_URL}/orders/${orderId}/send`, {
      method: 'POST',
      headers: headers()
    });
    return handleResponse(res);
  },
  cancelItem: async (itemId: string, reason: string) => {
    const res = await fetch(`${API_URL}/orders/items/${itemId}/cancel`, {
      method: 'PATCH',
      headers: headers(),
      body: JSON.stringify({ reason })
    });
    return handleResponse(res);
  },
  cancelItemPartial: async (itemId: string, data: { quantity: number; reason: string; comments?: string; wasteDestination?: 'waste' | 'restock'; adminAuthToken?: string }) => {
    const res = await fetch(`${API_URL}/orders/items/${itemId}/cancel-partial`, {
      method: 'PATCH',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },
  close: async (orderId: string, status = 'COMPLETED') => {
    const res = await fetch(`${API_URL}/orders/${orderId}/close`, {
      method: 'PATCH',
      headers: headers(),
      body: JSON.stringify({ status })
    });
    return handleResponse(res);
  }
};

export const cashSessionAPI = {
  getOpen: async () => {
    const res = await fetch(`${API_URL}/cash-sessions/open`, { headers: headers() });
    return handleResponse(res);
  },
  
  open: async (data: { initialBalance: number; notes?: string }) => {
    const res = await fetch(`${API_URL}/cash-sessions`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },
  
  close: async (id: string, data: { countedBalance: number; notes?: string }) => {
    const res = await fetch(`${API_URL}/cash-sessions/${id}/close`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },
  
  addIncome: async (id: string, amount: number, motive: string, description?: string) => {
    const res = await fetch(`${API_URL}/cash-sessions/${id}/income`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify({ amount, motive, description })
    });
    return handleResponse(res);
  },
  
  addExpense: async (id: string, amount: number, motive: string, description?: string, categoryId?: string) => {
    const res = await fetch(`${API_URL}/cash-sessions/${id}/expense`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify({ amount, motive, description, categoryId })
    });
    return handleResponse(res);
  },
  
  cancelIncome: async (sessionId: string, incomeId: string, reason: string) => {
    const res = await fetch(`${API_URL}/cash-sessions/${sessionId}/income/cancel`, {
      method: 'PUT',
      headers: headers(),
      body: JSON.stringify({ incomeId, reason })
    });
    return handleResponse(res);
  },
  
  cancelExpense: async (sessionId: string, expenseId: string, reason: string) => {
    const res = await fetch(`${API_URL}/cash-sessions/${sessionId}/expense/cancel`, {
      method: 'PUT',
      headers: headers(),
      body: JSON.stringify({ expenseId, reason })
    });
    return handleResponse(res);
  }
};

export const customersAPI = {
  getAll: async () => {
    const res = await fetch(`${API_URL}/customers`, { headers: headers() });
    return handleResponse(res);
  },
  search: async (q: string) => {
    const res = await fetch(`${API_URL}/customers/search?q=${encodeURIComponent(q)}`, { headers: headers() });
    return handleResponse(res);
  },
  getDefault: async () => {
    const res = await fetch(`${API_URL}/customers/default`, { headers: headers() });
    return handleResponse(res);
  },
  getBirthdays: async () => {
    const res = await fetch(`${API_URL}/customers/birthdays`, { headers: headers() });
    return handleResponse(res);
  },
  getById: async (id: string) => {
    const res = await fetch(`${API_URL}/customers/${id}`, { headers: headers() });
    return handleResponse(res);
  },
  getRecommended: async (id: string) => {
    const res = await fetch(`${API_URL}/customers/${id}/recommended`, { headers: headers() });
    return handleResponse(res);
  },
  create: async (data: any) => {
    const res = await fetch(`${API_URL}/customers`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },
  update: async (id: string, data: any) => {
    const res = await fetch(`${API_URL}/customers/${id}`, {
      method: 'PUT',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },
  delete: async (id: string) => {
    const res = await fetch(`${API_URL}/customers/${id}`, {
      method: 'DELETE',
      headers: headers()
    });
    return handleResponse(res);
  },
  adjustStamps: async (id: string, delta: number, reason?: string) => {
    const res = await fetch(`${API_URL}/customers/${id}/stamps`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify({ delta, reason })
    });
    return handleResponse(res);
  }
};

// Tarjeta de sellos del cliente (en vivo hacia su tarjeta digital; sin internet queda en cola)
export interface LoyaltyStatus {
  stampsCount: number;
  lifetimeStamps: number;
  stampsRequired: number;
  rewardText: string;
  enabled: boolean;
  hasCard: boolean;
  /** Equipo conectado a Lantify Cloud (sin eso no hay tarjeta digital) */
  linked: boolean;
  hasPhone: boolean;
  /** Movimientos que aún no llegan a la nube (sin internet) */
  queued: number;
  /** Sellos guardados que recibirá al registrarse en la página con su celular */
  waitingSignup: number;
  lastEvent: { id: string; stamps: number; status: StampEventStatus; createdAt: string; syncedAt: string | null } | null;
}
export type StampEventStatus = 'QUEUED' | 'APPLIED' | 'WAITING_SIGNUP';

export const loyaltyAPI = {
  status: async (customerId: string): Promise<LoyaltyStatus> =>
    handleResponse(await fetch(`${API_URL}/loyalty/customers/${customerId}`, { headers: headers() })),
  adjust: async (customerId: string, delta: number, reason?: string): Promise<Customer & { stampEventId: string }> =>
    handleResponse(await fetch(`${API_URL}/loyalty/customers/${customerId}/stamps`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify({ delta, reason }),
    })),
  event: async (id: string): Promise<{ id: string; status: StampEventStatus; stamps: number; syncedAt: string | null }> =>
    handleResponse(await fetch(`${API_URL}/loyalty/events/${id}`, { headers: headers() })),
  /** QR (o código "Socio XXXXXXXX") de la tarjeta de sellos del cliente → su ficha en Clientes */
  memberCard: async (code: string): Promise<Customer> =>
    handleResponse(await fetch(`${API_URL}/loyalty/member-card`, { method: 'POST', headers: headers(), body: JSON.stringify({ code }) })),
  cardLink: async (customerId: string): Promise<{ url: string; expiresAt: string; phone: string | null }> =>
    handleResponse(await fetch(`${API_URL}/loyalty/customers/${customerId}/card-link`, { method: 'POST', headers: headers() })),
};

export const expenseCategoriesAPI = {
  getAll: async () => {
    const res = await fetch(`${API_URL}/expense-categories`, { headers: headers() });
    return handleResponse(res);
  },
  create: async (data: any) => {
    const res = await fetch(`${API_URL}/expense-categories`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },
  update: async (id: string, data: any) => {
    const res = await fetch(`${API_URL}/expense-categories/${id}`, {
      method: 'PUT',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },
  delete: async (id: string) => {
    const res = await fetch(`${API_URL}/expense-categories/${id}`, {
      method: 'DELETE',
      headers: headers()
    });
    return handleResponse(res);
  }
};

export const analyticsAPI = {
  /** Tablero del negocio: período [from, to] (AAAA-MM-DD) contra el anterior de igual duración */
  getOverview: async (from: string, to: string) =>
    handleResponse(await fetch(`${API_URL}/analytics/overview?${new URLSearchParams({ from, to })}`, { headers: headers() })),
  /** Ingresos de los 12 meses de un año y del anterior */
  getMonthlyRevenue: async (year: number) =>
    handleResponse(await fetch(`${API_URL}/analytics/monthly-revenue?year=${year}`, { headers: headers() })),
  /** Ventas por canal (salón, página, Rappi, WhatsApp) */
  getChannelStats: async () => handleResponse(await fetch(`${API_URL}/analytics/channels`, { headers: headers() })),
  compareMonths: async (monthKeys: string[]) => {
    const params = new URLSearchParams({ months: monthKeys.join(',') });
    const res = await fetch(`${API_URL}/analytics/compare-months?${params}`, { headers: headers() });
    return handleResponse(res);
  },
  getTopProducts: async (year?: number, month?: number, limit: number = 50) => {
    const params = new URLSearchParams();
    if (year) params.append('year', String(year));
    if (month) params.append('month', String(month));
    if (limit) params.append('limit', String(limit));
    const res = await fetch(`${API_URL}/analytics/top-products?${params}`, { headers: headers() });
    return handleResponse(res);
  }
};

export const inventoryAPI = {
  getStatus: async (onlyTracked: boolean = true) => {
    const res = await fetch(`${API_URL}/inventory?onlyTracked=${onlyTracked}`, { headers: headers() });
    return handleResponse(res);
  },
  toggleTrack: async (variantId: string, enabled: boolean) => {
    const res = await fetch(`${API_URL}/inventory/${variantId}/toggle`, {
      method: 'PUT',
      headers: headers(),
      body: JSON.stringify({ enabled })
    });
    return handleResponse(res);
  },
  adjustStock: async (variantId: string, quantity: number, type: 'MANUAL_ADD' | 'MANUAL_REMOVE', notes?: string) => {
    const res = await fetch(`${API_URL}/inventory/${variantId}/adjust`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify({ quantity, type, notes })
    });
    return handleResponse(res);
  },
  submitCount: async (variantId: string, countedStock: number, justification?: string, userId?: string) => {
    const res = await fetch(`${API_URL}/inventory/${variantId}/count`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify({ countedStock, justification, userId })
    });
    return handleResponse(res);
  },
  getMovements: async (variantId: string) => {
    const res = await fetch(`${API_URL}/inventory/${variantId}/movements`, { headers: headers() });
    return handleResponse(res);
  },
  getCounts: async (variantId: string) => {
    const res = await fetch(`${API_URL}/inventory/${variantId}/counts`, { headers: headers() });
    return handleResponse(res);
  }
};

export const versionAPI = {
  get: async () => {
    const res = await fetch(`${API_URL}/version`, { headers: headers() });
    return handleResponse(res);
  },
  checkUpdate: async () => {
    const res = await fetch(`${API_URL}/version/check`, { headers: headers() });
    return handleResponse(res);
  },
  applyUpdate: async () => {
    const res = await fetch(`${API_URL}/version/apply-update`, {
      method: 'POST',
      headers: headers()
    });
    return handleResponse(res);
  }
};

export interface ReferralInfo {
  code: string;
  link: string;
  rewardMonths: number;
  monthsEarned: number;
  invited: { name: string; status: 'PENDING' | 'REWARDED'; createdAt: string; rewardedAt: string | null }[];
}

/** Recomendar Lantify: el código del negocio y a quién ha invitado */
export const referralAPI = {
  get: async (): Promise<ReferralInfo> => {
    const res = await fetch(`${API_URL}/cloud/referrals`, { headers: headers() });
    return handleResponse(res);
  },
};

export interface VariantGroup {
  key: string; base: string; categoryId: string | null; categoryName: string;
  items: { productId: string; name: string; label: string; isBase: boolean; price: number; variants: number; imageUrl: string | null }[];
}

export interface AiImagesQuota { dayUsed: number; dayLimit: number; monthUsed: number; monthLimit: number; left: number }
export interface AiImageProduct { key: string; category: string; name: string; description: string | null; image: string | null }
export interface AiImagesStatus {
  items?: number; withoutPhoto: number; covered: number; missing: number; available?: boolean;
  quota?: AiImagesQuota;
  products?: AiImageProduct[];
}
export interface AiImagesFill { generated: number; failed: number; remaining: number; covered: number; withoutPhoto: number; quota?: AiImagesQuota }

const postJson = (path: string, body: unknown) =>
  fetch(`${API_URL}${path}`, { method: 'POST', headers: { ...headers(), 'Content-Type': 'application/json' }, body: JSON.stringify(body) });

/** Fotos con IA para los productos sin foto (solo se ven en la página pública) */
export const pageAiImagesAPI = {
  status: async (): Promise<AiImagesStatus> => {
    const res = await fetch(`${API_URL}/page/ai-images`, { headers: headers() });
    return handleResponse(res);
  },
  fill: async (style?: string): Promise<AiImagesFill> => handleResponse(await postJson('/page/ai-images/fill', { style })),
  /** Propone hasta 3 fotos de un producto, siguiendo lo que el negocio cuenta de él */
  options: async (key: string, hint: string, style: string): Promise<{ options: { id: string; url: string }[]; quota: AiImagesQuota }> =>
    handleResponse(await postJson('/page/ai-images/options', { key, hint, style })),
  choose: async (key: string, id: string): Promise<{ image: string }> => handleResponse(await postJson('/page/ai-images/choose', { key, id })),
  remove: async (key: string): Promise<{ removed: boolean }> => handleResponse(await postJson('/page/ai-images/remove', { key })),
  clear: async (): Promise<{ cleared: boolean }> => {
    const res = await fetch(`${API_URL}/page/ai-images/clear`, { method: 'POST', headers: headers() });
    return handleResponse(res);
  },
};

export type BusinessType = 'RESTAURANT' | 'CAFE' | 'BAR' | 'FAST_FOOD' | 'FOOD_TRUCK' | 'RETAIL' | 'SERVICES';
export type TaxType = 'IVA' | 'INC' | 'NONE';
export type TaxRegime = 'NO_RESPONSABLE' | 'RESPONSABLE_INC' | 'RESPONSABLE_IVA';

export interface BusinessSettings {
  businessType: BusinessType;
  businessName: string;
  legalName: string | null;
  nit: string | null;
  dv: string | null;
  taxRegime: TaxRegime;
  address: string | null;
  city: string | null;
  phone: string | null;
  email: string | null;
  ticketFooter: string | null;
  /** Logo del negocio (/api/media/…): tickets, informes y la página */
  logoUrl?: string | null;
  /** QR de pago (Nequi, Bre-B…): pantalla del cliente y kiosco (Fase 4) */
  paymentQrUrl?: string | null;
  paymentQrLabel?: string | null;
  /** Aforo máximo del local para la pantalla Puerta (Fase 4) */
  maxCapacity?: number | null;
  usesTables: boolean;
  deliveryEnabled: boolean;
  /** Canales de venta del plan Premium (se encienden en Configuración) */
  whatsappEnabled?: boolean;
  rappiEnabled?: boolean;
  inventoryEnabled: boolean;
  tipEnabled: boolean;
  tipPercent: number;
  defaultTaxType: TaxType;
  defaultTaxRate: number;
  wantsElectronicInvoice: boolean;
  onboardingCompletedAt: string | null;
  onboardingDismissedAt?: string | null;
}

export interface OnboardingPayload {
  settings: Partial<Omit<BusinessSettings, 'onboardingCompletedAt'>> & { businessType: BusinessType; businessName: string };
  zones?: { name: string; tables: number }[];
  staff?: { name: string; username: string; password: string; role: 'CASHIER' | 'WAITER' }[];
  loadSampleMenu?: boolean;
  /** Carta leída con IA de una foto (reemplaza al menú de ejemplo) */
  menu?: MenuCategory[];
  language?: 'es' | 'en';
}

export interface MenuCategory {
  name: string;
  items: { name: string; price: number }[];
}

export interface SetupSuggestion {
  businessType: BusinessType;
  businessName: string | null;
  city: string | null;
  usesTables: boolean;
  zones: { name: string; tables: number }[];
  tipEnabled: boolean;
  tipPercent: number;
  taxRegime: TaxRegime;
  inventoryEnabled: boolean;
  deliveryEnabled: boolean;
  summary: string;
}

/** Asistente de configuración inicial (ADMIN): descripción → configuración; foto → carta */
export const setupAIAPI = {
  suggest: async (description: string, lang: string): Promise<SetupSuggestion> => {
    const res = await fetch(`${API_URL}/ai/setup`, { method: 'POST', headers: headers(), body: JSON.stringify({ description, lang }) });
    return handleResponse(res);
  },
  readMenu: async (image: string, mimeType: string, lang: string): Promise<{ categories: MenuCategory[] }> => {
    const res = await fetch(`${API_URL}/ai/menu`, { method: 'POST', headers: headers(), body: JSON.stringify({ image, mimeType, lang }) });
    return handleResponse(res);
  },
};

export const mediaAPI = {
  /** Sube una imagen ya recortada y reducida (data URL) y devuelve su dirección */
  upload: async (image: string): Promise<{ url: string; bytes: number }> => {
    const res = await fetch(`${API_URL}/media`, { method: 'POST', headers: headers(), body: JSON.stringify({ image }) });
    return handleResponse(res);
  },
};

export interface InstalledPrinter {
  name: string;
  isDefault: boolean;
  port: string | null;
  driver: string | null;
  offline: boolean;
  virtual: boolean;
}

export interface DevicesInfo {
  lanEnabled: boolean;
  hostname: string;
  urls: string[];
}

// Funciones de cajeros y meseros, y dirección para conectar tablets
export interface SetupGuideData {
  state: import('../../../src/domain/setupGuide').SetupGuideState;
  checks: Record<string, boolean>;
  usesTables?: boolean;
}

export const setupGuideAPI = {
  get: async (): Promise<SetupGuideData> => {
    const res = await fetch(`${API_URL}/setup-guide`, { headers: headers() });
    return handleResponse(res);
  },
  save: async (state: import('../../../src/domain/setupGuide').SetupGuideState): Promise<SetupGuideData> => {
    const res = await fetch(`${API_URL}/setup-guide`, { method: 'PUT', headers: headers(), body: JSON.stringify(state) });
    return handleResponse(res);
  },
};

export type NotificationKind = 'ONLINE_ORDER' | 'RESERVATION' | 'NEW_CUSTOMER' | 'PRIZE' | 'CARD_COMPLETE' | 'TABLE_ORDER';
export interface PosNotification { id: number; at: string; kind: NotificationKind; data: Record<string, string | number | null> }
export interface NotificationsFeed {
  cursor: number;
  items: PosNotification[];
  birthdays?: { id: string; name: string; phone: string | null }[];
}

export const notificationsAPI = {
  since: async (since: number | null, birthdays = false): Promise<NotificationsFeed> => {
    const q = new URLSearchParams();
    if (since != null) q.set('since', String(since));
    if (birthdays) q.set('birthdays', '1');
    const res = await fetch(`${API_URL}/notifications?${q}`, { headers: headers() });
    return handleResponse(res);
  },
};

export const permissionsAPI = {
  get: async (): Promise<RolePermissions> => {
    const res = await fetch(`${API_URL}/permissions`, { headers: headers() });
    return handleResponse(res);
  },
  save: async (perms: RolePermissions): Promise<RolePermissions> => {
    const res = await fetch(`${API_URL}/permissions`, { method: 'PUT', headers: headers(), body: JSON.stringify(perms) });
    return handleResponse(res);
  },
  devices: async (): Promise<DevicesInfo> => {
    const res = await fetch(`${API_URL}/permissions/devices`, { headers: headers() });
    return handleResponse(res);
  },
};

/** Enlace privado a la imagen de una cuenta (Lantify Cloud), para mandarlo por WhatsApp */
export const ticketsAPI = {
  share: async (data: string): Promise<{ id: string; url: string; image: string; expiresAt: string }> =>
    handleResponse(await fetch(`${API_URL}/tickets/share`, { method: 'POST', headers: headers(), body: JSON.stringify({ data }) })),
};

export const printingAPI = {
  getSettings: async (): Promise<PrintSettings> => {
    const res = await fetch(`${API_URL}/printing/settings`, { headers: headers() });
    return handleResponse(res);
  },
  saveSettings: async (settings: PrintSettings): Promise<PrintSettings> => {
    const res = await fetch(`${API_URL}/printing/settings`, { method: 'PUT', headers: headers(), body: JSON.stringify(settings) });
    return handleResponse(res);
  },
  printers: async (): Promise<{ supported: boolean; printers: InstalledPrinter[] }> => {
    const res = await fetch(`${API_URL}/printing/printers`, { headers: headers() });
    return handleResponse(res);
  },
  print: async (role: 'receipt' | 'kitchen', doc: TicketDoc, copies?: number, station?: string | null): Promise<{ ok: true }> => {
    const res = await fetch(`${API_URL}/printing/print`, { method: 'POST', headers: headers(), body: JSON.stringify({ role, doc, copies, station: station || undefined }) });
    return handleResponse(res);
  },
  test: async (target: PrinterTarget, doc: TicketDoc, settings: Partial<PrintSettings>, drawer = false): Promise<{ ok: true }> => {
    const res = await fetch(`${API_URL}/printing/test`, { method: 'POST', headers: headers(), body: JSON.stringify({ target, doc, settings, drawer }) });
    return handleResponse(res);
  },
};

export const businessAPI = {
  get: async (): Promise<BusinessSettings> => {
    const res = await fetch(`${API_URL}/business`, { headers: headers() });
    return handleResponse(res);
  },

  update: async (data: Partial<Omit<BusinessSettings, 'onboardingCompletedAt'>>): Promise<BusinessSettings> => {
    const res = await fetch(`${API_URL}/business`, {
      method: 'PUT',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },

  dismissOnboarding: async (): Promise<BusinessSettings> => {
    const res = await fetch(`${API_URL}/business/onboarding/dismiss`, { method: 'POST', headers: headers() });
    return handleResponse(res);
  },

  completeOnboarding: async (data: OnboardingPayload): Promise<{ settings: BusinessSettings; tablesCreated: number; staffCreated: number; sampleProducts: number }> => {
    const res = await fetch(`${API_URL}/business/onboarding`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify(data)
    });
    return handleResponse(res);
  },
};

// ── Gastos y lectura de facturas ────────────────────────────

export type PaymentSource = 'CASH_DRAWER' | 'BANK' | 'CARD' | 'NEQUI' | 'OTHER';

export interface ExpenseRecord {
  id: string;
  amount: number;
  motive: string;
  description: string | null;
  categoryId: string | null;
  category: { id: string; name: string; color: string | null } | null;
  paymentSource: PaymentSource;
  cashSessionId: string | null;
  cashSession?: { sessionNumber: string } | null;
  supplierName: string | null;
  supplierNit: string | null;
  invoiceNumber: string | null;
  invoiceDate: string | null;
  subtotal: number | null;
  taxAmount: number | null;
  captureMode: 'MANUAL' | 'AI_REVIEWED' | 'AI_AUTO';
  aiConfidence: number | null;
  createdBy: string | null;
  isCancelled: boolean;
  cancellationReason: string | null;
  createdAt: string;
  hasImage: boolean;
}

export interface ExpenseList {
  total: number;
  count: number;
  tax: number;
  byCategory: { id: string | null; name: string; color: string | null; total: number; count: number }[];
  bySource: { source: PaymentSource; total: number }[];
  expenses: ExpenseRecord[];
}

export interface InvoiceReading {
  isInvoice: boolean;
  supplierName: string | null;
  supplierNit: string | null;
  invoiceNumber: string | null;
  invoiceDate: string | null;
  subtotal: number | null;
  tax: number | null;
  total: number | null;
  paymentMethod: 'CASH' | 'CARD' | 'TRANSFER' | null;
  category: string | null;
  items: { description: string; quantity: number | null; total: number | null }[];
  confidence: number;
}

export type ScanResult =
  | { mode: 'auto'; reading: InvoiceReading; categoryId: string | null; paymentSource: PaymentSource; expense: ExpenseRecord }
  | { mode: 'review'; reading: InvoiceReading; categoryId: string | null; paymentSource: PaymentSource; prepared?: any };

export const expensesAPI = {
  list: async (from?: string, to?: string): Promise<ExpenseList> => {
    const q = new URLSearchParams();
    if (from) q.set('from', from);
    if (to) q.set('to', to);
    const res = await fetch(`${API_URL}/expenses${q.toString() ? `?${q}` : ''}`, { headers: headers() });
    return handleResponse(res);
  },
  create: async (data: Record<string, unknown>): Promise<ExpenseRecord> => {
    const res = await fetch(`${API_URL}/expenses`, { method: 'POST', headers: headers(), body: JSON.stringify(data) });
    return handleResponse(res);
  },
  scan: async (image: string, mimeType: string, lang: string): Promise<ScanResult> => {
    const res = await fetch(`${API_URL}/expenses/scan`, { method: 'POST', headers: headers(), body: JSON.stringify({ image, mimeType, lang }) });
    return handleResponse(res);
  },
  cancel: async (id: string, reason: string) => {
    const res = await fetch(`${API_URL}/expenses/${id}/cancel`, { method: 'PATCH', headers: headers(), body: JSON.stringify({ reason }) });
    return handleResponse(res);
  },
  /** La foto se pide con la sesión (no puede ir en un <img src>): se devuelve como URL local */
  imageUrl: async (id: string) => {
    const res = await fetch(`${API_URL}/expenses/${id}/image`, { headers: headers() });
    if (!res.ok) throw responseError(res.status, await res.json().catch(() => null));
    return URL.createObjectURL(await res.blob());
  },
};

export interface AiSettings {
  consent: boolean;
  consentAt: string | null;
  consentBy: string | null;
  expenseAutoRegister: boolean;
}

export const aiSettingsAPI = {
  get: async (): Promise<AiSettings> => handleResponse(await fetch(`${API_URL}/ai/settings`, { headers: headers() })),
  update: async (data: Partial<Pick<AiSettings, 'consent' | 'expenseAutoRegister'>>): Promise<AiSettings> =>
    handleResponse(await fetch(`${API_URL}/ai/settings`, { method: 'PUT', headers: headers(), body: JSON.stringify(data) })),
};

// ── Proveedores y cupones ───────────────────────────────────

export interface SupplierPrice {
  id: string;
  itemName: string;
  unit: string | null;
  price: number;
  source: 'MANUAL' | 'INVOICE';
  updatedAt: string;
}

export interface Supplier {
  id: string;
  name: string;
  nit: string | null;
  phone: string | null;
  email: string | null;
  contactName: string | null;
  notes: string | null;
  isActive: boolean;
  prices: SupplierPrice[];
}

export const suppliersAPI = {
  list: async (): Promise<Supplier[]> => handleResponse(await fetch(`${API_URL}/suppliers`, { headers: headers() })),
  create: async (data: Partial<Supplier>): Promise<Supplier> =>
    handleResponse(await fetch(`${API_URL}/suppliers`, { method: 'POST', headers: headers(), body: JSON.stringify(data) })),
  update: async (id: string, data: Partial<Supplier>): Promise<Supplier> =>
    handleResponse(await fetch(`${API_URL}/suppliers/${id}`, { method: 'PUT', headers: headers(), body: JSON.stringify(data) })),
  savePrices: async (id: string, prices: { itemName: string; unit?: string | null; price: number }[]): Promise<Supplier> =>
    handleResponse(await fetch(`${API_URL}/suppliers/${id}/prices`, { method: 'PUT', headers: headers(), body: JSON.stringify({ prices }) })),
  deletePrice: async (id: string, priceId: string) =>
    handleResponse(await fetch(`${API_URL}/suppliers/${id}/prices/${priceId}`, { method: 'DELETE', headers: headers() })),
};

export interface Coupon {
  id: string;
  code: string;
  description: string | null;
  type: 'PERCENT' | 'AMOUNT';
  value: number;
  minPurchase: number | null;
  startsAt: string | null;
  endsAt: string | null;
  maxUses: number | null;
  uses: number;
  isActive: boolean;
  source: 'MANUAL' | 'AGENT';
  createdAt: string;
}

export const couponsAPI = {
  list: async (): Promise<Coupon[]> => handleResponse(await fetch(`${API_URL}/coupons`, { headers: headers() })),
  create: async (data: Record<string, unknown>): Promise<Coupon> =>
    handleResponse(await fetch(`${API_URL}/coupons`, { method: 'POST', headers: headers(), body: JSON.stringify(data) })),
  update: async (id: string, data: Record<string, unknown>): Promise<Coupon> =>
    handleResponse(await fetch(`${API_URL}/coupons/${id}`, { method: 'PUT', headers: headers(), body: JSON.stringify(data) })),
  validate: async (code: string, subtotal: number): Promise<{ code: string; type: string; value: number; description: string | null; discount: number }> =>
    handleResponse(await fetch(`${API_URL}/coupons/validate?code=${encodeURIComponent(code)}&subtotal=${Math.round(subtotal)}`, { headers: headers() })),
};

// ── Agentes ─────────────────────────────────────────────────

export type AgentId = 'backoffice' | 'purchasing' | 'marketing';

export interface AgentChart {
  type: 'bar' | 'line';
  title: string;
  unit: 'COP' | 'units' | '%';
  labels: string[];
  series: { name: string; values: number[] }[];
}

export type AgentAction =
  | { type: 'purchase_order'; supplierId: string; supplierName: string; phone: string | null; items: { itemName: string; quantity: number; unit: string | null; price: number | null }[]; note: string | null }
  | { type: 'create_coupon'; code: string; description: string | null; discountType: 'PERCENT' | 'AMOUNT'; value: number; minPurchase: number | null; days: number };

export interface AgentMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  chart: AgentChart | null;
  actions: AgentAction[];
  /** Cifras clave de la respuesta (bloque 3) */
  kpis?: AgentKpi[];
  headline?: string | null;
  flyer?: FlyerCopy | null;
  /** 3 propuestas de flyer (tarea Crear un flyer) */
  flyers?: FlyerCopy[];
  userName: string | null;
  createdAt: string;
}

export interface AgentAskInput {
  question?: string;
  task?: string | null;
  /** Lo que se guarda como pregunta cuando se elige una tarea */
  taskLabel?: string;
  lang: string;
}

export interface AgentProfileData {
  profile: AiProfile;
  businessType: string | null;
  businessName: string | null;
  logoUrl: string | null;
}

import type { AgentKpi, AiProfile, FlyerCopy } from '../../../src/domain/v3/agents';

export const agentsAPI = {
  messages: async (agent: AgentId): Promise<AgentMessage[]> => handleResponse(await fetch(`${API_URL}/agents/${agent}/messages`, { headers: headers() })),
  clear: async (agent: AgentId) => handleResponse(await fetch(`${API_URL}/agents/${agent}/messages`, { method: 'DELETE', headers: headers() })),
  context: async (agent: AgentId): Promise<unknown> => handleResponse(await fetch(`${API_URL}/agents/${agent}/context`, { headers: headers() })),
  ask: async (agent: AgentId, question: string, lang: string): Promise<AgentMessage> =>
    handleResponse(await fetch(`${API_URL}/agents/${agent}/ask`, { method: 'POST', headers: headers(), body: JSON.stringify({ question, lang }) })),
  createCoupon: async (action: Extract<AgentAction, { type: 'create_coupon' }>): Promise<Coupon> =>
    handleResponse(await fetch(`${API_URL}/agents/marketing/coupons`, { method: 'POST', headers: headers(), body: JSON.stringify(action) })),
  /** En vivo: `onDelta` recibe el texto a medida que el agente lo escribe */
  stream: async (agent: AgentId, input: AgentAskInput, onDelta: (text: string) => void, signal?: AbortSignal): Promise<AgentMessage> => {
    const res = await fetch(`${API_URL}/agents/${agent}/stream`, { method: 'POST', headers: headers(), body: JSON.stringify(input), signal });
    if (!res.ok || !res.body || !(res.headers.get('content-type') || '').includes('text/event-stream')) return handleResponse(res);
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      let sep: number;
      while ((sep = buffer.indexOf('\n\n')) >= 0) {
        const block = buffer.slice(0, sep);
        buffer = buffer.slice(sep + 2);
        const event = /^event: (.+)$/m.exec(block)?.[1]?.trim();
        const raw = /^data: (.+)$/m.exec(block)?.[1];
        if (!event || !raw) continue;
        const data = JSON.parse(raw);
        if (event === 'delta') onDelta(String(data.t || ''));
        else if (event === 'done') return data as AgentMessage;
        else if (event === 'error') throw new ApiError(data.code || 'AI_UNAVAILABLE', data.code || 'AI_UNAVAILABLE', 503);
      }
    }
    throw new ApiError('AI_UNAVAILABLE', 'AI_UNAVAILABLE', 503);
  },
  profile: async (): Promise<AgentProfileData> => handleResponse(await fetch(`${API_URL}/agents/profile`, { headers: headers() })),
  saveProfile: async (profile: AiProfile): Promise<{ profile: AiProfile }> =>
    handleResponse(await fetch(`${API_URL}/agents/profile`, { method: 'PUT', headers: headers(), body: JSON.stringify({ profile }) })),
  flyerImage: async (prompt: string, kind: string, portrait: boolean): Promise<{ image: string }> =>
    handleResponse(await fetch(`${API_URL}/agents/flyer-image`, { method: 'POST', headers: headers(), body: JSON.stringify({ prompt, kind, portrait }) })),
};

// ── Propinas ────────────────────────────────────────────────

export interface TipsSummary {
  total: number;
  count: number;
  cash: number;
  salesCount: number;
  avgPercent: number;
  tipRate: number;
}

export interface TipsReportData {
  enabled: boolean;
  tipPercent: number;
  summary: TipsSummary;
  allTime: { total: number; count: number };
  byMonth: (TipsSummary & { month: string })[];
  bySession: (TipsSummary & { id: string; sessionNumber: string; openedAt: string; closedAt: string | null; status: string; byWaiter: { name: string; total: number; count: number }[] })[];
  byWaiter: { name: string; total: number; count: number }[];
  recent: { id: string; saleNumber: string; createdAt: string; tip: number; total: number; paymentMethod: string; cash: boolean; waiterName: string | null; cashierName: string | null; table: string | null }[];
}

export const tipsAPI = {
  report: async (from?: string, to?: string): Promise<TipsReportData> => {
    const q = new URLSearchParams();
    if (from) q.set('from', from);
    if (to) q.set('to', to);
    const res = await fetch(`${API_URL}/tips${q.toString() ? `?${q}` : ''}`, { headers: headers() });
    return handleResponse(res);
  },
  session: async (id: string): Promise<TipsSummary & { byWaiter: { name: string; total: number; count: number }[] }> => {
    const res = await fetch(`${API_URL}/tips/session/${id}`, { headers: headers() });
    return handleResponse(res);
  },
};

/**
 * Exportar ventas y facturas (CSV). Usa un permiso de 15 minutos: el ADMIN lo pide
 * con su sesión, o lo recibe al intentar entrar con la cuenta suspendida.
 */
export const exportAPI = {
  token: async (): Promise<{ exportToken: string }> => {
    const res = await fetch(`${API_URL}/export/token`, { method: 'POST', headers: headers() });
    return handleResponse(res);
  },
  download: async (kind: 'sales' | 'invoices', exportToken: string) => {
    const res = await fetch(`${API_URL}/export/${kind}.csv`, { headers: { Authorization: `Bearer ${exportToken}` } });
    if (!res.ok) throw responseError(res.status, await res.json().catch(() => null));
    const name = /filename="([^"]+)"/.exec(res.headers.get('Content-Disposition') || '')?.[1] || `lantify-${kind}.csv`;
    const url = URL.createObjectURL(await res.blob());
    const link = document.createElement('a');
    link.href = url;
    link.download = name;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  },
};

export const systemAPI = {
  getBackups: async () => {
    const res = await fetch(`${API_URL}/system/backups`, { headers: headers() });
    return handleResponse(res);
  },
  createBackup: async () => {
    const res = await fetch(`${API_URL}/system/backups`, {
      method: 'POST',
      headers: headers(),
    });
    return handleResponse(res);
  },
  cloudBackupStatus: async (): Promise<CloudBackupStatus> => handleResponse(await fetch(`${API_URL}/system/cloud-backup`, { headers: headers() })),
  cloudBackupUpload: async () => handleResponse(await fetch(`${API_URL}/system/cloud-backup`, { method: 'POST', headers: headers() })),
  cloudBackupRestore: async () => handleResponse(await fetch(`${API_URL}/system/cloud-backup/restore`, { method: 'POST', headers: headers() })),
  cloudBackupRestoreFile: async (file: File) =>
    handleResponse(await fetch(`${API_URL}/system/cloud-backup/restore-file`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${getToken() || ''}`, 'Content-Type': 'application/octet-stream' },
      body: file,
    })),
};

export interface CloudBackupInfo {
  sizeBytes: number;
  rawBytes: number | null;
  device: string | null;
  appVersion: string | null;
  counts: Record<string, number> | null;
  createdAt: string;
}
export interface CloudBackupStatus {
  linked: boolean;
  lastUploadAt: string | null;
  lastAttemptAt: string | null;
  lastError: string | null;
  running: boolean;
  canRestore: boolean;
  cloud: CloudBackupInfo | null;
  cloudError?: string;
}

export interface DianStatus {
  active: boolean;
  documentKind: 'invoice' | 'pos';
  resolutionNumber: string | null;
  prefix: string | null;
  rangeFrom: number;
  rangeTo: number;
  validUntil: string | null;
  checkedAt: string | null;
  autoSync: boolean;
}

export const dianAPI = {
  /** ¿Lantify activó la facturación? Con `refresh` pregunta a la nube en el momento */
  getStatus: async (refresh = false): Promise<{ status: DianStatus }> => {
    const res = await fetch(`${API_URL}/dian/status${refresh ? '?refresh=1' : ''}`, { headers: headers() });
    return handleResponse(res);
  },
  getStats: async () => {
    const res = await fetch(`${API_URL}/dian/stats`, { headers: headers() });
    return handleResponse(res);
  },
  getQueue: async (status?: string) => {
    const query = status ? `?status=${status}` : '';
    const res = await fetch(`${API_URL}/dian/queue${query}`, { headers: headers() });
    return handleResponse(res);
  },
  processQueue: async () => {
    const res = await fetch(`${API_URL}/dian/queue/process`, {
      method: 'POST',
      headers: headers()
    });
    return handleResponse(res);
  },
  retryInvoice: async (id: string) => {
    const res = await fetch(`${API_URL}/dian/queue/${id}/retry`, {
      method: 'POST',
      headers: headers()
    });
    return handleResponse(res);
  },
  emitInvoice: async (saleId: string, customer?: any) => {
    const res = await fetch(`${API_URL}/dian/emit`, {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify({ saleId, customer })
    });
    return handleResponse(res);
  },
  getResolution: async (): Promise<{ resolution: { resolutionNumber: string; resolutionDate: string; prefix: string; rangeFrom: number; rangeTo: number; operationMode: string } | null }> => {
    const res = await fetch(`${API_URL}/dian/resolution`, { headers: headers() });
    return handleResponse(res);
  },
  getSaleInvoice: async (saleId: string) => {
    const res = await fetch(`${API_URL}/dian/sale/${saleId}`, { headers: headers() });
    return handleResponse(res);
  },
  getXmlUrl: (invoiceId: string) => `${API_URL}/dian/invoice/${invoiceId}/xml`
};



// ============================================
// RESERVAS
// ============================================

export type ReservationStatus = 'PENDING' | 'CONFIRMED' | 'SEATED' | 'CANCELLED' | 'NO_SHOW';
export type ReservationChannel = 'POS' | 'WHATSAPP' | 'PHONE' | 'WALK_IN' | 'ONLINE';

export interface Reservation {
  id: string;
  code: string;
  tableId: string | null;
  table: { id: string; number: string; zone: string | null; capacity: number } | null;
  customerId: string | null;
  customer: { id: string; name: string; phone: string | null } | null;
  customerName: string;
  customerPhone: string | null;
  customerEmail: string | null;
  partySize: number;
  startsAt: string;
  endsAt: string;
  date: string;
  time: string;
  endTime: string;
  status: ReservationStatus;
  channel: ReservationChannel;
  notes: string | null;
  cancelReason: string | null;
  createdBy: string | null;
  cloudConflict: boolean;
  marketingOptIn: boolean;
}

export interface BookingScheduleBlock {
  day: number;
  from: string;
  to: string;
}

export interface BookingSettings {
  enabled: boolean;
  online: boolean;
  slotMinutes: number;
  durationMinutes: number;
  minAdvanceMinutes: number;
  maxDaysAhead: number;
  maxPartySize: number;
  requireConfirmation: boolean;
  cancelUntilMinutes: number;
  schedule: BookingScheduleBlock[];
  utcOffsetMinutes: number;
  whatsapp: string | null;
  message: string | null;
}

export interface BookingConfig {
  settings: BookingSettings;
  slug: string | null;
  publishedAt: string | null;
  syncAt: string | null;
  tables: { id: string; number: string; zone: string | null; capacity: number; reservable: boolean }[];
  /** Resultado de publicar en Lantify Cloud al guardar (si hay reservas en línea) */
  publish?: { ok: boolean; code?: string; url?: string; slug?: string };
}

export const reservationsAPI = {
  list: async (date: string): Promise<Reservation[]> => {
    const res = await fetch(`${API_URL}/reservations?date=${date}`, { headers: headers() });
    return handleResponse(res);
  },
  summary: async (): Promise<{ pending: number; conflicts: number; upcoming: number; latest: string }> => {
    const res = await fetch(`${API_URL}/reservations/summary`, { headers: headers() });
    return handleResponse(res);
  },
  availability: async (date: string, party: number): Promise<{ time: string; minutes: number; available: boolean }[]> => {
    const res = await fetch(`${API_URL}/reservations/availability?date=${date}&party=${party}`, { headers: headers() });
    return handleResponse(res);
  },
  create: async (data: Record<string, unknown>): Promise<Reservation> => {
    const res = await fetch(`${API_URL}/reservations`, { method: 'POST', headers: headers(), body: JSON.stringify(data) });
    return handleResponse(res);
  },
  update: async (id: string, data: Record<string, unknown>): Promise<Reservation> => {
    const res = await fetch(`${API_URL}/reservations/${id}`, { method: 'PATCH', headers: headers(), body: JSON.stringify(data) });
    return handleResponse(res);
  },
  settings: async (): Promise<BookingConfig> => {
    const res = await fetch(`${API_URL}/reservations/settings`, { headers: headers() });
    return handleResponse(res);
  },
  saveSettings: async (data: { settings: BookingSettings; reservableTableIds: string[]; slug?: string }): Promise<BookingConfig> => {
    const res = await fetch(`${API_URL}/reservations/settings`, { method: 'PUT', headers: headers(), body: JSON.stringify(data) });
    return handleResponse(res);
  },
};

// ============================================
// MI PÁGINA (página pública del negocio)
// ============================================

export interface PagePrize {
  id: string;
  label: string;
  kind: 'PERCENT' | 'AMOUNT';
  value: number;
  minPurchase: number | null;
  weight: number;
  dailyLimit: number | null;
  totalLimit: number | null;
  validDays: number;
}

export type OrderPayment = 'CASH' | 'NEQUI' | 'DAVIPLATA' | 'CARD' | 'TRANSFER';

export interface PageOrdering {
  delivery: boolean;
  pickup: boolean;
  deliveryFee: number;
  minOrder: number;
  payments: OrderPayment[];
  eta: string | null;
  notice: string | null;
}

export interface LoyaltyConfig {
  enabled: boolean;
  minSpendPerStamp: number;
  spendPerGamePlay: number;
  stampsRequired: number;
  rewardText: string;
  /** 'page' = v1 (tarjeta en la página); 'wallet' = v2 (Google Wallet en Android, pantalla de inicio en iPhone) */
  cardMode?: 'page' | 'wallet';
  /** Aviso al pasar cerca del local (tarjeta en Google Wallet) */
  nearby?: { enabled: boolean; message: string | null; locations: { lat: number; lng: number }[] };
}

export interface SocialConfig {
  googleReviewUrl: string | null;
  instagram: string | null;
  tiktok: string | null;
  facebook: string | null;
  whatsapp: string | null;
}

export interface PageCatalogProduct {
  id: string;
  name: string;
  categoryName: string;
  price: number;
  visible: boolean;
  imageUrl: string | null;
  variants?: { id: string; name: string; price: number }[];
}

export interface PageConfigData {
  sections: { menu: boolean; booking: boolean; signup: boolean; games: boolean; orders: boolean };
  profile: { tagline: string | null; address: string | null; city: string | null; hours: string | null; whatsapp: string | null; instagram: string | null };
  games: {
    type: 'wheel' | 'scratch' | 'trivia'; title: string; noPrizeWeight: number; tryAgainSlots: number;
    prizes: PagePrize[]; trivia: { q: string; options: string[]; answer: number }[];
  };
  legal: { owner: string | null; nit: string | null; email: string | null; address?: string | null; phone?: string | null; extra?: string | null };
  ordering: PageOrdering;
  theme: PageTheme;
  loyalty: LoyaltyConfig;
  social: SocialConfig;
  hiddenProductIds: string[];
  /** Favoritos de la casa: los más vendidos (auto) o los que elige el negocio */
  featured: { mode: 'auto' | 'manual'; productIds: string[] };
}

export type { PageTheme };

export interface DesignSuggestion {
  theme: PageTheme;
  tagline: string | null;
  why: string;
}

export interface PageState extends PageConfigData {
  slug: string | null;
  suggestedSlug: string;
  url: string | null;
  publishedAt: string | null;
  syncAt: string | null;
  linked: boolean;
  menuSummary: { categories: number; items: number };
  catalog?: PageCatalogProduct[];
  /** Productos más vendidos (ids), los que salen como favoritos en automático */
  bestSellers?: string[];
  business: { name: string; type: string; city: string | null };
  menuNames: { categories: string[]; items: string[] };
  stats: { members: number; marketing: number; prizesAwarded: number; prizesRedeemed: number };
  activity: {
    members: { id: string; name: string; phone: string | null; createdAt: string; marketingOptIn: boolean }[];
    prizes: { code: string; description: string | null; redeemed: boolean; endsAt: string | null; createdAt: string; customer: string | null }[];
  };
  publish?: { ok: boolean; code?: string; slug?: string };
}

export interface BirthdayRow {
  id: string;
  name: string;
  phone: string | null;
  marketingOptIn: boolean;
  inDays: number;
  day: number;
  month: number;
  favorite: string | null;
}

// ============================================
// PEDIDOS EN LÍNEA (desde la página del negocio)
// ============================================

export type OnlineOrderStatus = 'PENDING' | 'ACCEPTED' | 'READY' | 'COMPLETED' | 'REJECTED' | 'CANCELLED';

export interface OnlineOrder {
  id: string;
  code: string;
  kind: 'DELIVERY' | 'PICKUP';
  /** WEB = página del negocio; KIOSK = kiosco del local (Fase 4) */
  channel?: 'WEB' | 'KIOSK';
  status: OnlineOrderStatus;
  statusNote: string | null;
  customerId: string | null;
  customerName: string;
  customerPhone: string | null;
  address: string | null;
  notes: string | null;
  paymentMethod: OrderPayment;
  items: { id: string; name: string; price: number; qty: number; note: string | null }[];
  subtotal: number;
  deliveryFee: number;
  total: number;
  saleId: string | null;
  placedAt: string;
  acceptedBy: string | null;
}

export const onlineOrdersAPI = {
  list: async (date?: string): Promise<OnlineOrder[]> => {
    const res = await fetch(`${API_URL}/online-orders${date ? `?date=${date}` : ''}`, { headers: headers() });
    return handleResponse(res);
  },
  summary: async (): Promise<{ pending: number; open: number; latest: string; latestOrder: { id: string; code: string; customerName: string; total: number; kind: string } | null }> => {
    const res = await fetch(`${API_URL}/online-orders/summary`, { headers: headers() });
    return handleResponse(res);
  },
  act: async (id: string, action: 'accept' | 'reject' | 'ready' | 'complete', body: Record<string, unknown> = {}): Promise<OnlineOrder> => {
    const res = await fetch(`${API_URL}/online-orders/${id}/${action}`, { method: 'POST', headers: headers(), body: JSON.stringify(body) });
    return handleResponse(res);
  },
};

export const pageAPI = {
  get: async (): Promise<PageState> => {
    const res = await fetch(`${API_URL}/page`, { headers: headers() });
    return handleResponse(res);
  },
  save: async (data: PageConfigData & { slug: string }): Promise<PageState> => {
    const res = await fetch(`${API_URL}/page`, { method: 'PUT', headers: headers(), body: JSON.stringify(data) });
    return handleResponse(res);
  },
  publish: async (): Promise<PageState> => {
    const res = await fetch(`${API_URL}/page/publish`, { method: 'POST', headers: headers() });
    return handleResponse(res);
  },
  /** Diseño recomendado por la IA (solo nombres del negocio y de la carta) */
  designAI: async (data: Record<string, unknown>): Promise<DesignSuggestion> => {
    const res = await fetch(`${API_URL}/ai/design`, { method: 'POST', headers: headers(), body: JSON.stringify(data) });
    return handleResponse(res);
  },
  birthdays: async (): Promise<BirthdayRow[]> => {
    const res = await fetch(`${API_URL}/page/birthdays?days=7`, { headers: headers() });
    return handleResponse(res);
  },
};

/** Avisos en vivo: conexión abierta con el servidor del negocio (ver shared/live.ts) */
export const liveAPI = {
  open: (signal: AbortSignal) => fetch(`${API_URL}/events`, { headers: headers(), signal, cache: 'no-store' }),
};
