// ============================================
// SERVICES - Informes: un mismo documento en PDF o en Excel (.xlsx)
// ============================================
// Cada informe se arma una sola vez (ReportDoc) y sale en dos formatos:
//  · PDF: hoja carta con logo y datos del negocio, indicadores y tablas con total.
//    Se abre el diálogo de impresión, donde se elige la impresora o "Guardar como PDF".
//  · Excel: hoja "Resumen" con los indicadores y una hoja por tabla, con números de
//    verdad (moneda y porcentaje con formato), totales y filtros, listo para analizar.

import * as XLSX from 'xlsx';
import { useBusinessStore } from '../shared/business';
import { mediaSrc } from '../shared/media';
import { formatCurrency } from '../shared/formatUtils';
import { getLocale, t } from '../i18n';

/** Celda: texto, o número con su formato (así Excel recibe números y el PDF los muestra legibles) */
export type ReportCell = string | number | null | { v: number; f: 'money' | 'pct' | 'int' };

export const money = (v: unknown): ReportCell => ({ v: Math.round((Number(v) || 0) * 100) / 100, f: 'money' });
export const int = (v: unknown): ReportCell => ({ v: Number(v) || 0, f: 'int' });
export const pct = (part: number, whole: number): ReportCell => (whole > 0 ? { v: part / whole, f: 'pct' } : '—');
/** Moneda dentro de un texto (notas e indicaciones) */
export const moneyText = (v: unknown) => formatCurrency(Number(v) || 0);

export interface ReportKpi {
  label: string;
  value: ReportCell;
  /** Qué significa la cifra o de dónde sale */
  hint?: string;
  tone?: 'good' | 'bad' | 'neutral';
}

export interface ReportColumn {
  label: string;
  align?: 'left' | 'right' | 'center';
  /** Ancho relativo en el PDF */
  width?: number;
}

export interface ReportTable {
  title: string;
  /** Nombre corto de la hoja de Excel */
  sheet?: string;
  note?: string;
  columns: ReportColumn[];
  rows: ReportCell[][];
  totals?: ReportCell[];
  /** Texto cuando no hay filas */
  empty?: string;
  /** Solo en un formato (p. ej. el detalle completo, demasiado ancho para el PDF) */
  only?: 'pdf' | 'xlsx';
}

export interface ReportDoc {
  title: string;
  period: string;
  /** Filtros aplicados (arqueo, estado, categoría…) */
  scope?: string;
  kpis: ReportKpi[];
  tables: ReportTable[];
  notes?: string[];
}

export type ReportFormat = 'pdf' | 'xlsx';

const esc = (v: unknown) =>
  String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

export const cellText = (c: ReportCell): string => {
  if (c === null || c === undefined) return '';
  if (typeof c === 'object') {
    if (c.f === 'money') return formatCurrency(c.v);
    if (c.f === 'pct') return `${(c.v * 100).toLocaleString(getLocale(), { maximumFractionDigits: 1 })} %`;
    return c.v.toLocaleString(getLocale());
  }
  return typeof c === 'number' ? c.toLocaleString(getLocale()) : c;
};

const isNegative = (c: ReportCell) => typeof c === 'object' && c !== null && c.f === 'money' && c.v < 0;

// ── PDF ──────────────────────────────────────────────────────

const htmlTable = (tb: ReportTable) => {
  const widthSum = tb.columns.reduce((n, x) => n + (x.width || 1), 0);
  const align = (i: number) => tb.columns[i]?.align || 'left';
  const cells = (row: ReportCell[], tag: 'td' | 'th') =>
    row.map((v, i) => `<${tag} class="${align(i)}${isNegative(v) ? ' neg' : ''}">${esc(tag === 'th' ? v : cellText(v))}</${tag}>`).join('');
  return `
  <section class="block">
    <h2>${esc(tb.title)}</h2>
    ${tb.note ? `<p class="note">${esc(tb.note)}</p>` : ''}
    <table>
      <colgroup>${tb.columns.map((c) => `<col style="width:${(((c.width || 1) / widthSum) * 100).toFixed(2)}%">`).join('')}</colgroup>
      <thead><tr>${cells(tb.columns.map((c) => c.label), 'th')}</tr></thead>
      <tbody>${tb.rows.length ? tb.rows.map((r) => `<tr>${cells(r, 'td')}</tr>`).join('') : `<tr><td class="empty" colspan="${tb.columns.length}">${esc(tb.empty || t('reports:sin_datos'))}</td></tr>`}</tbody>
      ${tb.totals && tb.rows.length ? `<tfoot><tr>${cells(tb.totals, 'td')}</tr></tfoot>` : ''}
    </table>
  </section>`;
};

export const renderReport = (doc: ReportDoc) => {
  const b = useBusinessStore.getState().settings;
  const logo = mediaSrc(b?.logoUrl);
  const address = [b?.address, b?.city].filter(Boolean).join(', ');
  const generated = new Date().toLocaleString(getLocale(), { dateStyle: 'long', timeStyle: 'short' });
  return `<!DOCTYPE html>
<html lang="${getLocale().slice(0, 2)}"><head><meta charset="utf-8" />
<title>${esc(doc.title)} · ${esc(doc.period)}</title>
<style>
  @page { size: letter; margin: 14mm 12mm 16mm; }
  * { box-sizing: border-box; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  body { margin: 0; font-family: 'Segoe UI', Roboto, Arial, sans-serif; font-size: 10pt; color: #0f172a; background: #fff; }
  header { display: flex; align-items: center; gap: 14px; padding-bottom: 10px; border-bottom: 2px solid #0f172a; }
  header img { width: 56px; height: 56px; object-fit: contain; }
  header .biz { flex: 1; min-width: 0; }
  header .biz strong { display: block; font-size: 14pt; }
  header .biz span { display: block; font-size: 8.5pt; color: #475569; }
  header .doc { text-align: right; }
  header .doc strong { display: block; font-size: 13pt; }
  header .doc span { display: block; font-size: 9pt; color: #334155; }
  .scope { margin: 8px 0 0; font-size: 8.5pt; color: #475569; }
  .kpis { display: grid; grid-template-columns: repeat(auto-fit, minmax(36mm, 1fr)); gap: 6px; margin: 12px 0 4px; }
  .kpi { border: 1px solid #cbd5e1; border-radius: 6px; padding: 7px 9px; break-inside: avoid; }
  .kpi span { display: block; font-size: 7.5pt; color: #475569; text-transform: uppercase; letter-spacing: .03em; }
  .kpi strong { display: block; font-size: 12.5pt; font-variant-numeric: tabular-nums; margin-top: 2px; }
  .kpi small { display: block; font-size: 7.5pt; color: #64748b; margin-top: 2px; line-height: 1.3; }
  .kpi.good strong { color: #047857; } .kpi.bad strong { color: #b91c1c; }
  .block { margin-top: 14px; }
  h2 { font-size: 11pt; margin: 0 0 2px; break-after: avoid; }
  .note { margin: 0 0 5px; font-size: 8pt; color: #64748b; }
  table { width: 100%; border-collapse: collapse; table-layout: fixed; }
  th, td { padding: 4px 6px; border-bottom: 1px solid #e2e8f0; vertical-align: top; overflow-wrap: anywhere; }
  thead th { background: #f1f5f9; font-size: 7.5pt; text-transform: uppercase; letter-spacing: .03em; color: #334155; border-bottom: 1px solid #94a3b8; }
  thead { display: table-header-group; }
  tr { break-inside: avoid; }
  tfoot td { font-weight: 700; border-top: 1.5px solid #0f172a; border-bottom: none; background: #f8fafc; }
  .right { text-align: right; font-variant-numeric: tabular-nums; } .center { text-align: center; }
  td.neg { color: #b91c1c; }
  td.empty { text-align: center; color: #64748b; font-style: italic; padding: 10px; }
  .notes { margin-top: 14px; font-size: 8pt; color: #475569; padding-left: 14px; }
  footer { margin-top: 18px; padding-top: 6px; border-top: 1px solid #cbd5e1; display: flex; justify-content: space-between; font-size: 7.5pt; color: #64748b; }
</style></head>
<body>
  <header>
    ${logo ? `<img src="${esc(logo)}" alt="" />` : ''}
    <div class="biz">
      <strong>${esc(b?.businessName || 'Lantify POS')}</strong>
      ${b?.legalName && b.legalName !== b.businessName ? `<span>${esc(b.legalName)}</span>` : ''}
      ${b?.nit ? `<span>NIT ${esc(b.nit)}${b.dv ? `-${esc(b.dv)}` : ''}</span>` : ''}
      ${address ? `<span>${esc(address)}${b?.phone ? ` · ${esc(b.phone)}` : ''}</span>` : ''}
    </div>
    <div class="doc">
      <strong>${esc(doc.title)}</strong>
      <span>${esc(doc.period)}</span>
    </div>
  </header>
  ${doc.scope ? `<p class="scope">${esc(doc.scope)}</p>` : ''}
  <div class="kpis">${doc.kpis.map((k) => `<div class="kpi ${k.tone || ''}"><span>${esc(k.label)}</span><strong>${esc(cellText(k.value))}</strong>${k.hint ? `<small>${esc(k.hint)}</small>` : ''}</div>`).join('')}</div>
  ${doc.tables.filter((tb) => tb.only !== 'xlsx').map(htmlTable).join('')}
  ${doc.notes?.length ? `<ul class="notes">${doc.notes.map((n) => `<li>${esc(n)}</li>`).join('')}</ul>` : ''}
  <footer><span>${esc(t('reports:generado', { date: generated }))}</span><span>${esc(t('reports:software'))}</span></footer>
  <script>window.onload = function () { setTimeout(function () { window.focus(); window.print(); }, 300); };</script>
</body></html>`;
};

/** Abre el diálogo de impresión con el informe (imprimir o "Guardar como PDF") */
export const printReport = (doc: ReportDoc) => {
  document.getElementById('lantify-report-frame')?.remove();
  const iframe = document.createElement('iframe');
  iframe.id = 'lantify-report-frame';
  iframe.title = doc.title;
  Object.assign(iframe.style, { position: 'fixed', right: '0', bottom: '0', width: '0', height: '0', border: '0' });
  document.body.appendChild(iframe);
  const d = iframe.contentWindow?.document;
  if (!d) return;
  d.open();
  d.write(renderReport(doc));
  d.close();
};

// ── Excel ────────────────────────────────────────────────────

const FORMATS = { money: '"$" #,##0;[Red]-"$" #,##0', pct: '0.0%', int: '#,##0' } as const;

const xlsxCell = (c: ReportCell): XLSX.CellObject => {
  if (c === null || c === undefined || c === '') return { t: 's', v: '' };
  if (typeof c === 'object') return { t: 'n', v: c.v, z: FORMATS[c.f] };
  if (typeof c === 'number') return { t: 'n', v: c };
  return { t: 's', v: c };
};

const sheetName = (name: string, used: Set<string>) => {
  const base = name.replace(/[[\]:*?/\\]/g, ' ').trim().slice(0, 31) || 'Hoja';
  let out = base;
  for (let i = 2; used.has(out.toLowerCase()); i++) out = `${base.slice(0, 28)} ${i}`;
  used.add(out.toLowerCase());
  return out;
};

/** Hoja a partir de filas de celdas; anchos según el contenido */
const buildSheet = (rows: ReportCell[][], tableStart?: { row: number; cols: number; rows: number }) => {
  const ws: XLSX.WorkSheet = {};
  let maxCols = 1;
  rows.forEach((row, r) => {
    maxCols = Math.max(maxCols, row.length);
    row.forEach((c, col) => {
      if (c === null || c === undefined || c === '') return;
      ws[XLSX.utils.encode_cell({ r, c: col })] = xlsxCell(c);
    });
  });
  ws['!ref'] = XLSX.utils.encode_range({ s: { r: 0, c: 0 }, e: { r: Math.max(0, rows.length - 1), c: maxCols - 1 } });
  ws['!cols'] = Array.from({ length: maxCols }, (_, col) => {
    const longest = rows.reduce((n, row, r) => {
      // Las primeras filas (título, negocio) no definen el ancho de la columna A
      if (tableStart && r < tableStart.row) return n;
      return Math.max(n, cellText(row[col] ?? '').length);
    }, 8);
    return { wch: Math.min(48, longest + 2) };
  });
  if (tableStart && tableStart.rows > 0) {
    ws['!autofilter'] = { ref: XLSX.utils.encode_range({ s: { r: tableStart.row, c: 0 }, e: { r: tableStart.row + tableStart.rows, c: tableStart.cols - 1 } }) };
  }
  return ws;
};

export const reportWorkbook = (doc: ReportDoc) => {
  const b = useBusinessStore.getState().settings;
  const wb = XLSX.utils.book_new();
  const used = new Set<string>();
  const generated = new Date().toLocaleString(getLocale());
  const head: ReportCell[][] = [
    [b?.businessName || 'Lantify POS'],
    ...(b?.nit ? [[`NIT ${b.nit}${b.dv ? `-${b.dv}` : ''}`]] : []),
    [doc.title],
    [`${t('reports:periodo')}: ${doc.period}`],
    ...(doc.scope ? [[doc.scope]] : []),
    [t('reports:generado', { date: generated })],
    [],
  ];

  // Resumen: indicadores con su explicación y las notas
  const summary: ReportCell[][] = [
    ...head,
    [t('reports:col_indicador'), t('reports:col_valor'), t('reports:col_explicacion')],
    ...doc.kpis.map((k) => [k.label, k.value, k.hint || '']),
    ...(doc.notes?.length ? [[], [t('reports:notas')], ...doc.notes.map((n) => [n])] : []),
    [],
    [t('reports:software')],
  ];
  XLSX.utils.book_append_sheet(wb, buildSheet(summary, { row: head.length, cols: 3, rows: 0 }), sheetName(t('reports:hoja_resumen'), used));

  for (const tb of doc.tables.filter((x) => x.only !== 'pdf')) {
    const top: ReportCell[][] = [[tb.title], ...(tb.note ? [[tb.note]] : []), []];
    const rows: ReportCell[][] = [
      ...top,
      tb.columns.map((c) => c.label),
      ...(tb.rows.length ? tb.rows : [[tb.empty || t('reports:sin_datos')]]),
      ...(tb.totals && tb.rows.length ? [tb.totals] : []),
    ];
    XLSX.utils.book_append_sheet(wb, buildSheet(rows, { row: top.length, cols: tb.columns.length, rows: tb.rows.length }), sheetName(tb.sheet || tb.title, used));
  }
  return wb;
};

const fileSafe = (s: string) =>
  s.normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^\w-]+/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '').toLowerCase();

/** Genera el informe en el formato elegido */
export const exportReport = (doc: ReportDoc, format: ReportFormat, fileName?: string) => {
  if (format === 'pdf') return printReport(doc);
  XLSX.writeFile(reportWorkbook(doc), `lantify-${fileSafe(fileName || `${doc.title}-${doc.period}`)}.xlsx`, { compression: true });
};
