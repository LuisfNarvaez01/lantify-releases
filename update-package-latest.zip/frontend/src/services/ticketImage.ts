// ============================================
// SERVICES - Ticket como imagen (para mandarlo por WhatsApp)
// ============================================
// Dibuja en un canvas el mismo TicketDoc que va a la impresora, con letra negra
// y fondo blanco, y lo devuelve como PNG. No usa servicios externos.

import type { TicketBlock, TicketDoc } from '../../../src/domain/ticketDoc';
import { loadImage } from '../shared/media';

const WIDTH = 576; // 80 mm a 203 ppp: el ticket se ve igual que el impreso
const PAD = 28;
const SCALE = 2; // nítido en celulares
const FONT = "Arial, 'Helvetica Neue', sans-serif";
const SIZE = { small: 17, normal: 21, big: 32 } as const;

type Ctx = CanvasRenderingContext2D;

const fontFor = (b: { bold?: boolean; size?: 1 | 2; small?: boolean }) => {
  const px = b.size === 2 ? SIZE.big : b.small ? SIZE.small : SIZE.normal;
  return { css: `${b.bold || b.size === 2 ? 700 : 400} ${px}px ${FONT}`, line: Math.round(px * 1.32) };
};

/** Parte el texto en líneas que quepan en `max` píxeles */
const wrap = (ctx: Ctx, text: string, max: number): string[] => {
  const out: string[] = [];
  for (const para of String(text ?? '').split(/\r?\n/)) {
    let line = '';
    for (const word of para.split(/\s+/).filter(Boolean)) {
      const next = line ? `${line} ${word}` : word;
      if (ctx.measureText(next).width <= max || !line) line = next;
      else {
        out.push(line);
        line = word;
      }
    }
    out.push(line);
  }
  return out;
};

/** Recorre los bloques: con `draw` en falso solo mide la altura */
const layout = (ctx: Ctx, blocks: TicketBlock[], images: Map<string, HTMLImageElement>, x0: number, width: number, y0: number, draw: boolean): number => {
  let y = y0;
  for (const b of blocks) {
    switch (b.t) {
      case 'text': {
        const f = fontFor(b);
        ctx.font = f.css;
        for (const l of wrap(ctx, b.text, width - (b.invert ? 12 : 0))) {
          if (draw) {
            const w = ctx.measureText(l).width;
            const x = b.align === 'center' ? x0 + (width - w) / 2 : b.align === 'right' ? x0 + width - w : x0;
            if (b.invert) {
              ctx.fillStyle = '#000';
              ctx.fillRect(x - 6, y + 1, w + 12, f.line);
              ctx.fillStyle = '#fff';
            }
            ctx.fillText(l, x, y + f.line * 0.8);
            ctx.fillStyle = '#000';
          }
          y += f.line;
        }
        break;
      }
      case 'row': {
        const f = fontFor(b);
        ctx.font = f.css;
        const rw = ctx.measureText(b.right).width;
        const lines = wrap(ctx, b.left, Math.max(width * 0.4, width - rw - 12));
        lines.forEach((l, i) => {
          if (draw) {
            ctx.fillText(l, x0, y + f.line * 0.8);
            if (i === lines.length - 1) ctx.fillText(b.right, x0 + width - rw, y + f.line * 0.8);
          }
          y += f.line;
        });
        break;
      }
      case 'rule': {
        y += 6;
        if (draw) {
          ctx.lineWidth = b.style === 'double' ? 1.5 : 1.5;
          ctx.setLineDash(b.style === 'dashed' || !b.style ? [6, 4] : []);
          ctx.beginPath();
          ctx.moveTo(x0, y);
          ctx.lineTo(x0 + width, y);
          if (b.style === 'double') {
            ctx.moveTo(x0, y + 4);
            ctx.lineTo(x0 + width, y + 4);
          }
          ctx.stroke();
          ctx.setLineDash([]);
        }
        y += b.style === 'double' ? 12 : 8;
        break;
      }
      case 'feed':
        y += 12 * Math.max(1, Math.min(4, b.lines || 1));
        break;
      case 'image': {
        const img = b.src ? images.get(b.src) : undefined;
        if (!img) break;
        const w = Math.min(width, (b.width / WIDTH) * width);
        const h = (img.naturalHeight / img.naturalWidth) * w;
        if (draw) {
          const x = b.align === 'left' ? x0 : b.align === 'right' ? x0 + width - w : x0 + (width - w) / 2;
          ctx.imageSmoothingEnabled = false;
          ctx.drawImage(img, x, y, w, h);
        }
        y += h + 4;
        break;
      }
      case 'box': {
        const top = y + 4;
        const inner = layout(ctx, b.blocks, images, x0 + 10, width - 20, top + 8, draw);
        if (draw) {
          ctx.lineWidth = 1.5;
          ctx.setLineDash([6, 4]);
          ctx.strokeRect(x0, top, width, inner - top + 8);
          ctx.setLineDash([]);
        }
        y = inner + 16;
        break;
      }
    }
  }
  return y;
};

const collectImages = (blocks: TicketBlock[], out: string[] = []): string[] => {
  for (const b of blocks) {
    if (b.t === 'image' && b.src) out.push(b.src);
    if (b.t === 'box') collectImages(b.blocks, out);
  }
  return out;
};

/** El ticket como PNG listo para compartir */
export const ticketToPng = async (doc: TicketDoc): Promise<Blob> => {
  const images = new Map<string, HTMLImageElement>();
  await Promise.all(collectImages(doc.blocks).map((src) => loadImage(src).then((img) => images.set(src, img)).catch(() => undefined)));

  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d')!;
  const inner = WIDTH - PAD * 2;
  const height = Math.ceil(layout(ctx, doc.blocks, images, PAD, inner, PAD, false) + PAD);

  canvas.width = WIDTH * SCALE;
  canvas.height = height * SCALE;
  ctx.scale(SCALE, SCALE);
  ctx.fillStyle = '#fff';
  ctx.fillRect(0, 0, WIDTH, height);
  ctx.fillStyle = '#000';
  ctx.strokeStyle = '#000';
  ctx.textBaseline = 'alphabetic';
  layout(ctx, doc.blocks, images, PAD, inner, PAD, true);

  return new Promise((resolve, reject) => canvas.toBlob((b) => (b ? resolve(b) : reject(new Error('PNG'))), 'image/png'));
};
