// ============================================
// SERVICES - Errores de la API con mensajes claros
// ============================================
// Ningún error llega al usuario como "Failed to fetch" o un código HTTP:
// se clasifica (sin conexión, servidor apagado, sin permiso, credenciales...)
// y se muestra en su idioma. El detalle técnico queda en la consola.

import i18next, { t } from '../i18n';

export class ApiError extends Error {
  /** Datos extra de la respuesta (p. ej. la función que falta o el permiso de exportación) */
  public details: Record<string, any> = {};
  constructor(message: string, public code: string, public status: number) {
    super(message);
    this.name = ApiError.name;
  }
}

/** Errores en los que reintentar tiene sentido (red o servidor caído) */
export const CONNECTION_CODES = new Set(['NETWORK_OFFLINE', 'SERVER_UNREACHABLE', 'SERVER_TIMEOUT']);

export const isConnectionError = (e: unknown) => e instanceof ApiError && CONNECTION_CODES.has(e.code);

const known = (code?: string) => !!code && i18next.exists(`errors:${code}`);

/** Error de red (fetch no obtuvo respuesta). */
export const connectionError = (cause: unknown, timedOut: boolean): ApiError => {
  console.warn('[api] sin respuesta del servidor:', cause);
  const code = timedOut ? 'SERVER_TIMEOUT' : typeof navigator !== 'undefined' && navigator.onLine === false ? 'NETWORK_OFFLINE' : 'SERVER_UNREACHABLE';
  return new ApiError(t(`errors:${code}`), code, 0);
};

const STATUS_CODES: Record<number, string> = {
  401: 'AUTH_TOKEN_INVALID',
  403: 'AUTH_FORBIDDEN',
  404: 'NOT_FOUND',
  409: 'CONFLICT',
  413: 'PAYLOAD_TOO_LARGE',
  429: 'RATE_LIMITED',
};

/** Convierte una respuesta HTTP fallida en un error con mensaje para el usuario. */
export const responseError = (status: number, body: any): ApiError => {
  const err = classify(status, body);
  if (body && typeof body === 'object') err.details = body;
  return err;
};

const classify = (status: number, body: any): ApiError => {
  let code: string | undefined = body?.code;
  // Ruta que el servidor no conoce: la caja tiene una versión de Lantify más vieja que este equipo.
  // (Lantify 2.x responde NOT_FOUND con este texto; la 3.0 ya responde ROUTE_NOT_FOUND)
  if (status === 404 && (!body || typeof body !== 'object' || (code === 'NOT_FOUND' && body.error === 'La ruta solicitada no existe.'))) code = 'ROUTE_NOT_FOUND';
  // Los datos extra de la respuesta (p. ej. maxDevices) se usan en el mensaje
  if (known(code)) return new ApiError(t(`errors:${code}`, body || {}), code!, status);

  if (status >= 500) {
    console.error('[api] error del servidor:', status, body);
    return new ApiError(t('errors:SERVER_ERROR'), 'SERVER_ERROR', status);
  }
  // Las validaciones de negocio (400) traen un mensaje descriptivo del servidor
  if (status === 400 && typeof body?.error === 'string' && body.error.trim()) {
    return new ApiError(body.error, code || 'BAD_REQUEST', status);
  }
  const byStatus = STATUS_CODES[status];
  if (byStatus) return new ApiError(t(`errors:${byStatus}`), byStatus, status);
  if (typeof body?.error === 'string' && body.error.trim()) return new ApiError(body.error, code || 'HTTP_ERROR', status);
  return new ApiError(t('errors:error_en_la_solicitud'), 'HTTP_ERROR', status);
};

/** Mensaje para mostrar a partir de cualquier error capturado. */
export const errorMessage = (e: unknown, fallbackKey = 'errors:error_desconocido'): string => {
  if (e instanceof ApiError) return e.message;
  if (e instanceof TypeError && /fetch|network/i.test(e.message)) return t('errors:SERVER_UNREACHABLE');
  if (e instanceof Error && e.message) return e.message;
  return t(fallbackKey);
};
