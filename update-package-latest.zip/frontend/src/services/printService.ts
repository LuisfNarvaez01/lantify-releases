/**
 * Impresión de tickets: recibos, pre-cuentas y comandas.
 *
 * Con impresión directa el ticket va al servidor del negocio, que lo envía a la
 * impresora térmica elegida (USB por Windows o de red) sin ningún diálogo. Si no
 * está configurada o la impresora no responde, se abre el diálogo del navegador
 * con el mismo ticket, para que nunca quede un cobro sin su comprobante.
 */

import { printingAPI } from './api';
import { ApiError } from './apiErrors';
import { buildKitchenDoc, buildReceiptDoc, KitchenData, ReceiptData, TicketContext } from './ticketBuilder';
import { renderTicketPage } from './ticketHtml';
import { currentPrintSettings } from '../shared/printSettings';
import { useBusinessStore } from '../shared/business';
import { dotsFor, routeToStations, stationTarget } from '../../../src/domain/printSettings';
import type { PrintSettings } from '../../../src/domain/printSettings';
import type { TicketDoc } from '../../../src/domain/ticketDoc';
import { loadImage, mediaSrc, MonoBitmap, toMonoBitmap } from '../shared/media';
import { toast } from '../shared/toast';
import { t } from '../i18n';

export type PrintOutcome = 'direct' | 'browser';

const createPrintIframe = (content: string) => {
  document.getElementById('pos-print-iframe')?.remove();
  const iframe = document.createElement('iframe');
  iframe.id = 'pos-print-iframe';
  iframe.title = 'ticket';
  Object.assign(iframe.style, { position: 'fixed', right: '0', bottom: '0', width: '0', height: '0', border: '0' });
  document.body.appendChild(iframe);
  const doc = iframe.contentWindow?.document || iframe.contentDocument;
  if (doc) {
    doc.open();
    doc.write(content);
    doc.close();
  }
};

// El logo se convierte una vez por dirección y ancho de papel
const logoCache = new Map<string, Promise<MonoBitmap | null>>();

export const logoBitmap = (url: string | null | undefined, paper: PrintSettings['paperWidth']): Promise<MonoBitmap | null> => {
  if (!url) return Promise.resolve(null);
  const key = `${url}|${paper}`;
  if (!logoCache.has(key)) {
    const dots = dotsFor(paper);
    logoCache.set(
      key,
      loadImage(mediaSrc(url)!)
        .then((img) => toMonoBitmap(img, Math.round(dots * 0.5), 160))
        .catch(() => {
          logoCache.delete(key);
          return null;
        }),
    );
  }
  return logoCache.get(key)!;
};

export const ticketContext = async (settings?: PrintSettings): Promise<TicketContext> => {
  const s = settings || (await currentPrintSettings());
  const store = useBusinessStore.getState();
  const business = store.settings || (await store.load());
  return { settings: s, business, logo: s.showLogo ? await logoBitmap(business?.logoUrl, s.paperWidth) : null };
};

/** Envía directo a la impresora si está configurada. false = hay que usar el diálogo del navegador */
const tryDirect = async (role: 'receipt' | 'kitchen', doc: TicketDoc, s: PrintSettings, station?: string | null) => {
  const target = role === 'kitchen' ? stationTarget(s, station) : s.receipt;
  if (s.mode !== 'direct' || !target) return false;
  try {
    await printingAPI.print(role, doc, undefined, station);
    return true;
  } catch (err) {
    const reason = err instanceof ApiError && err.code !== 'PRINT_NOT_CONFIGURED' ? err.message : '';
    if (reason) toast.warning(reason, t('printing:fallo_directo_titulo'));
    return false;
  }
};

/** Imprime un ticket: directo si está configurado; si no (o si falla), con el diálogo del navegador */
export const printDoc = async (role: 'receipt' | 'kitchen', doc: TicketDoc, settings?: PrintSettings, station?: string | null): Promise<PrintOutcome> => {
  const s = settings || (await currentPrintSettings());
  if (await tryDirect(role, doc, s, station)) return 'direct';
  createPrintIframe(renderTicketPage(doc, s));
  return 'browser';
};

/** Varios tickets que no salieron directo van juntos en un solo diálogo, separados */
const joinDocs = (docs: TicketDoc[]): TicketDoc => ({
  title: docs.map((d) => d.title).join(' / '),
  blocks: docs.flatMap((d, i) => (i === 0 ? d.blocks : [{ t: 'feed', lines: 2 } as const, { t: 'rule', style: 'dashed' } as const, { t: 'feed', lines: 2 } as const, ...d.blocks])),
});

/** Dónde sale la comanda de un producto: lo elegido en el producto o en su categoría */
export type StationLookup = (productId: string) => { product?: string | null; category?: string | null };

const qrBitmap = async (dataUrl?: string) => {
  if (!dataUrl) return null;
  try {
    return toMonoBitmap(await loadImage(dataUrl), 200, 200, false);
  } catch {
    return null;
  }
};

export const printService = {
  /** Recibo del cobro, pre-cuenta o copia desde el historial */
  printReceipt: async (data: ReceiptData & { claimQrDataUrl?: string }): Promise<PrintOutcome> => {
    const ctx = await ticketContext();
    const doc = buildReceiptDoc({ ...data, claimQr: await qrBitmap(data.claimQrDataUrl) }, ctx);
    return printDoc('receipt', doc, ctx.settings);
  },

  /** Pre-cuenta desde el celular: sale en la impresora de la caja si hay impresión directa; nunca abre el diálogo del teléfono */
  printReceiptDirectOnly: async (data: ReceiptData): Promise<boolean> => {
    const ctx = await ticketContext();
    return tryDirect('receipt', buildReceiptDoc({ ...data, claimQr: null }, ctx), ctx.settings);
  },

  /**
   * Comanda del pedido. Si hay estaciones (barra, postres...), cada una recibe en su
   * impresora solo lo que prepara; lo marcado "no imprime" no sale. null = nada que imprimir.
   */
  printKitchenTicket: async (data: KitchenData, lookup?: StationLookup): Promise<PrintOutcome | null> => {
    const ctx = await ticketContext();
    const s = ctx.settings;
    const groups = routeToStations(data.items, (item: any) => (lookup && item?.productId ? lookup(item.productId) : {}), s);
    if (groups.length === 0) return null;
    const pending: TicketDoc[] = [];
    for (const g of groups) {
      // La cocina principal no lleva nombre; las demás estaciones sí (BARRA, POSTRES...)
      const doc = buildKitchenDoc({ ...data, items: g.items, station: g.name }, ctx);
      if (!(await tryDirect('kitchen', doc, s, g.id === 'kitchen' ? null : g.id))) pending.push(doc);
    }
    if (pending.length === 0) return 'direct';
    createPrintIframe(renderTicketPage(joinDocs(pending), s));
    return 'browser';
  },
};
