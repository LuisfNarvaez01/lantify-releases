/**
 * Impresión de tickets: recibos, pre-cuentas y comandas.
 *
 * Con impresión directa el ticket va al servidor del negocio, que lo envía a la
 * impresora térmica elegida (USB por Windows o de red) sin ningún diálogo. Si no
 * está configurada o la impresora no responde, se abre el diálogo del navegador
 * con el mismo ticket, para que nunca quede un cobro sin su comprobante.
 */

import { printingAPI } from './api';
import { ApiError } from './apiErrors';
import { buildKitchenDoc, buildReceiptDoc, KitchenData, ReceiptData, TicketContext } from './ticketBuilder';
import { renderTicketPage } from './ticketHtml';
import { currentPrintSettings } from '../shared/printSettings';
import { useBusinessStore } from '../shared/business';
import { dotsFor } from '../../../src/domain/printSettings';
import type { PrintSettings } from '../../../src/domain/printSettings';
import type { TicketDoc } from '../../../src/domain/ticketDoc';
import { loadImage, mediaSrc, MonoBitmap, toMonoBitmap } from '../shared/media';
import { toast } from '../shared/toast';
import { t } from '../i18n';

export type PrintOutcome = 'direct' | 'browser';

const createPrintIframe = (content: string) => {
  document.getElementById('pos-print-iframe')?.remove();
  const iframe = document.createElement('iframe');
  iframe.id = 'pos-print-iframe';
  iframe.title = 'ticket';
  Object.assign(iframe.style, { position: 'fixed', right: '0', bottom: '0', width: '0', height: '0', border: '0' });
  document.body.appendChild(iframe);
  const doc = iframe.contentWindow?.document || iframe.contentDocument;
  if (doc) {
    doc.open();
    doc.write(content);
    doc.close();
  }
};

// El logo se convierte una vez por dirección y ancho de papel
const logoCache = new Map<string, Promise<MonoBitmap | null>>();

export const logoBitmap = (url: string | null | undefined, paper: PrintSettings['paperWidth']): Promise<MonoBitmap | null> => {
  if (!url) return Promise.resolve(null);
  const key = `${url}|${paper}`;
  if (!logoCache.has(key)) {
    const dots = dotsFor(paper);
    logoCache.set(
      key,
      loadImage(mediaSrc(url)!)
        .then((img) => toMonoBitmap(img, Math.round(dots * 0.5), 160))
        .catch(() => {
          logoCache.delete(key);
          return null;
        }),
    );
  }
  return logoCache.get(key)!;
};

export const ticketContext = async (settings?: PrintSettings): Promise<TicketContext> => {
  const s = settings || (await currentPrintSettings());
  const store = useBusinessStore.getState();
  const business = store.settings || (await store.load());
  return { settings: s, business, logo: s.showLogo ? await logoBitmap(business?.logoUrl, s.paperWidth) : null };
};

/** Imprime un ticket: directo si está configurado; si no (o si falla), con el diálogo del navegador */
export const printDoc = async (role: 'receipt' | 'kitchen', doc: TicketDoc, settings?: PrintSettings): Promise<PrintOutcome> => {
  const s = settings || (await currentPrintSettings());
  const target = role === 'kitchen' ? s.kitchen || s.receipt : s.receipt;
  if (s.mode === 'direct' && target) {
    try {
      await printingAPI.print(role, doc);
      return 'direct';
    } catch (err) {
      const reason = err instanceof ApiError && err.code !== 'PRINT_NOT_CONFIGURED' ? err.message : '';
      if (reason) toast.warning(reason, t('printing:fallo_directo_titulo'));
    }
  }
  createPrintIframe(renderTicketPage(doc, s));
  return 'browser';
};

const qrBitmap = async (dataUrl?: string) => {
  if (!dataUrl) return null;
  try {
    return toMonoBitmap(await loadImage(dataUrl), 200, 200, false);
  } catch {
    return null;
  }
};

export const printService = {
  /** Recibo del cobro, pre-cuenta o copia desde el historial */
  printReceipt: async (data: ReceiptData & { claimQrDataUrl?: string }): Promise<PrintOutcome> => {
    const ctx = await ticketContext();
    const doc = buildReceiptDoc({ ...data, claimQr: await qrBitmap(data.claimQrDataUrl) }, ctx);
    return printDoc('receipt', doc, ctx.settings);
  },

  /** Comanda para cocina o barra (va a la impresora de cocina si hay una) */
  printKitchenTicket: async (data: KitchenData): Promise<PrintOutcome> => {
    const ctx = await ticketContext();
    return printDoc('kitchen', buildKitchenDoc(data, ctx), ctx.settings);
  },
};
