// ============================================
// SERVICES - Proyecta (Lantify Música). Ver src/interfaces/routes/proyectaRoutes.ts
// ============================================

import { API_URL } from '../config';
import { responseError } from './apiErrors';

export interface ProyectaVenue { venueId: string; name: string; online: boolean; lastSeenAt: string | null }
/** Pedido que espera decisión mientras no hay DJ en cabina */
export interface ProyectaDeskRequest { id: string; title: string; artist?: string; table?: string; guest?: string; thumbnailUrl?: string; at: string }
export interface ProyectaAlert { id: string; kind: 'load_failed' | 'skipped' | 'info'; text: string; at: string }
export interface ProyectaAutopilot { enabled: boolean; maxPerHour: number; maxPerTable: number; skipOnLoadError: boolean }
export interface ProyectaDesk {
  online: boolean;
  /** Con DJ en cabina la caja no recibe pedidos ni avisos (solo el chat) */
  djPresent: boolean;
  pending: ProyectaDeskRequest[];
  alerts: ProyectaAlert[];
  autopilot: ProyectaAutopilot;
  lastChat: { id: string; from: 'dj' | 'pos'; at: string } | null;
}
export interface ProyectaStatus { venue: ProyectaVenue | null; tableUrl: string | null; desk?: ProyectaDesk | null }
export interface ProyectaMessage { id: string; from: 'dj' | 'pos'; author: string; text: string; at: string }

const call = async <T = any>(method: string, path: string, body?: unknown): Promise<T> => {
  const res = await fetch(`${API_URL}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${localStorage.getItem('token') || ''}` },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  if (!res.ok) throw responseError(res.status, await res.json().catch(() => null));
  return res.status === 204 ? (null as T) : res.json();
};

export const proyectaAPI = {
  status: () => call<ProyectaStatus>('GET', '/proyecta'),
  linkCode: () => call<{ code: string; expiresAt: string }>('POST', '/proyecta/link-code', {}),
  chat: (since?: string | null) => call<{ messages: ProyectaMessage[]; online: boolean }>('GET', `/proyecta/chat${since ? `?since=${encodeURIComponent(since)}` : ''}`),
  send: (text: string) => call<ProyectaMessage>('POST', '/proyecta/chat', { text }),
  decide: (id: string, action: 'approve' | 'reject') => call('POST', '/proyecta/decide', { id, action }),
  setAutopilot: (rules: ProyectaAutopilot) => call<ProyectaAutopilot>('PUT', '/proyecta/autopilot', rules),
};
