// ============================================
// SERVICES - Proyecta (Lantify Música). Ver src/interfaces/routes/proyectaRoutes.ts
// ============================================

import { API_URL } from '../config';
import { responseError } from './apiErrors';

export interface ProyectaVenue { venueId: string; name: string; online: boolean; lastSeenAt: string | null }
export interface ProyectaStatus { venue: ProyectaVenue | null; tableUrl: string | null }
export interface ProyectaMessage { id: string; from: 'dj' | 'pos'; author: string; text: string; at: string }

const call = async <T = any>(method: string, path: string, body?: unknown): Promise<T> => {
  const res = await fetch(`${API_URL}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${localStorage.getItem('token') || ''}` },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  if (!res.ok) throw responseError(res.status, await res.json().catch(() => null));
  return res.status === 204 ? (null as T) : res.json();
};

export const proyectaAPI = {
  status: () => call<ProyectaStatus>('GET', '/proyecta'),
  linkCode: () => call<{ code: string; expiresAt: string }>('POST', '/proyecta/link-code', {}),
  chat: (since?: string | null) => call<{ messages: ProyectaMessage[]; online: boolean }>('GET', `/proyecta/chat${since ? `?since=${encodeURIComponent(since)}` : ''}`),
  send: (text: string) => call<ProyectaMessage>('POST', '/proyecta/chat', { text }),
};
