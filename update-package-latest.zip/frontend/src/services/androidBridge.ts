// ============================================
// SERVICES - Puente con la app Android (MainActivity.java)
// ============================================
// La app Android expone `window.LantifyAndroid`. Lo que tarda (buscar la caja en la red)
// responde llamando a una función de `window`, como el escáner de QR (__lantifyPair).
// En el navegador, el iPhone o la caja nada de esto existe y todo sigue igual.

import { discoveredBases } from '../../../src/domain/lanDiscovery';

export interface AndroidBridge {
  scanQr(): void;
  version?(): string;
  /** Busca _lantify._tcp en la red (NsdManager) y responde en __lantifyDiscovered(json) */
  discover?(): void;
  /** ¿El dueño activó el acceso a notificaciones para Lantify? */
  bankAccessEnabled?(): boolean;
  /** Abre la pantalla del sistema donde se activa ese acceso */
  openBankAccess?(): void;
  /** App 1.1+: Información de la app (para "Permitir configuración restringida") */
  openAppInfo?(): void;
  /** Avisos de transferencia ya analizados, en espera de llegar a la caja (JSON) */
  pendingBankNotices?(): string;
  /** La caja ya recibió este aviso: se quita de la cola del teléfono */
  ackBankNotice?(ref: string): void;
  /** App 1.2+: ingresos guardados por local (contraseña cifrada con AndroidKeyStore) */
  loginsList?(scope: string): string;
  loginPassword?(scope: string, username: string): string | null;
  loginSave?(scope: string, json: string): boolean;
  loginRemove?(scope: string, username: string): boolean;
  /** App 1.2+: con sesión abierta, seguir conectado con la pantalla apagada */
  keepAlive?(on: boolean): void;
}

declare global {
  interface Window {
    LantifyAndroid?: AndroidBridge;
    __lantifyPair?: (link: string) => void;
    __lantifyDiscovered?: (json: string) => void;
    __lantifyBankNotice?: () => void;
    /** La app volvió al frente (pantalla encendida): reconectar ya */
    __lantifyResume?: () => void;
  }
}

export const androidBridge = (): AndroidBridge | null => (typeof window !== 'undefined' ? window.LantifyAndroid ?? null : null);

let inFlight: Promise<string[]> | null = null;

/** Cajas anunciadas en la red local (vacío si no es la app Android o no hay ninguna) */
export const discoverOnLan = (timeoutMs = 6000): Promise<string[]> => {
  const bridge = androidBridge();
  if (!bridge?.discover) return Promise.resolve([]);
  if (inFlight) return inFlight;
  inFlight = new Promise<string[]>((resolve) => {
    const finish = (raw: unknown) => {
      clearTimeout(timer);
      if (window.__lantifyDiscovered === onResult) delete window.__lantifyDiscovered;
      inFlight = null;
      resolve(discoveredBases(raw));
    };
    const onResult = (json: string) => finish(json);
    const timer = setTimeout(() => finish('[]'), timeoutMs);
    window.__lantifyDiscovered = onResult;
    try { bridge.discover!(); } catch { finish('[]'); }
  });
  return inFlight;
};
