// ============================================
// SERVICES - API de Lantify 3.0 (bloque 1)
// ============================================
// Funciones activables, salón, operación y personal. Ver src/interfaces/routes/v3Routes.ts.

import { API_URL } from '../config';
import { responseError } from './apiErrors';
import type { FeatureKey, FeatureSettings, StaffGroup, TipRules } from '../../../src/domain/v3/features';
import type { TableAlert } from '../../../src/domain/v3/tableAlerts';
import type { DisplayType } from '../../../src/domain/v3/kitchen';
import type { MenuReading, Suggestion } from '../../../src/domain/v3/menuEngine';
import type { Intervention, Situation } from '../../../src/domain/v3/autopilot';
import type { CloseReport } from '../../../src/domain/v3/closeReport';
import type { PaymentPart } from '../../../src/domain/v3/paymentFix';
import { getLanguage as currentLanguage } from '../i18n';

const call = async <T = any>(method: string, path: string, body?: unknown): Promise<T> => {
  const res = await fetch(`${API_URL}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${localStorage.getItem('token') || ''}` },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  if (!res.ok) throw responseError(res.status, await res.json().catch(() => null));
  return res.status === 204 ? (null as T) : res.json();
};

const qs = (params: Record<string, string | undefined | null>) =>
  Object.entries(params).filter(([, v]) => v).map(([k, v]) => `${k}=${encodeURIComponent(v as string)}`).join('&');

export type FeaturesResponse = FeatureSettings & { plan: Record<FeatureKey, string | null>; requires: Partial<Record<FeatureKey, FeatureKey>> };

export interface FloorTable { tableId: string; tableNumber?: string; orderId: string; total: number; waiterId: string | null; waiterName: string | null; lastRoundAt: string | null; billRequestedAt: string | null }
export interface FloorPickup { tableId: string; tableNumber: string; waiterId: string | null; waiterName: string | null; count: number; readyAt: string | null }
export interface StaffNotice { id: string; message: string; createdAt: string; [k: string]: any }
export interface FloorState { now: string; tables: FloorTable[]; dirty: { tableId: string; dirtyAt: string | null }[]; alerts: TableAlert[]; pickups?: FloorPickup[]; notices?: StaffNotice[] }

export interface DisplayInfo { id: string; name: string; type: DisplayType; station: string | null; connected: boolean; pairing: boolean; lastSeenAt: string | null; createdAt: string }

export interface ShoppingGroup { supplierId: string | null; supplierName: string; phone: string | null; text: string; lines: { variantId: string; name: string; quantity: number; unit: string; stock: number; minStock: number }[] }

export interface Employee {
  id: string; name: string; position: StaffGroup; phone: string | null; startDate: string | null; payType: 'SHIFT' | 'HOUR' | 'FIXED'; payAmount: number; workDays?: string | null;
  userId: string | null; isActive: boolean; user: { id: string; username: string; role: string; isActive: boolean } | null; openShift: { id: string; startAt: string } | null;
}
export interface Shift { id: string; employeeId: string; startAt: string; endAt: string | null; needsReview: boolean; markedBy: string | null; editedBy: string | null; employee?: { name: string; position: string } }
export interface StaffMovement { id: string; employeeId: string; type: 'ADVANCE' | 'DEDUCTION'; amount: number; reason: string | null; date: string; payrollId: string | null; employee?: { name: string } }
export interface PayrollRow { employeeId: string; name: string; position: string; payType: string; payAmount: number; days: number; hours: number; pendingShifts: number; base: number; tips: number; advances: number; deductions: number; total: number }
export interface Payroll { id: string; employeeId: string; periodFrom: string; periodTo: string; base: number; tips: number; advances: number; deductions: number; total: number; status: 'PENDING' | 'PAID'; paidAt: string | null; employee?: { name: string; position: string } }
export interface TipPreview { total: number; rules: TipRules; shares: { employeeId: string; name: string; group: StaffGroup; amount: number }[]; unassigned: { group: StaffGroup; amount: number }[]; employees: { id: string; name: string; group: StaffGroup }[]; alreadyConfirmed: boolean }
export interface TipSplit { id: string; periodType: string; periodFrom: string; periodTo: string; total: number; status: 'CONFIRMED' | 'PAID'; shares: { id: string; employeeId: string; group: string; amount: number; payrollId: string | null; employee: { name: string } }[] }

export const featuresAPI = {
  get: () => call<FeaturesResponse>('GET', '/features'),
  save: (patch: Partial<Omit<FeatureSettings, 'flags' | 'alerts' | 'tips'>> & { flags?: Partial<Record<FeatureKey, boolean>>; alerts?: Partial<FeatureSettings['alerts']>; tips?: Partial<TipRules> }) => call<FeaturesResponse>('PUT', '/features', patch),
};

export const floorAPI = {
  state: () => call<FloorState>('GET', '/floor'),
  clean: (tableId: string) => call('PATCH', `/floor/tables/${tableId}/clean`),
  requestBill: (tableId: string) => call('POST', `/floor/tables/${tableId}/bill`),
  undoBill: (tableId: string) => call('DELETE', `/floor/tables/${tableId}/bill`),
  assignWaiter: (tableId: string, userId: string) => call('PATCH', `/floor/tables/${tableId}/waiter`, { userId }),
  served: (tableId: string) => call<{ served: number }>('POST', `/floor/tables/${tableId}/served`),
  details: (tableId: string, data: { guests: number | null; label: string | null }) => call('PATCH', `/floor/tables/${tableId}/details`, data),
  pickedUp: (orderId: string) => call('POST', `/floor/orders/${orderId}/picked-up`),
};

/** Pantallas: administración (ADMIN) */
export const displaysAPI = {
  list: () => call<DisplayInfo[]>('GET', '/displays'),
  create: (data: { name: string; type: DisplayType; station: string | null }) => call<{ display: DisplayInfo; code: string; expiresAt: string }>('POST', '/displays', data),
  code: (id: string) => call<{ display: DisplayInfo; code: string; expiresAt: string }>('POST', `/displays/${id}/code`),
  disconnect: (id: string) => call<DisplayInfo>('POST', `/displays/${id}/disconnect`),
  remove: (id: string) => call('DELETE', `/displays/${id}`),
};

export const opsAPI = {
  shoppingList: () => call<{ businessName: string; groups: ShoppingGroup[] }>('GET', `/ops/shopping-list?lang=${currentLanguage()}`),
  shoppingSent: (supplier: string, lines: number, via: 'whatsapp' | 'copy') => call('POST', '/ops/shopping-list/sent', { supplier, lines, via }),
  setReorder: (variantId: string, data: { minStock?: number | null; reorderQty?: number | null; purchaseUnit?: string | null; preferredSupplierId?: string | null }) => call('PUT', `/ops/reorder/${variantId}`, data),
  setIngredients: (productId: string, ingredients: string[]) => call<{ id: string; ingredients: string[] }>('PUT', `/ops/products/${productId}/ingredients`, { ingredients }),
  correctPayments: (saleId: string, payments: PaymentPart[], reason: string) => call('PUT', `/ops/sales/${saleId}/payments`, { payments, reason }),
  closeReport: (sessionId: string) => call<{ report: CloseReport; text: string; ownerWhatsapp: string; enabled: boolean }>('GET', `/ops/close-report/${sessionId}?lang=${currentLanguage()}`),
};

export const staffAPI = {
  list: () => call<Employee[]>('GET', '/staff'),
  create: (data: Partial<Employee>) => call<Employee>('POST', '/staff', data),
  update: (id: string, data: Partial<Employee>) => call<Employee>('PUT', `/staff/${id}`, data),
  myShift: () => call<{ employeeId: string | null; open: Shift | null }>('GET', '/staff/me/shift'),
  myClockIn: () => call<Shift>('POST', '/staff/me/clock-in'),
  myClockOut: () => call<Shift>('POST', '/staff/me/clock-out'),
  clockIn: (id: string) => call<Shift>('POST', `/staff/${id}/clock-in`),
  clockOut: (id: string) => call<Shift>('POST', `/staff/${id}/clock-out`),
  shifts: (from: string, to: string, employeeId?: string) => call<Shift[]>('GET', `/staff/shifts/list?${qs({ from, to, employeeId })}`),
  saveShift: (id: string | null, data: { employeeId?: string; startAt?: string; endAt?: string | null }) => (id ? call<Shift>('PUT', `/staff/shifts/${id}`, data) : call<Shift>('POST', '/staff/shifts', data)),
  deleteShift: (id: string) => call('DELETE', `/staff/shifts/${id}`),
  movements: (from: string, to: string) => call<StaffMovement[]>('GET', `/staff/movements/list?${qs({ from, to })}`),
  addMovement: (data: { employeeId: string; type: 'ADVANCE' | 'DEDUCTION'; amount: number; reason?: string }) => call<StaffMovement>('POST', '/staff/movements', data),
  deleteMovement: (id: string) => call('DELETE', `/staff/movements/${id}`),
  payrollPreview: (from: string, to: string) => call<PayrollRow[]>('GET', `/staff/payroll/preview?${qs({ from, to })}`),
  payrolls: () => call<Payroll[]>('GET', '/staff/payroll/list'),
  createPayroll: (employeeId: string, from: string, to: string) => call<Payroll>('POST', '/staff/payroll', { employeeId, from, to }),
  payPayroll: (id: string, asExpense: boolean) => call<Payroll>('POST', `/staff/payroll/${id}/pay`, { asExpense }),
  deletePayroll: (id: string) => call('DELETE', `/staff/payroll/${id}`),
  tipPreview: (from: string, to: string, cashSessionId?: string | null) => call<TipPreview>('GET', `/staff/tips/preview?${qs({ from, to, cashSessionId })}`),
  tipSplits: () => call<TipSplit[]>('GET', '/staff/tips/list'),
  confirmTips: (data: { from: string; to: string; periodType: string; cashSessionId?: string | null; shares: { employeeId: string; amount: number }[] }) => call<TipSplit>('POST', '/staff/tips', data),
  payTips: (id: string) => call<TipSplit>('POST', `/staff/tips/${id}/pay`),
  deleteTipSplit: (id: string) => call('DELETE', `/staff/tips/${id}`),
};

// ── Motor de menú y Autopilot (bloque 4) ──
export type AutopilotSituation = Situation & { id: string; firstSeenAt: string; ownerNotified: boolean };
export interface AutopilotAction { id: string; kind: Intervention['kind']; params: Record<string, any>; status: 'DONE' | 'REVERTED' | 'FAILED'; source: 'LOCAL' | 'OWNER'; decidedBy: string | null; revertAt: string | null; createdAt: string; result: any }
export interface AutopilotState { enabled: boolean; learning: { historyDays: number; minDays: number } | null; situations: AutopilotSituation[]; actions: AutopilotAction[] }
export interface AutopilotKnowledge {
  builtAt: string; historyDays: number; ready: boolean; minDays: number; firstSaleAt: string | null;
  prepAll: { median: number; p80: number } | null; capacity30: number | null;
  todayByHour: { hour: number; sales: number }[]; fastest: { name: string; minutes: number }[]; slowest: { name: string; minutes: number }[];
}

export const menuAPI = {
  reading: (fresh = false) => call<MenuReading>('GET', `/menu${fresh ? '?fresh=1' : ''}`),
  suggestions: (cart: string[]) => call<{ suggestions: Suggestion[] }>('POST', '/menu/suggestions', { cart }),
  event: (productId: string, reason: string, accepted: boolean) => call('POST', '/menu/suggestions/event', { productId, reason, accepted }),
};

export const autopilotAPI = {
  state: () => call<AutopilotState>('GET', '/autopilot'),
  knowledge: () => call<AutopilotKnowledge>('GET', '/autopilot/knowledge'),
  tick: () => call('POST', '/autopilot/tick'),
  decide: (situationId: string, interventionId: string, params: Record<string, any>) => call<{ action: { id: string; kind: string; params: any; result: any; revertAt: string | null } }>('POST', `/autopilot/situations/${situationId}/decide`, { interventionId, params }),
  dismiss: (situationId: string) => call('POST', `/autopilot/situations/${situationId}/dismiss`),
  revert: (actionId: string) => call('POST', `/autopilot/actions/${actionId}/revert`),
};

// ── Ingredientes y recetas ──
export interface Ingredient {
  id: string; name: string; unit: 'g' | 'ml' | 'und'; stock: number; avgCost: number; lastCost: number | null; minStock: number | null;
  category: string | null; preferredSupplierId: string | null; low: boolean; usedIn: number;
}
export interface IngredientMovement { id: string; type: string; quantity: number; previousStock: number; newStock: number; unitCost: number | null; reference: string | null; notes: string | null; createdBy: string | null; createdAt: string }
export interface RecipeView { productId: string; name: string; items: { ingredientId: string; name: string; unit: string; quantity: number; removable: boolean; avgCost: number; lineCost: number }[]; cost: number; price: number; margin: number | null; minMarginPct: number }

export const ingredientsAPI = {
  list: () => call<Ingredient[]>('GET', '/ingredients'),
  save: (id: string | null, data: Partial<Ingredient> & { stock?: number }) => (id ? call<Ingredient>('PUT', `/ingredients/${id}`, data) : call<Ingredient>('POST', '/ingredients', data)),
  remove: (id: string) => call('DELETE', `/ingredients/${id}`),
  movements: (id: string) => call<IngredientMovement[]>('GET', `/ingredients/${id}/movements`),
  adjust: (id: string, data: { type: 'ADJUSTMENT' | 'WASTE' | 'COUNT'; quantity: number; notes?: string }) => call<Ingredient>('POST', `/ingredients/${id}/adjust`, data),
};

export const recipesAPI = {
  get: (productId: string) => call<RecipeView>('GET', `/recipes/${productId}`),
  set: (productId: string, items: { ingredientId: string; quantity: number; removable: boolean }[]) => call<RecipeView>('PUT', `/recipes/${productId}`, { items }),
  costs: () => call<{ minMarginPct: number; products: { productId: string; name: string; cost: number; price: number; margin: number | null; low: boolean }[] }>('GET', '/recipes/costs'),
};
