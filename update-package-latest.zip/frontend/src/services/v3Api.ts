// ============================================
// SERVICES - API de Lantify 3.0 (bloque 1)
// ============================================
// Funciones activables, salón, operación y personal. Ver src/interfaces/routes/v3Routes.ts.

import { API_URL } from '../config';
import { responseError } from './apiErrors';
import type { FeatureKey, FeatureSettings, StaffGroup, TipRules } from '../../../src/domain/v3/features';
import type { TableAlert } from '../../../src/domain/v3/tableAlerts';
import type { DisplayType } from '../../../src/domain/v3/kitchen';
import type { MenuReading, Suggestion } from '../../../src/domain/v3/menuEngine';
import type { Intervention, Situation } from '../../../src/domain/v3/autopilot';
import type { CloseReport } from '../../../src/domain/v3/closeReport';
import type { ClosingTicket } from '../../../src/domain/v3/closingTicket';
import type { PaymentPart } from '../../../src/domain/v3/paymentFix';
import { getLanguage as currentLanguage } from '../i18n';
import type { PriceRule } from '../../../src/domain/priceRules';
import type { SurveySummary } from '../../../src/domain/survey';

const call = async <T = any>(method: string, path: string, body?: unknown): Promise<T> => {
  const res = await fetch(`${API_URL}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${localStorage.getItem('token') || ''}` },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  if (!res.ok) throw responseError(res.status, await res.json().catch(() => null));
  return res.status === 204 ? (null as T) : res.json();
};

const qs = (params: Record<string, string | undefined | null>) =>
  Object.entries(params).filter(([, v]) => v).map(([k, v]) => `${k}=${encodeURIComponent(v as string)}`).join('&');

export type FeaturesResponse = FeatureSettings & { plan: Record<FeatureKey, string | null>; requires: Partial<Record<FeatureKey, FeatureKey>> };

export interface FloorTable { tableId: string; tableNumber?: string; orderId: string; total: number; waiterId: string | null; waiterName: string | null; lastRoundAt: string | null; billRequestedAt: string | null }
export interface FloorPickup { tableId: string; tableNumber: string; waiterId: string | null; waiterName: string | null; count: number; readyAt: string | null }
export interface StaffNotice { id: string; message: string; createdAt: string; [k: string]: any }
/** Pedido que un cliente hizo desde el QR de su mesa y espera al mesero (Fase 4) */
export interface TableRequest {
  id: string; code: string; tableId: string | null; tableNumber: string; waiterId: string | null; waiterName: string | null;
  items: { name: string; qty: number; price: number; note: string | null }[]; notes: string | null; total: number; placedAt: string;
}
export interface FloorState { now: string; tables: FloorTable[]; dirty: { tableId: string; dirtyAt: string | null }[]; alerts: TableAlert[]; pickups?: FloorPickup[]; notices?: StaffNotice[]; tableRequests?: TableRequest[] }

export interface DisplayInfo { id: string; name: string; type: DisplayType; station: string | null; connected: boolean; pairing: boolean; lastSeenAt: string | null; createdAt: string }

export interface ShoppingGroup { supplierId: string | null; supplierName: string; phone: string | null; text: string; lines: { variantId: string; name: string; quantity: number; unit: string; stock: number; minStock: number }[] }

export interface Employee {
  id: string; name: string; position: StaffGroup; phone: string | null; startDate: string | null; payType: 'SHIFT' | 'HOUR' | 'FIXED'; payAmount: number; workDays?: string | null;
  userId: string | null; isActive: boolean; user: { id: string; username: string; role: string; isActive: boolean } | null; openShift: { id: string; startAt: string } | null;
  /** Tiene PIN de asistencia (el PIN nunca sale del servidor) */
  hasPin?: boolean;
}
export interface Shift { id: string; employeeId: string; startAt: string; endAt: string | null; needsReview: boolean; markedBy: string | null; editedBy: string | null; employee?: { name: string; position: string } }
export interface StaffMovement { id: string; employeeId: string; type: 'ADVANCE' | 'DEDUCTION'; amount: number; reason: string | null; date: string; payrollId: string | null; employee?: { name: string } }
export interface PayrollRow { employeeId: string; name: string; position: string; payType: string; payAmount: number; days: number; hours: number; pendingShifts: number; base: number; tips: number; advances: number; deductions: number; total: number }
export interface Payroll { id: string; employeeId: string; periodFrom: string; periodTo: string; base: number; tips: number; advances: number; deductions: number; total: number; status: 'PENDING' | 'PAID'; paidAt: string | null; employee?: { name: string; position: string } }
export interface TipPreview { total: number; rules: TipRules; shares: { employeeId: string; name: string; group: StaffGroup; amount: number }[]; unassigned: { group: StaffGroup; amount: number }[]; employees: { id: string; name: string; group: StaffGroup }[]; alreadyConfirmed: boolean }
export interface TipSplit { id: string; periodType: string; periodFrom: string; periodTo: string; total: number; status: 'CONFIRMED' | 'PAID'; shares: { id: string; employeeId: string; group: string; amount: number; payrollId: string | null; employee: { name: string } }[] }

export const featuresAPI = {
  get: () => call<FeaturesResponse>('GET', '/features'),
  save: (patch: Partial<Omit<FeatureSettings, 'flags' | 'alerts' | 'tips'>> & { flags?: Partial<Record<FeatureKey, boolean>>; alerts?: Partial<FeatureSettings['alerts']>; tips?: Partial<TipRules> }) => call<FeaturesResponse>('PUT', '/features', patch),
};

export const floorAPI = {
  state: () => call<FloorState>('GET', '/floor'),
  clean: (tableId: string) => call('PATCH', `/floor/tables/${tableId}/clean`),
  requestBill: (tableId: string) => call('POST', `/floor/tables/${tableId}/bill`),
  undoBill: (tableId: string) => call('DELETE', `/floor/tables/${tableId}/bill`),
  assignWaiter: (tableId: string, userId: string) => call('PATCH', `/floor/tables/${tableId}/waiter`, { userId }),
  served: (tableId: string) => call<{ served: number }>('POST', `/floor/tables/${tableId}/served`),
  details: (tableId: string, data: { guests: number | null; label: string | null }) => call('PATCH', `/floor/tables/${tableId}/details`, data),
  pickedUp: (orderId: string) => call('POST', `/floor/orders/${orderId}/picked-up`),
};

/** Pantallas: administración (ADMIN) */
export const displaysAPI = {
  list: () => call<DisplayInfo[]>('GET', '/displays'),
  create: (data: { name: string; type: DisplayType; station: string | null }) => call<{ display: DisplayInfo; code: string; expiresAt: string }>('POST', '/displays', data),
  code: (id: string) => call<{ display: DisplayInfo; code: string; expiresAt: string }>('POST', `/displays/${id}/code`),
  disconnect: (id: string) => call<DisplayInfo>('POST', `/displays/${id}/disconnect`),
  remove: (id: string) => call('DELETE', `/displays/${id}`),
};

export const opsAPI = {
  shoppingList: () => call<{ businessName: string; groups: ShoppingGroup[] }>('GET', `/ops/shopping-list?lang=${currentLanguage()}`),
  shoppingSent: (supplier: string, lines: number, via: 'whatsapp' | 'copy') => call('POST', '/ops/shopping-list/sent', { supplier, lines, via }),
  setReorder: (variantId: string, data: { minStock?: number | null; reorderQty?: number | null; purchaseUnit?: string | null; preferredSupplierId?: string | null }) => call('PUT', `/ops/reorder/${variantId}`, data),
  setIngredients: (productId: string, ingredients: string[]) => call<{ id: string; ingredients: string[] }>('PUT', `/ops/products/${productId}/ingredients`, { ingredients }),
  correctPayments: (saleId: string, payments: PaymentPart[], reason: string) => call('PUT', `/ops/sales/${saleId}/payments`, { payments, reason }),
  closingTicket: (sessionId: string) => call<ClosingTicket>('GET', `/ops/close-report/${sessionId}/ticket`),
  closeReport: (sessionId: string) => call<{ report: CloseReport; text: string; ownerWhatsapp: string; enabled: boolean }>('GET', `/ops/close-report/${sessionId}?lang=${currentLanguage()}`),
};

export const staffAPI = {
  list: () => call<Employee[]>('GET', '/staff'),
  create: (data: Partial<Employee>) => call<Employee>('POST', '/staff', data),
  update: (id: string, data: Partial<Employee>) => call<Employee>('PUT', `/staff/${id}`, data),
  myShift: () => call<{ employeeId: string | null; open: Shift | null }>('GET', '/staff/me/shift'),
  myClockIn: () => call<Shift>('POST', '/staff/me/clock-in'),
  myClockOut: () => call<Shift>('POST', '/staff/me/clock-out'),
  clockIn: (id: string) => call<Shift>('POST', `/staff/${id}/clock-in`),
  clockOut: (id: string) => call<Shift>('POST', `/staff/${id}/clock-out`),
  shifts: (from: string, to: string, employeeId?: string) => call<Shift[]>('GET', `/staff/shifts/list?${qs({ from, to, employeeId })}`),
  saveShift: (id: string | null, data: { employeeId?: string; startAt?: string; endAt?: string | null }) => (id ? call<Shift>('PUT', `/staff/shifts/${id}`, data) : call<Shift>('POST', '/staff/shifts', data)),
  deleteShift: (id: string) => call('DELETE', `/staff/shifts/${id}`),
  movements: (from: string, to: string) => call<StaffMovement[]>('GET', `/staff/movements/list?${qs({ from, to })}`),
  addMovement: (data: { employeeId: string; type: 'ADVANCE' | 'DEDUCTION'; amount: number; reason?: string }) => call<StaffMovement>('POST', '/staff/movements', data),
  deleteMovement: (id: string) => call('DELETE', `/staff/movements/${id}`),
  payrollPreview: (from: string, to: string) => call<PayrollRow[]>('GET', `/staff/payroll/preview?${qs({ from, to })}`),
  payrolls: () => call<Payroll[]>('GET', '/staff/payroll/list'),
  createPayroll: (employeeId: string, from: string, to: string) => call<Payroll>('POST', '/staff/payroll', { employeeId, from, to }),
  payPayroll: (id: string, asExpense: boolean) => call<Payroll>('POST', `/staff/payroll/${id}/pay`, { asExpense }),
  deletePayroll: (id: string) => call('DELETE', `/staff/payroll/${id}`),
  tipPreview: (from: string, to: string, cashSessionId?: string | null) => call<TipPreview>('GET', `/staff/tips/preview?${qs({ from, to, cashSessionId })}`),
  tipSplits: () => call<TipSplit[]>('GET', '/staff/tips/list'),
  confirmTips: (data: { from: string; to: string; periodType: string; cashSessionId?: string | null; shares: { employeeId: string; amount: number }[] }) => call<TipSplit>('POST', '/staff/tips', data),
  payTips: (id: string) => call<TipSplit>('POST', `/staff/tips/${id}/pay`),
  deleteTipSplit: (id: string) => call('DELETE', `/staff/tips/${id}`),
};

// ── Fase 4 · En el local: pantalla del cliente, asistencia y kiosco ──
export interface CustomerCartPayload {
  label: string | null;
  paid: number;
  lines: { name: string; qty: number; unitPrice: number; note: string | null; badge: string | null }[];
}
export const customerDisplayAPI = {
  list: () => call<{ id: string; name: string; connected: boolean }[]>('GET', '/displays/customer'),
  publish: (displayId: string, cart: CustomerCartPayload | null) => call<{ ok: boolean }>('PUT', '/displays/customer-cart', { displayId, cart: cart || { lines: [] } }),
};

export interface RosterEntry { id: string; name: string; position: StaffGroup; onShift: boolean; since: string | null }
export interface PunchResult { action: 'IN' | 'OUT'; name: string; at: string; startAt: string }
export interface ScheduleSlot { id?: string; employeeId?: string; weekday: number; start: string; end: string }
export interface AttendanceRow { employeeId: string; name: string; scheduledMin: number; workedMin: number; absences: number; lateCount: number; lateMin: number }
export interface AttendanceReport { from: string; to: string; rows: AttendanceRow[]; late: { employeeId: string; scheduledAt: string; arrivedAt: string; minutesLate: number }[] }
export const attendanceAPI = {
  roster: () => call<RosterEntry[]>('GET', '/attendance/roster'),
  punch: (employeeId: string, pin: string) => call<PunchResult>('POST', '/attendance/punch', { employeeId, pin }),
  setPin: (employeeId: string, pin: string | null) => call<{ employeeId: string; hasPin: boolean }>('PUT', `/staff/${employeeId}/pin`, { pin }),
  schedule: () => call<ScheduleSlot[]>('GET', '/staff/schedule/all'),
  setSchedule: (employeeId: string, slots: ScheduleSlot[]) => call<ScheduleSlot[]>('PUT', `/staff/${employeeId}/schedule`, { slots }),
  report: (from: string, to: string) => call<AttendanceReport>('GET', `/staff/attendance/report?${qs({ from, to })}`),
};

// ── Fase 4 · Clientes en la mesa y en la puerta ──
export interface AcceptedTableOrder {
  id: string; status: 'ACCEPTED'; orderId: string; tableId: string; tableNumber: string; roundNumber: number;
  items: { productId: string | null; productName: string; variantName: string; quantity: number; unitPrice: number; notes: string | null }[];
}
export interface TableQrSheet {
  enabled: boolean; published: boolean; slug: string | null; businessName: string;
  tables: { id: string; number: string; zone: string | null; label: string; url: string | null }[];
}
export const tableOrdersAPI = {
  list: () => call<TableRequest[]>('GET', '/table-orders'),
  accept: (id: string) => call<AcceptedTableOrder>('POST', `/table-orders/${id}/accept`, {}),
  reject: (id: string, reason?: string) => call<{ id: string; status: 'REJECTED' }>('POST', `/table-orders/${id}/reject`, { reason }),
  qr: () => call<TableQrSheet>('GET', '/table-orders/qr'),
  rotate: (tableId: string) => call<TableQrSheet>('POST', `/table-orders/qr/${tableId}/rotate`, {}),
};

export type CapacityLevel = 'none' | 'ok' | 'warn' | 'full';
export interface DoorState {
  nightFrom: string; capacity: number | null; warnPct: number; occupancy: number; level: CapacityLevel;
  entries: number; exits: number; coversSold: number; peak: number;
  recent: { id: string; kind: 'IN' | 'OUT'; wristband: string | null; at: string; by: string | null }[];
}
export interface DoorReport {
  from: string; to: string; capacity: number | null; coversSold: number; entries: number; doorEntries: number; exits: number;
  peak: number; peakAt: string | null; peakPct: number | null;
}
export const doorAPI = {
  state: () => call<DoorState>('GET', '/door'),
  mark: (kind: 'IN' | 'OUT', wristband?: string) => call<{ event: { id: string; kind: string; wristband: string | null }; state: DoorState }>('POST', '/door/events', { kind, wristband: wristband || undefined }),
  report: (date?: string) => call<DoorReport>('GET', `/door/report${date ? `?${qs({ date })}` : ''}`),
};

// ── Motor de menú y Autopilot (bloque 4) ──
export type AutopilotSituation = Situation & { id: string; firstSeenAt: string; ownerNotified: boolean };
export interface AutopilotAction { id: string; kind: Intervention['kind']; params: Record<string, any>; status: 'DONE' | 'REVERTED' | 'FAILED'; source: 'LOCAL' | 'OWNER'; decidedBy: string | null; revertAt: string | null; createdAt: string; result: any }
export interface AutopilotState { enabled: boolean; learning: { historyDays: number; minDays: number } | null; situations: AutopilotSituation[]; actions: AutopilotAction[] }
export interface AutopilotKnowledge {
  builtAt: string; historyDays: number; ready: boolean; minDays: number; firstSaleAt: string | null;
  prepAll: { median: number; p80: number } | null; capacity30: number | null;
  todayByHour: { hour: number; sales: number }[]; fastest: { name: string; minutes: number }[]; slowest: { name: string; minutes: number }[];
}

export const menuAPI = {
  reading: (fresh = false) => call<MenuReading>('GET', `/menu${fresh ? '?fresh=1' : ''}`),
  suggestions: (cart: string[]) => call<{ suggestions: Suggestion[] }>('POST', '/menu/suggestions', { cart }),
  event: (productId: string, reason: string, accepted: boolean) => call('POST', '/menu/suggestions/event', { productId, reason, accepted }),
};

export const autopilotAPI = {
  state: () => call<AutopilotState>('GET', '/autopilot'),
  knowledge: () => call<AutopilotKnowledge>('GET', '/autopilot/knowledge'),
  tick: () => call('POST', '/autopilot/tick'),
  decide: (situationId: string, interventionId: string, params: Record<string, any>) => call<{ action: { id: string; kind: string; params: any; result: any; revertAt: string | null } }>('POST', `/autopilot/situations/${situationId}/decide`, { interventionId, params }),
  dismiss: (situationId: string) => call('POST', `/autopilot/situations/${situationId}/dismiss`),
  revert: (actionId: string) => call('POST', `/autopilot/actions/${actionId}/revert`),
};

// ── Ingredientes y recetas ──
export interface Ingredient {
  id: string; name: string; unit: 'g' | 'ml' | 'und'; stock: number; avgCost: number; lastCost: number | null; minStock: number | null;
  category: string | null; preferredSupplierId: string | null; low: boolean; usedIn: number;
}
export interface IngredientMovement { id: string; type: string; quantity: number; previousStock: number; newStock: number; unitCost: number | null; reference: string | null; notes: string | null; createdBy: string | null; createdAt: string }
export interface RecipeView { productId: string; name: string; items: { ingredientId: string; name: string; unit: string; quantity: number; removable: boolean; avgCost: number; lineCost: number }[]; cost: number; price: number; margin: number | null; minMarginPct: number }

export const ingredientsAPI = {
  list: () => call<Ingredient[]>('GET', '/ingredients'),
  save: (id: string | null, data: Partial<Ingredient> & { stock?: number }) => (id ? call<Ingredient>('PUT', `/ingredients/${id}`, data) : call<Ingredient>('POST', '/ingredients', data)),
  remove: (id: string) => call('DELETE', `/ingredients/${id}`),
  movements: (id: string) => call<IngredientMovement[]>('GET', `/ingredients/${id}/movements`),
  adjust: (id: string, data: { type: 'ADJUSTMENT' | 'WASTE' | 'COUNT'; quantity: number; notes?: string }) => call<Ingredient>('POST', `/ingredients/${id}/adjust`, data),
};

export const recipesAPI = {
  get: (productId: string) => call<RecipeView>('GET', `/recipes/${productId}`),
  set: (productId: string, items: { ingredientId: string; quantity: number; removable: boolean }[]) => call<RecipeView>('PUT', `/recipes/${productId}`, { items }),
  costs: () => call<{ minMarginPct: number; products: { productId: string; name: string; cost: number; price: number; margin: number | null; low: boolean }[] }>('GET', '/recipes/costs'),
};

// ── Fase 4 · Precios por horario y encuesta ──

export const priceRulesAPI = {
  list: () => call<PriceRule[]>('GET', '/price-rules'),
  active: () => call<{ enabled: boolean; rules: PriceRule[]; activeIds: string[]; now: string }>('GET', '/price-rules/active'),
  create: (rule: Omit<PriceRule, 'id'>) => call<PriceRule>('POST', '/price-rules', rule),
  update: (id: string, rule: Omit<PriceRule, 'id'>) => call<PriceRule>('PUT', `/price-rules/${encodeURIComponent(id)}`, rule),
  remove: (id: string) => call<{ ok: boolean }>('DELETE', `/price-rules/${encodeURIComponent(id)}`),
};

export const surveysAPI = {
  summary: () => call<SurveySummary & { enabled: boolean }>('GET', '/surveys/summary'),
};

// ── Fase 4 · Transferencias confirmadas con el aviso del banco ──
export type BankApp = 'NEQUI' | 'DAVIPLATA' | 'BANCOLOMBIA' | 'BREB';
export interface IncomingTransfer { id: string; app: BankApp; amount: number; sender: string | null; postedAt: string; receivedAt: string; matched: boolean }
export interface ExpectedTransfer { id: string; amount?: number; status: 'WAITING' | 'CONFIRMED' | 'EXPIRED'; expiresAt?: string; transfer: IncomingTransfer | null }
export interface BankNotice { ref: string; app: BankApp; amount: number; sender: string | null; postedAt: number }
export const transfersAPI = {
  /** Lo envía el celular del negocio (ADMIN o CASHIER) */
  incoming: (notice: BankNotice) => call<{ transfer: IncomingTransfer; matched: boolean; duplicate: boolean }>('POST', '/payments/incoming', notice),
  recent: () => call<IncomingTransfer[]>('GET', '/payments/incoming'),
  expect: (amount: number) => call<ExpectedTransfer>('POST', '/payments/expect', { amount }),
  status: (id: string) => call<ExpectedTransfer>('GET', `/payments/expect/${id}`),
  close: (id: string, keep: boolean) => call<{ ok: true }>('POST', `/payments/expect/${id}/close`, { keep }),
};

// ── Fase 4 · Grupo E: gestión ────────────────────────────────
import type { AccountingAccounts, AccountingSale, Voucher } from '../../../src/domain/accountingExport';
import type { MenuExport, MenuPlan } from '../../../src/domain/menuTransfer';

export interface AccountingMonth {
  month: string;
  accounts: AccountingAccounts;
  sales: AccountingSale[];
  vouchers: Voucher[];
  balanced: boolean;
  sessions: { sessionNumber: string; openedAt: string; closedAt: string | null; initialBalance: number; income: number; expenses: number; expectedBalance: number | null; finalBalance: number | null; difference: number | null; status: string; closedByName: string | null }[];
  expenses: { createdAt: string; amount: number; motive: string; paymentSource: string; supplierName: string | null; supplierNit: string | null; invoiceNumber: string | null; subtotal: number | null; taxAmount: number | null; category: string | null }[];
  invoices: { invoiceNumber: string; issueDate: string; customerName: string; customerNit: string; subtotal: number; tax: number; total: number; status: string }[];
}

export const gestionAPI = {
  accountingMonth: (month: string) => call<AccountingMonth>('GET', `/accounting/month?${qs({ month })}`),
  exportMenu: () => call<MenuExport>('GET', '/menu-transfer/export'),
  previewMenu: (file: unknown) => call<MenuPlan>('POST', '/menu-transfer/preview', file),
  importMenu: (file: unknown) => call<MenuPlan>('POST', '/menu-transfer/import', file),
};
