// ============================================
// SERVICES - Arma los tickets (recibo, pre-cuenta, comanda, prueba)
// ============================================
// Devuelve un TicketDoc: el mismo documento se ve en pantalla, sale por el diálogo
// del navegador o va directo a la impresora térmica (ESC/POS). Los tickets se
// imprimen en el idioma configurado para el negocio, no en el de cada pantalla.

import i18next from '../i18n';
import { formatCurrency } from '../shared/formatUtils';
import type { BusinessSettings } from './api';
import type { TicketBlock, TicketDoc } from '../../../src/domain/ticketDoc';
import type { PrintSettings } from '../../../src/domain/printSettings';
import type { MonoBitmap } from '../shared/media';

type Tt = (key: string, opts?: Record<string, unknown>) => string;

export const ticketT = (settings: Pick<PrintSettings, 'language'>) => {
  const lang = settings.language === 'en' ? 'en' : 'es';
  return { tt: i18next.getFixedT(lang, 'ticket') as Tt, locale: lang === 'en' ? 'en-US' : 'es-CO' };
};

export interface TicketContext {
  settings: PrintSettings;
  business: Partial<BusinessSettings> | null;
  /** Logo ya convertido a blanco y negro (si el negocio tiene y se quiere imprimir) */
  logo?: MonoBitmap | null;
}

const money = (v: unknown) => formatCurrency(Number(v) || 0);

const regimeLabel = (tt: Tt, regime?: string | null) =>
  regime === 'RESPONSABLE_IVA' ? tt('regimen_iva') : regime === 'RESPONSABLE_INC' ? tt('regimen_inc') : regime === 'NO_RESPONSABLE' ? tt('regimen_no_responsable') : null;

const methodLabel = (tt: Tt, m: string) =>
  m === 'CASH' ? tt('efectivo') : m === 'CARD' ? tt('tarjeta') : m === 'TRANSFER' ? tt('transferencia') : tt('mixto');

/** Encabezado del negocio: logo, nombre, NIT y régimen, dirección y teléfono */
const header = (ctx: TicketContext, tt: Tt): TicketBlock[] => {
  const b = ctx.business || {};
  const blocks: TicketBlock[] = [];
  if (ctx.logo && ctx.settings.showLogo) {
    blocks.push({ t: 'image', width: ctx.logo.width, height: ctx.logo.height, bits: ctx.logo.bits, src: ctx.logo.src, align: 'center' }, { t: 'feed' });
  }
  blocks.push({ t: 'text', text: (b.businessName || 'Lantify POS').toUpperCase(), align: 'center', bold: true, size: 2 });
  if (b.legalName && b.legalName.trim().toLowerCase() !== (b.businessName || '').trim().toLowerCase()) {
    blocks.push({ t: 'text', text: b.legalName, align: 'center' });
  }
  if (b.nit) blocks.push({ t: 'text', text: `NIT ${b.nit}${b.dv ? `-${b.dv}` : ''}`, align: 'center', bold: true });
  const regime = regimeLabel(tt, b.taxRegime);
  if (regime && b.nit) blocks.push({ t: 'text', text: regime, align: 'center', small: true });
  const address = [b.address, b.city].filter(Boolean).join(', ');
  if (address) blocks.push({ t: 'text', text: address, align: 'center' });
  if (b.phone) blocks.push({ t: 'text', text: `${tt('tel')}: ${b.phone}`, align: 'center' });
  return blocks;
};

/** Pie: mensaje del negocio y, en pequeño, el software con que se hizo */
const footer = (ctx: TicketContext, tt: Tt): TicketBlock[] => [
  { t: 'feed' },
  { t: 'text', text: ctx.settings.footer || tt('gracias'), align: 'center', bold: true },
  { t: 'feed' },
  { t: 'text', text: tt('software'), align: 'center', small: true },
];

export interface ReceiptData {
  kind?: 'receipt' | 'prebill';
  /** Reimpresión desde el historial */
  copy?: boolean;
  saleNumber?: string;
  date?: string | Date;
  cashierName?: string | null;
  tableNumber?: string | null;
  items: any[];
  subtotal: number;
  total: number;
  taxLines?: { taxType: string; taxRate: number; amount: number }[];
  discountPct?: number;
  discountAmount?: number;
  tip?: number;
  suggestedTip?: number;
  tipPercent?: number;
  customer?: { name?: string; nit?: string | null; phone?: string | null; isDefault?: boolean } | null;
  payments?: { method: string; amount: number }[];
  paymentMethod?: string;
  change?: number;
  loyaltyInfo?: any;
  /** QR de sellos ya convertido para la impresora */
  claimQr?: MonoBitmap | null;
}

export const buildReceiptDoc = (data: ReceiptData, ctx: TicketContext): TicketDoc => {
  const { tt, locale } = ticketT(ctx.settings);
  const isPreBill = data.kind === 'prebill';
  const blocks: TicketBlock[] = [...header(ctx, tt), { t: 'rule' }];

  blocks.push({ t: 'text', text: isPreBill ? tt('precuenta').toUpperCase() : tt('recibo_de_venta'), align: 'center', bold: true });
  if (isPreBill) blocks.push({ t: 'text', text: tt('no_valida_como_factura'), align: 'center', small: true });
  if (data.copy) blocks.push({ t: 'text', text: tt('copia'), align: 'center', bold: true, invert: true });
  blocks.push({ t: 'feed' });
  if (data.saleNumber) blocks.push({ t: 'row', left: tt('recibo_n'), right: data.saleNumber, bold: true });
  const when = data.date ? new Date(data.date) : new Date();
  blocks.push({ t: 'row', left: tt('fecha'), right: when.toLocaleString(locale, { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }) });
  blocks.push({ t: 'row', left: tt('lugar'), right: data.tableNumber || tt('mostrador') });
  if (data.cashierName) blocks.push({ t: 'row', left: tt('atendio'), right: data.cashierName });

  const c = data.customer;
  if (c && !c.isDefault && c.name) {
    blocks.push({ t: 'rule' });
    blocks.push({ t: 'row', left: tt('cliente'), right: c.name });
    if (c.nit) blocks.push({ t: 'row', left: tt('nit_cc'), right: c.nit });
    if (c.phone) blocks.push({ t: 'row', left: tt('tel'), right: c.phone });
  }

  blocks.push({ t: 'rule' });
  let units = 0;
  for (const item of data.items) {
    if (item.isCancelled) continue;
    const qty = Number(item.quantity) || 1;
    units += qty;
    const name = item.productName || item.productVariant?.product?.name || tt('producto');
    const variant = item.variantName || item.productVariant?.name || '';
    const unit = Number(item.unitPrice) || 0;
    const total = item.total ?? item.subtotal ?? unit * qty;
    blocks.push({ t: 'row', left: `${qty}x ${name}`, right: money(total), bold: true });
    const detail = [variant && !/^(normal|única|unica|single)$/i.test(variant) ? variant : '', qty > 1 ? tt('precio_unitario', { qty, price: money(unit) }) : '']
      .filter(Boolean)
      .join(' · ');
    if (detail) blocks.push({ t: 'text', text: `  ${detail}`, small: true });
  }
  blocks.push({ t: 'text', text: tt('items_n', { count: units }), align: 'right', small: true });
  blocks.push({ t: 'rule' });

  blocks.push({ t: 'row', left: tt('subtotal'), right: money(data.subtotal) });
  if ((data.discountAmount || 0) > 0) blocks.push({ t: 'row', left: tt('descuento_pct', { pct: data.discountPct || 0 }), right: `-${money(data.discountAmount)}` });
  blocks.push({ t: 'row', left: tt('total'), right: money(data.total), bold: true, size: 2 });
  for (const l of (data.taxLines || []).filter((x) => x.amount > 0)) {
    const label = `${l.taxType === 'IVA' ? tt('iva') : tt('inc')} ${l.taxRate}%`;
    blocks.push({ t: 'row', left: tt('incluye_impuesto', { tax: label }), right: money(l.amount), small: true });
  }

  if (isPreBill && (data.suggestedTip || 0) > 0) {
    blocks.push({ t: 'rule' });
    blocks.push({ t: 'row', left: tt('propina_sugerida_pct', { pct: data.tipPercent || 0 }), right: money(data.suggestedTip) });
    blocks.push({ t: 'row', left: tt('total_con_propina'), right: money(data.total + (data.suggestedTip || 0)), bold: true });
    blocks.push({ t: 'text', text: tt('propina_es_voluntaria'), align: 'center', small: true });
  }

  if (!isPreBill) {
    const payments = data.payments?.length ? data.payments : data.paymentMethod ? [{ method: data.paymentMethod, amount: data.total }] : [];
    if (payments.length) {
      blocks.push({ t: 'rule' });
      blocks.push({ t: 'text', text: tt('pago_realizado'), bold: true });
      for (const p of payments) blocks.push({ t: 'row', left: methodLabel(tt, p.method), right: money(p.amount) });
      if ((data.tip || 0) > 0) blocks.push({ t: 'row', left: tt('propina_voluntaria'), right: money(data.tip) });
      if ((data.change || 0) > 0) blocks.push({ t: 'row', left: tt('cambio_devuelto'), right: money(data.change), bold: true });
    }
  }

  const loyalty = data.loyaltyInfo;
  if (!isPreBill && loyalty?.eligible && loyalty.customer) {
    const required = loyalty.stampsRequired || 10;
    blocks.push({ t: 'feed' }, {
      t: 'box',
      blocks: [
        { t: 'text', text: tt('sellos_sumados', { count: loyalty.stamps }).toUpperCase(), align: 'center', bold: true },
        { t: 'text', text: tt('sellos_lleva', { count: Math.min(loyalty.customer.stampsCount, required), total: required }), align: 'center' },
      ],
    });
  }
  if (!isPreBill && loyalty?.eligible && loyalty.token && data.claimQr) {
    blocks.push({ t: 'feed' }, {
      t: 'box',
      blocks: [
        { t: 'text', text: tt('sellos_en_compra', { count: loyalty.stamps }).toUpperCase(), align: 'center', bold: true },
        { t: 'text', text: tt('sellos_escanea'), align: 'center', small: true },
        { t: 'image', width: data.claimQr.width, height: data.claimQr.height, bits: data.claimQr.bits, src: data.claimQr.src, align: 'center' },
        { t: 'text', text: tt('sellos_vigencia'), align: 'center', small: true },
      ],
    });
  }

  blocks.push(...footer(ctx, tt));
  const cashPaid = (data.payments || []).some((p) => p.method === 'CASH') || data.paymentMethod === 'CASH';
  return { title: `${isPreBill ? tt('precuenta') : tt('recibo')} ${data.saleNumber || data.tableNumber || ''}`.trim(), blocks, drawer: !isPreBill && !data.copy && cashPaid };
};

export interface KitchenData {
  items: any[];
  tableNumber?: string | null;
  roundNumber?: number;
  waiterName?: string | null;
}

export const buildKitchenDoc = (data: KitchenData, ctx: TicketContext): TicketDoc => {
  const { tt, locale } = ticketT(ctx.settings);
  const blocks: TicketBlock[] = [
    { t: 'text', text: tt('comanda_titulo'), align: 'center', bold: true, invert: true },
    { t: 'feed' },
    { t: 'text', text: (data.tableNumber || tt('mostrador')).toUpperCase(), align: 'center', bold: true, size: 2 },
  ];
  const meta = [data.roundNumber ? tt('ronda', { round: data.roundNumber }) : '', new Date().toLocaleTimeString(locale, { hour: '2-digit', minute: '2-digit' })].filter(Boolean).join(' · ');
  blocks.push({ t: 'text', text: meta, align: 'center', bold: true });
  if (data.waiterName) blocks.push({ t: 'text', text: `${tt('atendio')}: ${data.waiterName}`, align: 'center' });
  blocks.push({ t: 'rule', style: 'double' });
  for (const item of data.items) {
    blocks.push({ t: 'text', text: `${item.quantity} x ${item.productName}`, bold: true, size: 2 });
    if (item.variantName && !/^(normal|única|unica|single)$/i.test(item.variantName)) blocks.push({ t: 'text', text: `   ${item.variantName}`, bold: true });
    if (item.notes) blocks.push({ t: 'text', text: `${tt('nota')}: ${item.notes}`, invert: true, bold: true });
    blocks.push({ t: 'rule' });
  }
  return { title: `${tt('comanda')} ${data.tableNumber || ''}`.trim(), blocks };
};

/** Venta de ejemplo para la vista previa y la prueba de impresión */
export const sampleReceiptData = (ctx: TicketContext): ReceiptData => {
  const { tt } = ticketT(ctx.settings);
  return {
    kind: 'receipt',
    saleNumber: 'V-000123',
    tableNumber: `${tt('mesa')} 4`,
    cashierName: 'Ana',
    items: [
      { quantity: 2, productName: 'Capuchino', variantName: '12 oz', unitPrice: 7500, total: 15000 },
      { quantity: 1, productName: 'Torta de zanahoria', variantName: 'Porción', unitPrice: 9000, total: 9000 },
    ],
    subtotal: 24000,
    total: 24000,
    taxLines: [{ taxType: 'INC', taxRate: 8, amount: 1778 }],
    payments: [{ method: 'CASH', amount: 30000 }],
    change: 6000,
  };
};

/** Ticket de prueba: confirma ancho, tildes, logo y corte */
export const buildTestDoc = (ctx: TicketContext, printerName: string): TicketDoc => {
  const { tt, locale } = ticketT(ctx.settings);
  const sample = buildReceiptDoc(sampleReceiptData(ctx), ctx);
  return {
    title: tt('prueba_titulo'),
    blocks: [
      { t: 'text', text: tt('prueba_titulo'), align: 'center', bold: true, invert: true },
      { t: 'row', left: tt('prueba_impresora'), right: printerName },
      { t: 'row', left: tt('prueba_papel'), right: ctx.settings.paperWidth },
      { t: 'row', left: tt('fecha'), right: new Date().toLocaleString(locale) },
      { t: 'text', text: tt('prueba_ok'), align: 'center', small: true },
      { t: 'rule', style: 'double' },
      ...sample.blocks,
    ],
  };
};
