// ============================================
// SERVICES - Ticket en HTML (vista previa y diálogo del navegador)
// ============================================
// Dibuja el mismo TicketDoc que va a la impresora térmica, con el ancho del rollo.

import type { TicketBlock, TicketDoc } from '../../../src/domain/ticketDoc';
import { PrintSettings, dotsFor } from '../../../src/domain/printSettings';

const esc = (v: unknown) =>
  String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

const FONT_PX = { compact: 11, medium: 12.5, large: 14 } as const;

export const ticketCss = (settings: PrintSettings) => {
  const is58 = settings.paperWidth === '58mm';
  const base = FONT_PX[settings.fontSize] ?? 12.5;
  const font = settings.font === 'monospace' ? "'Courier New', ui-monospace, monospace" : "'Arial Narrow', Arial, 'Helvetica Neue', sans-serif";
  return `
    .lt-ticket { width: ${is58 ? '48mm' : '72mm'}; margin: 0 auto; font-family: ${font}; font-size: ${base}px; line-height: 1.3; color: #000; background: #fff; }
    .lt-ticket * { box-sizing: border-box; }
    .lt-t { white-space: pre-wrap; word-break: break-word; }
    .lt-row { display: flex; justify-content: space-between; align-items: baseline; gap: 8px; }
    .lt-row > span:first-child { min-width: 0; word-break: break-word; }
    .lt-row > span:last-child { white-space: nowrap; font-variant-numeric: tabular-nums; }
    .lt-center { text-align: center; }
    .lt-right { text-align: right; }
    .lt-b { font-weight: 700; }
    .lt-big { font-size: 1.55em; line-height: 1.15; font-weight: 800; }
    .lt-small { font-size: 0.82em; }
    .lt-inv { background: #000; color: #fff; padding: 1px 4px; display: inline-block; }
    .lt-inv-wrap { text-align: inherit; }
    .lt-rule { border-top: 1px dashed #000; margin: 5px 0; }
    .lt-rule.solid { border-top-style: solid; }
    .lt-rule.double { border-top: 3px double #000; }
    .lt-feed { height: 0.6em; }
    .lt-img { display: block; height: auto; image-rendering: pixelated; }
    .lt-box { border: 1px dashed #000; border-radius: 4px; padding: 5px 6px; margin: 4px 0; }
  `;
};

const block = (b: TicketBlock, dots: number): string => {
  switch (b.t) {
    case 'text': {
      const cls = ['lt-t', b.align === 'center' ? 'lt-center' : b.align === 'right' ? 'lt-right' : '', b.bold ? 'lt-b' : '', b.size === 2 ? 'lt-big' : '', b.small ? 'lt-small' : ''].filter(Boolean).join(' ');
      const text = esc(b.text);
      return `<div class="${cls}">${b.invert ? `<span class="lt-inv">${text}</span>` : text}</div>`;
    }
    case 'row': {
      const cls = ['lt-row', b.bold ? 'lt-b' : '', b.size === 2 ? 'lt-big' : '', b.small ? 'lt-small' : ''].filter(Boolean).join(' ');
      return `<div class="${cls}"><span>${esc(b.left)}</span><span>${esc(b.right)}</span></div>`;
    }
    case 'rule':
      return `<div class="lt-rule ${b.style || ''}"></div>`;
    case 'feed':
      return '<div class="lt-feed"></div>'.repeat(Math.max(1, Math.min(4, b.lines || 1)));
    case 'image': {
      if (!b.src) return '';
      const pct = Math.min(100, (b.width / dots) * 100);
      const margin = b.align === 'left' ? '0' : b.align === 'right' ? '0 0 0 auto' : '0 auto';
      return `<img class="lt-img" src="${esc(b.src)}" alt="" style="width:${pct.toFixed(1)}%;margin:${margin}" />`;
    }
    case 'box':
      return `<div class="lt-box">${b.blocks.map((x) => block(x, dots)).join('')}</div>`;
  }
};

/** Solo el ticket (para la vista previa dentro de la pantalla) */
export const renderTicketBody = (doc: TicketDoc, settings: PrintSettings) =>
  `<div class="lt-ticket">${doc.blocks.map((b) => block(b, dotsFor(settings.paperWidth))).join('')}</div>`;

/** Página completa para imprimir con el diálogo del navegador */
export const renderTicketPage = (doc: TicketDoc, settings: PrintSettings, autoPrint = true) => `<!DOCTYPE html>
<html><head><meta charset="utf-8" /><title>${esc(doc.title)}</title>
<style>
  @page { size: ${settings.paperWidth} auto; margin: ${settings.margin}; }
  html, body { margin: 0; padding: 0; background: #fff; }
  * { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  ${ticketCss(settings)}
</style></head>
<body>${renderTicketBody(doc, settings)}
${autoPrint ? '<script>window.onload = function () { setTimeout(function () { window.focus(); window.print(); }, 250); };</script>' : ''}
</body></html>`;
