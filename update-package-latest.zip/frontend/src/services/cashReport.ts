// ============================================
// SERVICES - Informes de caja: mes, arqueo, gastos y movimientos
// ============================================
// Regla de todos: el cajón solo recibe efectivo. Tarjeta y transferencias son
// ventas pero no entran al cajón; los gastos pagados por banco no salen de él.
// Cada arqueo se cuadra por separado: esperado = base + ventas en efectivo +
// entradas − salidas; diferencia = contado − esperado.

import { API_URL } from '../config';
import { getLocale, t } from '../i18n';
import { int, money, moneyText, pct, ReportCell, ReportDoc, ReportTable } from './reportDocument';
import { cancelledTable, detailTables, fetchAllSales, methodLabel, methodsTable, paidBy, productsTable } from './salesReport';

export interface CashMonthStats {
  sessions: any[];
  completedSales: any[];
  salesTotal: number;
  salesCash: number;
  salesCard: number;
  salesTransfer: number;
  manualIncome: number;
  manualExpense: number;
  allIncomes: any[];
  allExpenses: any[];
}

const fromDrawer = (e: any) => (e.paymentSource ?? 'CASH_DRAWER') === 'CASH_DRAWER';
const when = (d: string | Date) => new Date(d).toLocaleString(getLocale(), { dateStyle: 'short', timeStyle: 'short' });
const sumBy = <T,>(list: T[], f: (x: T) => number) => list.reduce((n, x) => n + (f(x) || 0), 0);

/** Cuadre de un arqueo con sus ventas completadas */
export const balanceOf = (sess: any, completed: any[]) => {
  const sales = completed.filter((s) => s.cashSessionId === sess.id);
  const cashSales = sumBy(sales, (s) => paidBy(s, 'CASH'));
  const income = sumBy((sess.incomesDetails || []).filter((x: any) => !x.isCancelled), (x: any) => x.amount);
  const out = sumBy((sess.expensesDetails || []).filter((x: any) => !x.isCancelled && fromDrawer(x)), (x: any) => x.amount);
  const expected = sess.expectedBalance ?? (sess.initialBalance || 0) + cashSales + income - out;
  const counted: number | null = sess.status === 'CLOSED' ? sess.finalBalance ?? null : null;
  const diff: number | null = counted === null ? null : sess.difference ?? counted - expected;
  return { sales, salesTotal: sumBy(sales, (s) => s.total), cashSales, income, out, expected, counted, diff };
};

const movementsTable = (incomes: any[], expenses: any[], title = t('reports:movimientos')): ReportTable => {
  const list = [...incomes.map((x) => ({ ...x, kind: 'IN' })), ...expenses.map((x) => ({ ...x, kind: 'OUT' }))].sort(
    (a, b) => +new Date(a.createdAt) - +new Date(b.createdAt),
  );
  const active = list.filter((x) => !x.isCancelled);
  return {
    title,
    sheet: t('reports:hoja_movimientos'),
    note: t('reports:movimientos_nota'),
    columns: [{ label: t('reports:col_fecha'), width: 1.2 }, { label: t('reports:col_arqueo') }, { label: t('reports:col_tipo'), width: 1.2 }, { label: t('reports:col_categoria') }, { label: t('reports:col_concepto'), width: 2.2 }, { label: t('reports:col_valor'), align: 'right' }, { label: t('reports:col_estado') }],
    rows: list.map((x) => [
      when(x.createdAt),
      x.sessionNumber || '—',
      x.kind === 'IN' ? t('reports:entrada') : fromDrawer(x) ? t('reports:salida') : t('reports:gasto_banco'),
      x.category?.name || '—',
      [x.motive, x.description].filter(Boolean).join(' — '),
      money(x.kind === 'IN' ? x.amount : -x.amount),
      x.isCancelled ? `${t('reports:anulado')}${x.cancellationReason ? `: ${x.cancellationReason}` : ''}` : t('reports:valido'),
    ]),
    totals: ['', '', '', '', t('reports:neto_valido'), money(sumBy(active, (x) => (x.kind === 'IN' ? x.amount : -x.amount))), ''],
    empty: t('reports:sin_movimientos'),
  };
};

const categoriesTable = (expenses: any[], note?: string): ReportTable => {
  const byCat = new Map<string, { count: number; amount: number }>();
  for (const e of expenses.filter((x) => !x.isCancelled)) {
    const k = e.category?.name || t('reports:sin_categoria');
    const v = byCat.get(k) || { count: 0, amount: 0 };
    v.count++;
    v.amount += e.amount || 0;
    byCat.set(k, v);
  }
  const total = sumBy([...byCat.values()], (v) => v.amount);
  return {
    title: t('reports:gastos_categoria'),
    sheet: t('reports:hoja_categorias'),
    note,
    columns: [{ label: t('reports:col_categoria'), width: 2 }, { label: t('reports:col_cantidad'), align: 'right' }, { label: t('reports:col_valor'), align: 'right' }, { label: t('reports:col_participacion'), align: 'right' }],
    rows: [...byCat.entries()].sort((a, b) => b[1].amount - a[1].amount).map(([k, v]) => [k, int(v.count), money(v.amount), pct(v.amount, total)]),
    totals: [t('reports:total'), int(sumBy([...byCat.values()], (v) => v.count)), money(total), pct(total, total)],
    empty: t('reports:sin_gastos'),
  };
};

const bankNote = (expenses: any[]) => {
  const bank = expenses.filter((e) => !e.isCancelled && !fromDrawer(e));
  return bank.length ? t('reports:gastos_banco_nota', { amount: moneyText(sumBy(bank, (e) => e.amount)) }) : undefined;
};

// ── Informe mensual ───────────────────────────────────────────

export const buildCashReport = (stats: CashMonthStats, periodLabel: string): ReportDoc => {
  const rows = stats.sessions
    .slice()
    .sort((a, b) => +new Date(a.openedAt) - +new Date(b.openedAt))
    .map((sess) => ({ sess, ...balanceOf(sess, stats.completedSales) }));
  const closed = rows.filter((r) => r.diff !== null);
  const diffTotal = sumBy(closed, (r) => r.diff || 0);
  const unbalanced = closed.filter((r) => Math.abs(r.diff || 0) >= 1);

  return {
    title: t('reports:caja_titulo'),
    period: periodLabel,
    kpis: [
      { label: t('reports:ventas_netas'), value: money(stats.salesTotal), hint: t('reports:ventas_en_arqueos', { count: stats.completedSales.length }), tone: 'good' },
      { label: t('reports:efectivo_recibido'), value: money(stats.salesCash), hint: t('reports:del_total', { pct: stats.salesTotal ? Math.round((stats.salesCash / stats.salesTotal) * 100) : 0 }) },
      { label: t('reports:otros_medios'), value: money(stats.salesTotal - stats.salesCash), hint: t('reports:otros_medios_hint') },
      { label: t('reports:entradas_cajon'), value: money(stats.manualIncome), hint: t('reports:entradas_cajon_hint') },
      { label: t('reports:salidas_cajon'), value: money(stats.manualExpense), hint: t('reports:salidas_cajon_hint') },
      {
        label: t('reports:descuadre'),
        value: money(diffTotal),
        hint: closed.length ? t('reports:descuadre_hint', { bad: unbalanced.length, count: closed.length }) : t('reports:sin_cierres'),
        tone: unbalanced.length ? 'bad' : 'good',
      },
    ],
    tables: [
      {
        title: t('reports:arqueos'),
        sheet: t('reports:hoja_arqueos'),
        note: t('reports:arqueos_nota'),
        columns: [
          { label: t('reports:col_arqueo') }, { label: t('reports:col_apertura'), width: 1.3 }, { label: t('reports:col_base'), align: 'right' },
          { label: t('reports:col_ventas_efectivo'), align: 'right' }, { label: t('reports:col_entradas'), align: 'right' }, { label: t('reports:col_salidas'), align: 'right' },
          { label: t('reports:col_esperado'), align: 'right' }, { label: t('reports:col_contado'), align: 'right' }, { label: t('reports:col_diferencia'), align: 'right' },
        ],
        rows: rows.map((r) => [
          r.sess.sessionNumber,
          when(r.sess.openedAt),
          money(r.sess.initialBalance),
          money(r.cashSales),
          money(r.income),
          money(r.out),
          money(r.expected),
          r.counted === null ? t('reports:abierto') : money(r.counted),
          r.diff === null ? '—' : money(r.diff),
        ]),
        totals: ['', t('reports:total'), '', money(sumBy(rows, (r) => r.cashSales)), money(stats.manualIncome), money(stats.manualExpense), '', '', money(diffTotal)],
      },
      methodsTable(stats.completedSales),
      categoriesTable(stats.allExpenses, bankNote(stats.allExpenses)),
      movementsTable(stats.allIncomes, stats.allExpenses, t('reports:movimientos')),
    ],
    notes: [t('reports:nota_caja_esperado'), t('reports:nota_caja_mixtos')],
  };
};

// ── Informe de un arqueo ──────────────────────────────────────

/** Trae el arqueo con sus movimientos y todas sus ventas */
export const loadSessionReport = async (sessionId: string): Promise<ReportDoc> => {
  const res = await fetch(`${API_URL}/cash-sessions`, { headers: { Authorization: `Bearer ${localStorage.getItem('token') || ''}` } });
  if (!res.ok) throw new Error(t('reports:no_se_cargaron'));
  const sess = ((await res.json()) as any[]).find((s) => s.id === sessionId);
  if (!sess) throw new Error(t('reports:no_se_cargaron'));
  return buildSessionReport(sess, await fetchAllSales({ year: 0, month: 0, cashSessionId: sessionId }));
};

export const buildSessionReport = (sess: any, sales: any[]): ReportDoc => {
  const done = sales.filter((s) => s.status === 'COMPLETED');
  const cancelled = sales.filter((s) => s.status === 'CANCELLED');
  const b = balanceOf(sess, done);
  const incomes = (sess.incomesDetails || []).map((x: any) => ({ ...x, sessionNumber: sess.sessionNumber }));
  const expenses = (sess.expensesDetails || []).map((x: any) => ({ ...x, sessionNumber: sess.sessionNumber }));
  const tips = sumBy(done, (s) => s.tip);
  const opened = when(sess.openedAt);
  const period = sess.closedAt ? `${opened} → ${when(sess.closedAt)}` : `${opened} · ${t('reports:abierto')}`;
  const diffTone = b.diff === null ? 'neutral' : Math.abs(b.diff) < 1 ? 'good' : 'bad';

  const cuadre: ReportCell[][] = [
    [t('reports:cuadre_base'), money(sess.initialBalance)],
    [t('reports:cuadre_ventas_efectivo'), money(b.cashSales)],
    [t('reports:cuadre_entradas'), money(b.income)],
    [t('reports:cuadre_salidas'), money(-b.out)],
    [t('reports:cuadre_esperado'), money(b.expected)],
    [t('reports:cuadre_contado'), b.counted === null ? t('reports:sin_contar') : money(b.counted)],
  ];

  return {
    title: t('reports:arqueo_titulo', { n: sess.sessionNumber }),
    period,
    kpis: [
      { label: t('reports:ventas_netas'), value: money(b.salesTotal), hint: t('reports:num_ventas_hint_arqueo', { count: done.length }), tone: 'good' },
      { label: t('reports:efectivo_recibido'), value: money(b.cashSales), hint: t('reports:entra_al_cajon') },
      { label: t('reports:otros_medios'), value: money(b.salesTotal - b.cashSales), hint: t('reports:otros_medios_hint') },
      { label: t('reports:propinas'), value: money(tips), hint: t('reports:propinas_hint') },
      { label: t('reports:cuadre_esperado'), value: money(b.expected), hint: t('reports:esperado_hint') },
      {
        label: t('reports:col_diferencia'),
        value: b.diff === null ? t('reports:abierto') : money(b.diff),
        hint: b.diff === null ? t('reports:sin_contar') : Math.abs(b.diff) < 1 ? t('reports:cuadro_bien') : b.diff > 0 ? t('reports:sobro') : t('reports:falto'),
        tone: diffTone,
      },
    ],
    tables: [
      {
        title: t('reports:cuadre_titulo'),
        sheet: t('reports:hoja_cuadre'),
        note: sess.notes ? `${t('reports:notas_cierre')}: ${sess.notes}` : undefined,
        columns: [{ label: t('reports:col_concepto'), width: 3 }, { label: t('reports:col_valor'), align: 'right' }],
        rows: cuadre,
        totals: [t('reports:col_diferencia'), b.diff === null ? '—' : money(b.diff)],
      },
      methodsTable(done),
      productsTable(done),
      movementsTable(incomes, expenses, t('reports:movimientos_arqueo')),
      categoriesTable(expenses, bankNote(expenses)),
      cancelledTable(cancelled),
      ...detailTables(sales, done),
    ],
    notes: [t('reports:nota_caja_mixtos'), t('reports:nota_propinas')],
  };
};

// ── Gastos (con los filtros de la pestaña) ────────────────────

export const buildExpensesReport = (expenses: any[], periodLabel: string, scope?: string): ReportDoc => {
  const active = expenses.filter((e) => !e.isCancelled);
  const total = sumBy(active, (e) => e.amount);
  const drawer = sumBy(active.filter(fromDrawer), (e) => e.amount);
  const byCat = categoriesTable(expenses);
  const top = byCat.rows[0];
  return {
    title: t('reports:gastos_titulo'),
    period: periodLabel,
    scope,
    kpis: [
      { label: t('reports:total_gastos'), value: money(total), hint: t('reports:gastos_n', { count: active.length }), tone: 'bad' },
      { label: t('reports:gasto_promedio'), value: money(active.length ? total / active.length : 0) },
      { label: t('reports:del_cajon'), value: money(drawer), hint: t('reports:del_cajon_hint') },
      { label: t('reports:por_banco'), value: money(total - drawer), hint: t('reports:por_banco_hint') },
      { label: t('reports:mayor_categoria'), value: top ? String(top[0]) : '—', hint: top ? moneyText((top[2] as { v: number }).v) : undefined },
      { label: t('reports:anulados'), value: int(expenses.length - active.length), tone: expenses.length - active.length ? 'bad' : 'neutral' },
    ],
    tables: [
      byCat,
      {
        title: t('reports:detalle_gastos'),
        sheet: t('reports:hoja_gastos'),
        columns: [{ label: t('reports:col_fecha'), width: 1.2 }, { label: t('reports:col_arqueo') }, { label: t('reports:col_categoria'), width: 1.2 }, { label: t('reports:col_concepto'), width: 2.4 }, { label: t('reports:col_pago') }, { label: t('reports:col_valor'), align: 'right' }, { label: t('reports:col_estado') }],
        rows: expenses
          .slice()
          .sort((a, b) => +new Date(a.createdAt) - +new Date(b.createdAt))
          .map((e) => [
            when(e.createdAt),
            e.sessionNumber || '—',
            e.category?.name || t('reports:sin_categoria'),
            [e.motive, e.description].filter(Boolean).join(' — '),
            fromDrawer(e) ? t('reports:pago_cajon') : t('reports:pago_banco'),
            money(e.amount),
            e.isCancelled ? `${t('reports:anulado')}${e.cancellationReason ? `: ${e.cancellationReason}` : ''}` : t('reports:valido'),
          ]),
        totals: ['', '', '', '', t('reports:total_valido'), money(total), ''],
        empty: t('reports:sin_gastos'),
      },
    ],
    notes: [t('reports:nota_gastos')],
  };
};

// ── Movimientos de caja (con los filtros de la pestaña) ───────

export interface MovementRow {
  type: 'SALE' | 'INCOME' | 'EXPENSE';
  date: Date;
  amount: number;
  isInflow: boolean;
  motive: string;
  description?: string;
  paymentMethod?: string;
  sessionNumber: string;
  isCancelled?: boolean;
  /** Parte en efectivo (una venta con tarjeta no entra al cajón) */
  cash: number;
}

export const buildMovementsReport = (movements: MovementRow[], periodLabel: string, scope?: string): ReportDoc => {
  const active = movements.filter((m) => !m.isCancelled);
  const sales = active.filter((m) => m.type === 'SALE');
  const salesCash = sumBy(sales, (m) => m.cash);
  const income = sumBy(active.filter((m) => m.type === 'INCOME'), (m) => m.amount);
  const out = sumBy(active.filter((m) => m.type === 'EXPENSE'), (m) => m.amount);
  const typeLabel = (m: MovementRow) => (m.type === 'SALE' ? t('reports:venta') : m.type === 'INCOME' ? t('reports:entrada') : t('reports:salida'));
  return {
    title: t('reports:movimientos_titulo'),
    period: periodLabel,
    scope,
    kpis: [
      { label: t('reports:ventas_netas'), value: money(sumBy(sales, (m) => m.amount)), hint: t('reports:num_ventas_hint_arqueo', { count: sales.length }) },
      { label: t('reports:efectivo_recibido'), value: money(salesCash), hint: t('reports:entra_al_cajon') },
      { label: t('reports:entradas_cajon'), value: money(income), hint: t('reports:entradas_cajon_hint') },
      { label: t('reports:salidas_cajon'), value: money(out), hint: t('reports:salidas_cajon_hint') },
      { label: t('reports:efectivo_neto'), value: money(salesCash + income - out), hint: t('reports:efectivo_neto_hint'), tone: salesCash + income - out >= 0 ? 'good' : 'bad' },
    ],
    tables: [
      {
        title: t('reports:movimientos_titulo'),
        sheet: t('reports:hoja_movimientos'),
        note: t('reports:movimientos_tabla_nota'),
        columns: [
          { label: t('reports:col_fecha'), width: 1.2 }, { label: t('reports:col_arqueo') }, { label: t('reports:col_tipo') }, { label: t('reports:col_concepto'), width: 2.4 },
          { label: t('reports:col_metodo') }, { label: t('reports:col_valor'), align: 'right' }, { label: t('reports:col_efectivo_cajon'), align: 'right' }, { label: t('reports:col_estado') },
        ],
        rows: movements
          .slice()
          .sort((a, b) => +a.date - +b.date)
          .map((m) => [
            when(m.date),
            m.sessionNumber,
            typeLabel(m),
            m.motive + (m.description ? ` — ${m.description}` : ''),
            m.type === 'SALE' ? methodLabel(m.paymentMethod || 'CASH') : t('reports:metodo_CASH'),
            money(m.isInflow ? m.amount : -m.amount),
            money(m.isCancelled ? 0 : m.isInflow ? m.cash : -m.amount),
            m.isCancelled ? t('reports:anulado') : t('reports:valido'),
          ]),
        totals: ['', '', '', '', t('reports:total_valido'), money(sumBy(active, (m) => (m.isInflow ? m.amount : -m.amount))), money(salesCash + income - out), ''],
        empty: t('reports:sin_movimientos'),
      },
    ],
    notes: [t('reports:nota_caja_mixtos')],
  };
};

