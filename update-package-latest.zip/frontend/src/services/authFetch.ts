// ============================================
// SERVICES - Interceptor de sesión para fetch
// ============================================
// Todas las llamadas al backend llevan el token, aunque el componente lo olvide.
// Si el servidor revoca la sesión o exige cambiar la contraseña, se avisa a App.
// Si el servidor no responde, el error dice por qué (sin red, servidor apagado, demora).

import { API_URL } from '../config';
import { connectionError } from './apiErrors';
import { showPlanLock } from '../shared/plan';

export const SESSION_EXPIRED_EVENT = 'lantify:session-expired';
export const PASSWORD_CHANGE_EVENT = 'lantify:password-change-required';

const SESSION_CODES = new Set(['AUTH_TOKEN_INVALID', 'AUTH_SESSION_REVOKED', 'AUTH_TOKEN_MISSING']);
const TIMEOUT_MS = 20000;

export const installAuthFetch = () => {
  const originalFetch = window.fetch.bind(window);

  window.fetch = async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = typeof input === 'string' ? input : input instanceof URL ? input.href : input.url;
    if (!url.startsWith(API_URL)) return originalFetch(input, init);

    const headers = new Headers(init?.headers || (input instanceof Request ? input.headers : undefined));
    const token = localStorage.getItem('token');
    const current = headers.get('Authorization');
    if (token && (!current || current === 'Bearer ' || current === 'Bearer null')) {
      headers.set('Authorization', `Bearer ${token}`);
    }

    // Un servidor colgado no deja la pantalla esperando para siempre
    const controller = new AbortController();
    let timedOut = false;
    const timer = setTimeout(() => { timedOut = true; controller.abort(); }, TIMEOUT_MS);
    init?.signal?.addEventListener('abort', () => controller.abort());

    let response: Response;
    try {
      response = await originalFetch(input, { ...init, headers, signal: controller.signal });
    } catch (e) {
      if (init?.signal?.aborted) throw e; // cancelado a propósito por quien llamó
      throw connectionError(e, timedOut);
    } finally {
      clearTimeout(timer);
    }

    if ((response.status === 401 || response.status === 403) && token && !url.includes('/auth/login')) {
      const body = await response.clone().json().catch(() => null);
      if (response.status === 401 && body?.code && SESSION_CODES.has(body.code)) {
        window.dispatchEvent(new CustomEvent(SESSION_EXPIRED_EVENT));
      } else if (body?.code === 'AUTH_PASSWORD_CHANGE_REQUIRED') {
        window.dispatchEvent(new CustomEvent(PASSWORD_CHANGE_EVENT));
      }
    }

    // Una acción fuera del plan (p. ej. emitir una factura DIAN) explica qué plan la incluye.
    // Las consultas en segundo plano (GET) no abren nada: cada pantalla muestra su candado.
    if (response.status === 402 && (init?.method || 'GET').toUpperCase() !== 'GET') {
      const body = await response.clone().json().catch(() => null);
      if (body?.code === 'PLAN_FEATURE_REQUIRED' && body.feature) showPlanLock(body.feature);
    }

    return response;
  };
};
