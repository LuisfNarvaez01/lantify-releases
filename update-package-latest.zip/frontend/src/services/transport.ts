// ============================================
// SERVICES - Camino de cada petición en la app del celular
// ============================================
// La app de Lantify en el celular (Android con sus propios archivos, o la versión web
// en el iPhone) no vive en la caja: tiene que encontrarla. Orden:
//   1. Red local: directo a la caja (http://ip:puerto), lo más rápido. Si las direcciones
//      guardadas fallan, la app Android busca la caja en la red (mDNS) y solo usa una que
//      responda en /health con la huella de SU negocio.
//   2. Relevo de Lantify Cloud por internet (datos móviles o wifi lejos de la caja).
//   3. Sin ninguno: la petición falla como "sin conexión" y lo que ya guarda pedidos
//      en el celular (pedidos pendientes) los envía cuando vuelva la conexión.
// En la caja o en un navegador que abre la IP de la caja nada de esto se usa: las
// peticiones siguen yendo al mismo origen, como siempre.

import { create } from 'zustand';
import { parsePairingLink, type Pairing } from '../../../src/domain/relayPairing';
import { tenantTag } from '../../../src/domain/lanDiscovery';
import { discoverOnLan } from './androidBridge';

export type TransportMode = 'lan' | 'relay' | 'offline' | 'unknown';

interface TransportState {
  /** true = la app del celular (no la abrió la caja) */
  clientApp: boolean;
  paired: boolean;
  business: string | null;
  mode: TransportMode;
  /** La caja está conectada al relevo */
  hostOnline: boolean | null;
  lanBase: string | null;
}

const PAIRING_KEY = 'lantify.pairing';
const LAN_KEY = 'lantify.lanBase';
const LAN_TIMEOUT_MS = 2500;
const LAN_RETRY_MS = 15_000;
const RELAY_TIMEOUT_MS = 20_000;
/** Buscar la caja en la red como mucho una vez por minuto */
const DISCOVER_EVERY_MS = 60_000;

const isPrivateHost = (host: string) =>
  host === 'localhost' || host === '127.0.0.1' || host === '[::1]' || /^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(host) || host.endsWith('.local');

const read = <T,>(key: string): T | null => {
  try { const raw = localStorage.getItem(key); return raw ? (JSON.parse(raw) as T) : null; } catch { return null; }
};
const write = (key: string, value: unknown) => {
  try { value === null ? localStorage.removeItem(key) : localStorage.setItem(key, JSON.stringify(value)); } catch { /* sin almacenamiento */ }
};

/** Un enlace de vinculación en la dirección (#pair=…) se guarda y se borra de la barra */
const takePairingFromUrl = (): Pairing | null => {
  if (typeof window === 'undefined' || !window.location.hash.includes('pair=')) return null;
  const pairing = parsePairingLink(window.location.href);
  history.replaceState(null, '', window.location.pathname + window.location.search);
  if (pairing) {
    write(PAIRING_KEY, pairing);
    write(LAN_KEY, null);
  }
  return pairing;
};

const clientApp = typeof window !== 'undefined' && !isPrivateHost(window.location.hostname);
let pairing: Pairing | null = clientApp ? takePairingFromUrl() || read<Pairing>(PAIRING_KEY) : null;

export const useTransport = create<TransportState>(() => ({
  clientApp,
  paired: !!pairing,
  business: pairing?.n ?? null,
  mode: 'unknown',
  hostOnline: null,
  lanBase: read<string>(LAN_KEY),
}));

const set = (patch: Partial<TransportState>) => useTransport.setState(patch);

/** QR de "Conectar tablets" (solo red local, http://ip:puerto): sin relevo por internet */
const lanOnlyPairing = (text: string): Pairing | null => {
  try {
    const u = new URL(text.trim());
    if (u.protocol !== 'http:' || !isPrivateHost(u.hostname) || u.hostname === 'localhost' || u.hostname.startsWith('127.')) return null;
    return { v: 1, t: '', d: '', s: '', l: [u.origin], r: '', n: null };
  } catch {
    return null;
  }
};

/** Guarda una vinculación nueva (QR escaneado dentro de la app) */
export const pairWith = (link: string): boolean => {
  const p = parsePairingLink(link) || lanOnlyPairing(link);
  if (!p) return false;
  pairing = p;
  write(PAIRING_KEY, p);
  write(LAN_KEY, null);
  relay.reset();
  set({ paired: true, business: p.n ?? null, mode: 'unknown', lanBase: null });
  return true;
};

/** Olvidar la caja (cambiar de negocio): nunca hace falta borrar los datos de la app */
export const unpair = () => {
  pairing = null;
  write(PAIRING_KEY, null);
  write(LAN_KEY, null);
  relay.reset();
  set({ paired: false, business: null, mode: 'unknown', lanBase: null, hostOnline: null });
};

// ── Red local ───────────────────────────────────────────────

let lanDownUntil = 0;

const lanCandidates = (): string[] => {
  const list = [useTransport.getState().lanBase, ...(relay.hello?.lan || []), ...(pairing?.l || [])].filter(Boolean) as string[];
  return [...new Set(list)];
};

const withTimeout = (ms: number, outer?: AbortSignal | null) => {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), ms);
  outer?.addEventListener('abort', () => ctrl.abort());
  return { signal: ctrl.signal, done: () => clearTimeout(timer) };
};

/** ¿Responde la caja en esta dirección? (página pública, sin usuario) */
const probe = async (base: string, fetchImpl: typeof fetch) => {
  const t = withTimeout(LAN_TIMEOUT_MS);
  try {
    const res = await fetchImpl(`${base}/api/version`, { signal: t.signal, cache: 'no-store' });
    return res.ok;
  } catch {
    return false;
  } finally {
    t.done();
  }
};

/** Huella del negocio que responde en /health (null si no responde) */
const healthTenant = async (base: string, fetchImpl: typeof fetch): Promise<string | null> => {
  const t = withTimeout(LAN_TIMEOUT_MS);
  try {
    const res = await fetchImpl(`${base}/health`, { signal: t.signal, cache: 'no-store' });
    if (!res.ok) return null;
    const body = await res.json().catch(() => null);
    return typeof body?.tenant === 'string' ? body.tenant : null;
  } catch {
    return null;
  } finally {
    t.done();
  }
};

let discoverAfter = 0;

/**
 * Las direcciones guardadas no responden: la app Android busca la caja en la red (mDNS).
 * Una caja encontrada solo se usa si su /health trae la huella de ESTE negocio.
 * Sin código de negocio (vinculación solo por red local) no se busca: no habría cómo comprobarla.
 */
const discoverLan = async (fetchImpl: typeof fetch): Promise<string | null> => {
  if (!pairing?.t || Date.now() < discoverAfter) return null;
  discoverAfter = Date.now() + DISCOVER_EVERY_MS;
  const found = (await discoverOnLan()).filter((b) => !lanCandidates().includes(b));
  if (!found.length) return null;
  const want = await tenantTag(pairing.t);
  for (const base of found) {
    if (want && (await healthTenant(base, fetchImpl)) === want) return base;
  }
  return null;
};

let finding: Promise<string | null> | null = null;

const findLan = (fetchImpl: typeof fetch): Promise<string | null> => {
  finding ??= (async () => {
    for (const base of lanCandidates()) {
      if (await probe(base, fetchImpl)) return remember(base);
    }
    const discovered = await discoverLan(fetchImpl).catch(() => null);
    return discovered ? remember(discovered) : null;
  })().finally(() => { finding = null; });
  return finding;
};

const remember = (base: string) => {
  write(LAN_KEY, base);
  set({ lanBase: base });
  return base;
};

// ── Relevo por internet ─────────────────────────────────────

type Pending = { resolve: (r: Response) => void; reject: (e: Error) => void; timer: ReturnType<typeof setTimeout> };

const b64ToBytes = (b64: string) => Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));

class RelayClient {
  private ws: WebSocket | null = null;
  private ready: Promise<void> | null = null;
  private pending = new Map<string, Pending>();
  private streams = new Set<ReadableStreamDefaultController<Uint8Array>>();
  private seq = 0;
  hello: { lan?: string[]; business?: string | null } | null = null;

  reset() {
    this.ws?.close();
    this.ws = null;
    this.ready = null;
  }

  private connect(): Promise<void> {
    if (this.ready) return this.ready;
    if (!pairing || !pairing.r || !pairing.d) return Promise.reject(new TypeError('RELAY_NOT_PAIRED'));
    const p = pairing;
    this.ready = new Promise<void>((resolve, reject) => {
      const ws = new WebSocket(`${p.r.replace(/^http/, 'ws')}/v1/relay/device/${encodeURIComponent(p.t)}`);
      this.ws = ws;
      const fail = (why: string) => {
        if (this.ws === ws) { this.ws = null; this.ready = null; }
        for (const [rid, pend] of this.pending) { clearTimeout(pend.timer); pend.reject(new TypeError(why)); this.pending.delete(rid); }
        for (const c of this.streams) { try { c.close(); } catch { /* nada */ } }
        this.streams.clear();
        reject(new TypeError(why));
      };
      const timer = setTimeout(() => { ws.close(); fail('RELAY_TIMEOUT'); }, 8000);
      ws.onopen = () => ws.send(JSON.stringify({ t: 'auth', id: p.d, secret: p.s, v: 1 }));
      ws.onclose = (ev) => {
        clearTimeout(timer);
        if (ev.code === 4003) {
          // La caja quitó este celular: se pide vincularlo otra vez
          unpair();
        }
        fail('RELAY_CLOSED');
      };
      ws.onerror = () => { /* llega onclose */ };
      ws.onmessage = (ev) => {
        let frame: any;
        try { frame = JSON.parse(String(ev.data)); } catch { return; }
        if (frame.t === 'ready') {
          clearTimeout(timer);
          this.hello = frame.hello || null;
          set({ hostOnline: !!frame.host, ...(frame.hello?.business ? { business: frame.hello.business } : {}) });
          resolve();
        } else if (frame.t === 'host') {
          if (frame.hello) this.hello = frame.hello;
          set({ hostOnline: !!frame.online });
        } else if (frame.t === 'res') {
          const pend = this.pending.get(frame.rid);
          if (!pend) return;
          clearTimeout(pend.timer);
          this.pending.delete(frame.rid);
          const headers = new Headers(frame.headers || { 'content-type': 'application/json' });
          const b64 = headers.get('x-relay-b64') === '1';
          headers.delete('x-relay-b64');
          const body = frame.status === 204 ? null : b64 ? b64ToBytes(frame.body || '') : frame.body ?? '';
          pend.resolve(new Response(body, { status: frame.status, headers }));
        } else if (frame.t === 'sse' && typeof frame.chunk === 'string') {
          const bytes = new TextEncoder().encode(frame.chunk);
          for (const c of this.streams) { try { c.enqueue(bytes); } catch { this.streams.delete(c); } }
        } else if (frame.t === 'revoked' || frame.t === 'denied') {
          unpair();
        }
      };
    });
    return this.ready;
  }

  async request(path: string, init: RequestInit, headers: Headers): Promise<Response> {
    await this.connect();
    const ws = this.ws;
    if (!ws || ws.readyState !== WebSocket.OPEN) throw new TypeError('RELAY_CLOSED');
    const rid = `${Date.now().toString(36)}-${++this.seq}`;
    let body: string | null = null;
    if (init.body != null) {
      if (typeof init.body === 'string') body = init.body;
      else if (init.body instanceof URLSearchParams) body = init.body.toString();
      else body = await new Response(init.body as BodyInit).text();
    }
    const plain: Record<string, string> = {};
    headers.forEach((v, k) => { plain[k] = v; });
    return new Promise<Response>((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(rid);
        reject(new TypeError('RELAY_TIMEOUT'));
      }, RELAY_TIMEOUT_MS);
      this.pending.set(rid, { resolve, reject, timer });
      init.signal?.addEventListener('abort', () => {
        const pend = this.pending.get(rid);
        if (!pend) return;
        clearTimeout(pend.timer);
        this.pending.delete(rid);
        reject(new DOMException('Aborted', 'AbortError'));
      });
      ws.send(JSON.stringify({ t: 'req', rid, method: (init.method || 'GET').toUpperCase(), path, headers: plain, body }));
    });
  }

  /** /api/events por el relevo: un flujo que recibe los avisos que reenvía la caja */
  async events(signal?: AbortSignal | null): Promise<Response> {
    await this.connect();
    let ctrl: ReadableStreamDefaultController<Uint8Array>;
    const stream = new ReadableStream<Uint8Array>({
      start: (c) => {
        ctrl = c;
        this.streams.add(c);
        c.enqueue(new TextEncoder().encode('retry: 3000\nevent: hello\ndata: {}\n\n'));
      },
      cancel: () => { this.streams.delete(ctrl); },
    });
    signal?.addEventListener('abort', () => { this.streams.delete(ctrl); try { ctrl.close(); } catch { /* nada */ } });
    return new Response(stream, { status: 200, headers: { 'content-type': 'text/event-stream' } });
  }
}

const relay = new RelayClient();

// ── Envío ───────────────────────────────────────────────────

/**
 * Envía una petición a /api/... por el mejor camino. `url` es relativa (/api/...).
 * Fuera de la app del celular, es exactamente fetch().
 */
export const transportFetch = async (fetchImpl: typeof fetch, url: string, init: RequestInit & { headers: Headers }): Promise<Response> => {
  if (!clientApp || !pairing) return fetchImpl(url, init);
  const path = url.startsWith('http') ? new URL(url).pathname + new URL(url).search : url;

  // 1. Red local (si no falló hace poco)
  if (Date.now() >= lanDownUntil) {
    const base = useTransport.getState().lanBase || (await findLan(fetchImpl));
    if (base) {
      try {
        const res = await fetchImpl(`${base}${path}`, init);
        if (useTransport.getState().mode !== 'lan') set({ mode: 'lan' });
        return res;
      } catch (err) {
        if (init.signal?.aborted && (err as Error)?.name === 'AbortError') throw err;
        lanDownUntil = Date.now() + LAN_RETRY_MS;
        set({ lanBase: null });
        write(LAN_KEY, null);
      }
    } else {
      lanDownUntil = Date.now() + LAN_RETRY_MS;
    }
  }

  // 2. Relevo por internet
  try {
    const res = path.startsWith('/api/events') ? await relay.events(init.signal) : await relay.request(path, init, init.headers);
    if (useTransport.getState().mode !== 'relay') set({ mode: 'relay' });
    // Mientras tanto, se vuelve a buscar la caja en la red local
    if (Date.now() >= lanDownUntil) void findLan(fetchImpl).then((b) => { if (b) lanDownUntil = 0; });
    return res;
  } catch (err) {
    if ((err as Error)?.name === 'AbortError') throw err;
    set({ mode: 'offline' });
    throw err instanceof TypeError ? err : new TypeError(String((err as Error)?.message || err));
  }
};

/** Dirección para <img> de /api/media en la app del celular (por la red local) */
export const clientMediaBase = (): string | null => (clientApp ? useTransport.getState().lanBase : null);
