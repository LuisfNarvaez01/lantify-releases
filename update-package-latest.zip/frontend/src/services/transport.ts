// ============================================
// SERVICES - Camino de cada petición en la app del celular
// ============================================
// La app de Lantify en el celular (Android con sus propios archivos, o la versión web
// en el iPhone) no vive en la caja: tiene que encontrarla. Orden (decisión de Luis, 25 nov:
// el mesero se mueve por todo el local y afuera, así que internet va primero):
//   1. Relevo de Lantify Cloud por internet (datos móviles o cualquier wifi).
//   2. Red local: directo a la caja (http://ip:puerto) cuando no hay internet o la caja
//      perdió el suyo. Si las direcciones guardadas fallan, la app Android busca la caja
//      en la red (mDNS) y solo usa una que responda en /health con la huella de SU negocio.
//      Mientras va por la red local, cada 15 s se prueba de nuevo internet en segundo plano.
//   3. Sin ninguno: la petición falla como "sin conexión" y lo que ya guarda pedidos
//      en el celular (pedidos pendientes) los envía cuando vuelva la conexión.
//   Un celular vinculado con el QR de "Conectar tablets" (solo red local) usa solo el paso 2.
// En la caja o en un navegador que abre la IP de la caja nada de esto se usa: las
// peticiones siguen yendo al mismo origen, como siempre.

import { create } from 'zustand';
import { parsePairingLink, type Pairing } from '../../../src/domain/relayPairing';
import { tenantTag } from '../../../src/domain/lanDiscovery';
import { discoverOnLan } from './androidBridge';

export type TransportMode = 'lan' | 'relay' | 'offline' | 'unknown';

/** Un local que este celular ya vinculó (para volver sin escanear otra vez) */
export interface SavedPairing {
  key: string;
  pairing: Pairing;
  name: string | null;
  lastUsedAt: string;
}

interface TransportState {
  /** Locales vinculados antes en este celular, el más reciente primero */
  saved: SavedPairing[];
  /** true = la app del celular (no la abrió la caja) */
  clientApp: boolean;
  paired: boolean;
  business: string | null;
  mode: TransportMode;
  /** La caja está conectada al relevo */
  hostOnline: boolean | null;
  lanBase: string | null;
}

const PAIRING_KEY = 'lantify.pairing';
const HISTORY_KEY = 'lantify.pairings';
const MAX_SAVED = 10;
const LAN_KEY = 'lantify.lanBase';
const LAN_TIMEOUT_MS = 2500;
const LAN_RETRY_MS = 15_000;
const RELAY_TIMEOUT_MS = 20_000;
/** Sin internet: cuánto esperar antes de volver a probar el relevo */
const RELAY_RETRY_MS = 15_000;
/** Buscar la caja en la red como mucho una vez por minuto */
const DISCOVER_EVERY_MS = 60_000;

const isPrivateHost = (host: string) =>
  host === 'localhost' || host === '127.0.0.1' || host === '[::1]' || /^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(host) || host.endsWith('.local');

const read = <T,>(key: string): T | null => {
  try { const raw = localStorage.getItem(key); return raw ? (JSON.parse(raw) as T) : null; } catch { return null; }
};
const write = (key: string, value: unknown) => {
  try { value === null ? localStorage.removeItem(key) : localStorage.setItem(key, JSON.stringify(value)); } catch { /* sin almacenamiento */ }
};

/** Un enlace de vinculación en la dirección (#pair=…) se guarda y se borra de la barra */
const takePairingFromUrl = (): Pairing | null => {
  if (typeof window === 'undefined' || !window.location.hash.includes('pair=')) return null;
  const pairing = parsePairingLink(window.location.href);
  history.replaceState(null, '', window.location.pathname + window.location.search);
  if (pairing) {
    write(PAIRING_KEY, pairing);
    write(LAN_KEY, null);
  }
  return pairing;
};

const clientApp = typeof window !== 'undefined' && !isPrivateHost(window.location.hostname);
let pairing: Pairing | null = clientApp ? takePairingFromUrl() || read<Pairing>(PAIRING_KEY) : null;

// ── Historial de locales vinculados ─────────────────────────

/** Un local se reconoce por su negocio y este celular (o por su dirección, si es solo red local) */
export const pairingKey = (p: Pairing) => (p.t ? `${p.t}:${p.d}` : `lan:${p.l[0] || ''}`);

const readSaved = (): SavedPairing[] => {
  const list = read<SavedPairing[]>(HISTORY_KEY);
  return Array.isArray(list) ? list.filter((x) => x && x.pairing && typeof x.key === 'string') : [];
};

/** Guarda (o sube al primer lugar) el local en el historial */
const addSaved = (p: Pairing, name?: string | null) => {
  const key = pairingKey(p);
  const prev = readSaved();
  const old = prev.find((x) => x.key === key);
  const next = [{ key, pairing: p, name: name ?? p.n ?? old?.name ?? null, lastUsedAt: new Date().toISOString() }, ...prev.filter((x) => x.key !== key)].slice(0, MAX_SAVED);
  write(HISTORY_KEY, next);
  return next;
};

if (pairing) addSaved(pairing);

export const useTransport = create<TransportState>(() => ({
  saved: readSaved(),
  clientApp,
  paired: !!pairing,
  business: pairing?.n ?? (pairing ? readSaved().find((x) => x.key === pairingKey(pairing!))?.name ?? null : null),
  mode: 'unknown',
  hostOnline: null,
  lanBase: read<string>(LAN_KEY),
}));

const set = (patch: Partial<TransportState>) => useTransport.setState(patch);

/** QR de "Conectar tablets" (solo red local, http://ip:puerto): sin relevo por internet */
const lanOnlyPairing = (text: string): Pairing | null => {
  try {
    const u = new URL(text.trim());
    if (u.protocol !== 'http:' || !isPrivateHost(u.hostname) || u.hostname === 'localhost' || u.hostname.startsWith('127.')) return null;
    return { v: 1, t: '', d: '', s: '', l: [u.origin], r: '', n: null };
  } catch {
    return null;
  }
};

/** Lo de la sesión anterior no sirve en otro local: se cierra la sesión al cambiar */
const clearSession = () => {
  try {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  } catch { /* sin almacenamiento */ }
};

const activate = (p: Pairing) => {
  const changed = !pairing || pairingKey(pairing) !== pairingKey(p);
  if (changed) clearSession();
  pairing = p;
  write(PAIRING_KEY, p);
  write(LAN_KEY, null);
  relay.reset();
  lanDownUntil = 0;
  relayDownUntil = 0;
  const saved = addSaved(p);
  set({ paired: true, business: p.n ?? saved[0]?.name ?? null, mode: 'unknown', lanBase: null, hostOnline: null, saved });
};

/** Guarda una vinculación nueva (QR escaneado dentro de la app) */
export const pairWith = (link: string): boolean => {
  const p = parsePairingLink(link) || lanOnlyPairing(link);
  if (!p) return false;
  activate(p);
  return true;
};

/** Volver a un local del historial, sin escanear */
export const switchToPairing = (key: string): boolean => {
  const found = readSaved().find((x) => x.key === key);
  if (!found) return false;
  activate(found.pairing);
  return true;
};

/** Quitar un local del historial de este celular */
export const forgetPairing = (key: string) => {
  const next = readSaved().filter((x) => x.key !== key);
  write(HISTORY_KEY, next);
  set({ saved: next });
  if (pairing && pairingKey(pairing) === key) unpair();
};

/** Ir a la lista de locales (cambiar de negocio). El local queda en el historial:
 *  volver es un toque, sin otro QR. Nunca hace falta borrar los datos de la app. */
export const unpair = () => {
  pairing = null;
  write(PAIRING_KEY, null);
  write(LAN_KEY, null);
  relay.reset();
  clearSession();
  set({ paired: false, business: null, mode: 'unknown', lanBase: null, hostOnline: null, saved: readSaved() });
};

/** La caja quitó este celular: sale también del historial (ese QR ya no sirve) */
const revoked = () => {
  if (pairing) {
    const key = pairingKey(pairing);
    write(HISTORY_KEY, readSaved().filter((x) => x.key !== key));
  }
  unpair();
};

// ── Red local ───────────────────────────────────────────────

let lanDownUntil = 0;

const lanCandidates = (): string[] => {
  const list = [useTransport.getState().lanBase, ...(relay.hello?.lan || []), ...(pairing?.l || [])].filter(Boolean) as string[];
  return [...new Set(list)];
};

const withTimeout = (ms: number, outer?: AbortSignal | null) => {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), ms);
  outer?.addEventListener('abort', () => ctrl.abort());
  return { signal: ctrl.signal, done: () => clearTimeout(timer) };
};

/** ¿Responde la caja en esta dirección? (página pública, sin usuario) */
const probe = async (base: string, fetchImpl: typeof fetch) => {
  const t = withTimeout(LAN_TIMEOUT_MS);
  try {
    const res = await fetchImpl(`${base}/api/version`, { signal: t.signal, cache: 'no-store' });
    return res.ok;
  } catch {
    return false;
  } finally {
    t.done();
  }
};

/** Huella del negocio que responde en /health (null si no responde) */
const healthTenant = async (base: string, fetchImpl: typeof fetch): Promise<string | null> => {
  const t = withTimeout(LAN_TIMEOUT_MS);
  try {
    const res = await fetchImpl(`${base}/health`, { signal: t.signal, cache: 'no-store' });
    if (!res.ok) return null;
    const body = await res.json().catch(() => null);
    return typeof body?.tenant === 'string' ? body.tenant : null;
  } catch {
    return null;
  } finally {
    t.done();
  }
};

let discoverAfter = 0;

/**
 * Las direcciones guardadas no responden: la app Android busca la caja en la red (mDNS).
 * Una caja encontrada solo se usa si su /health trae la huella de ESTE negocio.
 * Sin código de negocio (vinculación solo por red local) no se busca: no habría cómo comprobarla.
 */
const discoverLan = async (fetchImpl: typeof fetch): Promise<string | null> => {
  if (!pairing?.t || Date.now() < discoverAfter) return null;
  discoverAfter = Date.now() + DISCOVER_EVERY_MS;
  const found = (await discoverOnLan()).filter((b) => !lanCandidates().includes(b));
  if (!found.length) return null;
  const want = await tenantTag(pairing.t);
  for (const base of found) {
    if (want && (await healthTenant(base, fetchImpl)) === want) return base;
  }
  return null;
};

let finding: Promise<string | null> | null = null;

const findLan = (fetchImpl: typeof fetch): Promise<string | null> => {
  finding ??= (async () => {
    for (const base of lanCandidates()) {
      if (await probe(base, fetchImpl)) return remember(base);
    }
    const discovered = await discoverLan(fetchImpl).catch(() => null);
    return discovered ? remember(discovered) : null;
  })().finally(() => { finding = null; });
  return finding;
};

const remember = (base: string) => {
  write(LAN_KEY, base);
  set({ lanBase: base });
  return base;
};

// ── Relevo por internet ─────────────────────────────────────

type Pending = { resolve: (r: Response) => void; reject: (e: Error) => void; timer: ReturnType<typeof setTimeout> };

const b64ToBytes = (b64: string) => Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));

class RelayClient {
  private ws: WebSocket | null = null;
  private ready: Promise<void> | null = null;
  private pending = new Map<string, Pending>();
  private streams = new Set<ReadableStreamDefaultController<Uint8Array>>();
  private seq = 0;
  hello: { lan?: string[]; business?: string | null } | null = null;

  reset() {
    this.ws?.close();
    this.ws = null;
    this.ready = null;
  }

  /** Hay conexión abierta con el relevo ahora mismo */
  isOpen() {
    return !!this.ws && this.ws.readyState === WebSocket.OPEN;
  }

  /** Abre la conexión sin enviar nada (para volver a internet en segundo plano) */
  warm() {
    return this.connect();
  }

  private connect(): Promise<void> {
    if (this.ready) return this.ready;
    if (!pairing || !pairing.r || !pairing.d) return Promise.reject(new TypeError('RELAY_NOT_PAIRED'));
    const p = pairing;
    this.ready = new Promise<void>((resolve, reject) => {
      const ws = new WebSocket(`${p.r.replace(/^http/, 'ws')}/v1/relay/device/${encodeURIComponent(p.t)}`);
      this.ws = ws;
      const fail = (why: string) => {
        if (this.ws === ws) { this.ws = null; this.ready = null; }
        for (const [rid, pend] of this.pending) { clearTimeout(pend.timer); pend.reject(new TypeError(why)); this.pending.delete(rid); }
        for (const c of this.streams) { try { c.close(); } catch { /* nada */ } }
        this.streams.clear();
        reject(new TypeError(why));
      };
      const timer = setTimeout(() => { ws.close(); fail('RELAY_TIMEOUT'); }, 6000);
      ws.onopen = () => ws.send(JSON.stringify({ t: 'auth', id: p.d, secret: p.s, v: 1 }));
      ws.onclose = (ev) => {
        clearTimeout(timer);
        if (ev.code === 4003) {
          // La caja quitó este celular: se pide vincularlo otra vez
          revoked();
        }
        fail('RELAY_CLOSED');
      };
      ws.onerror = () => { /* llega onclose */ };
      ws.onmessage = (ev) => {
        let frame: any;
        try { frame = JSON.parse(String(ev.data)); } catch { return; }
        if (frame.t === 'ready') {
          clearTimeout(timer);
          this.hello = frame.hello || null;
          set({ hostOnline: !!frame.host, ...(frame.hello?.business ? { business: frame.hello.business } : {}) });
          if (frame.hello?.business && pairing) set({ saved: addSaved(pairing, frame.hello.business) });
          resolve();
        } else if (frame.t === 'host') {
          if (frame.hello) this.hello = frame.hello;
          set({ hostOnline: !!frame.online });
        } else if (frame.t === 'res') {
          const pend = this.pending.get(frame.rid);
          if (!pend) return;
          clearTimeout(pend.timer);
          this.pending.delete(frame.rid);
          const headers = new Headers(frame.headers || { 'content-type': 'application/json' });
          const b64 = headers.get('x-relay-b64') === '1';
          headers.delete('x-relay-b64');
          const body = frame.status === 204 ? null : b64 ? b64ToBytes(frame.body || '') : frame.body ?? '';
          pend.resolve(new Response(body, { status: frame.status, headers }));
        } else if (frame.t === 'sse' && typeof frame.chunk === 'string') {
          const bytes = new TextEncoder().encode(frame.chunk);
          for (const c of this.streams) { try { c.enqueue(bytes); } catch { this.streams.delete(c); } }
        } else if (frame.t === 'revoked' || frame.t === 'denied') {
          revoked();
        }
      };
    });
    return this.ready;
  }

  async request(path: string, init: RequestInit, headers: Headers): Promise<Response> {
    await this.connect();
    const ws = this.ws;
    if (!ws || ws.readyState !== WebSocket.OPEN) throw new TypeError('RELAY_CLOSED');
    const rid = `${Date.now().toString(36)}-${++this.seq}`;
    let body: string | null = null;
    if (init.body != null) {
      if (typeof init.body === 'string') body = init.body;
      else if (init.body instanceof URLSearchParams) body = init.body.toString();
      else body = await new Response(init.body as BodyInit).text();
    }
    const plain: Record<string, string> = {};
    headers.forEach((v, k) => { plain[k] = v; });
    return new Promise<Response>((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(rid);
        reject(new TypeError('RELAY_TIMEOUT'));
      }, RELAY_TIMEOUT_MS);
      this.pending.set(rid, { resolve, reject, timer });
      init.signal?.addEventListener('abort', () => {
        const pend = this.pending.get(rid);
        if (!pend) return;
        clearTimeout(pend.timer);
        this.pending.delete(rid);
        reject(new DOMException('Aborted', 'AbortError'));
      });
      ws.send(JSON.stringify({ t: 'req', rid, method: (init.method || 'GET').toUpperCase(), path, headers: plain, body }));
    });
  }

  /** /api/events por el relevo: un flujo que recibe los avisos que reenvía la caja */
  async events(signal?: AbortSignal | null): Promise<Response> {
    await this.connect();
    let ctrl: ReadableStreamDefaultController<Uint8Array>;
    const stream = new ReadableStream<Uint8Array>({
      start: (c) => {
        ctrl = c;
        this.streams.add(c);
        c.enqueue(new TextEncoder().encode('retry: 3000\nevent: hello\ndata: {}\n\n'));
      },
      cancel: () => { this.streams.delete(ctrl); },
    });
    signal?.addEventListener('abort', () => { this.streams.delete(ctrl); try { ctrl.close(); } catch { /* nada */ } });
    return new Response(stream, { status: 200, headers: { 'content-type': 'text/event-stream' } });
  }
}

const relay = new RelayClient();

// ── Envío ───────────────────────────────────────────────────

/**
 * Envía una petición a /api/... por el mejor camino. `url` es relativa (/api/...).
 * Fuera de la app del celular, es exactamente fetch().
 */
export const transportFetch = async (fetchImpl: typeof fetch, url: string, init: RequestInit & { headers: Headers }): Promise<Response> => {
  if (!clientApp || !pairing) return fetchImpl(url, init);
  const path = url.startsWith('http') ? new URL(url).pathname + new URL(url).search : url;
  const canRelay = !!(pairing.r && pairing.d);
  const viaRelay = () => (path.startsWith('/api/events') ? relay.events(init.signal) : relay.request(path, init, init.headers));
  let hostOffline: Response | null = null;

  // 1. Internet primero. Si el relevo dice que la caja no está conectada a internet
  //    (o ya se sabe), se intenta la red local antes de dar esa respuesta.
  const relayUsable = canRelay && (relay.isOpen() || Date.now() >= relayDownUntil);
  if (relayUsable && !(relay.isOpen() && useTransport.getState().hostOnline === false)) {
    try {
      const res = await viaRelay();
      if (res.status !== 503 || !(await isHostOffline(res))) {
        if (useTransport.getState().mode !== 'relay') set({ mode: 'relay' });
        return res;
      }
      hostOffline = res;
    } catch (err) {
      if ((err as Error)?.name === 'AbortError') throw err;
      relayDownUntil = Date.now() + RELAY_RETRY_MS;
    }
  }

  // 2. Red local (si no falló hace poco)
  if (Date.now() >= lanDownUntil) {
    const base = useTransport.getState().lanBase || (await findLan(fetchImpl));
    if (base) {
      try {
        const res = await fetchImpl(`${base}${path}`, init);
        if (useTransport.getState().mode !== 'lan') set({ mode: 'lan' });
        retryRelaySoon(canRelay);
        return res;
      } catch (err) {
        if (init.signal?.aborted && (err as Error)?.name === 'AbortError') throw err;
        lanDownUntil = Date.now() + LAN_RETRY_MS;
        set({ lanBase: null });
        write(LAN_KEY, null);
      }
    } else {
      lanDownUntil = Date.now() + LAN_RETRY_MS;
    }
  }

  // 3. La caja no está en internet y tampoco en esta red: se entrega lo que dijo el relevo
  if (hostOffline) return hostOffline;
  // El relevo estaba conectado pero la caja no; quizá ya volvió
  if (canRelay && relay.isOpen()) {
    try {
      const res = await viaRelay();
      set({ mode: 'relay' });
      return res;
    } catch (err) {
      if ((err as Error)?.name === 'AbortError') throw err;
    }
  }
  set({ mode: 'offline' });
  retryRelaySoon(canRelay);
  throw new TypeError(canRelay ? 'OFFLINE' : 'LAN_ONLY_OFFLINE');
};

let relayDownUntil = 0;
let warming = false;

/** Va por la red local: vuelve a probar internet en segundo plano (como mucho cada 15 s) */
const retryRelaySoon = (canRelay: boolean) => {
  if (!canRelay || warming || relay.isOpen() || Date.now() < relayDownUntil) return;
  warming = true;
  relay.warm()
    .then(() => { relayDownUntil = 0; })
    .catch(() => { relayDownUntil = Date.now() + RELAY_RETRY_MS; })
    .finally(() => { warming = false; });
};

const isHostOffline = async (res: Response) => {
  try {
    const body = await res.clone().json();
    return body?.code === 'RELAY_HOST_OFFLINE' || body?.code === 'RELAY_UNAVAILABLE';
  } catch {
    return false;
  }
};

/** Local activo (para separar los ingresos guardados de cada negocio) */
export const currentPairingKey = (): string | null => (pairing ? pairingKey(pairing) : null);

// La app Android avisa al volver al frente: si la conexión cayó con la pantalla apagada,
// se reintenta ya (sin esperar los 15 s) y los avisos en vivo se vuelven a conectar.
if (clientApp && typeof window !== 'undefined') {
  const resume = () => {
    if (!pairing) return;
    lanDownUntil = 0;
    if (!relay.isOpen()) {
      relayDownUntil = 0;
      retryRelaySoon(!!(pairing.r && pairing.d));
    }
  };
  window.__lantifyResume = resume;
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') resume(); });
  window.addEventListener('online', resume);
}

/** ¿Este celular quedó vinculado solo por la red local (QR de "Conectar tablets")? */
export const lanOnlyPaired = () => !!pairing && !(pairing.r && pairing.d);

/** Dirección para <img> de /api/media en la app del celular (por la red local) */
export const clientMediaBase = (): string | null => (clientApp ? useTransport.getState().lanBase : null);
