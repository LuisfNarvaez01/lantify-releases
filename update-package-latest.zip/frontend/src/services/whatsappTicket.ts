// ============================================
// SERVICES - Mandar un ticket (pre-cuenta o recibo) por WhatsApp
// ============================================
// WhatsApp no deja adjuntar imágenes desde un enlace wa.me. Por eso:
//  - Si el negocio está en Lantify Cloud, la imagen se sube y el mensaje lleva un
//    enlace privado a la cuenta (vence a los 30 días): el cliente la ve con un toque.
//  - Además se puede copiar la imagen (Ctrl+V en el chat), descargarla o, en
//    celulares, usar "Compartir" del sistema y elegir WhatsApp.
// Todo eso lo ofrece la ventana WhatsAppShareHost.

import { buildReceiptDoc, ReceiptData } from './ticketBuilder';
import { ticketContext } from './printService';
import { ticketToPng } from './ticketImage';
import { useWhatsAppShare, WhatsAppOutcome } from '../shared/whatsappShare';

export type { WhatsAppOutcome } from '../shared/whatsappShare';

/** Celular colombiano de 10 dígitos → con indicativo; los demás se dejan como vienen */
export const whatsappNumber = (raw: string) => {
  const d = raw.replace(/\D/g, '');
  return d.length === 10 && d.startsWith('3') ? `57${d}` : d;
};

/** Abre el chat (o el selector de contactos si no hay número) con el texto escrito */
export const openWhatsAppChat = (phone: string, text: string) => {
  const n = whatsappNumber(phone);
  window.open(`https://wa.me/${n.length >= 7 ? n : ''}?text=${encodeURIComponent(text)}`, '_blank', 'noopener');
};

export const sendTicketByWhatsApp = async (opts: {
  data: ReceiptData;
  /** Celular del cliente si se conoce */
  phone?: string | null;
  /** Mensaje que acompaña la cuenta */
  message: string;
  fileName: string;
}): Promise<WhatsAppOutcome> => {
  const ctx = await ticketContext();
  const blob = await ticketToPng(buildReceiptDoc(opts.data, ctx));
  return useWhatsAppShare.getState().open({ blob, fileName: opts.fileName, message: opts.message, phone: opts.phone?.replace(/[^\d+]/g, '') || '' });
};
