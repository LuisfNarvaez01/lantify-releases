// ============================================
// SERVICES - Mandar un ticket (pre-cuenta o recibo) por WhatsApp como imagen
// ============================================
// WhatsApp no deja adjuntar imágenes desde un enlace, así que:
//  - En el computador: la imagen queda copiada y se abre el chat del cliente;
//    solo hay que pegarla (Ctrl+V) y enviar.
//  - En celulares y tablets: se abre "Compartir" del sistema con la imagen y se
//    elige WhatsApp.
//  - Si el navegador no permite ninguna de las dos (p. ej. tablet por http en la
//    red local): se descarga la imagen y se abre el chat para adjuntarla.

import { buildReceiptDoc, ReceiptData } from './ticketBuilder';
import { ticketContext } from './printService';
import { ticketToPng } from './ticketImage';
import { promptDialog } from '../shared/dialog';
import { toast } from '../shared/toast';
import { t } from '../i18n';

export type WhatsAppOutcome = 'pasted' | 'shared' | 'downloaded' | 'cancelled';

/** Celular colombiano de 10 dígitos → con indicativo; los demás se dejan como vienen */
export const whatsappNumber = (raw: string) => {
  const d = raw.replace(/\D/g, '');
  return d.length === 10 && d.startsWith('3') ? `57${d}` : d;
};

const isTouch = () => typeof window !== 'undefined' && window.matchMedia?.('(pointer: coarse)').matches;

const openChat = (phone: string, text: string) =>
  window.open(`https://wa.me/${phone}?text=${encodeURIComponent(text)}`, '_blank', 'noopener');

const download = (blob: Blob, name: string) => {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
};

export const sendTicketByWhatsApp = async (opts: {
  data: ReceiptData;
  /** Celular del cliente si se conoce; si no, se pregunta */
  phone?: string | null;
  /** Mensaje que acompaña la imagen */
  message: string;
  fileName: string;
}): Promise<WhatsAppOutcome> => {
  const ctx = await ticketContext();
  const blob = await ticketToPng(buildReceiptDoc(opts.data, ctx));
  const file = new File([blob], opts.fileName, { type: 'image/png' });

  // Celular o tablet: menú Compartir del sistema (ahí se elige WhatsApp y el chat)
  if (isTouch() && navigator.canShare?.({ files: [file] })) {
    try {
      await navigator.share({ files: [file], text: opts.message });
      return 'shared';
    } catch (err: any) {
      if (err?.name === 'AbortError') return 'cancelled';
    }
  }

  const typed = opts.phone?.replace(/\D/g, '')
    ? opts.phone
    : await promptDialog({
        title: t('pos:wa_titulo'),
        label: t('pos:wa_numero'),
        placeholder: '3001234567',
        inputMode: 'tel',
        confirmLabel: t('pos:wa_enviar'),
      });
  const phone = typed ? whatsappNumber(typed) : '';
  if (phone.length < 7) return 'cancelled';

  // Computador: copiar la imagen y abrir el chat del cliente
  if (window.isSecureContext && navigator.clipboard && typeof ClipboardItem !== 'undefined') {
    try {
      await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]);
      openChat(phone, opts.message);
      toast.show({ type: 'success', title: t('pos:wa_copiada_titulo'), message: t('pos:wa_copiada_desc'), duration: 9000 });
      return 'pasted';
    } catch {
      // sigue con la siguiente opción
    }
  }

  // Sin portapapeles: descargar y abrir el chat
  download(blob, opts.fileName);
  openChat(phone, opts.message);
  toast.show({ type: 'info', title: t('pos:wa_descargada_titulo'), message: t('pos:wa_descargada_desc'), duration: 9000 });
  return 'downloaded';
};
