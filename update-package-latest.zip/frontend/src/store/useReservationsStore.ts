// ============================================
// STORE - Aviso de reservas en el encabezado
// ============================================
// Cada minuto pregunta cuántas reservas esperan confirmación (las de la página
// llegan solas desde la nube) para mostrarlo en la pestaña Reservas.

import { create } from 'zustand';
import { reservationsAPI } from '../services/api';

interface ReservationsState {
  enabled: boolean;
  pending: number;
  conflicts: number;
  latest: string;
  /** Cambia cada vez que llegan reservas nuevas: la agenda se recarga sola */
  version: number;
  refresh: () => Promise<void>;
}

export const useReservationsStore = create<ReservationsState>((set, get) => ({
  enabled: false,
  pending: 0,
  conflicts: 0,
  latest: '',
  version: 0,
  refresh: async () => {
    try {
      const [config, summary] = await Promise.all([reservationsAPI.settings(), reservationsAPI.summary()]);
      const prev = get();
      const changed = summary.latest !== prev.latest;
      set({ enabled: config.settings.enabled, pending: summary.pending, conflicts: summary.conflicts, latest: summary.latest, version: changed ? prev.version + 1 : prev.version });
    } catch {
      // Sin la función en el plan o sin conexión con el servidor: no hay aviso
    }
  },
}));
