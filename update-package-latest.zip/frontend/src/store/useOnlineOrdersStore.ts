// ============================================
// STORE - Aviso de pedidos en línea en el encabezado
// ============================================
// Cada 20 s pregunta cuántos pedidos de la página esperan que la caja los acepte.
// Cuando llega uno nuevo, suena un aviso y la lista se recarga sola.

import { create } from 'zustand';
import { onlineOrdersAPI } from '../services/api';

interface OnlineOrdersState {
  pending: number;
  open: number;
  latest: string;
  /** Cambia cada vez que llega un pedido nuevo: la lista se recarga sola */
  version: number;
  refresh: () => Promise<{ isNew: boolean; code?: string; customerName?: string }>;
}

/** Dos tonos cortos, sin archivos de sonido */
export const chime = () => {
  try {
    const Ctx = window.AudioContext || (window as any).webkitAudioContext;
    const ctx = new Ctx();
    [880, 1320].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.0001, ctx.currentTime + i * 0.18);
      gain.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + i * 0.18 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + i * 0.18 + 0.25);
      osc.connect(gain).connect(ctx.destination);
      osc.start(ctx.currentTime + i * 0.18);
      osc.stop(ctx.currentTime + i * 0.18 + 0.3);
    });
  } catch {
    // sin audio en este equipo
  }
};

export const useOnlineOrdersStore = create<OnlineOrdersState>((set, get) => ({
  pending: 0,
  open: 0,
  latest: '',
  version: 0,
  refresh: async () => {
    try {
      const s = await onlineOrdersAPI.summary();
      const prev = get();
      const changed = s.latest !== prev.latest;
      // El primer vistazo al abrir el programa no cuenta como "nuevo"
      const isNew = changed && prev.latest !== '' && !!s.latestOrder;
      set({ pending: s.pending, open: s.open, latest: s.latest, version: changed ? prev.version + 1 : prev.version });
      return { isNew, code: s.latestOrder?.code, customerName: s.latestOrder?.customerName };
    } catch {
      // Sin la función en el plan o sin conexión con el servidor: no hay aviso
      return { isNew: false };
    }
  },
}));
