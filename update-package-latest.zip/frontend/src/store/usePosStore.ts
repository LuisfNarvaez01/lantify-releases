// ============================================
// STORE - Zustand POS Store
// ============================================

import { parseIngredients } from '../shared/itemNotes';
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { responseError } from '../services/apiErrors';
import type { 
  Product, 
  Category, 
  Table, 
  CashSession, 
  CartItem, 
  Sale,
  ProductVariant 
} from '../types';
import { productsAPI, tablesAPI, cashSessionAPI, salesAPI, ordersAPI } from '../services/api';

import { API_URL } from '../config';

import { t } from '../i18n';
import { newId } from '../shared/browser';
import { isProductPaused } from '../shared/productState';
import { toast } from '../shared/toast';
const getToken = () => localStorage.getItem('token');

const headers = () => ({
  'Content-Type': 'application/json',
  'Authorization': `Bearer ${getToken() || ''}`
});

interface PosState {
  // Products
  products: Product[];
  categories: Category[];
  selectedCategory: string | null;
  isLoadingProducts: boolean;
  
  // Cart - Ahora por mesa
  cartsByTable: Record<string, CartItem[]>; // Carritos por mesa (mesa ID -> items)
  customersByTable: Record<string, any>; // Cliente por mesa (mesa ID -> customer)
  /** Personas y descripción de la mesa (Lantify 3.0) */
  tableDetails: Record<string, { guests: number | null; label: string | null }>;
  setTableDetails: (tableId: string, d: { guests: number | null; label: string | null } | null) => void;
  currentTableId: string | null; // Mesa actual seleccionada
  currentSale: Sale | null;
  
  // Pedidos pendientes por mesa (guardado temporal hasta que se paga)
  pendingOrdersByTable: Record<string, CartItem[]>;
  
  // Tables
  tables: Table[];
  selectedTable: Table | null;
  isLoadingTables: boolean;
  
  // Cash Session
  cashSession: CashSession | null;
  isLoadingSession: boolean;
  
  // UI State
  isVariantModalOpen: boolean;
  selectedProductForVariant: Product | null;
  
  // Table Sales History (for tracking paid vs pending)
  tableSalesHistory: Sale[];
  totalPaid: number;
  
  // Actions - Products
  fetchProducts: () => Promise<void>;
  fetchCategories: () => Promise<void>;
  setSelectedCategory: (categoryId: string | null) => void;
  
  // Actions - Cart
  addToCart: (product: Product, variant: ProductVariant, quantity?: number, notes?: string) => void;
  updateCartItemQuantity: (itemId: string, quantity: number) => void;
  updateCartItemNotes: (itemId: string, notes: string, removed?: string[]) => void;
  removeFromCart: (itemId: string) => void;
  clearCart: () => void;
  getCartTotal: () => { subtotal: number; tax: number; total: number };
  getTableAccountTotal: () => { paid: number; pending: number; total: number };
  getCurrentCart: () => CartItem[];
  selectCustomerForTable: (tableId: string, customer: any) => void;
  
  // Actions - Pedidos pendientes (guardado temporal)
  savePendingOrder: (tableId: string, items: CartItem[]) => Promise<boolean>;
  getPendingOrder: (tableId: string) => CartItem[];
  clearPendingOrder: (tableId: string) => Promise<void> | void;
  /** Vacía por completo el pedido de una mesa o del mostrador (después de cobrarlo) */
  resetCart: (tableId: string) => void;
  /** Id de la comanda en el servidor por mesa ('counter' para mostrador) */
  serverOrderIdByTable: Record<string, string>;
  loadPendingOrderToCart: (tableId: string) => void;
  
  // Actions - Tables
  fetchTables: () => Promise<void>;
  selectTable: (table: Table | null) => void;
  loadTableSale: (tableId: string) => Promise<void>;
  occupyTable: (tableId: string) => Promise<void>;
  releaseTable: (tableId: string, cancellation?: { reason: string; adminAuthToken?: string }) => Promise<void>;
  orderTable: (tableId: string) => Promise<void>;
  setTablePending: (tableId: string) => Promise<void>;
  closeTable: (tableId: string) => Promise<void>;
  
  // Actions - Cash Session
  fetchOpenSession: () => Promise<void>;
  openCashSession: (initialBalance: number, notes?: string) => Promise<void>;
  closeCashSession: (countedBalance: number, notes?: string) => Promise<void>;
  addIncome: (amount: number, motive: string, description?: string) => Promise<void>;
  addExpense: (amount: number, motive: string, description?: string, categoryId?: string) => Promise<void>;
  cancelIncome: (incomeId: string, reason: string) => Promise<void>;
  cancelExpense: (expenseId: string, reason: string) => Promise<void>;
  
  // Actions - Sales
  createSale: (paymentMethod?: 'CASH' | 'CARD' | 'TRANSFER' | 'MIXED', customerId?: string, discountPct?: number, payments?: any[]) => Promise<Sale>;
  completeSale: (saleId: string) => Promise<void>;
  cancelSale: (saleId: string) => Promise<void>;
  cancelSaleItem: (itemId: string, reason: string) => Promise<void>;
  addPayment: (saleId: string, amount: number, paymentMethod: string) => Promise<void>;
  getSalePayments: (saleId: string) => Promise<any[]>;
  getSalePaidTotal: (saleId: string) => Promise<number>;
  
  // Actions - UI
  openVariantModal: (product: Product) => void;
  closeVariantModal: () => void;
  setCartAsOrdered: (tableId: string) => void;
  cancelCartItemPartial: (
    tableId: string,
    itemId: string,
    quantityToCancel: number,
    reason: string,
    comments?: string,
    adminName?: string,
    wasteDestination?: 'waste' | 'restock'
  ) => void;
}

// Los precios ya incluyen IVA, no se agrega impuesto adicional

export const usePosStore = create<PosState>()(persist((set, get) => ({
  // Initial State
  products: [],
  categories: [],
  selectedCategory: null,
  isLoadingProducts: false,
  
  // Cart - Ahora por mesa
  cartsByTable: {},
  customersByTable: {},
  tableDetails: {},
  setTableDetails: (tableId, d) => {
    const next = { ...get().tableDetails };
    if (d) next[tableId] = d; else delete next[tableId];
    set({ tableDetails: next });
  },
  currentTableId: null,
  currentSale: null,
  
  // Pedidos pendientes por mesa (guardado temporal hasta que se paga)
  pendingOrdersByTable: {},
  serverOrderIdByTable: {},
  
  tables: [],
  selectedTable: null,
  isLoadingTables: false,
  
  cashSession: null,
  isLoadingSession: false,
  
  isVariantModalOpen: false,
  selectedProductForVariant: null,
  
  // Table Sales History
  tableSalesHistory: [],
  totalPaid: 0,
  
  // ============================================
  // PRODUCT ACTIONS
  // ============================================
  
  fetchProducts: async () => {
    // Solo la primera carga muestra "cargando"; las recargas en vivo no hacen parpadear la carta
    const first = get().products.length === 0;
    if (first) set({ isLoadingProducts: true });
    try {
      const products = await productsAPI.getAll();
      // Sin cambios no se reemplaza la lista (evita volver a dibujar y volver a pedir sugerencias)
      if (!first && JSON.stringify(products) === JSON.stringify(get().products)) { set({ isLoadingProducts: false }); return; }
      set({ products, isLoadingProducts: false });
    } catch (error) {
      console.error('Error fetching products:', error);
      set({ isLoadingProducts: false });
    }
  },
  
  fetchCategories: async () => {
    try {
      const categories = await productsAPI.getCategories();
      set({ categories });
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  },
  
  setSelectedCategory: (categoryId) => {
    set({ selectedCategory: categoryId });
  },
  
  // ============================================
  // CART ACTIONS
  // ============================================
  
  // Obtener el carrito actual basado en la mesa seleccionada
  getCurrentCart: () => {
    const { cartsByTable, selectedTable } = get();
    const tableId = selectedTable?.id || 'counter'; // 'counter' para ventas sin mesa
    return cartsByTable[tableId] || [];
  },
  
  selectCustomerForTable: (tableId, customer) => {
    const { customersByTable } = get();
    set({
      customersByTable: {
        ...customersByTable,
        [tableId]: customer
      }
    });
  },
  
  // ============================================
  // PEDIDOS PENDIENTES (Guardado temporal hasta pago + sincronización con servidor)
  // ============================================
  
  // Guardar pedido pendiente para una mesa
  savePendingOrder: async (tableId: string, items: CartItem[]) => {
    const { pendingOrdersByTable } = get();
    set({
      pendingOrdersByTable: {
        ...pendingOrdersByTable,
        [tableId]: items
      }
    });

    // Sincronización asíncrona segura con el servidor (sin bloquear la interfaz si está offline)
    try {
      if (items && items.length > 0) {
        const saved = await ordersAPI.save({
          tableId: tableId === 'counter' ? undefined : tableId,
          // El mostrador no tiene mesa: se actualiza siempre la misma comanda
          orderId: tableId === 'counter' ? get().serverOrderIdByTable.counter : undefined,
          ...(get().tableDetails[tableId] ? { guests: get().tableDetails[tableId].guests, label: get().tableDetails[tableId].label } : {}),
          items: items.map(item => ({
            productVariantId: item.variantId,
            clientItemId: item.id,
            quantity: item.quantity,
            unitPrice: item.unitPrice,
            notes: item.notes,
            removed: item.removed,
            status: item.isOrdered ? 'SENT' : 'DRAFT',
            roundNumber: item.roundNumber,
            sentAt: item.orderedAt,
          }))
        });
        if (saved?.id) {
          set({ serverOrderIdByTable: { ...get().serverOrderIdByTable, [tableId]: saved.id } });
        }
      }
      return true;
    } catch (err) {
      console.warn('Advertencia: no se pudo sincronizar el pedido activo con el servidor (modo offline):', err);
      return false;
    }
  },
  
  // Obtener pedido pendiente de una mesa
  getPendingOrder: (tableId: string) => {
    const { pendingOrdersByTable } = get();
    return pendingOrdersByTable[tableId] || [];
  },
  
  // Limpiar pedido pendiente (cuando se paga)
  clearPendingOrder: async (tableId: string) => {
    const { pendingOrdersByTable } = get();
    const newPending = { ...pendingOrdersByTable };
    delete newPending[tableId];
    set({ pendingOrdersByTable: newPending });

    // El mostrador no tiene mesa: su comanda se cierra por id (si alguna vez se envió a cocina)
    const serverIds = { ...get().serverOrderIdByTable };
    const target = tableId === 'counter' ? serverIds.counter : tableId;
    delete serverIds[tableId];
    set({ serverOrderIdByTable: serverIds });
    if (!target) return;

    try {
      await ordersAPI.close(target);
    } catch (err) {
      console.warn('Advertencia: no se pudo cerrar el pedido en el servidor:', err);
    }
  },

  resetCart: (tableId: string) => {
    if (get().tableDetails[tableId]) get().setTableDetails(tableId, null);
    const { cartsByTable, pendingOrdersByTable } = get();
    const newCarts = { ...cartsByTable };
    delete newCarts[tableId];
    const newPending = { ...pendingOrdersByTable };
    delete newPending[tableId];
    set({ cartsByTable: newCarts, pendingOrdersByTable: newPending, currentSale: null });
  },
  
  // Cargar pedido pendiente al carrito
  loadPendingOrderToCart: (tableId: string) => {
    const { pendingOrdersByTable, cartsByTable } = get();
    const pendingItems = pendingOrdersByTable[tableId] || [];
    
    if (pendingItems.length > 0) {
      set({
        cartsByTable: {
          ...cartsByTable,
          [tableId]: pendingItems
        }
      });
    }
  },
  
  addToCart: (product, variant, quantity = 1, notes) => {
    // Un producto pausado (sin existencias) no se puede pedir desde ningún equipo
    if (isProductPaused(product)) {
      toast.warning(t('pos:producto_pausado_desc'), t('pos:producto_pausado', { name: product.name }));
      return;
    }
    const { cartsByTable, selectedTable } = get();
    const tableId = selectedTable?.id || 'counter';
    const cart = cartsByTable[tableId] || [];
    
    // Check if item already exists in cart AND is NOT ordered yet
    const existingItemIndex = cart.findIndex(item => item.variantId === variant.id && !item.isOrdered);
    
    let updatedCart: CartItem[];
    if (existingItemIndex >= 0) {
      // Update quantity of the non-ordered item
      updatedCart = [...cart];
      updatedCart[existingItemIndex] = {
        ...updatedCart[existingItemIndex],
        quantity: updatedCart[existingItemIndex].quantity + quantity,
        total: (updatedCart[existingItemIndex].quantity + quantity) * updatedCart[existingItemIndex].unitPrice,
      };
    } else {
      // Add new item (always starts as NOT ordered)
      const newItem: CartItem = {
        id: newId(),
        productId: product.id,
        productName: product.name,
        variantId: variant.id,
        variantName: variant.name,
        sku: variant.sku,
        quantity,
        unitPrice: variant.price,
        total: quantity * variant.price,
        notes,
        isOrdered: false,
      };
      updatedCart = [...cart, newItem];
    }
    
    set({ 
      cartsByTable: {
        ...cartsByTable,
        [tableId]: updatedCart
      }
    });
  },
  
  updateCartItemQuantity: (itemId, quantity) => {
    const { cartsByTable, selectedTable } = get();
    const tableId = selectedTable?.id || 'counter';
    const cart = cartsByTable[tableId] || [];
    
    if (quantity <= 0) {
      get().removeFromCart(itemId);
      return;
    }
    
    const updatedCart = cart.map(item => 
      item.id === itemId 
        ? { ...item, quantity, total: quantity * item.unitPrice }
        : item
    );
    
    set({ 
      cartsByTable: {
        ...cartsByTable,
        [tableId]: updatedCart
      }
    });
  },
  
  updateCartItemNotes: (itemId, notes, removed) => {
    const { cartsByTable, selectedTable } = get();
    const tableId = selectedTable?.id || 'counter';
    const cart = cartsByTable[tableId] || [];
    
    const updatedCart = cart.map(item => 
      item.id === itemId 
        ? { ...item, notes, removed: removed ?? item.removed }
        : item
    );
    
    set({ 
      cartsByTable: {
        ...cartsByTable,
        [tableId]: updatedCart
      }
    });
  },
  
  removeFromCart: (itemId) => {
    const { cartsByTable, selectedTable } = get();
    const tableId = selectedTable?.id || 'counter';
    const cart = cartsByTable[tableId] || [];
    
    const updatedCart = cart.filter(item => item.id !== itemId);
    
    set({ 
      cartsByTable: {
        ...cartsByTable,
        [tableId]: updatedCart
      }
    });
  },
  
  clearCart: () => {
    const { cartsByTable, selectedTable } = get();
    const tableId = selectedTable?.id || 'counter';
    const cart = cartsByTable[tableId] || [];
    
    // Solo mantener productos que YA están ordenados
    const newCarts = { ...cartsByTable };
    newCarts[tableId] = cart.filter(item => item.isOrdered);
    
    set({ 
      cartsByTable: newCarts,
      currentSale: null 
    });
  },
  
  // Get total pending (cart total) - el precio ya incluye IVA
  getCartTotal: () => {
    const cart = get().getCurrentCart();
    const total = cart.reduce((sum, item) => sum + item.total, 0);
    // IVA ya incluido en precio – ya no lo desglosamos
    return { subtotal: total, tax: 0, total };
  },
  
  // Get table account totals (paid + pending) - precios ya incluyen IVA
  getTableAccountTotal: () => {
    const cart = get().getCurrentCart();
    const { totalPaid } = get();
    const pendingTotal = cart.reduce((sum, item) => sum + item.total, 0);
    return { 
      paid: totalPaid, 
      pending: pendingTotal, 
      total: totalPaid + pendingTotal 
    };
  },
  
  // ============================================
  // TABLE ACTIONS
  // ============================================
  
  fetchTables: async () => {
    set({ isLoadingTables: true });
    try {
      const tables = await tablesAPI.getAll();
      set({ tables, isLoadingTables: false });
    } catch (error) {
      console.error('Error fetching tables:', error);
      set({ isLoadingTables: false });
    }
  },
  
  selectTable: (table) => {
    set({ selectedTable: table });
  },
  
  loadTableSale: async (tableId) => {
    try {
      set({ 
        currentTableId: tableId, 
        currentSale: null,
        tableSalesHistory: [],
        totalPaid: 0
      });

      // Intentar cargar pedido activo desde el servidor (permite multi-dispositivo y persistencia real)
      try {
        const serverOrder = await ordersAPI.getByTable(tableId);
        if (serverOrder && serverOrder.items && serverOrder.items.length > 0) {
          const mappedItems: CartItem[] = serverOrder.items
            .filter((it: any) => !it.isCancelled)
            .map((it: any) => ({
              id: it.clientItemId || it.id,
              productId: it.productVariant?.productId || it.productVariant?.product?.id,
              productName: it.productVariant?.product?.name || t('pos:producto'),
              variantId: it.productVariantId,
              variantName: it.productVariant?.name || t('pos:estandar'),
              sku: it.productVariant?.sku || '',
              quantity: it.quantity,
              unitPrice: it.unitPrice,
              total: it.quantity * it.unitPrice,
              notes: it.notes || '',
              removed: parseIngredients(it.removed),
              isOrdered: it.status !== 'DRAFT',
              roundNumber: it.roundNumber || undefined,
              orderedAt: it.sentAt || undefined,
            }));
          const { cartsByTable, pendingOrdersByTable } = get();
          set({
            cartsByTable: {
              ...cartsByTable,
              [tableId]: mappedItems
            },
            pendingOrdersByTable: {
              ...pendingOrdersByTable,
              [tableId]: mappedItems
            }
          });
        }
      } catch (err) {
        // En caso de modo offline, Zustand conserva localmente el carrito
        console.warn('No se pudo consultar el pedido activo del servidor, usando local:', err);
      }
    } catch (error) {
      console.error('Error loading table sale:', error);
    }
  },
  
  occupyTable: async (tableId) => {
    try {
      await tablesAPI.occupy(tableId);
      await get().fetchTables();
    } catch (error) {
      console.error('Error occupying table:', error);
      throw error;
    }
  },
  
  releaseTable: async (tableId, cancellation) => {
    try {
      await tablesAPI.release(tableId, cancellation);
      try {
        await ordersAPI.close(tableId);
      } catch (e) {
        // Ignore offline error
      }
      await get().fetchTables();
      // Limpiar solo el carrito de esa mesa
      const { cartsByTable, pendingOrdersByTable } = get();
      const newCarts = { ...cartsByTable };
      delete newCarts[tableId];
      const newPending = { ...pendingOrdersByTable };
      delete newPending[tableId];
      set({ selectedTable: null, currentTableId: null, currentSale: null, cartsByTable: newCarts, pendingOrdersByTable: newPending });
    } catch (error) {
      console.error('Error releasing table:', error);
      throw error;
    }
  },
  
  orderTable: async (tableId) => {
    try {
      const res = await fetch(`${API_URL}/tables/${tableId}/order`, {
        method: 'PATCH',
        headers: headers()
      });
      if (!res.ok) throw responseError(res.status, await res.json().catch(() => null));
      // Las líneas ya se guardan en el servidor marcadas como enviadas (savePendingOrder)
      await get().fetchTables();
    } catch (error) {
      console.error('Error ordering table:', error);
      throw error;
    }
  },
  
  setTablePending: async (tableId) => {
    try {
      await tablesAPI.setPending(tableId);
      await get().fetchTables();
    } catch (error) {
      console.error('Error setting table pending:', error);
      throw error;
    }
  },
  
  closeTable: async (tableId) => {
    try {
      await tablesAPI.closeTable(tableId);
      try {
        await ordersAPI.close(tableId);
      } catch (e) {
        // Ignore offline error
      }
      await get().fetchTables();
      // Limpiar solo el carrito de esa mesa
      const { cartsByTable, pendingOrdersByTable } = get();
      const newCarts = { ...cartsByTable };
      delete newCarts[tableId];
      const newPending = { ...pendingOrdersByTable };
      delete newPending[tableId];
      set({ selectedTable: null, currentTableId: null, currentSale: null, cartsByTable: newCarts, pendingOrdersByTable: newPending });
    } catch (error) {
      console.error('Error closing table:', error);
      throw error;
    }
  },
  
  // ============================================
  // CASH SESSION ACTIONS
  // ============================================
  
  fetchOpenSession: async () => {
    set({ isLoadingSession: true });
    try {
      const session = await cashSessionAPI.getOpen();
      set({ cashSession: session, isLoadingSession: false });
    } catch (error) {
      console.error('Error fetching session:', error);
      set({ isLoadingSession: false });
    }
  },
  
  openCashSession: async (initialBalance, notes) => {
    try {
      const session = await cashSessionAPI.open({ initialBalance, notes });
      set({ cashSession: session });
    } catch (error) {
      console.error('Error opening session:', error);
      throw error;
    }
  },
  
  closeCashSession: async (countedBalance, notes) => {
    const { cashSession } = get();
    if (!cashSession) throw new Error(t('pos:no_hay_sesion_de_caja_abierta'));
    
    try {
      await cashSessionAPI.close(cashSession.id, { countedBalance, notes });
      set({ cashSession: null });
    } catch (error) {
      console.error('Error closing session:', error);
      throw error;
    }
  },
  
  addIncome: async (amount, motive, description) => {
    const { cashSession } = get();
    if (!cashSession) throw new Error(t('pos:no_hay_sesion_de_caja_abierta'));
    
    try {
      const session = await cashSessionAPI.addIncome(cashSession.id, amount, motive, description);
      set({ cashSession: session });
    } catch (error) {
      console.error('Error adding income:', error);
      throw error;
    }
  },
  
  addExpense: async (amount, motive, description, categoryId) => {
    const { cashSession } = get();
    if (!cashSession) throw new Error(t('pos:no_hay_sesion_de_caja_abierta'));
    
    try {
      const session = await cashSessionAPI.addExpense(cashSession.id, amount, motive, description, categoryId);
      set({ cashSession: session });
    } catch (error) {
      console.error('Error adding expense:', error);
      throw error;
    }
  },

  cancelIncome: async (incomeId, reason) => {
    const { cashSession } = get();
    if (!cashSession) throw new Error(t('pos:no_hay_sesion_de_caja_abierta'));
    
    try {
      const session = await cashSessionAPI.cancelIncome(cashSession.id, incomeId, reason);
      set({ cashSession: session });
    } catch (error) {
      console.error('Error cancelling income:', error);
      throw error;
    }
  },

  cancelExpense: async (expenseId, reason) => {
    const { cashSession } = get();
    if (!cashSession) throw new Error(t('pos:no_hay_sesion_de_caja_abierta'));
    
    try {
      const session = await cashSessionAPI.cancelExpense(cashSession.id, expenseId, reason);
      set({ cashSession: session });
    } catch (error) {
      console.error('Error cancelling expense:', error);
      throw error;
    }
  },
  
  // ============================================
  // SALE ACTIONS
  // ============================================
  
  createSale: async (paymentMethod = 'CASH', customerId?: string, discountPct?: number, payments?: any[]) => {
    const cart = get().getCurrentCart();
    const { currentTableId, cashSession, selectedTable, cartsByTable, customersByTable } = get();
    
    if (cart.length === 0) throw new Error(t('pos:el_carrito_esta_vacio'));
    if (!cashSession) throw new Error(t('pos:debe_abrir_un_arqueo_de_caja_antes'));
    
    try {
      const sale = await salesAPI.create({
        tableId: currentTableId || selectedTable?.id || undefined,
        cashSessionId: cashSession?.id,
        customerId: customerId || undefined,
        discountPct: discountPct || 0,
        items: cart.map(item => ({
          productVariantId: item.variantId,
          quantity: item.quantity,
          unitPrice: item.unitPrice,
          notes: item.notes,
          removed: item.removed,
        })),
        paymentMethod,
        payments,
        taxRate: 0,
      });
      
      // Limpiar el carrito de la mesa actual
      const tableId = selectedTable?.id || 'counter';
      const newCarts = { ...cartsByTable };
      newCarts[tableId] = [];
      
      // Limpiar el cliente seleccionado de la mesa actual
      const newCustomers = { ...customersByTable };
      delete newCustomers[tableId];
      
      set({ cartsByTable: newCarts, customersByTable: newCustomers, currentSale: null });
      
      return sale;
    } catch (error) {
      console.error('Error creating sale:', error);
      throw error;
    }
  },
  
  completeSale: async (saleId) => {
    try {
      await salesAPI.complete(saleId);
      const { currentTableId } = get();
      if (currentTableId) {
        await get().releaseTable(currentTableId);
      }
    } catch (error) {
      console.error('Error completing sale:', error);
      throw error;
    }
  },
  
  cancelSale: async (saleId) => {
    try {
      await salesAPI.cancel(saleId);
      // Limpiar el carrito de la mesa actual
      const { cartsByTable, selectedTable } = get();
      const tableId = selectedTable?.id || 'counter';
      const newCarts = { ...cartsByTable };
      newCarts[tableId] = [];
      set({ cartsByTable: newCarts, currentSale: null });
      await get().fetchOpenSession();
    } catch (error) {
      console.error('Error cancelling sale:', error);
      throw error;
    }
  },
  
  // Anular un item de venta
  cancelSaleItem: async (itemId, reason) => {
    try {
      await salesAPI.cancelItem(itemId, reason);
      // Recargar la venta para ver los cambios
      const { currentSale } = get();
      if (currentSale) {
        const updatedSale = await salesAPI.getById(currentSale.id);
        set({ currentSale: updatedSale });
      }
    } catch (error) {
      console.error('Error cancelling item:', error);
      throw error;
    }
  },
  
  // Agregar pago/abono a una venta
  addPayment: async (saleId, amount, paymentMethod) => {
    const { cashSession } = get();
    if (!cashSession) throw new Error(t('pos:no_hay_sesion_de_caja_abierta'));
    
    try {
      await salesAPI.addPayment({
        saleId,
        amount,
        paymentMethod,
        cashSessionId: cashSession.id,
      });
      
      // Recargar la venta para ver los cambios
      const updatedSale = await salesAPI.getById(saleId);
      set({ currentSale: updatedSale });
      await get().fetchOpenSession();
    } catch (error) {
      console.error('Error adding payment:', error);
      throw error;
    }
  },
  
  // Obtener pagos de una venta
  getSalePayments: async (saleId) => {
    try {
      return await salesAPI.getPayments(saleId);
    } catch (error) {
      console.error('Error getting payments:', error);
      return [];
    }
  },
  
  // Obtener total pagado de una venta
  getSalePaidTotal: async (saleId) => {
    try {
      const result = await salesAPI.getPaidTotal(saleId);
      return result.paid || 0;
    } catch (error) {
      console.error('Error getting paid total:', error);
      return 0;
    }
  },
  
  // ============================================
  // UI ACTIONS
  // ============================================
  
  openVariantModal: (product) => {
    set({ isVariantModalOpen: true, selectedProductForVariant: product });
  },
  
  closeVariantModal: () => {
    set({ isVariantModalOpen: false, selectedProductForVariant: null });
  },
  
  setCartAsOrdered: (tableId: string) => {
    const { cartsByTable } = get();
    const cart = cartsByTable[tableId] || [];
    const currentRounds = cart.filter(i => i.isOrdered && i.roundNumber).map(i => i.roundNumber!);
    const nextRound = (currentRounds.length > 0 ? Math.max(...currentRounds) : 0) + 1;
    const nowIso = new Date().toISOString();

    const updatedCart = cart.map(item => {
      if (item.isOrdered) return item;
      return {
        ...item,
        isOrdered: true,
        orderedAt: item.orderedAt || nowIso,
        roundNumber: item.roundNumber || nextRound
      };
    });

    set({
      cartsByTable: {
        ...cartsByTable,
        [tableId]: updatedCart
      }
    });
  },

  cancelCartItemPartial: (
    tableId: string,
    itemId: string,
    quantityToCancel: number,
    reason: string,
    comments?: string,
    adminName?: string,
    wasteDestination?: 'waste' | 'restock'
  ) => {
    const { cartsByTable } = get();
    const cart = cartsByTable[tableId] || [];
    const itemIndex = cart.findIndex(i => i.id === itemId);
    if (itemIndex === -1) return;

    const item = cart[itemIndex];
    const cancellationRecord = {
      id: `canc-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      quantity: quantityToCancel,
      reason,
      comments,
      cancelledAt: new Date().toISOString(),
      cancelledBy: adminName || t('pos:administrador'),
      wasteDestination: wasteDestination || 'waste'
    };

    let updatedCart: CartItem[];

    if (quantityToCancel >= item.quantity) {
      // Si se cancela toda la línea, se retira del pedido activo
      updatedCart = cart.filter(i => i.id !== itemId);
    } else {
      // Cancelación parcial: se decrementa la cantidad activa y se guarda el historial
      const remainingQty = item.quantity - quantityToCancel;
      const existingCancellations = item.cancellations || [];
      updatedCart = cart.map(i =>
        i.id === itemId
          ? {
              ...i,
              quantity: remainingQty,
              total: remainingQty * i.unitPrice,
              cancellations: [...existingCancellations, cancellationRecord]
            }
          : i
      );
    }

    set({
      cartsByTable: {
        ...cartsByTable,
        [tableId]: updatedCart
      }
    });
  },
}), {
  name: 'lantify-pos-orders',
  // Solo se persiste el trabajo en curso (pedidos); catálogo, mesas y caja se vuelven a pedir al servidor
  partialize: (state) => ({
    cartsByTable: state.cartsByTable,
    pendingOrdersByTable: state.pendingOrdersByTable,
    customersByTable: state.customersByTable,
    tableDetails: state.tableDetails,
    serverOrderIdByTable: state.serverOrderIdByTable,
  }),
}));