// ============================================
// GUIDE - Motor de recorridos (driver.js)
// ============================================

import { driver, DriveStep } from 'driver.js';
import 'driver.js/dist/driver.css';
import { t } from '../i18n';
import { getTour, GuideModule, Role, TOURS } from './tours';

export const START_TOUR_EVENT = 'lantify:start-tour';

const userId = () => {
  try {
    return JSON.parse(localStorage.getItem('user') || '{}').id || 'anon';
  } catch {
    return 'anon';
  }
};
const seenKey = () => `lantify.tours.seen.${userId()}`;
const mutedKey = () => `lantify.tours.muted.${userId()}`;

const readSeen = (): string[] => {
  try {
    return JSON.parse(localStorage.getItem(seenKey()) || '[]');
  } catch {
    return [];
  }
};

export const hasSeenTour = (id: string) => readSeen().includes(id);

export const markTourSeen = (id: string) => {
  try {
    const seen = new Set(readSeen());
    seen.add(id);
    localStorage.setItem(seenKey(), JSON.stringify([...seen]));
  } catch {
    // sin almacenamiento: se volverá a ofrecer
  }
};

/** "No volver a mostrar": ya no se ofrecen recorridos automáticamente a este usuario */
export const areToursMuted = () => {
  try {
    return localStorage.getItem(mutedKey()) === '1';
  } catch {
    return false;
  }
};

export const muteTours = () => {
  try {
    localStorage.setItem(mutedKey(), '1');
  } catch {
    // sin almacenamiento
  }
};

/** El recorrido que se ofrece la primera vez que el usuario entra a un módulo */
export const pendingTourFor = (module: GuideModule, role: string) => {
  if (areToursMuted()) return null;
  return TOURS.find((tour) => tour.module === module && tour.roles.includes(role as Role) && !hasSeenTour(tour.id)) || null;
};

// Un nombre simple ("cart-pay") es un data-guide; cualquier otra cosa, un selector CSS
const resolve = (element: string) => {
  try {
    return /^[a-z0-9-]+$/.test(element) ? document.querySelector(`[data-guide="${element}"]`) : document.querySelector(element);
  } catch {
    return null;
  }
};

const isVisible = (el: Element | null) => {
  if (!el) return false;
  const rect = el.getBoundingClientRect();
  return rect.width > 0 && rect.height > 0;
};

export const startTour = (id: string, role = 'WAITER') => {
  const tour = getTour(id);
  if (!tour) return false;

  let missing = false;
  const steps: DriveStep[] = [];
  for (const step of tour.steps) {
    if (step.roles && !step.roles.includes(role as Role)) continue;
    const popover = { title: t(`guide:${step.key}_t`), description: t(`guide:${step.key}_d`) };
    if (!step.element) {
      steps.push({ popover });
      continue;
    }
    const el = resolve(step.element);
    if (!isVisible(el)) {
      missing = true;
      continue;
    }
    steps.push({ element: el as Element, popover });
  }
  if (missing && tour.missingHintKey) {
    steps.push({ popover: { title: t(`guide:${tour.missingHintKey}_t`), description: t(`guide:${tour.missingHintKey}_d`) } });
  }
  if (steps.length === 0) return false;

  const tourDriver = driver({
    steps,
    showProgress: true,
    allowClose: true,
    smoothScroll: true,
    stagePadding: 6,
    stageRadius: 12,
    popoverClass: 'lantify-tour',
    progressText: t('guide:progreso', { current: '{{current}}', total: '{{total}}' }),
    nextBtnText: t('guide:siguiente'),
    prevBtnText: t('guide:anterior'),
    doneBtnText: t('guide:entendido'),
    onDestroyed: () => markTourSeen(id),
  });
  tourDriver.drive();
  return true;
};

/** Cualquier componente (ayuda, asistente) puede pedir un recorrido sin conocer al resto */
export const requestTour = (id: string) => window.dispatchEvent(new CustomEvent(START_TOUR_EVENT, { detail: { id } }));
