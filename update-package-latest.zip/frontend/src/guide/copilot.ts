// ============================================
// GUIDE - Cliente del asistente con IA (Lantify Copilot)
// ============================================
// Pasa por el servidor local (/api/ai/chat), que firma la consulta con la licencia
// del negocio y la envía al Worker (Gemini y, si falla, Groq). El navegador nunca
// tiene una clave. Privacidad: solo se envía la pregunta, el idioma,
// la pantalla, el rol, el tipo de negocio y fragmentos del manual de ayuda.
// Nunca ventas, clientes, precios ni datos del negocio.

import { API_URL } from '../config';
import { articlesFor, searchArticles } from '../help';
import { toursForRole, GuideModule } from './tours';

export interface ChatTurn {
  role: 'user' | 'assistant';
  content: string;
}

export interface CopilotReply {
  answer: string;
  tourId: string | null;
  provider?: string;
}

export type CopilotErrorCode = 'AI_NOT_CONFIGURED' | 'AI_OFFLINE' | 'AI_QUOTA' | 'AI_UNAVAILABLE' | 'AI_UNAUTHORIZED' | 'AI_TIMEOUT' | 'AI_PLAN_REQUIRED' | 'AI_MONTHLY_QUOTA';

export class CopilotError extends Error {
  constructor(public code: CopilotErrorCode) {
    super(code);
    this.name = CopilotError.name;
  }
}

// El servidor local sabe si hay licencia o clave para el asistente
let availability: Promise<boolean> | null = null;
export const isCopilotConfigured = (): Promise<boolean> => {
  availability ||= fetch(`${API_URL}/cloud/status`)
    .then((r) => r.json())
    .then((s) => !!s.aiAvailable)
    .catch(() => false);
  return availability;
};

const MAX_QUESTION = 500;
const TIMEOUT_MS = 25000;

export async function askCopilot(input: {
  question: string;
  lang: 'es' | 'en';
  module: GuideModule;
  role: string;
  businessType?: string;
  history: ChatTurn[];
}): Promise<CopilotReply> {
  if (typeof navigator !== 'undefined' && navigator.onLine === false) throw new CopilotError('AI_OFFLINE');

  const question = input.question.trim().slice(0, MAX_QUESTION);
  // El manual es la base de conocimiento: se envían los artículos más relacionados
  const context = searchArticles(question, articlesFor(input.lang, input.role), 3).map((a) => ({
    id: a.id,
    title: a.title,
    text: a.body.slice(0, 1800),
    tourId: a.tourId || null,
  }));
  const tours = toursForRole(input.role).map((tour) => tour.id);

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  let res: Response;
  try {
    // El interceptor agrega el token de la sesión local
    res = await fetch(`${API_URL}/ai/chat`, {
      method: 'POST',
      signal: controller.signal,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        question,
        lang: input.lang,
        module: input.module,
        role: input.role,
        businessType: input.businessType || null,
        history: input.history.slice(-6).map((h) => ({ role: h.role, content: h.content.slice(0, 800) })),
        context,
        tours,
      }),
    });
  } catch {
    if (controller.signal.aborted) throw new CopilotError('AI_TIMEOUT');
    // Con red pero sin respuesta del Worker: el problema es del asistente, no de internet
    throw new CopilotError(typeof navigator !== 'undefined' && navigator.onLine === false ? 'AI_OFFLINE' : 'AI_UNAVAILABLE');
  } finally {
    clearTimeout(timer);
  }

  const errorBody = res.ok ? null : await res.clone().json().catch(() => null);
  if (errorBody?.code === 'AI_NOT_CONFIGURED') throw new CopilotError('AI_NOT_CONFIGURED');
  // El plan no incluye el asistente: lo dice la nube (AI_PLAN_REQUIRED) o el servidor local (402)
  if (errorBody?.code === 'AI_PLAN_REQUIRED' || errorBody?.code === 'PLAN_FEATURE_REQUIRED') throw new CopilotError('AI_PLAN_REQUIRED');
  if (errorBody?.code === 'AI_MONTHLY_QUOTA') throw new CopilotError('AI_MONTHLY_QUOTA');
  if (res.status === 401 || res.status === 403) throw new CopilotError('AI_UNAUTHORIZED');
  if (res.status === 429) throw new CopilotError('AI_QUOTA');
  if (!res.ok) throw new CopilotError('AI_UNAVAILABLE');

  const data = await res.json().catch(() => null);
  if (!data || typeof data.answer !== 'string') throw new CopilotError('AI_UNAVAILABLE');
  return {
    answer: data.answer,
    tourId: tours.includes(data.tourId) ? data.tourId : null,
    provider: data.provider,
  };
}
