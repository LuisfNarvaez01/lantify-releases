// ============================================
// GUIDE - Estado compartido de la ayuda (pantalla actual, panel abierto)
// ============================================

import { create } from 'zustand';
import type { GuideModule } from './tours';

type HelpTab = 'help' | 'assistant';

interface GuideState {
  module: GuideModule;
  helpOpen: boolean;
  helpTab: HelpTab;
  articleId: string | null;
  setModule: (m: GuideModule) => void;
  openHelp: (tab?: HelpTab, articleId?: string | null) => void;
  closeHelp: () => void;
  setTab: (tab: HelpTab) => void;
  setArticle: (id: string | null) => void;
}

export const useGuideStore = create<GuideState>((set) => ({
  module: 'pos',
  helpOpen: false,
  helpTab: 'help',
  articleId: null,
  setModule: (module) => set({ module }),
  openHelp: (tab = 'help', articleId = null) => set({ helpOpen: true, helpTab: tab, articleId }),
  closeHelp: () => set({ helpOpen: false }),
  setTab: (helpTab) => set({ helpTab }),
  setArticle: (articleId) => set({ articleId }),
}));
