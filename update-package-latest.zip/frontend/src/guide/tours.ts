// ============================================
// GUIDE - Recorridos guiados (funcionan sin internet)
// ============================================
// Cada paso apunta a un atributo data-guide="..." estable, no a clases de estilo,
// para que un cambio visual no rompa el recorrido. Un paso cuyo elemento no está
// en pantalla se omite (por ejemplo, el cobro cuando el pedido está vacío).

import { t } from '../i18n';

export type GuideModule = 'pos' | 'tables' | 'cash' | 'sales' | 'settings' | 'other';
export type Role = 'ADMIN' | 'CASHIER' | 'WAITER';

export interface TourStep {
  /** Nombre en data-guide (solo letras, números y guiones) o un selector CSS */
  element?: string;
  key: string; // guide:<key>_t (título) y guide:<key>_d (texto)
  roles?: Role[];
}

export interface TourDef {
  id: string;
  module: GuideModule;
  roles: Role[];
  steps: TourStep[];
  /** Paso final si faltaron elementos (p. ej. "agrega un producto para ver el cobro") */
  missingHintKey?: string;
}

const ALL: Role[] = ['ADMIN', 'CASHIER', 'WAITER'];
const CASH: Role[] = ['ADMIN', 'CASHIER'];

export const TOURS: TourDef[] = [
  {
    id: 'first-order',
    module: 'pos',
    roles: ALL,
    missingHintKey: 'first_order_missing',
    steps: [
      { key: 'first_order_welcome' },
      { element: 'main-nav', key: 'first_order_nav' },
      { element: 'product-search', key: 'first_order_search' },
      { element: 'product-categories', key: 'first_order_categories' },
      { element: 'product-grid', key: 'first_order_grid' },
      { element: 'table-sidebar', key: 'first_order_place' },
      { element: 'cart-customer', key: 'first_order_customer' },
      { element: 'cart-items', key: 'first_order_items' },
      { element: 'cart-send-kitchen', key: 'first_order_kitchen' },
      { element: 'cart-prebill', key: 'first_order_prebill' },
      { element: 'cart-total', key: 'first_order_total' },
      { element: 'cart-pay', key: 'first_order_pay', roles: CASH },
      { element: 'help-button', key: 'first_order_help' },
    ],
  },
  {
    id: 'tables',
    module: 'pos',
    roles: ALL,
    steps: [
      { element: 'table-sidebar', key: 'tables_list' },
      { element: 'cart-items', key: 'tables_rounds' },
      { element: 'cart-send-kitchen', key: 'tables_send' },
      { key: 'tables_cancel' },
    ],
  },
  {
    id: 'cash',
    module: 'cash',
    roles: CASH,
    steps: [
      { element: 'cash-open', key: 'cash_open' },
      { element: 'cash-summary', key: 'cash_summary' },
      { element: 'cash-movement', key: 'cash_movement' },
      { element: 'cash-history', key: 'cash_history' },
      { element: 'cash-close', key: 'cash_close' },
    ],
  },
  {
    id: 'sales',
    module: 'sales',
    roles: CASH,
    steps: [
      { element: 'sales-stats', key: 'sales_stats' },
      { element: 'sales-filters', key: 'sales_filters' },
      { key: 'sales_detail' },
    ],
  },
  {
    id: 'settings',
    module: 'settings',
    roles: ['ADMIN'],
    steps: [
      { element: 'settings-tabs', key: 'settings_tabs' },
      { element: '#bs-name', key: 'settings_business' },
      { element: 'label[for="bs-tip"]', key: 'settings_tip' },
      { key: 'settings_wizard' },
    ],
  },
];

export const getTour = (id: string) => TOURS.find((tour) => tour.id === id);

export const tourTitle = (id: string) => t(`guide:tour_${id.replace(/-/g, '_')}`);

export const toursForRole = (role: string) => TOURS.filter((tour) => tour.roles.includes(role as Role));
