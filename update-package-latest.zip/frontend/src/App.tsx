import { useState, useEffect } from 'react';
import { Login } from './components/Login';
import { Layout } from './components/layout/Layout';
import { authAPI, versionAPI } from './services/api';
import { ChangePasswordScreen } from './components/ChangePasswordScreen';
import { SESSION_EXPIRED_EVENT, PASSWORD_CHANGE_EVENT } from './services/authFetch';
import { bindThemeToUser } from './shared/theme/themeMode';
import { bindLanguageToUser, useLanguage } from './i18n';
import { UpdateModal } from './components/common/UpdateModal';
import { ToastContainer } from './components/common/ToastContainer';
import { DialogHost } from './components/common/DialogHost';
import { PlanLockHost } from './components/common/PlanLocked';
import { usePlanStore } from './shared/plan';
import { OnboardingWizard } from './components/onboarding/OnboardingWizard';
import { usePrintSettings } from './shared/printSettings';
import { usePermissions } from './shared/permissions';
import { useBusinessStore, OPEN_ONBOARDING_EVENT } from './shared/business';
import { businessAPI } from './services/api';
import { toast } from './shared/toast';
import { t } from './i18n';
import { useSetupGuide } from './shared/setupGuide';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);
  const [user, setUser] = useState<any>(null);
  const [updateData, setUpdateData] = useState<any>(null);
  const business = useBusinessStore((s) => s.settings);
  const businessLoaded = useBusinessStore((s) => s.loaded);
  const loadBusiness = useBusinessStore((s) => s.load);
  const setBusiness = useBusinessStore((s) => s.setSettings);
  const [wizardOpen, setWizardOpen] = useState(false);

  const checkVersionUpdate = async () => {
    try {
      const res = await versionAPI.checkUpdate();
      if (res && res.updateAvailable) {
        setUpdateData(res);
      }
    } catch {
      // Modo silencioso: no interrumpir al usuario si no hay conexión
    }
  };

  useEffect(() => {
    // Verificar si hay token guardado
    const token = localStorage.getItem('token');
    const savedUser = localStorage.getItem('user');
    
    if (token && savedUser) {
      // Verificar token con el backend
      authAPI.verify()
        .then((res: any) => {
          // El rol y el estado vienen del servidor, no de lo guardado en el navegador
          setUser({ ...JSON.parse(savedUser), ...(res?.user || {}), mustChangePassword: !!res?.mustChangePassword });
          setIsAuthenticated(true);
          checkVersionUpdate();
        })
        .catch(() => {
          // Token inválido, limpiar
          localStorage.removeItem('token');
          localStorage.removeItem('user');
          setIsAuthenticated(false);
        });
    } else {
      setIsAuthenticated(false);
    }
  }, []);

  const handleLogin = (userData: any) => {
    setUser(userData);
    setIsAuthenticated(true);
    checkVersionUpdate();
  };

  // Cambiar de idioma re-renderiza todo el árbol (sin perder estado: pantalla abierta, carrito...)
  useLanguage();

  // Cada usuario conserva su propio modo claro/oscuro e idioma
  useEffect(() => {
    bindThemeToUser(user?.id || null);
    bindLanguageToUser(user?.id || null);
  }, [user?.id]);

  // Datos del negocio compartidos por todos los equipos (ticket, impuestos, módulos)
  useEffect(() => {
    if (isAuthenticated && !user?.mustChangePassword) {
      loadBusiness();
      // Impresoras y papel: listos antes del primer cobro
      usePrintSettings.getState().load();
      usePermissions.getState().load();
      if (user?.role === 'ADMIN') useSetupGuide.getState().load();
    }
  }, [isAuthenticated, user?.mustChangePassword, loadBusiness]);

  // Plan y estado de pago (licencia). El servidor renueva la licencia cada 6 h; aquí se relee cada 30 min
  const loadPlan = usePlanStore((s) => s.load);
  const clearPlan = usePlanStore((s) => s.clear);
  useEffect(() => {
    if (!isAuthenticated || user?.mustChangePassword) return;
    loadPlan();
    const timer = setInterval(loadPlan, 30 * 60 * 1000);
    return () => clearInterval(timer);
  }, [isAuthenticated, user?.mustChangePassword, loadPlan]);

  useEffect(() => {
    const open = () => setWizardOpen(true);
    window.addEventListener(OPEN_ONBOARDING_EVENT, open);
    return () => window.removeEventListener(OPEN_ONBOARDING_EVENT, open);
  }, []);

  const handleLogout = () => {
    setWizardOpen(false);
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setUser(null);
    setIsAuthenticated(false);
    setUpdateData(null);
    clearPlan();
  };

  // El interceptor de fetch avisa si el servidor revocó la sesión o exige cambiar la contraseña
  useEffect(() => {
    const onExpired = () => handleLogout();
    const onPasswordChange = () => setUser((u: any) => (u ? { ...u, mustChangePassword: true } : u));
    window.addEventListener(SESSION_EXPIRED_EVENT, onExpired);
    window.addEventListener(PASSWORD_CHANGE_EVENT, onPasswordChange);
    return () => {
      window.removeEventListener(SESSION_EXPIRED_EVENT, onExpired);
      window.removeEventListener(PASSWORD_CHANGE_EVENT, onPasswordChange);
    };
  }, []);

  // Mientras verifica, mostrar pantalla de carga
  if (isAuthenticated === null) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-950">
        <div className="flex flex-col items-center gap-6">
          <img src="/logo-lantify-white.svg" alt="Lantify POS" className="h-12 w-auto animate-pulse" />
          <div className="animate-spin rounded-full h-8 w-8 border-2 border-slate-700 border-t-blue-500"></div>
          <span className="text-xs font-semibold tracking-wider uppercase text-slate-400">Iniciando Lantify POS...</span>
        </div>
      </div>
    );
  }

  // Si no está autenticado, mostrar login
  if (!isAuthenticated) {
    return <Login onLogin={handleLogin} />;
  }

  // Cuenta con clave de fábrica o restablecida por un admin: primero cambiar la contraseña
  if (user?.mustChangePassword) {
    return <ChangePasswordScreen user={user} onChanged={(u) => setUser(u)} onLogout={handleLogout} />;
  }

  // El asistente se abre solo la primera vez. Si se pospone, queda en Configuración → Negocio.
  const needsOnboarding = user?.role === 'ADMIN' && businessLoaded && !!business
    && !business.onboardingCompletedAt && !business.onboardingDismissedAt;
  if (wizardOpen || needsOnboarding) {
    return (
      <>
        <OnboardingWizard
          user={user}
          current={business}
          onDone={(settings) => {
            setWizardOpen(false);
            // Lo básico quedó listo: sigue la guía con lo demás que va a usar
            useSetupGuide.getState().load().then(() => useSetupGuide.getState().requestOpen());
            toast.success(t('onboarding:listo_desc', { name: settings.businessName }), t('onboarding:listo'));
          }}
          onSkip={() => {
            setWizardOpen(false);
            if (business && !business.onboardingCompletedAt && !business.onboardingDismissedAt) {
              // Se marca de inmediato para no volver a mostrarlo; el servidor lo recuerda para siempre
              setBusiness({ ...business, onboardingDismissedAt: new Date().toISOString() });
              businessAPI.dismissOnboarding().then(setBusiness).catch(() => { /* se reintenta en el próximo ingreso */ });
              toast.info(t('onboarding:pospuesto_desc'), t('onboarding:pospuesto'));
            }
          }}
        />
        <ToastContainer />
        <DialogHost />
      </>
    );
  }

  // Si está autenticado, mostrar la app
  return (
    <>
      <Layout user={user} onLogout={handleLogout} />
      <ToastContainer />
      <DialogHost />
      <PlanLockHost />
      {updateData && (
        <UpdateModal
          updateData={updateData}
          onClose={() => setUpdateData(null)}
        />
      )}
    </>
  );
}

export default App;