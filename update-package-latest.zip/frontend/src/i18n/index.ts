// ============================================
// i18n - Idiomas de la interfaz (español / inglés)
// ============================================
// Uso en cualquier archivo:  import { t } from '../i18n';  t('pos:cobrar')
// Los textos viven en src/locales/<idioma>/<namespace>.json. Las claves que falten
// en inglés se muestran en español (nunca aparece una clave cruda).

import i18next from 'i18next';
import { useEffect, useState } from 'react';

export const LANGUAGES = [
  { id: 'es', label: 'Español', locale: 'es-CO' },
  { id: 'en', label: 'English', locale: 'en-US' },
] as const;

export type Language = (typeof LANGUAGES)[number]['id'];

const DEFAULT_LANGUAGE: Language = 'es';
const LAST_KEY = 'lantify.lang.last';
const userKey = (userId?: string | null) => (userId ? `lantify.lang.${userId}` : LAST_KEY);
let currentUserId: string | null = null;

// Carga todos los JSON de src/locales/<idioma>/<namespace>.json
const modules = import.meta.glob('../locales/*/*.json', { eager: true }) as Record<string, { default: Record<string, string> }>;
const resources: Record<string, Record<string, Record<string, string>>> = {};
for (const [file, mod] of Object.entries(modules)) {
  const match = /locales\/(\w+)\/([\w-]+)\.json$/.exec(file);
  if (!match) continue;
  const [, lang, ns] = match;
  resources[lang] = resources[lang] || {};
  resources[lang][ns] = mod.default;
}

const read = (key: string): Language | null => {
  try {
    const v = localStorage.getItem(key);
    return v === 'es' || v === 'en' ? v : null;
  } catch {
    return null;
  }
};

const initial = read(LAST_KEY) || DEFAULT_LANGUAGE;

i18next.init({
  resources,
  lng: initial,
  fallbackLng: DEFAULT_LANGUAGE,
  ns: Object.keys(resources[DEFAULT_LANGUAGE] || { common: {} }),
  defaultNS: 'common',
  interpolation: { escapeValue: false }, // React ya escapa
  returnEmptyString: false,
  returnNull: false,
  initImmediate: false,
});

if (typeof document !== 'undefined') document.documentElement.lang = initial;

/** Traduce una clave 'namespace:clave' con interpolación {{variable}} */
export const t = (key: string, options?: Record<string, unknown>): string =>
  i18next.t(key, options as any) as unknown as string;

export const getLanguage = (): Language => (i18next.language === 'en' ? 'en' : 'es');

/** Locale para fechas y números según el idioma (la moneda siempre es la del negocio: COP) */
export const getLocale = (): string => LANGUAGES.find(l => l.id === getLanguage())!.locale;

export const LANGUAGE_EVENT = 'lantify:language-changed';

const apply = (lang: Language) => {
  if (i18next.language !== lang) i18next.changeLanguage(lang);
  document.documentElement.lang = lang;
  window.dispatchEvent(new CustomEvent(LANGUAGE_EVENT, { detail: lang }));
};

export const setLanguage = (lang: Language) => {
  try {
    localStorage.setItem(userKey(currentUserId), lang);
    localStorage.setItem(LAST_KEY, lang);
  } catch {
    // sin almacenamiento: solo esta sesión
  }
  apply(lang);
};

/** Al iniciar o cerrar sesión: cada usuario conserva su idioma */
export const bindLanguageToUser = (userId: string | null) => {
  currentUserId = userId;
  apply(read(userKey(userId)) || read(LAST_KEY) || DEFAULT_LANGUAGE);
};

/** Hook: idioma actual (re-renderiza al cambiar) */
export const useLanguage = () => {
  const [language, setLang] = useState<Language>(getLanguage);
  useEffect(() => {
    const onChange = () => setLang(getLanguage());
    window.addEventListener(LANGUAGE_EVENT, onChange);
    return () => window.removeEventListener(LANGUAGE_EVENT, onChange);
  }, []);
  return { language, setLanguage };
};

export default i18next;
