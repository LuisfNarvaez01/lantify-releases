import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
// Tipografías empaquetadas: funcionan sin internet
import '@fontsource/rubik/400.css';
import '@fontsource/rubik/500.css';
import '@fontsource/rubik/600.css';
import '@fontsource/rubik/700.css';
import '@fontsource/rubik/800.css';
import '@fontsource/outfit/500.css';
import '@fontsource/outfit/600.css';
import '@fontsource/outfit/700.css';
import '@fontsource/outfit/800.css';
import '@fontsource/outfit/900.css';
import './index.css';
import { applyTheme } from './shared/themeManager';
import { installAuthFetch } from './services/authFetch';
import { initThemeMode } from './shared/theme/themeMode';

// /pantalla: TV de cocina, entregas o salón (sin usuario; se conecta con su código)
const isDisplay = window.location.pathname.startsWith('/pantalla');
const DisplayApp = React.lazy(() => import('./components/display/DisplayApp').then((m) => ({ default: m.DisplayApp })));

// Adjunta el token a todas las llamadas al backend y detecta sesiones revocadas
if (!isDisplay) installAuthFetch();

// Modo claro/oscuro primero, luego la paleta del preset para ese modo
initThemeMode();
applyTheme();

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    {isDisplay ? <React.Suspense fallback={null}><DisplayApp /></React.Suspense> : <App />}
  </React.StrictMode>
);