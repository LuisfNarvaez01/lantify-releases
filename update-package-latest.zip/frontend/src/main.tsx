import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
// Tipografías empaquetadas: funcionan sin internet
import '@fontsource-variable/geist';
import '@fontsource-variable/geist-mono';
import './index.css';
import { applyTheme } from './shared/themeManager';
import { installAuthFetch } from './services/authFetch';
import { initThemeMode } from './shared/theme/themeMode';
import { DesktopTitleBar } from './components/layout/DesktopTitleBar';
import { ClientGate } from './components/mobile/ClientGate';

// /pantalla: TV de cocina, entregas o salón (sin usuario; se conecta con su código)
const isDisplay = window.location.pathname.startsWith('/pantalla');
const DisplayApp = React.lazy(() => import('./components/display/DisplayApp').then((m) => ({ default: m.DisplayApp })));

// Adjunta el token a todas las llamadas al backend y detecta sesiones revocadas
if (!isDisplay) installAuthFetch();

// Modo claro/oscuro primero, luego la paleta del preset para ese modo
initThemeMode();
applyTheme();

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    {isDisplay ? <React.Suspense fallback={null}><DisplayApp /></React.Suspense> : <><DesktopTitleBar /><ClientGate><App /></ClientGate></>}
  </React.StrictMode>
);