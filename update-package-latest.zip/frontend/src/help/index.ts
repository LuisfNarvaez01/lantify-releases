// ============================================
// HELP - Centro de ayuda local (artículos en Markdown dentro del programa)
// ============================================
// Los artículos viven en src/help/<idioma>/<id>.md. La segunda línea lleva los
// metadatos: <!-- id: x | tour: y | roles: A,B | module: pos -->, y una línea
// <!-- keywords: ... --> ayuda al buscador. Funciona sin internet.

import type { GuideModule } from '../guide/tours';

export interface HelpArticle {
  id: string;
  lang: 'es' | 'en';
  title: string;
  body: string; // Markdown sin el título ni los comentarios
  tourId?: string;
  roles: string[];
  module: GuideModule;
  keywords: string[];
}

const files = import.meta.glob('./*/*.md', { query: '?raw', import: 'default', eager: true }) as Record<string, string>;

const parseMeta = (raw: string, name: string) => {
  const match = raw.match(new RegExp(`<!--[^>]*\\b${name}:\\s*([^|>]*?)\\s*(\\||-->)`));
  return match ? match[1].trim() : '';
};

const parse = (path: string, raw: string): HelpArticle => {
  const lang = path.includes('/en/') ? 'en' : 'es';
  const lines = raw.split('\n');
  const title = (lines.find((l) => l.startsWith('# ')) || '').slice(2).trim();
  const body = lines
    .filter((l) => !l.startsWith('# ') && !l.trim().startsWith('<!--'))
    .join('\n')
    .trim();
  return {
    id: parseMeta(raw, 'id') || path.split('/').pop()!.replace(/\.md$/, ''),
    lang,
    title,
    body,
    tourId: parseMeta(raw, 'tour') || undefined,
    roles: parseMeta(raw, 'roles').split(',').map((r) => r.trim()).filter(Boolean),
    module: (parseMeta(raw, 'module') || 'other') as GuideModule,
    keywords: parseMeta(raw, 'keywords').split(',').map((k) => k.trim()).filter(Boolean),
  };
};

export const ARTICLES: HelpArticle[] = Object.entries(files).map(([path, raw]) => parse(path, raw));

export const articlesFor = (lang: string, role: string) =>
  ARTICLES.filter((a) => a.lang === (lang === 'en' ? 'en' : 'es') && (a.roles.length === 0 || a.roles.includes(role)));

export const getArticle = (id: string, lang: string) =>
  ARTICLES.find((a) => a.id === id && a.lang === (lang === 'en' ? 'en' : 'es'));

// ── Búsqueda sin acentos, con más peso al título y a las palabras clave ──
const STOP = new Set(['el', 'la', 'los', 'las', 'un', 'una', 'de', 'del', 'en', 'y', 'o', 'a', 'que', 'con', 'por', 'para', 'como', 'se', 'mi', 'es', 'the', 'a', 'an', 'of', 'to', 'in', 'and', 'or', 'how', 'do', 'i', 'my', 'is', 'on', 'for']);

export const normalize = (s: string) =>
  s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();

const tokens = (s: string) => normalize(s).split(/[^a-z0-9ñ]+/).filter((w) => w.length > 1 && !STOP.has(w));

export const searchArticles = (query: string, list: HelpArticle[], limit = 6) => {
  const q = tokens(query);
  if (q.length === 0) return [];
  const scored = list.map((a) => {
    const title = normalize(a.title);
    const keys = normalize(a.keywords.join(' '));
    const body = normalize(a.body);
    let score = 0;
    for (const w of q) {
      // prefijo: "cobr" encuentra "cobrar" y "cobro"
      const stem = w.length > 5 ? w.slice(0, w.length - 2) : w;
      if (title.includes(stem)) score += 6;
      if (keys.includes(stem)) score += 4;
      const hits = body.split(stem).length - 1;
      score += Math.min(hits, 3);
    }
    return { article: a, score };
  });
  return scored.filter((s) => s.score > 0).sort((x, y) => y.score - x.score).slice(0, limit).map((s) => s.article);
};
