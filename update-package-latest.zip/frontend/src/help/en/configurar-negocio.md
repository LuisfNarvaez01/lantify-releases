# Setting up the business
<!-- id: configurar-negocio | tour: settings | roles: ADMIN | module: settings -->

<!-- keywords: settings, business, tax id, tip, taxes, tables, wizard, receipt, electronic invoice, dian, factus -->

**Administration → My business → Business details** holds the details printed on the receipt and invoice: name, tax ID, address, tax regime and operating options (tables, tips, inventory, delivery).

- **Tips:** turn on *Do you take tips?* and set the suggested percentage. Only then does it appear when charging and on the pre-bill.
- **Wizard:** *Open wizard* repeats the initial setup without deleting products, tables or sales.
- **Electronic invoicing:** in *DIAN electronic invoicing* you connect your provider (Factus) and your resolution.
- **Printing, appearance and tables** each have their own tab.

[[tour:settings|Show me the tour]]
