# Menu engine
<!-- id: motor-de-menu | roles: ADMIN | module: settings -->

<!-- keywords: menu engine, profitability, stars, plowhorses, puzzles, to review, no cost, margin, menu -->

The menu engine analyzes sales from the last 60 days to help you make decisions about your menu. You can find it in **Menu → Menu engine** (or Administration → Menu).

### The five product classes

Each item is classified according to its popularity and profit margin:

- **Stars:** sell a lot and leave a good margin. Protect them: ensure ingredients never run out and keep their recipe and quality consistent.
- **Plowhorses:** sell a lot but leave little margin. Raise the price slightly or negotiate lower ingredient costs with suppliers.
- **Puzzles:** leave a good margin but sell little. Push them: give them visibility with photos on the menu and promote them in waiter suggestions.
- **To review:** sell little and leave little margin. Review them: change the recipe, increase the price, or remove them from the menu if they do not rotate.
- **No cost:** items without a recorded cost. They cannot be classified by margin.

### Product costs and combinations

Entering the cost of each item in **Products** is essential to knowing your true profit; without a recorded cost, Lantify cannot calculate margins or place dishes in their proper class.

The screen also displays the **14-day trend** (comparing the last two weeks against the previous two) to track whether sales are rising or falling. It also shows **what sells together** on the same ticket, highlighting frequent pairings to create combos or promotions.
