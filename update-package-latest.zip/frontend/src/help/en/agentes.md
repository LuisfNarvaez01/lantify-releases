# Artificial intelligence agents
<!-- id: agentes | roles: ADMIN | module: settings -->

<!-- keywords: agents, ai, back office, purchasing, marketing, tasks, profile, whatsapp, coupon, premium -->

AI agents analyze your operations and help you make business decisions without complex charts. They require the Premium plan and enabling AI permissions under **Administration → AI assistant**.

### Three specialized agents

- **Back office:** your personal business analyst. Compares sales week over week, identifies low-margin items, highlights slow and peak hours, tracks expenses, and forecasts monthly revenue.
- **Purchasing:** your inventory buyer. Prepares weekly order lists, predicts shortages before the weekend, and compares supplier prices.
- **Marketing:** your creative lead. Creates promotional flyers, recommends campaigns for slow days, and crafts customer win-back coupons.

### Ready tasks and live responses

Each agent features ready-made **Tasks** with one-tap buttons (such as *How this week went* or *This week’s order*), as well as a freeform question box. Answers stream in live with step-by-step progress indicators. Results display key KPI cards, concise explanations, and direct action buttons such as **Send by WhatsApp** to suppliers or **Create this coupon**.

### Your business for the AI and data privacy

At the top of the module you will find the **Your business for the AI** card. Filling in what you sell, target customers, brand tone, and colors ensures agents provide tailored suggestions instead of generic advice.

Lantify strictly safeguards your privacy: only aggregated business summaries are sent to the AI service, never customer names, phone numbers, or identification numbers. You can click **What data is sent** at any time to inspect the exact payload.
