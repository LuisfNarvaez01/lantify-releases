# Notes and ingredients on kitchen orders
<!-- id: comentarios-e-ingredientes | roles: ADMIN,CASHIER | module: pos -->

<!-- keywords: ingredients, notes, kitchen, ticket, no onions, quick phrases, orders, modifiers -->

In Lantify you can quickly specify how customers want their meals prepared, preventing miscommunications with the kitchen.

### Configuring product ingredients

To set which ingredients a customer may ask to leave out:

1. Go to **Administration → Menu and products → Products**.
2. When creating or editing an item, tap the **Ingredients** button.
3. Enter the ingredient names (for example: onion, tomato, sauce, cheese) and save your changes.

### Adding notes while taking an order

When taking an order from the register or phone:

1. Tap the added product item in the order list to open the kitchen notes sheet.
2. **Remove ingredients:** each ingredient shows as a tap button. Tap any ingredient to remove it; it turns into a strike-through tag (such as *No onion*). Tap it again to re-add it.
3. **Quick phrases:** tap ready-made buttons such as *Medium rare*, *Cold beverage*, or *To go*. You can edit these buttons in **Administration → Features**.
4. **Free note:** if you need to provide special instructions, type them in the free text note field.

### Clear kitchen ticket printing

When you tap **Send to kitchen**, the printed kitchen ticket highlights removed ingredients on their own line in prominent uppercase (for example: **SIN CEBOLLA** / **NO ONION**), placed right above any free notes. This ensures kitchen staff catch critical instructions immediately and avoid wasted plates.
