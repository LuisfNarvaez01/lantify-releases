# Tip split distribution
<!-- id: reparto-de-propinas | roles: ADMIN,CASHIER | module: cash -->

<!-- keywords: tips, tip split, waiters, kitchen, percentages, cash shift, shifts, contributions, settlement -->

The **Tip split** feature allows restaurants to distribute voluntary tips collected from guests in a clear and transparent way. It requires the Staff feature enabled and is configured in **Administration → Features**.

### Setting distribution rules

The business sets how the total collected tip pool is divided for each period:

- **Group percentages:** define what share goes to each team group (Waiters, Cashiers, Kitchen, Bar, Others). The percentages must add up to exactly 100%.
- **Distribution among waiters:** choose between **Equal parts** (all waiters who worked get the same share) or **By what each one brought in** (proportional to the tips collected on each waiter's orders). In other groups, tips are divided equally among workers with clocked shifts.
- **Periods:** calculate splits **Every week**, **Every cash shift**, or **Every month**.

### Reviewing and confirming the split

1. Navigate to **Staff → Tips** and choose the period to settle.
2. Lantify calculates a proposed breakdown based on your active rules and shift attendance.
3. **Manual adjustments:** the administrator can edit any individual amount by hand to handle special circumstances before finalizing.
4. **Groups with no clocked shifts:** if a group was allocated a percentage but nobody clocked in during that period, its share is marked as unassigned. The administrator must reassign that balance manually to other staff before saving.
5. Once everything is balanced, tap **Confirm split**. The amounts flow directly into each employee's period settlement.
