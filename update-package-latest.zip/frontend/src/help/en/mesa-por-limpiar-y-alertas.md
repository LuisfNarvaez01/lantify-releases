# Tables to clean and table alerts
<!-- id: mesa-por-limpiar-y-alertas | roles: ADMIN,CASHIER | module: pos -->

<!-- keywords: tables, to clean, alerts, idle table, pending bill, ready for bill, times, floor, turnover -->

Lantify helps you manage dining room timing through two operational features enabled in **Administration → Features**:

### Tables to clean

When a bill is paid or a table is released, its status changes to **To clean** instead of becoming free right away. This prevents staff from seating guests at a table that has not been bused.

- On the floor map and table list, the table is marked as **To clean**.
- Any team member can tap the table and select **Tap to mark it clean**. With a single tap, the table returns to free and ready for new guests.
- If you turn this feature off, tables become free immediately after payment as before.

### Operational table alerts

The floor plan and table list highlight tables requiring staff attention with a gentle pulse and badge:

- **Idle table:** triggers when too much time has passed since the last round was sent to the kitchen without a bill requested (default threshold: 20 minutes). This prompts the waiter to offer drinks, coffee, or dessert.
- **Bill pending:** triggers when guests requested their bill but payment has not been collected (default threshold: 7 minutes), helping prevent unnecessary delays.

You can customize both threshold times in **Administration → Features → Floor and orders** with the **Save times** button.

The additional alert **Ready for bill** (which notifies you when food was served from the kitchen but no bill has been requested) will start working once the kitchen display screen becomes available in a future update.
