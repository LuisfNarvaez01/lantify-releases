# Opening and closing the register
<!-- id: caja | tour: cash | roles: ADMIN,CASHIER | module: cash -->

<!-- keywords: register, cash count, open, close, float, expense, income, balance, shortage, overage -->

You can't charge with the register closed.

1. **Open the register:** in **Register** tap *Open register* and enter the starting cash (the float).
2. **During the shift:** record income and expenses (e.g. buying ice) in the movements form, with a reason and category.
3. **Close the register:** count the cash (you can use the bill calculator) and tap *Close register*. The system compares what you counted with what was expected and shows the difference.

Cash tips go into the register. The monthly report is under *View monthly report*.

[[tour:cash|Show me the tour]]
