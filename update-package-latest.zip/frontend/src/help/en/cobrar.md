# Charging a bill
<!-- id: cobrar | tour: first-order | roles: ADMIN,CASHIER | module: pos -->

<!-- keywords: charge, pay, tip, cash, card, transfer, change, split payment, partial payment, split bill -->

Tap **Charge** (or `F2`). The payment window shows:

- **Summary:** subtotal, discount and the taxes already included in the price.
- **Voluntary tip:** no tip, the suggested one or *Other amount*. It only appears if the business takes tips (*Settings → Business & Tax → Do you take tips?*). The tip is not part of the sale or the invoice.
- **Payment method:** cash, card, transfer or split. With cash, use *Exact* or the suggested bills and you'll see the change.
- **Pay for some items only:** to split the bill; the rest stays pending on the table.

Confirming prints the receipt. If you ticked **DIAN electronic invoice**, the invoice is printed instead once it's issued.

## Pre-bill

The **Pre-bill** button prints the total for the customer to review, with the suggested tip and the total with tip. It's not an invoice.
