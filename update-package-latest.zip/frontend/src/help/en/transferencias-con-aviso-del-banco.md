# Confirm transfers with the bank notification
<!-- id: transferencias-con-aviso-del-banco | roles: ADMIN,CASHIER | module: pos -->

<!-- keywords: transfer, nequi, daviplata, bancolombia, bre-b, notification, confirm, charge, payment, phone, android, pro -->

Part of the **Pro** plan. The business phone reads the transfer notification your bank already showed and the register confirms the charge on its own.

1. In **Administration → Users → Phones**, turn on **Confirm transfers with the bank notification**.
2. On the business phone (Lantify Android app, signed in as **admin** or **cashier**), open **More options → Transfer notifications** and tap **Open Settings to enable it**. Find **Lantify POS** and allow notification access.
3. That phone must receive the **Nequi**, **Daviplata**, **Bancolombia** or **Bre-B** notifications of the business account.

When you charge by **Transfer**, the register shows **Waiting for confirmation…**. When a notification for the **exact same amount** arrives within the next 15 minutes (or the previous 15), it turns green with the amount, sender and time. If two charges have the same amount, the oldest one is confirmed first.

- You can **always** confirm the payment by hand: the notification only helps and never blocks a sale.
- Lantify only reads amount, sender and time from those apps; everything else is discarded on the phone. Notifications are deleted from the register after 24 hours.
- Lantify **never moves money** or accesses your accounts.
- If you turn the feature off or remove the permission in the phone Settings, it stops reading notifications right away.
