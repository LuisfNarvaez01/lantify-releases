# Sales history
<!-- id: ventas | tour: sales | roles: ADMIN,CASHIER | module: sales -->

<!-- keywords: sales, history, reprint, invoice, cancel sale, search sale, export -->

In **Sales** you see today's and earlier sales with totals by payment method.

- Filter by date, channel or payment method and search by number or customer.
- Open a sale to see its items, **reprint** the receipt or issue the **electronic invoice** later.
- Cancelling a sale returns the money to the register and the stock to inventory; it's recorded in the audit log.

[[tour:sales|Show me the tour]]
