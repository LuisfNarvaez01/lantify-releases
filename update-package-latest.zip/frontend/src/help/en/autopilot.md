# Autopilot
<!-- id: autopilot | roles: ADMIN,CASHIER | module: pos -->

<!-- keywords: autopilot, situations, kitchen overloaded, rush, stockout, waiter overloaded, slow hour, alerts, premium -->

Autopilot monitors operations and compares every moment against what is normal for your business on that day and time. Everything is computed on the venue’s computer and works without internet. It requires the Premium plan and is turned on in **Floor and tables**.

The **Autopilot** button on the top bar displays active situations. You can click **Do it**, adjust minutes or percentage, or click **Dismiss**. When an action is accepted, it stays **Running** with an **Undo** option. Temporary actions revert automatically when their time expires.

### The six situations

1. **The kitchen is getting overloaded:** delayed tickets. Proposes offering quick dishes first, pausing slow items in the online store, and notifying wait times.
2. **A rush is coming:** order pace will exceed kitchen capacity. Proposes pausing slow items, alerting staff, and calling backup on WhatsApp.
3. **An item is running out:** low stock before closing. Proposes pausing it in the online store and in suggestions until closing, and telling the staff not to offer it.
4. **Waiter is overloaded:** handles more tables than the median. Proposes asking another waiter for support.
5. **Slow hour:** sales below 50% of normal. Proposes a 2-hour flash coupon or pushing high-margin dishes.
6. **Several tables waiting:** tables with service delays. Sends a general notice to waitstaff.

### Products paused by Autopilot

When Autopilot pauses a product, it disappears immediately from the business web page, shows as **Paused** on the register and on mobile phones, and cannot be ordered. To sell it again, undo the pause in Autopilot.

### Roles and owner notification

The administrator sees everything with numbers. Cashiers see operational alerts without sales figures or coupons. Waiters only see staff notices on their phones.

The **Tell the owner** button sends the alert via WhatsApp. The owner decides in **My account → Autopilot** on the website, and the venue executes it in under a minute with internet (expires in 30 min).

In **What it knows**, it requires 14 days of history for slow hours and rushes. Kitchen times arrive with the kitchen display.
