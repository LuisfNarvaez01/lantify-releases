# Connection problems and errors
<!-- id: problemas-de-conexion | roles: ADMIN,CASHIER,WAITER | module: other -->

<!-- keywords: error, connection, server, can't connect, failed to fetch, credentials, password, slow, offline -->

- **No connection to the server:** the Lantify program isn't running on the main computer, or this tablet isn't on the same network. Start it and tap *Try again*.
- **The server took too long:** wait a moment and retry; if it continues, restart Lantify.
- **Invalid credentials:** the username or password don't match. Check caps lock and the keyboard.
- **Too many attempts:** for security it locks briefly after several failed attempts.
- **You don't have permission:** the action belongs to another role; ask an administrator.

Lantify works offline: only the AI assistant and electronic invoicing need a connection.
