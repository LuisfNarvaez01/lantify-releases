# Fixing the payment method of a sale
<!-- id: corregir-medio-de-pago | roles: ADMIN,CASHIER | module: sales -->

<!-- keywords: fix payment, payment method, cash, card, transfer, register, sales history, audit -->

If a sale was recorded with the wrong payment method (for example, marked as cash instead of transfer), there is no need to void the sale or alter inventory. You can adjust the payment directly from the sales history.

### How to fix a payment

1. Open **Sales** and tap the sale you need to adjust.
2. Tap the **Fix payment** button.
3. Choose the correct payment methods (Cash, Card, Transfer) and type the corresponding amounts. The payments must match the total charged amount exactly.
4. Enter the required **Reason for the fix** (for example: "Customer paid via transfer, cashier tapped cash").
5. Tap **Save fix**.

### Rules and restrictions

- **Total sale value cannot change:** you can only reassign how the existing total was paid across methods.
- **Open cash shift required:** you can only fix payments while the cash register shift where the sale occurred remains open. Once the shift is closed, payment figures are locked.
- **No transmitted electronic invoice:** if the sale already has an electronic invoice submitted to the tax authority (DIAN), payment methods cannot be edited.
- **Required permissions:** only administrators or cashiers with the *Fix payment method* permission can perform this action.
- **Audit tracking:** Lantify logs who made the adjustment, the timestamp, and the previous payment breakdown. If cash amounts change, expected drawer cash recalculates automatically.
