# Staff, shifts and payments
<!-- id: personal-y-pagos | roles: ADMIN | module: settings -->

<!-- keywords: staff, employees, shifts, clock in, clock out, payroll, advances, deductions, settlement, kitchen -->

The **Staff, shifts and pay** feature provides operational management of your restaurant team. Enable it in **Administration → Features** to replace the users panel with the comprehensive **Staff** menu, organized into four sections:

- **Users and permissions:** manage POS sign-in access and permission rules for each role.
- **Team:** maintain employee profiles with their position (waiters, cashiers, kitchen, bar, others), pay rate type (per shift, per hour, or fixed per period), and agreed amount. You can register staff members without a POS user, such as kitchen or cleaning staff who do not use terminals.
- **Shifts:** attendance tracking. Employees with user accounts tap **Clock in** and **Clock out** from their own session. Admins or cashiers can clock in staff members without user accounts or add manual shifts when someone forgets to clock.
- **Pay:** record employee **Advances** and **Deductions** with dates and reasons. At the end of the week, fortnight, or month, tap **Settle** to calculate total pay based on worked shifts, hours, and allocated tips. Once handed over, tap **Mark paid** (with an option to log it as a business expense).

### Important note on legal scope

This module is designed strictly for **internal operational control** to simplify daily restaurant shift tracking and cash payouts. It does not calculate statutory social security, severance, or DIAN electronic payroll, and **does not replace formal Colombian legal payroll**.
