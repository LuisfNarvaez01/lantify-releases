# Stamp card and prize games
<!-- id: fidelidad-y-juegos | roles: ADMIN | module: settings -->

<!-- keywords: loyalty, stamps, card, reward, game, wheel, scratch, trivia, join, sign up, coupon -->

It's part of the **Premium** plan. Set it up in **Administration → My page and loyalty → Loyalty & Stamps**.

1. **Rules:** minimum purchase per stamp, how many stamps are needed and the reward. Customers see these terms on their card.
2. **Sections:** turn on **Join** (customer sign-up) and, if you want, **Play and win**. To sign up customers you must enter the data controller's legal name (Profile tab).
3. **Game:** choose wheel, scratch card or trivia, and add prizes with their odds.
4. **Publish** the page so the changes show.

At checkout the receipt includes a QR to add the stamp. Prizes won arrive as coupons redeemed at the register.
