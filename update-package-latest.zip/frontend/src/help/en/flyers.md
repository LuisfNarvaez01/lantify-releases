# Promotional flyer studio
<!-- id: flyers | roles: ADMIN | module: settings -->

<!-- keywords: flyer, flyers, marketing, advertising, design, image, png, instagram, whatsapp, light, dark, story, square -->

The flyer studio lets you create polished promotional graphics for social media and WhatsApp status updates without graphic design software.

### How to create a flyer

1. In the top navigation bar, open **Agents** and select the **Marketing** agent.
2. In the ready tasks list, tap **Create a flyer**.
3. Type what you want to promote (for example: *2-for-1 burger special on Thursdays*) or tap **You choose** to let the agent pick the best item.
4. Once generated, tap **Open and edit** to access the design studio.

### Design settings in the studio

- **Styles:** choose between **Light**, **Dark**, or full-bleed **Photo** backgrounds.
- **Formats:** select **Post** (1080×1350 px for Instagram and Facebook feeds), **Story** (1080×1920 px for stories and status), or **Square** (1080×1080 px).
- **Photo:** select the catalog product photo, click **Upload photo** to use an image from your computer, or tap **Make photo with AI**. Generating AI photos consumes your plan's monthly image allowance. A genuine, well-lit photograph of your product always connects best with customers.
- **Text editing:** easily customize the headline, colored accent line, key benefits with matching icons, special offer badge, and call to action.

### Contact information and export

Your WhatsApp number and Instagram handle are loaded automatically from the **Your business for the AI** profile. Keep them updated so customers know how to order.

When satisfied with the preview, tap **Download PNG** to save the graphic in high resolution or click **Share** to forward it via WhatsApp.
