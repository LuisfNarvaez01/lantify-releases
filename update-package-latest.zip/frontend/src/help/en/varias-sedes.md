# Multiple branches: owner board and copying the menu
<!-- id: varias-sedes | roles: ADMIN | module: settings -->

<!-- keywords: branches, locations, several businesses, owner, group, board, consolidated, copy menu, export menu, import menu -->

Premium plan. Each branch is still a business with its own code, register and sales; the group only shows the owner the summaries.

**Create the group and join the branches** (at lantifypos.com/cuenta):

1. Sign in to **My account** with the main business and, under **Multiple branches**, tap **Create group**.
2. Tap **Invite a branch**: you get a code like SEDE-ABCD-2345 (single use, expires in 7 days).
3. Sign in to **My account** with the other branch's ADMIN, enter the code and **confirm**. Without that confirmation the branch shares nothing.

From then on, the main business sees the board for every branch in **My account**: sales and closings for the last 30 days, cash differences and Autopilot alerts. Branches don't see each other. The owner can remove a branch and a branch can leave whenever it wants.

**Copy the menu from one branch to another** (in the program):

1. In **Administration → Business details**, turn on **Multiple branches** in both branches.
2. In the source branch tap **Export the menu**: a .json file downloads.
3. In the other branch tap **Import a menu** and choose the file. You'll see which products, categories, sizes and recipes are created or changed; tap **Apply changes**.

Matching is by name: importing the same file twice changes nothing. It never touches stock, costs, sales or photos, and products not in the file stay as they are.
