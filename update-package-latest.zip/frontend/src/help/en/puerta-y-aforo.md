# Door: cover charge, wristbands and capacity
<!-- id: puerta-y-aforo | roles: ADMIN,CASHIER | module: settings -->

<!-- keywords: door, doorman, cover, entry, wristband, capacity, occupancy, club, bar, night, pro -->

Included in the **Pro** plan. A screen for the doorman's phone with live occupancy.

1. In **Admin → Business → Features**, turn on **Door: cover charge and capacity**.
2. In **Settings → Business settings → Door**, type the **maximum capacity**.
3. In **Products**, mark the cover with **This is a cover charge (entry)**: each unit charged adds one entry.
4. Create a user with the **Doorman** role: they go straight to the **Door** screen and see no sales, register or menu.

On the Door: **In (+1)** for people entering without a cover (guest list, courtesy), **Out (−1)** for people leaving, and the **wristband code** to record entries and exits with a wristband (a wristband cannot enter twice without leaving). At 90% of capacity it warns in yellow and in red when full; it never blocks a sale or an entry.

A night runs from noon to noon. The **night report** (Business settings → Door) shows covers charged, entries, exits and peak occupancy.
