# Export the month's accounting to Siigo or Alegra (beta)
<!-- id: exportacion-contable | roles: ADMIN | module: cash -->

<!-- keywords: accountant, accounting, siigo, alegra, puc, voucher, sales book, csv, excel, vat, consumption tax, tips, export -->

Pro plan and up. This is a **beta**: review the files with your accountant and with the template each program downloads before importing them.

1. In **Administration → Business details**, turn on **Accounting export (Siigo and Alegra)**.
2. Go to **Cash → Monthly report**, pick the month and open the **Accounting export** tab.
3. Under **Chart of accounts (PUC)** enter the accounts your accountant gives you (cash, banks, cards, income, VAT, consumption tax, tips) and save. If you don't change them, the general PUC accounts are used (110505, 111005, 413505, 240805, 249505, 280505).
4. Download what you need:
   - **Sales book (CSV)**: one row per paid sale with its short number (C1-000123), base, VAT, consumption tax, total, tip and payment methods. Opens in Excel.
   - **Voucher for Siigo Nube**: one voucher per day. In Siigo: Configuración › Contabilidad › Importación › Comprobantes contables. If the month has more than 500 records, several files are created.
   - **Voucher for Alegra**: the same daily voucher. In Alegra: Contabilidad › Comprobante contable › Más acciones › Importar comprobantes.
   - **Accountant report** (PDF or Excel): vouchers, cash closings, expenses and invoices for the month.

Every voucher balances (debits = credits): cash goes to the cash account, transfers and wallets to banks and cards to their account; on the credit side go income, VAT, consumption tax and tips (which belong to the staff, not the business). Voided and refunded sales are left out.

Lantify only **reads** sales: exporting never changes a sale or the cash register.
