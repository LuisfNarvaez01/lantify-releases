# Printer and receipts
<!-- id: impresion | roles: ADMIN | module: settings -->

<!-- keywords: printer, receipt, kitchen ticket, thermal, laser, paper, 58, 80, light print, dark, drawer -->

Set it up in **Administration → My business → Printing and receipts**.

- **Direct (best for thermal printers):** receipts print without dialogs. Pick the register printer and, if you have one, the kitchen printer.
- **Through the browser:** the print dialog opens. Use it with laser printers or if direct printing fails.
- **Paper:** 58 mm or 80 mm, matching your roll.
- **Print is too light:** in *Advanced → Print darkness* choose *Dark* or *Extra dark*.
- **Cash drawer:** opens on cash payments if it's connected to the printer.

After saving, use **Print test** to check the receipt prints complete.
