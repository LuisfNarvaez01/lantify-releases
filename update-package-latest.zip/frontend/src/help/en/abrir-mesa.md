# Details when opening a table
<!-- id: abrir-mesa | roles: ADMIN,CASHIER,WAITER | module: pos -->

<!-- keywords: table, open table, guests, customers, description, dining, service order, spend per guest -->

Capture essential details when opening a table to better know your customers and track spend per guest.

### Enabling the feature

1. Go to **Floor and tables**.
2. Under table settings, turn on **Details when opening a table**. You can toggle this feature on or off whenever needed depending on your venue workflow.

### The open table prompt

When you tap a free table on the floor plan or list, the table becomes occupied immediately, even before ordering anything, and shows who opened it. It appears in blue with the **Open** badge until the first order is sent to the kitchen.

If the feature is enabled, the details window appears with three fields:

- **Guests:** tap the quick buttons from **1** to **8**, or choose **Other number** for larger parties. This number feeds into your business statistics and calculates average spend per guest in the menu engine.
- **Description (optional):** type an identifying note such as "Anniversary celebration", "Patio window", or, in service businesses (like laundromats or repair shops), the job ticket number (e.g. "Laundry order #15").
- **Customer:** defaults to **Walk-in customer**. You can search for an existing loyalty customer or register a new one in seconds.

During peak rush hours when speed is top priority, tap **Skip** to open the order immediately without filling in extra details. When ready with the information, tap **Open table**.

### Table alert colors

On the floor plan, tables display alert colors that are always accompanied by text:

- **Teal:** shows **Ready in kitchen** when the kitchen has marked dishes ready.
- **Pink / red:** indicates the bill was requested. The color turns into a deeper red if it takes twice the configured time.
- **Amber / orange:** indicates the table has gone a while without ordering. It turns orange if it reaches twice the configured time.
- **Light blue:** indicates the food was served a while ago.

### Updating details during service

If extra guests join the table later or the customer provides their contact info mid-meal, you can update details at any time:

1. Open the table’s active order.
2. Tap the top header bar showing the table number and current guest count.
3. Update the guest count, descriptive note, or assigned customer and save.
