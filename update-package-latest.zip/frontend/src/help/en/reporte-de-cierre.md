# Cash register close report to owner
<!-- id: reporte-de-cierre | roles: ADMIN,CASHIER | module: cash -->

<!-- keywords: register close, report, owner, whatsapp, email, my account, summary, cash drawer, shifts -->

The **Close report to the owner** feature delivers an immediate financial summary to the restaurant owner whenever a cash register shift is closed, without requiring physical presence. Enable it in **Administration → Features**.

### Instant delivery via WhatsApp

When cash counting is finished and you tap **Close shift** in **Cash register**, the confirmation screen presents the **Send to owner** button:

1. Tap **Send to owner**.
2. Lantify opens WhatsApp with the owner's pre-configured phone number and a complete summary message ready to send.
3. The message details: business name, date and time, opening and closing user, total sales, number of transactions, payment breakdown (cash, card, transfer), expected vs. counted cash, difference, expenses, manual cash entries, and collected tips.

### Automatic cloud and email backup

Even if the cashier does not tap the WhatsApp button, the summary is backed up automatically:

- **On the website:** the summary uploads to the cloud and is immediately viewable in **My account → Cash register closures** when signing in with the owner's account.
- **By email:** a copy is delivered to the primary account email and any additional email address entered in Features.
- **Offline operation:** if the venue loses internet access when closing the shift, the register closes locally without delay. The report queues securely on the machine and sends automatically the moment internet connectivity returns.
