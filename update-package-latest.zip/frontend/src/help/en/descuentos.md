# Discounts
<!-- id: descuentos | roles: ADMIN,CASHIER | module: pos -->

<!-- keywords: discount, percentage, birthday, courtesy -->

In the order tap **Discount** and choose 5, 10, 15, 20, 25 or 50 %, or type another percentage and tap *Apply*.

- The discount applies to the whole bill and the tax is recalculated on the discounted amount.
- To remove it, tap the **×** next to the discount line or *Remove discount*.
- If the selected customer's birthday is today, 10 % is suggested automatically.
- Every discount is logged with its reason and who authorized it.
