# Proyecta: songs requested from the table
<!-- id: proyecta | roles: ADMIN | module: settings -->

<!-- keywords: proyecta, dj, music, songs, request songs, youtube, qr, chat with the dj, link, musica.lantifypos.com -->

**Proyecta** is the DJ app (screens and music). Linked to your business, guests scan their table's QR, search the song like on YouTube and send it to the DJ, from mobile data or any WiFi. The DJ decides what plays.

## Link

1. In **Administration → Proyecta · music**, tap **Link Proyecta**. You get an 8-letter code that expires in 15 minutes and works once.
2. On the DJ's computer, in Proyecta, go to **Settings → Song requests → Over the internet** and tap **Link with Lantify POS**. Type the code.
3. When Proyecta connects, the status changes to **DJ online**.

If the DJ changes computers, link again: the old one is logged out and printed QR codes keep working.

## Table QR codes

The same screen has **QR codes to request songs**: print them all or one by one. Guests register their table once on their phone. If your page has ordering from the table, the menu also shows **Request songs**.

The music page uses the colors and logo from **My page**.

## Messages with the DJ

In **Messages with the DJ** you send short messages (up to 280 characters): a birthday song, lower the volume, last call. While the screen is open, the DJ's messages arrive every few seconds and you get a notice for new ones.

It needs internet on the till and on the DJ's computer. If the DJ is offline, the music page tells guests and doesn't take requests.
