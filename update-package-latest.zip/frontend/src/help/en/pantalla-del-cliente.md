# Customer display
<!-- id: pantalla-del-cliente | roles: ADMIN,CASHIER | module: pos -->

<!-- keywords: customer display, second screen, monitor, total, tip, payment qr, nequi, bre-b, tablet, pro -->

Included in the **Pro** plan. A tablet or monitor next to the register, facing the customer, shows what is being charged.

1. In **Admin → Floor and tables → Features**, turn on **Customer display**.
2. In **Business settings → Payments**, upload your Nequi, Daviplata or Bre-B **payment QR** and the text shown below it.
3. In **Floor and tables → Displays**, add a **Customer (by the register)** display. On the tablet open the address shown and type the 6-digit code.
4. With several registers, tap **Use on this register** on each register computer. With a single display this is not needed.

While you build the order, the display shows the lines, the total, the **suggested tip** and the payment QR. With no order it shows the current happy hour, your products with photos and your page QR.

- The display only shows: it never charges or changes the sale. If it disconnects, the register keeps working.
- Lantify does not see or confirm QR payments: check the receipt as usual.
