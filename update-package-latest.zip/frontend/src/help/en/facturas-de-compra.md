# Purchase invoices and accounts payable
<!-- id: facturas-de-compra | roles: ADMIN,CASHIER | module: settings -->

<!-- keywords: invoices, purchases, expenses, suppliers, inventory, accounts payable, credit, photo, bills -->

Record supplier invoices from a photo to update expenses and inventory in one step. A supply invoice is never recorded alone: it always requires your review before anything is saved.

### How to record an invoice

1. In **Expenses**, click **Invoice photo** and upload a clear picture taken with your phone.
2. The review screen displays the photo on one side and the editable form on the other.
3. If the supplier is new, click **Review and create supplier** to verify and save their details extracted from the bill.
4. Choose the invoice type: **Supplies (inventory)** for ingredients or resale items, or **Expense or service** for operational bills.
5. Review the invoice items table. Match each line to an existing ingredient or product, or click **+ Create new ingredient**. If you purchased in bulk, set the conversion factor to your base unit (for example, 1 box = 24 units). You will see the new unit cost and its percentage variation against the previous price.
6. Under payment details, select whether the invoice is **Paid** (selecting the payment source) or **On credit** with its due date.
7. Click **Confirm and register**. Lantify saves everything in one transaction: the expense record, stock arrivals, and updated weighted average costs.

### Learned items and accounts payable

- **Automatic matching:** the next time you scan an invoice from that same vendor, Lantify remembers previous links and marks them as **Known**, saving you time.
- **Accounts payable:** credit purchases appear under accounts payable in suppliers and expenses. Once you pay the vendor, click **Register payment…** to convert the pending balance into an expense from the selected source.
