# Order from the table with QR
<!-- id: pedido-desde-la-mesa | roles: ADMIN,CASHIER,WAITER | module: pos -->

<!-- keywords: qr, table, order from the table, menu, guest phone, round, waiter, accept, premium -->

Included in the **Premium** plan. Guests scan their table's QR, see the menu on their phone and send the order. The waiter confirms it before it goes to the kitchen.

1. In **Admin → Floor and tables → Features**, turn on **Order from the table**.
2. Your page must be published (**My page**, with internet).
3. In **Floor and tables → Table QR codes**, tap **Print** and place each QR on its table.

When an order arrives it shows above the floor plan and in the waiter's phone **Alerts**, with a sound. **Accept and send** adds it as a new round of the table and prints the kitchen ticket. **Reject** shows the reason to the guest.

- Prices come from the register (with happy hour when active), never from the guest's phone.
- Each table has only one order waiting at a time.
- No name, phone or payment is asked: it is charged with the table bill.
- If a QR is lost or copied, tap **Change QR** on that table and print the new one.
