# Users and roles
<!-- id: usuarios-y-roles | roles: ADMIN | module: settings -->

<!-- keywords: user, role, cashier, waiter, administrator, password, permissions, staff, fix payment -->

Each person signs in with their own user. They're created in **Administration → My business → Users and roles** (if you enable the staff feature in Features, this section is renamed to **Staff**).

- **Waiter:** takes orders and sends them to the kitchen. Can't charge or see the register.
- **Cashier:** can also charge, run the register and see sales.
- **Administrator:** everything, including settings and authorizing voids.

If someone forgets their password, an administrator resets it and they must change it when they sign in.

In the **What each role can do** table you decide what cashiers and waiters can do (charge, register, history, online orders, customers, reservations, statistics, and the **Fix payment method** permission, which lets cashiers change payment methods on sales while the cash register shift is open). Taking orders is always allowed. The QR to connect tablets is on the same screen.
