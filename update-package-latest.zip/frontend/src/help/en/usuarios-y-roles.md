# Users and roles
<!-- id: usuarios-y-roles | roles: ADMIN | module: settings -->

<!-- keywords: user, role, cashier, waiter, administrator, password, permissions -->

Each person signs in with their own user. They're created in **Administration → My business → Users and roles**.

- **Waiter:** takes orders and sends them to the kitchen. Can't charge or see the register.
- **Cashier:** can also charge, run the register and see sales.
- **Administrator:** everything, including settings and authorizing voids.

If someone forgets their password, an administrator resets it and they must change it when they sign in.

In the **What each role can do** table you decide what cashiers and waiters can do (charge, register, history, online orders, customers, reservations, statistics). Taking orders is always allowed. The QR to connect tablets is on the same screen.
