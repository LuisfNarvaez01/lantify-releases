# Users and roles
<!-- id: usuarios-y-roles | roles: ADMIN | module: settings -->

<!-- keywords: user, role, cashier, waiter, administrator, password, permissions -->

Each person signs in with their own user. They're created in **Admin → Users & roles**.

- **Waiter:** takes orders and sends them to the kitchen. Can't charge or see the register.
- **Cashier:** can also charge, run the register and see sales.
- **Administrator:** everything, including settings and authorizing voids.

If someone forgets their password, an administrator resets it and they must change it when they sign in.
