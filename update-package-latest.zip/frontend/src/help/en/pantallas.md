# Kitchen, pickup and floor screens
<!-- id: pantallas | roles: ADMIN,CASHIER | module: pos -->

<!-- keywords: screens, kitchen, pickup, floor, waiter, kds, tv, wifi, code, ready, deliver, pro -->

Screens display live orders and operational notices on TVs or tablets connected to the local venue WiFi. They never show prices, totals, or customer details. Requires the Pro plan.

There are three types of screens:

- **Kitchen (KDS):** displays order tickets as cards by arrival order, showing elapsed minutes, table number, and notes. Tap an item to cross it out. Tap **Ready** to complete a ticket or **Undo** to restore the last one. Supports keyboard control: number keys to select, **Enter** to mark ready, and **U** to undo. A sound chime plays when a new ticket arrives.
- **Pickup (for customers):** customer-facing screen showing two columns: *Preparing* and *Ready! Pick up your order*.
- **Floor (for waiters):** floor overview showing table status and dishes waiting for pickup.

### How to connect a screen

1. On the main register, go to **Floor and tables → Screens**.
2. Enter a screen name, select the display type (and station if applicable), and tap **Add screen**.
3. You will see a 6-digit code valid for 10 minutes and the local web address (`http://REGISTER-IP:5000/pantalla`).
4. Connect the TV to the venue WiFi, open the address in the browser, and enter the code. The TV links immediately.

### Waiter notification and bill alert

When the kitchen marks a ticket as **Ready**, the waiter sees **Pick up in the kitchen** under **Notices** on their phone. Once delivered to the table, the waiter taps **Delivered**. This triggers the *Ready for bill* alert after the configured time.

### Notification bell

At the top of the screen (on both computer and mobile phone), the notification bell displays the number of unread notices and the list of the last 7 days (web orders, reservations, dishes ready, requested bills, waiting tables, and Autopilot). Tap **Clear all** to empty the list. Notifications are stored locally on each device. Waiters only receive notices for their assigned tables. Dishes ready and requested bills play a chime.

### Instant updates

Floor tables, the kitchen display, and notifications update immediately as soon as they change, without waiting.

### Kitchen display

The kitchen display only shows orders sent within the last 6 hours and never shows tables that have already been paid. Paid counter orders remain visible for up to 90 minutes or until marked ready.

To disconnect or delete a screen, return to **Floor and tables → Screens** and tap **Disconnect** or **Remove**.
