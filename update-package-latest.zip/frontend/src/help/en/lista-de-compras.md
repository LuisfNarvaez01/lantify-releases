# Shopping list by supplier
<!-- id: lista-de-compras | roles: ADMIN,CASHIER | module: settings -->

<!-- keywords: purchases, suppliers, shopping list, inventory, minimum stock, restock, whatsapp, supply orders -->

The **Shopping list by supplier** feature lets you identify low stock and compile purchase orders in seconds to send to your vendors. Enable it in **Administration → Features**.

### Setting restock parameters

In **Inventory**, every item with stock tracking features a **Restock** button:

- **Minimum stock:** the alert threshold. If left empty, Lantify uses a default of 5 units.
- **Quantity to order:** the suggested quantity to purchase. If left blank, Lantify calculates what is needed to reach twice the minimum stock.
- **Purchase unit:** the packaging format your vendor delivers (cases, kilograms, packs, bottles).
- **Supplier:** the preferred vendor assigned to the product.

### Generating and sending the shopping list

1. In the **Inventory** section, tap the **Shopping list** button.
2. Lantify gathers all products currently at or below their minimum stock level, grouped by supplier (items without an assigned vendor appear under *No supplier*).
3. Review the summary: you can adjust quantities directly or tap the remove icon on any line item you do not wish to reorder today.
4. To dispatch the order to each supplier:
   - **Copy:** copies the order message to your clipboard to paste into an email or messaging app.
   - **Send on WhatsApp:** opens WhatsApp directly with the supplier's registered phone number and a pre-written order message.
