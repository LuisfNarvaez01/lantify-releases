# Appear in “Places with Lantify”
<!-- id: lugares-con-lantify | roles: ADMIN | module: settings -->

<!-- keywords: directory, places, city, page, google, listed, find restaurants, lantifypos.com/lugares -->

All plans. It stays **off** until you turn it on.

1. In **My page → Profile & legal details**, turn on **Appear in the “Places with Lantify” directory**.
2. Enter the **city** in the profile and publish the page. Without a city you won't be listed.

Your business appears at **lantifypos.com/lugares** and on your city's page (for example lantifypos.com/lugares/neiva), with the cover photo, business type, tagline and a link to your page. Nothing else is shown: never the address, phone, tax ID or anything about your sales.

If you turn it off, you leave the directory as soon as the page is published again (a few minutes).
