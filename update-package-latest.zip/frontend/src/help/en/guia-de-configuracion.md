# Setup guide: where to start
<!-- id: guia-de-configuracion | roles: ADMIN | module: settings -->

<!-- keywords: start, first time, setup, install, guide, steps, plan, features, checklist -->

The **setup guide** is in **Administration → Get started → Setup guide**. It shows everything that's left, in order.

1. **The basics** are done in the first-time wizard: business type, tables, details and team.
2. **Choose what you'll use:** the guide asks feature by feature (inventory, coupons, web page, stamp card…). It only shows the ones **in your plan**. If you don't need one, tap *I don't need it*; you can add it back anytime.
3. **Follow the steps:** each step has a **Go** button that takes you to the right screen and a *How do I do it?* explanation.
4. **Steps are marked automatically** when the system can check them (for example, once there are products or tables). Mark the rest with *Mark as done*.

While steps are pending, the POS shows a notice at the top with a link to continue. You can hide it; the guide stays in Administration and in this help center.

**The Administration menu** is grouped like this:
- **My business:** business details, dining room and tables, users and roles, printing and appearance.
- **Menu and inventory:** products, inventory, suppliers and expenses.
- **Customers and online sales:** customers, coupons, my page and loyalty.
- **Account and system:** DIAN e-invoicing, plan and subscription, AI assistant, backups and maintenance.
