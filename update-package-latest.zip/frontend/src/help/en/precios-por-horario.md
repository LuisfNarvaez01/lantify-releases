# Happy hour and time-based prices
<!-- id: precios-por-horario | roles: ADMIN | module: settings -->

<!-- keywords: happy hour, time-based price, promotion, discount by hour, special price, days -->

Included in the **Pro** plan. Set it up in **Settings → Products → Time-based prices**.

1. Turn on **Time-based prices (happy hour)** above the list.
2. Tap **New rule**: give it a name (for example *Happy hour*) and choose days and hours.
3. Choose the type: **Discount %** or **Special price** (for example, beer at $5.000).
4. Choose what it applies to: the **whole menu**, some **categories** or some **products**. The **preview** shows the resulting prices.

While the rule is active, the register and phones set the price automatically and the cart shows a badge with the rule name. Your page shows the notice (for example, *Happy hour · Mon to Fri · 5 pm – 7 pm*).

- If the end time is earlier than the start (22:00 to 02:00), the rule runs into the next day.
- What a table ordered during happy hour is charged at that price even after it ends.
- For safety, the register does not accept a price below the menu price that no rule justifies. If you see that notice, remove the product and add it again.
