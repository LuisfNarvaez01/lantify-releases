# Waiter suggestions
<!-- id: sugerencias-al-mesero | roles: ADMIN,CASHIER,WAITER | module: pos -->

<!-- keywords: waiter suggestions, offer first, cross selling, sides, favorites, quick dishes, floor and tables -->

Waiter suggestions display smart recommendations at the top of the order screen, both on the register and on waiter phones, under the header **Offer first**.

The feature is turned on in **Floor and tables → Waiter suggestions**.

### Where suggestions come from

Lantify analyzes your sales history to recommend 2 to 3 timely items with a clear reason:

- **If the order already has items:** suggests what is frequently ordered together with them (for example: "7 in 10 with burger order fries").
- **If the order is empty:** suggests favorites for the current time slot (**Stars**) and high-margin dishes (**Puzzles**).

The system never suggests out-of-stock items or products that are currently paused.

### How to use them during service

1. When opening a table or ticket on the register or phone, check the **Offer first** bar.
2. Offer the recommendation to the customer, highlighting the suggested pairing or popular dish.
3. With **a single tap** on the suggested item, it is instantly added to the ticket without searching through categories.

### Prioritization with Autopilot

When Autopilot detects that the kitchen is getting overloaded, it can automatically prioritize quick-to-prepare dishes in suggestions for a set time. This guides diners toward faster options and helps ease kitchen congestion without slowing down table service.
