# Satisfaction survey and Google reviews
<!-- id: encuesta-de-satisfaccion | roles: ADMIN | module: settings -->

<!-- keywords: survey, satisfaction, rating, feedback, comments, review, google, stars, qr, receipt -->

## 1-to-5 survey

Included in **Premium** (it comes with the stamp card). Turn it on in **Settings → My page and loyalty → Loyalty & Stamps → Satisfaction survey**.

When customers claim stamps on your page (or open their card from Google Wallet), they see one question from 1 to 5 with an optional comment. Each customer answers at most once a day.

Answers reach the register automatically: see them in **Statistics → Team and customers → Satisfaction**. With **Autopilot**, you get a notice when the 7-day average drops below 3.5 or someone rates 1 or 2 with a comment.

## Rate us on Google

- When claiming stamps, customers are also invited to rate you on Google, whatever they answered in the survey (Google requires it).
- In **Settings → Printing** turn on **Google review QR** to print a code on the receipt. First paste your review link in **My page → Social**.
