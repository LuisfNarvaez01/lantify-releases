# Business features
<!-- id: funciones | roles: ADMIN | module: settings -->

<!-- keywords: features, enable, disable, modules, settings, what's new, 3.0 -->

In **Administration → Features** you can choose which tools your restaurant needs for its daily operation.

Every business works differently. That is why Lantify lets you turn modules on or off according to your operational needs:

- **Turned off means hidden:** when you disable a feature, its buttons, tabs, and menu options disappear completely across the entire system. Your team will not see unnecessary options or unused clutter.
- **Turn on whenever you want:** you can enable any feature at any time with a single tap, and it will be available immediately.
- **Upgrading to version 3.0:** when updating to Lantify 3.0, all your existing tools stay enabled so your daily routine remains uninterrupted. New features arrive turned off by default. You can check the what's new banner and visit this screen to activate the ones you want.

Available toggleable features include: tables to clean, table alerts, shopping list by supplier, close report to owner, staff and pay, and tip split.

To enable or disable a feature:

1. Go to **Administration → Features**.
2. Find the feature you want to configure within its group.
3. Turn the switch on or off.
4. If the feature has additional settings (such as alert times or phone numbers), adjust them and tap **Save**.
