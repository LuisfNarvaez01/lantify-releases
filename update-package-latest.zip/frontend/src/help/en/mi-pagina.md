# My web page, reservations and online orders
<!-- id: mi-pagina | roles: ADMIN | module: settings -->

<!-- keywords: page, web, menu, qr, link, reservations, orders, delivery, publish, design, terms, privacy, data policy, tax id -->

Set it up in **Administration → Customers and online sales → My page and loyalty**.

- **Design:** colors, template and tagline.
- **Menu:** which sections show (menu, orders, reservations) and which products are hidden.
- **Profile:** hours, address, social media and the data controller's legal name.
- **Reservations** (Premium): hours, duration and bookable tables. Reservations arrive at the POS automatically.
- **Online orders** (Premium): delivery or pickup, delivery fee and payment methods. Each new order chimes and shows at the bottom right.

When you're done, tap **Publish**. The link and QR are ready to share. Each change is published again.

## Terms and privacy policy

Every public website generates its legal **Terms and conditions** and **Data privacy policy** pages automatically. They are built using your registered business information: legal business name, NIT/tax ID, email, address, and phone number.

Customers can access these documents via links in the page footer and within online order and reservation forms. For legal compliance, if you have not filled in all required business information in your profile, the page cannot be published for the first time.
