# Self-service kiosk
<!-- id: kiosco | roles: ADMIN,CASHIER | module: pos -->

<!-- keywords: kiosk, self-service, tablet, self ordering, line, number, pay at register, qr, premium -->

Included in the **Premium** plan. A tablet at the entrance where customers order on their own.

1. In **Admin → Floor and tables → Features**, turn on **Self-service kiosk**.
2. In **Displays**, add a **Self-service kiosk** display. On the tablet open the address shown and type the 6-digit code.
3. Optional: upload your **payment QR** in **Business settings → Payments** so customers can pay with their app.

The customer taps **Tap to order**, picks products with photos and a size, removes ingredients or leaves a comment with the on-screen keyboard, types their name and chooses **At the register** or **With QR**. They get a number, for example **K7**.

At the register the order appears in **Delivery → Web orders** tagged **Kiosk**, with the usual sound. Accept it (it goes to the kitchen) and charge it with its number like any order.

- Prices come from the register, not the tablet.
- If nobody touches the tablet for a minute and a half, it goes back to the start and clears the unfinished order.
- Kiosk orders are not uploaded to your page or the cloud.
