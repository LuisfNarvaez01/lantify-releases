# Your first order
<!-- id: primer-pedido | tour: first-order | roles: ADMIN,CASHIER,WAITER | module: pos -->

<!-- keywords: start, sell, order, product, add, search, counter -->

The **Orders** screen handles every sale, at a table or at the counter.

1. Choose where you're serving: **Counter** or a table in the list on the left.
2. Find the product by name, code or barcode scanner. The `/` key jumps to the search box.
3. Tap the product to add it. If it has sizes or presentations, pick one.
4. In the order (on the right) adjust quantities, add kitchen notes or remove items.
5. Send to the kitchen with **Kitchen** or `F4`, and charge with **Charge** or `F2`.

[[tour:first-order|Show me the tour]]
