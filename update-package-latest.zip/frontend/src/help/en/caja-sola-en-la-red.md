# The app finds the register on its own
<!-- id: caja-sola-en-la-red | roles: ADMIN | module: settings -->

<!-- keywords: phone, android, local network, wifi, ip, router, find, register, mdns, tablets, connection -->

Available on every plan. It helps when the router changes the register address (IP) and the Android phone app can no longer reach it on the local network.

1. In **Administration → Users → Phones**, turn on **The app finds the register on its own**.
2. **Tablets on the local network** must be enabled (in the desktop app): otherwise the register does not announce itself.

When the saved addresses do not answer, the Android app looks for the register on the network before switching to the internet. It only uses a register that answers with **your** business fingerprint: it never connects to another venue register on the same network. If it finds nothing, it carries on over the internet (Lantify Cloud relay) as usual.

On iPhone (web version) there is no automatic search: if the IP changes, scan the **Connect tablets** QR again.
