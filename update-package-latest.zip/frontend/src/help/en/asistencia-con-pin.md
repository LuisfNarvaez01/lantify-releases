# Attendance with PIN and weekly schedule
<!-- id: asistencia-con-pin | roles: ADMIN,CASHIER | module: settings -->

<!-- keywords: attendance, pin, clock in, clock out, time clock, late arrivals, schedule, shifts, kitchen, staff, pro -->

Included in the **Pro** plan and needs **Staff** turned on. Lets people without a user (kitchen, helpers) clock in and out.

1. In **Admin → Staff**, turn on **Attendance with PIN**.
2. In the **Attendance** tab, tap **Set PIN** for each person (4 to 6 digits; 1234 or 0000 are not accepted). Tell it privately: nobody else can see it.
3. Build each person's **Weekly schedule**: tap **Shift** on each day and set start and end times.

To clock in or out:

- **At the register:** your user menu → **Clock in / out**. The person taps their name and types their PIN.
- **On a tablet:** in **Floor and tables → Displays**, add an **Attendance (PIN)** display and connect it with the code.

With no open shift it clocks **in**; with one, it clocks **out**. Shifts appear in **Schedule and shifts** as usual.

The **Attendance report** compares scheduled and worked hours and lists late arrivals (more than 5 minutes) and shifts with no clock-in.

- After 5 wrong PINs, that person waits 10 minutes.
- If someone forgets their PIN, set a new one.
