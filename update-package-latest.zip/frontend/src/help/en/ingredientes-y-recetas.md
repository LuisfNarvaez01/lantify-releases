# Ingredients, recipes and stock control
<!-- id: ingredientes-y-recetas | roles: ADMIN,CASHIER | module: settings -->

<!-- keywords: inventory, ingredients, recipes, kardex, stock, cost, margin, waste, adjustment, supplies -->

Track your kitchen supplies and the real food cost of every dish directly from inventory.

### Creating and adjusting ingredients

1. Go to **Inventory → Ingredients** and click **New ingredient**.
2. Enter the name, category, and base tracking unit: **Grams (g)**, **Milliliters (ml)**, or **Units (und)**.
3. Enter the starting cost per kg, liter, or unit, along with current stock and the desired minimum stock.
4. To reconcile stock by hand, use the **Adjust** button on any ingredient row. You can record a physical count, log kitchen waste, or apply a positive or negative adjustment.
5. Tap movements to check the kardex log: purchases, sales, void returns, waste, and adjustments.

### Setting up recipes and ingredients in products

1. Go to **Inventory → Products** and select a product.
2. Tap the chef hat button (**Recipe and ingredients**; the separate Ingredients button no longer exists). The window has two tabs:
   - **With recipe**: ingredients from inventory with their quantity (include packaging such as cups or bags). Each row has the **Can be left out** checkbox: checked items appear in order notes to order "without"; uncheck it for packaging, salt, or oil. The product cost is calculated from the recipe (in **Edit product**, the cost is locked and explains why).
   - **Without recipe**: for businesses that do not track ingredient inventory. Type the list of what can be left out, and enter the cost manually in **Edit product**. Saving in **Without recipe** deletes any existing recipe.
3. In **With recipe**, the screen calculates the recipe cost, sale price, and gross margin. If the margin drops below the minimum configured (30% by default), Lantify shows a visual alert.
4. The cost of dishes with a recipe updates automatically when you purchase supplies at new prices, but the sale price never changes on its own.

### What happens when selling or voiding

- **When charging:** Lantify immediately deducts recipe ingredients for each sold item. If stock is insufficient, the sale goes through without interrupting service and inventory goes negative so you can adjust it later.
- **When voiding:** ingredients return to inventory. If the person voiding says the dish was already prepared, it is recorded as waste and does not return.
