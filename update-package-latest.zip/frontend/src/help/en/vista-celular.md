# Mobile phone view for waiters
<!-- id: vista-celular | roles: ADMIN,CASHIER | module: pos -->

<!-- keywords: phone, mobile, waiter, my tables, orders, alerts, kitchen ticket, pre-bill, wifi, local network -->

When you open Lantify on a smartphone or small screen, the system displays an interface designed for phones with large touch targets and three main destinations in the bottom bar:

- **Tables:** shows the dining floor with the status of each table. You can tap **My tables** to view only the tables opened and served by you, or browse all tables. Each card displays current totals, idle minutes, or whether the bill has been requested.
- **Orders:** lists open orders alongside elapsed waiting times for each round. Tapping any order opens that table to take or add items.
- **Alerts:** brings together active operational notifications for your tables, such as idle tables or pending bills.

### Taking an order from a mobile phone

1. Connect the phone to the **same WiFi network** as the main register computer. Without this local network connection, the phone cannot communicate with the POS.
2. Open the system address in the phone's web browser. From the browser menu, choose *Add to home screen* to open it like an app.
3. Sign in with your user credentials.
4. Tap the table on the **Tables** screen.
5. Browse categories and tap **+** on the products the customer wants.
6. Tap the bottom bar **Send to kitchen** to send the order items and kitchen notes.
7. When the customer is done, tap **Request bill** to notify the team and print the pre-bill.
