# Taking orders from tablets and phones
<!-- id: tablets | roles: ADMIN | module: settings -->

<!-- keywords: tablet, phone, waiter, wifi, network, qr, ip, connect, orders -->

Waiters can take orders from their phone or tablet without installing anything.

1. The phone must be on the **same WiFi** as the register computer.
2. In **Administration → My business → Users and roles**, scroll to *Connect tablets and phones*.
3. Scan the **QR code** with the camera and sign in with the waiter's user.
4. From the browser menu you can *Add to home screen* to open it like an app.

If it stops opening one day (for example, after restarting the router), come back to that screen and scan the new code.
