# Floor plan editor
<!-- id: editor-del-plano | roles: ADMIN,CASHIER | module: pos -->

<!-- keywords: floor plan, layout, tables, editor, zones, move, rotate, grid, bar, walls, shortcuts -->

Design the exact layout of your venue using the visual floor plan editor.

### Adding tables and architectural elements

1. Go to **Floor and tables** and open the floor plan editor.
2. To add dining spots, click **Table** and select its shape: square, round, rectangle, or bar seat. Assign its table number and seat capacity.
3. To mirror your actual physical venue, click **Element** and place walls, doors, bars, kitchens, restrooms, plants, areas, or custom text labels.

### Arranging and manipulating objects

- **Snap to grid and alignment guides:** drag any item to snap it to the 8 px grid. Hold the **Shift** key while dragging for completely free movement.
- **Multiple selection:** hold **Ctrl** or **Shift** while clicking items, or drag a selection box across any empty area.
- **Precision nudging:** use keyboard arrow keys to move selected items 1 px at a time (hold **Shift** + arrow keys for 10 px jumps).
- **Rotating and resizing:** press **R** to rotate 15° or click the rotate buttons. Drag the blue corner handle to adjust width and height.
- **Duplicate and remove:** press **Ctrl+D** to duplicate elements or **Delete** to remove them. A table with an open order cannot be deleted.
- **Align and distribute:** use toolbar buttons to center, align edges, or evenly space elements horizontally and vertically.
- **Undo, redo, and zoom:** use **Ctrl+Z** to undo, **Ctrl+Y** to redo, and **Ctrl + mouse wheel** to zoom in and out.
- **Zones:** structure your floor into separate zones such as terrace, main dining room, or bar counter.

Nothing is saved until you click **Save** (or press **Ctrl+S**). If you close the editor, you can discard unsaved changes.
