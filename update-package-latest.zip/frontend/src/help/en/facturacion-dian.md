# DIAN e-invoicing
<!-- id: facturacion-dian | roles: ADMIN | module: settings -->

<!-- keywords: dian, electronic invoice, resolution, factus, cufe, provider, numbering -->

Set it up in **Administration → Account and system → DIAN e-invoicing** (Pro and Premium plans).

1. Request the e-invoicing **numbering resolution** in the DIAN portal and enter it with its prefix and range.
2. Connect the **billing provider** with the credentials they gave you.
3. Use **Test connection** and issue a test invoice.

Without internet, invoices are queued and sent automatically when the connection returns. Check your tax regime with your accountant before invoicing.
