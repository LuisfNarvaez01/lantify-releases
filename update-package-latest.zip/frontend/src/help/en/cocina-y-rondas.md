# Kitchen and rounds
<!-- id: cocina-y-rondas | tour: tables | roles: ADMIN,CASHIER,WAITER | module: pos -->

<!-- keywords: ticket, kitchen, round, send, note, waiter, waiting time -->

Every time you send new items to the kitchen a **round** is created and its ticket is printed.

- Rounds appear in the order with the time sent and the waiting time: green on time, amber after 15 minutes and red after 30.
- Notes (*no onions*, *to go*…) are added before sending with **Add note**.
- Items already sent can't be deleted; they are **voided** (see *Voiding an item*).
- The order is saved on the server, so another register or tablet sees the same table.
