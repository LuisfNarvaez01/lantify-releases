# Language and theme
<!-- id: idioma-y-tema | roles: ADMIN,CASHIER,WAITER | module: other -->

<!-- keywords: language, english, spanish, theme, dark, light, colors, font -->

In your user menu (top right) choose the **language** (Spanish or English) and **theme** (light, dark or automatic). Each person keeps their own preference.

Business colors and font size are changed in *Settings → Appearance*. The receipt language is set in *Settings → Printing*.
