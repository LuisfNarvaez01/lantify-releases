# Voiding an item or cancelling an order
<!-- id: anular-producto | roles: ADMIN,CASHIER,WAITER | module: pos -->

<!-- keywords: void, cancel, mistake, return, admin password, waste -->

## Item not sent yet
Remove it with the trash icon or lower the quantity. To remove all new items: **⋯ menu → Remove unsent items**.

## Item already sent to the kitchen
Tap **Void** on the line. Choose how many units, the reason and whether it was waste; an administrator enters their password to authorize it.

## Cancel a table's whole order
**⋯ menu → Cancel table order**. It asks for a reason and, if you're not an administrator, an administrator's password.

Everything is recorded in the audit log with the reason and who authorized it.
