# Troubleshooting common problems
<!-- id: solucion-de-problemas | roles: ADMIN,CASHIER | module: settings -->

<!-- keywords: troubleshooting, errors, solutions, messages, wifi, register, screens, agents, photos, closing, support -->

Quick guide to resolve common alert messages and operational questions in Lantify:

| If you see this message | What it means | What to do |
| --- | --- | --- |
| "The register computer runs an older Lantify version…" | The register computer is running an older Lantify version that lacks this feature. | On the main register go to **Administration → About → Check for updates**, install the latest update, and restart. If testing a development version, close the installed app. |
| "The Lantify AI service does not have this feature yet…" | The cloud AI service does not have this capability deployed yet. | This is not an issue with your device or data. It will activate automatically once Lantify deploys the service update; use other agent tasks in the meantime. |
| "You have used today’s or this month’s AI photos…" | You have reached the AI photo generation limit for today or this billing period. | Click **Upload photo** in the flyer studio or catalog and use a picture taken with your camera or phone. |
| "The administrator must authorize the AI…" | Administrator consent is required before sending business summaries to the AI engine. | Sign in as administrator, navigate to **Administration → AI assistant**, and enable the AI authorization toggle. |
| "Could not connect to the server" or "No connection to the register" | Your tablet, phone, or TV cannot communicate with the main register computer. | Ensure the main register is powered on with Lantify running, both devices are on the same WiFi network, and the URL is `http://IP:5000`. In **Users and roles**, click **Test connection** to see the exact cause (Firewall, Public network, or multiple networks) and use **Repair now**. |
| "The phone screen keeps loading" | The phone browser cannot reach the local register IP or the network blocks internal communication. | Make sure the phone is on the same WiFi as the register and turn off mobile data. Check that the router does not use a guest network or client isolation. |
| **Available on the Pro plan** | You are attempting to use kitchen screens or features reserved for higher tiers. | Review your active plan under **Administration → Plan and subscription** to upgrade. |
| **Shift closing email not received** | The end-of-day register report has not arrived in the owner's inbox. | Verify the email address in **Business details → Close report** and check your spam folder. Without internet, it queues and sends once reconnected. |
| **Screen no longer connected** | The TV display lost its session or the temporary pairing code expired. | Go to **Floor and tables → Screens**, generate a **New code**, and enter the 6 digits on the TV screen. |
| "Autopilot says it is learning" | Lantify needs 14 days with sales to learn your business pace and anticipate slow hours or rushes. | Keep using Lantify as usual; everything else works already while it gathers the 14 days of history. |
