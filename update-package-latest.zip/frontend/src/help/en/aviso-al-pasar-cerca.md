# Nearby alert
<!-- id: aviso-al-pasar-cerca | roles: ADMIN | module: settings -->

<!-- keywords: nearby, location, geofence, wallet, google wallet, alert, notification, walk by, invitation, message -->

## What it does

When a customer who saved your **stamp card in Google Wallet** walks near your place, their Android phone shows the card with an alert. When they tap it they see your message at the top, for example: *"You're one block away! Today your house juice is 10% off."*

## How to turn it on

1. Go to **Administration → My page & loyalty → Loyalty & Stamps**.
2. Under **Where customers keep their card** choose **In the phone's wallet** (v2).
3. Turn on **Nearby alert (Android)**.
4. Write the message (up to 150 characters).
5. Add your location in one of these ways:
   - Open your place in Google Maps, long-press the exact spot and copy the numbers shown (for example `2.9273, -75.2819`). Paste them and tap **Add**.
   - Paste the long Google Maps link (the one in the browser's address bar).
   - If you are at the place with a phone or a device with location, tap **I'm at the place**.
6. **Publish the page.** Publishing also updates the cards your customers already saved.

You can add up to 10 locations (for example, each branch or a mall entrance).

## Good to know

- **Google decides** how close and for how long the customer must be before showing the alert, and writes the alert text. Your message is what the customer reads when opening the card.
- It only reaches customers with Google Wallet **notifications** and **precise location** turned on.
- The alert goes away when the customer walks away.
- **iPhone has no nearby alert**: there the card lives on the home screen and only gets stamp alerts.
- Short links (`maps.app.goo.gl/…`) don't include coordinates: open them in the browser and copy the long address.
- Lantify never stores or sees your customers' location: each customer's phone compares its own position with your place.
