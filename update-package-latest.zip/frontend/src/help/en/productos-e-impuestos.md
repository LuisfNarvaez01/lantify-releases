# Products, inventory and taxes
<!-- id: productos-e-impuestos | roles: ADMIN | module: settings -->

<!-- keywords: product, price, category, variant, inventory, stock, vat, consumption tax, tax, import -->

Products are managed in **Admin → Products** (administrators only).

- Each product has variants (sizes) with price, cost and SKU.
- **Taxes:** the price already includes tax. Each product uses the business tax or its own: consumption tax 8 %, VAT 19 %, VAT 5 % or no tax.
- **Inventory:** turn on stock tracking per product; it's deducted when charging and warns you when running low.
- You can import many products at once from a CSV file.
