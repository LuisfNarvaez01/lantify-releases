# Pantalla del cliente
<!-- id: pantalla-del-cliente | roles: ADMIN,CASHIER | module: pos -->

<!-- keywords: pantalla del cliente, segunda pantalla, monitor, total, propina, qr de pago, nequi, bre-b, tablet, pro -->

Es del plan **Pro**. Una tablet o monitor junto a la caja, mirando al cliente, muestra lo que se le está cobrando.

1. En **Administración → Salón y mesas → Funciones**, enciende **Pantalla del cliente**.
2. En **Ajustes del negocio → Pagos**, sube la imagen del **QR de pago** de tu Nequi, Daviplata o Bre-B y escribe el texto que va debajo (por ejemplo *Nequi 300 123 4567*).
3. En **Salón y mesas → Pantallas**, agrega una pantalla de tipo **Cliente (junto a la caja)**. En la tablet abre la dirección que aparece y escribe el código de 6 números.
4. Si tienes varias cajas, en cada equipo de caja toca **Usar en esta caja** junto a su pantalla. Con una sola pantalla no hace falta.

Mientras armas el pedido, la pantalla muestra las líneas, el total, la **propina sugerida** (la de Ajustes del negocio) y el QR de pago. Sin pedido muestra el happy hour vigente, tus productos con foto y el QR de tu página.

- La pantalla solo muestra: nunca cobra ni cambia la venta. Si se desconecta, la caja sigue cobrando igual.
- Lantify no ve ni confirma el pago por QR: revisa el comprobante como siempre.
