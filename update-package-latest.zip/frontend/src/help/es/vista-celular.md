# Vista para celulares y meseros
<!-- id: vista-celular | roles: ADMIN,CASHIER | module: pos -->

<!-- keywords: celular, móvil, mesero, mis mesas, pedidos, avisos, comanda, cocina, pre-cuenta, wifi, red local -->

Cuando abres Lantify en un teléfono celular o pantalla pequeña, el sistema muestra una vista optimizada con botones táctiles grandes y tres secciones en la barra inferior:

- **Mesas:** muestra la cuadrícula del salón con el estado de cada mesa. Puedes filtrar por **Mis mesas** para ver únicamente las mesas que abriste y estás atendiendo, o ver todas las del local. Cada recuadro muestra el total actual, minutos sin pedir o si la cuenta ya fue solicitada.
- **Pedidos:** lista las comandas abiertas con el tiempo transcurrido por cada ronda de pedidos. Al tocar una mesa entras de inmediato a tomar o completar la orden.
- **Avisos:** reúne alertas operativas de tus mesas, como mesas inactivas o cuentas pendientes de cobro.

### Cómo tomar un pedido desde el celular

1. Conecta el celular a la **misma red WiFi** del computador principal de la caja. Sin esa conexión local, el celular no se comunicará con el POS.
2. Abre la dirección del sistema en el navegador del teléfono. Desde el menú del navegador puedes seleccionar *Agregar a la pantalla de inicio* para usarlo a pantalla completa como una aplicación.
3. Inicia sesión con tu usuario.
4. Toca la mesa deseada en **Mesas**.
5. Selecciona las categorías y pulsa **+** en los productos que el cliente desea pedir.
6. Pulsa la barra inferior **Enviar a cocina** para imprimir o enviar la comanda con sus comentarios.
7. Cuando el cliente termine, pulsa **Pedir cuenta** para marcar la mesa y llevar la pre-cuenta.
