# Productos, inventario e impuestos
<!-- id: productos-e-impuestos | roles: ADMIN | module: settings -->

<!-- keywords: producto, precio, categoría, variante, inventario, stock, iva, impoconsumo, impuesto, importar -->

Los productos se administran en **Administración → Productos** (solo administradores).

- Cada producto tiene variantes (tamaños) con precio, costo y SKU.
- **Impuestos:** el precio ya incluye el impuesto. Cada producto usa el impuesto del negocio o uno propio: impoconsumo 8 %, IVA 19 %, IVA 5 % o sin impuesto.
- **Inventario:** activa el control de existencias por producto; se descuenta al cobrar y avisa cuando queda poco.
- Puedes importar muchos productos a la vez desde un archivo CSV.
