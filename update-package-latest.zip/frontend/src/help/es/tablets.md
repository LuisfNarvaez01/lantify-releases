# Comandar desde tablets y celulares
<!-- id: tablets | roles: ADMIN | module: settings -->

<!-- keywords: tablet, celular, mesero, wifi, red, qr, ip, conectar, comandar -->

Los meseros pueden tomar pedidos desde su celular o tablet, sin instalar nada.

1. El celular debe estar en el **mismo WiFi** que el computador de la caja.
2. En **Administración → Mi negocio → Usuarios y roles**, baja hasta *Conectar tablets y celulares*.
3. Escanea el **código QR** con la cámara y entra con el usuario del mesero.
4. Desde el menú del navegador puedes *Agregar a la pantalla de inicio* para abrirlo como una app.

Si un día deja de abrir (por ejemplo, después de reiniciar el router), vuelve a esa pantalla y escanea el código nuevo.
