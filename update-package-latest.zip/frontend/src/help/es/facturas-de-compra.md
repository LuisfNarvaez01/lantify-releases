# Registro de facturas de compra y cuentas por pagar
<!-- id: facturas-de-compra | roles: ADMIN,CASHIER | module: settings -->

<!-- keywords: facturas, compras, gastos, proveedores, insumos, inventario, cuentas por pagar, crédito, foto -->

Registra las facturas de tus proveedores con una foto para actualizar gastos e inventario en un solo paso. Una factura de insumos nunca se registra sola: siempre pasa por tu revisión antes de guardarse.

### Cómo registrar una factura

1. En **Gastos**, pulsa **Foto de factura** y sube la imagen tomada con el celular.
2. Se abre la pantalla de revisión con la foto a un lado y el formulario al otro.
3. Si el proveedor no existe en el sistema, pulsa **Revisar y crear proveedor** para guardar sus datos tomados de la factura.
4. Elige el tipo de factura: **Insumos (inventario)** si trae ingredientes o productos, o **Gasto o servicio** si es un servicio general.
5. Revisa la tabla de lo que trae la factura. Vincula cada línea a un ingrediente o producto existente, o pulsa **+ Crear ingrediente nuevo**. Si compraste por bulto o paca, define el factor de conversión a la unidad base (por ejemplo, 1 caja = 24 unidades). Verás el costo nuevo por unidad y cuánto varió frente a la última compra.
6. En la sección de pago, indica si la factura está **Pagada** (indicando la cuenta o medio de pago) o si queda **A crédito** con su fecha de vencimiento.
7. Pulsa **Confirmar y registrar**. El sistema guarda todo junto: el gasto contable, la entrada de inventario y el nuevo costo promedio ponderado.

### Facturas aprendidas y cuentas por pagar

- **Reconocimiento automático:** la próxima vez que subas una factura del mismo proveedor, Lantify recuerda las equivalencias anteriores y muestra la etiqueta **Ya lo conozco**, ahorrándote tiempo.
- **Cuentas por pagar:** las facturas a crédito quedan en la pestaña de cuentas por pagar dentro de proveedores y gastos. Cuando hagas el abono, toca **Registrar pago…** para convertirlo en un gasto del medio elegido.
