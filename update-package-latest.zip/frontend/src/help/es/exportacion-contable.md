# Exportar la contabilidad del mes a Siigo o Alegra (beta)
<!-- id: exportacion-contable | roles: ADMIN | module: cash -->

<!-- keywords: contador, contabilidad, siigo, alegra, puc, comprobante, libro de ventas, csv, excel, iva, impoconsumo, propinas, exportar -->

Plan Pro en adelante. Es una función **beta**: revisa los archivos con tu contador y con la plantilla que descarga cada programa antes de importarlos.

1. En **Administración → Datos del negocio**, enciende **Exportación contable (Siigo y Alegra)**.
2. Ve a **Caja → Informe mensual**, elige el mes y abre la pestaña **Exportación contable**.
3. En **Cuentas PUC** escribe las cuentas que te dé tu contador (caja, bancos, tarjetas, ingresos, IVA, impoconsumo, propinas) y guarda. Si no las cambias se usan las del PUC general (110505, 111005, 413505, 240805, 249505, 280505).
4. Descarga lo que necesites:
   - **Libro de ventas (CSV)**: una fila por venta cobrada con su número corto (C1-000123), base, IVA, impoconsumo, total, propina y medios de pago. Se abre en Excel.
   - **Comprobante para Siigo Nube**: un comprobante por día. En Siigo: Configuración › Contabilidad › Importación › Comprobantes contables. Si el mes pasa de 500 registros salen varios archivos.
   - **Comprobante para Alegra**: el mismo comprobante diario. En Alegra: Contabilidad › Comprobante contable › Más acciones › Importar comprobantes.
   - **Informe para el contador** (PDF o Excel): comprobantes, cierres de caja, gastos y facturas del mes.

Cada comprobante cuadra (débitos = créditos): el efectivo va a caja, las transferencias y billeteras a bancos y la tarjeta a su cuenta; al crédito van los ingresos, el IVA, el impoconsumo y las propinas (que son de los empleados, no ingreso del negocio). Las ventas anuladas y devueltas no se incluyen.

Lantify solo **lee** las ventas: exportar nunca cambia una venta ni la caja.
