# Aparecer en «Lugares con Lantify»
<!-- id: lugares-con-lantify | roles: ADMIN | module: settings -->

<!-- keywords: directorio, lugares, ciudad, página, google, aparecer, buscar restaurantes, lantifypos.com/lugares -->

Todos los planes. Está **apagado** hasta que tú lo enciendas.

1. En **Mi página → Perfil & Datos Legales**, enciende **Aparecer en el directorio «Lugares con Lantify»**.
2. Escribe la **ciudad** en el perfil y publica la página. Sin ciudad no apareces.

Tu negocio sale en **lantifypos.com/lugares** y en la página de tu ciudad (por ejemplo lantifypos.com/lugares/neiva), con la foto de portada, el tipo de negocio, tu frase y el enlace a tu página. Solo se muestra eso: nunca la dirección, el teléfono, el NIT ni nada de tus ventas.

Si lo apagas, desapareces del directorio en cuanto la página se vuelve a publicar (unos minutos).
