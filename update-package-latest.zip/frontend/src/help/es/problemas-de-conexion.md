# Problemas de conexión y errores
<!-- id: problemas-de-conexion | roles: ADMIN,CASHIER,WAITER | module: other -->

<!-- keywords: error, conexión, servidor, no conecta, failed to fetch, credenciales, contraseña, lento, sin internet -->

- **Sin conexión con el servidor:** el programa de Lantify no está abierto en el equipo principal, o esta tablet no está en la misma red. Ábrelo y toca *Reintentar*.
- **El servidor tardó demasiado:** espera un momento y repite; si sigue, reinicia Lantify.
- **Error de credenciales:** el usuario o la contraseña no coinciden. Revisa mayúsculas y el teclado.
- **Demasiados intentos:** por seguridad se bloquea un momento después de varios intentos fallidos.
- **No tienes permiso:** la acción es de otro rol; pide ayuda a un administrador.

Lantify funciona sin internet: solo el asistente con IA y la factura electrónica necesitan conexión.
