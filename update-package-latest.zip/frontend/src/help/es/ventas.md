# Historial de ventas
<!-- id: ventas | tour: sales | roles: ADMIN,CASHIER | module: sales -->

<!-- keywords: ventas, historial, reimprimir, factura, anular venta, buscar venta, exportar -->

En **Ventas** ves las ventas del día y anteriores con totales por medio de pago.

- Filtra por fecha, canal o medio de pago y busca por número o cliente.
- Abre una venta para ver sus productos, **reimprimir** el recibo o emitir la **factura electrónica** después.
- Anular una venta devuelve el dinero de la caja y el inventario; queda registrada en la auditoría.

[[tour:sales|Mostrarme el recorrido]]
