# Puerta: cover, manillas y aforo
<!-- id: puerta-y-aforo | roles: ADMIN,CASHIER | module: settings -->

<!-- keywords: puerta, portero, cover, entrada, manilla, aforo, ocupación, discoteca, bar, noche, pro -->

Es del plan **Pro**. Una pantalla para el celular del portero con la ocupación en vivo.

1. En **Administración → Negocio → Funciones**, enciende **Puerta: cover y aforo**.
2. En **Configuración → Ajustes del negocio → Puerta**, escribe el **aforo máximo**.
3. En **Productos**, marca el cover con **Es un cover (entrada)**: cada unidad cobrada suma una entrada.
4. Crea un usuario con el rol **Portero**: al entrar va directo a la pantalla **Puerta** y no ve ventas, caja ni carta.

En la Puerta: **Entra (+1)** para quien entra sin cover (lista, cortesía), **Sale (−1)** para quien sale, y el **código de la manilla** para registrar entradas y salidas con manilla (una manilla no entra dos veces sin salir). Al 90 % del aforo avisa en amarillo y lleno en rojo; nunca bloquea una venta ni una entrada.

La noche va de mediodía a mediodía. El **informe de la noche** (Ajustes del negocio → Puerta) muestra covers cobrados, entradas, salidas y el pico de ocupación.
