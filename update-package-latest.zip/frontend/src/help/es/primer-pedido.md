# Tu primer pedido
<!-- id: primer-pedido | tour: first-order | roles: ADMIN,CASHIER,WAITER | module: pos -->

<!-- keywords: empezar, vender, pedido, producto, agregar, buscar, mostrador -->

En la pantalla **Pedidos** se toma cualquier venta, en mesa o en mostrador.

1. Elige dónde atiendes: **Mostrador** o una mesa en la lista de la izquierda.
2. Busca el producto por nombre, código o con el lector de barras. La tecla `/` lleva al buscador.
3. Toca el producto para agregarlo. Si tiene tamaños o presentaciones, eliges una.
4. En el pedido (a la derecha) ajusta cantidades, agrega notas para cocina o quita productos.
5. Envía a cocina con **Cocina** o la tecla `F4`, y cobra con **Cobrar** o `F2`.

[[tour:first-order|Mostrarme el recorrido]]
