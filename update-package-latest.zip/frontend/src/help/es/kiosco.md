# Kiosco de autoservicio
<!-- id: kiosco | roles: ADMIN,CASHIER | module: pos -->

<!-- keywords: kiosco, autoservicio, tablet, pedir solo, fila, número, pagar en caja, qr, premium -->

Es del plan **Premium**. Una tablet en la entrada donde el cliente pide solo.

1. En **Administración → Salón y mesas → Funciones**, enciende **Kiosco de autoservicio**.
2. En **Pantallas**, agrega una de tipo **Kiosco de autoservicio**. En la tablet abre la dirección que aparece y escribe el código de 6 números.
3. Opcional: sube tu **QR de pago** en **Ajustes del negocio → Pagos** para que el cliente pueda pagar con su app.

El cliente toca **Toca para pedir**, elige productos con foto y su presentación, quita ingredientes o deja un comentario con el teclado de la pantalla, escribe su nombre y elige **En la caja** o **Con QR**. Recibe un número, por ejemplo **K7**.

En la caja el pedido aparece en **Domicilios → Pedidos web** con la etiqueta **Kiosco** y suena el aviso. Acéptalo (va a cocina) y cóbralo con su número como cualquier pedido.

- Los precios los pone la caja, no la tablet.
- Si nadie toca la tablet por un minuto y medio, vuelve al inicio y se borra el pedido a medias.
- Los pedidos del kiosco no se suben a tu página ni a la nube.
