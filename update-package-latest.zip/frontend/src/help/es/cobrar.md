# Cobrar una cuenta
<!-- id: cobrar | tour: first-order | roles: ADMIN,CASHIER | module: pos -->

<!-- keywords: cobrar, pagar, propina, efectivo, tarjeta, transferencia, cambio, combinado, pago parcial, dividir cuenta -->

Toca **Cobrar** (o `F2`). La ventana de cobro muestra:

- **Resumen:** subtotal, descuento y los impuestos que ya vienen incluidos en el precio.
- **Propina voluntaria:** sin propina, la sugerida o *Otro valor*. Solo aparece si el negocio la maneja (*Administración → Datos del negocio → ¿Manejas propina?*). La propina no hace parte de la venta ni de la factura.
- **Medio de pago:** efectivo, tarjeta, transferencia o combinado. Con efectivo, usa *Exacto* o los billetes sugeridos y verás el cambio.
- **Pagar solo algunos productos:** para dividir la cuenta; los demás quedan pendientes en la mesa.

Al confirmar se imprime el recibo. Si marcaste **Factura electrónica DIAN**, en lugar del recibo se imprime la factura cuando se emite.

## Pre-cuenta

El botón **Pre-cuenta** imprime el total para que el cliente lo revise, con la propina sugerida y el total con propina. No es una factura.
