# Configurar el negocio
<!-- id: configurar-negocio | tour: settings | roles: ADMIN | module: settings -->

<!-- keywords: configuración, negocio, nit, propina, impuestos, mesas, asistente, ticket, factura electrónica, dian, factus -->

En **Administración → Mi negocio → Datos del negocio** están los datos que salen en el ticket y en la factura: nombre, NIT, dirección, régimen de impuestos y opciones de operación (mesas, propina, inventario, domicilios).

- **Propina:** activa *¿Manejas propina?* y el porcentaje sugerido. Solo entonces aparece al cobrar y en la pre-cuenta.
- **Asistente:** *Abrir asistente* repite la configuración inicial sin borrar productos, mesas ni ventas.
- **Factura electrónica:** en *Cuenta y sistema → Facturación DIAN* conectas tu proveedor y tu resolución.
- **Impresión, apariencia y mesas** están en el mismo grupo *Mi negocio*.
- **¿Qué falta por configurar?** Abre la *Guía de configuración* (primer botón del menú).

[[tour:settings|Mostrarme el recorrido]]
