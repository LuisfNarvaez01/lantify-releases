# Reparto de propinas
<!-- id: reparto-de-propinas | roles: ADMIN,CASHIER | module: cash -->

<!-- keywords: propinas, reparto, meseros, cocina, porcentajes, arqueo, turnos, aportes, liquidación -->

El **Reparto de propinas** permite distribuir de forma clara y equitativa el dinero voluntario dejado por los comensales. Requiere tener encendida la función Personal y se configura en **Administración → Funciones**.

### Reglas de distribución

El negocio define cómo se reparte el pozo total del periodo:

- **Porcentajes por grupo:** asigna qué porcentaje le corresponde a cada grupo de trabajo (Meseros, Caja, Cocina, Barra, Otros). La suma de todos los grupos debe dar exactamente el 100 %.
- **Distribución entre meseros:** puedes elegir entre **Partes iguales** (todos los meseros que trabajaron reciben lo mismo) o **Según lo que cada uno aportó** (proporcional al monto de propinas cobrado en las comandas de cada mesero). En los demás grupos se reparte en partes iguales entre quienes registraron turno.
- **Periodos:** el reparto se puede liquidar **Cada semana**, **Cada arqueo de caja** o **Cada mes**.

### Cómo liquidar y confirmar el reparto

1. Entra a **Personal → Propinas** y selecciona el periodo a liquidar.
2. Lantify presenta una propuesta automática según las reglas configuradas y los turnos marcados.
3. **Ajustes manuales:** antes de confirmar, el administrador puede modificar cualquier valor asignado a mano si hubo casos especiales.
4. **Grupos sin personal en turno:** si un grupo tiene porcentaje asignado pero nadie registró turnos en ese periodo, su valor aparecerá como dinero pendiente por asignar. El administrador debe repartir ese saldo a mano entre los demás empleados antes de guardar.
5. Cuando todo cuadre al 100 %, pulsa **Confirmar reparto**. Los valores pasarán a la liquidación de pago de cada empleado.
