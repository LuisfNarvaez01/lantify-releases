# Varias sedes: tablero del dueño y copiar la carta
<!-- id: varias-sedes | roles: ADMIN | module: settings -->

<!-- keywords: sedes, sucursales, varios negocios, dueño, grupo, tablero, consolidado, copiar carta, exportar carta, importar carta, menú -->

Plan Premium. Cada sede sigue siendo un negocio con su propio código, su caja y sus ventas; el grupo solo le muestra al dueño los resúmenes.

**Crear el grupo y unir las sedes** (en lantifypos.com/cuenta):

1. Entra a **Mi cuenta** con el negocio principal y, en **Varias sedes**, toca **Crear grupo**.
2. Toca **Invitar una sede**: sale un código como SEDE-ABCD-2345 (sirve una vez y vence en 7 días).
3. Entra a **Mi cuenta** con el ADMIN de la otra sede, escribe el código y **confirma**. Sin esa confirmación la sede no comparte nada.

Desde ese momento, el negocio principal ve en **Mi cuenta** el tablero de todas las sedes: ventas y cierres de los últimos 30 días, diferencias de caja y avisos del Autopilot. Las sedes no ven a las demás. El dueño puede quitar una sede y una sede puede salirse cuando quiera.

**Copiar la carta de una sede a otra** (en el programa):

1. En **Administración → Datos del negocio**, enciende **Varias sedes** en las dos sedes.
2. En la sede de origen toca **Exportar la carta**: se descarga un archivo .json.
3. En la otra sede toca **Importar una carta** y elige el archivo. Verás qué productos, categorías, presentaciones y recetas se crean o cambian; toca **Aplicar cambios**.

Se compara por nombre: importar dos veces el mismo archivo no cambia nada. Nunca toca existencias, costos, ventas ni fotos, y los productos que no vienen en el archivo se quedan como están.
