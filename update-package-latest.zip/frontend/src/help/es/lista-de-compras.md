# Lista de compras por proveedor
<!-- id: lista-de-compras | roles: ADMIN,CASHIER | module: settings -->

<!-- keywords: compras, proveedores, lista de compras, inventario, stock mínimo, reposición, whatsapp, pedidos insumos -->

La función **Lista de compras por proveedor** te permite revisar qué insumos o productos están agotándose y armar pedidos en segundos para enviarlos a cada proveedor. Se activa en **Administración → Funciones**.

### Configurar los datos de reposición

En **Inventario**, cada producto con control de existencias tiene un botón de **Reposición**:

- **Stock mínimo:** la cantidad límite de alerta. Si dejas este valor vacío, Lantify utiliza 5 unidades por defecto.
- **Cantidad a pedir:** el número sugerido de unidades al momento de hacer el pedido. Si no lo defines, el sistema sugiere lo necesario para llegar al doble del mínimo.
- **Unidad de compra:** cómo te despacha el proveedor (cajas, kilogramos, pacas, botellas).
- **Proveedor:** el proveedor asignado para ese producto.

### Generar y enviar la lista de compras

1. En la pestaña **Inventario**, toca el botón **Lista de compras**.
2. Lantify revisará las existencias y agrupará todos los productos que estén en o por debajo de su stock mínimo, organizados por proveedor (los artículos sin proveedor quedan bajo el encabezado *Sin proveedor*).
3. Revisa la lista: puedes ajustar las cantidades a pedir o tocar el botón para quitar cualquier renglón que no desees ordenar hoy.
4. Para despachar el pedido a cada proveedor:
   - **Copiar:** copia el texto del pedido al portapapeles para pegarlo en un correo o mensaje.
   - **Enviar por WhatsApp:** abre un chat directo con el número guardado del proveedor con el mensaje formateado listo para enviar.
