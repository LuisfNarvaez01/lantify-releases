# Asistencia con PIN y horario semanal
<!-- id: asistencia-con-pin | roles: ADMIN,CASHIER | module: settings -->

<!-- keywords: asistencia, pin, marcar entrada, marcar salida, reloj, llegadas tarde, horario, turnos, cocina, personal, pro -->

Es del plan **Pro** y necesita **Personal** encendido. Sirve para que quien no tiene usuario (cocina, oficios) marque su entrada y salida.

1. En **Administración → Personal**, enciende **Asistencia con PIN**.
2. En la pestaña **Asistencia**, toca **Poner PIN** a cada persona (4 a 6 números; no se aceptan 1234 ni 0000). Díselo en privado: nadie más puede verlo.
3. Arma el **Horario de la semana** de cada persona: toca **Turno** en cada día y pon la hora de entrada y de salida.

Para marcar:

- **En la caja:** menú de tu usuario → **Marcar asistencia**. La persona toca su nombre y escribe su PIN.
- **En una tablet:** en **Salón y mesas → Pantallas**, agrega una de tipo **Asistencia (PIN)** y conéctala con el código.

Si no tiene turno abierto, marca la **entrada**; si lo tiene, la **salida**. Los turnos quedan en **Horario y turnos** como siempre.

El **Informe de asistencia** compara lo programado con lo trabajado y muestra las llegadas tarde (más de 5 minutos) y los turnos sin entrada.

- Tras 5 PIN equivocados, esa persona espera 10 minutos.
- Si alguien olvida su PIN, ponle uno nuevo.
