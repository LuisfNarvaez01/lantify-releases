# La app encuentra la caja sola
<!-- id: caja-sola-en-la-red | roles: ADMIN | module: settings -->

<!-- keywords: celular, android, red local, wifi, ip, router, encontrar, caja, mdns, tablets, conexión -->

Funciona en todos los planes. Sirve cuando el router le cambia la dirección (IP) a la caja y la app Android del celular ya no la encuentra por la red del local.

1. En **Administración → Usuarios → Celulares**, enciende **La app encuentra la caja sola**.
2. Las **tablets en la red local** deben estar activadas (en la app de escritorio): sin eso la caja no se anuncia.

Cuando las direcciones guardadas no responden, la app Android busca la caja en la red antes de pasar a internet. Solo usa una caja que responda con la huella de **tu** negocio: nunca se conecta a la caja de otro local en la misma red. Si no la encuentra, sigue por internet (relevo de Lantify Cloud) como siempre.

En el iPhone (versión web) no hay búsqueda automática: si cambia la IP, vuelve a escanear el QR de **Conectar tablets**.
