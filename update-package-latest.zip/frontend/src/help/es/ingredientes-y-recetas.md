# Ingredientes, recetas y control de existencias
<!-- id: ingredientes-y-recetas | roles: ADMIN,CASHIER | module: settings -->

<!-- keywords: inventario, ingredientes, recetas, kardex, existencias, costo, margen, desperdicio, ajuste, merma -->

Controla los insumos de tu cocina y el costo real de cada plato desde el inventario.

### Crear y ajustar ingredientes

1. Ve a **Inventario → Ingredientes** y pulsa **Nuevo ingrediente**.
2. Escribe el nombre, la categoría y la unidad base de manejo: **Gramos (g)**, **Mililitros (ml)** o **Unidades (und)**.
3. Ingresa el costo inicial por kilo, litro o unidad, junto con la existencia inicial y el stock mínimo deseado.
4. Para cuadrar cantidades a mano, usa el botón **Ajustar** en la fila del insumo. Puedes registrar un conteo físico, reportar desperdicio o hacer un ajuste sumando o restando.
5. Toca el historial para ver los movimientos de kardex: compras, ventas, anulaciones, desperdicio y ajustes.

### Configurar receta e ingredientes en tus productos

1. Ve a **Inventario → Productos** y selecciona un producto.
2. Toca el botón del gorro de chef (**Receta e ingredientes**; el botón aparte de Ingredientes ya no existe). La ventana tiene dos pestañas:
   - **Con receta**: ingredientes del inventario con su cantidad (incluye empaques como vasos o bolsas). Cada fila tiene la casilla **Se puede quitar**: lo marcado aparece en los comentarios del pedido para pedirlo "sin"; desmárcala en empaques, sal o aceite. El costo del producto se calcula con la receta (en **Editar producto** el costo queda bloqueado y lo explica).
   - **Sin receta**: para negocios que no llevan inventario de ingredientes. Escribe la lista de lo que se puede quitar y el costo se escribe a mano en **Editar producto**. Guardar en **Sin receta** borra la receta que hubiera.
3. En **Con receta**, el sistema calcula en pantalla el costo de receta, el precio de venta y el margen bruto. Si el margen cae por debajo del mínimo configurado (30 % por defecto), Lantify muestra una alerta visual.
4. El costo de los platos con receta se actualiza automáticamente cuando compras insumos a precios nuevos, pero el precio de venta nunca cambia solo.

### Qué pasa al vender o anular

- **Al cobrar:** el sistema descuenta de inmediato los ingredientes de cada porción vendida. Si las existencias no alcanzan, la venta se completa sin detener la atención y el saldo queda en negativo para que luego lo ajustes.
- **Al anular:** los insumos regresan al stock. Si quien anula indica que el plato ya se había preparado, queda registrado como desperdicio y no regresa.
