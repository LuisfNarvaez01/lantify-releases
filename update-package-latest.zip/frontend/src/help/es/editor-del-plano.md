# Editor del plano del salón
<!-- id: editor-del-plano | roles: ADMIN,CASHIER | module: pos -->

<!-- keywords: plano, salón, mesas, editor, zonas, mover, girar, cuadrícula, barra, paredes, atajos -->

Diseña la distribución exacta de tu negocio con las herramientas del editor visual.

### Agregar mesas y elementos estructurales

1. Ve a **Salón y mesas** y abre el editor del plano.
2. Para añadir puestos de atención, pulsa **Mesa** y elige su forma: cuadrada, redonda, rectangular o puesto de barra. Asigna su número y cantidad de puestos.
3. Para representar tu espacio real, pulsa **Elemento** y añade paredes, puertas, barras, cocina, baños, plantas, áreas o cajas de texto informativas.

### Cómo organizar y mover elementos

- **Rejilla con imán y guías:** arrastra cualquier objeto para alinearlo con la cuadrícula de 8 px. Si mantienes presionada la tecla **Shift** al arrastrar, el movimiento es libre.
- **Seleccionar varios:** haz clic sobre varios elementos manteniendo presionado **Ctrl** o **Shift**, o arrastra una caja de selección sobre un espacio vacío.
- **Mover con precisión:** usa las flechas del teclado para desplazar la selección 1 px (**Shift** + flecha para mover 10 px).
- **Girar y cambiar tamaño:** presiona la tecla **R** para girar 15° o usa los botones de rotación. Arrastra la esquina azul para cambiar el ancho y alto.
- **Duplicar y eliminar:** presiona **Ctrl+D** para duplicar o **Supr** para quitar. No se puede quitar una mesa que tenga un pedido abierto.
- **Alinear y repartir:** usa los botones de la barra para centrar, alinear a los bordes o distribuir elementos de manera uniforme.
- **Deshacer, rehacer y zoom:** cuentas con **Ctrl+Z** para deshacer, **Ctrl+Y** para rehacer y **Ctrl + rueda del ratón** para alejar o acercar.
- **Zonas:** organiza el plano creando zonas para separar terraza, salón principal o barra.

Nada de lo que hagas se guarda hasta que pulses **Guardar** (o uses **Ctrl+S**). Si sales sin guardar, puedes descartar los cambios.
