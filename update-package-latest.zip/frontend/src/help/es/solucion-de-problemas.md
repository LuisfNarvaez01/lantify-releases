# Solución de problemas frecuentes
<!-- id: solucion-de-problemas | roles: ADMIN,CASHIER | module: settings -->

<!-- keywords: problemas, error, solución, mensajes, wifi, caja, pantallas, agentes, fotos, cierre, soporte -->

Guía rápida para resolver los mensajes e incidencias más comunes en Lantify:

| Si ves este mensaje | Qué significa | Qué hacer |
| --- | --- | --- |
| "El computador de la caja tiene una versión de Lantify más vieja…" | El computador principal de la caja tiene una versión más vieja de Lantify que no incluye esta función. | En el computador de la caja ve a **Administración → Acerca de → Buscar actualizaciones**, instala la última versión y reinicia. Si estás probando una versión en desarrollo, cierra el Lantify instalado. |
| "El servicio de IA de Lantify todavía no tiene esta función…" | El servicio de IA en la nube todavía no tiene habilitada esta tarea o herramienta. | No es un fallo de tu equipo ni de tus datos. La función se activará automáticamente cuando Lantify actualice el servicio; mientras tanto usa las demás tareas del agente. |
| "Ya usaste las fotos con IA de hoy o del mes…" | Se agotó el cupo de fotos con IA disponible para el día o mes según tu suscripción. | Pulsa **Subir foto** en el estudio de flyers o catálogo y utiliza una imagen tomada con tu propio celular. |
| "El administrador debe autorizar el uso de la IA…" | Falta autorización administrativa para enviar resúmenes del negocio al asistente de IA. | Entra como administrador a **Administración → Asistente IA** y activa la casilla para autorizar el uso de la IA. |
| "No se pudo conectar con el servidor" o "Sin conexión con la caja" | Tu tablet, celular o pantalla no logra comunicarse con el computador de la caja. | Verifica que la caja esté encendida con Lantify abierto, que ambos equipos estén en la misma red WiFi y que la dirección sea `http://IP:5000`. En **Usuarios y roles** pulsa **Probar conexión** para ver la causa exacta (Firewall, red Pública o varias redes) y usa **Reparar ahora**. |
| "En el celular se queda cargando" | El navegador no alcanza la dirección local de la caja o la red bloquea la comunicación interna. | Verifica que el celular esté en el mismo WiFi que la caja y apaga los datos móviles. Revisa que el router no tenga activa una red de invitados o aislamiento de clientes. |
| **Disponible en el plan Pro** | Intentas abrir pantallas o funciones avanzadas no incluidas en tu plan actual. | Revisa y mejora tu suscripción en **Administración → Plan y suscripción**. |
| **El correo del cierre no llega** | El reporte de arqueo no aparece en la bandeja de entrada del dueño. | Revisa el correo configurado en **Datos del negocio → Reporte de cierre** y mira la carpeta de spam. Sin internet se enviará en cuanto regrese la conexión. |
| **Pantalla ya no está conectada** | El TV perdió la sesión o el código temporal de emparejamiento caducó. | Ve a **Salón y mesas → Pantallas**, genera un **Nuevo código** de 6 dígitos y escríbelo en el navegador del TV. |
| "Autopilot dice que está aprendiendo" | Lantify necesita 14 días con ventas para conocer el ritmo de tu negocio y anticipar horas flojas o picos. | Sigue usando Lantify con normalidad; lo demás ya funciona mientras reúne los 14 días de historia. |
