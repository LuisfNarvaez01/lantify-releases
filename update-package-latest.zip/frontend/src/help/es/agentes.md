# Agentes de inteligencia artificial
<!-- id: agentes | roles: ADMIN | module: settings -->

<!-- keywords: agentes, ia, administración, compras, marketing, tareas, perfil, whatsapp, cupón, premium -->

Los agentes de IA analizan tu negocio y te ayudan a tomar decisiones operativas sin tecnicismos. Requieren el plan Premium y autorizar el uso de la IA en **Administración → Asistente IA**.

### Los tres agentes especializados

- **Administración:** tu analista de cabecera. Evalúa ventas de la semana contra la anterior, márgenes de ganancia, horas flojas o fuertes, gastos y proyección mensual.
- **Compras:** tu jefe de abastecimiento. Calcula qué insumos pedir, detecta faltantes antes del fin de semana y compara precios entre proveedores.
- **Marketing:** tu asesor comercial. Diseña flyers para tus promociones, propone campañas para días quietos y crea cupones de fidelización.

### Tareas listas y respuestas en vivo

Cada agente incluye **Tareas** predefinidas con botones rápidos (como *Cómo me fue esta semana* o *Pedido de la semana*), además de un campo para preguntas libres. Las respuestas se generan en vivo mientras el modelo procesa la información, mostrando indicadores de avance. Cada análisis presenta cifras clave en tarjetas destacadas, explicaciones claras y botones de acción directa, como **Enviar por WhatsApp** al proveedor o **Crear este cupón**.

### Tu negocio para la IA y privacidad

En la parte superior encontrarás la tarjeta **Tu negocio para la IA**. Completar la oferta, clientes objetivo, tono de voz y colores de marca permite que los agentes redacten sugerencias acordes a tu actividad real y no respuestas genéricas.

Lantify protege tu privacidad: solo se transmiten resúmenes agregados del negocio, nunca nombres, teléfonos ni cédulas de tus clientes. Puedes pulsar **Qué datos se envían** para revisar el resumen exacto en cualquier momento.
