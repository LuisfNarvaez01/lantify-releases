# Usuarios y roles
<!-- id: usuarios-y-roles | roles: ADMIN | module: settings -->

<!-- keywords: usuario, rol, cajero, mesero, administrador, contraseña, permisos, personal, corregir pago -->

Cada persona entra con su propio usuario. Se crean en **Administración → Mi negocio → Usuarios y roles** (si activas la función de personal en Funciones, esta sección pasa a llamarse **Personal**).

- **Mesero:** toma pedidos y los envía a cocina.
- **Cajero:** por defecto, además cobra, maneja la caja y ve las ventas.
- **Administrador:** todo, incluida la configuración y la autorización de anulaciones.

En la tabla **Funciones de cada rol** decides qué puede hacer el cajero y el mesero (cobrar, caja, historial, pedidos en línea, clientes, reservas, estadísticas y el permiso **Corregir el medio de pago**, que autoriza a cambiar medios de pago en ventas con el turno de caja abierto). Tomar pedidos siempre está permitido. En la misma pantalla está el QR para conectar tablets.

Si alguien olvida su contraseña, un administrador la restablece y la persona debe cambiarla al entrar.
