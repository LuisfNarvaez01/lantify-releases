# Usuarios y roles
<!-- id: usuarios-y-roles | roles: ADMIN | module: settings -->

<!-- keywords: usuario, rol, cajero, mesero, administrador, contraseña, permisos -->

Cada persona entra con su propio usuario. Se crean en **Administración → Usuarios y roles**.

- **Mesero:** toma pedidos y los envía a cocina. No cobra ni ve la caja.
- **Cajero:** además cobra, maneja la caja y ve las ventas.
- **Administrador:** todo, incluida la configuración y la autorización de anulaciones.

Si alguien olvida su contraseña, un administrador la restablece y la persona debe cambiarla al entrar.
