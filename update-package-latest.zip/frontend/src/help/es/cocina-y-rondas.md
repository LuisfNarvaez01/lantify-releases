# Cocina y rondas
<!-- id: cocina-y-rondas | tour: tables | roles: ADMIN,CASHIER,WAITER | module: pos -->

<!-- keywords: comanda, cocina, ronda, enviar, nota, mesero, tiempo de espera -->

Cada vez que envías productos nuevos a cocina se crea una **ronda** y se imprime su comanda.

- Las rondas aparecen en el pedido con la hora de envío y el tiempo de espera: verde a tiempo, ámbar después de 15 minutos y rojo después de 30.
- Las notas (*sin cebolla*, *para llevar*…) se escriben antes de enviar con **Agregar nota**.
- Los productos ya enviados no se pueden borrar; se **anulan** (ver *Anular un producto*).
- El pedido queda guardado en el servidor, así que otra caja o tablet ve la misma mesa.
