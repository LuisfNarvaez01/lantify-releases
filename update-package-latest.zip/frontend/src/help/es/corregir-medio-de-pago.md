# Corregir el medio de pago de una venta
<!-- id: corregir-medio-de-pago | roles: ADMIN,CASHIER | module: sales -->

<!-- keywords: corregir pago, medio de pago, efectivo, tarjeta, transferencia, arqueo, caja, ventas, historial -->

Si un cobro se registró por error con un medio de pago equivocado (por ejemplo, se marcó efectivo en lugar de transferencia), no necesitas anular la venta ni alterar el inventario. Puedes corregir el pago directamente desde el historial de ventas.

### Cómo corregir el pago

1. Entra a **Ventas** y abre el detalle de la venta que deseas modificar.
2. Toca el botón **Corregir pago**.
3. Selecciona los medios de pago correctos (Efectivo, Tarjeta, Transferencia) y escribe los montos correspondientes. Los pagos deben sumar exactamente el valor total cobrado.
4. Escribe de manera obligatoria el **Motivo de la corrección** (por ejemplo: "Cliente pagó por Nequi y cajero marcó efectivo").
5. Toca **Guardar corrección**.

### Condiciones y reglas

- **El valor total de la venta no cambia:** solo se redistribuye entre los medios de pago seleccionados.
- **Turno de caja abierto:** solo se puede corregir si el turno de caja donde se cobró la venta sigue abierto. Si la caja ya fue cerrada y firmada en el arqueo, los pagos no se pueden modificar.
- **Sin factura electrónica transmitida:** si la venta ya cuenta con una factura electrónica emitida y transmitida a la DIAN, el sistema no permite el cambio para mantener la validez fiscal.
- **Permisos requeridos:** esta acción la realiza el administrador o un cajero que tenga activo el permiso *Corregir el medio de pago*.
- **Auditoría:** el sistema guarda en el registro de auditoría quién hizo el cambio, la fecha y los valores anteriores. Si cambia el monto en efectivo, el efectivo esperado de la caja se recalcula automáticamente.
