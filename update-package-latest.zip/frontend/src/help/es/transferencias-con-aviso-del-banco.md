# Confirmar transferencias con el aviso del banco
<!-- id: transferencias-con-aviso-del-banco | roles: ADMIN,CASHIER | module: pos -->

<!-- keywords: transferencia, nequi, daviplata, bancolombia, bre-b, aviso, notificación, confirmar, cobrar, pago, celular, android, pro -->

Es del plan **Pro**. El celular del negocio lee el aviso de transferencia que ya mostró tu banco y la caja confirma sola el cobro.

1. En **Administración → Usuarios → Celulares**, enciende **Confirmar transferencias con el aviso del banco**.
2. En el celular del negocio (app Android de Lantify, con sesión de **administrador** o **cajero**), abre **Más opciones → Avisos de transferencias** y toca **Abrir Ajustes para activarlo**. Busca **Lantify POS** y activa el acceso a notificaciones.
3. En ese celular deben llegar los avisos de **Nequi**, **Daviplata**, **Bancolombia** o pagos **Bre-B** de la cuenta del negocio.

Al cobrar con **Transferencia**, la caja muestra **Esperando confirmación…**. Cuando llega un aviso del **mismo valor exacto** en los 15 minutos siguientes (o en los 15 anteriores), se pone en verde con el monto, quien envió y la hora. Si llegan dos cobros del mismo valor, se confirma primero el más antiguo.

- **Siempre** puedes confirmar el pago a mano: el aviso es solo una ayuda y nunca bloquea una venta.
- Lantify solo lee monto, remitente y hora de esas apps; todo lo demás se descarta en el teléfono. Los avisos se borran de la caja a las 24 horas.
- Lantify **nunca mueve dinero** ni entra a tus cuentas.
- Si apagas la función o quitas el permiso en Ajustes del celular, deja de leer avisos de inmediato.
