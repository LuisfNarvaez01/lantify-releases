# Motor de menú
<!-- id: motor-de-menu | roles: ADMIN | module: settings -->

<!-- keywords: motor de menu, rentabilidad, estrellas, caballos de batalla, rompecabezas, para revisar, sin costo, margen, carta -->

El motor de menú analiza las ventas de los últimos 60 días para ayudarte a tomar decisiones sobre tu carta. Lo encuentras en **Carta → Motor de menú** (o Administración → Carta).

### Las cinco clases de productos

Cada producto se clasifica según su popularidad y su margen de ganancia:

- **Estrellas:** se venden mucho y dejan buen margen. Cuídalas: procura que nunca falten insumos y mantén su receta y calidad.
- **Caballos de batalla:** se venden mucho pero dejan poco margen. Sube un poco su precio o negocia menores costos con proveedores.
- **Rompecabezas:** dejan buen margen pero se venden poco. Empújalos: dales visibilidad con fotos en la carta y actívalos en las sugerencias al mesero.
- **Para revisar:** se venden poco y dejan poco margen. Revísalos: cambia la receta, ajusta el precio o retíralos de la carta si no rotan.
- **Sin costo:** productos sin costo cargado. No se pueden clasificar por margen.

### Costo de productos y combinaciones

Es indispensable cargar el costo de cada producto en **Productos** para conocer la ganancia real de tu negocio; sin costo registrado, Lantify no puede calcular el margen ni ubicar el plato en la clase correspondiente.

La pantalla también muestra la **tendencia de 14 días** (comparando las últimas dos semanas contra las dos anteriores) para ver si un plato sube o baja de ritmo. Además, identifica **lo que se pide junto** en el mismo pedido, revelando combinaciones frecuentes para crear combos o promociones.
