# Pantallas de cocina, entregas y salón
<!-- id: pantallas | roles: ADMIN,CASHIER | module: pos -->

<!-- keywords: pantallas, cocina, entregas, salón, mesero, kds, tv, wifi, código, listo, recoger, entregado, pro -->

Las pantallas muestran comandas e información operativa en televisores o tablets conectados al WiFi del local. No muestran precios, totales ni datos de clientes. Requiere el plan Pro.

Existen tres tipos de pantalla:

- **Cocina (KDS):** muestra las comandas en tarjetas por orden de llegada con tiempos, mesa y notas. Al tocar un producto se tacha. Toca **Listo** para despachar la comanda o **Deshacer** si te equivocas. Admite teclado: números para seleccionar, **Enter** para marcar listo y la tecla **U** para deshacer. Emite un sonido al recibir una orden.
- **Entregas (para clientes):** televisor para el público con las columnas *Preparando* y *¡Listo! Recoge tu pedido*.
- **Salón (para meseros):** vista rápida del salón con mesas ocupadas y platos por recoger.

### Cómo conectar una pantalla

1. En la caja principal, ve a **Salón y mesas → Pantallas**.
2. Escribe un nombre, selecciona el tipo (y la estación si aplica) y pulsa **Agregar pantalla**.
3. Verás un código de 6 dígitos que vence en 10 minutos y la dirección web local (`http://IP-DE-LA-CAJA:5000/pantalla`).
4. Conecta el TV al mismo WiFi del negocio, abre la dirección en su navegador y escribe el código. La pantalla queda vinculada de inmediato.

### Aviso al mesero y alerta de cuenta

Cuando cocina toca **Listo**, el mesero ve el aviso **Recoger en cocina** en su celular dentro de la sección **Avisos**. Al llevar el pedido a la mesa, pulsa **Entregado**. Esto activa la alerta *Lista para cuenta*, recordando pasar la pre-cuenta tras el tiempo configurado.

### Campanita de avisos

Arriba en la barra (en el computador y en el celular) encuentras la campanita de avisos con el número de avisos sin ver y la lista de los últimos 7 días (pedidos de la página, reservas, platos listos, cuenta pedida, mesas que esperan y Autopilot). Pulsa **Borrar todo** para vaciar la lista. Los avisos se guardan en cada equipo de manera independiente. El mesero solo recibe avisos de sus mesas asignadas. Los platos listos y la cuenta pedida emiten sonido.

### Avisos al instante

El plano de mesas, la cocina y los avisos se actualizan apenas cambian, de forma inmediata y sin esperar.

### Pantalla de cocina

La pantalla de cocina solo muestra lo enviado en las últimas 6 horas y nunca muestra mesas ya cobradas. Los pedidos de mostrador cobrados siguen visibles hasta por 90 minutos o hasta marcarlos listos.

Para apagar o retirar una pantalla, ve a **Salón y mesas → Pantallas** y pulsa **Desconectar** o **Quitar**.
