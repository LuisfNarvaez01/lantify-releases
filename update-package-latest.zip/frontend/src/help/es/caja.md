# Abrir y cerrar caja
<!-- id: caja | tour: cash | roles: ADMIN,CASHIER | module: cash -->

<!-- keywords: caja, arqueo, abrir, cerrar, base, gasto, egreso, ingreso, cuadre, faltante, sobrante, tirilla, informe de cierre, imprimir cierre, numero de venta -->

No se puede cobrar con la caja cerrada.

1. **Abrir caja:** en **Caja** toca *Abrir caja* y escribe el dinero inicial (la base).
2. **Durante el turno:** registra ingresos y gastos (por ejemplo, compra de hielo) en el formulario de movimientos, con motivo y categoría.
3. **Cerrar caja:** cuenta el efectivo (puedes usar la calculadora de billetes) y toca *Cerrar caja*. El sistema compara lo contado con lo esperado y muestra la diferencia.

**Informe de cierre impreso:** al cerrar, Lantify imprime en la tirilla el informe del turno, como el cierre de un datáfono: rango de ventas (por ejemplo *C1-000101 a C1-000148*), una línea por venta con hora, lugar, medio de pago y valor, las anuladas, impuestos, totales por medio de pago, gastos y entradas, y el arqueo con la diferencia. Lleva espacio para la firma del cajero y del administrador. Puedes imprimirlo antes de cerrar (*Imprimir cierre*) o reimprimir una copia justo después. Es un documento de control interno: no reemplaza la factura.

**Números de venta:** cada venta tiene un número corto que nunca se reinicia, por ejemplo *C1-000123* (C1 es la caja). Las ventas anteriores recibieron su número en el orden en que se hicieron; el número interno largo se conserva.

Las propinas en efectivo entran a la caja. El reporte mensual está en *Ver reporte mensual*.

[[tour:cash|Mostrarme el recorrido]]
