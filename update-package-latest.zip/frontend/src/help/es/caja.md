# Abrir y cerrar caja
<!-- id: caja | tour: cash | roles: ADMIN,CASHIER | module: cash -->

<!-- keywords: caja, arqueo, abrir, cerrar, base, gasto, egreso, ingreso, cuadre, faltante, sobrante -->

No se puede cobrar con la caja cerrada.

1. **Abrir caja:** en **Caja** toca *Abrir caja* y escribe el dinero inicial (la base).
2. **Durante el turno:** registra ingresos y gastos (por ejemplo, compra de hielo) en el formulario de movimientos, con motivo y categoría.
3. **Cerrar caja:** cuenta el efectivo (puedes usar la calculadora de billetes) y toca *Cerrar caja*. El sistema compara lo contado con lo esperado y muestra la diferencia.

Las propinas en efectivo entran a la caja. El reporte mensual está en *Ver reporte mensual*.

[[tour:cash|Mostrarme el recorrido]]
