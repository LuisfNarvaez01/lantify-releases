# Personal, turnos y pagos
<!-- id: personal-y-pagos | roles: ADMIN | module: settings -->

<!-- keywords: personal, empleados, turnos, reloj, entrada, salida, pagos, adelantos, descuentos, liquidación, cocina -->

La función **Personal, turnos y pagos** te ayuda a llevar el control operativo del equipo de trabajo. Se activa en **Administración → Funciones** y transforma la sección de usuarios en el menú **Personal**, compuesto por cuatro áreas:

- **Usuarios y permisos:** administra los accesos al POS y lo que cada rol puede realizar en el sistema.
- **Equipo:** registra la ficha de cada trabajador con su puesto (meseros, cajeros, cocina, barra, otros), tipo de pago (por turno, por hora o fijo por periodo) y valor acordado. Aquí puedes registrar empleados sin usuario del POS, como cocineros o personal de apoyo que no maneja pantallas.
- **Turnos:** registro de asistencia. Los trabajadores con usuario marcan **Marcar entrada** y **Marcar salida** desde su sesión. El administrador o cajero puede marcar a quienes no tienen usuario, o registrar turnos manuales si alguien olvidó fichar.
- **Pagos:** permite asentar **Adelantos** y **Descuentos** con su motivo y fecha. Al final de la semana, quincena o mes, pulsa **Liquidar** para calcular lo adeudado según turnos u horas trabajadas más sus propinas asignadas. Una vez entregado el dinero, pulsa **Marcar pagada** (con la opción de registrarlo como gasto del negocio).

### Importante sobre el alcance legal

Este módulo es una herramienta de **control interno y organizativo** para facilitar el cálculo de pagos diarios y propinas en el restaurante. No calcula prestaciones sociales, seguridad social ni emite nómina electrónica DIAN, por lo que **no reemplaza la nómina legal colombiana**.
