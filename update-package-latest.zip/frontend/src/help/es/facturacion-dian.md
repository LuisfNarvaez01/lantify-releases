# Facturación electrónica DIAN
<!-- id: facturacion-dian | roles: ADMIN | module: settings -->

<!-- keywords: dian, factura electrónica, resolución, factus, cufe, proveedor, numeración -->

Se configura en **Administración → Cuenta y sistema → Facturación DIAN** (planes Pro y Premium).

1. Pide en el portal de la DIAN la **resolución de numeración** para facturación electrónica y escríbela con su prefijo y rango.
2. Conecta el **proveedor de facturación** con las credenciales que te entregó.
3. Usa **Probar conexión** y emite una factura de prueba.

Sin internet, las facturas quedan en cola y se envían solas al volver la conexión. Confirma con tu contador el régimen de impuestos antes de facturar.
