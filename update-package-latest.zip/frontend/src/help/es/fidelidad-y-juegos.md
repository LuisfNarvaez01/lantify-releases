# Tarjeta de sellos y juegos con premios
<!-- id: fidelidad-y-juegos | roles: ADMIN | module: settings -->

<!-- keywords: fidelidad, sellos, tarjeta, premio, juego, ruleta, raspa, trivia, únete, registro, cupón -->

Es del plan **Premium**. Se configura en **Administración → Mi página y fidelidad → Fidelidad & Sellos**.

1. **Reglas:** compra mínima por sello, cuántos sellos se necesitan y el premio. El cliente ve estas condiciones en su tarjeta.
2. **Secciones:** enciende **Únete** (registro de clientes) y, si quieres, **Juega y gana**. Para registrar clientes debes escribir la razón social del responsable de los datos (pestaña Perfil).
3. **Juego:** elige ruleta, raspa y gana o trivia, y agrega los premios con su probabilidad.
4. **Publica** la página para que los cambios se vean.

Al cobrar, el ticket trae un QR para sumar el sello. Los premios ganados llegan como cupones que se canjean en la caja.
