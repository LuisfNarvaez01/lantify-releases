# Pedido desde la mesa con QR
<!-- id: pedido-desde-la-mesa | roles: ADMIN,CASHIER,WAITER | module: pos -->

<!-- keywords: qr, mesa, pedir desde la mesa, carta, celular del cliente, ronda, mesero, aceptar, premium -->

Es del plan **Premium**. El cliente escanea el QR de su mesa, ve la carta en su celular y envía el pedido. El mesero lo confirma antes de que vaya a la cocina.

1. En **Administración → Salón y mesas → Funciones**, enciende **Pedido desde la mesa**.
2. Tu página debe estar publicada (**Mi página**, con internet).
3. En **Salón y mesas → QR de mesas**, toca **Imprimir** y pon cada QR en su mesa.

Cuando llega un pedido, aparece arriba del plano y en **Avisos** del celular del mesero, con sonido. **Aceptar y enviar** lo agrega como una ronda nueva de la mesa y sale la comanda. **Rechazar** le muestra el motivo al cliente.

- Los precios los pone la caja (con el happy hour si está vigente), nunca el celular del cliente.
- Cada mesa tiene un solo pedido esperando a la vez.
- No se pide nombre, celular ni pago: se cobra con la cuenta de la mesa.
- Si un QR se pierde o lo copian, toca **Cambiar QR** en esa mesa e imprime el nuevo.
