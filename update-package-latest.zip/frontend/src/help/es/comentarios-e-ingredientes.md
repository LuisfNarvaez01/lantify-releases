# Comentarios e ingredientes en comandas
<!-- id: comentarios-e-ingredientes | roles: ADMIN,CASHIER | module: pos -->

<!-- keywords: ingredientes, comentarios, notas, comanda, cocina, sin cebolla, frases rapidas, pedidos -->

En Lantify puedes especificar cómo desea el cliente su plato de forma rápida y sin errores de digitación hacia la cocina.

### Configurar ingredientes de un producto

Para indicar los ingredientes que un cliente puede pedir que le retiren:

1. Ve a **Administración → Carta y productos → Productos**.
2. Al editar o crear un plato, pulsa el botón **Ingredientes**.
3. Escribe los nombres de los ingredientes (por ejemplo: cebolla, tomate, salsa, queso) y guarda los cambios.

### Tomar el pedido con observaciones

Al armar la orden en caja o desde el celular:

1. Toca el producto agregado en la lista del pedido para abrir la ventana de notas de cocina.
2. **Quitar ingredientes:** verás los ingredientes del plato en botones individuales. Toca cualquiera para excluirlo; cambiará a estado tachado (por ejemplo, *Sin cebolla*). Toca de nuevo si deseas reintegrarlo.
3. **Frases rápidas:** utiliza botones predefinidos como *Término medio*, *Bebida fría* o *Para llevar*. Estas frases se configuran y editan desde **Administración → Funciones**.
4. **Comentario libre:** si necesitas dar una instrucción especial, escríbela en el campo de texto libre.

### Impresión clara en cocina

Cuando tocas **Enviar a cocina**, la comanda impresa en la impresora térmica resalta los ingredientes retirados en su propia línea en mayúsculas destacadas (por ejemplo: **SIN CEBOLLA**), ubicada antes del comentario libre. Así el equipo de cocina lee las instrucciones críticas al instante y evita devoluciones de platos.
