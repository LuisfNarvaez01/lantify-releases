# Estudio de flyers publicitarios
<!-- id: flyers | roles: ADMIN | module: settings -->

<!-- keywords: flyer, flyers, marketing, publicidad, diseño, imagen, png, instagram, whatsapp, claro, oscuro, historia, cuadrado -->

El estudio de flyers te permite diseñar piezas gráficas profesionales para promocionar tus productos y servicios en redes sociales y estados de WhatsApp.

### Cómo crear un flyer

1. En la barra superior, abre la pestaña **Agentes** y selecciona el agente de **Marketing**.
2. En las tareas listas, pulsa **Crear un flyer**.
3. Escribe qué deseas promocionar (por ejemplo: *2x1 en hamburguesas los jueves*) o pulsa **Elige tú** para que el agente escoja el producto más conveniente.
4. Cuando el borrador esté listo, toca **Abrir y editar** para entrar al estudio.

### Opciones de diseño en el estudio

- **Estilos:** elige entre **Claro**, **Oscuro** o **Foto** a sangre para cambiar el fondo y contraste.
- **Formatos:** selecciona **Publicación** (1080×1350 px para muro de Instagram/Facebook), **Historia** (1080×1920 px para estados y reels) o **Cuadrado** (1080×1080 px).
- **Foto:** puedes usar la foto del producto del catálogo, pulsar **Subir foto** para cargar un archivo desde tu equipo, o tocar **Hacer foto con IA**. Ten en cuenta que las fotos con IA consumen el cupo de imágenes de tu plan. Una foto real y bien iluminada de tu negocio siempre se ve mejor.
- **Edición de textos:** puedes personalizar el titular, la segunda línea de acento, los beneficios con sus iconos correspondientes, la oferta y el llamado a la acción.

### Datos de contacto y descarga

Los datos de WhatsApp e Instagram se toman automáticamente de la tarjeta **Tu negocio para la IA**. Asegúrate de completarlos allí para que tus clientes sepan dónde escribirte.

Al finalizar, pulsa **Descargar PNG** para guardar la imagen en alta calidad o **Compartir** para enviarla directamente por WhatsApp.
