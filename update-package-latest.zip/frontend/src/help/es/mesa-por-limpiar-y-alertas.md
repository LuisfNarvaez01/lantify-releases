# Mesa por limpiar y alertas de mesa
<!-- id: mesa-por-limpiar-y-alertas | roles: ADMIN,CASHIER | module: pos -->

<!-- keywords: mesas, por limpiar, alertas, mesa inactiva, cuenta pendiente, lista para cuenta, tiempos, salon, rotacion -->

Lantify te ayuda a cuidar los tiempos del salón mediante dos herramientas que se encienden en **Administración → Funciones**:

### Mesa por limpiar

Al cobrar una cuenta o liberar una mesa, su estado cambia automáticamente a **Por limpiar** en lugar de quedar libre de inmediato. Esto evita que un mesero siente clientes en una mesa desordenada.

- En el plano y en la lista de mesas verás la etiqueta **Por limpiar**.
- Cualquier miembro del equipo puede tocar la mesa y presionar **Toca para marcarla limpia**. Con ese único toque la mesa queda libre y lista para nuevos comensales.
- Si apagas esta función, las mesas pasan directamente a libres al cobrarse, como siempre.

### Alertas operativas de mesa

El mapa y la lista de mesas resaltan con un pulso visual suave y un aviso cuando una mesa requiere atención del personal:

- **Mesa inactiva:** se enciende si pasa mucho tiempo desde la última ronda enviada a cocina sin que hayan pedido la cuenta (tiempo por defecto: 20 minutos). Sirve para que el mesero se acerque a ofrecer bebidas o postre.
- **Cuenta pendiente:** se activa cuando el cliente pidió la cuenta y aún no se registra el cobro (tiempo por defecto: 7 minutos). Ayuda a evitar esperas al momento de pagar.

Ambos tiempos se configuran en **Administración → Funciones → Salón y pedidos** usando el botón **Guardar tiempos**.

La alerta adicional **Lista para cuenta** (que avisa cuando los platos salieron de cocina pero no se ha pedido la cuenta) comenzará a funcionar cuando se active la pantalla de cocina en una próxima versión.
