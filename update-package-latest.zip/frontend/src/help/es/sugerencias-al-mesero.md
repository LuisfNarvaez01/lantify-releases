# Sugerencias al mesero
<!-- id: sugerencias-al-mesero | roles: ADMIN,CASHIER,WAITER | module: pos -->

<!-- keywords: sugerencias al mesero, ofrece primero, ventas cruzadas, acompañamientos, favoritos, platos rapidos, salon y mesas -->

Las sugerencias al mesero muestran recomendaciones inteligentes en la parte superior del pedido, tanto en la caja como en el celular del mesero, bajo el encabezado **Ofrece primero**.

La función se enciende en **Salón y mesas → Sugerencias al mesero**.

### De dónde salen las sugerencias

Lantify analiza las ventas del negocio para sugerir de 2 a 3 productos oportunos con una breve explicación:

- **Si el pedido ya tiene productos:** sugiere lo que se pide junto habitualmente con esos platos (por ejemplo: "7 de cada 10 que piden hamburguesa piden papas").
- **Si el pedido está vacío:** sugiere los favoritos de la franja horaria actual (**Estrellas**) y los platos con buen margen (**Rompecabezas**).

El sistema nunca sugiere productos agotados o pausados en el inventario.

### Cómo utilizarlas en la atención

1. Al abrir una mesa o comanda en la caja o en el celular, revisa la barra **Ofrece primero**.
2. Ofrécele la recomendación al cliente mencionando el acompañamiento o la sugerencia del momento.
3. Con **un solo toque** sobre el producto sugerido, este se agrega de inmediato al pedido sin necesidad de buscarlo en las categorías.

### Priorización con Autopilot

Cuando Autopilot detecta que la cocina se está saturando, puede priorizar automáticamente los platos de preparación rápida en las sugerencias durante un tiempo determinado. De esta forma, el equipo orienta a los comensales hacia opciones ágiles y ayuda a descongestionar la cocina sin interrumpir el servicio.
