# Funciones del negocio
<!-- id: funciones | roles: ADMIN | module: settings -->

<!-- keywords: funciones, activar, desactivar, módulos, características, configuración, novedades, 3.0 -->

En **Administración → Funciones** puedes elegir qué herramientas necesita tu restaurante en su día a día.

Cada negocio opera de manera diferente. Por eso, Lantify te permite encender o apagar módulos según tu operación:

- **Lo que apagas desaparece:** cuando desactivas una función, sus botones, pestañas y accesos se ocultan por completo en todo el sistema. Tu equipo no verá opciones innecesarias ni botones que no use.
- **Enciende cuando quieras:** puedes activar cualquier función en cualquier momento con un solo toque y comenzará a funcionar de inmediato.
- **Actualización a la versión 3.0:** al actualizar el sistema a Lantify 3.0, tus opciones habituales se mantienen encendidas para que nada se interrumpa. Las funciones nuevas del bloque llegan apagadas por defecto. Puedes revisar el aviso de novedades y entrar a esta pantalla para encender las que quieras probar.

Entre las funciones activables encuentras: mesa por limpiar, alertas de mesa, lista de compras por proveedor, reporte de cierre al dueño, personal y pagos, y reparto de propinas.

Para activar o desactivar una función:

1. Entra a **Administración → Funciones**.
2. Ubica la herramienta que deseas usar dentro de su grupo correspondiente.
3. Activa o desactiva el interruptor.
4. Si la función tiene opciones adicionales (como tiempos o números de contacto), ajústalas y toca **Guardar**.
