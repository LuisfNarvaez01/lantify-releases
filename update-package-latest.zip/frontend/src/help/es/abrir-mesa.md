# Detalles al abrir mesa
<!-- id: abrir-mesa | roles: ADMIN,CASHIER,WAITER | module: pos -->

<!-- keywords: mesa, abrir mesa, personas, comensales, clientes, descripción, salón, orden de servicio -->

Registra información clave al abrir una mesa para conocer a tus clientes y medir el consumo por persona.

### Activar la función

1. Ve a **Salón y mesas**.
2. En la configuración de mesas, activa la opción **Detalles al abrir mesa**. Puedes encenderla o apagarla cuando quieras según el ritmo de tu negocio.

### La ventana al abrir mesa

Al tocar una mesa libre en el plano o en la lista, la mesa queda ocupada de inmediato, aunque no se haya pedido nada todavía, y muestra quién la abrió. Se ve en azul con la etiqueta **Abierta** hasta el primer envío a cocina.

Si tienes activa la función, aparece la ventana de apertura con tres datos:

- **Personas:** toca los botones rápidos del **1** al **8**, o pulsa **Otro número** si se trata de un grupo más grande. Este dato alimenta las estadísticas de comensales y calcula el consumo promedio por persona en el motor de menú.
- **Descripción (opcional):** escribe una nota identificadora como "Cumpleaños Carlos", "Mesa ventana" o, si tienes un negocio de servicios (como lavanderías o talleres), el número de orden de trabajo (ej. "Orden de lavado #15").
- **Cliente:** viene seleccionado **Cliente común** por defecto. Puedes buscar un cliente frecuente para sumar sus consumos o crear uno nuevo en segundos.

Si estás en hora pico y necesitas tomar la orden de inmediato, pulsa **Omitir** para abrir la mesa al instante sin guardar estos datos. Para confirmar la información ingresada, pulsa **Abrir mesa**.

### Colores de alerta en la mesa

En el plano, las mesas muestran colores de alerta acompañados siempre con texto:

- **Verde azulado:** muestra **Listo en cocina** cuando la cocina marcó platos listos.
- **Rosado / rojo:** indica que pidieron la cuenta. El color se vuelve rojo más intenso si lleva el doble del tiempo configurado.
- **Ámbar / naranja:** indica que la mesa lleva rato sin pedir. Pasa a naranja si lleva el doble del tiempo configurado.
- **Azul claro:** indica que el pedido se sirvió hace rato.

### Editar los detalles durante el servicio

Si llegan más acompañantes o el cliente decide dar sus datos después, puedes modificar la información en cualquier momento:

1. Entra al pedido activo de la mesa.
2. Toca la barra superior donde aparece el número de mesa y los detalles actuales.
3. Actualiza el número de personas, la nota o el cliente y guarda los cambios.
