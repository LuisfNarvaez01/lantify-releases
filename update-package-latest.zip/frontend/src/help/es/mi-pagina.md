# Mi página web, reservas y pedidos en línea
<!-- id: mi-pagina | roles: ADMIN | module: settings -->

<!-- keywords: página, web, carta, qr, enlace, reservas, pedidos, domicilio, publicar, diseño, términos, privacidad, datos personales, nit -->

Se configura en **Administración → Clientes y ventas en línea → Mi página y fidelidad**.

- **Diseño:** colores, plantilla y frase del negocio.
- **Carta:** qué secciones se ven (carta, pedidos, reservas) y qué productos se ocultan.
- **Perfil:** horario, dirección, redes y la razón social del responsable de los datos.
- **Reservas** (Premium): horario, duración y mesas que se pueden reservar. Las reservas llegan solas al POS.
- **Pedidos en línea** (Premium): domicilio o recoger, costo de envío y medios de pago. Cada pedido nuevo suena y aparece abajo a la derecha.

Cuando termines, toca **Publicar**. La dirección y el QR quedan listos para compartir. Cada cambio se vuelve a publicar.

## Términos y política de datos

Toda página pública genera automáticamente sus páginas de **Términos y condiciones** y **Política de privacidad y datos**. Se construyen a partir de los datos registrados de tu negocio: razón social, NIT, correo electrónico, dirección y teléfono.

Los clientes pueden consultar estos documentos en los enlaces del pie de página y en los formularios de pedidos y reservas. Por cumplimiento legal, si no has ingresado todos estos datos obligatorios en el perfil, la página no se publicará por primera vez.
