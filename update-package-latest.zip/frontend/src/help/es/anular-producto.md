# Anular un producto o cancelar un pedido
<!-- id: anular-producto | roles: ADMIN,CASHIER,WAITER | module: pos -->

<!-- keywords: anular, cancelar, error, devolver, clave administrador, merma -->

## Producto aún no enviado
Quítalo con el ícono de la papelera o baja la cantidad. Para quitar todos los nuevos: menú **⋯ → Quitar productos sin enviar**.

## Producto ya enviado a cocina
Toca **Anular** en la línea. Eliges cuántas unidades, el motivo y si fue merma; un administrador escribe su clave para autorizarlo.

## Cancelar todo el pedido de una mesa
Menú **⋯ → Cancelar pedido de la mesa**. Pide motivo y, si no eres administrador, la clave de un administrador.

Todo queda en la auditoría con el motivo y quién autorizó.
