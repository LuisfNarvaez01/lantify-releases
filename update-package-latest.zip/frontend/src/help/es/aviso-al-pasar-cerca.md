# Aviso al pasar cerca del local
<!-- id: aviso-al-pasar-cerca | roles: ADMIN | module: settings -->

<!-- keywords: cerca, cercanía, ubicación, geolocalización, wallet, google wallet, aviso, notificación, pasar, invitación, mensaje -->

## Qué hace

Cuando un cliente que guardó tu **tarjeta de sellos en Google Wallet** pasa cerca de tu local, su celular Android le muestra la tarjeta con un aviso. Al tocarlo ve arriba tu mensaje, por ejemplo: *"¡Estás a una cuadra! Hoy tu jugo de la casa con 10 % de descuento."*

## Cómo se activa

1. Ve a **Administración → Mi página y fidelidad → Fidelidad & Sellos**.
2. En **Dónde lleva el cliente su tarjeta** elige **En la wallet del celular** (v2).
3. Enciende **Aviso al pasar cerca (Android)**.
4. Escribe el mensaje (máximo 150 letras).
5. Agrega la ubicación del local, de una de estas formas:
   - Abre tu local en Google Maps, mantén presionado el punto exacto y copia los números que aparecen (por ejemplo `2.9273, -75.2819`). Pégalos y toca **Agregar**.
   - Pega el enlace largo de Google Maps (el que se ve en la barra del navegador).
   - Si estás en el local con el celular o un equipo con ubicación, toca **Estoy en el local**.
6. **Publica la página.** Al publicar se ponen al día también las tarjetas que tus clientes ya tenían guardadas.

Puedes agregar hasta 10 ubicaciones (por ejemplo, cada sede o la entrada de un centro comercial).

## Lo que debes saber

- **Google decide** a qué distancia y cuánto tiempo debe estar el cliente para mostrar el aviso, y escribe el texto del aviso. Tu mensaje es lo que el cliente lee al abrir la tarjeta.
- Solo les llega a clientes que tienen activadas las **notificaciones** y la **ubicación precisa** de Google Wallet.
- El aviso se va solo cuando el cliente se aleja.
- **En iPhone no hay aviso por cercanía**: allí la tarjeta vive en la pantalla de inicio y solo recibe los avisos de sellos.
- Los enlaces cortos (`maps.app.goo.gl/…`) no traen las coordenadas: ábrelos en el navegador y copia la dirección larga.
- Lantify no guarda ni ve la ubicación de tus clientes: el celular de cada cliente compara su posición con la del local.
