# Proyecta: canciones pedidas desde la mesa
<!-- id: proyecta | roles: ADMIN | module: settings -->

<!-- keywords: proyecta, dj, música, musica, canciones, pedir canciones, youtube, qr, chat con el dj, vincular, musica.lantifypos.com -->

**Proyecta** es el programa del DJ (pantallas y música). Vinculado a tu negocio, los clientes escanean el QR de su mesa, buscan la canción como en YouTube y se la piden al DJ, desde los datos del celular o cualquier WiFi. El DJ decide qué suena.

## Vincular

1. En **Administración → Proyecta · música**, toca **Vincular Proyecta**. Aparece un código de 8 letras que vence en 15 minutos y sirve una sola vez.
2. En el computador del DJ, en Proyecta, ve a **Ajustes → Pedidos de canciones → Por internet** y toca **Vincular con Lantify POS**. Escribe el código.
3. Cuando Proyecta se conecta, el estado cambia a **DJ conectado**.

Si cambias el computador del DJ, vuelve a vincular: el equipo anterior queda fuera y los QR impresos siguen sirviendo.

## QR de las mesas

En la misma pantalla está **QR para pedir canciones**: imprime todos o mesa por mesa. El cliente registra su mesa una sola vez en el celular. Si tu página tiene el pedido desde la mesa, también muestra **Pedir canciones** en la carta.

La página de música usa los colores y el logo de **Mi página**.

## Mensajes con el DJ

En **Mensajes con el DJ** escribes mensajes cortos (hasta 280 caracteres): una canción para un cumpleaños, bajar el volumen, anunciar el cierre. Mientras la pantalla está abierta, los mensajes del DJ llegan solos cada pocos segundos y te avisa cuando hay uno nuevo.

Necesita internet en la caja y en el computador del DJ. Si el DJ no está conectado, la página de música avisa a los clientes y no recibe pedidos.
