# Reporte de cierre de caja al dueño
<!-- id: reporte-de-cierre | roles: ADMIN,CASHIER | module: cash -->

<!-- keywords: cierre de caja, reporte, arqueo, dueño, whatsapp, correo, mi cuenta, resumen, efectivo, turnos -->

El **Reporte de cierre al dueño** permite que el propietario del restaurante reciba un resumen financiero completo cada vez que se cierra un turno de caja, sin necesidad de estar físicamente en el local. Se activa en **Administración → Funciones**.

### Envío inmediato por WhatsApp

Al terminar el conteo de dinero y tocar **Cerrar caja** en la sección **Caja**, la pantalla muestra la confirmación junto al botón **Enviar al dueño**:

1. Toca **Enviar al dueño**.
2. Lantify abrirá WhatsApp con el número del propietario configurado y un mensaje detallado listo para enviar.
3. El mensaje contiene: nombre del negocio, fecha y hora, quién abrió y cerró el turno, total vendido, número de transacciones, desglose por medio de pago (efectivo, tarjetas, transferencias), efectivo esperado vs. contado, diferencia de caja, ingresos, gastos y propinas recaudadas.

### Respaldo automático en la nube y por correo

Incluso si el cajero no presiona el botón de WhatsApp, el sistema envía el resumen de forma automática y silenciosa:

- **En la web:** el informe sube a la plataforma y queda disponible en **Mi cuenta → Cierres de caja** al iniciar sesión con la cuenta titular del negocio.
- **Por correo electrónico:** se envía una copia al correo principal de la cuenta del restaurante y al correo adicional configurado en Funciones.
- **Funcionamiento sin internet:** si el local se queda sin conexión al momento de cerrar caja, el cierre se guarda en el equipo sin demoras. El reporte queda en cola y se transmite solo tan pronto vuelva la señal de internet.
