# Autopilot
<!-- id: autopilot | roles: ADMIN,CASHIER | module: pos -->

<!-- keywords: autopilot, situaciones, cocina saturada, pico, agotado, mesero sobrecargado, hora floja, alertas, premium -->

Autopilot vigila la operación y compara cada momento contra lo normal de tu negocio a ese día y hora. Se calcula en el equipo del local y funciona sin internet. Requiere plan Premium y se activa en **Salón y mesas**.

El botón **Autopilot** en la barra superior muestra las situaciones activas. Puedes pulsar **Hacerlo**, ajustar minutos o porcentaje, o tocar **Descartar**. Al aceptar una acción pasa a **En marcha**, con opción de **Deshacer**. Lo temporal se revierte solo al vencer su plazo.

### Las seis situaciones

1. **La cocina se está saturando:** comandas demoradas. Propone ofrecer platos rápidos, pausar platos lentos en la tienda web y avisar tiempos de espera.
2. **Viene un pico de pedidos:** el ritmo superará la capacidad de cocina. Propone pausar platos lentos, avisar al personal y llamar apoyo por WhatsApp.
3. **Se va a acabar:** existencias bajas antes del cierre. Propone pausarlo en la tienda en línea y en las sugerencias hasta el cierre, y avisar al personal para que no lo ofrezca.
4. **Mesero sobrecargado:** atiende más mesas que la mediana. Propone pedir apoyo a otro mesero.
5. **La hora está floja:** ventas bajo el 50 % de lo normal. Propone un cupón relámpago de 2 horas o empujar platos con buen margen.
6. **Varias mesas esperando:** mesas con demoras. Envía un aviso general a los meseros.

### Productos pausados por Autopilot

Cuando Autopilot pausa un producto, este desaparece de inmediato de la página del negocio, sale como **Pausado** en la caja y en el celular, y no se puede pedir. Para volver a venderlo se deshace la pausa en Autopilot.

### Permisos y aviso al dueño

El administrador ve todo con cifras. El cajero ve lo operativo sin ventas ni cupones. El mesero solo ve los avisos en su celular.

El botón **Avisar al dueño** envía la alerta por WhatsApp. El dueño decide en **Mi cuenta → Autopilot** del sitio y el local lo ejecuta en menos de un minuto con internet (vence en 30 min).

En **Lo que sabe**, necesita 14 días de historia para horas flojas y picos. Los tiempos de cocina llegan con la pantalla de cocina.
