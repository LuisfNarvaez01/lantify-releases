# Happy hour y precios por horario
<!-- id: precios-por-horario | roles: ADMIN | module: settings -->

<!-- keywords: happy hour, precio por horario, promoción, descuento por hora, 2x1, hora feliz, precio especial, días -->

Es del plan **Pro**. Se configura en **Administración → Productos → Precios por horario**.

1. Enciende **Precios por horario (happy hour)** arriba de la lista.
2. Toca **Nueva regla**: ponle un nombre (por ejemplo *Happy hour*), elige los días y las horas.
3. Elige el tipo: **Descuento %** (por ejemplo 20 % menos) o **Precio especial** (por ejemplo, cerveza a $5.000).
4. Elige a qué aplica: **toda la carta**, unas **categorías** o unos **productos**. La **vista previa** te muestra cómo quedan los precios.

Mientras la regla está vigente, la caja y el celular ponen el precio solos y el carrito muestra la insignia con el nombre de la regla. Tu página muestra el aviso (por ejemplo, *Happy hour · lun a vie · 5 pm – 7 pm*).

- Si la hora de fin es menor que la de inicio (22:00 a 02:00), la regla sigue hasta el día siguiente.
- Lo que una mesa pidió durante el happy hour se cobra a ese precio aunque ya haya terminado.
- Por seguridad, la caja no acepta un precio menor al de la carta que ninguna regla justifique. Si aparece ese aviso, quita el producto y agrégalo de nuevo.
- Puedes **pausar** una regla sin borrarla.
