# Encuesta de satisfacción y reseñas en Google
<!-- id: encuesta-de-satisfaccion | roles: ADMIN | module: settings -->

<!-- keywords: encuesta, satisfacción, calificación, opinión, comentarios, reseña, google, estrellas, qr, recibo -->

## Encuesta de 1 a 5

Es del plan **Premium** (va con la tarjeta de sellos). Se enciende en **Administración → Mi página y fidelidad → Fidelidad & Sellos → Encuesta de satisfacción**.

Cuando un cliente reclama sus sellos en tu página (o abre su tarjeta desde Google Wallet), le aparece una sola pregunta: *¿Cómo te atendimos hoy?*, del 1 al 5, con un comentario opcional. Cada cliente responde máximo una vez al día.

Las respuestas llegan solas a la caja y las ves en **Estadísticas → Equipo y clientes → Satisfacción**: el promedio de los últimos 7 días, el promedio de cada semana y los comentarios recientes.

Si tienes el **Autopilot**, te avisa cuando el promedio de 7 días baja de 3,5 o cuando alguien califica 1 o 2 y deja un comentario.

## Califícanos en Google

- Al reclamar sellos en la página también aparece la invitación a calificarte en Google. La ve todo el mundo, sin importar la calificación que dio en la encuesta (así lo exige Google).
- En **Ajustes → Impresión** puedes activar **QR para calificar en Google**: el recibo trae un código que lleva a tu página de reseñas. Primero pega tu enlace de reseñas en **Mi página → Redes**.
