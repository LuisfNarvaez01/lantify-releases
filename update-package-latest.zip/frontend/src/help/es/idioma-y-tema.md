# Idioma y tema
<!-- id: idioma-y-tema | roles: ADMIN,CASHIER,WAITER | module: other -->

<!-- keywords: idioma, inglés, español, tema, oscuro, claro, colores, letra -->

En el menú de tu usuario (arriba a la derecha) eliges **idioma** (español o inglés) y **tema** (claro, oscuro o automático). Cada persona conserva su preferencia.

Los colores del negocio y el tamaño de letra se cambian en *Administración → Apariencia*. El idioma de los tickets se elige en *Administración → Impresión y tickets*.
