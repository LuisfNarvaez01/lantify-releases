# Guía de configuración: por dónde empezar
<!-- id: guia-de-configuracion | roles: ADMIN | module: settings -->

<!-- keywords: empezar, primera vez, configurar, instalar, guía, pasos, plan, funciones, checklist -->

La **guía de configuración** está en **Administración → Empezar → Guía de configuración**. Te dice todo lo que falta, en orden.

1. **Lo básico** se hace en el asistente de la primera vez: tipo de negocio, mesas, datos y equipo.
2. **Elige qué vas a usar:** la guía pregunta función por función (inventario, cupones, página web, tarjeta de sellos…). Solo muestra las que **incluye tu plan**. Si no la necesitas, toca *No la necesito*; puedes volver a agregarla cuando quieras.
3. **Sigue el paso a paso:** cada paso tiene un botón **Ir** que te lleva a la pantalla donde se hace y un *¿Cómo se hace?* con la explicación.
4. **Los pasos se marcan solos** cuando el sistema puede comprobarlos (por ejemplo, cuando ya hay productos o mesas). Los demás los marcas tú con *Marcar como hecho*.

Mientras falten pasos, el POS muestra un aviso arriba con un enlace para continuar. Lo puedes ocultar; la guía sigue en Administración y en este centro de ayuda.

**El menú de Administración** está agrupado así:
- **Mi negocio:** datos del negocio, salón y mesas, usuarios y roles, impresión y apariencia.
- **Carta e inventario:** productos, inventario, proveedores y gastos.
- **Clientes y ventas en línea:** clientes, cupones, mi página y fidelidad.
- **Cuenta y sistema:** facturación DIAN, plan y suscripción, asistente IA, copias y mantenimiento.
