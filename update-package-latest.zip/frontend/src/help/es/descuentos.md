# Descuentos
<!-- id: descuentos | roles: ADMIN,CASHIER | module: pos -->

<!-- keywords: descuento, porcentaje, cumpleaños, cortesía, rebaja -->

En el pedido toca **Descuento** y elige 5, 10, 15, 20, 25 o 50 %, o escribe otro porcentaje y toca *Aplicar*.

- El descuento se aplica a toda la cuenta y el impuesto se recalcula sobre el valor con descuento.
- Para quitarlo, toca la **×** junto a la línea del descuento o *Quitar descuento*.
- Si el cliente seleccionado cumple años hoy, se sugiere automáticamente un 10 %.
- Cada descuento queda registrado con el motivo y quién lo autorizó.
