# Impresora y tickets
<!-- id: impresion | roles: ADMIN | module: settings -->

<!-- keywords: impresora, ticket, recibo, comanda, térmica, láser, papel, 58, 80, letra clara, oscura, cajón -->

Se configura en **Administración → Mi negocio → Impresión y tickets**.

- **Directa (recomendada para térmicas):** el ticket sale sin ventanas. Elige la impresora de la caja y, si tienes, la de cocina.
- **Por el navegador:** se abre el diálogo de impresión. Úsalo con impresoras láser o si la directa no funciona.
- **Papel:** 58 mm u 80 mm, según tu rollo.
- **La letra sale muy clara:** en *Avanzado → Oscuridad de la letra* elige *Oscura* o *Muy oscura*.
- **Cajón monedero:** se abre al cobrar en efectivo si está conectado a la impresora.

Después de guardar, usa **Imprimir prueba** para revisar que el ticket salga completo.
