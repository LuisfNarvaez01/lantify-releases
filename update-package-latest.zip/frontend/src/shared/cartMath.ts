// ============================================
// SHARED - Cálculos del pedido (mismas reglas que el servidor)
// ============================================
// Los precios traen el impuesto incluido. Aquí se calcula, para mostrar antes
// de cobrar, cuánto es descuento, cuánto es impuesto y cuánto la propina.
// El servidor vuelve a calcular todo al registrar la venta (src/domain/tax.ts).

import type { CartItem, Product } from '../types';
import type { BusinessSettings } from '../services/api';

export type TaxType = 'IVA' | 'INC' | 'NONE';

export interface TaxLine {
  taxType: TaxType;
  taxRate: number;
  amount: number;
}

const round2 = (n: number) => Math.round(n * 100) / 100;

const productTax = (
  product: Pick<Product, 'taxType' | 'taxRate'> | undefined,
  business: BusinessSettings | null,
): { taxType: TaxType; taxRate: number } => {
  const own = product?.taxType;
  if (own === 'NONE') return { taxType: 'NONE', taxRate: 0 };
  if ((own === 'IVA' || own === 'INC') && Number(product?.taxRate) > 0) {
    return { taxType: own, taxRate: Number(product!.taxRate) };
  }
  if (business && business.defaultTaxType !== 'NONE' && business.defaultTaxRate > 0) {
    return { taxType: business.defaultTaxType, taxRate: business.defaultTaxRate };
  }
  return { taxType: 'NONE', taxRate: 0 };
};

export interface CartTotals {
  /** Suma de los productos (con impuesto incluido) */
  subtotal: number;
  discount: number;
  /** Lo que paga el cliente por la venta (sin propina) */
  total: number;
  /** Impuesto incluido en el total, por tipo y tarifa */
  taxLines: TaxLine[];
  taxTotal: number;
  units: number;
}

export const computeCartTotals = (
  items: CartItem[],
  discountPct: number,
  products: Product[],
  business: BusinessSettings | null,
): CartTotals => {
  const subtotal = items.reduce((s, i) => s + i.total, 0);
  const pct = Math.min(100, Math.max(0, discountPct || 0));
  const discount = pct > 0 ? Math.round(subtotal * (pct / 100)) : 0;
  const total = subtotal - discount;
  const factor = subtotal > 0 ? total / subtotal : 0;

  const byKey = new Map<string, TaxLine>();
  for (const item of items) {
    const tax = productTax(products.find((p) => p.id === item.productId), business);
    if (tax.taxType === 'NONE') continue;
    const net = item.total * factor;
    const amount = net - net / (1 + tax.taxRate / 100);
    const key = `${tax.taxType}:${tax.taxRate}`;
    const line = byKey.get(key) || { ...tax, amount: 0 };
    line.amount = round2(line.amount + amount);
    byKey.set(key, line);
  }
  const taxLines = Array.from(byKey.values());
  return {
    subtotal,
    discount,
    total,
    taxLines,
    taxTotal: round2(taxLines.reduce((s, l) => s + l.amount, 0)),
    units: items.reduce((n, i) => n + i.quantity, 0),
  };
};

/** Propina sugerida redondeada a la centena (como se cobra en la práctica). */
export const suggestedTipFor = (total: number, percent: number) =>
  percent > 0 ? Math.round((total * percent) / 100 / 100) * 100 : 0;

export const taxLineLabel = (l: { taxType: string; taxRate: number }, names: { iva: string; inc: string }) =>
  `${l.taxType === 'IVA' ? names.iva : names.inc} ${l.taxRate} %`;
