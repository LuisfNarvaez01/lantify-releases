// ============================================
// SHARED - Guía de configuración (estado compartido de la pantalla)
// ============================================
// La guía vive en Administración; el aviso del POS y el centro de ayuda solo
// muestran el avance y piden abrirla (Layout escucha `openRequested`).

import { create } from 'zustand';
import { setupGuideAPI } from '../services/api';
import { usePlanStore, hasFeature } from './plan';
import { useBusinessStore } from './business';
import { EMPTY_GUIDE, functionsFor, guideProgress, SetupGuideState } from '../../../src/domain/setupGuide';

export * from '../../../src/domain/setupGuide';

interface GuideStore {
  state: SetupGuideState;
  checks: Record<string, boolean>;
  loaded: boolean;
  /** Alguien pidió abrir la guía (aviso del POS, ayuda o fin del asistente inicial) */
  openRequested: number;
  load: () => Promise<void>;
  save: (next: SetupGuideState) => Promise<void>;
  requestOpen: () => void;
}

export const useSetupGuide = create<GuideStore>((set, get) => ({
  state: EMPTY_GUIDE,
  checks: {},
  loaded: false,
  openRequested: 0,
  load: async () => {
    try {
      const r = await setupGuideAPI.get();
      set({ state: r.state, checks: r.checks, loaded: true });
    } catch {
      // sin permiso (no es ADMIN) o sin conexión: la guía no se muestra
    }
  },
  save: async (next) => {
    const prev = get().state;
    set({ state: next });
    try {
      const r = await setupGuideAPI.save(next);
      set({ state: r.state, checks: r.checks });
    } catch (err) {
      set({ state: prev });
      throw err;
    }
  },
  requestOpen: () => set((s) => ({ openRequested: s.openRequested + 1 })),
}));

/** Funciones del negocio según su plan, y el avance de la guía */
export const useGuideProgress = () => {
  const { state, checks, loaded } = useSetupGuide();
  const info = usePlanStore((s) => s.info);
  const usesTables = useBusinessStore((s) => s.settings?.usesTables ?? true);
  const { available, locked } = functionsFor((f) => hasFeature(info, f), usesTables);
  return { loaded, available, locked, progress: guideProgress(available, state, checks) };
};
