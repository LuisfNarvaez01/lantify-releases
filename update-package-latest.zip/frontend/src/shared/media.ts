// ============================================
// SHARED - Imágenes: mostrar, recortar, reducir y pasar a blanco y negro
// ============================================
// Las fotos se recortan y reducen aquí, en el navegador: al equipo del negocio
// solo llega la imagen final (cuadrada para productos y logo, 16:9 la portada).

import { API_URL } from '../config';
import { mediaAPI } from '../services/api';
import { IMAGE_SPECS, ImageKind } from '../../../src/domain/media';

export { IMAGE_SPECS } from '../../../src/domain/media';
export type { ImageKind } from '../../../src/domain/media';

// Absoluta: los informes y tickets se imprimen en ventanas aparte, donde una ruta relativa no carga
const API_ORIGIN = new URL(API_URL, window.location.origin).href.replace(/\/api\/?$/, '');

/** Dirección para <img>: las fotos del equipo (/api/media/…) se piden al servidor del negocio */
export const mediaSrc = (url: string | null | undefined): string | undefined => {
  if (!url) return undefined;
  return url.startsWith('/api/') ? `${API_ORIGIN}${url}` : url;
};

export const ACCEPTED_IMAGE_TYPES = 'image/jpeg,image/png,image/webp';
/** Lo que se acepta del celular o la cámara antes de reducir */
export const MAX_SOURCE_BYTES = 15 * 1024 * 1024;

export class ImageFileError extends Error {
  constructor(public code: 'TYPE' | 'SIZE' | 'READ' | 'SMALL') {
    super(code);
  }
}

export const loadImage = (src: string) =>
  new Promise<HTMLImageElement>((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => reject(new ImageFileError('READ'));
    img.src = src;
  });

/** Abre un archivo elegido por el usuario (comprueba tipo y peso) */
export const readImageFile = async (file: File): Promise<{ img: HTMLImageElement; url: string }> => {
  if (!/^image\/(jpeg|png|webp)$/.test(file.type)) throw new ImageFileError('TYPE');
  if (file.size > MAX_SOURCE_BYTES) throw new ImageFileError('SIZE');
  const url = URL.createObjectURL(file);
  try {
    return { img: await loadImage(url), url };
  } catch (e) {
    URL.revokeObjectURL(url);
    throw e;
  }
};

/** Encuadre: cuánto se amplía (1 = la imagen cubre justo el marco) y hacia dónde se corre (-1…1) */
export interface Framing {
  zoom: number;
  x: number;
  y: number;
}

export const CENTERED: Framing = { zoom: 1, x: 0, y: 0 };

/** Parte de la imagen original que queda dentro del marco */
export const sourceRect = (w: number, h: number, aspect: number, f: Framing) => {
  // Al 100 % la imagen cubre el marco (como object-fit: cover)
  let sw = w;
  let sh = w / aspect;
  if (sh > h) {
    sh = h;
    sw = h * aspect;
  }
  sw /= f.zoom;
  sh /= f.zoom;
  const sx = (w - sw) / 2 + (f.x * (w - sw)) / 2;
  const sy = (h - sh) / 2 + (f.y * (h - sh)) / 2;
  return { sx, sy, sw, sh };
};

/** Recorta y reduce al tamaño de su uso; devuelve un data URL listo para subir */
export const renderImage = (img: HTMLImageElement, kind: ImageKind, f: Framing = CENTERED, background?: string): string => {
  const spec = IMAGE_SPECS[kind];
  const { sx, sy, sw, sh } = sourceRect(img.naturalWidth, img.naturalHeight, spec.aspect, f);
  // No se agranda una imagen pequeña: se deja en su tamaño real
  const scale = Math.min(1, spec.width / sw);
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(sw * scale));
  canvas.height = Math.max(1, Math.round(sh * scale));
  const ctx = canvas.getContext('2d')!;
  if (background) {
    ctx.fillStyle = background;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(img, sx, sy, sw, sh, 0, 0, canvas.width, canvas.height);
  if (spec.format === 'png') return canvas.toDataURL('image/png');
  const webp = canvas.toDataURL('image/webp', 0.86);
  // Navegadores sin WebP devuelven PNG: se usa JPG, más liviano
  return webp.startsWith('data:image/webp') ? webp : canvas.toDataURL('image/jpeg', 0.88);
};

/** Recorta, reduce y sube. Devuelve la dirección guardada en el equipo. */
export const uploadImage = async (img: HTMLImageElement, kind: ImageKind, f: Framing = CENTERED) => {
  let data = renderImage(img, kind, f);
  // Un logo PNG grande (foto en vez de dibujo) se pasa a WebP para no pesar de más
  if (kind === 'logo' && data.length > 1_400_000) {
    const canvas = document.createElement('canvas');
    const im = await loadImage(data);
    canvas.width = im.naturalWidth;
    canvas.height = im.naturalHeight;
    canvas.getContext('2d')!.drawImage(im, 0, 0);
    data = canvas.toDataURL('image/webp', 0.9);
  }
  return (await mediaAPI.upload(data)).url;
};

// ── Imagen para la impresora térmica ─────────────────────────
// 1 bit por punto, con difuminado (Floyd–Steinberg) para que fotos y logos con
// degradados se vean en papel térmico. Ancho múltiplo de 8 (lo exige ESC/POS).

export interface MonoBitmap {
  width: number;
  height: number;
  bits: string;
  /** Vista previa en blanco y negro (para el ticket en HTML) */
  src: string;
}

export const toMonoBitmap = (img: HTMLImageElement | HTMLCanvasElement, maxWidth: number, maxHeight = maxWidth, dither = true): MonoBitmap => {
  const iw = img instanceof HTMLImageElement ? img.naturalWidth : img.width;
  const ih = img instanceof HTMLImageElement ? img.naturalHeight : img.height;
  const scale = Math.min(maxWidth / iw, maxHeight / ih, 1);
  const width = Math.max(8, Math.floor((iw * scale) / 8) * 8);
  const height = Math.max(1, Math.round((ih * width) / iw));
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d', { willReadFrequently: true })!;
  ctx.fillStyle = '#fff';
  ctx.fillRect(0, 0, width, height);
  ctx.drawImage(img, 0, 0, width, height);
  const px = ctx.getImageData(0, 0, width, height);
  const gray = new Float32Array(width * height);
  for (let i = 0; i < gray.length; i++) {
    const a = px.data[i * 4 + 3] / 255;
    // Lo transparente cuenta como papel (blanco)
    const lum = 0.299 * px.data[i * 4] + 0.587 * px.data[i * 4 + 1] + 0.114 * px.data[i * 4 + 2];
    gray[i] = lum * a + 255 * (1 - a);
  }
  const rowBytes = width / 8;
  const out = new Uint8Array(rowBytes * height);
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const i = y * width + x;
      const old = gray[i];
      const black = old < 128;
      if (black) out[y * rowBytes + (x >> 3)] |= 0x80 >> (x & 7);
      if (!dither) continue;
      const err = old - (black ? 0 : 255);
      if (x + 1 < width) gray[i + 1] += (err * 7) / 16;
      if (y + 1 < height) {
        if (x > 0) gray[i + width - 1] += (err * 3) / 16;
        gray[i + width] += (err * 5) / 16;
        if (x + 1 < width) gray[i + width + 1] += err / 16;
      }
    }
  }
  // Vista previa con los mismos puntos que saldrán en el papel
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const on = out[y * rowBytes + (x >> 3)] & (0x80 >> (x & 7));
      const o = (y * width + x) * 4;
      px.data[o] = px.data[o + 1] = px.data[o + 2] = on ? 0 : 255;
      px.data[o + 3] = 255;
    }
  }
  ctx.putImageData(px, 0, 0);
  let bin = '';
  for (let i = 0; i < out.length; i++) bin += String.fromCharCode(out[i]);
  return { width, height, bits: btoa(bin), src: canvas.toDataURL('image/png') };
};
