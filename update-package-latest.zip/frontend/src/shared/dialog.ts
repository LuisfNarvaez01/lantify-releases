
import { t } from '../i18n';// ============================================
// SHARED - Diálogos de confirmación (reemplazo de window.confirm / prompt)
// ============================================
// Uso:
//   if (!(await confirmDialog({ title: '¿Eliminar producto?', tone: 'danger' }))) return;
//   const reason = await reasonDialog({ title: 'Anular venta' }); // null si cancela
//   const phone = await promptDialog({ title: 'Enviar por WhatsApp', label: 'Número' });

export type DialogTone = 'default' | 'danger';

export interface DialogRequest {
  id: number;
  kind: 'confirm' | 'prompt';
  title: string;
  message?: string;
  confirmLabel?: string;
  cancelLabel?: string;
  tone?: DialogTone;
  // prompt
  label?: string;
  placeholder?: string;
  defaultValue?: string;
  required?: boolean;
  multiline?: boolean;
  inputMode?: 'text' | 'tel' | 'numeric';
  inputType?: 'text' | 'password';
  resolve: (value: any) => void;
}

type Listener = (current: DialogRequest | null) => void;

class DialogManager {
  private queue: DialogRequest[] = [];
  private listeners = new Set<Listener>();
  private nextId = 1;

  subscribe(listener: Listener) {
    this.listeners.add(listener);
    listener(this.queue[0] || null);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    const current = this.queue[0] || null;
    for (const l of this.listeners) l(current);
  }

  open<T>(req: Omit<DialogRequest, 'id' | 'resolve'>): Promise<T> {
    return new Promise<T>((resolve) => {
      this.queue.push({ ...req, id: this.nextId++, resolve });
      this.notify();
    });
  }

  close(id: number, value: unknown) {
    const req = this.queue.find(r => r.id === id);
    if (!req) return;
    this.queue = this.queue.filter(r => r.id !== id);
    req.resolve(value);
    this.notify();
  }
}

export const dialogManager = new DialogManager();

export const confirmDialog = (opts: {
  title: string;
  message?: string;
  confirmLabel?: string;
  cancelLabel?: string;
  tone?: DialogTone;
}): Promise<boolean> => dialogManager.open<boolean>({ kind: 'confirm', ...opts });

export const promptDialog = (opts: {
  title: string;
  message?: string;
  label: string;
  placeholder?: string;
  defaultValue?: string;
  confirmLabel?: string;
  required?: boolean;
  multiline?: boolean;
  inputMode?: 'text' | 'tel' | 'numeric';
  inputType?: 'text' | 'password';
  tone?: DialogTone;
}): Promise<string | null> => dialogManager.open<string | null>({ kind: 'prompt', required: true, ...opts });

/** Confirmación de una acción sensible con motivo obligatorio (queda en auditoría) */
export const reasonDialog = (opts: { title: string; message?: string; confirmLabel?: string; placeholder?: string }) =>
  promptDialog({
    label: t('common:motivo'),
    placeholder: opts.placeholder || t('common:ej_el_cliente_cambio_de_opinion'),
    multiline: true,
    tone: 'danger',
    confirmLabel: opts.confirmLabel || t('common:confirmar'),
    ...opts,
  });
