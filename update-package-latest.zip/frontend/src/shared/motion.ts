// ============================================
// MOTION - Tokens de movimiento del sistema
// ============================================
// Una sola curva y tres duraciones para todo Lantify (las mismas que index.css:
// --ease-out, --dur-fast, --dur-base, --dur-slow).
//
// Regla de uso (rediseño 2026-11):
// - Operación (caja, mesas, pedido): solo FAST/BASE, sin entradas escalonadas ni
//   rebotes. Nada que haga esperar al cajero.
// - Tableros, páginas públicas e intro: SLOW, escalonado y contadores animados.
// - Siempre respetar prefers-reduced-motion (useReducedMotion de motion/react).

import type { Transition, Variants } from 'motion/react';

export const EASE_OUT = [0.2, 0.8, 0.2, 1] as const;

export const DUR = {
  fast: 0.15,
  base: 0.22,
  slow: 0.32,
  /** Contadores y gráficos que crecen */
  data: 0.9,
} as const;

/** Retraso entre hijos de una lista escalonada */
export const STAGGER = 0.04;

export const transition = {
  fast: { duration: DUR.fast, ease: EASE_OUT } satisfies Transition,
  base: { duration: DUR.base, ease: EASE_OUT } satisfies Transition,
  slow: { duration: DUR.slow, ease: EASE_OUT } satisfies Transition,
  data: { duration: DUR.data, ease: EASE_OUT } satisfies Transition,
  /** Para paneles que se deslizan: firme, sin rebote */
  spring: { type: 'spring', stiffness: 420, damping: 38, mass: 0.9 } satisfies Transition,
};

/** Entrada simple: aparece y sube 6px */
export const enter: Variants = {
  hidden: { opacity: 0, y: 6 },
  show: { opacity: 1, y: 0, transition: transition.slow },
};

/** Contenedor que escalona a sus hijos (usar con `enter` en cada hijo) */
export const stagger = (delayChildren = 0): Variants => ({
  hidden: {},
  show: { transition: { staggerChildren: STAGGER, delayChildren } },
});

/** Modales y menús: escala mínima, nunca desde 0 */
export const pop: Variants = {
  hidden: { opacity: 0, scale: 0.97 },
  show: { opacity: 1, scale: 1, transition: transition.base },
  exit: { opacity: 0, scale: 0.98, transition: transition.fast },
};
