// ============================================
// SHARED - Fotos (facturas): reducir antes de enviar
// ============================================
// Una foto del celular pesa 3–6 MB; para leer una factura bastan ~1600 px.
// Se reduce en el navegador (JPEG) para que viaje rápido y ocupe poco al guardarse.

export interface PreparedImage {
  base64: string; // sin el encabezado data:
  mimeType: 'image/jpeg';
  previewUrl: string;
  bytes: number;
}

const MAX_SIDE = 1600;

export const prepareInvoicePhoto = (file: File): Promise<PreparedImage> =>
  new Promise((resolve, reject) => {
    if (!file.type.startsWith('image/')) {
      reject(new Error('NOT_AN_IMAGE'));
      return;
    }
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, MAX_SIDE / Math.max(img.width, img.height));
      const canvas = document.createElement('canvas');
      canvas.width = Math.round(img.width * scale);
      canvas.height = Math.round(img.height * scale);
      const ctx = canvas.getContext('2d')!;
      ctx.fillStyle = '#fff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.82);
      const base64 = dataUrl.split(',')[1];
      resolve({ base64, mimeType: 'image/jpeg', previewUrl: dataUrl, bytes: Math.round((base64.length * 3) / 4) });
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('NOT_AN_IMAGE'));
    };
    img.src = url;
  });
