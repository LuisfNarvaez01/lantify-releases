// ============================================
// SHARED - Funciones activables del negocio y estado del salón (Lantify 3.0)
// ============================================
// La fuente es el servidor (GET /features). Se guarda una copia local para que
// la pantalla no parpadee al entrar. Lo apagado no se muestra.

import { useEffect } from 'react';
import { create } from 'zustand';
import { featuresAPI, floorAPI, type FeaturesResponse, type FloorState } from '../services/v3Api';
import { normalizeFeatures, type FeatureKey } from '../../../src/domain/v3/features';
import { hasFeature, usePlanStore } from './plan';

export type { FeatureKey } from '../../../src/domain/v3/features';
export { FEATURE_KEYS, STAFF_GROUPS } from '../../../src/domain/v3/features';

const CACHE_KEY = 'lantify.features';

const EMPTY: FeaturesResponse = {
  ...normalizeFeatures({}),
  plan: { dirty_tables: null, table_alerts: 'ops_pro', waiter_suggestions: 'autopilot', shopping_list: 'suppliers', staff: 'ops_pro', tip_split: 'ops_pro', close_report: 'ops_pro', kitchen_display: 'ops_pro', autopilot: 'autopilot', table_details: null },
  requires: { tip_split: 'staff' },
};

const cached = (): FeaturesResponse => {
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    if (raw) return { ...EMPTY, ...normalizeFeatures(JSON.parse(raw)) };
  } catch {
    // sin almacenamiento local
  }
  return EMPTY;
};

interface FeaturesState {
  settings: FeaturesResponse;
  loaded: boolean;
  load: () => Promise<void>;
  save: (patch: Parameters<typeof featuresAPI.save>[0]) => Promise<FeaturesResponse>;
}

const remember = (settings: FeaturesResponse) => {
  try { localStorage.setItem(CACHE_KEY, JSON.stringify(settings)); } catch { /* sin almacenamiento local */ }
};

export const useFeatures = create<FeaturesState>((set) => ({
  settings: cached(),
  loaded: false,
  load: async () => {
    try {
      const settings = await featuresAPI.get();
      remember(settings);
      set({ settings, loaded: true });
    } catch {
      set({ loaded: true }); // se queda con la copia local
    }
  },
  save: async (patch) => {
    const settings = await featuresAPI.save(patch);
    remember(settings);
    set({ settings, loaded: true });
    return settings;
  },
}));

/** ¿El negocio usa la función y su plan la incluye? */
export const useFeatureFlag = (key: FeatureKey) => {
  const on = useFeatures((s) => s.settings.flags[key]);
  const code = useFeatures((s) => s.settings.plan[key]);
  const info = usePlanStore((s) => s.info);
  return !!on && (!code || hasFeature(info, code));
};

// ── Estado del salón: mesero por mesa, cuenta pedida, por limpiar y alertas ──

const EMPTY_FLOOR: FloorState = { now: new Date(0).toISOString(), tables: [], dirty: [], alerts: [] };
const FLOOR_POLL_MS = 20_000;

interface FloorStore {
  floor: FloorState;
  refresh: () => Promise<void>;
}

export const useFloorStore = create<FloorStore>((set) => ({
  floor: EMPTY_FLOOR,
  refresh: async () => {
    try {
      set({ floor: await floorAPI.state() });
    } catch {
      // sin conexión con el servidor: se conserva lo último
    }
  },
}));

let floorUsers = 0;
let floorTimer: ReturnType<typeof setInterval> | null = null;

/** Mantiene el estado del salón al día mientras alguna pantalla lo use */
export const useFloor = () => {
  const floor = useFloorStore((s) => s.floor);
  const refresh = useFloorStore((s) => s.refresh);
  useEffect(() => {
    floorUsers += 1;
    refresh();
    if (!floorTimer) floorTimer = setInterval(() => { if (!document.hidden) useFloorStore.getState().refresh(); }, FLOOR_POLL_MS);
    return () => {
      floorUsers -= 1;
      if (floorUsers <= 0 && floorTimer) { clearInterval(floorTimer); floorTimer = null; floorUsers = 0; }
    };
  }, [refresh]);
  return { floor, refresh };
};

export const currentUserId = (): string | null => {
  try {
    const u = JSON.parse(localStorage.getItem('user') || '{}');
    return u?.id || u?.userId || null;
  } catch {
    return null;
  }
};
