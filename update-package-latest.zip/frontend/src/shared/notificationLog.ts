// ============================================
// SHARED - Historial de avisos (la campanita)
// ============================================
// Todo aviso que sale en pantalla queda aquí para verlo después: pedidos de la
// página, reservas, platos listos en cocina, cuentas pedidas, Autopilot. Se guarda
// en este equipo (últimos 7 días, máximo 150) y sobrevive a cerrar el programa.

import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type LogIcon = 'order' | 'reservation' | 'customer' | 'prize' | 'card' | 'birthday' | 'kitchen' | 'bill' | 'alert' | 'autopilot';

export interface LogEntry {
  id: string;
  at: number;
  icon: LogIcon;
  /** Clase de color del ícono (tailwind) */
  tone: string;
  title: string;
  message: string;
  read: boolean;
}

const MAX = 150;
const KEEP_MS = 7 * 24 * 3600_000;

interface LogState {
  entries: LogEntry[];
  add: (e: Omit<LogEntry, 'at' | 'read'> & { at?: number }) => void;
  markAllRead: () => void;
  clear: () => void;
}

export const useNotificationLog = create<LogState>()(
  persist(
    (set) => ({
      entries: [],
      add: (e) => set((s) => {
        if (s.entries.some((x) => x.id === e.id)) return s;
        const now = Date.now();
        const entry: LogEntry = { ...e, at: e.at ?? now, read: false };
        return { entries: [entry, ...s.entries].filter((x) => now - x.at < KEEP_MS).slice(0, MAX) };
      }),
      markAllRead: () => set((s) => ({ entries: s.entries.map((x) => (x.read ? x : { ...x, read: true })) })),
      clear: () => set({ entries: [] }),
    }),
    { name: 'lantify.notificationLog', version: 1 },
  ),
);

export const useUnreadCount = () => useNotificationLog((s) => s.entries.reduce((n, x) => n + (x.read ? 0 : 1), 0));
