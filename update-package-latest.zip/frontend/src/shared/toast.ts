// ============================================
// SHARED - Modern Toast Notification Manager
// ============================================

export type ToastType = 'success' | 'error' | 'warning' | 'info';

export interface ToastItem {
  id: string;
  type: ToastType;
  title?: string;
  message: string;
  duration?: number;
}

type Listener = (toasts: ToastItem[]) => void;

class ToastManager {
  private toasts: ToastItem[] = [];
  private listeners: Set<Listener> = new Set();

  subscribe(listener: Listener) {
    this.listeners.add(listener);
    listener([...this.toasts]);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    for (const listener of this.listeners) {
      listener([...this.toasts]);
    }
  }

  show(item: Omit<ToastItem, 'id'>) {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const duration = item.duration ?? 4000;
    const newToast: ToastItem = { ...item, id, duration };

    this.toasts = [...this.toasts, newToast];
    this.notify();

    if (duration > 0) {
      setTimeout(() => {
        this.dismiss(id);
      }, duration);
    }

    return id;
  }

  dismiss(id: string) {
    this.toasts = this.toasts.filter(t => t.id !== id);
    this.notify();
  }

  success(message: string, title?: string) {
    return this.show({ type: 'success', message, title });
  }

  error(message: string, title?: string) {
    return this.show({ type: 'error', message, title, duration: 5500 });
  }

  warning(message: string, title?: string) {
    return this.show({ type: 'warning', message, title });
  }

  info(message: string, title?: string) {
    return this.show({ type: 'info', message, title });
  }
}

export const toast = new ToastManager();
