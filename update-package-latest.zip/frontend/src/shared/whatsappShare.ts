// ============================================
// SHARED - Ventana "Enviar cuenta por WhatsApp" (estado)
// ============================================
// sendTicketByWhatsApp prepara la imagen y abre la ventana (WhatsAppShareHost, montada
// una vez en App). La promesa se resuelve cuando la persona envía o cierra.

import { create } from 'zustand';

export type WhatsAppOutcome = 'sent' | 'copied' | 'shared' | 'downloaded' | 'cancelled';

export interface WhatsAppShareRequest {
  id: number;
  blob: Blob;
  fileName: string;
  /** Mensaje que acompaña la cuenta (sin el enlace: se agrega cuando está listo) */
  message: string;
  phone: string;
  resolve: (outcome: WhatsAppOutcome) => void;
}

interface State {
  current: WhatsAppShareRequest | null;
  open: (req: Omit<WhatsAppShareRequest, 'id' | 'resolve'>) => Promise<WhatsAppOutcome>;
  close: (outcome: WhatsAppOutcome) => void;
}

let seq = 0;

export const useWhatsAppShare = create<State>((set, get) => ({
  current: null,
  open: (req) =>
    new Promise<WhatsAppOutcome>((resolve) => {
      get().current?.resolve('cancelled');
      set({ current: { ...req, id: ++seq, resolve } });
    }),
  close: (outcome) => {
    const cur = get().current;
    if (!cur) return;
    set({ current: null });
    cur.resolve(outcome);
  },
}));
