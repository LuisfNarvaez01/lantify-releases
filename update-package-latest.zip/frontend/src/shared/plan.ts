// ============================================
// SHARED - Plan del negocio y funciones incluidas
// ============================================
// Viene de la licencia firmada por Lantify Cloud (GET /api/license). El servidor
// local es quien bloquea de verdad (402); aquí solo se decide qué mostrar:
// una función fuera del plan aparece con candado y el plan que la incluye,
// nunca desaparece sin explicación.

import { create } from 'zustand';
import { authAPI } from '../services/api';

export type PlanCode = 'basic' | 'pro' | 'premium';
export type SubStatus = 'TRIAL' | 'ACTIVE' | 'PAST_DUE' | 'GRACE' | 'SUSPENDED';

export interface LicenseInfo {
  linked: boolean;
  tenant?: { code: string; name: string } | null;
  plan?: PlanCode;
  features?: string[];
  subStatus?: SubStatus;
  periodEnd?: string | null;
  graceUntil?: string | null;
  offlineUntil?: string;
  lastSyncAt?: string | null;
}

/** Plan más barato que incluye cada función (para el mensaje "Disponible en ...") */
export const FEATURE_PLAN: Record<string, PlanCode> = {
  customers: 'pro',
  dian: 'pro',
  analytics_adv: 'pro',
  inventory: 'pro',
  multi_terminal: 'pro',
  delivery: 'premium',
  whatsapp: 'premium',
  webstore: 'premium',
  ai_copilot: 'basic',
  expense_ocr: 'pro',
  suppliers: 'pro',
  coupons: 'pro',
  ai_agents: 'premium',
  reservations: 'premium',
  loyalty: 'premium',
  business_page: 'basic',
  ops_pro: 'pro',
  autopilot: 'premium',
};

/** Precios mensuales en COP sin IVA (decisión D7 del plan de evolución) */
export const PLAN_PRICE: Record<PlanCode, number> = { basic: 49900, pro: 79900, premium: 129900 };

interface PlanState {
  info: LicenseInfo | null;
  load: () => Promise<void>;
  /** El inicio de sesión ya trae el resumen de la licencia: se usa sin esperar otra consulta */
  setFromLogin: (license: Partial<LicenseInfo> | undefined) => void;
  clear: () => void;
}

export const usePlanStore = create<PlanState>((set) => ({
  info: null,
  load: async () => {
    try {
      set({ info: await authAPI.getLicense() });
    } catch {
      // Sin respuesta se conserva lo último conocido; el servidor sigue aplicando los candados
    }
  },
  setFromLogin: (license) => {
    if (license) set((s) => ({ info: { ...(s.info || {}), linked: true, ...license } as LicenseInfo }));
  },
  clear: () => set({ info: null }),
}));

/** ¿El plan incluye la función? Sin negocio vinculado (o mientras carga) todo está disponible. */
export const hasFeature = (info: LicenseInfo | null, feature: string) =>
  !info || !info.linked || !info.features || info.features.includes(feature)
  // Licencias anteriores a la 3.0 no traen ops_pro: Pro o superior (analítica avanzada) lo incluye
  || (feature === 'ops_pro' && info.features.includes('analytics_adv'))
  || (feature === 'autopilot' && info.features.includes('ai_agents'));

export const usePlan = () => {
  const info = usePlanStore((s) => s.info);
  return {
    info,
    linked: !!info?.linked,
    plan: info?.plan,
    subStatus: info?.subStatus,
    has: (feature: string) => hasFeature(info, feature),
  };
};

export const useFeature = (feature: string) => hasFeature(usePlanStore((s) => s.info), feature);

const DAY = 86_400_000;

/** Días enteros que faltan hasta una fecha (0 si ya pasó) */
export const daysUntil = (iso: string | null | undefined, now = Date.now()) =>
  iso ? Math.max(0, Math.ceil((Date.parse(iso) - now) / DAY)) : null;

/** Evento para abrir el aviso del plan desde cualquier pantalla (p. ej. al recibir un 402) */
export const PLAN_LOCK_EVENT = 'lantify:plan-lock';
export const showPlanLock = (feature: string) =>
  window.dispatchEvent(new CustomEvent(PLAN_LOCK_EVENT, { detail: { feature } }));
