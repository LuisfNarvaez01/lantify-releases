// Puente con la app de escritorio (Lantify.exe). Solo existe en la ventana del equipo principal;
// en las tablets y en el navegador `desktop()` devuelve null.

export interface DesktopUpdateStatus {
  state: 'idle' | 'checking' | 'downloading' | 'ready' | 'up-to-date' | 'error' | 'disabled';
  currentVersion: string;
  latestVersion?: string;
  percent?: number;
}

export interface DesktopInfo {
  version: string;
  firstRun: boolean;
  legacyImport: { from: string; at: string; database: boolean; secrets: boolean } | null;
  lanAccess: boolean;
  tabletUrls: string[];
  dataDir: string;
  update: DesktopUpdateStatus;
}

interface DesktopBridge {
  info(): Promise<DesktopInfo>;
  markWelcomed(): Promise<boolean>;
  openBackups(): Promise<string>;
  copy(text: string): Promise<void>;
  /** Ingresos guardados (versiones anteriores de Lantify.exe no lo tienen) */
  logins?: {
    list(): Promise<{ username: string; name: string; hasPassword: boolean; lastUsedAt: string }[]>;
    password(username: string): Promise<string | null>;
    save(login: { username: string; name?: string; password?: string }): Promise<boolean>;
    remove(username: string): Promise<boolean>;
  };
}

export const desktop = (): DesktopBridge | null => (window as unknown as { lantifyDesktop?: DesktopBridge }).lantifyDesktop ?? null;
