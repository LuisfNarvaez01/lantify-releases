// ============================================
// SHARED - Funciones del usuario actual (las define el ADMIN por rol)
// ============================================
// La fuente es el servidor (GET /permissions); se guarda una copia local para
// que la pantalla no parpadee al entrar. El servidor aplica la misma regla, así
// que esconder un botón aquí es solo comodidad, no seguridad.

import { create } from 'zustand';
import { permissionsAPI } from '../services/api';
import { DEFAULT_ROLE_PERMISSIONS, normalizeRolePermissions, Permission, roleCan, RolePermissions } from '../../../src/domain/rolePermissions';

export type { Permission, RolePermissions, ConfigurableRole } from '../../../src/domain/rolePermissions';
export { PERMISSIONS, CONFIGURABLE_ROLES, DEFAULT_ROLE_PERMISSIONS } from '../../../src/domain/rolePermissions';

const CACHE_KEY = 'lantify.rolePermissions';

const cached = (): RolePermissions => {
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    if (raw) return normalizeRolePermissions(JSON.parse(raw));
  } catch {
    // sin almacenamiento local
  }
  return normalizeRolePermissions(DEFAULT_ROLE_PERMISSIONS);
};

interface PermissionsState {
  perms: RolePermissions;
  load: () => Promise<void>;
  save: (perms: RolePermissions) => Promise<RolePermissions>;
}

const remember = (perms: RolePermissions) => {
  try {
    localStorage.setItem(CACHE_KEY, JSON.stringify(perms));
  } catch {
    // sin almacenamiento local
  }
};

export const usePermissions = create<PermissionsState>((set) => ({
  perms: cached(),
  load: async () => {
    try {
      const perms = normalizeRolePermissions(await permissionsAPI.get());
      remember(perms);
      set({ perms });
    } catch {
      // se queda con la copia local
    }
  },
  save: async (next) => {
    const perms = normalizeRolePermissions(await permissionsAPI.save(next));
    remember(perms);
    set({ perms });
    return perms;
  },
}));

const currentRole = (): string | undefined => {
  try {
    return JSON.parse(localStorage.getItem('user') || '{}')?.role;
  } catch {
    return undefined;
  }
};

/** ¿El usuario (o el rol indicado) tiene alguna de estas funciones? */
export const useCan = (role?: string) => {
  const perms = usePermissions((s) => s.perms);
  const r = (role || currentRole() || 'WAITER').toUpperCase();
  return (...wanted: Permission[]) => roleCan(perms, r, ...wanted);
};

/** Pestañas del POS y la función que piden (mesas y pedidos son de todos) */
const TAB_PERMISSION: Record<string, Permission | 'ADMIN' | null> = {
  tables: null,
  products: null,
  sales: 'sales_history',
  cash: 'cash',
  analytics: 'analytics',
  reservations: 'reservations',
  delivery: 'online_orders',
  agents: 'ADMIN',
};

export const tabAllowed = (perms: RolePermissions, role: string | undefined, tab: string): boolean => {
  const r = (role || 'WAITER').toUpperCase();
  if (r === 'ADMIN') return true;
  const need = TAB_PERMISSION[tab];
  if (need === undefined || need === 'ADMIN') return false;
  return need === null || roleCan(perms, r, need);
};
