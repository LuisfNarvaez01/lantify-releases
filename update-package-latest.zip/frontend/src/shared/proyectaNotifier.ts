// ============================================
// Avisos de Proyecta en toda la caja (3.7)
// ============================================
// Con Proyecta vinculado, la caja se entera de lo que importa sin abrir Administración:
//  · un mensaje nuevo del DJ;
//  · sin DJ en cabina: un pedido de canción esperando decisión o una canción que no cargó.
// Con DJ en cabina solo llegan los mensajes (él decide los pedidos). Si el negocio no tiene
// Proyecta vinculado, se revisa muy de vez en cuando.

import { t } from '../i18n';
import { toast } from './toast';
import { proyectaAPI, type ProyectaStatus } from '../services/proyectaApi';

const POLL_MS = 20_000;
const IDLE_MS = 5 * 60_000;

export const startProyectaNotifier = (opts: { isOpen: () => boolean; onStatus?: (s: ProyectaStatus | null) => void }) => {
  let alive = true;
  let timer: ReturnType<typeof setTimeout> | null = null;
  let seenChat: string | null | undefined;
  const seenPending = new Set<string>();
  const seenAlerts = new Set<string>();
  let first = true;

  const tick = async () => {
    let next = POLL_MS;
    try {
      if (document.visibilityState === 'hidden') return;
      const s = await proyectaAPI.status();
      opts.onStatus?.(s);
      if (!s.venue || !s.desk) { next = IDLE_MS; return; }
      const desk = s.desk;
      // La pantalla de Proyecta ya muestra todo: allí no se repite con avisos
      const quiet = first || opts.isOpen();

      const last = desk.lastChat;
      if (last && seenChat !== undefined && last.id !== seenChat && last.from === 'dj' && !quiet) toast.info(t('proyecta:aviso_mensaje'), t('proyecta:aviso_titulo'));
      seenChat = last?.id ?? null;

      if (!desk.djPresent) {
        const fresh = desk.pending.filter((r) => !seenPending.has(r.id));
        if (fresh.length && !quiet) {
          const r = fresh[0];
          const by = r.guest || (r.table ? t('proyecta:mesa', { number: r.table }) : '');
          toast.info(fresh.length === 1 ? t('proyecta:aviso_pedido', { title: r.title, by }) : t('proyecta:aviso_pedidos', { count: fresh.length }), t('proyecta:aviso_titulo'));
        }
        const alerts = desk.alerts.filter((a) => !seenAlerts.has(a.id));
        if (alerts.length && !quiet) toast.warning(alerts[alerts.length - 1].text, t('proyecta:aviso_titulo'));
        alerts.forEach((a) => seenAlerts.add(a.id));
      }
      desk.pending.forEach((r) => seenPending.add(r.id));
      first = false;
    } catch {
      opts.onStatus?.(null);
      next = IDLE_MS; // sin permiso, sin nube o sin plan: se revisa poco
    } finally {
      if (alive) timer = setTimeout(tick, next);
    }
  };

  void tick();
  return () => { alive = false; if (timer) clearTimeout(timer); };
};
