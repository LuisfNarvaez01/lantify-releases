// ============================================
// SHARED - Avisos en vivo del servidor del negocio (Lantify 3.0)
// ============================================
// Una sola conexión abierta por equipo (GET /api/events). Cuando el servidor dice
// que algo cambió, se vuelve a pedir solo eso: mesas y salón, la carta o los
// avisos. Si la conexión se cae se reintenta sola; mientras tanto las pantallas
// siguen preguntando cada pocos segundos como antes, así que nunca se queda sin datos.

import { useEffect } from 'react';
import { create } from 'zustand';
import { liveAPI } from '../services/api';
import { usePosStore } from '../store/usePosStore';
import { useFloorStore } from './features';

export type LiveTopic = 'floor' | 'catalog' | 'notifications';

interface LiveState {
  /** Hay conexión en vivo con el servidor */
  connected: boolean;
  /** Último aviso recibido (ms) */
  lastAt: number;
}

export const useLive = create<LiveState>(() => ({ connected: false, lastAt: 0 }));

/** Lo que escucha la campanita y el centro de avisos */
export const LIVE_NOTIFICATIONS_EVENT = 'lantify:notifications';

const timers: Partial<Record<LiveTopic, ReturnType<typeof setTimeout>>> = {};
const soon = (topic: LiveTopic, fn: () => void, ms = 150) => {
  if (timers[topic]) clearTimeout(timers[topic]);
  timers[topic] = setTimeout(() => { delete timers[topic]; fn(); }, ms);
};

export const applyTopics = (topics: LiveTopic[]) => {
  useLive.setState({ lastAt: Date.now() });
  if (topics.includes('floor')) {
    soon('floor', () => {
      useFloorStore.getState().refresh();
      usePosStore.getState().fetchTables().catch(() => undefined);
    });
  }
  if (topics.includes('catalog')) soon('catalog', () => { usePosStore.getState().fetchProducts().catch(() => undefined); }, 300);
  if (topics.includes('notifications')) soon('notifications', () => window.dispatchEvent(new Event(LIVE_NOTIFICATIONS_EVENT)), 50);
};

/** Lee el flujo `event: …\ndata: …\n\n` y entrega cada aviso */
const readStream = async (res: Response, onTopics: (t: LiveTopic[]) => void) => {
  if (!res.body) return;
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buf = '';
  for (;;) {
    const { value, done } = await reader.read();
    if (done) return;
    buf += decoder.decode(value, { stream: true });
    let cut: number;
    while ((cut = buf.indexOf('\n\n')) >= 0) {
      const block = buf.slice(0, cut);
      buf = buf.slice(cut + 2);
      const event = /^event: (.+)$/m.exec(block)?.[1];
      const data = /^data: (.+)$/m.exec(block)?.[1];
      if (event !== 'change' || !data) continue;
      try {
        const parsed = JSON.parse(data) as { topics?: LiveTopic[] };
        if (Array.isArray(parsed.topics)) onTopics(parsed.topics);
      } catch { /* aviso dañado: se ignora */ }
    }
  }
};

/** Mantiene la conexión en vivo mientras haya alguien con sesión en la pantalla */
export function useLiveEvents(enabled = true) {
  useEffect(() => {
    if (!enabled) return;
    let alive = true;
    let ctrl: AbortController | null = null;
    let wait = 1000;
    const loop = async () => {
      while (alive) {
        ctrl = new AbortController();
        try {
          const res = await liveAPI.open(ctrl.signal);
          if (res.ok) {
            useLive.setState({ connected: true });
            wait = 1000;
            // Al reconectar se pide todo una vez: pudo cambiar algo mientras no había conexión
            applyTopics(['floor', 'notifications']);
            await readStream(res, applyTopics);
          } else if (res.status === 401 || res.status === 403) {
            return; // sin sesión: no se insiste
          }
        } catch { /* sin conexión: se reintenta */ }
        useLive.setState({ connected: false });
        if (!alive) return;
        await new Promise((r) => setTimeout(r, wait));
        wait = Math.min(wait * 2, 15_000);
      }
    };
    loop();
    return () => {
      alive = false;
      ctrl?.abort();
      useLive.setState({ connected: false });
    };
  }, [enabled]);
}
