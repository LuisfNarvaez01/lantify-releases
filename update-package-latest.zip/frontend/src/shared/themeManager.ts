// ============================================
// THEME MANAGER - Global Design & Typography Tokens
// Full System-wide Theme & Color Personalization
// ============================================

import { familyVars, primaryScale, PRIMARY_FAMILY } from './theme/paletteCore.js';
import { THEME_MODE_EVENT, getResolvedTheme } from './theme/themeMode';

import { t } from '../i18n';
export interface ThemeConfig {
  primaryColor: string;
  primaryHover: string;
  primaryLight: string;
  headerColor: string;
  accentColor: string;
  fontScale: string; // '13px' | '14px' | '15px' | '16px'
}

export interface ThemePreset {
  id: string;
  name: string;
  category: string;
  primary: string;
  hover: string;
  light: string;
  header: string;
  accent: string;
  description: string;
}

export const THEME_PRESETS: ThemePreset[] = [
  {
    id: 'zafiro',
    get name() { return t('common:azul_zafiro_real_recomendado'); },
    get category() { return t('common:corporativo_ejecutivo'); },
    primary: '#1e40af',
    hover: '#1e3a8a',
    light: '#eff6ff',
    header: '#0f172a',
    accent: '#38bdf8',
    get description() { return t('common:elegancia_sobriedad_y_maxima_legibilidad_en_salone'); }
  },
  {
    id: 'cobalto',
    get name() { return t('common:cobalto_cian_moderno'); },
    get category() { return t('common:tecnologico_retail'); },
    primary: '#2563eb',
    hover: '#1d4ed8',
    light: '#eff6ff',
    header: '#0b1329',
    accent: '#06b6d4',
    get description() { return t('common:vibrante_y_moderno_excelente_para_retail_y'); }
  },
  {
    id: 'espresso',
    get name() { return t('common:cafe_tostado_caramelo'); },
    get category() { return t('common:cafeteria_panaderia'); },
    primary: '#78350f',
    hover: '#572507',
    light: '#fef3c7',
    header: '#1c1917',
    accent: '#d97706',
    get description() { return t('common:tonos_calidos_de_cafe_y_madera_para'); }
  },
  {
    id: 'esmeralda',
    get name() { return t('common:bistro_esmeralda_menta'); },
    get category() { return t('common:saludable_bistro'); },
    primary: '#047857',
    hover: '#065f46',
    light: '#ecfdf5',
    header: '#064e3b',
    accent: '#10b981',
    get description() { return t('common:frescura_organica_para_restaurantes_saludables_jug'); }
  },
  {
    id: 'borgona',
    get name() { return t('common:vino_tinto_borgona'); },
    get category() { return t('common:parrilla_trattoria'); },
    primary: '#9f1239',
    hover: '#881337',
    light: '#fff1f2',
    header: '#4c0519',
    accent: '#f43f5e',
    get description() { return t('common:calido_y_distinguido_para_steakhouses_pizzerias_it'); }
  },
  {
    id: 'purpura',
    get name() { return t('common:purpura_imperial_lavanda'); },
    get category() { return t('common:lounge_nocturno'); },
    primary: '#6d28d9',
    hover: '#5b21b6',
    light: '#f5f3ff',
    header: '#2e1065',
    accent: '#a855f7',
    get description() { return t('common:ambientes_sofisticados_cocteleria_de_autor_y_bares'); }
  },
  {
    id: 'terracota',
    get name() { return t('common:terracota_ambar_fuego'); },
    get category() { return t('common:fast_casual_pizzeria'); },
    primary: '#c2410c',
    hover: '#9a3412',
    light: '#fff7ed',
    header: '#292524',
    accent: '#f97316',
    get description() { return t('common:energia_y_dinamismo_para_hamburgueserias_pizzerias'); }
  },
  {
    id: 'marino',
    get name() { return t('common:azul_marino_clasico'); },
    get category() { return t('common:mariscos_tradicional'); },
    primary: '#0369a1',
    hover: '#075985',
    light: '#f0f9ff',
    header: '#082f49',
    accent: '#38bdf8',
    get description() { return t('common:limpio_y_acogedor_para_restaurantes_de_costa'); }
  },
  {
    id: 'rubi',
    get name() { return t('common:rosa_rubi_gourmet'); },
    get category() { return t('common:heladeria_dulces'); },
    primary: '#be185d',
    hover: '#9d174d',
    light: '#fdf2f8',
    header: '#500724',
    accent: '#ec4899',
    get description() { return t('common:divertido_y_dulce_para_heladerias_pastelerias_fina'); }
  },
  {
    id: 'onyx',
    get name() { return t('common:dark_onyx_carbon_puro'); },
    get category() { return t('common:minimalista_total'); },
    primary: '#334155',
    hover: '#1e293b',
    light: '#f1f5f9',
    header: '#020617',
    accent: '#94a3b8',
    get description() { return t('common:minimalismo_escandinavo_en_escala_neutra_de_carbon'); }
  },
];

export const FONT_SCALE_PRESETS = [
  { id: 'compact', get label() { return t('common:compacta'); }, size: '13px', get description() { return t('common:monitores_pequenos_o_alta_densidad'); } },
  { id: 'normal', get label() { return t('common:estandar'); }, size: '14px', get description() { return t('common:equilibrado_recomendado'); } },
  { id: 'comfortable', get label() { return t('common:comoda'); }, size: '15px', get description() { return t('common:mayor_descanso_visual'); } },
  { id: 'large', get label() { return t('common:grande_tactil'); }, size: '16px', get description() { return t('common:pantallas_tactiles_y_alta_distancia'); } },
  { id: 'xl', get label() { return t('common:muy_grande'); }, size: '18px', get description() { return t('common:muy_grande_desc'); } },
  { id: 'xxl', get label() { return t('common:extra_grande'); }, size: '20px', get description() { return t('common:extra_grande_desc'); } },
];

/** Límites del tamaño de letra (px de la letra raíz; todo el sistema mide en rem) */
export const FONT_SIZE_MIN = 12;
export const FONT_SIZE_MAX = 22;

export const DEFAULT_THEME: ThemeConfig = {
  primaryColor: '#1e40af',
  primaryHover: '#1e3a8a',
  primaryLight: '#eff6ff',
  headerColor: '#0f172a',
  accentColor: '#38bdf8',
  fontScale: '14px',
};

// Helper para oscurecer/aclarar colores hexadecimales para hover/light generados
export function adjustColorBrightness(hex: string, percent: number): string {
  const clean = hex.replace('#', '');
  const num = parseInt(clean, 16);
  if (isNaN(num)) return hex;
  const amt = Math.round(2.55 * percent);
  const R = (num >> 16) + amt;
  const G = (num >> 8 & 0x00FF) + amt;
  const B = (num & 0x0000FF) + amt;
  return '#' + (
    0x1000000 +
    (R < 255 ? (R < 1 ? 0 : R) : 255) * 0x10000 +
    (G < 255 ? (G < 1 ? 0 : G) : 255) * 0x100 +
    (B < 255 ? (B < 1 ? 0 : B) : 255)
  ).toString(16).slice(1);
}

/**
 * Aplica los tokens del tema al elemento raíz :root del documento
 */
export function applyTheme(theme?: Partial<ThemeConfig>): ThemeConfig {
  const currentTheme = getSavedTheme();
  const merged: ThemeConfig = {
    ...DEFAULT_THEME,
    ...currentTheme,
    ...theme,
  };

  if (typeof document !== 'undefined') {
    const root = document.documentElement;
    root.style.setProperty('--lantify-primary', merged.primaryColor);
    root.style.setProperty('--lantify-primary-hover', merged.primaryHover || adjustColorBrightness(merged.primaryColor, -15));
    root.style.setProperty('--lantify-primary-light', merged.primaryLight || adjustColorBrightness(merged.primaryColor, 85));
    root.style.setProperty('--lantify-header', merged.headerColor || adjustColorBrightness(merged.primaryColor, -65));
    root.style.setProperty('--lantify-accent', merged.accentColor || adjustColorBrightness(merged.primaryColor, 35));
    root.style.setProperty('--lantify-font-scale', merged.fontScale);
    root.style.fontSize = merged.fontScale;
    applyPrimaryPalette(merged);
  }

  return merged;
}

/**
 * Recalcula la escala completa del color principal (las clases bg-blue-*, text-blue-*...)
 * para el tema efectivo (claro u oscuro).
 */
function applyPrimaryPalette(theme: ThemeConfig) {
  const scale = primaryScale(theme.primaryColor, theme.primaryHover, theme.primaryLight);
  const vars = familyVars(PRIMARY_FAMILY, scale, getResolvedTheme(), false);
  const root = document.documentElement;
  for (const [name, value] of Object.entries(vars)) {
    root.style.setProperty(name, value);
  }
}

// Al cambiar entre claro y oscuro, la escala del color principal se recalcula
if (typeof window !== 'undefined') {
  window.addEventListener(THEME_MODE_EVENT, () => applyPrimaryPalette(getSavedTheme()));
}

/**
 * Lee la configuración guardada en localStorage
 */
export function getSavedTheme(): ThemeConfig {
  try {
    const saved = localStorage.getItem('posConfig');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed.theme) {
        return {
          ...DEFAULT_THEME,
          ...parsed.theme,
        };
      }
    }
  } catch (e) {
    console.error('Error reading saved theme config:', e);
  }
  return DEFAULT_THEME;
}

/**
 * Guarda y aplica el nuevo tema
 */
export function saveTheme(theme: Partial<ThemeConfig>): ThemeConfig {
  const updated = applyTheme(theme);
  try {
    const saved = localStorage.getItem('posConfig');
    const config = saved ? JSON.parse(saved) : {};
    config.theme = updated;
    localStorage.setItem('posConfig', JSON.stringify(config));
  } catch (e) {
    console.error('Error saving theme config:', e);
  }
  return updated;
}
