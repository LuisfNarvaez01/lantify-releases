// ============================================
// SHARED - Estado de un producto para pedirlo
// ============================================

/** Pausado hasta una hora (Autopilot o a mano, por falta de existencias) */
export const isProductPaused = (product: { pausedUntil?: string | Date | null } | null | undefined, now = Date.now()) =>
  !!product?.pausedUntil && new Date(product.pausedUntil).getTime() > now;
