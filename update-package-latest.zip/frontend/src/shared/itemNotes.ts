// ============================================
// SHARED - Comentarios de una línea del pedido
// ============================================
// Lo que se quitó ("sin cebolla") va aparte del texto libre para que la cocina
// lo vea destacado y para poder analizarlo después.

import { t } from '../i18n';

/** "Sin cebolla, sin salsa" */
export const removedText = (removed?: string[] | null): string => {
  if (!removed || !removed.length) return '';
  const text = removed.map((name) => `${t('v3:sin').toLowerCase()} ${name.toLowerCase()}`).join(', ');
  return text.charAt(0).toUpperCase() + text.slice(1);
};

/** Todo el comentario de la línea en una frase (carrito, recibos) */
export const fullNote = (item: { notes?: string | null; removed?: string[] | null }): string =>
  [removedText(item.removed), (item.notes || '').trim()].filter(Boolean).join(' · ');

/** Ingredientes de un producto tal como llegan del servidor (JSON o lista) */
export const parseIngredients = (raw: unknown): string[] => {
  if (Array.isArray(raw)) return raw.filter((x): x is string => typeof x === 'string' && !!x.trim());
  if (typeof raw !== 'string' || !raw) return [];
  try {
    const list = JSON.parse(raw);
    return Array.isArray(list) ? list.filter((x): x is string => typeof x === 'string' && !!x.trim()) : [];
  } catch {
    return [];
  }
};
