// ============================================
// SHARED - Configuración del negocio (fuente: servidor)
// ============================================
// La define la configuración inicial y la comparten todos los equipos del local
// (caja, tablets de meseros). Se copia también a `posConfig` para que la
// impresión de tickets siga funcionando sin conexión con el último dato conocido.

import { create } from 'zustand';
import { businessAPI, BusinessSettings, TaxType } from '../services/api';

interface BusinessState {
  settings: BusinessSettings | null;
  loaded: boolean;
  load: () => Promise<BusinessSettings | null>;
  setSettings: (s: BusinessSettings) => void;
}

const mirrorToPosConfig = (s: BusinessSettings) => {
  try {
    const saved = localStorage.getItem('posConfig');
    const config = saved ? JSON.parse(saved) : {};
    config.businessName = s.businessName || config.businessName;
    config.address = [s.address, s.city].filter(Boolean).join(', ');
    config.phone = s.phone || '';
    config.nit = s.nit ? (s.dv ? `${s.nit}-${s.dv}` : s.nit) : '';
    if (s.ticketFooter) config.ticketFooterText = s.ticketFooter;
    localStorage.setItem('posConfig', JSON.stringify(config));
  } catch {
    // sin almacenamiento local: el ticket usa lo que tenga en memoria
  }
};

export const useBusinessStore = create<BusinessState>((set) => ({
  settings: null,
  loaded: false,
  load: async () => {
    try {
      const settings = await businessAPI.get();
      mirrorToPosConfig(settings);
      set({ settings, loaded: true });
      return settings;
    } catch {
      set({ loaded: true });
      return null;
    }
  },
  setSettings: (settings) => {
    mirrorToPosConfig(settings);
    set({ settings, loaded: true });
  },
}));

/** Valores por defecto mientras carga o si el servidor no responde. */
export const useBusiness = () => {
  const settings = useBusinessStore((s) => s.settings);
  return {
    settings,
    usesTables: settings ? settings.usesTables : true,
    tipEnabled: !!settings?.tipEnabled,
    tipPercent: settings?.tipPercent ?? 10,
  };
};

/** Configuración → Mantenimiento → Reconfigurar abre de nuevo el asistente */
export const OPEN_ONBOARDING_EVENT = 'lantify:open-onboarding';
export const openOnboarding = () => window.dispatchEvent(new Event(OPEN_ONBOARDING_EVENT));

export const formatTaxLabel = (taxType: TaxType | string | null | undefined, rate: number | null | undefined) => {
  if (taxType === 'IVA') return `IVA ${rate ?? 0} %`;
  if (taxType === 'INC') return `INC ${rate ?? 0} %`;
  return null;
};

/** Agrupa el impuesto de las líneas de una venta (para el ticket). */
export const groupSaleTaxes = (items: { taxType?: string; taxRate?: number; taxAmount?: number; isCancelled?: boolean }[] = []) => {
  const groups = new Map<string, { taxType: string; taxRate: number; amount: number }>();
  for (const it of items) {
    if (it.isCancelled || !it.taxAmount || !it.taxType || it.taxType === 'NONE') continue;
    const key = `${it.taxType}:${it.taxRate}`;
    const g = groups.get(key) || { taxType: it.taxType, taxRate: it.taxRate || 0, amount: 0 };
    g.amount = Math.round((g.amount + it.taxAmount) * 100) / 100;
    groups.set(key, g);
  }
  return Array.from(groups.values());
};
