// ============================================
// SHARED - Presets por tipo de negocio (configuración inicial)
// ============================================
// Cada tipo propone valores de partida; el dueño los puede cambiar en los
// pasos siguientes y después en Configuración.

import { t } from '../i18n';
import type { BusinessType, TaxRegime, TaxType } from '../services/api';
import type { TableViewMode } from './posSettings';
import type { ThemeMode } from './theme/themeMode';

export interface BusinessPreset {
  id: BusinessType;
  icon: 'utensils' | 'coffee' | 'wine' | 'burger' | 'truck' | 'store' | 'services';
  readonly label: string;
  readonly description: string;
  readonly highlights: string[];
  usesTables: boolean;
  zones: { readonly name: string; tables: number }[];
  tableViewMode: TableViewMode;
  tipEnabled: boolean;
  inventoryEnabled: boolean;
  deliveryEnabled: boolean;
  taxRegime: TaxRegime;
  themeMode: ThemeMode;
  themePresetId: string;
}

export const BUSINESS_PRESETS: BusinessPreset[] = [
  {
    id: 'RESTAURANT',
    icon: 'utensils',
    get label() { return t('onboarding:tipo_restaurante'); },
    get description() { return t('onboarding:tipo_restaurante_desc'); },
    get highlights() { return [t('onboarding:hl_plano_mesas'), t('onboarding:hl_comandas'), t('onboarding:hl_propina')]; },
    usesTables: true,
    zones: [{ get name() { return t('onboarding:zona_salon'); }, tables: 10 }],
    tableViewMode: 'floorplan',
    tipEnabled: true,
    inventoryEnabled: false,
    deliveryEnabled: false,
    taxRegime: 'RESPONSABLE_INC',
    themeMode: 'light',
    themePresetId: 'zafiro',
  },
  {
    id: 'CAFE',
    icon: 'coffee',
    get label() { return t('onboarding:tipo_cafe'); },
    get description() { return t('onboarding:tipo_cafe_desc'); },
    get highlights() { return [t('onboarding:hl_mostrador'), t('onboarding:hl_pocas_mesas'), t('onboarding:hl_catalogo_visual')]; },
    usesTables: true,
    zones: [{ get name() { return t('onboarding:zona_salon'); }, tables: 4 }],
    tableViewMode: 'operational',
    tipEnabled: false,
    inventoryEnabled: false,
    deliveryEnabled: false,
    taxRegime: 'RESPONSABLE_INC',
    themeMode: 'light',
    themePresetId: 'espresso',
  },
  {
    id: 'BAR',
    icon: 'wine',
    get label() { return t('onboarding:tipo_bar'); },
    get description() { return t('onboarding:tipo_bar_desc'); },
    get highlights() { return [t('onboarding:hl_cuentas_abiertas'), t('onboarding:hl_tema_oscuro'), t('onboarding:hl_propina')]; },
    usesTables: true,
    zones: [
      { get name() { return t('onboarding:zona_barra'); }, tables: 6 },
      { get name() { return t('onboarding:zona_salon'); }, tables: 8 },
    ],
    tableViewMode: 'floorplan',
    tipEnabled: true,
    inventoryEnabled: true,
    deliveryEnabled: false,
    taxRegime: 'RESPONSABLE_INC',
    themeMode: 'dark',
    themePresetId: 'purpura',
  },
  {
    id: 'FAST_FOOD',
    icon: 'burger',
    get label() { return t('onboarding:tipo_comidas_rapidas'); },
    get description() { return t('onboarding:tipo_comidas_rapidas_desc'); },
    get highlights() { return [t('onboarding:hl_mostrador'), t('onboarding:hl_cobro_rapido'), t('onboarding:hl_domicilios')]; },
    usesTables: false,
    zones: [],
    tableViewMode: 'operational',
    tipEnabled: false,
    inventoryEnabled: false,
    deliveryEnabled: true,
    taxRegime: 'RESPONSABLE_INC',
    themeMode: 'light',
    themePresetId: 'terracota',
  },
  {
    id: 'FOOD_TRUCK',
    icon: 'truck',
    get label() { return t('onboarding:tipo_food_truck'); },
    get description() { return t('onboarding:tipo_food_truck_desc'); },
    get highlights() { return [t('onboarding:hl_solo_mostrador'), t('onboarding:hl_cobro_rapido'), t('onboarding:hl_pantalla_tactil')]; },
    usesTables: false,
    zones: [],
    tableViewMode: 'operational',
    tipEnabled: false,
    inventoryEnabled: false,
    deliveryEnabled: false,
    taxRegime: 'NO_RESPONSABLE',
    themeMode: 'light',
    themePresetId: 'cobalto',
  },
  {
    id: 'RETAIL',
    icon: 'store',
    get label() { return t('onboarding:tipo_tienda'); },
    get description() { return t('onboarding:tipo_tienda_desc'); },
    get highlights() { return [t('onboarding:hl_lector_codigos'), t('onboarding:hl_inventario'), t('onboarding:hl_iva_producto')]; },
    usesTables: false,
    zones: [],
    tableViewMode: 'operational',
    tipEnabled: false,
    inventoryEnabled: true,
    deliveryEnabled: false,
    taxRegime: 'RESPONSABLE_IVA',
    themeMode: 'light',
    themePresetId: 'marino',
  },
  {
    id: 'SERVICES',
    icon: 'services',
    get label() { return t('onboarding:tipo_servicios'); },
    get description() { return t('onboarding:tipo_servicios_desc'); },
    get highlights() { return [t('onboarding:hl_servicios_ordenes'), t('onboarding:hl_servicios_entrega'), t('onboarding:hl_servicios_whatsapp')]; },
    usesTables: false,
    zones: [],
    tableViewMode: 'operational',
    tipEnabled: false,
    inventoryEnabled: false,
    deliveryEnabled: true,
    taxRegime: 'NO_RESPONSABLE',
    themeMode: 'light',
    themePresetId: 'cobalto',
  },
];

export const getPreset = (id: BusinessType | string | null | undefined) =>
  BUSINESS_PRESETS.find((p) => p.id === id) || BUSINESS_PRESETS[0];

/** Impuesto por defecto según el régimen tributario. */
export const TAX_BY_REGIME: Record<TaxRegime, { taxType: TaxType; taxRate: number }> = {
  NO_RESPONSABLE: { taxType: 'NONE', taxRate: 0 },
  RESPONSABLE_INC: { taxType: 'INC', taxRate: 8 },
  RESPONSABLE_IVA: { taxType: 'IVA', taxRate: 19 },
};

export const TAX_REGIMES: { id: TaxRegime; readonly label: string; readonly description: string }[] = [
  {
    id: 'NO_RESPONSABLE',
    get label() { return t('onboarding:regimen_no_responsable'); },
    get description() { return t('onboarding:regimen_no_responsable_desc'); },
  },
  {
    id: 'RESPONSABLE_INC',
    get label() { return t('onboarding:regimen_inc'); },
    get description() { return t('onboarding:regimen_inc_desc'); },
  },
  {
    id: 'RESPONSABLE_IVA',
    get label() { return t('onboarding:regimen_iva'); },
    get description() { return t('onboarding:regimen_iva_desc'); },
  },
];
