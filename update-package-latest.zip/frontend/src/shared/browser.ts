// ============================================
// SHARED - Funciones del navegador que también sirven en las tablets
// ============================================
// Las tablets de los meseros abren el POS por http://<IP-del-equipo>:5173. Ahí el
// navegador no habilita crypto.randomUUID ni navigator.clipboard (solo existen en
// localhost o HTTPS), así que estas versiones tienen un respaldo.

/** Identificador único (UUID v4) */
export const newId = (): string => {
  if (typeof crypto.randomUUID === 'function') return crypto.randomUUID();
  const b = crypto.getRandomValues(new Uint8Array(16));
  b[6] = (b[6] & 0x0f) | 0x40;
  b[8] = (b[8] & 0x3f) | 0x80;
  const h = Array.from(b, (x) => x.toString(16).padStart(2, '0')).join('');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
};

/** Copia texto al portapapeles; lanza un error si el navegador no lo permite */
export const copyText = async (text: string): Promise<void> => {
  if (navigator.clipboard && window.isSecureContext) {
    await navigator.clipboard.writeText(text);
    return;
  }
  const area = document.createElement('textarea');
  area.value = text;
  area.setAttribute('readonly', '');
  area.style.position = 'fixed';
  area.style.opacity = '0';
  document.body.appendChild(area);
  area.select();
  const ok = document.execCommand('copy');
  area.remove();
  if (!ok) throw new Error('copy failed');
};
