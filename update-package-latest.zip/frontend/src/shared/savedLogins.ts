// ============================================
// SHARED - Ingresos guardados en este equipo
// ============================================
// Lantify.exe (caja): usuario y contraseña, cifrada con la cuenta de Windows por la app
//   de escritorio. La interfaz nunca la guarda en el navegador.
// App Android 1.2+: igual que la caja, pero en el almacén cifrado del teléfono y por local.
// Tablets y navegador: solo el usuario y su nombre. La contraseña la recuerda el gestor
//   de contraseñas del navegador (el formulario usa autocomplete="username/current-password").

import { desktop } from './desktop';
import { androidBridge } from '../services/androidBridge';
import { currentPairingKey } from '../services/transport';

type LoginsBridge = NonNullable<NonNullable<ReturnType<typeof desktop>>['logins']>;

/** La app Android con el mismo contrato que la de escritorio (cada local con su lista) */
const androidLogins = (): LoginsBridge | null => {
  const a = androidBridge();
  if (!a?.loginsList || !a.loginSave || !a.loginPassword || !a.loginRemove) return null;
  const scope = currentPairingKey() || 'local';
  return {
    list: async () => {
      try { return JSON.parse(a.loginsList!(scope) || '[]'); } catch { return []; }
    },
    password: async (username) => a.loginPassword!(scope, username) ?? null,
    save: async (login) => a.loginSave!(scope, JSON.stringify(login)),
    remove: async (username) => a.loginRemove!(scope, username),
  };
};

const bridge = (): LoginsBridge | null => desktop()?.logins ?? androidLogins();

export interface SavedLogin {
  username: string;
  name: string;
  hasPassword: boolean;
  lastUsedAt: string;
}

const KEY = 'lantify.savedLogins';
const PREF = 'lantify.rememberLogin';
const MAX = 12;

const readLocal = (): SavedLogin[] => {
  try {
    const list = JSON.parse(localStorage.getItem(KEY) || '[]');
    return Array.isArray(list) ? list.filter((l) => l && typeof l.username === 'string').map((l) => ({ ...l, hasPassword: false })) : [];
  } catch {
    return [];
  }
};

const writeLocal = (list: SavedLogin[]) => {
  try {
    localStorage.setItem(KEY, JSON.stringify(list.slice(0, MAX).map(({ username, name, lastUsedAt }) => ({ username, name, lastUsedAt }))));
  } catch {
    // sin almacenamiento local
  }
};

/** En Lantify.exe la contraseña se puede guardar (cifrada); en el navegador, solo el usuario */
export const canSavePasswords = () => !!bridge();

export const savedLogins = {
  async list(): Promise<SavedLogin[]> {
    const b = bridge();
    if (b) {
      try {
        return await b.list();
      } catch {
        return [];
      }
    }
    return readLocal().sort((a, b) => b.lastUsedAt.localeCompare(a.lastUsedAt));
  },

  async password(username: string): Promise<string | null> {
    try {
      return (await bridge()?.password(username)) ?? null;
    } catch {
      return null;
    }
  },

  async save(login: { username: string; name: string; password?: string }) {
    const b = bridge();
    if (b) {
      await b.save(login).catch(() => false);
      return;
    }
    const username = login.username.trim().toLowerCase();
    writeLocal([{ username, name: login.name || username, hasPassword: false, lastUsedAt: new Date().toISOString() }, ...readLocal().filter((l) => l.username !== username)]);
  },

  async remove(username: string) {
    const b = bridge();
    if (b) {
      await b.remove(username).catch(() => false);
      return;
    }
    writeLocal(readLocal().filter((l) => l.username !== username));
  },

  /** Preferencia de la casilla "Recordar" en este equipo (por defecto sí) */
  remember(): boolean {
    try {
      return localStorage.getItem(PREF) !== '0';
    } catch {
      return true;
    }
  },
  setRemember(on: boolean) {
    try {
      localStorage.setItem(PREF, on ? '1' : '0');
    } catch {
      // sin almacenamiento local
    }
  },
};
