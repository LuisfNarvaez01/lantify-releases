// ============================================
// SHARED - Ingresos guardados en este equipo
// ============================================
// Lantify.exe (caja): usuario y contraseña, cifrada con la cuenta de Windows por la app
//   de escritorio. La interfaz nunca la guarda en el navegador.
// Tablets y navegador: solo el usuario y su nombre. La contraseña la recuerda el gestor
//   de contraseñas del navegador (el formulario usa autocomplete="username/current-password").

import { desktop } from './desktop';

export interface SavedLogin {
  username: string;
  name: string;
  hasPassword: boolean;
  lastUsedAt: string;
}

const KEY = 'lantify.savedLogins';
const PREF = 'lantify.rememberLogin';
const MAX = 12;

const readLocal = (): SavedLogin[] => {
  try {
    const list = JSON.parse(localStorage.getItem(KEY) || '[]');
    return Array.isArray(list) ? list.filter((l) => l && typeof l.username === 'string').map((l) => ({ ...l, hasPassword: false })) : [];
  } catch {
    return [];
  }
};

const writeLocal = (list: SavedLogin[]) => {
  try {
    localStorage.setItem(KEY, JSON.stringify(list.slice(0, MAX).map(({ username, name, lastUsedAt }) => ({ username, name, lastUsedAt }))));
  } catch {
    // sin almacenamiento local
  }
};

/** En Lantify.exe la contraseña se puede guardar (cifrada); en el navegador, solo el usuario */
export const canSavePasswords = () => !!desktop()?.logins;

export const savedLogins = {
  async list(): Promise<SavedLogin[]> {
    const bridge = desktop()?.logins;
    if (bridge) {
      try {
        return await bridge.list();
      } catch {
        return [];
      }
    }
    return readLocal().sort((a, b) => b.lastUsedAt.localeCompare(a.lastUsedAt));
  },

  async password(username: string): Promise<string | null> {
    try {
      return (await desktop()?.logins?.password(username)) ?? null;
    } catch {
      return null;
    }
  },

  async save(login: { username: string; name: string; password?: string }) {
    const bridge = desktop()?.logins;
    if (bridge) {
      await bridge.save(login).catch(() => false);
      return;
    }
    const username = login.username.trim().toLowerCase();
    writeLocal([{ username, name: login.name || username, hasPassword: false, lastUsedAt: new Date().toISOString() }, ...readLocal().filter((l) => l.username !== username)]);
  },

  async remove(username: string) {
    const bridge = desktop()?.logins;
    if (bridge) {
      await bridge.remove(username).catch(() => false);
      return;
    }
    writeLocal(readLocal().filter((l) => l.username !== username));
  },

  /** Preferencia de la casilla "Recordar" en este equipo (por defecto sí) */
  remember(): boolean {
    try {
      return localStorage.getItem(PREF) !== '0';
    } catch {
      return true;
    }
  },
  setRemember(on: boolean) {
    try {
      localStorage.setItem(PREF, on ? '1' : '0');
    } catch {
      // sin almacenamiento local
    }
  },
};
