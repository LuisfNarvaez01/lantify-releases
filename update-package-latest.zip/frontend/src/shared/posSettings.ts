
import { t } from '../i18n';// ============================================
// POS SETTINGS - Modo de visualización de mesas
// ============================================
// Ambas vistas comparten el mismo store (usePosStore): mesas, carritos y pedidos.
// Cambiar de vista NO afecta los datos.

export type TableViewMode = 'operational' | 'floorplan';

export const TABLE_VIEW_MODES: { id: TableViewMode; label: string; description: string }[] = [
  {
    id: 'operational',
    get label() { return t('common:vista_operativa'); },
    get description() { return t('common:mesas_en_lista_lateral_junto_al_catalogo'); },
  },
  {
    id: 'floorplan',
    get label() { return t('common:plano_del_establecimiento'); },
    get description() { return t('common:mapa_visual_con_la_distribucion_fisica_de'); },
  },
];

export const DEFAULT_TABLE_VIEW_MODE: TableViewMode = 'operational';

export function getTableViewMode(): TableViewMode {
  try {
    const saved = localStorage.getItem('posConfig');
    if (saved) {
      const mode = JSON.parse(saved).tableViewMode;
      if (mode === 'operational' || mode === 'floorplan') return mode;
    }
  } catch {
    // ignorar configuración corrupta
  }
  return DEFAULT_TABLE_VIEW_MODE;
}

export function saveTableViewMode(mode: TableViewMode): void {
  try {
    const saved = localStorage.getItem('posConfig');
    const config = saved ? JSON.parse(saved) : {};
    config.tableViewMode = mode;
    localStorage.setItem('posConfig', JSON.stringify(config));
  } catch (e) {
    console.error('Error saving table view mode:', e);
  }
}
