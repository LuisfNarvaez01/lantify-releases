// ============================================
// SHARED - Configuración de impresión (fuente: servidor del negocio)
// ============================================
// La comparten la caja y las tablets. Se guarda una copia local para imprimir
// aunque el servidor tarde en responder. Antes de que el ADMIN la guarde por
// primera vez se respetan los ajustes que este equipo tenía (posConfig).

import { create } from 'zustand';
import { printingAPI } from '../services/api';
import { DEFAULT_PRINT_SETTINGS, normalizePrintSettings, PrintSettings } from '../../../src/domain/printSettings';

export type { PrintSettings, PrinterTarget } from '../../../src/domain/printSettings';
export { DEFAULT_PRINT_SETTINGS, columnsFor, dotsFor } from '../../../src/domain/printSettings';

const CACHE_KEY = 'lantify.printSettings';

/** Ajustes que versiones anteriores guardaban solo en este navegador */
const legacy = (): Partial<PrintSettings> => {
  try {
    const c = JSON.parse(localStorage.getItem('posConfig') || '{}');
    return {
      ...(c.paperWidth ? { paperWidth: c.paperWidth } : {}),
      ...(c.receiptMargin ? { margin: c.receiptMargin } : {}),
      ...(c.fontSizeTicket ? { fontSize: c.fontSizeTicket } : {}),
      ...(c.receiptFont ? { font: c.receiptFont } : {}),
      ...(c.ticketLanguage ? { language: c.ticketLanguage } : {}),
      ...(c.ticketFooterText ? { footer: c.ticketFooterText } : {}),
    };
  } catch {
    return {};
  }
};

const cached = (): PrintSettings => {
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    if (raw) return normalizePrintSettings(JSON.parse(raw));
  } catch {
    // sin almacenamiento local
  }
  return normalizePrintSettings({ ...DEFAULT_PRINT_SETTINGS, ...legacy() });
};

interface PrintState {
  settings: PrintSettings;
  loaded: boolean;
  load: () => Promise<PrintSettings>;
  setSettings: (s: PrintSettings) => void;
}

export const usePrintSettings = create<PrintState>((set, get) => ({
  settings: cached(),
  loaded: false,
  load: async () => {
    try {
      const { configured, ...raw } = (await printingAPI.getSettings()) as PrintSettings & { configured?: boolean };
      const settings = normalizePrintSettings(configured === false ? { ...raw, ...legacy(), footer: raw.footer || legacy().footer } : raw);
      get().setSettings(settings);
      return settings;
    } catch {
      set({ loaded: true });
      return get().settings;
    }
  },
  setSettings: (settings) => {
    try {
      localStorage.setItem(CACHE_KEY, JSON.stringify(settings));
    } catch {
      // sin almacenamiento local: queda en memoria
    }
    set({ settings, loaded: true });
  },
}));

/** Para imprimir fuera de React: la última configuración conocida (y la pide si aún no llegó) */
export const currentPrintSettings = async (): Promise<PrintSettings> => {
  const st = usePrintSettings.getState();
  if (st.loaded) return st.settings;
  return st.load();
};
