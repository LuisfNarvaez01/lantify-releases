// ============================================
// SHARED - Pantalla del cliente de esta caja (Fase 4 · 10)
// ============================================
// Cada equipo de caja recuerda a qué pantalla del cliente manda su carrito. Si el
// negocio tiene una sola pantalla del cliente, se usa sola sin configurar nada.

const KEY = 'lantify.customerDisplay';
export const CUSTOMER_DISPLAY_CHANGED = 'lantify:customer-display';

export const getCustomerDisplayId = (): string | null => {
  try { return localStorage.getItem(KEY); } catch { return null; }
};

export const setCustomerDisplayId = (id: string | null) => {
  try {
    if (id) localStorage.setItem(KEY, id);
    else localStorage.removeItem(KEY);
  } catch { /* sin almacenamiento */ }
  window.dispatchEvent(new Event(CUSTOMER_DISPLAY_CHANGED));
};
