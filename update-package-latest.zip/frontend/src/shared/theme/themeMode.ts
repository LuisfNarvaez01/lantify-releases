// ============================================
// THEME - Modo claro / oscuro / automático (por usuario)
// ============================================

import { useEffect, useState } from 'react';

export type ThemeMode = 'light' | 'dark' | 'system';
export type ResolvedTheme = 'light' | 'dark';

export const THEME_MODE_EVENT = 'lantify:theme-mode-changed';

// Último modo usado en este equipo: lo lee index.html antes de pintar (sin parpadeo)
const LAST_KEY = 'lantify.themeMode.last';
const userKey = (userId?: string | null) => (userId ? `lantify.themeMode.${userId}` : LAST_KEY);

let currentUserId: string | null = null;

const read = (key: string): ThemeMode | null => {
  try {
    const v = localStorage.getItem(key);
    return v === 'light' || v === 'dark' || v === 'system' ? v : null;
  } catch {
    return null;
  }
};

const systemPrefersDark = () =>
  typeof window !== 'undefined' && window.matchMedia?.('(prefers-color-scheme: dark)').matches;

export const resolveTheme = (mode: ThemeMode): ResolvedTheme =>
  mode === 'system' ? (systemPrefersDark() ? 'dark' : 'light') : mode;

export const getThemeMode = (): ThemeMode => read(userKey(currentUserId)) || read(LAST_KEY) || 'light';

export const getResolvedTheme = (): ResolvedTheme =>
  document.documentElement.dataset.theme === 'dark' ? 'dark' : 'light';

const applyResolved = (mode: ThemeMode) => {
  const resolved = resolveTheme(mode);
  const root = document.documentElement;
  if (root.dataset.theme !== resolved) {
    root.dataset.theme = resolved;
  }
  window.dispatchEvent(new CustomEvent(THEME_MODE_EVENT, { detail: { mode, resolved } }));
};

export const setThemeMode = (mode: ThemeMode) => {
  try {
    localStorage.setItem(userKey(currentUserId), mode);
    localStorage.setItem(LAST_KEY, mode);
  } catch {
    // sin almacenamiento: se aplica solo en esta sesión
  }
  applyResolved(mode);
};

/** Al iniciar o cerrar sesión: cada usuario conserva su propio modo */
export const bindThemeToUser = (userId: string | null) => {
  currentUserId = userId;
  applyResolved(getThemeMode());
};

let systemListenerInstalled = false;

export const initThemeMode = () => {
  applyResolved(getThemeMode());
  if (!systemListenerInstalled && window.matchMedia) {
    systemListenerInstalled = true;
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
      if (getThemeMode() === 'system') applyResolved('system');
    });
  }
};

/** Hook: modo elegido, tema efectivo y función para cambiarlo */
export const useThemeMode = () => {
  const [mode, setMode] = useState<ThemeMode>(getThemeMode);
  const [resolved, setResolved] = useState<ResolvedTheme>(() => resolveTheme(getThemeMode()));

  useEffect(() => {
    const onChange = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      setMode(detail.mode);
      setResolved(detail.resolved);
    };
    window.addEventListener(THEME_MODE_EVENT, onChange);
    return () => window.removeEventListener(THEME_MODE_EVENT, onChange);
  }, []);

  return { mode, resolved, setMode: setThemeMode };
};
