// ============================================
// THEME - Onda al cambiar entre claro y oscuro
// ============================================
// El tema nuevo se abre en círculo desde donde se tocó (View Transitions de Chromium,
// que también trae la app de escritorio) y un anillo suave sale del mismo punto.
// Sin soporte, con "reducir movimiento" o con la pestaña oculta, cambia al instante.
// La misma pieza vive en web/src/lib/themeWave.ts: si cambias una, cambia la otra.
// Las reglas ::view-transition (html.lf-wave) están en index.css de cada app.

type Point = { x: number; y: number };

let last: Point | null = null;
let installed = false;

/** Recuerda dónde se tocó por última vez: de ahí sale la onda */
const install = () => {
  if (installed || typeof window === 'undefined') return;
  installed = true;
  window.addEventListener('pointerdown', (e) => { last = { x: e.clientX, y: e.clientY }; }, { capture: true, passive: true });
  window.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter' && e.key !== ' ') return;
    const el = document.activeElement as HTMLElement | null;
    const r = el?.getBoundingClientRect();
    if (r && r.width) last = { x: r.left + r.width / 2, y: r.top + r.height / 2 };
  }, { capture: true, passive: true });
};
install();

const reducedMotion = () => window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

/** Anillo que se expande desde el punto (decorativo, no bloquea toques) */
const ring = ({ x, y }: Point, dark: boolean) => {
  const el = document.createElement('div');
  el.setAttribute('aria-hidden', 'true');
  Object.assign(el.style, {
    position: 'fixed', left: `${x}px`, top: `${y}px`, width: '24px', height: '24px', margin: '-12px 0 0 -12px',
    borderRadius: '9999px', pointerEvents: 'none', zIndex: '2147483647',
    border: `2px solid ${dark ? 'rgba(147,177,255,.75)' : 'rgba(37,99,235,.55)'}`,
    boxShadow: dark ? '0 0 24px rgba(96,140,255,.35)' : '0 0 24px rgba(37,99,235,.25)',
  } as CSSStyleDeclaration);
  document.body.appendChild(el);
  const a = el.animate(
    [{ transform: 'scale(1)', opacity: 0.9 }, { transform: 'scale(14)', opacity: 0 }],
    { duration: 700, easing: 'cubic-bezier(.2,.7,.2,1)' },
  );
  a.onfinish = () => el.remove();
  a.oncancel = () => el.remove();
};

/**
 * Cambia el tema con la onda. `change` debe dejar el DOM con el tema nuevo antes de
 * volver (por ejemplo con flushSync si depende de un estado de React).
 */
export const withThemeWave = (change: () => void, nextIsDark?: boolean) => {
  const doc = document as Document & { startViewTransition?: (cb: () => void) => { ready: Promise<void>; finished: Promise<void> } };
  const origin = last || { x: window.innerWidth - 48, y: 48 };
  last = null;
  if (!doc.startViewTransition || reducedMotion() || document.visibilityState !== 'visible') {
    change();
    return;
  }
  const root = document.documentElement;
  const radius = Math.hypot(Math.max(origin.x, window.innerWidth - origin.x), Math.max(origin.y, window.innerHeight - origin.y));
  root.classList.add('lf-wave');
  let vt: { ready: Promise<void>; finished: Promise<void> };
  try {
    vt = doc.startViewTransition(change);
  } catch {
    root.classList.remove('lf-wave');
    change();
    return;
  }
  vt.ready.then(() => {
    root.animate(
      { clipPath: [`circle(0px at ${origin.x}px ${origin.y}px)`, `circle(${radius}px at ${origin.x}px ${origin.y}px)`] },
      { duration: 620, easing: 'cubic-bezier(.22,.8,.24,1)', pseudoElement: '::view-transition-new(root)' },
    );
    ring(origin, nextIsDark ?? root.dataset.theme === 'dark');
  }).catch(() => undefined);
  vt.finished.finally(() => root.classList.remove('lf-wave'));
};
