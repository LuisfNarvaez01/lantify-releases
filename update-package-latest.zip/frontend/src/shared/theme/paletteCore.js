// ============================================
// THEME - Núcleo de paleta (compartido por tailwind.config.js y el navegador)
// ============================================
// Cada clase de color de Tailwind (bg-white, text-slate-900, bg-blue-600...) apunta
// a una variable CSS. Fondo (bg), texto (tx) y borde (bd) tienen variables separadas
// para que, en tema oscuro, un text-blue-700 se aclare sin aclarar el hover bg-blue-700.
// La familia "blue" es el color principal del negocio (preset de Apariencia).

export const SHADES = [50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 950];
export const KINDS = ['bg', 'tx', 'bd'];
export const NEUTRALS = ['slate', 'gray', 'zinc', 'neutral', 'stone'];
export const STATUS = ['red', 'orange', 'amber', 'yellow', 'lime', 'green', 'emerald', 'teal', 'cyan', 'sky', 'indigo', 'violet', 'purple', 'fuchsia', 'pink', 'rose'];
export const PRIMARY_FAMILY = 'blue';

// Neutro cálido (diseño corporativo 2026-11): reemplaza a slate/gray/zinc/neutral/stone
// para que todo el sistema comparta un solo gris, sin el tinte azul de slate.
// 100 = lienzo de la aplicación (#efefed); el texto principal es casi negro.
export const WARM_NEUTRAL = {
  50: '#f7f7f5',
  100: '#efefed',
  200: '#e3e3e0',
  300: '#cfcfcb',
  400: '#a2a29d',
  500: '#74746f',
  600: '#575753',
  700: '#3e3e3b',
  800: '#292927',
  900: '#161615',
  950: '#0c0c0b',
};

// Superficies del tema oscuro (grafito neutro, sin azul)
export const DARK = {
  canvas: '#0f0f0e',
  card: '#191918',
  fgOnCard: '#f2f2f0',
};

// Neutros en oscuro: fondos claros → superficies oscuras; textos oscuros → claros.
// Los tonos que ya son oscuros (bg 950) o claros (text 100–300) no cambian.
const DARK_NEUTRAL = {
  // 800/900: botones y chips "seleccionados" oscuros; en tema oscuro se aclaran para seguir destacando
  bg: { 50: '#141413', 100: '#222220', 200: '#2c2c2a', 300: '#3a3a37', 400: '#52524e', 800: '#4a4a46', 900: '#3a3a37' },
  tx: { 400: '#8a8a85', 500: '#a3a39e', 600: '#bdbdb8', 700: '#d2d2ce', 800: '#e6e6e3', 900: '#f2f2f0', 950: '#fafaf9' },
  bd: { 50: '#1c1c1b', 100: '#242422', 200: '#2e2e2c', 300: '#3c3c39', 400: '#52524e' },
};

export const hexToRgb = (hex) => {
  const clean = hex.replace('#', '');
  const full = clean.length === 3 ? clean.split('').map(c => c + c).join('') : clean;
  const n = parseInt(full, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
};

export const rgbToHex = (rgb) => '#' + rgb.map(v => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('');

/** Mezcla: t = peso del segundo color (0 = a, 1 = b) */
export const mix = (a, b, t) => {
  const ra = hexToRgb(a);
  const rb = hexToRgb(b);
  return rgbToHex(ra.map((v, i) => v * (1 - t) + rb[i] * t));
};

export const triplet = (hex) => hexToRgb(hex).join(' ');

/** Ajuste de un color de estado (verde, rojo, ámbar...) para tema oscuro */
const darkStatus = (scale, kind, shade) => {
  const base = scale[500];
  if (kind === 'bg') {
    const t = { 50: 0.14, 100: 0.2, 200: 0.3, 300: 0.42 }[shade];
    return t ? mix(DARK.card, base, t) : null;
  }
  if (kind === 'tx') {
    return { 600: scale[400], 700: scale[300], 800: scale[200], 900: scale[100], 950: scale[50] }[shade] || null;
  }
  if (kind === 'bd') {
    const t = { 50: 0.12, 100: 0.2, 200: 0.32, 300: 0.45 }[shade];
    return t ? mix(DARK.card, base, t) : null;
  }
  return null;
};

/** Variables CSS de una familia para un modo ('light' | 'dark') */
export const familyVars = (name, scale, mode, isNeutral = false) => {
  const vars = {};
  for (const shade of SHADES) {
    for (const kind of KINDS) {
      let hex = scale[shade];
      if (mode === 'dark') {
        const adjusted = isNeutral ? DARK_NEUTRAL[kind][shade] : darkStatus(scale, kind, shade);
        if (adjusted) hex = adjusted;
      }
      vars[`--${name}-${shade}-${kind}`] = triplet(hex);
    }
  }
  return vars;
};

export const whiteBlackVars = (mode) => ({
  '--white-bg': triplet(mode === 'dark' ? DARK.card : '#ffffff'),
  '--white-tx': triplet('#ffffff'),
  '--white-bd': triplet('#ffffff'),
  '--black-bg': triplet('#000000'),
  '--black-tx': triplet(mode === 'dark' ? '#f8fafc' : '#000000'),
  '--black-bd': triplet('#000000'),
});

/** Escala completa (50–950) derivada del color principal del preset */
export const primaryScale = (primary, hover, light) => {
  const h = hover || mix(primary, '#000000', 0.15);
  return {
    50: light || mix(primary, '#ffffff', 0.93),
    100: mix(primary, '#ffffff', 0.85),
    200: mix(primary, '#ffffff', 0.72),
    300: mix(primary, '#ffffff', 0.55),
    400: mix(primary, '#ffffff', 0.35),
    500: mix(primary, '#ffffff', 0.15),
    600: primary,
    700: h,
    800: mix(h, '#000000', 0.15),
    900: mix(h, '#000000', 0.3),
    950: mix(h, '#000000', 0.5),
  };
};

/** Variables semánticas (para código nuevo: bg-surface, text-fg, border-line...) */
export const semanticVars = (mode) => {
  const dark = mode === 'dark';
  return {
    '--canvas': triplet(dark ? DARK.canvas : WARM_NEUTRAL[100]),
    '--focus-ring': dark ? '0 0 0 3px rgb(var(--blue-400-bg) / 0.55)' : '0 0 0 3px rgb(var(--blue-500-bg) / 0.4)',
    '--scrollbar-track': triplet(dark ? '#1c1c1b' : WARM_NEUTRAL[100]),
    '--scrollbar-thumb': triplet(dark ? '#3c3c39' : WARM_NEUTRAL[300]),
    // Elevación (lenguaje Corbel): anillo fino + sombra larga y difusa, nunca sombras grises duras
    '--shadow-card': dark
      ? '0 0 0 1px rgb(255 255 255 / 0.06), 0 1px 2px rgb(0 0 0 / 0.4)'
      : '0 0 0 1px rgb(17 17 17 / 0.05), 0 1px 2px rgb(17 17 17 / 0.04)',
    '--shadow-raised': dark
      ? '0 0 0 1px rgb(255 255 255 / 0.07), 0 22px 44px -24px rgb(0 0 0 / 0.7)'
      : '0 0 0 1px rgb(17 17 17 / 0.05), 0 22px 44px -28px rgb(17 17 17 / 0.28)',
    '--shadow-overlay': dark
      ? '0 0 0 1px rgb(255 255 255 / 0.08), 0 24px 60px -18px rgb(0 0 0 / 0.75)'
      : '0 0 0 1px rgb(17 17 17 / 0.06), 0 24px 60px -18px rgb(17 17 17 / 0.32)',
  };
};
