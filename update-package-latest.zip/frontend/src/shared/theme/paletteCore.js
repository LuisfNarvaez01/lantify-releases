// ============================================
// THEME - Núcleo de paleta (compartido por tailwind.config.js y el navegador)
// ============================================
// Cada clase de color de Tailwind (bg-white, text-slate-900, bg-blue-600...) apunta
// a una variable CSS. Fondo (bg), texto (tx) y borde (bd) tienen variables separadas
// para que, en tema oscuro, un text-blue-700 se aclare sin aclarar el hover bg-blue-700.
// La familia "blue" es el color principal del negocio (preset de Apariencia).

export const SHADES = [50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 950];
export const KINDS = ['bg', 'tx', 'bd'];
export const NEUTRALS = ['slate', 'gray', 'zinc', 'neutral', 'stone'];
export const STATUS = ['red', 'orange', 'amber', 'yellow', 'lime', 'green', 'emerald', 'teal', 'cyan', 'sky', 'indigo', 'violet', 'purple', 'fuchsia', 'pink', 'rose'];
export const PRIMARY_FAMILY = 'blue';

// Superficies del tema oscuro
export const DARK = {
  canvas: '#0b1220',
  card: '#141d2f',
  fgOnCard: '#f1f5f9',
};

// Neutros en oscuro: fondos claros → superficies oscuras; textos oscuros → claros.
// Los tonos que ya son oscuros (bg 950) o claros (text 100–300) no cambian.
const DARK_NEUTRAL = {
  // 800/900: botones y chips "seleccionados" oscuros; en tema oscuro se aclaran para seguir destacando
  bg: { 50: '#0f1729', 100: '#1c2638', 200: '#263247', 300: '#334155', 400: '#475569', 800: '#3d4d68', 900: '#2f3d55' },
  tx: { 400: '#7d8ba1', 500: '#9aa8bb', 600: '#b6c2d2', 700: '#cbd5e1', 800: '#e2e8f0', 900: '#f1f5f9', 950: '#f8fafc' },
  bd: { 50: '#172033', 100: '#1c2638', 200: '#263247', 300: '#334155', 400: '#475569' },
};

export const hexToRgb = (hex) => {
  const clean = hex.replace('#', '');
  const full = clean.length === 3 ? clean.split('').map(c => c + c).join('') : clean;
  const n = parseInt(full, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
};

export const rgbToHex = (rgb) => '#' + rgb.map(v => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('');

/** Mezcla: t = peso del segundo color (0 = a, 1 = b) */
export const mix = (a, b, t) => {
  const ra = hexToRgb(a);
  const rb = hexToRgb(b);
  return rgbToHex(ra.map((v, i) => v * (1 - t) + rb[i] * t));
};

export const triplet = (hex) => hexToRgb(hex).join(' ');

/** Ajuste de un color de estado (verde, rojo, ámbar...) para tema oscuro */
const darkStatus = (scale, kind, shade) => {
  const base = scale[500];
  if (kind === 'bg') {
    const t = { 50: 0.14, 100: 0.2, 200: 0.3, 300: 0.42 }[shade];
    return t ? mix(DARK.card, base, t) : null;
  }
  if (kind === 'tx') {
    return { 600: scale[400], 700: scale[300], 800: scale[200], 900: scale[100], 950: scale[50] }[shade] || null;
  }
  if (kind === 'bd') {
    const t = { 50: 0.12, 100: 0.2, 200: 0.32, 300: 0.45 }[shade];
    return t ? mix(DARK.card, base, t) : null;
  }
  return null;
};

/** Variables CSS de una familia para un modo ('light' | 'dark') */
export const familyVars = (name, scale, mode, isNeutral = false) => {
  const vars = {};
  for (const shade of SHADES) {
    for (const kind of KINDS) {
      let hex = scale[shade];
      if (mode === 'dark') {
        const adjusted = isNeutral ? DARK_NEUTRAL[kind][shade] : darkStatus(scale, kind, shade);
        if (adjusted) hex = adjusted;
      }
      vars[`--${name}-${shade}-${kind}`] = triplet(hex);
    }
  }
  return vars;
};

export const whiteBlackVars = (mode) => ({
  '--white-bg': triplet(mode === 'dark' ? DARK.card : '#ffffff'),
  '--white-tx': triplet('#ffffff'),
  '--white-bd': triplet('#ffffff'),
  '--black-bg': triplet('#000000'),
  '--black-tx': triplet(mode === 'dark' ? '#f8fafc' : '#000000'),
  '--black-bd': triplet('#000000'),
});

/** Escala completa (50–950) derivada del color principal del preset */
export const primaryScale = (primary, hover, light) => {
  const h = hover || mix(primary, '#000000', 0.15);
  return {
    50: light || mix(primary, '#ffffff', 0.93),
    100: mix(primary, '#ffffff', 0.85),
    200: mix(primary, '#ffffff', 0.72),
    300: mix(primary, '#ffffff', 0.55),
    400: mix(primary, '#ffffff', 0.35),
    500: mix(primary, '#ffffff', 0.15),
    600: primary,
    700: h,
    800: mix(h, '#000000', 0.15),
    900: mix(h, '#000000', 0.3),
    950: mix(h, '#000000', 0.5),
  };
};

/** Variables semánticas (para código nuevo: bg-surface, text-fg, border-line...) */
export const semanticVars = (mode) => {
  const dark = mode === 'dark';
  return {
    '--canvas': triplet(dark ? DARK.canvas : '#f8fafc'),
    '--focus-ring': dark ? '0 0 0 3px rgb(var(--blue-400-bg) / 0.55)' : '0 0 0 3px rgb(var(--blue-500-bg) / 0.45)',
    '--scrollbar-track': triplet(dark ? '#172033' : '#f1f5f9'),
    '--scrollbar-thumb': triplet(dark ? '#334155' : '#cbd5e1'),
  };
};
