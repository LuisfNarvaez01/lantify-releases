// ============================================
// SHARED - Happy hour en la caja y el celular (Fase 4 · 7)
// ============================================
// Las reglas vienen del servidor (GET /price-rules/active) y se refrescan cada
// minuto. El carrito usa priceNow() al agregar un producto; el servidor revisa
// el precio al cobrar, así que esto solo decide qué se muestra.

import { create } from 'zustand';
import { priceRulesAPI } from '../services/v3Api';
import { priceFor, type PriceRule } from '../../../src/domain/priceRules';

const REFRESH_MS = 60_000;

interface PriceRulesState {
  rules: PriceRule[];
  loadedAt: number;
  load: (force?: boolean) => Promise<void>;
}

export const usePriceRules = create<PriceRulesState>((set, get) => ({
  rules: [],
  loadedAt: 0,
  load: async (force = false) => {
    if (!force && Date.now() - get().loadedAt < REFRESH_MS) return;
    set({ loadedAt: Date.now() });
    try {
      const res = await priceRulesAPI.active();
      set({ rules: res.enabled ? res.rules : [] });
    } catch {
      // sin conexión o sin permiso: se venden con el precio de la carta
    }
  },
}));

/** Precio de la variante ahora mismo (y la regla que lo da, si hay) */
export const priceNow = (variant: { id: string; price: number }, categoryId: string | null | undefined, now = new Date()) => {
  const { rules, load } = usePriceRules.getState();
  load(); // refresca en segundo plano si ya pasó el minuto
  return priceFor(variant, categoryId, now, rules);
};
