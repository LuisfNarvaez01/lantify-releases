// ============================================
// ASISTENCIA - "Marcar asistencia" en la caja (Fase 4 · 13)
// ============================================
// Quien no tiene usuario (cocina, oficios) marca su entrada o salida con su PIN
// en el equipo de la caja. Solo aparece con la función encendida.

import { useCallback, useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { Fingerprint, X } from 'lucide-react';
import { t } from '../../i18n';
import { useFeatureFlag } from '../../shared/features';
import { attendanceAPI, type RosterEntry } from '../../services/v3Api';
import { errorMessage } from '../../services/apiErrors';
import { AttendancePunch } from './AttendancePunch';

const OPEN_EVENT = 'lantify:attendance-open';

/** Opción del menú de usuario: abre la ventana (que vive fuera del menú) */
export function AttendanceButton({ role, onOpen }: { role: string; onOpen?: () => void }) {
  const on = useFeatureFlag('attendance');
  if (!on || !['ADMIN', 'CASHIER'].includes(role)) return null;
  return (
    <button
      type="button"
      onClick={() => { onOpen?.(); window.dispatchEvent(new Event(OPEN_EVENT)); }}
      className="flex h-10 w-full items-center gap-2.5 rounded-[10px] px-3 text-left text-[0.8125rem] font-medium text-white/80 transition-colors duration-fast hover:bg-white/10 hover:text-white"
    >
      <Fingerprint className="h-4 w-4 text-white/60" aria-hidden />
      <span>{t('v3:asis_titulo')}</span>
    </button>
  );
}

/** La ventana de marcar con PIN; va montada siempre en el encabezado */
export function AttendanceHost() {
  const on = useFeatureFlag('attendance');
  const [open, setOpen] = useState(false);
  const [roster, setRoster] = useState<RosterEntry[]>([]);
  useEffect(() => {
    const show = () => setOpen(true);
    window.addEventListener(OPEN_EVENT, show);
    return () => window.removeEventListener(OPEN_EVENT, show);
  }, []);

  const load = useCallback(() => { attendanceAPI.roster().then(setRoster).catch(() => setRoster([])); }, []);
  useEffect(() => { if (open) load(); }, [open, load]);
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open]);

  if (!on || !open) return null;
  return (
    <>
      {createPortal(
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/70 p-4" role="dialog" aria-modal="true" aria-label={t('v3:asis_titulo')}>
          <div className="relative flex h-[min(46rem,92dvh)] w-full max-w-3xl flex-col overflow-hidden rounded-3xl bg-slate-950 text-white shadow-2xl">
            <header className="flex items-center justify-between border-b border-slate-800 px-5 py-3">
              <h2 className="text-xl font-black">{t('v3:asis_titulo')}</h2>
              <button type="button" onClick={() => setOpen(false)} className="rounded-xl p-2 text-slate-300 hover:bg-slate-800" aria-label={t('v3:cerrar')}><X className="h-6 w-6" /></button>
            </header>
            <AttendancePunch roster={roster} punch={attendanceAPI.punch} onDone={load} errorText={errorMessage} />
          </div>
        </div>,
        document.body,
      )}
    </>
  );
}
