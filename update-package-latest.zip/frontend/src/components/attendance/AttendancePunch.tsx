// ============================================
// ASISTENCIA - Marcar entrada y salida con PIN (Fase 4 · 13)
// ============================================
// Lo usan la pantalla de asistencia (/pantalla, sin usuario) y la caja. El empleado
// toca su nombre y escribe su PIN en el teclado de la pantalla: si no tiene turno
// abierto marca la entrada; si lo tiene, la salida.

import { useCallback, useEffect, useState } from 'react';
import { ArrowLeft, Delete, LogIn, LogOut, UserRound } from 'lucide-react';
import { t } from '../../i18n';

export interface PunchPerson { id: string; name: string; onShift: boolean }
export interface PunchOutcome { action: 'IN' | 'OUT'; name: string; at: string; startAt: string }

interface Props {
  roster: PunchPerson[];
  punch: (employeeId: string, pin: string) => Promise<PunchOutcome>;
  /** Después de marcar (para refrescar quién está en turno) */
  onDone?: () => void;
  /** Mensaje de error legible de lo que falló */
  errorText?: (err: unknown) => string;
}

const hhmm = (iso: string) => new Date(iso).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
const worked = (from: string, to: string) => {
  const min = Math.max(0, Math.round((+new Date(to) - +new Date(from)) / 60_000));
  return t('v3:asis_trabajaste', { h: Math.floor(min / 60), m: min % 60 });
};

const KEYS = ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'del', '0', 'ok'] as const;

export function AttendancePunch({ roster, punch, onDone, errorText }: Props) {
  const [who, setWho] = useState<PunchPerson | null>(null);
  const [pin, setPin] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState<PunchOutcome | null>(null);

  const reset = useCallback(() => { setWho(null); setPin(''); setError(''); setDone(null); }, []);

  // El resultado se muestra unos segundos y vuelve a la lista
  useEffect(() => {
    if (!done) return;
    const id = setTimeout(reset, 4500);
    return () => clearTimeout(id);
  }, [done, reset]);

  // Sin tocar nada por un rato, vuelve a la lista (nadie deja su nombre abierto)
  useEffect(() => {
    if (!who || done) return;
    const id = setTimeout(reset, 30_000);
    return () => clearTimeout(id);
  }, [who, pin, done, reset]);

  const submit = useCallback(async (value: string) => {
    if (!who || value.length < 4 || busy) return;
    setBusy(true);
    setError('');
    try {
      const out = await punch(who.id, value);
      setDone(out);
      onDone?.();
    } catch (err) {
      setPin('');
      setError(errorText ? errorText(err) : (err as Error)?.message || t('v3:pantalla_error'));
    } finally {
      setBusy(false);
    }
  }, [who, busy, punch, onDone, errorText]);

  const press = useCallback((k: (typeof KEYS)[number]) => {
    if (k === 'del') { setPin((p) => p.slice(0, -1)); return; }
    if (k === 'ok') { submit(pin); return; }
    setError('');
    setPin((p) => (p.length >= 6 ? p : p + k));
  }, [pin, submit]);

  // Teclado físico también sirve (tablet con teclado o la caja)
  useEffect(() => {
    if (!who || done) return;
    const onKey = (e: KeyboardEvent) => {
      if (/^\d$/.test(e.key)) press(e.key as (typeof KEYS)[number]);
      else if (e.key === 'Backspace') press('del');
      else if (e.key === 'Enter') press('ok');
      else if (e.key === 'Escape') reset();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [who, done, press, reset]);

  if (done) {
    const isIn = done.action === 'IN';
    return (
      <div className="flex flex-1 flex-col items-center justify-center p-8 text-center" role="status">
        <span className={`grid h-24 w-24 place-items-center rounded-full ${isIn ? 'bg-emerald-500' : 'bg-blue-600'} text-white`}>
          {isIn ? <LogIn className="h-12 w-12" aria-hidden /> : <LogOut className="h-12 w-12" aria-hidden />}
        </span>
        <p className="mt-6 text-4xl font-black">{isIn ? t('v3:asis_hola', { name: done.name.split(' ')[0] }) : t('v3:asis_chao', { name: done.name.split(' ')[0] })}</p>
        <p className="mt-3 text-2xl font-bold text-slate-300">{isIn ? t('v3:asis_entrada_a', { hora: hhmm(done.at) }) : t('v3:asis_salida_a', { hora: hhmm(done.at) })}</p>
        {!isIn && <p className="mt-2 text-lg text-slate-400">{worked(done.startAt, done.at)}</p>}
      </div>
    );
  }

  if (!who) {
    return (
      <div className="flex flex-1 min-h-0 flex-col p-6">
        <h2 className="text-3xl font-black">{t('v3:asis_quien_eres')}</h2>
        <p className="mt-1 text-lg text-slate-400">{t('v3:asis_quien_desc')}</p>
        {roster.length === 0 ? (
          <p className="m-auto max-w-md text-center text-xl text-slate-400">{t('v3:asis_sin_pin')}</p>
        ) : (
          <ul className="mt-6 grid content-start gap-3 overflow-y-auto" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(12rem, 1fr))' }}>
            {roster.map((p) => (
              <li key={p.id}>
                <button type="button" onClick={() => { setWho(p); setPin(''); setError(''); }} className="flex w-full min-h-[88px] items-center gap-3 rounded-2xl bg-slate-800 px-4 text-left hover:bg-slate-700 focus:outline-none focus:ring-4 focus:ring-blue-500">
                  <UserRound className="h-8 w-8 shrink-0 text-slate-400" aria-hidden />
                  <span className="min-w-0">
                    <span className="block truncate text-xl font-black text-white">{p.name}</span>
                    <span className={`text-sm font-bold ${p.onShift ? 'text-emerald-400' : 'text-slate-400'}`}>{p.onShift ? t('v3:asis_en_turno') : t('v3:asis_fuera')}</span>
                  </span>
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    );
  }

  return (
    <div className="flex flex-1 flex-col items-center justify-center p-6">
      <div className="w-full max-w-sm">
        <button type="button" onClick={reset} className="inline-flex min-h-[48px] items-center gap-2 rounded-xl px-3 text-lg font-bold text-slate-300 hover:bg-slate-800">
          <ArrowLeft className="h-5 w-5" aria-hidden />{t('v3:asis_no_soy')}
        </button>
        <p className="mt-4 text-center text-3xl font-black">{who.name}</p>
        <p className="mt-1 text-center text-lg text-slate-400">{who.onShift ? t('v3:asis_pin_salida') : t('v3:asis_pin_entrada')}</p>
        <div className="mt-6 flex justify-center gap-3" aria-label={t('v3:asis_pin')} aria-live="polite">
          {Array.from({ length: Math.max(4, pin.length) }).map((_, i) => (
            <span key={i} className={`h-5 w-5 rounded-full ${i < pin.length ? 'bg-white' : 'bg-slate-700'}`} />
          ))}
        </div>
        <p role="alert" className="mt-3 min-h-[1.75rem] text-center text-lg font-bold text-rose-300">{error}</p>
        <div className="mt-2 grid grid-cols-3 gap-3">
          {KEYS.map((k) => (
            <button
              key={k}
              type="button"
              disabled={busy || (k === 'ok' && pin.length < 4)}
              onClick={() => press(k)}
              aria-label={k === 'del' ? t('v3:asis_borrar') : k === 'ok' ? t('v3:asis_marcar') : k}
              className={`min-h-[76px] rounded-2xl text-3xl font-black disabled:opacity-40 focus:outline-none focus:ring-4 focus:ring-blue-500 ${k === 'ok' ? 'bg-blue-600 text-white text-xl hover:bg-blue-500' : 'bg-slate-800 text-white hover:bg-slate-700'}`}
            >
              {k === 'del' ? <Delete className="mx-auto h-8 w-8" aria-hidden /> : k === 'ok' ? t('v3:asis_marcar') : k}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
