// ============================================
// CHARTS - Kit de gráficas del tablero (SVG/CSS + motion, sin librerías)
// ============================================
// Color 60·30·10:
//   60 % neutro → lienzo y tarjetas blancas (lo pone el contenedor)
//   30 % grafito → barras, líneas secundarias, celdas, texto
//   10 % acento (azul del negocio) → SOLO el dato que importa: el período actual,
//        el mes en curso, el producto #1, la hora pico.
// Las animaciones crecen desde cero al montar y al cambiar de período, con la
// curva del sistema (shared/motion). Con movimiento reducido aparecen sin animar.

import React, { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { EASE_OUT } from '../../shared/motion';

// ── Utilidades ───────────────────────────────────────────────

/** Ancho del contenedor (las gráficas SVG se dibujan a su tamaño real) */
export function useWidth<T extends HTMLElement>() {
  const ref = useRef<T>(null);
  const [width, setWidth] = useState(0);
  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    setWidth(el.clientWidth);
    const ro = new ResizeObserver(([e]) => setWidth(Math.round(e.contentRect.width)));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  return [ref, width] as const;
}

/** $1,2 M · $350 mil · $9.500 */
export const fmtMoneyShort = (v: number) => {
  const a = Math.abs(v);
  if (a >= 1_000_000) return `$${(v / 1_000_000).toLocaleString('es-CO', { maximumFractionDigits: a >= 10_000_000 ? 0 : 1 })} M`;
  if (a >= 10_000) return `$${Math.round(v / 1000).toLocaleString('es-CO')} mil`;
  return `$${Math.round(v).toLocaleString('es-CO')}`;
};

/** Escala "bonita" para ejes: 0, 25k, 50k... */
const niceMax = (max: number) => {
  if (max <= 0) return 1;
  const pow = 10 ** Math.floor(Math.log10(max));
  const n = max / pow;
  const step = n <= 1 ? 1 : n <= 2 ? 2 : n <= 2.5 ? 2.5 : n <= 5 ? 5 : 10;
  return step * pow;
};

/** Tooltip negro (lenguaje Corbel): título + filas etiqueta/valor */
export function ChartTooltip({ title, rows, style, className = '' }: {
  title: React.ReactNode;
  rows: { label: React.ReactNode; value: React.ReactNode; accent?: boolean }[];
  style?: React.CSSProperties;
  className?: string;
}) {
  return (
    <div
      role="tooltip"
      style={style}
      className={`lt-pop pointer-events-none absolute z-20 min-w-[150px] rounded-xl bg-slate-950 px-3 py-2.5 text-white shadow-overlay [color-scheme:dark] ${className}`}
    >
      <p className="mb-1.5 text-xs font-semibold text-white/90">{title}</p>
      <div className="space-y-1">
        {rows.map((r, i) => (
          <div key={i} className="flex items-center justify-between gap-4 text-[0.75rem]">
            <span className="text-white/60">{r.label}</span>
            <span className={`num font-semibold ${r.accent ? 'rounded-md bg-white/10 px-1.5' : ''}`}>{r.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Sparkline ────────────────────────────────────────────────

export function Sparkline({ values, width = 96, height = 32, tone = 'dark', className = '' }: {
  values: number[]; width?: number; height?: number; tone?: 'dark' | 'light' | 'accent'; className?: string;
}) {
  const reduce = useReducedMotion();
  if (values.length < 2 || values.every((v) => v === 0)) return null;
  const max = Math.max(...values);
  const min = Math.min(...values);
  const span = max - min || 1;
  const pts = values.map((v, i) => [(i / (values.length - 1)) * width, height - 3 - ((v - min) / span) * (height - 6)]);
  const d = pts.map((p, i) => `${i ? 'L' : 'M'}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ');
  const stroke = tone === 'light' ? 'rgb(255 255 255 / 0.85)' : tone === 'accent' ? 'rgb(var(--blue-600-bg))' : 'rgb(var(--slate-900-tx))';
  const last = pts[pts.length - 1];
  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} className={className} aria-hidden>
      <motion.path
        d={d} fill="none" stroke={stroke} strokeWidth={1.75} strokeLinecap="round" strokeLinejoin="round"
        initial={reduce ? false : { pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 1, ease: EASE_OUT }}
      />
      <circle cx={last[0]} cy={last[1]} r={2.5} fill={stroke} />
    </svg>
  );
}

// ── Barras verticales (ingresos por mes / día de la semana) ────

export interface BarDatum {
  key: string;
  label: string;
  value: number;
  /** Valor de comparación (año o período anterior): marca fina sobre la barra */
  compare?: number;
  /** El dato que importa (mes en curso, día pico): va en el color de acento */
  highlight?: boolean;
  tooltip?: { title: React.ReactNode; rows: { label: React.ReactNode; value: React.ReactNode; accent?: boolean }[] };
}

export function BarChart({ data, height = 220, format = fmtMoneyShort, showAverage = true, averageLabel = 'prom.' }: {
  data: BarDatum[];
  height?: number;
  format?: (v: number) => string;
  showAverage?: boolean;
  averageLabel?: string;
}) {
  const reduce = useReducedMotion();
  const [hover, setHover] = useState<number | null>(null);
  const max = niceMax(Math.max(...data.map((d) => Math.max(d.value, d.compare || 0)), 0));
  const nonZero = data.filter((d) => d.value > 0);
  const avg = nonZero.length ? nonZero.reduce((a, d) => a + d.value, 0) / nonZero.length : 0;
  const ticks = [1, 0.75, 0.5, 0.25, 0];
  return (
    <div className="relative flex gap-3" style={{ height }}>
      {/* Eje Y */}
      <div className="flex w-12 shrink-0 flex-col justify-between pb-6 text-right text-[0.7rem] text-slate-400 num">
        {ticks.map((t) => <span key={t} className="-translate-y-1/2 leading-none first:translate-y-0 last:translate-y-0">{format(max * t)}</span>)}
      </div>
      <div className="relative flex-1">
        {/* Guías */}
        <div className="absolute inset-x-0 top-0 bottom-6 flex flex-col justify-between" aria-hidden>
          {ticks.map((t) => <div key={t} className={`border-t ${t === 0 ? 'border-slate-300' : 'border-dashed border-slate-200'}`} />)}
        </div>
        {showAverage && avg > 0 && (
          <div className="pointer-events-none absolute inset-x-0 top-0 bottom-6 z-10" aria-hidden>
            <div className="absolute inset-x-0 flex translate-y-1/2 items-center" style={{ bottom: `${(avg / max) * 100}%` }}>
              <div className="h-px flex-1 border-t border-dashed border-slate-500/60" />
              <span className="ml-1 rounded-md bg-white px-1.5 py-0.5 text-[0.68rem] font-medium text-slate-600 shadow-card num">{averageLabel} {format(avg)}</span>
            </div>
          </div>
        )}
        {/* Barras */}
        <div className="absolute inset-x-0 top-0 bottom-0 flex items-stretch gap-[3%]">
          {data.map((d, i) => {
            const h = (d.value / max) * 100;
            const active = hover === i;
            return (
              <div
                key={d.key}
                className="relative flex flex-1 flex-col items-center"
                onMouseEnter={() => setHover(i)}
                onMouseLeave={() => setHover(null)}
              >
                <div className="relative w-full max-w-[44px] flex-1">
                  {d.compare !== undefined && d.compare > 0 && (
                    <div className="absolute inset-x-1 z-[1] h-0.5 rounded-full bg-slate-400" style={{ bottom: `${(d.compare / max) * 100}%` }} aria-hidden />
                  )}
                  <motion.div
                    className={[
                      'absolute inset-x-0 bottom-0 rounded-full',
                      d.highlight ? 'bg-blue-600' : active ? 'bg-slate-900' : 'lt-hatch',
                      'transition-colors duration-fast',
                    ].join(' ')}
                    style={{ height: `${Math.max(h, d.value > 0 ? 2 : 0)}%`, transformOrigin: 'bottom' }}
                    initial={reduce ? false : { scaleY: 0 }}
                    animate={{ scaleY: 1 }}
                    transition={{ duration: 0.7, ease: EASE_OUT, delay: i * 0.035 }}
                  />
                </div>
                <span className={`mt-2 h-4 text-[0.72rem] leading-4 ${d.highlight || active ? 'font-semibold text-slate-900' : 'text-slate-500'}`}>{d.label}</span>
                {active && d.tooltip && (
                  <ChartTooltip
                    title={d.tooltip.title}
                    rows={d.tooltip.rows}
                    className={i > data.length / 2 ? 'right-full mr-2' : 'left-full ml-2'}
                    style={{ bottom: `calc(${Math.min(h, 80)}% - 1rem)` }}
                  />
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ── Línea / área (día a día contra el período anterior) ───────

export interface SeriesPoint { label: string; value: number; compare?: number; title?: string }

export function LineChart({ points, height = 220, format = fmtMoneyShort, valueLabel, compareLabel }: {
  points: SeriesPoint[];
  height?: number;
  format?: (v: number) => string;
  valueLabel: string;
  compareLabel: string;
}) {
  const reduce = useReducedMotion();
  const [ref, width] = useWidth<HTMLDivElement>();
  const [hover, setHover] = useState<number | null>(null);
  const padL = 48, padB = 24, padT = 8;
  const w = Math.max(width - padL, 10);
  const h = height - padB - padT;
  const max = niceMax(Math.max(...points.map((p) => Math.max(p.value, p.compare || 0)), 0));
  const x = (i: number) => padL + (points.length <= 1 ? w / 2 : (i / (points.length - 1)) * w);
  const y = (v: number) => padT + h - (v / max) * h;
  const line = (get: (p: SeriesPoint) => number) => points.map((p, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(get(p)).toFixed(1)}`).join(' ');
  const main = line((p) => p.value);
  const hasCompare = points.some((p) => (p.compare || 0) > 0);
  const area = `${main} L${x(points.length - 1).toFixed(1)},${(padT + h).toFixed(1)} L${x(0).toFixed(1)},${(padT + h).toFixed(1)} Z`;
  // Etiquetas del eje X: máximo ~8 para no amontonar
  const every = Math.max(1, Math.ceil(points.length / 8));
  const ticks = [1, 0.5, 0];
  const gradId = useMemo(() => `lg-${Math.random().toString(36).slice(2, 8)}`, []);
  const key = `${points.length}-${points[0]?.label}-${points[points.length - 1]?.label}`;

  const onMove = (e: React.MouseEvent<SVGSVGElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const px = e.clientX - rect.left - padL;
    const i = points.length <= 1 ? 0 : Math.round((px / w) * (points.length - 1));
    setHover(Math.max(0, Math.min(points.length - 1, i)));
  };

  return (
    <div ref={ref} className="relative" style={{ height }}>
      {width > 0 && (
        <svg width={width} height={height} onMouseMove={onMove} onMouseLeave={() => setHover(null)} role="img" aria-label={valueLabel}>
          <defs>
            <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="rgb(var(--blue-600-bg))" stopOpacity={0.16} />
              <stop offset="100%" stopColor="rgb(var(--blue-600-bg))" stopOpacity={0} />
            </linearGradient>
          </defs>
          {ticks.map((t) => (
            <g key={t}>
              <line x1={padL} x2={width} y1={y(max * t)} y2={y(max * t)} stroke="rgb(var(--slate-200-bd))" strokeDasharray={t === 0 ? undefined : '3 4'} />
              <text x={padL - 8} y={y(max * t)} textAnchor="end" dominantBaseline="middle" className="fill-slate-400 num" style={{ fontSize: 11 }}>{format(max * t)}</text>
            </g>
          ))}
          {points.map((p, i) => (i % every === 0 || i === points.length - 1) && (
            <text key={i} x={x(i)} y={height - 6} textAnchor="middle" className="fill-slate-500" style={{ fontSize: 11 }}>{p.label}</text>
          ))}
          {hasCompare && (
            <motion.path
              key={`c-${key}`} d={line((p) => p.compare || 0)} fill="none" stroke="rgb(var(--slate-400-bg))" strokeWidth={1.5} strokeDasharray="4 5"
              initial={reduce ? false : { opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.6, delay: 0.3 }}
            />
          )}
          <motion.path key={`a-${key}`} d={area} fill={`url(#${gradId})`} initial={reduce ? false : { opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.8, delay: 0.4 }} />
          <motion.path
            key={`m-${key}`} d={main} fill="none" stroke="rgb(var(--blue-600-bg))" strokeWidth={2.25} strokeLinecap="round" strokeLinejoin="round"
            initial={reduce ? false : { pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 1.1, ease: EASE_OUT }}
          />
          {hover !== null && (
            <g>
              <line x1={x(hover)} x2={x(hover)} y1={padT} y2={padT + h} stroke="rgb(var(--slate-900-tx))" strokeOpacity={0.25} />
              <circle cx={x(hover)} cy={y(points[hover].value)} r={4.5} fill="rgb(var(--blue-600-bg))" stroke="white" strokeWidth={2} />
            </g>
          )}
        </svg>
      )}
      {hover !== null && width > 0 && (
        <ChartTooltip
          title={points[hover].title || points[hover].label}
          rows={[
            { label: valueLabel, value: format(points[hover].value), accent: true },
            ...(hasCompare ? [{ label: compareLabel, value: format(points[hover].compare || 0) }] : []),
          ]}
          style={{ top: 4, ...(x(hover) > width / 2 ? { right: width - x(hover) + 12 } : { left: x(hover) + 12 }) }}
        />
      )}
    </div>
  );
}

// ── Dona ─────────────────────────────────────────────────────

export interface DonutSlice { key: string; label: string; value: number }

/** Tonos de la dona: el primero en acento, el resto en grafito decreciente */
export const SLICE_TONES = ['bg-blue-600', 'bg-slate-900', 'bg-slate-600', 'bg-slate-400', 'bg-slate-300', 'bg-slate-200'];
const SLICE_STROKES = ['rgb(var(--blue-600-bg))', 'rgb(var(--slate-900-bg))', 'rgb(var(--slate-600-bg))', 'rgb(var(--slate-400-bg))', 'rgb(var(--slate-300-bg))', 'rgb(var(--slate-200-bg))'];

export function Donut({ slices, size = 168, thickness = 18, center }: {
  slices: DonutSlice[]; size?: number; thickness?: number; center?: React.ReactNode;
}) {
  const reduce = useReducedMotion();
  const total = slices.reduce((a, s) => a + s.value, 0);
  const r = (size - thickness) / 2;
  const c = 2 * Math.PI * r;
  const gap = slices.length > 1 ? 3 : 0;
  let offset = 0;
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="-rotate-90" aria-hidden>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgb(var(--slate-100-bg))" strokeWidth={thickness} />
        {total > 0 && slices.map((s, i) => {
          const len = Math.max((s.value / total) * c - gap, 0);
          const el = (
            <motion.circle
              key={s.key}
              cx={size / 2} cy={size / 2} r={r} fill="none"
              stroke={SLICE_STROKES[Math.min(i, SLICE_STROKES.length - 1)]}
              strokeWidth={thickness} strokeLinecap="butt"
              strokeDasharray={`${len} ${c}`}
              initial={reduce ? false : { strokeDashoffset: -offset + len, opacity: 0 }}
              animate={{ strokeDashoffset: -offset, opacity: 1 }}
              transition={{ duration: 0.8, ease: EASE_OUT, delay: 0.1 + i * 0.08 }}
            />
          );
          offset += (s.value / total) * c;
          return el;
        })}
      </svg>
      {center && <div className="absolute inset-0 flex flex-col items-center justify-center text-center">{center}</div>}
    </div>
  );
}

// ── Medidor (semicírculo de marcas, sobre la tarjeta negra) ────

export function Gauge({ ratio, size = 240, center }: {
  /** 0–1: parte encendida del arco */
  ratio: number; size?: number; center?: React.ReactNode;
}) {
  const reduce = useReducedMotion();
  const [on, setOn] = useState(reduce ? ratio : 0);
  useEffect(() => {
    if (reduce) { setOn(ratio); return; }
    const id = requestAnimationFrame(() => setOn(ratio));
    return () => cancelAnimationFrame(id);
  }, [ratio, reduce]);
  const N = 44;
  const cx = size / 2, cy = size / 2;
  const r1 = size / 2 - 6, r2 = size / 2 - 22;
  const lit = Math.round(Math.max(0, Math.min(1, on)) * N);
  const ang = (i: number) => Math.PI + (i / (N - 1)) * Math.PI;
  const knob = ang(Math.max(0, Math.min(N - 1, Math.round(Math.max(0, Math.min(1, ratio)) * (N - 1)))));
  return (
    <div className="relative" style={{ width: size, height: size / 2 + 14 }}>
      <svg width={size} height={size / 2 + 14} aria-hidden>
        {Array.from({ length: N }, (_, i) => {
          const a = ang(i);
          const long = i % 4 === 0;
          const ri = long ? r2 - 4 : r2;
          return (
            <line
              key={i}
              x1={cx + Math.cos(a) * ri} y1={cy + Math.sin(a) * ri + 6}
              x2={cx + Math.cos(a) * r1} y2={cy + Math.sin(a) * r1 + 6}
              stroke="white" strokeOpacity={i < lit ? 0.95 : 0.16} strokeWidth={long ? 2.5 : 2} strokeLinecap="round"
              style={{ transition: `stroke-opacity 200ms ease ${i * 18}ms` }}
            />
          );
        })}
        <motion.circle
          r={7} fill="rgb(var(--slate-950-bg))" stroke="white" strokeWidth={3}
          initial={reduce ? false : { opacity: 0 }}
          animate={{ cx: cx + Math.cos(knob) * ((r1 + r2) / 2), cy: cy + Math.sin(knob) * ((r1 + r2) / 2) + 6, opacity: 1 }}
          transition={{ duration: 0.9, ease: EASE_OUT, delay: 0.2 }}
        />
      </svg>
      {center && <div className="absolute inset-x-0 bottom-0 flex flex-col items-center">{center}</div>}
    </div>
  );
}

// ── Mapa de calor (día × hora) ───────────────────────────────

export function Heatmap({ rows, cols, values, format, cellTitle }: {
  rows: string[];
  cols: string[];
  /** values[fila][columna] */
  values: number[][];
  format: (v: number) => string;
  cellTitle: (row: number, col: number) => string;
}) {
  const reduce = useReducedMotion();
  const [hover, setHover] = useState<[number, number] | null>(null);
  const max = Math.max(...values.flat(), 0);
  let peakRow = -1, peakCol = -1;
  if (max > 0) {
    outer: for (let i = 0; i < values.length; i++) {
      for (let j = 0; j < values[i].length; j++) if (values[i][j] === max) { peakRow = i; peakCol = j; break outer; }
    }
  }
  const level = (v: number) => (v <= 0 ? 0 : Math.min(5, Math.ceil((v / max) * 5)));
  const TONES = ['bg-slate-100', 'bg-slate-200', 'bg-slate-300', 'bg-slate-500', 'bg-slate-700', 'bg-slate-900'];
  return (
    <div className="relative">
      <div className="grid gap-1" style={{ gridTemplateColumns: `2.5rem repeat(${cols.length}, minmax(0, 1fr))` }}>
        <span />
        {cols.map((c, j) => <span key={c} className="pb-1 text-center text-[0.68rem] text-slate-400 num">{j % 2 === 0 ? c : ''}</span>)}
        {rows.map((r, i) => (
          <React.Fragment key={r}>
            <span className="flex items-center text-[0.72rem] text-slate-500">{r}</span>
            {cols.map((c, j) => {
              const v = values[i][j];
              const isPeak = peakRow === i && peakCol === j;
              return (
                <motion.div
                  key={c}
                  onMouseEnter={() => setHover([i, j])}
                  onMouseLeave={() => setHover(null)}
                  className={`relative h-7 rounded-md ${isPeak ? 'bg-blue-600' : TONES[level(v)]} ${hover && hover[0] === i && hover[1] === j ? 'ring-2 ring-slate-900 ring-offset-1' : ''}`}
                  initial={reduce ? false : { opacity: 0, scale: 0.6 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.35, ease: EASE_OUT, delay: (i * cols.length + j) * 0.004 }}
                />
              );
            })}
          </React.Fragment>
        ))}
      </div>
      {hover && (
        <ChartTooltip
          title={cellTitle(hover[0], hover[1])}
          rows={[{ label: '', value: format(values[hover[0]][hover[1]]), accent: true }]}
          style={{ top: `${((hover[0] + 1) / (rows.length + 1)) * 100}%`, ...(hover[1] > cols.length / 2 ? { right: `${((cols.length - hover[1]) / cols.length) * 100}%` } : { left: `calc(2.5rem + ${((hover[1] + 1) / cols.length) * 100}%)` }) }}
        />
      )}
      <div className="mt-3 flex items-center justify-end gap-1.5 text-[0.7rem] text-slate-400">
        <span>{format(0)}</span>
        {TONES.map((t) => <span key={t} className={`h-2.5 w-4 rounded-sm ${t}`} />)}
        <span className="num">{format(max)}</span>
      </div>
    </div>
  );
}

// ── Lista con barras horizontales (productos, equipo, canales) ─

export interface RankItem { key: string; label: React.ReactNode; sub?: React.ReactNode; value: number; display: React.ReactNode; aside?: React.ReactNode }

export function RankList({ items, max: maxProp, numbered = false }: { items: RankItem[]; max?: number; numbered?: boolean }) {
  const reduce = useReducedMotion();
  const max = maxProp ?? Math.max(...items.map((i) => i.value), 1);
  return (
    <ol className="space-y-3">
      {items.map((it, i) => (
        <li key={it.key} className="lt-enter" style={{ animationDelay: `${i * 40}ms` }}>
          <div className="mb-1.5 flex items-baseline justify-between gap-3">
            <div className="flex min-w-0 items-baseline gap-2">
              {numbered && <span className="w-5 shrink-0 text-xs font-semibold text-slate-400 num">{i + 1}</span>}
              <span className="truncate text-sm font-medium text-slate-900">{it.label}</span>
              {it.sub && <span className="hidden truncate text-xs text-slate-500 sm:inline">{it.sub}</span>}
            </div>
            <div className="flex shrink-0 items-baseline gap-2">
              {it.aside}
              <span className="text-sm font-semibold text-slate-900 num">{it.display}</span>
            </div>
          </div>
          <div className={`h-1.5 overflow-hidden rounded-full bg-slate-100 ${numbered ? 'ml-7' : ''}`}>
            <motion.div
              className={`h-full rounded-full ${i === 0 ? 'bg-blue-600' : 'bg-slate-800'}`}
              initial={reduce ? false : { width: 0 }}
              animate={{ width: `${(it.value / max) * 100}%` }}
              transition={{ duration: 0.8, ease: EASE_OUT, delay: 0.1 + i * 0.04 }}
            />
          </div>
        </li>
      ))}
    </ol>
  );
}

// ── Barra apilada horizontal (reparto en una sola línea) ──────

export function StackBar({ slices }: { slices: DonutSlice[] }) {
  const reduce = useReducedMotion();
  const total = slices.reduce((a, s) => a + s.value, 0) || 1;
  return (
    <div className="flex h-2.5 w-full gap-0.5 overflow-hidden rounded-full bg-slate-100">
      {slices.map((s, i) => (
        <motion.div
          key={s.key}
          className={`h-full ${SLICE_TONES[Math.min(i, SLICE_TONES.length - 1)]}`}
          initial={reduce ? false : { width: 0 }}
          animate={{ width: `${(s.value / total) * 100}%` }}
          transition={{ duration: 0.8, ease: EASE_OUT, delay: i * 0.06 }}
        />
      ))}
    </div>
  );
}
