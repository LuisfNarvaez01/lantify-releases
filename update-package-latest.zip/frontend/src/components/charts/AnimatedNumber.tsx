// ============================================
// CHARTS - AnimatedNumber: cifras que ruedan como un odómetro
// ============================================
// Cada dígito es una columna 0–9 que se desplaza hasta su valor; los separadores
// ($, puntos, %) quedan quietos. Al cambiar el período los dígitos ruedan del
// valor anterior al nuevo. Con movimiento reducido se muestra el número directo.
// El texto completo va en aria-label: el lector de pantalla no lee la columna.

import { useEffect, useState } from 'react';
import { useReducedMotion } from 'motion/react';

const DIGITS = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];

function Digit({ d, delay }: { d: number; delay: number }) {
  return (
    <span className="relative inline-block h-[1em] overflow-hidden align-top" aria-hidden>
      <span className="invisible">0</span>
      <span
        className="absolute left-0 top-0 flex flex-col"
        style={{
          transform: `translateY(-${d * 10}%)`,
          transition: `transform 900ms cubic-bezier(0.2, 0.8, 0.2, 1) ${delay}ms`,
        }}
      >
        {DIGITS.map((n) => <span key={n} className="block h-[1em] leading-none">{n}</span>)}
      </span>
    </span>
  );
}

export function AnimatedNumber({ value, format = (v) => Math.round(v).toLocaleString('es-CO'), className = '' }: {
  value: number;
  format?: (v: number) => string;
  className?: string;
}) {
  const reduce = useReducedMotion();
  const text = format(value);
  // Primer pintado en ceros para que los dígitos rueden al montar
  const [shown, setShown] = useState(() => (reduce ? text : text.replace(/\d/g, '0')));

  useEffect(() => {
    if (reduce) { setShown(text); return; }
    const id = requestAnimationFrame(() => setShown(text));
    return () => cancelAnimationFrame(id);
  }, [text, reduce]);

  const chars = shown.split('');
  return (
    <span className={`num inline-flex items-start leading-none whitespace-nowrap ${className}`} aria-label={text} role="img">
      {chars.map((ch, i) => {
        // Clave desde la derecha: las unidades conservan su columna aunque el número crezca
        const key = chars.length - i;
        return /\d/.test(ch)
          ? <Digit key={key} d={Number(ch)} delay={Math.min(i, 8) * 35} />
          : <span key={`s${key}`} aria-hidden className="inline-block h-[1em] leading-none">{ch}</span>;
      })}
    </span>
  );
}

export default AnimatedNumber;
