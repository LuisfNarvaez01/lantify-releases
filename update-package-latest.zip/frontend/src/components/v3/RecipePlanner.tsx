// ============================================
// V3 - Inventario → Producción (Fase 4 · mejoras)
// ============================================
// Tres herramientas con las recetas y las existencias de ingredientes:
//   1. Cuánto alcanza: porciones posibles de cada producto y qué se acaba primero.
//   2. Calculadora: "¿qué necesito para 50 hamburguesas y 30 perros?", qué falta
//      y el pedido al proveedor por WhatsApp con un toque.
//   3. Recetas en lote: los productos sin receta en una sola lista, escribiendo
//      "200 g carne, 1 pan, 30 g queso" o con la sugerencia de la IA.

import React, { useEffect, useMemo, useState } from 'react';
import { AlertTriangle, Calculator, ChefHat, Copy, Gauge, MessageCircle, Minus, Plus, Search, Sparkles, Wand2, X } from 'lucide-react';
import { planningAPI, type PlanningData } from '../../services/v3Api';
import { errorMessage } from '../../services/apiErrors';
import { formatCurrency } from '../../shared/formatUtils';
import { toast } from '../../shared/toast';
import { openWhatsAppChat } from '../../services/whatsappTicket';
import { copyText } from '../../shared/browser';
import { Button } from '../common/Button';
import { t, getLanguage as currentLanguage } from '../../i18n';
import { fmtQty } from './IngredientsPanel';
import { matchIngredient, parseRecipeText, requirements, shortageText, yields, type BaseUnit } from '../../../../src/domain/v3/recipePlanning';

type View = 'yield' | 'calc' | 'recipes';
const card = 'rounded-3xl border border-slate-200/80 bg-white shadow-sm';
const field = 'w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/40';

/** Texto de una receta existente, para copiarla a otro producto ("150 g Carne, 1 und Pan") */
const recipeAsText = (recipe: { ingredientId: string; quantity: number }[], ingredients: PlanningData['ingredients']) =>
  recipe.map((r) => { const i = ingredients.find((x) => x.id === r.ingredientId); return i ? `${r.quantity} ${i.unit} ${i.name}` : ''; }).filter(Boolean).join(', ');

function YieldView({ data }: { data: PlanningData }) {
  const [q, setQ] = useState('');
  const rows = useMemo(() => yields(data.products, data.ingredients).sort((a, b) => a.canMake - b.canMake), [data]);
  const shown = rows.filter((r) => !q || r.name.toLowerCase().includes(q.toLowerCase()));
  const price = new Map(data.products.map((p) => [p.id, p.price]));
  if (!rows.length) return <Empty text={t('v3:plan_sin_recetas')} />;
  return (
    <div className="space-y-3">
      <SearchBox value={q} onChange={setQ} />
      <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white">
        <table className="w-full min-w-[620px] text-sm">
          <thead className="bg-slate-50 text-left text-xs font-bold uppercase tracking-wide text-slate-500">
            <tr><th className="px-4 py-3">{t('v3:plan_producto')}</th><th className="px-4 py-3 text-right">{t('v3:plan_alcanzan')}</th><th className="px-4 py-3">{t('v3:plan_se_acaba')}</th><th className="px-4 py-3 text-right">{t('v3:plan_costo')}</th><th className="px-4 py-3 text-right">{t('v3:plan_margen')}</th></tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {shown.map((r) => {
              const p = price.get(r.productId) || 0;
              const margin = p > 0 ? Math.round(((p - r.cost) / p) * 100) : null;
              return (
                <tr key={r.productId}>
                  <td className="px-4 py-3 font-semibold text-slate-900">{r.name}</td>
                  <td className="px-4 py-3 text-right">
                    <span className={`inline-flex min-w-[3rem] justify-center rounded-full px-2.5 py-1 text-sm font-black tabular-nums ${r.canMake === 0 ? 'bg-rose-100 text-rose-800' : r.canMake < 10 ? 'bg-amber-100 text-amber-900' : 'bg-emerald-100 text-emerald-800'}`}>{r.canMake}</span>
                  </td>
                  <td className="px-4 py-3 text-xs text-slate-600">{r.limiting?.name || '—'}</td>
                  <td className="px-4 py-3 text-right tabular-nums">{formatCurrency(r.cost)}</td>
                  <td className={`px-4 py-3 text-right tabular-nums ${margin !== null && margin < 30 ? 'font-bold text-rose-700' : ''}`}>{margin === null ? '—' : `${margin} %`}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <p className="text-xs text-slate-500">{t('v3:plan_alcanzan_ayuda')}</p>
    </div>
  );
}

function CalcView({ data }: { data: PlanningData }) {
  const withRecipe = data.products.filter((p) => p.recipe.length);
  const [qty, setQty] = useState<Record<string, number>>({});
  const [q, setQ] = useState('');
  const plan = Object.entries(qty).filter(([, n]) => n > 0).map(([productId, n]) => ({ productId, qty: n }));
  const result = useMemo(() => requirements(plan, data.products, data.ingredients), [plan, data]);
  const shown = withRecipe.filter((p) => !q || p.name.toLowerCase().includes(q.toLowerCase()));
  const set = (id: string, n: number) => setQty((s) => ({ ...s, [id]: Math.max(0, Math.min(100_000, Math.round(n) || 0)) }));
  const short = result.needs.filter((n) => n.short > 0);

  // Lo que falta, agrupado por el proveedor de cada ingrediente
  const bySupplier = useMemo(() => {
    const m = new Map<string, typeof short>();
    for (const n of short) m.set(n.supplierId || '', [...(m.get(n.supplierId || '') || []), n]);
    return [...m.entries()].map(([id, lines]) => ({ supplier: data.suppliers.find((s) => s.id === id) || null, lines }));
  }, [short, data.suppliers]);
  const message = (lines: typeof short) => shortageText(data.businessName, lines.map((l) => ({ name: l.name, quantity: l.short, unit: l.unit as BaseUnit })), currentLanguage() === 'en' ? 'en' : 'es');

  if (!withRecipe.length) return <Empty text={t('v3:plan_sin_recetas')} />;
  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.15fr)]">
      <section className={`${card} p-4`}>
        <h3 className="font-bold text-slate-900">{t('v3:calc_que_vas')}</h3>
        <div className="mt-2"><SearchBox value={q} onChange={setQ} /></div>
        <ul className="mt-3 max-h-[28rem] divide-y divide-slate-100 overflow-y-auto">
          {shown.map((p) => (
            <li key={p.id} className="flex items-center gap-2 py-2">
              <span className="min-w-0 flex-1 truncate text-sm font-semibold text-slate-800">{p.name}</span>
              <button type="button" onClick={() => set(p.id, (qty[p.id] || 0) - 1)} className="grid h-9 w-9 place-items-center rounded-lg bg-slate-100 active:scale-95" aria-label={t('v3:kio_menos')}><Minus className="h-4 w-4" /></button>
              <input type="number" min={0} inputMode="numeric" aria-label={t('v3:calc_cantidad_de', { name: p.name })} className="w-20 rounded-lg border border-slate-300 px-2 py-1.5 text-center text-sm font-bold tabular-nums" value={qty[p.id] || ''} placeholder="0" onChange={(e) => set(p.id, Number(e.target.value))} />
              <button type="button" onClick={() => set(p.id, (qty[p.id] || 0) + 1)} className="grid h-9 w-9 place-items-center rounded-lg bg-slate-100 active:scale-95" aria-label={t('v3:kio_mas')}><Plus className="h-4 w-4" /></button>
            </li>
          ))}
        </ul>
        {plan.length > 0 && <button type="button" onClick={() => setQty({})} className="mt-2 text-xs font-bold text-slate-500 hover:text-slate-800">{t('v3:calc_limpiar')}</button>}
      </section>
      <section className={`${card} p-4`} aria-live="polite">
        <div className="flex items-baseline justify-between gap-3">
          <h3 className="font-bold text-slate-900">{t('v3:calc_necesitas')}</h3>
          {result.needs.length > 0 && <span className="text-sm text-slate-600">{t('v3:calc_costo_total')} <strong className="tabular-nums text-slate-900">{formatCurrency(result.cost)}</strong></span>}
        </div>
        {!plan.length ? <p className="mt-6 text-center text-sm text-slate-500">{t('v3:calc_vacio')}</p> : (
          <>
            <table className="mt-3 w-full text-sm">
              <thead className="text-left text-xs text-slate-500"><tr><th className="py-1.5">{t('v3:ing_nombre')}</th><th className="text-right">{t('v3:calc_necesita')}</th><th className="text-right">{t('v3:calc_tienes')}</th><th className="text-right">{t('v3:calc_falta')}</th></tr></thead>
              <tbody className="divide-y divide-slate-100">
                {result.needs.map((n) => (
                  <tr key={n.ingredientId} className="display-pop">
                    <td className="py-2 font-semibold text-slate-800">{n.name}</td>
                    <td className="text-right tabular-nums">{fmtQty(n.need, n.unit)}</td>
                    <td className="text-right tabular-nums text-slate-500">{fmtQty(n.have, n.unit)}</td>
                    <td className={`text-right font-bold tabular-nums ${n.short > 0 ? 'text-rose-700' : 'text-emerald-700'}`}>{n.short > 0 ? fmtQty(n.short, n.unit) : '✓'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {result.missingRecipe.length > 0 && <p className="mt-2 text-xs font-semibold text-amber-800">{t('v3:calc_sin_receta', { count: result.missingRecipe.length })}</p>}
            {short.length === 0 ? (
              <p className="mt-4 rounded-2xl bg-emerald-50 p-3 text-sm font-semibold text-emerald-900">{t('v3:calc_alcanza')}</p>
            ) : (
              <div className="mt-4 space-y-2">
                <p className="flex items-center gap-2 text-sm font-bold text-slate-900"><AlertTriangle className="h-4 w-4 text-amber-600" aria-hidden />{t('v3:calc_pedir')}</p>
                {bySupplier.map((g) => (
                  <div key={g.supplier?.id || 'none'} className="flex flex-wrap items-center gap-2 rounded-2xl bg-slate-50 p-3">
                    <span className="min-w-0 flex-1 text-sm"><strong>{g.supplier?.name || t('v3:calc_sin_proveedor')}</strong><span className="block text-xs text-slate-500">{g.lines.map((l) => `${l.name} ${fmtQty(l.short, l.unit)}`).join(' · ')}</span></span>
                    {g.supplier?.phone && <Button size="sm" variant="success" leftIcon={<MessageCircle className="h-4 w-4" />} onClick={() => openWhatsAppChat(g.supplier!.phone!, message(g.lines))}>{t('v3:calc_whatsapp')}</Button>}
                    <Button size="sm" variant="outline" leftIcon={<Copy className="h-4 w-4" />} onClick={() => copyText(message(g.lines)).then(() => toast.success(t('v3:copiado')))}>{t('v3:copiar')}</Button>
                  </div>
                ))}
                <p className="text-xs text-slate-500">{t('v3:calc_proveedor_ayuda')}</p>
              </div>
            )}
          </>
        )}
      </section>
    </div>
  );
}

interface Draft { text: string; source: 'manual' | 'ai' | 'copy' }

function RecipesView({ data, reload }: { data: PlanningData; reload: () => void }) {
  const missing = data.products.filter((p) => !p.recipe.length);
  const withRecipe = data.products.filter((p) => p.recipe.length);
  const [drafts, setDrafts] = useState<Record<string, Draft>>({});
  const [q, setQ] = useState('');
  const [busy, setBusy] = useState<'ai' | 'save' | null>(null);
  const shown = missing.filter((p) => !q || `${p.name} ${p.category || ''}`.toLowerCase().includes(q.toLowerCase()));
  const ready = Object.entries(drafts).filter(([id, d]) => missing.some((p) => p.id === id) && parseRecipeText(d.text).length > 0);

  const suggest = async () => {
    const targets = shown.filter((p) => !drafts[p.id]?.text).slice(0, 60);
    if (!targets.length) return;
    setBusy('ai');
    try {
      for (let i = 0; i < targets.length; i += 30) {
        const batch = targets.slice(i, i + 30);
        const r = await planningAPI.suggestRecipes({ products: batch.map((p) => ({ name: p.name, description: p.description })), ingredients: data.ingredients.map((x) => ({ name: x.name, unit: x.unit })), businessType: data.businessType });
        setDrafts((d) => {
          const next = { ...d };
          for (const rec of r.recipes) {
            const p = batch.find((x) => x.name === rec.product);
            if (p && !next[p.id]?.text) next[p.id] = { text: rec.items.map((it) => `${it.quantity} ${it.unit} ${it.ingredient}`).join(', '), source: 'ai' };
          }
          return next;
        });
      }
      toast.success(t('v3:rec_ia_lista'));
    } catch (err) { toast.error(errorMessage(err)); } finally { setBusy(null); }
  };

  const save = async () => {
    setBusy('save');
    try {
      const r = await planningAPI.bulkRecipes(ready.map(([productId, d]) => ({ productId, items: parseRecipeText(d.text).map((l) => ({ name: l.name, quantity: l.quantity, unit: l.unit })) })));
      toast.success(t('v3:rec_guardadas', { count: r.saved, nuevos: r.createdIngredients }));
      setDrafts({});
      reload();
    } catch (err) { toast.error(errorMessage(err)); } finally { setBusy(null); }
  };

  if (!missing.length) return <Empty text={t('v3:rec_todas_listas')} good />;
  return (
    <div className="space-y-3">
      <div className="rounded-2xl border border-blue-200 bg-blue-50 p-4 text-sm text-blue-950">
        <p className="font-bold">{t('v3:rec_como')}</p>
        <p className="mt-1">{t('v3:rec_como_desc')}</p>
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <div className="min-w-[14rem] flex-1"><SearchBox value={q} onChange={setQ} /></div>
        <Button variant="outline" leftIcon={<Sparkles className="h-4 w-4" />} isLoading={busy === 'ai'} onClick={suggest}>{t('v3:rec_sugerir_ia')}</Button>
        <Button leftIcon={<ChefHat className="h-4 w-4" />} isLoading={busy === 'save'} disabled={!ready.length} onClick={save}>{t('v3:rec_guardar_n', { count: ready.length })}</Button>
      </div>
      <p className="text-xs text-slate-500">{t('v3:rec_faltan', { count: missing.length })}</p>
      <ul className="space-y-2">
        {shown.slice(0, 120).map((p) => {
          const d = drafts[p.id];
          const lines = parseRecipeText(d?.text || '');
          return (
            <li key={p.id} className={`${card} p-3`}>
              <div className="flex flex-wrap items-center gap-2">
                <span className="min-w-0 flex-1"><span className="font-bold text-slate-900">{p.name}</span>{p.category && <span className="ml-2 text-xs text-slate-500">{p.category}</span>}</span>
                {d?.source === 'ai' && <span className="inline-flex items-center gap-1 rounded-full bg-violet-100 px-2 py-0.5 text-xs font-bold text-violet-800"><Wand2 className="h-3 w-3" aria-hidden />{t('v3:rec_de_ia')}</span>}
                {withRecipe.length > 0 && (
                  <select aria-label={t('v3:rec_copiar_de')} className="max-w-[12rem] rounded-xl border border-slate-300 bg-white px-2 py-1.5 text-xs" value="" onChange={(e) => { const src = withRecipe.find((x) => x.id === e.target.value); if (src) setDrafts((s) => ({ ...s, [p.id]: { text: recipeAsText(src.recipe, data.ingredients), source: 'copy' } })); }}>
                    <option value="">{t('v3:rec_copiar_de')}</option>
                    {withRecipe.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}
                  </select>
                )}
                {d?.text && <button type="button" onClick={() => setDrafts((s) => { const n = { ...s }; delete n[p.id]; return n; })} className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100" aria-label={t('v3:quitar')}><X className="h-4 w-4" /></button>}
              </div>
              <input className={`${field} mt-2`} value={d?.text || ''} placeholder={t('v3:rec_ej')} aria-label={t('v3:rec_de', { name: p.name })} onChange={(e) => setDrafts((s) => ({ ...s, [p.id]: { text: e.target.value, source: s[p.id]?.source === 'ai' ? 'ai' : 'manual' } }))} />
              {lines.length > 0 && (
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {lines.map((l, i) => {
                    const hit = matchIngredient(l.name, data.ingredients);
                    return <span key={i} className={`rounded-lg px-2 py-0.5 text-xs font-semibold ${hit ? 'bg-emerald-50 text-emerald-800' : 'bg-amber-50 text-amber-900'}`} title={hit ? hit.name : t('v3:rec_se_crea')}>{fmtQty(l.quantity, l.unit)} {hit ? hit.name : `${l.name} +`}</span>;
                  })}
                </div>
              )}
            </li>
          );
        })}
      </ul>
      <p className="text-xs text-slate-500">{t('v3:rec_leyenda')}</p>
    </div>
  );
}

function SearchBox({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return (
    <label className="relative block">
      <span className="sr-only">{t('v3:ing_buscar')}</span>
      <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" aria-hidden />
      <input value={value} onChange={(e) => onChange(e.target.value)} placeholder={t('v3:plan_buscar')} className="w-full rounded-xl border border-slate-300 py-2 pl-9 pr-3 text-sm" />
    </label>
  );
}

function Empty({ text, good = false }: { text: string; good?: boolean }) {
  return <p className={`rounded-2xl border p-6 text-center text-sm ${good ? 'border-emerald-200 bg-emerald-50 text-emerald-900' : 'border-slate-200 bg-white text-slate-500'}`}>{text}</p>;
}

export const RecipePlanner: React.FC = () => {
  const [data, setData] = useState<PlanningData | null>(null);
  const [view, setView] = useState<View>('yield');
  const load = () => planningAPI.get().then(setData).catch((e) => toast.error(errorMessage(e)));
  useEffect(() => { load(); }, []);
  const missing = data ? data.products.filter((p) => !p.recipe.length).length : 0;
  const views: { id: View; icon: typeof Gauge }[] = [{ id: 'yield', icon: Gauge }, { id: 'calc', icon: Calculator }, { id: 'recipes', icon: ChefHat }];
  return (
    <div className="space-y-4">
      <div className="inline-flex flex-wrap gap-1 rounded-2xl bg-slate-100 p-1" role="tablist" aria-label={t('v3:inv_tab_planning')}>
        {views.map(({ id, icon: Icon }) => (
          <button key={id} type="button" role="tab" aria-selected={view === id} onClick={() => setView(id)} className={`inline-flex min-h-[40px] items-center gap-2 rounded-xl px-4 text-sm font-bold transition ${view === id ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}>
            <Icon className="h-4 w-4" aria-hidden />{t(`v3:plan_vista_${id}`)}
            {id === 'recipes' && missing > 0 && <span className="rounded-full bg-amber-100 px-1.5 text-xs font-black text-amber-900">{missing}</span>}
          </button>
        ))}
      </div>
      {!data ? <p className="text-sm text-slate-500">{t('v3:cargando')}</p> : (
        <div key={view} className="kiosk-fade">
          {view === 'yield' && <YieldView data={data} />}
          {view === 'calc' && <CalcView data={data} />}
          {view === 'recipes' && <RecipesView data={data} reload={load} />}
        </div>
      )}
    </div>
  );
};
