// ============================================
// V3 - Salón y mesas en subpestañas
// ============================================
// Antes todo iba en una sola página larga (funciones, frases, pantallas y plano)
// y había que bajar y subir para encontrar cada cosa.

import React, { useState } from 'react';
import { LayoutGrid, MessageSquareText, Monitor, QrCode, ToggleRight } from 'lucide-react';
import { TablesManager } from '../admin/TablesManager';
import { FeaturesPanel } from '../admin/FeaturesPanel';
import { DisplaysPanel } from '../admin/DisplaysPanel';
import { TableQrPanel } from '../admin/TableQrPanel';
import { t } from '../../i18n';

const TABS = [
  ['plano', LayoutGrid],
  ['funciones', ToggleRight],
  ['frases', MessageSquareText],
  ['pantallas', Monitor],
  ['qr', QrCode],
] as const;
type SalonTab = (typeof TABS)[number][0];
const KEY = 'lantify.salonTab';

const initial = (): SalonTab => {
  try {
    const v = localStorage.getItem(KEY);
    if (TABS.some(([id]) => id === v)) return v as SalonTab;
  } catch { /* sin almacenamiento */ }
  return 'plano';
};

export const SalonTabs: React.FC = () => {
  const [tab, setTab] = useState<SalonTab>(initial);
  const pick = (id: SalonTab) => {
    setTab(id);
    try { localStorage.setItem(KEY, id); } catch { /* sin almacenamiento */ }
  };
  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-2xl font-bold text-slate-900 font-heading">{t('admin:salon_y_mesas')}</h2>
        <p className="mt-1 text-sm text-slate-500">{t('admin:salon_y_mesas_desc')}</p>
      </div>
      <div className="-mx-1 overflow-x-auto px-1 pb-1">
        <div className="inline-flex gap-1 rounded-2xl bg-slate-100 p-1" role="tablist" aria-label={t('v3:salon_tabs')}>
          {TABS.map(([id, Icon]) => (
            <button key={id} type="button" role="tab" aria-selected={tab === id} onClick={() => pick(id)} className={`inline-flex min-h-[40px] items-center gap-2 whitespace-nowrap rounded-xl px-4 text-sm font-bold ${tab === id ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}>
              <Icon className="h-4 w-4" aria-hidden />{t(`v3:salon_tab_${id}`)}
            </button>
          ))}
        </div>
      </div>
      <div role="tabpanel">
        {tab === 'plano' && <TablesManager />}
        {tab === 'funciones' && <FeaturesPanel place="salon" />}
        {tab === 'frases' && <FeaturesPanel place="salon" features={false} notes />}
        {tab === 'pantallas' && <DisplaysPanel />}
        {tab === 'qr' && <TableQrPanel />}
      </div>
    </div>
  );
};
