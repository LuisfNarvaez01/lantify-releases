// ============================================
// Lantify 3.0 - Ventanas de operación
// ============================================
// Lista de compras por proveedor, reposición de un producto, corrección del medio
// de pago, ingredientes de un producto y reporte de cierre para el dueño.

import React, { useEffect, useMemo, useState } from 'react';
import { Copy, MessageCircle, Plus, Trash2, X } from 'lucide-react';
import { t } from '../../i18n';
import { toast } from '../../shared/toast';
import { formatCurrency } from '../../shared/formatUtils';
import { Button } from '../common/Button';
import { suppliersAPI } from '../../services/api';
import { opsAPI, type ShoppingGroup } from '../../services/v3Api';
import { openWhatsAppChat } from '../../services/whatsappTicket';
import { parseIngredients } from '../../shared/itemNotes';
import { lineText } from '../../../../src/domain/v3/shoppingList';
import type { PaymentMethod, PaymentPart } from '../../../../src/domain/v3/paymentFix';

const field = 'rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 min-h-[44px] focus:outline-none focus:ring-2 focus:ring-blue-500/40';

function Modal({ title, subtitle, onClose, children, wide }: { title: string; subtitle?: string; onClose: () => void; children: React.ReactNode; wide?: boolean }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);
  return (
    <div className="fixed inset-0 bg-black/50 flex items-end sm:items-center justify-center z-[130] sm:p-4" role="presentation" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div role="dialog" aria-modal="true" aria-label={title} className={`bg-white rounded-t-3xl sm:rounded-3xl w-full ${wide ? 'sm:max-w-2xl' : 'sm:max-w-md'} shadow-2xl max-h-[92dvh] flex flex-col overflow-hidden`}>
        <div className="flex items-start justify-between gap-3 p-5 border-b border-slate-100 shrink-0">
          <div className="min-w-0">
            <h3 className="font-bold text-lg text-slate-900 font-heading">{title}</h3>
            {subtitle && <p className="text-xs text-slate-500 mt-0.5">{subtitle}</p>}
          </div>
          <button type="button" onClick={onClose} aria-label={t('pos:cerrar')} className="w-11 h-11 hover:bg-slate-100 text-slate-500 rounded-xl flex items-center justify-center shrink-0"><X className="w-5 h-5" aria-hidden /></button>
        </div>
        <div className="p-5 overflow-y-auto space-y-4">{children}</div>
      </div>
    </div>
  );
}

// ── Lista de compras ────────────────────────────────────────

export function ShoppingListModal({ onClose }: { onClose: () => void }) {
  const [groups, setGroups] = useState<ShoppingGroup[] | null>(null);
  const [business, setBusiness] = useState('');

  useEffect(() => {
    opsAPI.shoppingList().then((res) => { setGroups(res.groups); setBusiness(res.businessName); }).catch((err) => { toast.error(err?.message || t('v3:no_se_guardo')); onClose(); });
  }, [onClose]);

  const textOf = (g: ShoppingGroup) => {
    const head = g.text.split('\n')[0];
    return [head, ...g.lines.map((l) => `• ${lineText(l)}`)].join('\n');
  };
  const setQty = (gi: number, li: number, quantity: number) =>
    setGroups((gs) => gs && gs.map((g, i) => (i !== gi ? g : { ...g, lines: g.lines.map((l, j) => (j === li ? { ...l, quantity: Math.max(1, quantity) } : l)) })));
  const removeLine = (gi: number, li: number) =>
    setGroups((gs) => gs && gs.map((g, i) => (i !== gi ? g : { ...g, lines: g.lines.filter((_, j) => j !== li) })).filter((g) => g.lines.length > 0));

  const copy = async (g: ShoppingGroup) => {
    try {
      await navigator.clipboard.writeText(textOf(g));
      toast.success(t('v3:copiado'));
      opsAPI.shoppingSent(g.supplierName, g.lines.length, 'copy').catch(() => undefined);
    } catch {
      toast.error(t('v3:no_se_copio'));
    }
  };
  const send = (g: ShoppingGroup) => {
    if (!g.phone) return;
    openWhatsAppChat(g.phone, textOf(g));
    opsAPI.shoppingSent(g.supplierName, g.lines.length, 'whatsapp').catch(() => undefined);
  };

  return (
    <Modal wide title={t('v3:lista_compras')} subtitle={t('v3:lista_compras_desc', { negocio: business })} onClose={onClose}>
      {groups === null && <p className="text-sm text-slate-500">{t('v3:cargando')}</p>}
      {groups && groups.length === 0 && <p className="text-sm text-slate-700 py-6 text-center">{t('v3:nada_por_comprar')}</p>}
      {groups?.map((g, gi) => (
        <section key={g.supplierId || 'none'} className="rounded-2xl border border-slate-200 overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 bg-slate-50 border-b border-slate-200">
            <h4 className="text-sm font-bold text-slate-900">{g.supplierName || t('v3:sin_proveedor')}</h4>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" leftIcon={<Copy className="w-4 h-4" />} onClick={() => copy(g)}>{t('v3:copiar')}</Button>
              {g.phone && <Button size="sm" variant="success" leftIcon={<MessageCircle className="w-4 h-4" />} onClick={() => send(g)}>WhatsApp</Button>}
            </div>
          </div>
          <ul className="divide-y divide-slate-100">
            {g.lines.map((l, li) => (
              <li key={l.variantId} className="px-4 py-2 flex items-center gap-3">
                <span className="flex-1 min-w-0"><span className="block text-sm font-semibold text-slate-900 truncate">{l.name}</span><span className="block text-xs text-slate-500">{t('v3:hay_minimo', { stock: l.stock, min: l.minStock })}</span></span>
                <input type="number" min={1} aria-label={t('v3:cantidad_a_pedir')} className={`${field} w-20 text-right tabular-nums`} value={l.quantity} onChange={(e) => setQty(gi, li, Math.round(Number(e.target.value) || 1))} />
                <span className="text-sm text-slate-600 w-14 truncate">{l.unit}</span>
                <button type="button" onClick={() => removeLine(gi, li)} aria-label={t('v3:quitar_de_la_lista', { name: l.name })} className="w-10 h-10 inline-flex items-center justify-center rounded-lg text-slate-500 hover:bg-rose-50 hover:text-rose-700"><Trash2 className="w-4 h-4" aria-hidden /></button>
              </li>
            ))}
          </ul>
          {!g.supplierId && <p className="px-4 py-2 text-xs text-slate-500 bg-slate-50 border-t border-slate-200">{t('v3:sin_proveedor_desc')}</p>}
        </section>
      ))}
    </Modal>
  );
}

// ── Reposición de un producto ───────────────────────────────

export function ReorderModal({ item, onClose, onSaved }: { item: { variantId: string; productName: string; variantName?: string; minStock?: number | null; reorderQty?: number | null; purchaseUnit?: string | null; preferredSupplierId?: string | null }; onClose: () => void; onSaved: () => void }) {
  const [suppliers, setSuppliers] = useState<{ id: string; name: string }[]>([]);
  const [form, setForm] = useState({ minStock: item.minStock ?? '', reorderQty: item.reorderQty ?? '', purchaseUnit: item.purchaseUnit || '', preferredSupplierId: item.preferredSupplierId || '' });
  const [saving, setSaving] = useState(false);

  useEffect(() => { suppliersAPI.list().then((list: any[]) => setSuppliers(list.filter((s) => s.isActive !== false))).catch(() => setSuppliers([])); }, []);

  const save = async () => {
    setSaving(true);
    try {
      await opsAPI.setReorder(item.variantId, {
        minStock: form.minStock === '' ? null : Number(form.minStock),
        reorderQty: form.reorderQty === '' ? null : Number(form.reorderQty),
        purchaseUnit: form.purchaseUnit || null,
        preferredSupplierId: form.preferredSupplierId || null,
      });
      toast.success(t('v3:guardado'));
      onSaved();
      onClose();
    } catch (err: any) {
      toast.error(err?.message || t('v3:no_se_guardo'));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal title={t('v3:reposicion')} subtitle={item.productName} onClose={onClose}>
      <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); save(); }}>
        <div className="grid grid-cols-2 gap-3">
          <label className="text-xs font-bold text-slate-700 space-y-1 block">{t('v3:stock_minimo')}<input type="number" min={0} placeholder="5" className={`${field} w-full`} value={form.minStock} onChange={(e) => setForm({ ...form, minStock: e.target.value })} /></label>
          <label className="text-xs font-bold text-slate-700 space-y-1 block">{t('v3:cantidad_a_pedir')}<input type="number" min={0} className={`${field} w-full`} value={form.reorderQty} onChange={(e) => setForm({ ...form, reorderQty: e.target.value })} /></label>
        </div>
        <label className="text-xs font-bold text-slate-700 space-y-1 block">{t('v3:unidad_compra')}<input maxLength={20} placeholder={t('v3:unidad_compra_ej')} className={`${field} w-full`} value={form.purchaseUnit} onChange={(e) => setForm({ ...form, purchaseUnit: e.target.value })} /></label>
        <label className="text-xs font-bold text-slate-700 space-y-1 block">{t('v3:proveedor_preferido')}
          <select className={`${field} w-full`} value={form.preferredSupplierId} onChange={(e) => setForm({ ...form, preferredSupplierId: e.target.value })}>
            <option value="">{t('v3:sin_proveedor')}</option>
            {suppliers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
        </label>
        <p className="text-xs text-slate-500">{t('v3:reposicion_desc')}</p>
        <div className="flex justify-end gap-2 pt-1"><Button type="button" variant="secondary" onClick={onClose}>{t('v3:cancelar')}</Button><Button type="submit" isLoading={saving}>{t('v3:guardar')}</Button></div>
      </form>
    </Modal>
  );
}

// ── Corregir el medio de pago ───────────────────────────────

const METHODS: PaymentMethod[] = ['CASH', 'CARD', 'TRANSFER'];

export function PaymentFixModal({ sale, onClose, onSaved }: { sale: any; onClose: () => void; onSaved: () => void }) {
  const due = useMemo(() => {
    const paid = (sale.payments || []).reduce((a: number, p: any) => a + p.amount, 0);
    return paid > 0 ? paid : sale.total + (sale.tip || 0);
  }, [sale]);
  const initial = useMemo(() => {
    const out: Record<PaymentMethod, number> = { CASH: 0, CARD: 0, TRANSFER: 0 };
    const key = (m: string): PaymentMethod => (m === 'CASH' || m === 'CARD' ? m : 'TRANSFER');
    if ((sale.payments || []).length) for (const p of sale.payments) out[key(p.paymentMethod)] += p.amount;
    else out[key(sale.paymentMethod)] = due;
    return out;
  }, [sale, due]);
  const [amounts, setAmounts] = useState(initial);
  const [reason, setReason] = useState('');
  const [saving, setSaving] = useState(false);

  const sum = METHODS.reduce((a, m) => a + (Number(amounts[m]) || 0), 0);
  const left = due - sum;
  const changed = METHODS.some((m) => Math.round(amounts[m]) !== Math.round(initial[m]));
  const allIn = (m: PaymentMethod) => setAmounts({ CASH: 0, CARD: 0, TRANSFER: 0, [m]: due } as Record<PaymentMethod, number>);

  const save = async () => {
    setSaving(true);
    try {
      const payments: PaymentPart[] = METHODS.filter((m) => amounts[m] > 0).map((m) => ({ method: m, amount: Math.round(amounts[m]) }));
      await opsAPI.correctPayments(sale.id, payments, reason);
      toast.success(t('v3:pago_corregido'));
      onSaved();
      onClose();
    } catch (err: any) {
      toast.error(err?.message || t('v3:no_se_guardo'));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal title={t('v3:corregir_pago')} subtitle={t('v3:corregir_pago_desc', { venta: sale.saleNumber, total: formatCurrency(due) })} onClose={onClose}>
      <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); save(); }}>
        {METHODS.map((m) => (
          <div key={m} className="flex items-center gap-2">
            <label htmlFor={`fix-${m}`} className="flex-1 text-sm font-bold text-slate-900">{t(`v3:metodo_${m}`)}</label>
            <input id={`fix-${m}`} type="number" min={0} step={100} className={`${field} w-36 text-right tabular-nums`} value={amounts[m]} onChange={(e) => setAmounts({ ...amounts, [m]: Math.max(0, Math.round(Number(e.target.value) || 0)) })} />
            <Button type="button" size="sm" variant="outline" onClick={() => allIn(m)}>{t('v3:todo')}</Button>
          </div>
        ))}
        <p role="status" className={`text-sm font-bold ${left === 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
          {left === 0 ? t('v3:pagos_cuadran') : left > 0 ? t('v3:falta_asignar', { valor: formatCurrency(left) }) : t('v3:sobra_asignar', { valor: formatCurrency(-left) })}
        </p>
        <label className="text-xs font-bold text-slate-700 space-y-1 block">{t('v3:motivo_correccion')}<input required minLength={3} maxLength={200} className={`${field} w-full`} value={reason} onChange={(e) => setReason(e.target.value)} /></label>
        <p className="text-xs text-slate-500">{t('v3:corregir_pago_nota')}</p>
        <div className="flex justify-end gap-2 pt-1"><Button type="button" variant="secondary" onClick={onClose}>{t('v3:cancelar')}</Button><Button type="submit" disabled={left !== 0 || !changed || reason.trim().length < 3} isLoading={saving}>{t('v3:guardar_correccion')}</Button></div>
      </form>
    </Modal>
  );
}

// ── Ingredientes que se pueden quitar ───────────────────────

export function IngredientsModal({ product, onClose, onSaved }: { product: { id: string; name: string; ingredients?: unknown }; onClose: () => void; onSaved: () => void }) {
  const [list, setList] = useState<string[]>(() => parseIngredients(product.ingredients));
  const [value, setValue] = useState('');
  const [saving, setSaving] = useState(false);

  const add = () => {
    const names = value.split(',').map((x) => x.trim().slice(0, 40)).filter(Boolean);
    setList((cur) => [...cur, ...names.filter((n) => !cur.some((c) => c.toLowerCase() === n.toLowerCase()))].slice(0, 24));
    setValue('');
  };

  const save = async () => {
    setSaving(true);
    try {
      await opsAPI.setIngredients(product.id, list);
      toast.success(t('v3:guardado'));
      onSaved();
      onClose();
    } catch (err: any) {
      toast.error(err?.message || t('v3:no_se_guardo'));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal title={t('v3:ingredientes')} subtitle={product.name} onClose={onClose}>
      <p className="text-sm text-slate-600">{t('v3:ingredientes_desc')}</p>
      <div className="flex flex-wrap gap-2">
        {list.map((n) => (
          <span key={n} className="inline-flex items-center gap-1 rounded-full bg-slate-100 border border-slate-200 pl-3 pr-1 py-1 text-sm font-semibold text-slate-800">
            {n}
            <button type="button" className="w-8 h-8 inline-flex items-center justify-center rounded-full hover:bg-slate-200" aria-label={t('v3:quitar_frase', { frase: n })} onClick={() => setList(list.filter((x) => x !== n))}><X className="w-4 h-4" aria-hidden /></button>
          </span>
        ))}
        {list.length === 0 && <span className="text-sm text-slate-500">{t('v3:sin_ingredientes')}</span>}
      </div>
      <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); add(); }}>
        <input autoFocus className={`${field} flex-1`} placeholder={t('v3:ingrediente_ej')} aria-label={t('v3:ingrediente_nuevo')} value={value} onChange={(e) => setValue(e.target.value)} />
        <Button type="submit" variant="secondary" leftIcon={<Plus className="w-4 h-4" />}>{t('v3:agregar')}</Button>
      </form>
      <div className="flex justify-end gap-2"><Button type="button" variant="secondary" onClick={onClose}>{t('v3:cancelar')}</Button><Button isLoading={saving} onClick={save}>{t('v3:guardar')}</Button></div>
    </Modal>
  );
}

// ── Reporte de cierre para el dueño ─────────────────────────

export function CloseReportCard({ sessionId }: { sessionId: string }) {
  const [data, setData] = useState<{ text: string; ownerWhatsapp: string; enabled: boolean } | null>(null);
  useEffect(() => { opsAPI.closeReport(sessionId).then(setData).catch(() => setData(null)); }, [sessionId]);
  if (!data || !data.enabled) return null;
  return (
    <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-xl bg-emerald-50 border border-emerald-200">
      <p className="text-xs text-emerald-900 flex-1 min-w-[12rem]">{data.ownerWhatsapp ? t('v3:cierre_listo') : t('v3:cierre_sin_numero')}</p>
      <div className="flex gap-2">
        <Button size="sm" variant="outline" leftIcon={<Copy className="w-4 h-4" />} onClick={() => navigator.clipboard.writeText(data.text).then(() => toast.success(t('v3:copiado'))).catch(() => toast.error(t('v3:no_se_copio')))}>{t('v3:copiar')}</Button>
        {data.ownerWhatsapp && <Button size="sm" variant="success" leftIcon={<MessageCircle className="w-4 h-4" />} onClick={() => openWhatsAppChat(data.ownerWhatsapp, data.text)}>{t('v3:enviar_al_dueno')}</Button>}
      </div>
    </div>
  );
}
