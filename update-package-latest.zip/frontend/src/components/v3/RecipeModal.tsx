// ============================================
// V3 - Receta e ingredientes del producto (Lantify 3.0)
// ============================================
// Un solo lugar para lo que lleva el producto:
//  · Con receta: ingredientes del inventario con su cantidad. El costo del producto
//    sale de aquí, al cobrar se descuentan, y los marcados "se puede quitar" son los
//    que el mesero ofrece en los comentarios ("sin cebolla").
//  · Sin receta: para negocios que no llevan inventario de ingredientes. Solo la
//    lista de lo que se puede quitar; el costo se escribe a mano en Editar producto.

import React, { useEffect, useMemo, useState } from 'react';
import { createPortal } from 'react-dom';
import { ChefHat, ListChecks, Plus, Trash2, X } from 'lucide-react';
import { ingredientsAPI, opsAPI, recipesAPI, type Ingredient, type RecipeView } from '../../services/v3Api';
import { errorMessage } from '../../services/apiErrors';
import { formatCurrency } from '../../shared/formatUtils';
import { parseIngredients } from '../../shared/itemNotes';
import { toast } from '../../shared/toast';
import { t } from '../../i18n';

type Mode = 'recipe' | 'manual';
interface Row { ingredientId: string; quantity: string; removable: boolean }

export const RecipeModal: React.FC<{ product: { id: string; name: string; ingredients?: unknown }; onClose: () => void; onSaved?: () => void }> = ({ product, onClose, onSaved }) => {
  const [ingredients, setIngredients] = useState<Ingredient[]>([]);
  const [rows, setRows] = useState<Row[]>([]);
  const [view, setView] = useState<RecipeView | null>(null);
  const [mode, setMode] = useState<Mode>('recipe');
  const [manual, setManual] = useState<string[]>(() => parseIngredients(product.ingredients));
  const [value, setValue] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    Promise.all([ingredientsAPI.list(), recipesAPI.get(product.id)]).then(([list, r]) => {
      setIngredients(list); setView(r);
      setRows(r.items.length ? r.items.map((i) => ({ ingredientId: i.ingredientId, quantity: String(i.quantity), removable: i.removable !== false })) : [{ ingredientId: '', quantity: '', removable: true }]);
      // Sin receta guardada y con una lista escrita a mano (o sin inventario de ingredientes): se abre en "Sin receta"
      if (!r.items.length && (parseIngredients(product.ingredients).length > 0 || list.length === 0)) setMode('manual');
    }).catch((e) => toast.error(errorMessage(e)));
  }, [product.id, product.ingredients]);

  const byId = useMemo(() => new Map(ingredients.map((i) => [i.id, i])), [ingredients]);
  const cost = rows.reduce((n, r) => n + (Number(r.quantity) || 0) * (byId.get(r.ingredientId)?.avgCost || 0), 0);
  const price = view?.price || 0;
  const margin = price > 0 ? ((price - cost) / price) * 100 : null;
  const min = view?.minMarginPct ?? 30;
  const hadRecipe = !!view?.items.length;
  const removableNames = rows.filter((r) => r.removable && byId.get(r.ingredientId)).map((r) => byId.get(r.ingredientId)!.name);

  const addManual = () => {
    const names = value.split(',').map((x) => x.trim().slice(0, 40)).filter(Boolean);
    setManual((cur) => [...cur, ...names.filter((n) => !cur.some((c) => c.toLowerCase() === n.toLowerCase()))].slice(0, 24));
    setValue('');
  };

  const save = async () => {
    setBusy(true);
    try {
      if (mode === 'recipe') {
        await recipesAPI.set(product.id, rows.filter((r) => r.ingredientId && Number(r.quantity) > 0).map((r) => ({ ingredientId: r.ingredientId, quantity: Number(r.quantity), removable: r.removable })));
        toast.success(t('v3:receta_guardada'));
      } else {
        // Pasar a "sin receta" borra la receta: el costo vuelve a escribirse a mano
        if (hadRecipe) await recipesAPI.set(product.id, []);
        await opsAPI.setIngredients(product.id, manual);
        toast.success(t('v3:guardado'));
      }
      onSaved?.();
      onClose();
    } catch (e) { toast.error(errorMessage(e)); } finally { setBusy(false); }
  };

  const tab = (m: Mode, label: string, Icon: React.ElementType) => (
    <button
      type="button"
      role="tab"
      aria-selected={mode === m}
      onClick={() => setMode(m)}
      className={`inline-flex min-h-[40px] flex-1 items-center justify-center gap-2 rounded-lg px-3 text-sm font-bold transition-colors ${mode === m ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
    >
      <Icon className="h-4 w-4" aria-hidden />{label}
    </button>
  );

  return createPortal(
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/50 p-4" role="presentation" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div role="dialog" aria-modal="true" aria-labelledby="recipe-title" className="flex max-h-[90vh] w-full max-w-2xl flex-col rounded-3xl bg-white shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-100 px-6 py-4">
          <h3 id="recipe-title" className="flex items-center gap-2 font-black text-slate-900"><ChefHat className="h-5 w-5 text-blue-700" aria-hidden />{t('v3:receta_de', { name: product.name })}</h3>
          <button type="button" onClick={onClose} className="rounded-xl p-2 text-slate-400 hover:bg-slate-100" aria-label={t('v3:cancelar')}><X className="h-5 w-5" /></button>
        </div>

        <div className="px-6 pt-4">
          <div role="tablist" aria-label={t('v3:receta_modo')} className="flex gap-1 rounded-xl bg-slate-100 p-1">
            {tab('recipe', t('v3:receta_con'), ChefHat)}
            {tab('manual', t('v3:receta_sin'), ListChecks)}
          </div>
        </div>

        {mode === 'recipe' ? (
          <div className="flex-1 space-y-3 overflow-y-auto px-6 py-4">
            {!ingredients.length && view && <p className="rounded-xl bg-amber-50 p-3 text-sm text-amber-900">{t('v3:receta_sin_ingredientes')}</p>}
            <ul className="space-y-2">
              {rows.map((r, k) => {
                const ing = byId.get(r.ingredientId);
                return (
                  <li key={k} className="grid grid-cols-[1fr_6.5rem_auto] items-center gap-2 sm:grid-cols-[1fr_7rem_5.5rem_auto_auto]">
                    <select aria-label={t('v3:receta_ingrediente')} value={r.ingredientId} onChange={(e) => setRows(rows.map((x, i) => (i === k ? { ...x, ingredientId: e.target.value } : x)))} className="min-w-0 rounded-xl border border-slate-300 px-2 py-2 text-sm">
                      <option value="">{t('v3:receta_elegir')}</option>
                      {ingredients.map((i) => <option key={i.id} value={i.id} disabled={rows.some((x, j) => j !== k && x.ingredientId === i.id)}>{i.name}</option>)}
                    </select>
                    <label className="flex items-center gap-1 text-xs text-slate-600">
                      <input type="number" min={0} step="any" aria-label={t('v3:receta_cantidad')} value={r.quantity} onChange={(e) => setRows(rows.map((x, i) => (i === k ? { ...x, quantity: e.target.value } : x)))} className="w-full rounded-xl border border-slate-300 px-2 py-2 text-sm tabular-nums" />
                      {ing?.unit || ''}
                    </label>
                    <span className="hidden text-right text-sm tabular-nums text-slate-700 sm:block">{ing ? formatCurrency((Number(r.quantity) || 0) * ing.avgCost) : '—'}</span>
                    <label className="col-span-2 flex items-center gap-1.5 text-xs font-semibold text-slate-700 sm:col-span-1" title={t('v3:receta_quitable_ayuda')}>
                      <input type="checkbox" checked={r.removable} onChange={(e) => setRows(rows.map((x, i) => (i === k ? { ...x, removable: e.target.checked } : x)))} className="h-4 w-4 rounded border-slate-300" />
                      {t('v3:receta_quitable')}
                    </label>
                    <button type="button" onClick={() => setRows(rows.filter((_, i) => i !== k))} className="justify-self-end rounded-lg p-2 text-slate-400 hover:bg-rose-50 hover:text-rose-700" aria-label={t('v3:quitar')}><Trash2 className="h-4 w-4" /></button>
                  </li>
                );
              })}
            </ul>
            <button type="button" onClick={() => setRows([...rows, { ingredientId: '', quantity: '', removable: true }])} className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-dashed border-slate-300 px-3 text-sm font-bold text-slate-700 hover:bg-slate-50"><Plus className="h-4 w-4" aria-hidden />{t('v3:receta_agregar')}</button>
            <p className="text-xs text-slate-500">{t('v3:receta_ayuda')}</p>
            {removableNames.length > 0 && (
              <p className="rounded-xl bg-slate-50 p-3 text-xs text-slate-700">
                <span className="font-bold">{t('v3:receta_en_comentarios')}</span> {removableNames.join(', ')}
              </p>
            )}
          </div>
        ) : (
          <div className="flex-1 space-y-3 overflow-y-auto px-6 py-4">
            <p className="text-sm text-slate-600">{t('v3:receta_sin_desc')}</p>
            {hadRecipe && <p className="rounded-xl bg-amber-50 p-3 text-sm text-amber-900">{t('v3:receta_se_borra')}</p>}
            <div className="flex flex-wrap gap-2">
              {manual.map((n) => (
                <span key={n} className="inline-flex items-center gap-1 rounded-full border border-slate-200 bg-slate-100 py-1 pl-3 pr-1 text-sm font-semibold text-slate-800">
                  {n}
                  <button type="button" className="inline-flex h-8 w-8 items-center justify-center rounded-full hover:bg-slate-200" aria-label={t('v3:quitar_frase', { frase: n })} onClick={() => setManual(manual.filter((x) => x !== n))}><X className="h-4 w-4" aria-hidden /></button>
                </span>
              ))}
              {manual.length === 0 && <span className="text-sm text-slate-500">{t('v3:sin_ingredientes')}</span>}
            </div>
            <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); addManual(); }}>
              <input className="min-w-0 flex-1 rounded-xl border border-slate-300 px-3 py-2 text-sm" placeholder={t('v3:ingrediente_ej')} aria-label={t('v3:ingrediente_nuevo')} value={value} onChange={(e) => setValue(e.target.value)} />
              <button type="submit" className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-slate-300 px-3 text-sm font-bold text-slate-700 hover:bg-slate-50"><Plus className="h-4 w-4" aria-hidden />{t('v3:agregar')}</button>
            </form>
            <p className="text-xs text-slate-500">{t('v3:receta_costo_manual')}</p>
          </div>
        )}

        <div className="flex flex-wrap items-center gap-4 border-t border-slate-100 px-6 py-4">
          {mode === 'recipe' ? (
            <dl className="flex flex-1 flex-wrap gap-5 text-sm">
              <div><dt className="text-xs text-slate-500">{t('v3:receta_costo')}</dt><dd className="font-black tabular-nums">{formatCurrency(Math.round(cost))}</dd></div>
              <div><dt className="text-xs text-slate-500">{t('v3:receta_precio')}</dt><dd className="font-black tabular-nums">{formatCurrency(price)}</dd></div>
              <div><dt className="text-xs text-slate-500">{t('v3:receta_margen')}</dt><dd className={`font-black tabular-nums ${margin !== null && margin < min ? 'text-rose-700' : 'text-emerald-700'}`}>{margin === null ? '—' : `${margin.toFixed(1)} %`}</dd></div>
            </dl>
          ) : <span className="flex-1" />}
          <button type="button" onClick={save} disabled={busy || !view} className="min-h-[44px] rounded-xl bg-slate-900 px-5 text-sm font-bold text-white disabled:opacity-60">{t('v3:guardar')}</button>
        </div>
      </div>
    </div>,
    document.body,
  );
};
