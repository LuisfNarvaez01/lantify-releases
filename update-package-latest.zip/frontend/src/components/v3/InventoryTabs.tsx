// ============================================
// V3 - Inventario: Productos e Ingredientes en subpestañas (Lantify 3.0)
// ============================================

import React, { useState } from 'react';
import { Boxes, Wheat } from 'lucide-react';
import { InventoryModule } from '../admin/InventoryModule';
import { IngredientsPanel } from './IngredientsPanel';
import { t } from '../../i18n';

export const InventoryTabs: React.FC = () => {
  const [tab, setTab] = useState<'products' | 'ingredients'>('products');
  return (
    <div className="space-y-4">
      <div className="inline-flex gap-1 rounded-2xl bg-slate-100 p-1" role="tablist" aria-label={t('v3:inv_tabs')}>
        {([['products', Boxes], ['ingredients', Wheat]] as const).map(([id, Icon]) => (
          <button key={id} type="button" role="tab" aria-selected={tab === id} onClick={() => setTab(id)} className={`inline-flex min-h-[40px] items-center gap-2 rounded-xl px-4 text-sm font-bold ${tab === id ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}>
            <Icon className="h-4 w-4" aria-hidden />{t(`v3:inv_tab_${id}`)}
          </button>
        ))}
      </div>
      {tab === 'products' ? <InventoryModule /> : <IngredientsPanel />}
    </div>
  );
};
