// ============================================
// V3 - Inventario → Carga rápida de ingredientes (Fase 4 · mejoras)
// ============================================
// Un restaurante tiene decenas de ingredientes: crearlos uno por uno cansa. Dos
// caminos rápidos (además de la factura, que los crea al registrar la compra):
//   · Pegar una lista de Excel o WhatsApp: nombre, unidad, costo, existencia…
//   · Marcar los de un catálogo base de cocina colombiana.

import React, { useMemo, useState } from 'react';
import { ClipboardPaste, ListChecks } from 'lucide-react';
import { planningAPI, type BulkIngredientRow } from '../../services/v3Api';
import { errorMessage } from '../../services/apiErrors';
import { formatCurrency } from '../../shared/formatUtils';
import { toast } from '../../shared/toast';
import { Button } from '../common/Button';
import { t } from '../../i18n';
import { fmtQty } from './IngredientsPanel';
import { nameKey, parseIngredientList } from '../../../../src/domain/v3/recipePlanning';

/** Lo más común en una cocina en Colombia, por categoría */
const CATALOG: Record<string, [string, 'g' | 'ml' | 'und'][]> = {
  'Carnes': [['Carne de res', 'g'], ['Carne molida', 'g'], ['Pechuga de pollo', 'g'], ['Pollo entero', 'g'], ['Cerdo', 'g'], ['Tocineta', 'g'], ['Chorizo', 'und'], ['Salchicha', 'und'], ['Jamón', 'g'], ['Pescado', 'g'], ['Camarón', 'g']],
  'Lácteos y huevos': [['Huevo', 'und'], ['Queso mozzarella', 'g'], ['Queso campesino', 'g'], ['Queso cheddar', 'g'], ['Leche', 'ml'], ['Crema de leche', 'ml'], ['Mantequilla', 'g'], ['Suero costeño', 'ml']],
  'Verduras y frutas': [['Tomate', 'g'], ['Cebolla cabezona', 'g'], ['Cebolla larga', 'g'], ['Lechuga', 'g'], ['Papa', 'g'], ['Papa criolla', 'g'], ['Plátano verde', 'und'], ['Plátano maduro', 'und'], ['Yuca', 'g'], ['Aguacate', 'und'], ['Limón', 'und'], ['Cilantro', 'g'], ['Ajo', 'g'], ['Pimentón', 'g'], ['Mango', 'g'], ['Fresa', 'g'], ['Maracuyá', 'g'], ['Mora', 'g'], ['Lulo', 'g']],
  'Panadería y granos': [['Pan de hamburguesa', 'und'], ['Pan de perro', 'und'], ['Arepa', 'und'], ['Tortilla de harina', 'und'], ['Arroz', 'g'], ['Fríjol', 'g'], ['Lenteja', 'g'], ['Harina de trigo', 'g'], ['Masa de maíz', 'g'], ['Pasta', 'g']],
  'Salsas y abarrotes': [['Aceite', 'ml'], ['Sal', 'g'], ['Azúcar', 'g'], ['Salsa de tomate', 'g'], ['Mayonesa', 'g'], ['Mostaza', 'g'], ['Salsa BBQ', 'g'], ['Salsa de piña', 'g'], ['Papas fritas (ripio)', 'g'], ['Café', 'g'], ['Chocolate', 'g']],
  'Bebidas': [['Gaseosa 400 ml', 'und'], ['Agua en botella', 'und'], ['Cerveza', 'und'], ['Jugo en caja', 'ml'], ['Hielo', 'g'], ['Aguardiente', 'ml'], ['Ron', 'ml']],
  'Empaques': [['Caja para hamburguesa', 'und'], ['Vaso desechable', 'und'], ['Tapa para vaso', 'und'], ['Pitillo', 'und'], ['Servilleta', 'und'], ['Bolsa', 'und'], ['Contenedor icopor', 'und']],
};

export const IngredientBulk: React.FC<{ existing: string[]; onDone: () => void }> = ({ existing, onDone }) => {
  const [mode, setMode] = useState<'paste' | 'catalog'>('paste');
  const [text, setText] = useState('');
  const [picked, setPicked] = useState<Set<string>>(new Set());
  const [busy, setBusy] = useState(false);
  const have = useMemo(() => new Set(existing.map(nameKey)), [existing]);
  const rows = useMemo(() => parseIngredientList(text), [text]);
  const valid = rows.filter((r) => !r.error && !have.has(nameKey(r.name)));

  const create = async (list: BulkIngredientRow[]) => {
    if (!list.length) return;
    setBusy(true);
    try {
      const r = await planningAPI.bulkIngredients(list);
      toast.success(t('v3:bulk_creados', { count: r.created }));
      onDone();
    } catch (err) { toast.error(errorMessage(err)); } finally { setBusy(false); }
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-1 rounded-xl bg-slate-100 p-1" role="tablist">
        {([['paste', ClipboardPaste], ['catalog', ListChecks]] as const).map(([id, Icon]) => (
          <button key={id} type="button" role="tab" aria-selected={mode === id} onClick={() => setMode(id)} className={`inline-flex min-h-[40px] items-center justify-center gap-2 rounded-lg text-sm font-bold ${mode === id ? 'bg-white shadow-sm' : 'text-slate-600'}`}><Icon className="h-4 w-4" aria-hidden />{t(`v3:bulk_${id}`)}</button>
        ))}
      </div>
      {mode === 'paste' ? (
        <>
          <p className="text-sm text-slate-600">{t('v3:bulk_paste_desc')}</p>
          <textarea value={text} onChange={(e) => setText(e.target.value)} rows={7} className="w-full rounded-xl border border-slate-300 p-3 font-mono text-sm" placeholder={'Tomate; kg; 3.500; 10; 2; Verduras\nHuevo; und; 500; 60; 30\nAceite; l; 9.000; 5'} aria-label={t('v3:bulk_paste')} />
          {rows.length > 0 && (
            <div className="max-h-56 overflow-y-auto rounded-xl border border-slate-200">
              <table className="w-full text-xs">
                <thead className="sticky top-0 bg-slate-50 text-left text-slate-500"><tr><th className="px-2 py-1.5">{t('v3:ing_nombre')}</th><th className="text-right">{t('v3:ing_existencia_col')}</th><th className="text-right">{t('v3:ing_costo_col')}</th><th className="px-2" /></tr></thead>
                <tbody className="divide-y divide-slate-100">
                  {rows.map((r, i) => {
                    const dup = have.has(nameKey(r.name));
                    return (
                      <tr key={i} className={r.error || dup ? 'text-slate-400' : ''}>
                        <td className="px-2 py-1.5 font-semibold">{r.name}</td>
                        <td className="text-right tabular-nums">{r.stock !== null ? fmtQty(r.stock, r.unit) : '—'}</td>
                        <td className="text-right tabular-nums">{r.costPerBase !== null ? (r.unit === 'und' ? formatCurrency(r.costPerBase) : `${formatCurrency(r.costPerBase * 1000)}/${r.unit === 'g' ? 'kg' : 'l'}`) : '—'}</td>
                        <td className="px-2 text-right font-bold">{r.error ? <span className="text-rose-700">{t('v3:bulk_unidad_rara')}</span> : dup ? t('v3:bulk_ya_existe') : <span className="text-emerald-700">✓</span>}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
          <Button className="w-full" disabled={!valid.length} isLoading={busy} onClick={() => create(valid.map((r) => ({ name: r.name, unit: r.unit, costPerBase: r.costPerBase, stock: r.stock, minStock: r.minStock, category: r.category })))}>{t('v3:bulk_crear_n', { count: valid.length })}</Button>
        </>
      ) : (
        <>
          <p className="text-sm text-slate-600">{t('v3:bulk_catalog_desc')}</p>
          <div className="max-h-[22rem] space-y-3 overflow-y-auto pr-1">
            {Object.entries(CATALOG).map(([cat, items]) => (
              <fieldset key={cat}>
                <legend className="mb-1.5 text-xs font-black uppercase tracking-wide text-slate-500">{cat}</legend>
                <div className="flex flex-wrap gap-1.5">
                  {items.map(([name]) => {
                    const dup = have.has(nameKey(name));
                    const on = picked.has(name);
                    return (
                      <button key={name} type="button" disabled={dup} aria-pressed={on} onClick={() => setPicked((s) => { const n = new Set(s); if (n.has(name)) n.delete(name); else n.add(name); return n; })} className={`min-h-[36px] rounded-full border px-3 text-sm font-semibold transition ${dup ? 'border-slate-100 text-slate-300 line-through' : on ? 'border-blue-600 bg-blue-600 text-white' : 'border-slate-200 text-slate-700 hover:border-slate-300'}`}>{name}</button>
                    );
                  })}
                </div>
              </fieldset>
            ))}
          </div>
          <Button className="w-full" disabled={!picked.size} isLoading={busy} onClick={() => create(Object.entries(CATALOG).flatMap(([cat, items]) => items.filter(([n]) => picked.has(n)).map(([name, unit]) => ({ name, unit, category: cat }))))}>{t('v3:bulk_crear_n', { count: picked.size })}</Button>
          <p className="text-xs text-slate-500">{t('v3:bulk_catalog_nota')}</p>
        </>
      )}
    </div>
  );
};
