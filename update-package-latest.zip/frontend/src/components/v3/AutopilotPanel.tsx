// ============================================
// V3 - Autopilot (Lantify 3.0 · bloque 4)
// ============================================
// Botón con el número de situaciones abiertas y un panel con el diagnóstico,
// las intervenciones (Lantify las ejecuta al aceptar), lo que ya hizo (con
// Deshacer) y lo que sabe del negocio. Cada rol ve su recorte (lo da el servidor).

import React, { useCallback, useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { Brain, Check, Clock, Loader2, MessageCircle, Radar, RotateCcw, X } from 'lucide-react';
import { autopilotAPI, type AutopilotAction, type AutopilotKnowledge, type AutopilotSituation, type AutopilotState } from '../../services/v3Api';
import { errorMessage } from '../../services/apiErrors';
import { useFeatureFlag, useFeatures } from '../../shared/features';
import { usePosStore } from '../../store/usePosStore';
import { toast } from '../../shared/toast';
import { formatTableElapsed } from '../pos/tableSelection';
import { t } from '../../i18n';
import type { Intervention } from '../../../../src/domain/v3/autopilot';

const POLL_MS = 30_000;
let shared: { state: AutopilotState | null; at: number } = { state: null, at: 0 };

export const useAutopilot = (enabled: boolean) => {
  const [state, setState] = useState<AutopilotState | null>(shared.state);
  const load = useCallback(async () => {
    try {
      const s = await autopilotAPI.state();
      shared = { state: s, at: Date.now() };
      setState(s);
    } catch { /* sin conexión: se conserva lo último */ }
  }, []);
  useEffect(() => {
    if (!enabled) return;
    load();
    const id = setInterval(() => { if (!document.hidden) load(); }, POLL_MS);
    return () => clearInterval(id);
  }, [enabled, load]);
  return { state, reload: load };
};

const useProductNames = () => {
  const products = usePosStore((s) => s.products);
  return (ids: string[] = []) => ids.map((id) => products.find((p) => p.id === id)?.name).filter(Boolean).join(', ');
};

/** Texto de una intervención con sus parámetros */
const interventionText = (iv: Pick<Intervention, 'kind' | 'params'>, names: (ids: string[]) => string) => {
  const p = iv.params || {};
  const list = names(p.productIds);
  switch (iv.kind) {
    case 'boost_products': return t('v3:ap_i_boost', { products: list || t('v3:ap_productos'), minutes: p.minutes });
    case 'pause_products': return p.untilClose ? t('v3:ap_i_pause_close', { products: list || t('v3:ap_productos') }) : t('v3:ap_i_pause', { products: list || t('v3:ap_productos'), minutes: p.minutes });
    case 'notify_staff': return t('v3:ap_i_notify', { message: t(`v3:ap_n_${p.message}`, p) });
    case 'flash_coupon': return t('v3:ap_i_coupon', { percent: p.percent, hours: p.hours });
    case 'call_staff': return t('v3:ap_i_call');
  }
};

const SEVERITY = { high: 'border-l-rose-500', medium: 'border-l-amber-400' } as const;

function SituationCard({ s, onDone, ownerWhatsapp }: { s: AutopilotSituation; onDone: () => void; ownerWhatsapp: string }) {
  const names = useProductNames();
  const [busy, setBusy] = useState<string | null>(null);
  const [params, setParams] = useState<Record<string, Record<string, number>>>({});
  const [contacts, setContacts] = useState<{ name: string; phone: string }[] | null>(null);
  const title = t(`v3:ap_t_${s.kind}`, s.evidence as any);
  const diagnosis = t(`v3:ap_d_${s.kind}`, s.evidence as any);

  const act = async (iv: Intervention) => {
    setBusy(iv.id);
    try {
      const r = await autopilotAPI.decide(s.id, iv.id, params[iv.id] || {});
      if (iv.kind === 'call_staff') setContacts(r.action.result?.contacts || []);
      else onDone();
      toast.success(iv.kind === 'flash_coupon' ? t('v3:ap_cupon_listo', { code: r.action.result?.code }) : t('v3:ap_hecho'));
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusy(null);
    }
  };

  const ownerText = encodeURIComponent(`${t('v3:ap_wa_dueno', { title })}\n${diagnosis}\nhttps://lantifypos.dpdns.org/cuenta`);
  const wa = ownerWhatsapp.replace(/\D/g, '');

  return (
    <article className={`rounded-2xl border border-slate-200 border-l-4 bg-white p-4 shadow-xs ${SEVERITY[s.severity]}`}>
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="font-black text-slate-900">{title}</h3>
          <p className="mt-0.5 text-sm text-slate-700">{diagnosis}</p>
        </div>
        <span className="inline-flex shrink-0 items-center gap-1 text-xs text-slate-500"><Clock className="h-3.5 w-3.5" aria-hidden />{formatTableElapsed(s.firstSeenAt)}</span>
      </div>
      <p className="mt-3 text-[11px] font-bold uppercase tracking-wide text-slate-500">{t('v3:ap_propone')}</p>
      <ul className="mt-1.5 space-y-2">
        {s.interventions.map((iv) => {
          const editable = ['minutes', 'percent'].find((k) => k in (iv.params || {}) && typeof iv.params[k] === 'number');
          const value = params[iv.id]?.[editable || ''] ?? iv.params?.[editable || ''];
          return (
            <li key={iv.id} className="flex flex-wrap items-center gap-2 rounded-xl bg-slate-50 px-3 py-2">
              <span className="min-w-0 flex-1 text-sm text-slate-800">{interventionText({ kind: iv.kind, params: { ...iv.params, ...(params[iv.id] || {}) } }, names)}</span>
              {editable && (
                <label className="inline-flex items-center gap-1 text-xs text-slate-600">
                  <input type="number" min={editable === 'percent' ? 5 : 5} max={editable === 'percent' ? 30 : 240} value={value} onChange={(e) => setParams((p) => ({ ...p, [iv.id]: { [editable]: Number(e.target.value) } }))} className="w-16 rounded-lg border border-slate-300 px-2 py-1 text-sm tabular-nums" aria-label={t(`v3:ap_param_${editable}`)} />
                  {editable === 'percent' ? '%' : t('v3:minutos')}
                </label>
              )}
              <button type="button" disabled={busy !== null} onClick={() => act(iv)} className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl bg-slate-900 px-3 text-sm font-bold text-white disabled:opacity-50">
                {busy === iv.id ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <Check className="h-4 w-4" aria-hidden />}{t('v3:ap_hacerlo')}
              </button>
            </li>
          );
        })}
      </ul>
      {contacts && (
        <ul className="mt-2 space-y-1">
          {contacts.length === 0 && <li className="text-xs text-slate-500">{t('v3:ap_sin_contactos')}</li>}
          {contacts.map((c) => (
            <li key={c.phone}><a href={`https://wa.me/57${c.phone.replace(/\D/g, '').replace(/^57/, '')}?text=${encodeURIComponent(t('v3:ap_wa_llamar'))}`} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 text-sm font-bold text-emerald-700 underline"><MessageCircle className="h-4 w-4" aria-hidden />{c.name}</a></li>
          ))}
        </ul>
      )}
      <div className="mt-3 flex flex-wrap items-center gap-2">
        <button type="button" onClick={async () => { await autopilotAPI.dismiss(s.id).catch(() => undefined); onDone(); }} className="min-h-[36px] rounded-lg px-3 text-xs font-bold text-slate-600 hover:bg-slate-100">{t('v3:ap_descartar')}</button>
        {wa && (
          <a href={`https://wa.me/${wa.length === 10 ? `57${wa}` : wa}?text=${ownerText}`} target="_blank" rel="noreferrer" className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg px-3 text-xs font-bold text-emerald-700 hover:bg-emerald-50"><MessageCircle className="h-4 w-4" aria-hidden />{t('v3:ap_avisar_dueno')}</a>
        )}
        {s.ownerNotified && <span className="text-xs text-slate-500">{t('v3:ap_dueno_avisado')}</span>}
      </div>
    </article>
  );
}

function Knowledge() {
  const [k, setK] = useState<AutopilotKnowledge | null>(null);
  useEffect(() => { autopilotAPI.knowledge().then(setK).catch(() => setK(null)); }, []);
  if (!k) return <p className="py-8 text-center text-sm text-slate-500"><Loader2 className="mx-auto h-5 w-5 animate-spin" aria-label={t('v3:cargando')} /></p>;
  const max = Math.max(1, ...k.todayByHour.map((h) => h.sales));
  const hours = k.todayByHour.filter((h) => h.sales > 0 || (h.hour >= 8 && h.hour <= 23));
  return (
    <div className="space-y-4 text-sm text-slate-700">
      <p>{k.ready ? t('v3:ap_sabe_listo', { days: k.historyDays }) : t('v3:ap_sabe_aprendiendo', { days: k.historyDays, min: k.minDays })}</p>
      <figure>
        <figcaption className="text-xs font-bold text-slate-600">{t('v3:ap_normal_hoy')}</figcaption>
        <div className="mt-2 flex h-24 items-end gap-0.5" role="img" aria-label={t('v3:ap_normal_hoy')}>
          {hours.map((h) => <div key={h.hour} title={`${h.hour}:00 · ${h.sales}`} className="flex-1 rounded-t bg-blue-500/80" style={{ height: `${(h.sales / max) * 100}%`, minHeight: h.sales ? 2 : 0 }} />)}
        </div>
        <div className="flex justify-between text-[10px] text-slate-500"><span>{hours[0]?.hour}:00</span><span>{hours[hours.length - 1]?.hour}:00</span></div>
      </figure>
      <dl className="grid grid-cols-2 gap-2">
        <div className="rounded-xl bg-slate-50 p-3"><dt className="text-xs text-slate-500">{t('v3:ap_tiempo_cocina')}</dt><dd className="text-lg font-black tabular-nums">{k.prepAll ? `${Math.round(k.prepAll.median)}–${Math.round(k.prepAll.p80)} min` : '—'}</dd></div>
        <div className="rounded-xl bg-slate-50 p-3"><dt className="text-xs text-slate-500">{t('v3:ap_capacidad')}</dt><dd className="text-lg font-black tabular-nums">{k.capacity30 ? t('v3:ap_capacidad_n', { n: k.capacity30 }) : '—'}</dd></div>
      </dl>
      {k.slowest.length > 0 && <p><span className="font-bold">{t('v3:ap_lentos')}:</span> {k.slowest.map((x) => `${x.name} (${Math.round(x.minutes)} min)`).join(', ')}</p>}
      {!k.prepAll && <p className="text-xs text-slate-500">{t('v3:ap_sin_tiempos')}</p>}
    </div>
  );
}

function Panel({ state, role, onClose, reload }: { state: AutopilotState; role: string; onClose: () => void; reload: () => void }) {
  const names = useProductNames();
  const ownerWhatsapp = useFeatures((s) => s.settings.ownerWhatsapp) || '';
  const [tab, setTab] = useState<'now' | 'knows'>('now');
  const active = state.actions.filter((a) => a.status === 'DONE');
  const revert = async (a: AutopilotAction) => {
    try { await autopilotAPI.revert(a.id); reload(); toast.success(t('v3:ap_deshecho')); } catch (e) { toast.error(errorMessage(e)); }
  };
  return createPortal(
    <div className="fixed inset-0 z-[85] flex justify-end bg-slate-950/40" role="presentation" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <aside role="dialog" aria-modal="true" aria-labelledby="ap-title" className="flex h-full w-full max-w-lg flex-col bg-slate-50 shadow-2xl">
        <header className="flex items-center gap-3 border-b border-slate-200 bg-white px-5 py-4">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-slate-900 text-white"><Radar className="h-5 w-5" aria-hidden /></span>
          <div className="min-w-0 flex-1">
            <h2 id="ap-title" className="font-black text-slate-900">Autopilot</h2>
            <p className="text-xs text-slate-500">{state.learning ? t('v3:ap_aprendiendo', { days: state.learning.historyDays, min: state.learning.minDays }) : t('v3:ap_vigilando')}</p>
          </div>
          <button type="button" onClick={onClose} className="rounded-xl p-2 text-slate-500 hover:bg-slate-100" aria-label={t('pos:cerrar')}><X className="h-5 w-5" /></button>
        </header>
        {role === 'ADMIN' && (
          <div className="flex gap-1 border-b border-slate-200 bg-white px-5" role="tablist">
            {(['now', 'knows'] as const).map((k) => (
              <button key={k} type="button" role="tab" aria-selected={tab === k} onClick={() => setTab(k)} className={`-mb-px border-b-2 px-3 py-2.5 text-sm font-bold ${tab === k ? 'border-slate-900 text-slate-900' : 'border-transparent text-slate-500'}`}>
                {k === 'now' ? t('v3:ap_ahora') : <span className="inline-flex items-center gap-1.5"><Brain className="h-4 w-4" aria-hidden />{t('v3:ap_lo_que_sabe')}</span>}
              </button>
            ))}
          </div>
        )}
        <div className="flex-1 space-y-4 overflow-y-auto p-5">
          {tab === 'knows' ? <Knowledge /> : (
            <>
              {state.situations.length === 0 && (
                <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-5 text-center">
                  <Check className="mx-auto h-8 w-8 text-emerald-600" aria-hidden />
                  <p className="mt-2 font-bold text-emerald-900">{t('v3:ap_todo_bien')}</p>
                  <p className="text-sm text-emerald-800">{t('v3:ap_todo_bien_d')}</p>
                </div>
              )}
              {state.situations.map((s) => <SituationCard key={s.id} s={s} ownerWhatsapp={ownerWhatsapp} onDone={reload} />)}
              {active.length > 0 && (
                <section>
                  <h3 className="text-[11px] font-bold uppercase tracking-wide text-slate-500">{t('v3:ap_en_marcha')}</h3>
                  <ul className="mt-2 space-y-2">
                    {active.map((a) => (
                      <li key={a.id} className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm">
                        <span className="min-w-0 flex-1">{interventionText(a, names)}<span className="block text-xs text-slate-500">{a.source === 'OWNER' ? t('v3:ap_por_dueno') : a.decidedBy || ''}{a.revertAt ? ` · ${t('v3:ap_hasta', { hora: new Date(a.revertAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) })}` : ''}</span></span>
                        {['pause_products', 'boost_products', 'flash_coupon'].includes(a.kind) && (
                          <button type="button" onClick={() => revert(a)} className="inline-flex min-h-[36px] items-center gap-1 rounded-lg px-2.5 text-xs font-bold text-slate-700 hover:bg-slate-100"><RotateCcw className="h-3.5 w-3.5" aria-hidden />{t('v3:ap_deshacer')}</button>
                        )}
                      </li>
                    ))}
                  </ul>
                </section>
              )}
            </>
          )}
        </div>
      </aside>
    </div>,
    document.body,
  );
}

/** Botón de Autopilot (barra superior de la caja y del celular) */
export const AutopilotButton: React.FC<{ role: string; tone?: 'dark' | 'light' }> = ({ role, tone = 'dark' }) => {
  const on = useFeatureFlag('autopilot') && (role === 'ADMIN' || role === 'CASHIER');
  const { state, reload } = useAutopilot(on);
  const [open, setOpen] = useState(false);
  if (!on) return null;
  const count = state?.situations.length || 0;
  const high = state?.situations.some((s) => s.severity === 'high');
  return (
    <>
      <button
        type="button"
        onClick={() => { setOpen(true); reload(); }}
        aria-label={count ? t('v3:ap_boton_n', { count }) : t('v3:ap_boton')}
        title="Autopilot"
        className={`relative inline-flex h-10 w-10 items-center justify-center rounded-xl transition-colors ${tone === 'dark' ? 'text-slate-300 hover:bg-slate-800 hover:text-white' : 'text-slate-700 hover:bg-slate-100'}`}
      >
        <Radar className={`h-5 w-5 ${high ? 'text-rose-400' : ''}`} aria-hidden />
        {count > 0 && <span className={`absolute -right-0.5 -top-0.5 grid h-5 min-w-[1.25rem] place-items-center rounded-full px-1 text-[11px] font-black text-white ${high ? 'bg-rose-600 animate-pulse' : 'bg-amber-500'}`}>{count}</span>}
      </button>
      {open && state && <Panel state={state} role={role} onClose={() => setOpen(false)} reload={reload} />}
    </>
  );
};
