// ============================================
// V3 - "Ofrece primero": sugerencias al mesero (Lantify 3.0 · bloque 4)
// ============================================
// 2–3 productos con su porqué. Un toque los agrega al pedido. Se calcula en la
// caja con el motor de menú; aquí solo se muestran.

import React, { useEffect, useRef, useState } from 'react';
import { Plus, Sparkles } from 'lucide-react';
import { usePosStore } from '../../store/usePosStore';
import { useFeatureFlag } from '../../shared/features';
import { menuAPI } from '../../services/v3Api';
import { t } from '../../i18n';
import type { Suggestion } from '../../../../src/domain/v3/menuEngine';

const reasonText = (s: Suggestion) =>
  s.reason === 'PAIRS' ? t('v3:sug_pairs', { ofTen: s.ofTen, with: s.with })
    : s.reason === 'BOOST' ? t('v3:sug_boost')
      : s.reason === 'STAR_NOW' ? t('v3:sug_star') : t('v3:sug_puzzle');

export const SuggestionsBar: React.FC<{ variant?: 'phone' | 'desk' }> = ({ variant = 'desk' }) => {
  const on = useFeatureFlag('waiter_suggestions');
  const { products, addToCart, openVariantModal, getCurrentCart } = usePosStore();
  const cart = getCurrentCart();
  const cartKey = [...new Set(cart.map((i) => i.productId))].sort().join(',');
  const [items, setItems] = useState<Suggestion[]>([]);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (!on) return;
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => {
      menuAPI.suggestions(cartKey ? cartKey.split(',') : []).then((r) => setItems(r.suggestions)).catch(() => setItems([]));
    }, 350);
    return () => { if (timer.current) clearTimeout(timer.current); };
  }, [on, cartKey]);

  if (!on || items.length === 0) return null;

  const pick = (s: Suggestion) => {
    const product = products.find((p) => p.id === s.productId);
    if (!product || !product.variants?.length) return;
    if (product.variants.length > 1) openVariantModal(product);
    else addToCart(product, product.variants[0]);
    menuAPI.event(s.productId, s.reason, true).catch(() => undefined);
  };

  const phone = variant === 'phone';
  return (
    <section aria-label={t('v3:ofrece_primero')} className={`rounded-2xl border border-violet-200 bg-gradient-to-r from-violet-50 to-white ${phone ? 'p-2.5' : 'p-3'}`}>
      <p className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-violet-800"><Sparkles className="h-3.5 w-3.5" aria-hidden />{t('v3:ofrece_primero')}</p>
      <ul className={`mt-2 flex gap-2 ${phone ? 'overflow-x-auto -mx-1 px-1 pb-0.5' : 'flex-wrap'}`}>
        {items.map((s) => (
          <li key={s.productId} className="shrink-0">
            <button type="button" onClick={() => pick(s)} className="flex min-h-[48px] items-center gap-2 rounded-xl border border-violet-200 bg-white px-3 py-1.5 text-left shadow-xs hover:border-violet-400 active:bg-violet-50">
              <span className="grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-violet-600 text-white"><Plus className="h-4 w-4" aria-hidden /></span>
              <span className="min-w-0">
                <span className="block max-w-[11rem] truncate text-sm font-bold text-slate-900">{s.name}</span>
                <span className="block max-w-[13rem] truncate text-[11px] text-slate-600">{reasonText(s)}</span>
              </span>
            </button>
          </li>
        ))}
      </ul>
    </section>
  );
};
