// ============================================
// V3 - Inventario de ingredientes (Lantify 3.0)
// ============================================
// Insumos por gramo, mililitro o unidad: existencias, costo promedio, mínimo,
// ajustes (ajuste, desperdicio, conteo) y el kardex de cada uno. Arriba, los
// productos con receta cuyo margen quedó por debajo del mínimo.

import React, { useEffect, useMemo, useState } from 'react';
import { createPortal } from 'react-dom';
import { AlertTriangle, History, Pencil, Plus, Scale, Search, Trash2, X } from 'lucide-react';
import { ingredientsAPI, recipesAPI, type Ingredient, type IngredientMovement } from '../../services/v3Api';
import { errorMessage } from '../../services/apiErrors';
import { formatCurrency } from '../../shared/formatUtils';
import { toast } from '../../shared/toast';
import { confirmDialog } from '../../shared/dialog';
import { t, getLocale } from '../../i18n';

const field = 'w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/40';

/** Cantidades legibles: 1.500 g → 1,5 kg; 750 ml → 750 ml */
export const fmtQty = (q: number, unit: string) => {
  const abs = Math.abs(q);
  if (unit === 'g' && abs >= 1000) return `${(q / 1000).toLocaleString(getLocale(), { maximumFractionDigits: 2 })} kg`;
  if (unit === 'ml' && abs >= 1000) return `${(q / 1000).toLocaleString(getLocale(), { maximumFractionDigits: 2 })} l`;
  return `${q.toLocaleString(getLocale(), { maximumFractionDigits: 2 })} ${unit}`;
};
/** Costo por kilo, litro o unidad (más fácil de leer que por gramo) */
export const fmtCost = (perBase: number, unit: string) =>
  unit === 'und' ? `${formatCurrency(perBase)} / und` : `${formatCurrency(perBase * 1000)} / ${unit === 'g' ? 'kg' : 'l'}`;

function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  return createPortal(
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/50 p-4" role="presentation" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div role="dialog" aria-modal="true" aria-label={title} className="flex max-h-[90vh] w-full max-w-lg flex-col rounded-3xl bg-white shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-100 px-6 py-4">
          <h3 className="font-black text-slate-900">{title}</h3>
          <button type="button" onClick={onClose} className="rounded-xl p-2 text-slate-400 hover:bg-slate-100" aria-label={t('v3:cancelar')}><X className="h-5 w-5" /></button>
        </div>
        <div className="flex-1 overflow-y-auto px-6 py-4">{children}</div>
      </div>
    </div>,
    document.body,
  );
}

function EditForm({ item, onDone }: { item: Ingredient | null; onDone: () => void }) {
  const [f, setF] = useState({ name: item?.name || '', unit: item?.unit || 'g', minStock: item?.minStock ?? '', category: item?.category || '', avgCost: item ? item.avgCost * (item.unit === 'und' ? 1 : 1000) : '', stock: '' as any });
  const [busy, setBusy] = useState(false);
  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      const per = f.unit === 'und' ? 1 : 1000;
      await ingredientsAPI.save(item?.id || null, {
        name: f.name, unit: f.unit as Ingredient['unit'], category: f.category || null,
        minStock: f.minStock === '' ? null : Number(f.minStock),
        ...(f.avgCost === '' ? {} : { avgCost: Number(f.avgCost) / per }),
        ...(item || f.stock === '' ? {} : { stock: Number(f.stock) }),
      } as any);
      toast.success(t('v3:guardado'));
      onDone();
    } catch (err) { toast.error(errorMessage(err)); } finally { setBusy(false); }
  };
  const big = f.unit === 'g' ? 'kg' : f.unit === 'ml' ? 'l' : 'und';
  return (
    <form onSubmit={save} className="space-y-3">
      <label className="block space-y-1 text-xs font-bold text-slate-700">{t('v3:ing_nombre')}<input required className={field} value={f.name} maxLength={80} onChange={(e) => setF({ ...f, name: e.target.value })} placeholder={t('v3:ing_nombre_ej')} /></label>
      <div className="grid grid-cols-2 gap-3">
        <label className="block space-y-1 text-xs font-bold text-slate-700">{t('v3:ing_unidad')}
          <select className={field} value={f.unit} onChange={(e) => setF({ ...f, unit: e.target.value as any })}>
            <option value="g">{t('v3:ing_unidad_g')}</option><option value="ml">{t('v3:ing_unidad_ml')}</option><option value="und">{t('v3:ing_unidad_und')}</option>
          </select>
        </label>
        <label className="block space-y-1 text-xs font-bold text-slate-700">{t('v3:ing_categoria')}<input className={field} value={f.category} maxLength={40} onChange={(e) => setF({ ...f, category: e.target.value })} placeholder={t('v3:ing_categoria_ej')} /></label>
        <label className="block space-y-1 text-xs font-bold text-slate-700">{t('v3:ing_costo', { unit: big })}<input type="number" min={0} step={1} className={field} value={f.avgCost} onChange={(e) => setF({ ...f, avgCost: e.target.value as any })} /></label>
        <label className="block space-y-1 text-xs font-bold text-slate-700">{t('v3:ing_minimo', { unit: f.unit })}<input type="number" min={0} step="any" className={field} value={f.minStock} onChange={(e) => setF({ ...f, minStock: e.target.value as any })} /></label>
        {!item && <label className="block space-y-1 text-xs font-bold text-slate-700">{t('v3:ing_existencia', { unit: f.unit })}<input type="number" min={0} step="any" className={field} value={f.stock} onChange={(e) => setF({ ...f, stock: e.target.value })} /></label>}
      </div>
      <p className="text-xs text-slate-500">{t('v3:ing_ayuda')}</p>
      <button type="submit" disabled={busy} className="min-h-[44px] w-full rounded-xl bg-slate-900 text-sm font-bold text-white disabled:opacity-60">{t('v3:guardar')}</button>
    </form>
  );
}

function AdjustForm({ item, onDone }: { item: Ingredient; onDone: () => void }) {
  const [type, setType] = useState<'ADJUSTMENT' | 'WASTE' | 'COUNT'>('COUNT');
  const [qty, setQty] = useState('');
  const [notes, setNotes] = useState('');
  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    try { await ingredientsAPI.adjust(item.id, { type, quantity: Number(qty), notes }); toast.success(t('v3:guardado')); onDone(); } catch (err) { toast.error(errorMessage(err)); }
  };
  return (
    <form onSubmit={save} className="space-y-3">
      <p className="text-sm text-slate-600">{t('v3:ing_existencia_actual', { qty: fmtQty(item.stock, item.unit) })}</p>
      <div className="grid grid-cols-3 gap-1 rounded-xl bg-slate-100 p-1" role="radiogroup">
        {(['COUNT', 'WASTE', 'ADJUSTMENT'] as const).map((x) => <button key={x} type="button" role="radio" aria-checked={type === x} onClick={() => setType(x)} className={`min-h-[40px] rounded-lg text-xs font-bold ${type === x ? 'bg-white shadow-sm' : 'text-slate-600'}`}>{t(`v3:mov_${x}`)}</button>)}
      </div>
      <label className="block space-y-1 text-xs font-bold text-slate-700">{t(`v3:ing_cantidad_${type}`, { unit: item.unit })}<input required type="number" step="any" className={field} value={qty} onChange={(e) => setQty(e.target.value)} /></label>
      <label className="block space-y-1 text-xs font-bold text-slate-700">{t('v3:ing_nota')}<input className={field} value={notes} maxLength={200} onChange={(e) => setNotes(e.target.value)} /></label>
      <button type="submit" className="min-h-[44px] w-full rounded-xl bg-slate-900 text-sm font-bold text-white">{t('v3:guardar')}</button>
    </form>
  );
}

function Kardex({ item }: { item: Ingredient }) {
  const [rows, setRows] = useState<IngredientMovement[] | null>(null);
  useEffect(() => { ingredientsAPI.movements(item.id).then(setRows).catch(() => setRows([])); }, [item.id]);
  if (!rows) return <p className="text-sm text-slate-500">{t('v3:cargando')}</p>;
  if (!rows.length) return <p className="text-sm text-slate-500">{t('v3:ing_sin_movimientos')}</p>;
  return (
    <table className="w-full text-sm">
      <thead className="text-left text-xs text-slate-500"><tr><th className="py-1.5">{t('v3:ing_fecha')}</th><th>{t('v3:ing_mov')}</th><th className="text-right">{t('v3:ing_cant')}</th><th className="text-right">{t('v3:ing_queda')}</th></tr></thead>
      <tbody className="divide-y divide-slate-100">
        {rows.map((r) => (
          <tr key={r.id} title={r.notes || ''}>
            <td className="py-1.5 text-xs text-slate-600">{new Date(r.createdAt).toLocaleString(getLocale(), { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' })}</td>
            <td className="text-xs font-semibold">{t(`v3:mov_${r.type}`)}</td>
            <td className={`text-right tabular-nums ${r.quantity < 0 ? 'text-rose-700' : 'text-emerald-700'}`}>{r.quantity > 0 ? '+' : ''}{fmtQty(r.quantity, item.unit)}</td>
            <td className="text-right tabular-nums">{fmtQty(r.newStock, item.unit)}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export const IngredientsPanel: React.FC = () => {
  const [list, setList] = useState<Ingredient[]>([]);
  const [low, setLow] = useState<{ name: string; margin: number | null; cost: number; price: number }[]>([]);
  const [minMargin, setMinMargin] = useState(30);
  const [q, setQ] = useState('');
  const [modal, setModal] = useState<{ kind: 'edit' | 'adjust' | 'kardex'; item: Ingredient | null } | null>(null);

  const load = async () => {
    try {
      const [l, c] = await Promise.all([ingredientsAPI.list(), recipesAPI.costs()]);
      setList(l); setLow(c.products.filter((p) => p.low)); setMinMargin(c.minMarginPct);
    } catch (e) { toast.error(errorMessage(e)); }
  };
  useEffect(() => { load(); }, []);

  const shown = useMemo(() => list.filter((i) => !q || `${i.name} ${i.category || ''}`.toLowerCase().includes(q.toLowerCase())), [list, q]);
  const close = () => { setModal(null); load(); };

  return (
    <div className="space-y-4">
      {low.length > 0 && (
        <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-950" role="status">
          <p className="flex items-center gap-2 font-bold"><AlertTriangle className="h-4 w-4" aria-hidden />{t('v3:ing_margen_bajo', { min: minMargin })}</p>
          <ul className="mt-1 list-disc pl-6">{low.map((p) => <li key={p.name}>{t('v3:ing_margen_item', { name: p.name, margin: p.margin, cost: formatCurrency(p.cost), price: formatCurrency(p.price) })}</li>)}</ul>
        </div>
      )}
      <div className="flex flex-wrap items-center gap-2">
        <label className="relative min-w-[14rem] flex-1">
          <span className="sr-only">{t('v3:ing_buscar')}</span>
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" aria-hidden />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('v3:ing_buscar')} className="w-full rounded-xl border border-slate-300 py-2 pl-9 pr-3 text-sm" />
        </label>
        <button type="button" onClick={() => setModal({ kind: 'edit', item: null })} className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl bg-blue-700 px-4 text-sm font-bold text-white"><Plus className="h-4 w-4" aria-hidden />{t('v3:ing_nuevo')}</button>
      </div>
      <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white">
        <table className="w-full min-w-[640px] text-sm">
          <thead className="bg-slate-50 text-left text-xs font-bold uppercase tracking-wide text-slate-500">
            <tr><th className="px-4 py-3">{t('v3:ing_nombre')}</th><th className="px-4 py-3 text-right">{t('v3:ing_existencia_col')}</th><th className="px-4 py-3 text-right">{t('v3:ing_costo_col')}</th><th className="px-4 py-3">{t('v3:ing_en_recetas')}</th><th className="px-4 py-3" /></tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {shown.map((i) => (
              <tr key={i.id}>
                <td className="px-4 py-3"><span className="font-semibold text-slate-900">{i.name}</span>{i.category && <span className="block text-xs text-slate-500">{i.category}</span>}</td>
                <td className={`px-4 py-3 text-right font-bold tabular-nums ${i.stock < 0 ? 'text-rose-700' : i.low ? 'text-amber-700' : 'text-slate-900'}`}>{fmtQty(i.stock, i.unit)}{i.minStock !== null && <span className="block text-xs font-normal text-slate-500">{t('v3:ing_min', { qty: fmtQty(i.minStock, i.unit) })}</span>}</td>
                <td className="px-4 py-3 text-right tabular-nums">{fmtCost(i.avgCost, i.unit)}</td>
                <td className="px-4 py-3 text-xs text-slate-600">{i.usedIn ? t('v3:ing_n_productos', { count: i.usedIn }) : '—'}</td>
                <td className="px-4 py-3">
                  <div className="flex justify-end gap-1">
                    <button type="button" onClick={() => setModal({ kind: 'adjust', item: i })} className="rounded-lg p-2 text-slate-600 hover:bg-slate-100" aria-label={t('v3:ing_ajustar', { name: i.name })} title={t('v3:ing_ajustar', { name: i.name })}><Scale className="h-4 w-4" /></button>
                    <button type="button" onClick={() => setModal({ kind: 'kardex', item: i })} className="rounded-lg p-2 text-slate-600 hover:bg-slate-100" aria-label={t('v3:ing_kardex', { name: i.name })} title={t('v3:ing_kardex', { name: i.name })}><History className="h-4 w-4" /></button>
                    <button type="button" onClick={() => setModal({ kind: 'edit', item: i })} className="rounded-lg p-2 text-slate-600 hover:bg-slate-100" aria-label={t('v3:ing_editar', { name: i.name })}><Pencil className="h-4 w-4" /></button>
                    <button type="button" onClick={async () => { if (await confirmDialog({ title: t('v3:ing_quitar'), message: t('v3:ing_quitar_desc', { name: i.name }), tone: 'danger', confirmLabel: t('v3:quitar') })) { await ingredientsAPI.remove(i.id); load(); } }} className="rounded-lg p-2 text-slate-400 hover:bg-rose-50 hover:text-rose-700" aria-label={t('v3:ing_quitar')}><Trash2 className="h-4 w-4" /></button>
                  </div>
                </td>
              </tr>
            ))}
            {shown.length === 0 && <tr><td colSpan={5} className="px-4 py-10 text-center text-slate-500">{t('v3:ing_vacio')}</td></tr>}
          </tbody>
        </table>
      </div>
      {modal?.kind === 'edit' && <Modal title={modal.item ? modal.item.name : t('v3:ing_nuevo')} onClose={() => setModal(null)}><EditForm item={modal.item} onDone={close} /></Modal>}
      {modal?.kind === 'adjust' && modal.item && <Modal title={t('v3:ing_ajustar', { name: modal.item.name })} onClose={() => setModal(null)}><AdjustForm item={modal.item} onDone={close} /></Modal>}
      {modal?.kind === 'kardex' && modal.item && <Modal title={t('v3:ing_kardex', { name: modal.item.name })} onClose={() => setModal(null)}><Kardex item={modal.item} /></Modal>}
    </div>
  );
};
