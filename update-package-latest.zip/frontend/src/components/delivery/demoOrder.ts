// ============================================
// DELIVERY - Pedidos de demostración (Rappi, WhatsApp)
// ============================================
// Las integraciones con Rappi y WhatsApp aún no están conectadas: sus pantallas se
// muestran como demostración. Estos pedidos viven solo en la pantalla: no crean
// ventas, no tocan la caja ni el inventario.

import type { Product } from '../../types';

export interface DemoOrder {
  id: string;
  saleNumber: string;
  channel: 'RAPPI' | 'WHATSAPP';
  createdAt: string;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  deliveryNotes: string;
  paymentMethod: string;
  total: number;
  items: { quantity: number; total: number; productName: string }[];
}

const NAMES = ['Sofía Restrepo', 'Juan Camilo Reyes', 'Andrea Gómez', 'Diego Londoño', 'Paula Barrientos'];
const ADDRESSES = ['Calle 127 # 19-45 Apto 502', 'Carrera 11 # 94-22', 'Transversal 6 # 82-15', 'Calle 106 # 14-30'];
const SAMPLE = [
  { productName: 'Hamburguesa de la casa', price: 28000 },
  { productName: 'Limonada de coco', price: 9000 },
  { productName: 'Papas rústicas', price: 12000 },
];
const pick = <T,>(list: T[]) => list[Math.floor(Math.random() * list.length)];

/** Un pedido de ejemplo con productos de la carta (o de muestra si aún no hay carta) */
export const demoOrder = (
  channel: DemoOrder['channel'],
  products: Product[] = [],
  data: Partial<Pick<DemoOrder, 'customerName' | 'customerPhone' | 'customerAddress' | 'deliveryNotes' | 'paymentMethod'>> & {
    items?: { productName: string; price: number; quantity: number }[];
  } = {},
): DemoOrder => {
  const menu = products
    .filter((p) => p.isActive !== false)
    .flatMap((p) => p.variants.filter((v) => v.isActive !== false).map((v) => ({ productName: p.variants.length > 1 ? `${p.name} (${v.name})` : p.name, price: v.price })));
  const items = data.items?.length
    ? data.items
    : Array.from({ length: 1 + Math.floor(Math.random() * 2) }, () => ({ ...pick(menu.length ? menu : SAMPLE), quantity: 1 }));
  const lines = items.map((i) => ({ quantity: i.quantity, total: i.price * i.quantity, productName: i.productName }));
  const n = Math.floor(1000 + Math.random() * 9000);
  return {
    id: `demo-${channel}-${Date.now()}-${n}`,
    saleNumber: `DEMO-${n}`,
    channel,
    createdAt: new Date().toISOString(),
    customerName: data.customerName || pick(NAMES),
    customerPhone: data.customerPhone || '300 000 0000',
    customerAddress: data.customerAddress || pick(ADDRESSES),
    deliveryNotes: data.deliveryNotes || '',
    paymentMethod: data.paymentMethod || (channel === 'RAPPI' ? 'RAPPI_PAY' : 'NEQUI'),
    total: lines.reduce((sum, l) => sum + l.total, 0),
    items: lines,
  };
};
