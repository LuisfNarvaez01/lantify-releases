// ============================================
// DELIVERY - Página web, pedidos en línea y canales (Premium)
// ============================================
// Una sola pestaña para todo lo que llega de afuera: los pedidos de la página, la
// página misma y los canales WhatsApp y Rappi. Lo que el plan no incluye se muestra
// como promoción; lo que aún no está conectado, como "Próximamente" con su demostración.

import { useEffect, useState } from 'react';
import { Bike, Globe, MessageCircle, Zap, ExternalLink, PencilLine, Lock, Clock, ToggleRight, Info } from 'lucide-react';
import { pageAPI, PageState } from '../../services/api';
import { usePlan } from '../../shared/plan';
import { useBusiness } from '../../shared/business';
import { useOnlineOrdersStore } from '../../store/useOnlineOrdersStore';
import { PlanLocked } from '../common/PlanLocked';
import { OnlineOrdersModule } from '../orders/OnlineOrdersModule';
import { RappiOrdersPanel } from '../pos/RappiOrdersPanel';
import { WhatsAppBotSimulator } from '../pos/WhatsAppBotSimulator';
import type { Product } from '../../types';
import { t } from '../../i18n';

export type DeliverySection = 'web' | 'page' | 'whatsapp' | 'rappi';

interface Props {
  role: string;
  products: Product[];
  /** Abre Administración → Mi página */
  onEditPage?: () => void;
}

const SECTIONS: { id: DeliverySection; feature: string; soon?: boolean; icon: typeof Bike }[] = [
  { id: 'web', feature: 'webstore', icon: Bike },
  { id: 'page', feature: 'business_page', icon: Globe },
  { id: 'whatsapp', feature: 'whatsapp', soon: true, icon: MessageCircle },
  { id: 'rappi', feature: 'delivery', soon: true, icon: Zap },
];

/** Secciones que ve cada rol: la caja atiende pedidos; la página y los canales son del ADMIN */
export const deliverySectionsFor = (role: string, enabled: { whatsapp: boolean; rappi: boolean }) =>
  SECTIONS.filter((s) => role === 'ADMIN' || s.id === 'web' || (s.id === 'whatsapp' && enabled.whatsapp) || (s.id === 'rappi' && enabled.rappi));

export function DeliveryModule({ role, products, onEditPage }: Props) {
  const plan = usePlan();
  const settings = useBusiness().settings;
  const enabled = { whatsapp: !!settings?.whatsappEnabled, rappi: !!settings?.rappiEnabled };
  const sections = deliverySectionsFor(role, enabled);
  const pending = useOnlineOrdersStore((s) => s.pending);
  const [section, setSection] = useState<DeliverySection>(() => (plan.has('webstore') ? 'web' : sections[0]?.id || 'web'));
  const current = sections.find((s) => s.id === section) || sections[0];

  return (
    <div className="space-y-5">
      <nav aria-label={t('layout:delivery')} className="-mx-1 overflow-x-auto px-1">
        <div className="flex w-max gap-1 rounded-2xl border border-slate-200 bg-white p-1 shadow-sm">
          {sections.map((s) => {
            const active = current?.id === s.id;
            const locked = !plan.has(s.feature);
            const Icon = s.icon;
            return (
              <button
                key={s.id}
                type="button"
                onClick={() => setSection(s.id)}
                aria-pressed={active}
                className={`relative inline-flex min-h-[42px] items-center gap-2 rounded-xl px-4 text-sm font-semibold transition-colors ${
                  active ? 'bg-slate-900 text-white shadow-sm' : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <Icon className="h-4 w-4" aria-hidden />
                {t(`layout:delivery_${s.id}`)}
                {locked && <Lock className="h-3.5 w-3.5 opacity-70" aria-label={t('plan:no_incluido')} />}
                {!locked && s.soon && (
                  <span className={`rounded-full px-1.5 py-0.5 text-[0.7143rem] font-bold uppercase tracking-wide ${active ? 'bg-white/20 text-white' : 'bg-amber-100 text-amber-800'}`}>
                    {t('plan:proximamente')}
                  </span>
                )}
                {s.id === 'web' && pending > 0 && (
                  <span className="grid h-5 min-w-5 place-items-center rounded-full bg-red-500 px-1 text-[0.7143rem] font-bold text-white">{pending}</span>
                )}
              </button>
            );
          })}
        </div>
      </nav>

      {current?.id === 'web' && <OnlineOrdersModule businessName={settings?.businessName || 'Lantify'} />}
      {current?.id === 'page' && (plan.has('business_page') ? <PageSummary onEditPage={onEditPage} /> : <PlanLocked feature="business_page" />)}
      {current?.id === 'whatsapp' && (
        <ChannelSection feature="whatsapp" enabled={enabled.whatsapp} role={role}>
          <WhatsAppBotSimulator products={products} />
        </ChannelSection>
      )}
      {current?.id === 'rappi' && (
        <ChannelSection feature="delivery" enabled={enabled.rappi} role={role}>
          <RappiOrdersPanel products={products} />
        </ChannelSection>
      )}
    </div>
  );
}

/**
 * Canal aún no conectado. Sin el plan: promoción con su demostración.
 * Con el plan: se enciende en Configuración y, mientras llega la conexión, se ve la demostración.
 */
function ChannelSection({ feature, enabled, role, children }: { feature: string; enabled: boolean; role: string; children: React.ReactNode }) {
  const plan = usePlan();
  const included = plan.has(feature);
  const [demo, setDemo] = useState(false);
  const showDemo = demo || (included && enabled);

  return (
    <div className="space-y-5">
      {included ? (
        <section className="flex flex-col gap-4 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-3">
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-amber-100 text-amber-700">
              <Clock className="h-5 w-5" aria-hidden />
            </span>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-lg font-bold text-slate-900 font-heading">{t(`plan:f_${feature}`)}</h2>
                <span className="rounded-full bg-amber-100 px-2 py-0.5 text-xs font-bold text-amber-800">{t('plan:proximamente')}</span>
                <span className={`rounded-full px-2 py-0.5 text-xs font-bold ${enabled ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'}`}>
                  {enabled ? t('layout:canal_activado') : t('layout:canal_apagado')}
                </span>
              </div>
              <p className="mt-1 max-w-2xl text-sm text-slate-600">{t('plan:proximamente_desc')}</p>
              {!enabled && role === 'ADMIN' && (
                <p className="mt-2 inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500">
                  <ToggleRight className="h-4 w-4" aria-hidden /> {t('layout:canal_como_activar')}
                </p>
              )}
            </div>
          </div>
          {!enabled && (
            <button
              type="button"
              onClick={() => setDemo((v) => !v)}
              aria-expanded={showDemo}
              className="inline-flex min-h-[44px] shrink-0 items-center justify-center rounded-xl border border-slate-300 px-5 text-sm font-semibold text-slate-700 hover:bg-slate-50"
            >
              {showDemo ? t('plan:ocultar_demo') : t('plan:ver_demo')}
            </button>
          )}
        </section>
      ) : (
        <PlanLocked feature={feature} soon onDemo={() => setDemo((v) => !v)} demoOpen={demo} />
      )}

      {showDemo && (
        <div className="space-y-3">
          <p className="flex items-center gap-2 rounded-xl border border-sky-200 bg-sky-50 px-4 py-2.5 text-sm font-medium text-sky-900">
            <Info className="h-4 w-4 shrink-0" aria-hidden /> {t('plan:demo_aviso')}
          </p>
          {children}
        </div>
      )}
    </div>
  );
}

/** La página del negocio: dirección, estado y atajos para abrirla o editarla */
function PageSummary({ onEditPage }: { onEditPage?: () => void }) {
  const [page, setPage] = useState<PageState | null>(null);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    pageAPI.get().then(setPage).catch(() => setFailed(true));
  }, []);

  const published = !!(page?.url && page.publishedAt);
  const sections = page
    ? (['menu', 'signup', 'games', 'orders'] as const).filter((k) => (page.sections as Record<string, boolean>)[k])
    : [];

  return (
    <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm sm:p-8">
      <div className="flex flex-col gap-6 lg:flex-row lg:items-start lg:justify-between">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="text-2xl font-bold text-slate-900 font-heading">{t('plan:f_business_page')}</h2>
            {page && (
              <span className={`rounded-full px-2.5 py-0.5 text-xs font-bold ${published ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'}`}>
                {published ? t('layout:pagina_publicada') : t('layout:pagina_sin_publicar')}
              </span>
            )}
          </div>
          <p className="mt-1 max-w-2xl text-sm text-slate-600">{t('plan:f_business_page_desc')}</p>
          {published && (
            <a href={page!.url!} target="_blank" rel="noreferrer" className="mt-4 inline-flex max-w-full items-center gap-2 break-all rounded-xl bg-slate-50 px-4 py-2.5 font-mono text-sm text-blue-700 hover:bg-slate-100">
              {page!.url} <ExternalLink className="h-4 w-4 shrink-0" aria-hidden />
            </a>
          )}
          {failed && <p className="mt-4 text-sm text-slate-500">{t('layout:mi_pagina_sin_publicar')}</p>}
          {page && (
            <dl className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
              <Stat label={t('layout:pagina_platos')} value={page.menuSummary.items} />
              <Stat label={t('layout:pagina_miembros')} value={page.stats.members} />
              <Stat label={t('layout:pagina_premios')} value={page.stats.prizesAwarded} />
              <Stat label={t('layout:pagina_secciones')} value={sections.length} />
            </dl>
          )}
        </div>
        <div className="flex shrink-0 flex-col gap-2 sm:flex-row lg:flex-col">
          {published && (
            <a href={page!.url!} target="_blank" rel="noreferrer" className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl bg-blue-600 px-5 text-sm font-semibold text-white hover:bg-blue-700">
              <ExternalLink className="h-4 w-4" aria-hidden /> {t('layout:abrir_mi_pagina')}
            </a>
          )}
          {onEditPage && (
            <button type="button" onClick={onEditPage} className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl border border-slate-300 px-5 text-sm font-semibold text-slate-700 hover:bg-slate-50">
              <PencilLine className="h-4 w-4" aria-hidden /> {t('layout:editar_mi_pagina')}
            </button>
          )}
        </div>
      </div>
    </section>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-2xl bg-slate-50 px-4 py-3">
      <dt className="text-xs font-semibold text-slate-500">{label}</dt>
      <dd className="mt-0.5 text-xl font-bold tabular-nums text-slate-900">{value}</dd>
    </div>
  );
}
