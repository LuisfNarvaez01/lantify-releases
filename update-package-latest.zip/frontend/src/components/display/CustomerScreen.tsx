// ============================================
// DISPLAY - Pantalla del cliente (Fase 4 · 10)
// ============================================
// Mira hacia el cliente junto a la caja. Muestra lo que se está cobrando (líneas y
// total), la propina sugerida y el QR de pago del negocio. En reposo: happy hour,
// productos destacados y el QR de la página. Solo lectura: nunca se toca.

import { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { Clock3 } from 'lucide-react';
import { t } from '../../i18n';
import { mediaUrl, money } from './displayApi';

export interface CustomerFeed {
  now: string;
  display: { name: string; type: 'CUSTOMER' };
  business: { name: string; logoUrl: string | null };
  cart: { label: string | null; paid: number; total: number; lines: { name: string; qty: number; unitPrice: number; total: number; note: string | null; badge: string | null }[] } | null;
  due: number;
  tip: number;
  tipPercent: number;
  paymentQr: { url: string; label: string } | null;
  idle: {
    happyHours: { name: string; start: string; end: string; kind: 'PERCENT' | 'FIXED'; value: number; active: boolean }[];
    featured: { name: string; imageUrl: string | null; price: number }[];
    pageUrl: string | null;
  } | null;
}

const hour = (hhmm: string) => {
  const [h, m] = hhmm.split(':').map(Number);
  return new Date(2000, 0, 1, h, m).toLocaleTimeString([], { hour: 'numeric', minute: m ? '2-digit' : undefined });
};

function PageQr({ url }: { url: string }) {
  const [src, setSrc] = useState<string | null>(null);
  useEffect(() => {
    QRCode.toDataURL(url, { width: 360, margin: 1, errorCorrectionLevel: 'M' }).then(setSrc).catch(() => setSrc(null));
  }, [url]);
  if (!src) return null;
  return <img src={src} alt={t('v3:cli_qr_pagina')} className="h-40 w-40 rounded-2xl bg-white p-2" />;
}

function Idle({ feed }: { feed: CustomerFeed }) {
  const idle = feed.idle!;
  const logo = mediaUrl(feed.business.logoUrl);
  const live = idle.happyHours.find((h) => h.active);
  return (
    <div className="flex flex-1 min-h-0 flex-col gap-6 p-8">
      <header className="flex items-center gap-5">
        {logo && <img src={logo} alt="" className="h-20 w-20 rounded-2xl bg-white object-contain p-1" />}
        <div>
          <p className="text-lg font-bold text-slate-400">{t('v3:cli_bienvenido')}</p>
          <h1 className="text-5xl font-black">{feed.business.name || 'Lantify'}</h1>
        </div>
      </header>
      {live && (
        <div className="flex items-center gap-4 rounded-3xl bg-amber-400 px-6 py-5 text-slate-950">
          <Clock3 className="h-10 w-10 shrink-0" aria-hidden />
          <div>
            <p className="text-3xl font-black">{live.name}</p>
            <p className="text-xl font-bold">{t('v3:cli_hh_hasta', { hora: hour(live.end) })}{live.kind === 'PERCENT' ? ` · ${t('v3:cli_hh_pct', { pct: live.value })}` : ''}</p>
          </div>
        </div>
      )}
      <div className="flex flex-1 min-h-0 gap-6">
        <ul className="grid flex-1 content-start gap-4 overflow-hidden" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(14rem, 1fr))' }}>
          {idle.featured.map((p) => (
            <li key={p.name} className="overflow-hidden rounded-3xl bg-slate-900">
              {p.imageUrl && <img src={mediaUrl(p.imageUrl)!} alt="" className="aspect-square w-full object-cover" />}
              <div className="p-4">
                <p className="truncate text-xl font-black">{p.name}</p>
                <p className="text-lg font-bold text-slate-300 tabular-nums">{money(p.price)}</p>
              </div>
            </li>
          ))}
        </ul>
        {idle.pageUrl && (
          <aside className="flex w-56 shrink-0 flex-col items-center justify-center gap-3 rounded-3xl bg-slate-900 p-5 text-center">
            <PageQr url={idle.pageUrl} />
            <p className="text-lg font-bold">{t('v3:cli_pagina')}</p>
            <p className="text-sm text-slate-400">{t('v3:cli_pagina_desc')}</p>
          </aside>
        )}
      </div>
    </div>
  );
}

export function CustomerScreen({ feed }: { feed: CustomerFeed }) {
  if (!feed.cart) return <Idle feed={feed} />;
  const cart = feed.cart;
  const qr = feed.paymentQr ? mediaUrl(feed.paymentQr.url) : null;
  return (
    <div className="grid flex-1 min-h-0 grid-cols-[1fr_minmax(20rem,28rem)] gap-6 p-6">
      <section className="flex min-h-0 flex-col rounded-3xl bg-slate-900 p-6" aria-labelledby="cli-pedido">
        <h1 id="cli-pedido" className="text-3xl font-black">{cart.label || t('v3:cli_tu_pedido')}</h1>
        <ul className="mt-4 flex-1 divide-y divide-slate-800 overflow-y-auto">
          {cart.lines.map((l, i) => (
            <li key={`${l.name}-${i}`} className="flex items-baseline gap-4 py-3">
              <span className="w-12 shrink-0 text-2xl font-black tabular-nums text-slate-300">{l.qty}×</span>
              <span className="min-w-0 flex-1">
                <span className="block text-2xl font-bold leading-tight">{l.name}</span>
                {(l.badge || l.note) && (
                  <span className="mt-1 flex flex-wrap items-center gap-2 text-base text-slate-400">
                    {l.badge && <span className="rounded-md bg-amber-400 px-2 py-0.5 font-black text-slate-950">{l.badge}</span>}
                    {l.note}
                  </span>
                )}
              </span>
              <span className="text-2xl font-bold tabular-nums">{money(l.total)}</span>
            </li>
          ))}
        </ul>
      </section>
      <aside className="flex min-h-0 flex-col gap-4">
        <div className="rounded-3xl bg-white p-6 text-slate-950">
          <p className="text-xl font-bold text-slate-500">{t('v3:cli_total')}</p>
          <p className="text-6xl font-black tabular-nums">{money(feed.due)}</p>
          {cart.paid > 0 && <p className="mt-1 text-lg font-semibold text-slate-500">{t('v3:cli_ya_pagado', { valor: money(cart.paid) })}</p>}
          {feed.tip > 0 && (
            <p className="mt-3 rounded-2xl bg-slate-100 px-4 py-3 text-lg font-semibold text-slate-700">
              {t('v3:cli_propina', { pct: feed.tipPercent, valor: money(feed.tip) })}
            </p>
          )}
        </div>
        {qr && (
          <div className="flex flex-1 min-h-0 flex-col items-center justify-center rounded-3xl bg-slate-900 p-5 text-center">
            <p className="text-xl font-black">{t('v3:cli_paga_qr')}</p>
            <img src={qr} alt={t('v3:cli_qr_pago')} className="mt-3 max-h-[40vh] w-auto max-w-full rounded-2xl bg-white object-contain p-2" />
            {feed.paymentQr!.label && <p className="mt-3 text-lg font-bold text-slate-300">{feed.paymentQr!.label}</p>}
          </div>
        )}
      </aside>
    </div>
  );
}
