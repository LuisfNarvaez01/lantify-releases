// ============================================
// DISPLAY - Kiosco de autoservicio (Fase 4 · 16)
// ============================================
// Tablet emparejada con código. El cliente ve la carta con fotos, elige
// presentación, quita ingredientes y deja un comentario, revisa su pedido, escribe
// su nombre y lo envía. Recibe un número (K7) para pagar en la caja o con el QR.
// Sin teclado del sistema: los campos usan el teclado propio de la pantalla. Si
// nadie toca la pantalla un rato, vuelve al inicio y se vacía el pedido.

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ArrowLeft, Check, Delete, Minus, Plus, QrCode, ShoppingBag, Store, Trash2, X } from 'lucide-react';
import { t } from '../../i18n';
import { api, mediaUrl, money, Unpaired } from './displayApi';

export interface KioskFeed {
  now: string;
  display: { name: string; type: 'KIOSK' };
  business: { name: string; logoUrl: string | null };
  paymentQr: { url: string; label: string } | null;
  idleSeconds: number;
  categories: { id: string; name: string }[];
  products: { id: string; name: string; description: string | null; imageUrl: string | null; categoryId: string | null; removable: string[]; variants: { id: string; name: string; price: number }[] }[];
}

type Product = KioskFeed['products'][number];
interface Line { key: string; variantId: string; name: string; price: number; qty: number; removed: string[]; comment: string }

const variantLabel = (v: { name: string }) => (v.name && v.name !== 'Única' && !['default', 'regular'].includes(v.name.toLowerCase()) ? v.name : '');
const noteOf = (l: Pick<Line, 'removed' | 'comment'>) => [...l.removed.map((r) => t('v3:sin_x', { x: r })), l.comment.trim()].filter(Boolean).join(' · ');

// ── Teclado propio (la tablet no abre el teclado del sistema) ──
const ROWS = ['QWERTYUIOP', 'ASDFGHJKLÑ', 'ZXCVBNM'];
function OnScreenKeyboard({ value, onChange, max }: { value: string; onChange: (v: string) => void; max: number }) {
  const key = (k: string) => onChange((value + k).slice(0, max));
  const btn = 'min-h-[56px] flex-1 rounded-xl bg-slate-200 text-xl font-black text-slate-900 active:bg-slate-300';
  return (
    <div className="space-y-2 select-none" aria-label={t('v3:kio_teclado')}>
      {ROWS.map((row, i) => (
        <div key={row} className="flex gap-1.5" style={{ paddingInline: `${i * 1.25}rem` }}>
          {row.split('').map((k) => <button key={k} type="button" className={btn} onClick={() => key(value && !value.endsWith(' ') ? k.toLowerCase() : k)}>{k}</button>)}
        </div>
      ))}
      <div className="flex gap-1.5">
        <button type="button" className={`${btn} flex-[5]`} onClick={() => key(' ')}>{t('v3:kio_espacio')}</button>
        <button type="button" className={`${btn} flex-[2]`} onClick={() => onChange(value.slice(0, -1))} aria-label={t('v3:asis_borrar')}><Delete className="mx-auto h-6 w-6" aria-hidden /></button>
      </div>
    </div>
  );
}

function ProductSheet({ product, onAdd, onClose }: { product: Product; onAdd: (l: Omit<Line, 'key'>) => void; onClose: () => void }) {
  const [variant, setVariant] = useState(product.variants[0]);
  const [removed, setRemoved] = useState<string[]>([]);
  const [comment, setComment] = useState('');
  const [typing, setTyping] = useState(false);
  const [qty, setQty] = useState(1);
  const photo = mediaUrl(product.imageUrl);
  return (
    <div className="fixed inset-0 z-20 flex items-end justify-center bg-slate-950/70 sm:items-center" role="dialog" aria-modal="true" aria-labelledby="kio-prod">
      <div className="flex max-h-[95dvh] w-full max-w-3xl flex-col overflow-hidden rounded-t-3xl bg-white text-slate-900 sm:rounded-3xl">
        <div className="flex-1 overflow-y-auto">
          {photo && <img src={photo} alt="" className="h-64 w-full object-cover" />}
          <div className="space-y-5 p-6">
            <div className="flex items-start justify-between gap-4">
              <div>
                <h2 id="kio-prod" className="text-3xl font-black">{product.name}</h2>
                {product.description && <p className="mt-1 text-lg text-slate-600">{product.description}</p>}
              </div>
              <button type="button" onClick={onClose} className="rounded-xl p-3 text-slate-500 hover:bg-slate-100" aria-label={t('v3:cancelar')}><X className="h-7 w-7" /></button>
            </div>
            {product.variants.length > 1 && (
              <fieldset>
                <legend className="text-lg font-black">{t('v3:kio_elige')}</legend>
                <div className="mt-2 grid grid-cols-2 gap-2">
                  {product.variants.map((v) => (
                    <button key={v.id} type="button" onClick={() => setVariant(v)} aria-pressed={variant.id === v.id} className={`min-h-[64px] rounded-2xl border-2 px-4 text-left text-lg font-bold ${variant.id === v.id ? 'border-blue-600 bg-blue-50' : 'border-slate-200'}`}>
                      {variantLabel(v) || product.name}<span className="block text-base font-semibold text-slate-600 tabular-nums">{money(v.price)}</span>
                    </button>
                  ))}
                </div>
              </fieldset>
            )}
            {product.removable.length > 0 && (
              <fieldset>
                <legend className="text-lg font-black">{t('v3:kio_quitar')}</legend>
                <div className="mt-2 flex flex-wrap gap-2">
                  {product.removable.map((r) => {
                    const off = removed.includes(r);
                    return (
                      <button key={r} type="button" aria-pressed={off} onClick={() => setRemoved((x) => (off ? x.filter((y) => y !== r) : [...x, r]))} className={`min-h-[52px] rounded-full border-2 px-5 text-lg font-bold ${off ? 'border-rose-600 bg-rose-50 text-rose-800 line-through' : 'border-slate-200'}`}>
                        {r}
                      </button>
                    );
                  })}
                </div>
              </fieldset>
            )}
            <div>
              <p className="text-lg font-black">{t('v3:kio_comentario')}</p>
              <button type="button" onClick={() => setTyping((v) => !v)} className={`mt-2 flex min-h-[60px] w-full items-center rounded-2xl border-2 px-4 text-left text-lg ${typing ? 'border-blue-600' : 'border-slate-200'} ${comment ? 'text-slate-900' : 'text-slate-400'}`}>
                {comment || t('v3:kio_comentario_ej')}{typing && <span className="ml-0.5 h-6 w-0.5 animate-pulse bg-blue-600" aria-hidden />}
              </button>
              {typing && <div className="mt-3"><OnScreenKeyboard value={comment} onChange={setComment} max={80} /></div>}
            </div>
          </div>
        </div>
        <footer className="flex items-center gap-4 border-t border-slate-200 p-4">
          <div className="flex items-center gap-2">
            <button type="button" onClick={() => setQty((q) => Math.max(1, q - 1))} className="grid h-14 w-14 place-items-center rounded-xl bg-slate-100" aria-label={t('v3:kio_menos')}><Minus className="h-6 w-6" /></button>
            <span className="w-10 text-center text-2xl font-black tabular-nums" aria-live="polite">{qty}</span>
            <button type="button" onClick={() => setQty((q) => Math.min(20, q + 1))} className="grid h-14 w-14 place-items-center rounded-xl bg-slate-100" aria-label={t('v3:kio_mas')}><Plus className="h-6 w-6" /></button>
          </div>
          <button
            type="button"
            onClick={() => onAdd({ variantId: variant.id, name: [product.name, variantLabel(variant)].filter(Boolean).join(' · '), price: variant.price, qty, removed, comment })}
            className="flex min-h-[64px] flex-1 items-center justify-between rounded-2xl bg-blue-600 px-6 text-xl font-black text-white hover:bg-blue-500"
          >
            <span>{t('v3:kio_agregar')}</span><span className="tabular-nums">{money(variant.price * qty)}</span>
          </button>
        </footer>
      </div>
    </div>
  );
}

type Step = 'start' | 'menu' | 'review' | 'sent';

export function KioskScreen({ feed, token, onUnpaired }: { feed: KioskFeed; token: string; onUnpaired: (err: unknown) => void }) {
  const [step, setStep] = useState<Step>('start');
  const [category, setCategory] = useState<string | null>(null);
  const [open, setOpen] = useState<Product | null>(null);
  const [lines, setLines] = useState<Line[]>([]);
  const [name, setName] = useState('');
  const [payment, setPayment] = useState<'COUNTER' | 'QR'>('COUNTER');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [sent, setSent] = useState<{ number: string; total: number; payment: 'COUNTER' | 'QR' } | null>(null);
  const lastTouch = useRef(Date.now());

  const restart = useCallback(() => {
    setStep('start'); setLines([]); setName(''); setPayment('COUNTER'); setOpen(null); setError(''); setSent(null); setCategory(null);
  }, []);

  // Inactividad: vuelve al inicio y vacía el pedido
  useEffect(() => {
    const touch = () => { lastTouch.current = Date.now(); };
    window.addEventListener('pointerdown', touch);
    window.addEventListener('keydown', touch);
    const id = setInterval(() => {
      const limit = (step === 'sent' ? 25 : feed.idleSeconds || 90) * 1000;
      if (step !== 'start' && Date.now() - lastTouch.current > limit) restart();
    }, 1000);
    return () => { clearInterval(id); window.removeEventListener('pointerdown', touch); window.removeEventListener('keydown', touch); };
  }, [step, feed.idleSeconds, restart]);

  const products = useMemo(() => feed.products.filter((p) => !category || p.categoryId === category), [feed.products, category]);
  const count = lines.reduce((n, l) => n + l.qty, 0);
  const total = lines.reduce((n, l) => n + l.qty * l.price, 0);
  // Si un producto desapareció de la carta, sale del pedido
  useEffect(() => {
    const ids = new Set(feed.products.flatMap((p) => p.variants.map((v) => v.id)));
    setLines((ls) => (ls.every((l) => ids.has(l.variantId)) ? ls : ls.filter((l) => ids.has(l.variantId))));
  }, [feed.products]);

  const add = (l: Omit<Line, 'key'>) => {
    setLines((ls) => {
      const same = ls.find((x) => x.variantId === l.variantId && noteOf(x) === noteOf(l));
      if (same) return ls.map((x) => (x === same ? { ...x, qty: Math.min(20, x.qty + l.qty) } : x));
      return [...ls, { ...l, key: `${l.variantId}-${Date.now()}` }];
    });
    setOpen(null);
  };
  const change = (key: string, d: number) => setLines((ls) => ls.flatMap((l) => (l.key !== key ? [l] : l.qty + d <= 0 ? [] : [{ ...l, qty: Math.min(20, l.qty + d) }])));

  const send = async () => {
    setBusy(true);
    setError('');
    try {
      const r = await api<{ number: string; total: number; payment: 'COUNTER' | 'QR' }>('POST', '/display/kiosk/order', token, {
        customerName: name.trim(),
        payment,
        items: lines.map((l) => ({ variantId: l.variantId, qty: l.qty, note: noteOf(l) || undefined })),
      });
      setSent(r);
      setStep('sent');
      setLines([]);
    } catch (err) {
      if (err instanceof Unpaired) { onUnpaired(err); return; }
      setError((err as Error)?.message || t('v3:pantalla_error'));
    } finally {
      setBusy(false);
    }
  };

  const logo = mediaUrl(feed.business.logoUrl);
  const qr = feed.paymentQr ? mediaUrl(feed.paymentQr.url) : null;

  if (step === 'start') {
    return (
      <button type="button" onClick={() => { setStep('menu'); document.documentElement.requestFullscreen?.().catch(() => undefined); }} className="flex flex-1 flex-col items-center justify-center gap-6 bg-slate-950 p-8 text-center">
        {logo && <img src={logo} alt="" className="h-32 w-32 rounded-3xl bg-white object-contain p-2" />}
        <span className="text-5xl font-black">{feed.business.name || 'Lantify'}</span>
        <span className="inline-flex min-h-[88px] items-center gap-3 rounded-3xl bg-blue-600 px-10 text-3xl font-black text-white"><ShoppingBag className="h-9 w-9" aria-hidden />{t('v3:kio_toca')}</span>
        <span className="text-lg text-slate-400">{t('v3:kio_toca_desc')}</span>
      </button>
    );
  }

  if (step === 'sent' && sent) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center gap-4 p-8 text-center" role="status">
        <span className="grid h-20 w-20 place-items-center rounded-full bg-emerald-500"><Check className="h-12 w-12 text-white" aria-hidden /></span>
        <p className="text-2xl font-bold text-slate-300">{t('v3:kio_tu_numero')}</p>
        <p className="text-9xl font-black tabular-nums">{sent.number}</p>
        <p className="text-3xl font-black">{money(sent.total)}</p>
        {sent.payment === 'QR' && qr ? (
          <>
            <p className="max-w-xl text-xl text-slate-300">{t('v3:kio_paga_qr_desc')}</p>
            <img src={qr} alt={t('v3:cli_qr_pago')} className="max-h-[32vh] rounded-2xl bg-white p-2" />
            {feed.paymentQr!.label && <p className="text-lg font-bold text-slate-300">{feed.paymentQr!.label}</p>}
          </>
        ) : (
          <p className="max-w-xl text-xl text-slate-300">{t('v3:kio_paga_caja_desc')}</p>
        )}
        <button type="button" onClick={restart} className="mt-4 min-h-[64px] rounded-2xl bg-slate-800 px-8 text-xl font-black">{t('v3:kio_listo')}</button>
      </div>
    );
  }

  if (step === 'review') {
    return (
      <div className="flex flex-1 min-h-0 flex-col gap-4 p-6 lg:flex-row">
        <section className="flex min-h-0 flex-1 flex-col rounded-3xl bg-slate-900 p-5">
          <div className="flex items-center gap-3">
            <button type="button" onClick={() => setStep('menu')} className="inline-flex min-h-[52px] items-center gap-2 rounded-xl px-3 text-lg font-bold text-slate-300 hover:bg-slate-800"><ArrowLeft className="h-5 w-5" aria-hidden />{t('v3:kio_seguir')}</button>
            <h1 className="text-3xl font-black">{t('v3:kio_tu_pedido')}</h1>
          </div>
          <ul className="mt-3 flex-1 divide-y divide-slate-800 overflow-y-auto">
            {lines.map((l) => (
              <li key={l.key} className="flex items-center gap-3 py-3">
                <div className="min-w-0 flex-1">
                  <p className="text-xl font-bold">{l.name}</p>
                  {noteOf(l) && <p className="text-base text-amber-300">{noteOf(l)}</p>}
                  <p className="text-base text-slate-400 tabular-nums">{money(l.price)}</p>
                </div>
                <button type="button" onClick={() => change(l.key, -1)} className="grid h-12 w-12 place-items-center rounded-xl bg-slate-800" aria-label={l.qty === 1 ? t('v3:kio_quitar_linea') : t('v3:kio_menos')}>{l.qty === 1 ? <Trash2 className="h-5 w-5" /> : <Minus className="h-5 w-5" />}</button>
                <span className="w-8 text-center text-2xl font-black tabular-nums">{l.qty}</span>
                <button type="button" onClick={() => change(l.key, 1)} className="grid h-12 w-12 place-items-center rounded-xl bg-slate-800" aria-label={t('v3:kio_mas')}><Plus className="h-5 w-5" /></button>
              </li>
            ))}
          </ul>
          <p className="mt-3 flex justify-between border-t border-slate-800 pt-3 text-3xl font-black"><span>{t('v3:cli_total')}</span><span className="tabular-nums">{money(total)}</span></p>
        </section>
        <section className="flex w-full flex-col gap-4 rounded-3xl bg-white p-5 text-slate-900 lg:w-[34rem]">
          <div>
            <p className="text-lg font-black">{t('v3:kio_tu_nombre')}</p>
            <div className="mt-2 flex min-h-[60px] items-center rounded-2xl border-2 border-blue-600 px-4 text-2xl font-bold" aria-live="polite">
              {name || <span className="text-slate-400">{t('v3:kio_nombre_ej')}</span>}<span className="ml-0.5 h-7 w-0.5 animate-pulse bg-blue-600" aria-hidden />
            </div>
            <div className="mt-3"><OnScreenKeyboard value={name} onChange={setName} max={40} /></div>
          </div>
          <fieldset>
            <legend className="text-lg font-black">{t('v3:kio_como_pagas')}</legend>
            <div className="mt-2 grid grid-cols-2 gap-2">
              <button type="button" aria-pressed={payment === 'COUNTER'} onClick={() => setPayment('COUNTER')} className={`flex min-h-[64px] items-center justify-center gap-2 rounded-2xl border-2 text-lg font-bold ${payment === 'COUNTER' ? 'border-blue-600 bg-blue-50' : 'border-slate-200'}`}><Store className="h-6 w-6" aria-hidden />{t('v3:kio_pagar_caja')}</button>
              {qr && <button type="button" aria-pressed={payment === 'QR'} onClick={() => setPayment('QR')} className={`flex min-h-[64px] items-center justify-center gap-2 rounded-2xl border-2 text-lg font-bold ${payment === 'QR' ? 'border-blue-600 bg-blue-50' : 'border-slate-200'}`}><QrCode className="h-6 w-6" aria-hidden />{t('v3:kio_pagar_qr')}</button>}
            </div>
          </fieldset>
          {error && <p role="alert" className="rounded-xl bg-rose-50 px-4 py-3 text-lg font-semibold text-rose-800">{error}</p>}
          <button type="button" disabled={busy || name.trim().length < 2 || !lines.length} onClick={send} className="mt-auto min-h-[72px] rounded-2xl bg-blue-600 text-2xl font-black text-white hover:bg-blue-500 disabled:opacity-40">
            {busy ? t('v3:cargando') : t('v3:kio_enviar')}
          </button>
        </section>
      </div>
    );
  }

  return (
    <div className="flex flex-1 min-h-0 flex-col">
      {feed.categories.length > 1 && (
        <nav className="flex gap-2 overflow-x-auto border-b border-slate-800 px-4 py-3" aria-label={t('v3:kio_categorias')}>
          {[{ id: null as string | null, name: t('v3:kio_todo') }, ...feed.categories].map((c) => (
            <button key={c.id || 'all'} type="button" aria-pressed={category === c.id} onClick={() => setCategory(c.id)} className={`min-h-[56px] whitespace-nowrap rounded-2xl px-5 text-lg font-black ${category === c.id ? 'bg-white text-slate-950' : 'bg-slate-800 text-slate-200'}`}>{c.name}</button>
          ))}
        </nav>
      )}
      <ul className="grid flex-1 content-start gap-4 overflow-y-auto p-4" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(13rem, 1fr))' }}>
        {products.map((p) => {
          const photo = mediaUrl(p.imageUrl);
          return (
            <li key={p.id}>
              <button type="button" onClick={() => setOpen(p)} className="flex h-full w-full flex-col overflow-hidden rounded-3xl bg-slate-900 text-left hover:ring-4 hover:ring-blue-500 focus:outline-none focus:ring-4 focus:ring-blue-500">
                {photo ? <img src={photo} alt="" className="aspect-square w-full object-cover" /> : <span className="grid aspect-square w-full place-items-center bg-slate-800 text-5xl font-black text-slate-600">{p.name.slice(0, 1)}</span>}
                <span className="block p-4">
                  <span className="block text-xl font-black leading-tight">{p.name}</span>
                  <span className="mt-1 block text-lg font-bold text-slate-300 tabular-nums">{p.variants.length > 1 ? t('v3:kio_desde', { valor: money(p.variants[0].price) }) : money(p.variants[0].price)}</span>
                </span>
              </button>
            </li>
          );
        })}
      </ul>
      <footer className="flex items-center gap-4 border-t border-slate-800 p-4">
        <button type="button" onClick={restart} className="min-h-[64px] rounded-2xl px-5 text-lg font-bold text-slate-300 hover:bg-slate-800">{t('v3:cancelar')}</button>
        <button type="button" disabled={!count} onClick={() => setStep('review')} className="flex min-h-[72px] flex-1 items-center justify-between rounded-2xl bg-blue-600 px-6 text-2xl font-black text-white disabled:opacity-40">
          <span className="inline-flex items-center gap-3"><ShoppingBag className="h-7 w-7" aria-hidden />{t('v3:kio_ver_pedido', { count })}</span>
          <span className="tabular-nums">{money(total)}</span>
        </button>
      </footer>
      {open && <ProductSheet product={open} onAdd={add} onClose={() => setOpen(null)} />}
    </div>
  );
}
