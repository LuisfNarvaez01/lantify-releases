// ============================================
// DISPLAY - Kiosco de autoservicio (Fase 4 · 16)
// ============================================
// Tablet emparejada con código. El cliente ve la carta con fotos, elige
// presentación, quita ingredientes y deja un comentario, revisa su pedido, escribe
// su nombre y lo envía. Recibe un número (K7) para pagar en la caja o con el QR.
// Sin teclado del sistema: los campos usan el teclado propio de la pantalla. Si
// nadie toca la pantalla un rato, vuelve al inicio y se vacía el pedido.
// Mejoras: claro por defecto (u oscuro), "Lo más pedido", agregar con un toque,
// el pedido siempre a la vista en pantallas anchas, "¿Algo más?", comer aquí o
// para llevar y una cuenta regresiva al terminar.

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ArrowLeft, Check, Delete, Flame, Minus, Moon, Plus, QrCode, ShoppingBag, Store, Sun, Trash2, UtensilsCrossed, X } from 'lucide-react';
import { t } from '../../i18n';
import { api, mediaUrl, money, Unpaired, type DisplayTheme } from './displayApi';

export interface KioskFeed {
  now: string;
  display: { name: string; type: 'KIOSK' };
  business: { name: string; logoUrl: string | null };
  paymentQr: { url: string; label: string } | null;
  idleSeconds: number;
  categories: { id: string; name: string }[];
  /** Los más pedidos (ids de producto), del más al menos */
  popular?: string[];
  products: { id: string; name: string; description: string | null; imageUrl: string | null; categoryId: string | null; removable: string[]; variants: { id: string; name: string; price: number }[] }[];
}

type Product = KioskFeed['products'][number];
interface Line { key: string; variantId: string; productId: string; name: string; price: number; qty: number; removed: string[]; comment: string }

const POPULAR = '__popular';
const variantLabel = (v: { name: string }) => (v.name && v.name !== 'Única' && !['default', 'regular'].includes(v.name.toLowerCase()) ? v.name : '');
const noteOf = (l: Pick<Line, 'removed' | 'comment'>) => [...l.removed.map((r) => t('v3:sin_x', { x: r })), l.comment.trim()].filter(Boolean).join(' · ');
/** Sin presentaciones ni ingredientes para quitar: se agrega con un toque */
const isSimple = (p: Product) => p.variants.length === 1 && p.removable.length === 0;

// ── Teclado propio (la tablet no abre el teclado del sistema) ──
const ROWS = ['QWERTYUIOP', 'ASDFGHJKLÑ', 'ZXCVBNM'];
function OnScreenKeyboard({ value, onChange, max }: { value: string; onChange: (v: string) => void; max: number }) {
  const key = (k: string) => onChange((value + k).slice(0, max));
  const btn = 'min-h-[56px] flex-1 rounded-xl bg-slate-200 text-xl font-black text-slate-900 transition active:scale-95 active:bg-slate-300';
  return (
    <div className="space-y-2 select-none" aria-label={t('v3:kio_teclado')}>
      {ROWS.map((row, i) => (
        <div key={row} className="flex gap-1.5" style={{ paddingInline: `${i * 1.25}rem` }}>
          {row.split('').map((k) => <button key={k} type="button" className={btn} onClick={() => key(value && !value.endsWith(' ') ? k.toLowerCase() : k)}>{k}</button>)}
        </div>
      ))}
      <div className="flex gap-1.5">
        <button type="button" className={`${btn} flex-[5]`} onClick={() => key(' ')}>{t('v3:kio_espacio')}</button>
        <button type="button" className={`${btn} flex-[2]`} onClick={() => onChange(value.slice(0, -1))} aria-label={t('v3:asis_borrar')}><Delete className="mx-auto h-6 w-6" aria-hidden /></button>
      </div>
    </div>
  );
}

function Photo({ product, className }: { product: Product; className: string }) {
  const photo = mediaUrl(product.imageUrl);
  return photo
    ? <img src={photo} alt="" loading="lazy" className={`${className} object-cover`} />
    : <span className={`${className} grid place-items-center bg-gradient-to-br from-blue-50 to-slate-100 text-5xl font-black text-blue-700/50`}>{product.name.slice(0, 1)}</span>;
}

function ProductSheet({ product, onAdd, onClose }: { product: Product; onAdd: (l: Omit<Line, 'key'>) => void; onClose: () => void }) {
  const [variant, setVariant] = useState(product.variants[0]);
  const [removed, setRemoved] = useState<string[]>([]);
  const [comment, setComment] = useState('');
  const [typing, setTyping] = useState(false);
  const [qty, setQty] = useState(1);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);
  return (
    <div className="kiosk-fade fixed inset-0 z-20 flex items-end justify-center bg-black/50 sm:items-center" role="dialog" aria-modal="true" aria-labelledby="kio-prod" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="kiosk-sheet flex max-h-[95dvh] w-full max-w-3xl flex-col overflow-hidden rounded-t-3xl bg-white text-slate-900 shadow-2xl sm:rounded-3xl">
        <div className="flex-1 overflow-y-auto">
          {product.imageUrl && <Photo product={product} className="h-64 w-full" />}
          <div className="space-y-5 p-6">
            <div className="flex items-start justify-between gap-4">
              <div>
                <h2 id="kio-prod" className="text-3xl font-black">{product.name}</h2>
                {product.description && <p className="mt-1 text-lg text-slate-600">{product.description}</p>}
              </div>
              <button type="button" onClick={onClose} className="rounded-xl p-3 text-slate-500 hover:bg-slate-100" aria-label={t('v3:cancelar')}><X className="h-7 w-7" /></button>
            </div>
            {product.variants.length > 1 && (
              <fieldset>
                <legend className="text-lg font-black">{t('v3:kio_elige')}</legend>
                <div className="mt-2 grid grid-cols-2 gap-2">
                  {product.variants.map((v) => (
                    <button key={v.id} type="button" onClick={() => setVariant(v)} aria-pressed={variant.id === v.id} className={`min-h-[64px] rounded-2xl border-2 px-4 text-left text-lg font-bold transition ${variant.id === v.id ? 'border-blue-600 bg-blue-50' : 'border-slate-200'}`}>
                      {variantLabel(v) || product.name}<span className="block text-base font-semibold text-slate-600 tabular-nums">{money(v.price)}</span>
                    </button>
                  ))}
                </div>
              </fieldset>
            )}
            {product.removable.length > 0 && (
              <fieldset>
                <legend className="text-lg font-black">{t('v3:kio_quitar')}</legend>
                <div className="mt-2 flex flex-wrap gap-2">
                  {product.removable.map((r) => {
                    const off = removed.includes(r);
                    return (
                      <button key={r} type="button" aria-pressed={off} onClick={() => setRemoved((x) => (off ? x.filter((y) => y !== r) : [...x, r]))} className={`min-h-[52px] rounded-full border-2 px-5 text-lg font-bold transition ${off ? 'border-rose-600 bg-rose-50 text-rose-800 line-through' : 'border-slate-200'}`}>
                        {r}
                      </button>
                    );
                  })}
                </div>
              </fieldset>
            )}
            <div>
              <p className="text-lg font-black">{t('v3:kio_comentario')}</p>
              <button type="button" onClick={() => setTyping((v) => !v)} className={`mt-2 flex min-h-[60px] w-full items-center rounded-2xl border-2 px-4 text-left text-lg ${typing ? 'border-blue-600' : 'border-slate-200'} ${comment ? 'text-slate-900' : 'text-slate-500'}`}>
                {comment || t('v3:kio_comentario_ej')}{typing && <span className="ml-0.5 h-6 w-0.5 animate-pulse bg-blue-600" aria-hidden />}
              </button>
              {typing && <div className="mt-3"><OnScreenKeyboard value={comment} onChange={setComment} max={80} /></div>}
            </div>
          </div>
        </div>
        <footer className="flex items-center gap-4 border-t border-slate-200 p-4">
          <div className="flex items-center gap-2">
            <button type="button" onClick={() => setQty((q) => Math.max(1, q - 1))} className="grid h-14 w-14 place-items-center rounded-xl bg-slate-100 active:scale-95" aria-label={t('v3:kio_menos')}><Minus className="h-6 w-6" /></button>
            <span className="w-10 text-center text-2xl font-black tabular-nums" aria-live="polite">{qty}</span>
            <button type="button" onClick={() => setQty((q) => Math.min(20, q + 1))} className="grid h-14 w-14 place-items-center rounded-xl bg-slate-100 active:scale-95" aria-label={t('v3:kio_mas')}><Plus className="h-6 w-6" /></button>
          </div>
          <button
            type="button"
            onClick={() => onAdd({ variantId: variant.id, productId: product.id, name: [product.name, variantLabel(variant)].filter(Boolean).join(' · '), price: variant.price, qty, removed, comment })}
            className="flex min-h-[64px] flex-1 items-center justify-between rounded-2xl bg-blue-600 px-6 text-xl font-black text-white transition hover:bg-blue-500 active:scale-[0.98]"
          >
            <span>{t('v3:kio_agregar')}</span><span className="tabular-nums">{money(variant.price * qty)}</span>
          </button>
        </footer>
      </div>
    </div>
  );
}

/** Lista del pedido con + / − (en la revisión y en el panel lateral) */
function OrderLines({ lines, change, compact = false }: { lines: Line[]; change: (key: string, d: number) => void; compact?: boolean }) {
  return (
    <ul className="divide-y divide-slate-200">
      {lines.map((l) => (
        <li key={l.key} className="kiosk-pop flex items-center gap-3 py-3">
          <div className="min-w-0 flex-1">
            <p className={`${compact ? 'text-lg' : 'text-xl'} font-bold leading-tight`}>{l.name}</p>
            {noteOf(l) && <p className="text-base text-amber-700">{noteOf(l)}</p>}
            <p className="text-base text-slate-500 tabular-nums">{money(l.price * l.qty)}</p>
          </div>
          <button type="button" onClick={() => change(l.key, -1)} className={`grid ${compact ? 'h-11 w-11' : 'h-12 w-12'} place-items-center rounded-xl bg-slate-100 active:scale-95`} aria-label={l.qty === 1 ? t('v3:kio_quitar_linea') : t('v3:kio_menos')}>{l.qty === 1 ? <Trash2 className="h-5 w-5" /> : <Minus className="h-5 w-5" />}</button>
          <span className="w-7 text-center text-2xl font-black tabular-nums">{l.qty}</span>
          <button type="button" onClick={() => change(l.key, 1)} className={`grid ${compact ? 'h-11 w-11' : 'h-12 w-12'} place-items-center rounded-xl bg-slate-100 active:scale-95`} aria-label={t('v3:kio_mas')}><Plus className="h-5 w-5" /></button>
        </li>
      ))}
    </ul>
  );
}

type Step = 'start' | 'menu' | 'review' | 'sent';
const SENT_SECONDS = 25;

export function KioskScreen({ feed, token, onUnpaired, theme, onToggleTheme }: { feed: KioskFeed; token: string; onUnpaired: (err: unknown) => void; theme?: DisplayTheme; onToggleTheme?: () => void }) {
  const popular = useMemo(() => (feed.popular || []).filter((id) => feed.products.some((p) => p.id === id)), [feed.popular, feed.products]);
  const [step, setStep] = useState<Step>('start');
  const [category, setCategory] = useState<string | null>(null);
  const [open, setOpen] = useState<Product | null>(null);
  const [lines, setLines] = useState<Line[]>([]);
  const [name, setName] = useState('');
  const [payment, setPayment] = useState<'COUNTER' | 'QR'>('COUNTER');
  const [dineIn, setDineIn] = useState<'HERE' | 'TOGO'>('HERE');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [sent, setSent] = useState<{ number: string; total: number; payment: 'COUNTER' | 'QR' } | null>(null);
  const [bump, setBump] = useState(0);
  const [left, setLeft] = useState(SENT_SECONDS);
  const lastTouch = useRef(Date.now());

  const restart = useCallback(() => {
    setStep('start'); setLines([]); setName(''); setPayment('COUNTER'); setDineIn('HERE'); setOpen(null); setError(''); setSent(null); setCategory(null);
  }, []);

  // Inactividad: vuelve al inicio y vacía el pedido
  useEffect(() => {
    const touch = () => { lastTouch.current = Date.now(); };
    window.addEventListener('pointerdown', touch);
    window.addEventListener('keydown', touch);
    const id = setInterval(() => {
      const limit = (step === 'sent' ? SENT_SECONDS : feed.idleSeconds || 90) * 1000;
      if (step === 'sent') setLeft(Math.max(0, Math.ceil((limit - (Date.now() - lastTouch.current)) / 1000)));
      if (step !== 'start' && Date.now() - lastTouch.current > limit) restart();
    }, 1000);
    return () => { clearInterval(id); window.removeEventListener('pointerdown', touch); window.removeEventListener('keydown', touch); };
  }, [step, feed.idleSeconds, restart]);

  const products = useMemo(() => {
    if (category === POPULAR) return popular.map((id) => feed.products.find((p) => p.id === id)!).filter(Boolean);
    return feed.products.filter((p) => !category || p.categoryId === category);
  }, [feed.products, category, popular]);
  const count = lines.reduce((n, l) => n + l.qty, 0);
  const total = lines.reduce((n, l) => n + l.qty * l.price, 0);
  const inCart = useMemo(() => {
    const m = new Map<string, number>();
    for (const l of lines) m.set(l.productId, (m.get(l.productId) || 0) + l.qty);
    return m;
  }, [lines]);
  // "¿Algo más?": de lo más pedido, lo que aún no está en el pedido y se agrega con un toque
  const extras = useMemo(() => popular.map((id) => feed.products.find((p) => p.id === id)!).filter((p) => p && !inCart.has(p.id) && isSimple(p)).slice(0, 4), [popular, feed.products, inCart]);

  // Si un producto desapareció de la carta, sale del pedido
  useEffect(() => {
    const ids = new Set(feed.products.flatMap((p) => p.variants.map((v) => v.id)));
    setLines((ls) => (ls.every((l) => ids.has(l.variantId)) ? ls : ls.filter((l) => ids.has(l.variantId))));
  }, [feed.products]);

  const add = (l: Omit<Line, 'key'>) => {
    setLines((ls) => {
      const same = ls.find((x) => x.variantId === l.variantId && noteOf(x) === noteOf(l));
      if (same) return ls.map((x) => (x === same ? { ...x, qty: Math.min(20, x.qty + l.qty) } : x));
      return [...ls, { ...l, key: `${l.variantId}-${Date.now()}` }];
    });
    setOpen(null);
    setBump((b) => b + 1);
  };
  const quickAdd = (p: Product) => add({ variantId: p.variants[0].id, productId: p.id, name: p.name, price: p.variants[0].price, qty: 1, removed: [], comment: '' });
  const change = (key: string, d: number) => setLines((ls) => ls.flatMap((l) => (l.key !== key ? [l] : l.qty + d <= 0 ? [] : [{ ...l, qty: Math.min(20, l.qty + d) }])));

  const send = async () => {
    setBusy(true);
    setError('');
    try {
      const r = await api<{ number: string; total: number; payment: 'COUNTER' | 'QR' }>('POST', '/display/kiosk/order', token, {
        customerName: name.trim(),
        payment,
        dineIn,
        items: lines.map((l) => ({ variantId: l.variantId, qty: l.qty, note: noteOf(l) || undefined })),
      });
      setSent(r);
      setLeft(SENT_SECONDS);
      setStep('sent');
      setLines([]);
    } catch (err) {
      if (err instanceof Unpaired) { onUnpaired(err); return; }
      setError((err as Error)?.message || t('v3:pantalla_error'));
    } finally {
      setBusy(false);
    }
  };

  const logo = mediaUrl(feed.business.logoUrl);
  const qr = feed.paymentQr ? mediaUrl(feed.paymentQr.url) : null;
  const themeToggle = onToggleTheme && (
    <button type="button" onClick={(e) => { e.stopPropagation(); onToggleTheme(); }} className="rounded-xl p-2.5 text-slate-400 opacity-60 transition hover:bg-slate-100 hover:opacity-100" aria-label={theme === 'dark' ? t('v3:pantalla_tema_claro') : t('v3:pantalla_tema_oscuro')}>
      {theme === 'dark' ? <Sun className="h-5 w-5" aria-hidden /> : <Moon className="h-5 w-5" aria-hidden />}
    </button>
  );

  if (step === 'start') {
    const showcase = (popular.length ? popular.map((id) => feed.products.find((p) => p.id === id)!) : feed.products).filter((p) => p?.imageUrl).slice(0, 6);
    return (
      <div className="relative flex flex-1 overflow-hidden bg-slate-50">
        {showcase.length >= 3 && (
          <div className="pointer-events-none absolute inset-0 grid grid-cols-3 gap-3 p-3 opacity-25" aria-hidden>
            {showcase.map((p, i) => <div key={p.id} className="kiosk-float overflow-hidden rounded-3xl" style={{ animationDelay: `${i * 0.7}s` }}><Photo product={p} className="h-full w-full" /></div>)}
          </div>
        )}
        <div className="absolute right-3 top-3 z-10">{themeToggle}</div>
        <button type="button" onClick={() => { setStep('menu'); document.documentElement.requestFullscreen?.().catch(() => undefined); }} className="relative z-[1] flex flex-1 flex-col items-center justify-center gap-6 p-8 text-center">
          <span className="kiosk-rise flex flex-col items-center gap-6 rounded-[2.5rem] bg-white/90 px-12 py-10 shadow-xl backdrop-blur">
            {logo && <img src={logo} alt="" className="h-32 w-32 rounded-3xl bg-white object-contain p-2 shadow-sm" />}
            <span className="text-5xl font-black text-slate-900">{feed.business.name || 'Lantify'}</span>
            <span className="kiosk-breathe inline-flex min-h-[88px] items-center gap-3 rounded-3xl bg-blue-600 px-10 text-3xl font-black text-white shadow-lg shadow-blue-600/30"><ShoppingBag className="h-9 w-9" aria-hidden />{t('v3:kio_toca')}</span>
            <span className="text-lg text-slate-500">{t('v3:kio_toca_desc')}</span>
          </span>
        </button>
      </div>
    );
  }

  if (step === 'sent' && sent) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center gap-4 p-8 text-center" role="status">
        <span className="kiosk-check grid h-24 w-24 place-items-center rounded-full bg-emerald-500 shadow-lg shadow-emerald-500/30"><Check className="h-14 w-14 text-white" aria-hidden /></span>
        <p className="text-2xl font-bold text-slate-600">{t('v3:kio_tu_numero')}</p>
        <p className="kiosk-rise text-9xl font-black tabular-nums">{sent.number}</p>
        <p className="text-3xl font-black">{money(sent.total)}</p>
        {sent.payment === 'QR' && qr ? (
          <>
            <p className="max-w-xl text-xl text-slate-600">{t('v3:kio_paga_qr_desc')}</p>
            <img src={qr} alt={t('v3:cli_qr_pago')} className="max-h-[32vh] rounded-2xl bg-white p-2 shadow" />
            {feed.paymentQr!.label && <p className="text-lg font-bold text-slate-600">{feed.paymentQr!.label}</p>}
          </>
        ) : (
          <p className="max-w-xl text-xl text-slate-600">{t('v3:kio_paga_caja_desc')}</p>
        )}
        <button type="button" onClick={restart} className="mt-4 min-h-[64px] rounded-2xl bg-slate-900 px-8 text-xl font-black text-white">{t('v3:kio_listo')}</button>
        <p className="text-sm text-slate-500">{t('v3:kio_vuelve_en', { s: left })}</p>
      </div>
    );
  }

  if (step === 'review') {
    return (
      <div className="kiosk-fade flex flex-1 min-h-0 flex-col gap-4 p-6 lg:flex-row">
        <section className="flex min-h-0 flex-1 flex-col rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-200">
          <div className="flex items-center gap-3">
            <button type="button" onClick={() => setStep('menu')} className="inline-flex min-h-[52px] items-center gap-2 rounded-xl px-3 text-lg font-bold text-slate-600 hover:bg-slate-100"><ArrowLeft className="h-5 w-5" aria-hidden />{t('v3:kio_seguir')}</button>
            <h1 className="text-3xl font-black">{t('v3:kio_tu_pedido')}</h1>
          </div>
          <div className="mt-3 flex-1 overflow-y-auto"><OrderLines lines={lines} change={change} /></div>
          {extras.length > 0 && (
            <div className="mt-3 border-t border-slate-200 pt-3">
              <p className="text-lg font-black">{t('v3:kio_algo_mas')}</p>
              <ul className="mt-2 grid grid-cols-2 gap-2 xl:grid-cols-4">
                {extras.map((p) => (
                  <li key={p.id}>
                    <button type="button" onClick={() => quickAdd(p)} className="flex w-full items-center gap-2 rounded-2xl bg-slate-100 p-2 text-left transition hover:bg-blue-50 active:scale-[0.98]">
                      <Photo product={p} className="h-12 w-12 shrink-0 rounded-xl" />
                      <span className="min-w-0 flex-1"><span className="block truncate text-base font-bold">{p.name}</span><span className="text-sm text-slate-500 tabular-nums">+ {money(p.variants[0].price)}</span></span>
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          )}
          <p className="mt-3 flex justify-between border-t border-slate-200 pt-3 text-3xl font-black"><span>{t('v3:cli_total')}</span><span className="tabular-nums">{money(total)}</span></p>
        </section>
        <section className="flex w-full flex-col gap-4 overflow-y-auto rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-200 lg:w-[34rem]">
          <div>
            <p className="text-lg font-black">{t('v3:kio_tu_nombre')}</p>
            <div className="mt-2 flex min-h-[60px] items-center rounded-2xl border-2 border-blue-600 px-4 text-2xl font-bold" aria-live="polite">
              {name || <span className="text-slate-400">{t('v3:kio_nombre_ej')}</span>}<span className="ml-0.5 h-7 w-0.5 animate-pulse bg-blue-600" aria-hidden />
            </div>
            <div className="mt-3"><OnScreenKeyboard value={name} onChange={setName} max={40} /></div>
          </div>
          <fieldset>
            <legend className="text-lg font-black">{t('v3:kio_donde')}</legend>
            <div className="mt-2 grid grid-cols-2 gap-2">
              <button type="button" aria-pressed={dineIn === 'HERE'} onClick={() => setDineIn('HERE')} className={`flex min-h-[60px] items-center justify-center gap-2 rounded-2xl border-2 text-lg font-bold transition ${dineIn === 'HERE' ? 'border-blue-600 bg-blue-50' : 'border-slate-200'}`}><UtensilsCrossed className="h-6 w-6" aria-hidden />{t('v3:kio_aqui')}</button>
              <button type="button" aria-pressed={dineIn === 'TOGO'} onClick={() => setDineIn('TOGO')} className={`flex min-h-[60px] items-center justify-center gap-2 rounded-2xl border-2 text-lg font-bold transition ${dineIn === 'TOGO' ? 'border-blue-600 bg-blue-50' : 'border-slate-200'}`}><ShoppingBag className="h-6 w-6" aria-hidden />{t('v3:kio_llevar')}</button>
            </div>
          </fieldset>
          <fieldset>
            <legend className="text-lg font-black">{t('v3:kio_como_pagas')}</legend>
            <div className="mt-2 grid grid-cols-2 gap-2">
              <button type="button" aria-pressed={payment === 'COUNTER'} onClick={() => setPayment('COUNTER')} className={`flex min-h-[60px] items-center justify-center gap-2 rounded-2xl border-2 text-lg font-bold transition ${payment === 'COUNTER' ? 'border-blue-600 bg-blue-50' : 'border-slate-200'}`}><Store className="h-6 w-6" aria-hidden />{t('v3:kio_pagar_caja')}</button>
              {qr && <button type="button" aria-pressed={payment === 'QR'} onClick={() => setPayment('QR')} className={`flex min-h-[60px] items-center justify-center gap-2 rounded-2xl border-2 text-lg font-bold transition ${payment === 'QR' ? 'border-blue-600 bg-blue-50' : 'border-slate-200'}`}><QrCode className="h-6 w-6" aria-hidden />{t('v3:kio_pagar_qr')}</button>}
            </div>
          </fieldset>
          {error && <p role="alert" className="rounded-xl bg-rose-50 px-4 py-3 text-lg font-semibold text-rose-800">{error}</p>}
          <button type="button" disabled={busy || name.trim().length < 2 || !lines.length} onClick={send} className="mt-auto min-h-[72px] rounded-2xl bg-blue-600 text-2xl font-black text-white transition hover:bg-blue-500 active:scale-[0.98] disabled:opacity-40">
            {busy ? t('v3:cargando') : name.trim().length < 2 ? t('v3:kio_escribe_nombre') : t('v3:kio_enviar')}
          </button>
        </section>
      </div>
    );
  }

  const chips = [
    ...(popular.length ? [{ id: POPULAR as string | null, name: t('v3:kio_mas_pedido') }] : []),
    { id: null as string | null, name: t('v3:kio_todo') },
    ...feed.categories,
  ];
  return (
    <div className="flex flex-1 min-h-0">
      <div className="flex min-w-0 flex-1 flex-col">
        <nav className="flex items-center gap-2 overflow-x-auto border-b border-slate-200 bg-white px-4 py-3" aria-label={t('v3:kio_categorias')}>
          {chips.length > 1 && chips.map((c) => (
            <button key={c.id || 'all'} type="button" aria-pressed={category === c.id} onClick={() => setCategory(c.id)} className={`inline-flex min-h-[56px] items-center gap-2 whitespace-nowrap rounded-2xl px-5 text-lg font-black transition ${category === c.id ? 'bg-slate-900 text-white shadow' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'}`}>
              {c.id === POPULAR && <Flame className="h-5 w-5 text-orange-500" aria-hidden />}{c.name}
            </button>
          ))}
          <span className="ml-auto shrink-0">{themeToggle}</span>
        </nav>
        <ul key={category || 'all'} className="kiosk-fade grid flex-1 content-start gap-4 overflow-y-auto p-4" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(13rem, 1fr))' }}>
          {products.map((p) => {
            const n = inCart.get(p.id) || 0;
            return (
              <li key={p.id} className="relative">
                <button type="button" onClick={() => setOpen(p)} className={`flex h-full w-full flex-col overflow-hidden rounded-3xl bg-white text-left shadow-sm ring-1 transition hover:-translate-y-0.5 hover:shadow-md focus:outline-none focus-visible:ring-4 focus-visible:ring-blue-500 ${n ? 'ring-2 ring-blue-500' : 'ring-slate-200'}`}>
                  <Photo product={p} className="aspect-square w-full" />
                  <span className="block p-4 pr-16">
                    <span className="block text-xl font-black leading-tight">{p.name}</span>
                    <span className="mt-1 block text-lg font-bold text-slate-600 tabular-nums">{p.variants.length > 1 ? t('v3:kio_desde', { valor: money(p.variants[0].price) }) : money(p.variants[0].price)}</span>
                  </span>
                </button>
                {n > 0 && <span key={`${p.id}-${n}`} className="kiosk-pop absolute left-3 top-3 grid h-10 min-w-10 place-items-center rounded-full bg-blue-600 px-2 text-lg font-black text-white shadow" aria-label={t('v3:kio_en_pedido', { count: n })}>{n}</span>}
                <button type="button" onClick={() => (isSimple(p) ? quickAdd(p) : setOpen(p))} className="absolute bottom-3 right-3 grid h-12 w-12 place-items-center rounded-2xl bg-blue-600 text-white shadow-md transition hover:bg-blue-500 active:scale-90" aria-label={t('v3:kio_agregar_x', { name: p.name })}><Plus className="h-6 w-6" aria-hidden /></button>
              </li>
            );
          })}
        </ul>
        <footer className="flex items-center gap-4 border-t border-slate-200 bg-white p-4 lg:hidden">
          <button type="button" onClick={restart} className="min-h-[64px] rounded-2xl px-5 text-lg font-bold text-slate-600 hover:bg-slate-100">{t('v3:cancelar')}</button>
          <button type="button" disabled={!count} onClick={() => setStep('review')} className="flex min-h-[72px] flex-1 items-center justify-between rounded-2xl bg-blue-600 px-6 text-2xl font-black text-white transition disabled:opacity-40">
            <span className="inline-flex items-center gap-3"><ShoppingBag key={bump} className={`h-7 w-7 ${bump ? 'kiosk-pop' : ''}`} aria-hidden />{t('v3:kio_ver_pedido', { count })}</span>
            <span className="tabular-nums">{money(total)}</span>
          </button>
        </footer>
      </div>
      {/* Pantallas anchas: el pedido siempre a la vista */}
      <aside className="hidden w-[24rem] shrink-0 flex-col border-l border-slate-200 bg-white lg:flex" aria-label={t('v3:kio_tu_pedido')}>
        <h2 className="flex items-center gap-2 px-5 pt-5 text-2xl font-black"><ShoppingBag key={bump} className={`h-6 w-6 ${bump ? 'kiosk-pop' : ''}`} aria-hidden />{t('v3:kio_tu_pedido')}</h2>
        <div className="flex-1 overflow-y-auto px-5">
          {lines.length ? <OrderLines lines={lines} change={change} compact /> : <p className="mt-10 text-center text-lg text-slate-500">{t('v3:kio_vacio')}</p>}
        </div>
        <div className="space-y-3 border-t border-slate-200 p-5">
          <p className="flex justify-between text-2xl font-black"><span>{t('v3:cli_total')}</span><span className="tabular-nums">{money(total)}</span></p>
          <button type="button" disabled={!count} onClick={() => setStep('review')} className="min-h-[72px] w-full rounded-2xl bg-blue-600 text-2xl font-black text-white transition hover:bg-blue-500 active:scale-[0.98] disabled:opacity-40">{t('v3:kio_continuar')}</button>
          <button type="button" onClick={restart} className="min-h-[52px] w-full rounded-2xl text-lg font-bold text-slate-500 hover:bg-slate-100">{t('v3:cancelar')}</button>
        </div>
      </aside>
      {open && <ProductSheet product={open} onAdd={add} onClose={() => setOpen(null)} />}
    </div>
  );
}
