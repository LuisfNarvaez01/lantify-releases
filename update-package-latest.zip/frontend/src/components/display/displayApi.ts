// ============================================
// DISPLAY - Conexión de las pantallas con la caja (sin usuario, con su token)
// ============================================
// El token se guarda en este equipo al emparejar y viaja en la cabecera
// X-Display-Token (nunca en la dirección). Los avisos en vivo se leen con fetch,
// que sí puede mandar la cabecera.

import { useEffect, useRef } from 'react';
import { API_URL } from '../../config';
import { t } from '../../i18n';

const TOKEN_KEY = 'lantify.display.token';

export const readToken = () => { try { return localStorage.getItem(TOKEN_KEY); } catch { return null; } };
export const saveToken = (v: string | null) => { try { if (v) localStorage.setItem(TOKEN_KEY, v); else localStorage.removeItem(TOKEN_KEY); } catch { /* sin almacenamiento */ } };

export class Unpaired extends Error {}
export class DisplayApiError extends Error {
  constructor(message: string, public code: string, public status: number) {
    super(message);
  }
}

export const api = async <T,>(method: string, path: string, token: string | null, body?: unknown): Promise<T> => {
  const res = await fetch(`${API_URL}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { 'X-Display-Token': token } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && data?.code === 'DISPLAY_UNPAIRED') throw new Unpaired(data?.error || '');
  if (!res.ok) throw new DisplayApiError(data?.error || t('v3:pantalla_error'), data?.code || 'ERROR', res.status);
  return data as T;
};

/** Escucha los avisos en vivo de la caja; `onTopics` recibe qué cambió. Se reconecta sola. */
export function useDisplayEvents(token: string | null, onTopics: (topics: string[]) => void) {
  const cb = useRef(onTopics);
  cb.current = onTopics;
  useEffect(() => {
    if (!token) return;
    let alive = true;
    let ctrl: AbortController | null = null;
    let wait = 1000;
    const loop = async () => {
      while (alive) {
        ctrl = new AbortController();
        try {
          const res = await fetch(`${API_URL}/display/events`, { headers: { 'X-Display-Token': token }, signal: ctrl.signal });
          if (res.status === 401 || res.status === 403) return; // la pantalla sigue con su consulta periódica
          if (res.ok && res.body) {
            wait = 1000;
            const reader = res.body.getReader();
            const decoder = new TextDecoder();
            let buf = '';
            for (;;) {
              const { value, done } = await reader.read();
              if (done) break;
              buf += decoder.decode(value, { stream: true });
              let cut: number;
              while ((cut = buf.indexOf('\n\n')) >= 0) {
                const block = buf.slice(0, cut);
                buf = buf.slice(cut + 2);
                const data = /^data: (.+)$/m.exec(block)?.[1];
                if (!/^event: change$/m.test(block) || !data) continue;
                try {
                  const parsed = JSON.parse(data) as { topics?: string[] };
                  if (Array.isArray(parsed.topics)) cb.current(parsed.topics);
                } catch { /* aviso dañado */ }
              }
            }
          }
        } catch { /* sin conexión: se reintenta */ }
        if (!alive) return;
        await new Promise((r) => setTimeout(r, wait));
        wait = Math.min(wait * 2, 15_000);
      }
    };
    loop();
    return () => { alive = false; ctrl?.abort(); };
  }, [token]);
}

/** Imagen de la caja (/api/media/…) vista desde la pantalla */
export const mediaUrl = (url: string | null | undefined) => {
  if (!url) return null;
  if (/^https?:\/\//.test(url)) return url;
  return url.startsWith('/api/') ? `${API_URL.replace(/\/api\/?$/, '')}${url}` : url;
};

export const money = (n: number) => `$${Math.round(n).toLocaleString('es-CO')}`;
