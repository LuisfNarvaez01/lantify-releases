// ============================================
// DISPLAY - Conexión de las pantallas con la caja (sin usuario, con su token)
// ============================================
// El token se guarda en este equipo al emparejar y viaja en la cabecera
// X-Display-Token (nunca en la dirección). Los avisos en vivo se leen con fetch,
// que sí puede mandar la cabecera.

import { useEffect, useRef } from 'react';
import { API_URL } from '../../config';
import { t } from '../../i18n';

// ── Varias pantallas en un mismo equipo ──
// Antes había un solo token por navegador: al conectar el kiosco en otra pestaña se
// perdía la cocina. Ahora el equipo guarda la lista de sus pantallas; cada pestaña
// recuerda la suya (sessionStorage) y la dirección lleva ?id=… para volver a abrirla.
const LEGACY_KEY = 'lantify.display.token';
const LIST_KEY = 'lantify.display.screens';
const ACTIVE_KEY = 'lantify.display.active';

export interface SavedScreen { token: string; id: string | null; name: string; type: string; lastUsedAt: string }

const safe = <T,>(fn: () => T, fallback: T): T => { try { return fn(); } catch { return fallback; } };

export const savedScreens = (): SavedScreen[] => safe(() => {
  const list = JSON.parse(localStorage.getItem(LIST_KEY) || '[]');
  const out: SavedScreen[] = Array.isArray(list) ? list.filter((x) => x && typeof x.token === 'string') : [];
  // Equipos que ya tenían una pantalla conectada con la versión anterior
  const legacy = localStorage.getItem(LEGACY_KEY);
  if (legacy && !out.some((x) => x.token === legacy)) out.push({ token: legacy, id: null, name: '', type: '', lastUsedAt: new Date(0).toISOString() });
  return out;
}, []);

const writeScreens = (list: SavedScreen[]) => safe(() => {
  localStorage.setItem(LIST_KEY, JSON.stringify(list.slice(0, 12)));
  localStorage.removeItem(LEGACY_KEY);
}, undefined);

const urlId = () => safe(() => new URLSearchParams(window.location.search).get('id'), null);
const setUrlId = (id: string | null) => safe(() => {
  const url = new URL(window.location.href);
  if (id) url.searchParams.set('id', id); else url.searchParams.delete('id');
  url.searchParams.delete('nueva');
  window.history.replaceState(null, '', url.toString());
}, undefined);

/** ¿Se abrió para conectar otra pantalla (?nueva=1)? */
export const wantsNew = () => safe(() => new URLSearchParams(window.location.search).has('nueva'), false);

/** El token de esta pestaña: el de la dirección, el que ya usaba o, si el equipo tiene una sola, esa */
export const readToken = (): string | null => {
  if (wantsNew()) return null;
  const list = savedScreens();
  const id = urlId();
  if (id) { const hit = list.find((x) => x.id === id); if (hit) return hit.token; }
  const active = safe(() => sessionStorage.getItem(ACTIVE_KEY), null);
  if (active && list.some((x) => x.token === active)) return active;
  return list.length === 1 ? list[0].token : null;
};

/** Esta pestaña queda con esta pantalla (null = desconectar esta pestaña y olvidarla) */
export const saveToken = (v: string | null, forget?: string | null) => {
  safe(() => { if (v) sessionStorage.setItem(ACTIVE_KEY, v); else sessionStorage.removeItem(ACTIVE_KEY); }, undefined);
  if (!v && forget) { writeScreens(savedScreens().filter((x) => x.token !== forget)); setUrlId(null); }
  if (v && !savedScreens().some((x) => x.token === v)) writeScreens([...savedScreens(), { token: v, id: null, name: '', type: '', lastUsedAt: new Date().toISOString() }]);
};

/** Al recibir la pantalla: se guarda su nombre y su id (para la lista y la dirección) */
export const rememberScreen = (token: string, d: { id?: string; name: string; type: string }) => {
  const list = savedScreens();
  const cur = list.find((x) => x.token === token);
  if (cur && cur.id === (d.id || null) && cur.name === d.name && cur.type === d.type) { if (d.id && urlId() !== d.id) setUrlId(d.id); return; }
  writeScreens([...list.filter((x) => x.token !== token), { token, id: d.id || null, name: d.name, type: d.type, lastUsedAt: new Date().toISOString() }]);
  if (d.id && urlId() !== d.id) setUrlId(d.id);
};

/** Abre otra ventana para conectar una pantalla más en este equipo */
export const openAnotherScreen = () => { window.open(`${window.location.pathname}?nueva=1`, '_blank', 'noopener'); };

// ── Tema: cada pantalla es clara por defecto; se cambia con el sol / la luna ──
export type DisplayTheme = 'light' | 'dark';
export const applyDisplayTheme = (theme: DisplayTheme) => {
  const root = document.documentElement;
  if (root.dataset.theme !== theme) root.dataset.theme = theme;
};

export class Unpaired extends Error {}
export class DisplayApiError extends Error {
  constructor(message: string, public code: string, public status: number) {
    super(message);
  }
}

export const api = async <T,>(method: string, path: string, token: string | null, body?: unknown): Promise<T> => {
  const res = await fetch(`${API_URL}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { 'X-Display-Token': token } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && data?.code === 'DISPLAY_UNPAIRED') throw new Unpaired(data?.error || '');
  if (!res.ok) throw new DisplayApiError(data?.error || t('v3:pantalla_error'), data?.code || 'ERROR', res.status);
  return data as T;
};

/** Escucha los avisos en vivo de la caja; `onTopics` recibe qué cambió. Se reconecta sola. */
export function useDisplayEvents(token: string | null, onTopics: (topics: string[]) => void) {
  const cb = useRef(onTopics);
  cb.current = onTopics;
  useEffect(() => {
    if (!token) return;
    let alive = true;
    let ctrl: AbortController | null = null;
    let wait = 1000;
    const loop = async () => {
      while (alive) {
        ctrl = new AbortController();
        try {
          const res = await fetch(`${API_URL}/display/events`, { headers: { 'X-Display-Token': token }, signal: ctrl.signal });
          if (res.status === 401 || res.status === 403) return; // la pantalla sigue con su consulta periódica
          if (res.ok && res.body) {
            wait = 1000;
            const reader = res.body.getReader();
            const decoder = new TextDecoder();
            let buf = '';
            for (;;) {
              const { value, done } = await reader.read();
              if (done) break;
              buf += decoder.decode(value, { stream: true });
              let cut: number;
              while ((cut = buf.indexOf('\n\n')) >= 0) {
                const block = buf.slice(0, cut);
                buf = buf.slice(cut + 2);
                const data = /^data: (.+)$/m.exec(block)?.[1];
                if (!/^event: change$/m.test(block) || !data) continue;
                try {
                  const parsed = JSON.parse(data) as { topics?: string[] };
                  if (Array.isArray(parsed.topics)) cb.current(parsed.topics);
                } catch { /* aviso dañado */ }
              }
            }
          }
        } catch { /* sin conexión: se reintenta */ }
        if (!alive) return;
        await new Promise((r) => setTimeout(r, wait));
        wait = Math.min(wait * 2, 15_000);
      }
    };
    loop();
    return () => { alive = false; ctrl?.abort(); };
  }, [token]);
}

/** Imagen de la caja (/api/media/…) vista desde la pantalla */
export const mediaUrl = (url: string | null | undefined) => {
  if (!url) return null;
  if (/^https?:\/\//.test(url)) return url;
  return url.startsWith('/api/') ? `${API_URL.replace(/\/api\/?$/, '')}${url}` : url;
};

export const money = (n: number) => `$${Math.round(n).toLocaleString('es-CO')}`;
