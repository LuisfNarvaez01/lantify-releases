// ============================================
// DISPLAY - Pantallas en TV (Lantify 3.0 · bloque 2)
// ============================================
// Se abre en http://<ip-de-la-caja>:5000/pantalla. Sin usuario: la pantalla se
// conecta una vez con el código de 6 dígitos y guarda su token. Consulta cada 3 s.
// Cocina: comandas por llegada, Listo / Deshacer, con toque, mouse o teclado.
// Entregas: números grandes para clientes. Salón: el plano para meseros.

import { FormEvent, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Bell, BellOff, Check, ChefHat, Maximize, RotateCcw, Unplug, WifiOff } from 'lucide-react';
import { API_URL } from '../../config';
import { t } from '../../i18n';
import type { KitchenTicket, PickupOrder } from '../../../../src/domain/v3/kitchen';

const TOKEN_KEY = 'lantify.display.token';
const POLL_MS = 3000;

const readToken = () => { try { return localStorage.getItem(TOKEN_KEY); } catch { return null; } };
const saveToken = (v: string | null) => { try { if (v) localStorage.setItem(TOKEN_KEY, v); else localStorage.removeItem(TOKEN_KEY); } catch { /* sin almacenamiento */ } };

class Unpaired extends Error {}

const api = async <T,>(method: string, path: string, token: string | null, body?: unknown): Promise<T> => {
  const res = await fetch(`${API_URL}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { 'X-Display-Token': token } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401) throw new Unpaired(data?.error || '');
  if (!res.ok) throw new Error(data?.error || t('v3:pantalla_error'));
  return data as T;
};

interface Base { now: string; display: { name: string; type: 'KITCHEN' | 'PICKUP' | 'FLOOR'; station: string | null } }
type KitchenFeed = Base & { tickets: KitchenTicket[]; lastReady: { label: string; itemIds: string[] } | null };
type PickupFeed = Base & { preparing: PickupOrder[]; ready: PickupOrder[] };
type FloorFeed = Base & {
  tables: { id: string; number: string; zone: string | null; status: string }[];
  alerts: { tableId: string; tableNumber: string; kind: string; minutes: number }[];
  pickups: { tableId: string; tableNumber: string; waiterName: string | null; count: number }[];
  bills: { tableId: string }[];
};
type Feed = KitchenFeed | PickupFeed | FloorFeed;

// ── Sonido corto al llegar una comanda (el navegador exige un toque antes) ──
let audio: AudioContext | null = null;
const beep = () => {
  try {
    audio ||= new AudioContext();
    const o = audio.createOscillator();
    const g = audio.createGain();
    o.frequency.value = 880;
    g.gain.setValueAtTime(0.0001, audio.currentTime);
    g.gain.exponentialRampToValueAtTime(0.4, audio.currentTime + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, audio.currentTime + 0.35);
    o.connect(g).connect(audio.destination);
    o.start();
    o.stop(audio.currentTime + 0.4);
  } catch { /* sin audio */ }
};

function Pairing({ onPaired }: { onPaired: (token: string) => void }) {
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      const r = await api<{ token: string }>('POST', '/display/pair', null, { code });
      saveToken(r.token);
      onPaired(r.token);
    } catch (err: any) {
      setError(err?.message || t('v3:pantalla_error'));
    } finally {
      setBusy(false);
    }
  };
  return (
    <main className="min-h-[100dvh] bg-slate-950 text-white flex items-center justify-center p-6">
      <form onSubmit={submit} className="w-full max-w-lg text-center">
        <img src="/logo-lantify-white.svg" alt="Lantify" className="mx-auto h-12" />
        <h1 className="mt-8 text-3xl font-black">{t('v3:conectar_pantalla')}</h1>
        <p className="mt-2 text-slate-400">{t('v3:conectar_pantalla_desc')}</p>
        <label htmlFor="pair-code" className="sr-only">{t('v3:codigo')}</label>
        <input
          id="pair-code"
          autoFocus
          inputMode="numeric"
          autoComplete="one-time-code"
          maxLength={6}
          value={code}
          onChange={(e) => setCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
          className="mt-8 w-full rounded-2xl border-2 border-slate-700 bg-slate-900 py-5 text-center font-mono text-6xl font-black tracking-[0.4em] text-white focus:border-blue-500 focus:outline-none"
          placeholder="······"
        />
        {error && <p role="alert" className="mt-4 rounded-xl bg-rose-500/15 px-4 py-3 text-rose-200">{error}</p>}
        <button type="submit" disabled={code.length !== 6 || busy} className="mt-6 w-full min-h-[64px] rounded-2xl bg-blue-600 text-xl font-black disabled:opacity-40">{t('v3:conectar')}</button>
      </form>
    </main>
  );
}

const LEVEL: Record<KitchenTicket['level'], string> = {
  ok: 'bg-emerald-600',
  warn: 'bg-amber-500 text-slate-950',
  late: 'bg-rose-600 animate-pulse',
};

function KitchenBoard({ feed, token, refresh }: { feed: KitchenFeed; token: string; refresh: () => void }) {
  const [struck, setStruck] = useState<Set<string>>(new Set());
  const [selected, setSelected] = useState(0);
  const [busy, setBusy] = useState<string | null>(null);
  const tickets = feed.tickets;

  const ready = useCallback(async (ticket: KitchenTicket) => {
    setBusy(ticket.key);
    try {
      await api('POST', '/display/ready', token, { itemIds: ticket.lines.filter((l) => !l.ready).map((l) => l.id) });
      refresh();
    } finally {
      setBusy(null);
    }
  }, [token, refresh]);

  const undo = useCallback(async () => {
    if (!feed.lastReady) return;
    await api('POST', '/display/undo', token, { itemIds: feed.lastReady.itemIds });
    refresh();
  }, [feed.lastReady, token, refresh]);

  // Teclado: 1-9 elige, Enter = listo, U o Retroceso = deshacer
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (/^[1-9]$/.test(e.key)) setSelected(Number(e.key) - 1);
      else if (e.key === 'ArrowRight') setSelected((s) => Math.min(s + 1, tickets.length - 1));
      else if (e.key === 'ArrowLeft') setSelected((s) => Math.max(s - 1, 0));
      else if (e.key === 'Enter' && tickets[selected]) ready(tickets[selected]);
      else if (e.key === 'u' || e.key === 'U' || e.key === 'Backspace') undo();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [tickets, selected, ready, undo]);

  useEffect(() => { if (selected >= tickets.length) setSelected(Math.max(0, tickets.length - 1)); }, [tickets.length, selected]);

  return (
    <div className="flex-1 min-h-0 overflow-y-auto p-4">
      {feed.lastReady && (
        <button type="button" onClick={undo} className="mb-4 inline-flex min-h-[48px] items-center gap-2 rounded-xl bg-slate-800 px-4 text-lg font-bold text-slate-200 hover:bg-slate-700">
          <RotateCcw className="h-5 w-5" aria-hidden /> {t('v3:deshacer_listo', { label: feed.lastReady.label })}
        </button>
      )}
      {tickets.length === 0 ? (
        <div className="flex h-[60vh] flex-col items-center justify-center text-slate-500">
          <ChefHat className="h-20 w-20" aria-hidden />
          <p className="mt-4 text-3xl font-bold">{t('v3:sin_comandas')}</p>
        </div>
      ) : (
        <ol className="grid gap-4" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(19rem, 1fr))' }}>
          {tickets.map((tk, i) => (
            <li key={tk.key} className={`flex flex-col overflow-hidden rounded-2xl bg-slate-900 ring-4 ${i === selected ? 'ring-blue-500' : 'ring-transparent'}`}>
              <header className={`flex items-center justify-between gap-3 px-4 py-3 ${LEVEL[tk.level]}`}>
                <div className="min-w-0">
                  <p className="text-3xl font-black leading-none">{tk.isTable ? t('v3:mesa_n', { n: tk.label }) : tk.label}</p>
                  <p className="mt-1 truncate text-sm font-bold opacity-90">{[tk.roundNumber ? t('v3:ronda_n', { n: tk.roundNumber }) : null, tk.waiterName].filter(Boolean).join(' · ')}</p>
                </div>
                <div className="text-right">
                  <p className="text-4xl font-black tabular-nums leading-none">{tk.minutes}′</p>
                  <p className="text-xs font-bold opacity-80">{i + 1}</p>
                </div>
              </header>
              <ul className="flex-1 divide-y divide-slate-800 px-4">
                {tk.lines.map((l) => {
                  const off = l.ready || struck.has(l.id);
                  return (
                    <li key={l.id}>
                      <button type="button" onClick={() => setStruck((s) => { const n = new Set(s); if (n.has(l.id)) n.delete(l.id); else n.add(l.id); return n; })} className={`w-full py-3 text-left ${off ? 'opacity-40 line-through' : ''}`}>
                        <span className="flex items-baseline gap-3">
                          <span className="min-w-[2.5rem] text-3xl font-black tabular-nums text-white">{l.quantity}×</span>
                          <span className="text-2xl font-bold leading-tight text-white">{l.name}</span>
                        </span>
                        {l.removed.length > 0 && (
                          <span className="mt-1 flex flex-wrap gap-1.5 pl-[3.25rem]">
                            {l.removed.map((r) => <span key={r} className="rounded-md bg-rose-600 px-2 py-0.5 text-base font-black uppercase text-white">{t('v3:sin_x', { x: r })}</span>)}
                          </span>
                        )}
                        {l.notes && <span className="mt-1 block pl-[3.25rem] text-lg font-semibold text-amber-300">{l.notes}</span>}
                      </button>
                    </li>
                  );
                })}
              </ul>
              <button type="button" disabled={busy === tk.key} onClick={() => ready(tk)} className="m-3 inline-flex min-h-[64px] items-center justify-center gap-2 rounded-xl bg-emerald-500 text-2xl font-black text-slate-950 hover:bg-emerald-400 disabled:opacity-60">
                <Check className="h-7 w-7" aria-hidden /> {t('v3:listo')}
              </button>
            </li>
          ))}
        </ol>
      )}
    </div>
  );
}

function PickupBoard({ feed }: { feed: PickupFeed }) {
  return (
    <div className="grid flex-1 min-h-0 grid-cols-2 gap-6 p-6">
      <section className="flex flex-col rounded-3xl bg-slate-900 p-6">
        <h2 className="text-3xl font-black text-slate-300">{t('v3:preparando')}</h2>
        <ul className="mt-6 grid content-start gap-4" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(9rem, 1fr))' }}>
          {feed.preparing.map((o) => <li key={o.orderId} className="rounded-2xl bg-slate-800 py-5 text-center text-5xl font-black tabular-nums text-slate-200">{o.label}</li>)}
        </ul>
      </section>
      <section className="flex flex-col rounded-3xl bg-emerald-600 p-6 text-slate-950">
        <h2 className="text-3xl font-black">{t('v3:listo_recoge')}</h2>
        <ul className="mt-6 grid content-start gap-4" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(11rem, 1fr))' }}>
          {feed.ready.map((o, i) => <li key={o.orderId} className={`rounded-2xl bg-white py-6 text-center text-6xl font-black tabular-nums ${i === 0 ? 'ring-8 ring-white/50' : ''}`}>{o.label}</li>)}
        </ul>
      </section>
    </div>
  );
}

const TABLE_TONE: Record<string, string> = {
  AVAILABLE: 'bg-slate-800 text-slate-300',
  ORDERED: 'bg-blue-600 text-white',
  PENDING: 'bg-violet-600 text-white',
  DIRTY: 'bg-slate-700 text-slate-300 border-2 border-dashed border-slate-400',
};

function FloorBoard({ feed }: { feed: FloorFeed }) {
  const pickups = new Map(feed.pickups.map((p) => [p.tableId, p]));
  const alerts = new Map(feed.alerts.map((a) => [a.tableId, a]));
  return (
    <div className="flex flex-1 min-h-0 gap-4 p-4">
      <ul className="grid flex-1 content-start gap-3 overflow-y-auto" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(8.5rem, 1fr))' }}>
        {feed.tables.map((tb) => {
          const p = pickups.get(tb.id);
          const a = alerts.get(tb.id);
          return (
            <li key={tb.id} className={`relative flex min-h-[8rem] flex-col items-center justify-center rounded-2xl p-3 text-center ${TABLE_TONE[tb.status] || TABLE_TONE.AVAILABLE} ${a ? 'ring-4 ring-amber-400' : ''}`}>
              <span className="text-4xl font-black">{tb.number}</span>
              <span className="mt-1 text-sm font-bold opacity-90">{t(`v3:estado_${tb.status}`)}</span>
              {p && <span className="absolute -right-2 -top-2 rounded-full bg-emerald-400 px-2.5 py-1 text-sm font-black text-slate-950">{t('v3:recoger_n', { count: p.count })}</span>}
              {a && <span className="mt-1 text-xs font-black text-amber-300">{t(`v3:alerta_corta_${a.kind}`, { min: a.minutes })}</span>}
            </li>
          );
        })}
      </ul>
      <aside className="w-80 shrink-0 space-y-3 overflow-y-auto">
        <h2 className="text-xl font-black text-emerald-400">{t('v3:para_recoger')}</h2>
        {feed.pickups.length === 0 && <p className="text-slate-500">{t('v3:nada_para_recoger')}</p>}
        {feed.pickups.map((p) => (
          <div key={p.tableId} className="rounded-2xl bg-emerald-500 p-4 text-slate-950">
            <p className="text-3xl font-black">{t('v3:mesa_n', { n: p.tableNumber })}</p>
            <p className="font-bold">{t('v3:platos_listos', { count: p.count })}{p.waiterName ? ` · ${p.waiterName}` : ''}</p>
          </div>
        ))}
      </aside>
    </div>
  );
}

export function DisplayApp() {
  const [token, setToken] = useState<string | null>(readToken);
  const [feed, setFeed] = useState<Feed | null>(null);
  const [offline, setOffline] = useState(false);
  const [sound, setSound] = useState(false);
  const [clock, setClock] = useState(() => new Date());
  const seen = useRef<Set<string> | null>(null);

  const load = useCallback(async () => {
    if (!token) return;
    try {
      const f = await api<Feed>('GET', '/display/feed', token);
      setFeed(f);
      setOffline(false);
      if ('tickets' in f) {
        const keys = new Set(f.tickets.map((x) => x.key));
        if (seen.current && sound && [...keys].some((k) => !seen.current!.has(k))) beep();
        seen.current = keys;
      }
    } catch (err) {
      if (err instanceof Unpaired) { saveToken(null); setToken(null); setFeed(null); return; }
      setOffline(true);
    }
  }, [token, sound]);

  useEffect(() => {
    load();
    const id = setInterval(load, POLL_MS);
    const tick = setInterval(() => setClock(new Date()), 15_000);
    return () => { clearInterval(id); clearInterval(tick); };
  }, [load]);

  // Que el TV no se apague mientras muestra la pantalla
  useEffect(() => {
    let lock: any = null;
    (navigator as any).wakeLock?.request('screen').then((l: any) => { lock = l; }).catch(() => undefined);
    return () => { lock?.release?.().catch?.(() => undefined); };
  }, [token]);

  const title = useMemo(() => feed?.display.name || '', [feed]);
  if (!token) return <Pairing onPaired={setToken} />;

  const pending = feed && 'tickets' in feed ? feed.tickets.length : null;
  return (
    <div className="flex h-[100dvh] flex-col bg-slate-950 text-white">
      <header className="flex items-center gap-4 border-b border-slate-800 px-5 py-3">
        <img src="/logo-lantify-white.svg" alt="Lantify" className="h-8" />
        <h1 className="flex-1 truncate text-2xl font-black">{title}{pending !== null ? <span className="ml-3 rounded-full bg-slate-800 px-3 py-1 text-lg tabular-nums">{pending}</span> : null}</h1>
        {offline && <span className="inline-flex items-center gap-2 rounded-full bg-rose-600 px-3 py-1.5 text-sm font-bold"><WifiOff className="h-4 w-4" aria-hidden />{t('v3:sin_conexion_caja')}</span>}
        <span className="text-2xl font-black tabular-nums text-slate-300">{clock.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
        {feed?.display.type === 'KITCHEN' && (
          <button type="button" onClick={() => { setSound((s) => !s); if (!sound) beep(); }} className="rounded-xl p-2.5 text-slate-300 hover:bg-slate-800" aria-label={sound ? t('v3:silenciar') : t('v3:activar_sonido')} aria-pressed={sound}>
            {sound ? <Bell className="h-6 w-6" /> : <BellOff className="h-6 w-6" />}
          </button>
        )}
        <button type="button" onClick={() => document.documentElement.requestFullscreen?.().catch(() => undefined)} className="rounded-xl p-2.5 text-slate-300 hover:bg-slate-800" aria-label={t('v3:pantalla_completa')}><Maximize className="h-6 w-6" /></button>
        <button type="button" onClick={() => { saveToken(null); setToken(null); setFeed(null); }} className="rounded-xl p-2.5 text-slate-500 hover:bg-slate-800" aria-label={t('v3:desconectar')}><Unplug className="h-6 w-6" /></button>
      </header>
      {!feed ? (
        <p className="m-auto text-xl text-slate-400">{offline ? t('v3:sin_conexion_caja') : t('v3:cargando')}</p>
      ) : 'tickets' in feed ? (
        <KitchenBoard feed={feed} token={token} refresh={load} />
      ) : 'preparing' in feed ? (
        <PickupBoard feed={feed} />
      ) : (
        <FloorBoard feed={feed as FloorFeed} />
      )}
    </div>
  );
}
