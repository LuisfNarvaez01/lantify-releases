// ============================================
// COMPONENTS - Tarjeta de sellos en la ficha del cliente
// ============================================
// Sumar o quitar a mano se ve al instante y se envía a su tarjeta digital (sin
// internet queda en cola). El saldo se refresca solo mientras la ficha está abierta:
// así también se ven los sellos que el cliente reclamó con el QR del ticket.

import { useCallback, useEffect, useState } from 'react';
import { Award, Gift, Link2, Minus, Plus, Smartphone, UserPlus } from 'lucide-react';
import { loyaltyAPI, LoyaltyStatus } from '../../services/api';
import { errorMessage } from '../../services/apiErrors';
import { promptDialog } from '../../shared/dialog';
import { toast } from '../../shared/toast';
import { useBusiness } from '../../shared/business';
import { useFeature } from '../../shared/plan';
import { t } from '../../i18n';
import { CardLinkDialog, StampDots, StampSyncLine, useStampEventStatus } from './StampCard';

interface Props {
  customer: { id: string; name: string; phone?: string | null };
  /** El saldo cambió (para actualizar la lista de clientes) */
  onChange?: (stampsCount: number, lifetimeStamps: number) => void;
}

export function CustomerStampPanel({ customer, onChange }: Props) {
  const allowed = useFeature('loyalty');
  const businessName = useBusiness().settings?.businessName || 'Lantify';
  const [status, setStatus] = useState<LoyaltyStatus | null>(null);
  const [busy, setBusy] = useState(false);
  const [fresh, setFresh] = useState(0);
  const [eventId, setEventId] = useState<string | null>(null);
  const [showLink, setShowLink] = useState(false);
  const sync = useStampEventStatus(eventId);

  const load = useCallback(async () => {
    try {
      const s = await loyaltyAPI.status(customer.id);
      setStatus(s);
      return s;
    } catch {
      return null;
    }
  }, [customer.id]);

  useEffect(() => {
    if (!allowed) return;
    setStatus(null);
    setEventId(null);
    load();
    const timer = window.setInterval(() => document.visibilityState === 'visible' && load(), 8000);
    return () => window.clearInterval(timer);
  }, [allowed, load]);

  // Cuando el movimiento llega a la nube, el saldo puede cambiar (premio entregado al completar)
  useEffect(() => {
    if (sync.status && sync.status !== 'QUEUED') load();
  }, [sync.status, load]);

  useEffect(() => {
    if (status) onChange?.(status.stampsCount, status.lifetimeStamps);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status?.stampsCount, status?.lifetimeStamps]);

  if (!allowed || !status) return null;
  if (!status.enabled) {
    return <p className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-xs text-amber-900">{t('loyalty:desactivada')}</p>;
  }

  const first = customer.name.split(' ')[0];
  const required = status.stampsRequired;
  const completed = !status.hasCard && status.stampsCount >= required;

  const adjust = async (delta: number, reason?: string) => {
    setBusy(true);
    try {
      const updated = await loyaltyAPI.adjust(customer.id, delta, reason);
      setStatus((s) => (s ? { ...s, stampsCount: updated.stampsCount ?? s.stampsCount, lifetimeStamps: updated.lifetimeStamps ?? s.lifetimeStamps } : s));
      setFresh(delta > 0 ? delta : 0);
      setEventId(updated.stampEventId);
      load();
      toast.success(delta > 0 ? t('loyalty:sello_sumado', { name: first }) : t('loyalty:sello_quitado', { name: first }));
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusy(false);
    }
  };

  const add = async () => {
    const reason = await promptDialog({ title: t('loyalty:sumar'), label: t('common:motivo'), placeholder: t('loyalty:motivo_sumar'), required: false });
    if (reason === null) return;
    adjust(1, reason || undefined);
  };
  const remove = async () => {
    const reason = await promptDialog({ title: t('loyalty:quitar'), label: t('common:motivo'), placeholder: t('loyalty:motivo_quitar'), tone: 'danger' });
    if (!reason) return;
    adjust(-1, reason);
  };

  return (
    <section aria-labelledby={`stamps-${customer.id}`} className="space-y-3 rounded-2xl border border-amber-200/80 bg-amber-50/60 p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-2">
          <Award className="h-5 w-5 shrink-0 text-amber-600" aria-hidden />
          <div>
            <h5 id={`stamps-${customer.id}`} className="text-sm font-extrabold text-amber-950">{t('loyalty:tarjeta')}</h5>
            <p className="text-[0.7857rem] text-amber-800">{t('loyalty:meta', { total: required, reward: status.rewardText })}</p>
          </div>
        </div>
        <span className="shrink-0 rounded-full bg-amber-500 px-2.5 py-1 text-xs font-black tabular-nums text-white shadow-sm">
          {Math.min(status.stampsCount, required)} / {required}
        </span>
      </div>

      <StampDots count={status.stampsCount} total={required} fresh={fresh} size={required > 10 ? 'sm' : 'md'} />

      {completed && (
        <button
          type="button"
          disabled={busy}
          onClick={() => adjust(-required, t('loyalty:tarjeta_completa', { reward: status.rewardText }))}
          className="flex w-full min-h-[44px] items-center justify-center gap-2 rounded-xl bg-emerald-600 text-sm font-bold text-white hover:bg-emerald-700 disabled:opacity-50"
        >
          <Gift className="h-4 w-4" aria-hidden /> {t('loyalty:tarjeta_completa', { reward: status.rewardText })}
        </button>
      )}

      {eventId && <StampSyncLine status={sync.status} settled={sync.settled} hasCard={status.hasCard} linked={status.linked} />}

      <div className="flex flex-wrap items-center justify-between gap-2 border-t border-amber-200/60 pt-3 text-[0.7857rem] text-amber-900">
        {status.linked && (
          <span className="inline-flex items-center gap-1.5 font-semibold">
            {status.hasCard ? <Smartphone className="h-3.5 w-3.5" aria-hidden /> : <UserPlus className="h-3.5 w-3.5" aria-hidden />}
            {t('loyalty:estado_tarjeta')}: {status.hasCard ? t('loyalty:con_tarjeta') : t('loyalty:sin_tarjeta')}
          </span>
        )}
        <span className="tabular-nums">{t('loyalty:historico', { count: status.lifetimeStamps })}</span>
        {status.linked && status.queued > 0 && <span className="w-full font-semibold text-amber-800">{t('loyalty:pendientes_cola', { count: status.queued })}</span>}
        {status.linked && status.waitingSignup > 0 && !status.hasCard && <span className="w-full font-semibold text-sky-800">{t('loyalty:esperan_registro', { count: status.waitingSignup })}</span>}
      </div>

      <div className="grid grid-cols-[auto_1fr] gap-2">
        <button
          type="button"
          disabled={busy || status.stampsCount <= 0}
          onClick={remove}
          aria-label={t('loyalty:quitar')}
          title={t('loyalty:quitar')}
          className="grid min-h-[44px] w-11 place-items-center rounded-xl border border-amber-300 bg-white text-amber-900 hover:bg-amber-100 disabled:opacity-40"
        >
          <Minus className="h-4 w-4" aria-hidden />
        </button>
        <button
          type="button"
          disabled={busy}
          onClick={add}
          className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl bg-amber-600 text-sm font-bold text-white shadow-sm hover:bg-amber-700 disabled:opacity-40"
        >
          <Plus className="h-4 w-4" aria-hidden /> {t('loyalty:sumar')}
        </button>
      </div>
      {status.linked && status.hasCard && (
        <button
          type="button"
          onClick={() => setShowLink(true)}
          className="inline-flex w-full min-h-[40px] items-center justify-center gap-2 rounded-xl border border-amber-300 bg-white text-xs font-bold text-amber-900 hover:bg-amber-100"
        >
          <Link2 className="h-4 w-4" aria-hidden /> {t('loyalty:enlace_tarjeta')}
        </button>
      )}
      {showLink && <CardLinkDialog customer={customer} businessName={businessName} onClose={() => setShowLink(false)} />}
    </section>
  );
}
