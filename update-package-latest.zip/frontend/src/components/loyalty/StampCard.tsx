// ============================================
// COMPONENTS - Tarjeta de sellos en la caja
// ============================================
// Lo que ve el cajero cuando un cliente gana o pierde sellos: cuántos lleva, cuánto
// le falta y si ya llegó a su tarjeta digital (en vivo), si quedó en cola sin internet
// o si los recibirá al registrarse. También el enlace para recuperar su tarjeta.

import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import QRCode from 'qrcode';
import { Check, CloudOff, Loader2, Smartphone, UserPlus, X, MessageCircle, Copy } from 'lucide-react';
import { loyaltyAPI, StampEventStatus } from '../../services/api';
import { errorMessage } from '../../services/apiErrors';
import { toast } from '../../shared/toast';
import { t, getLocale } from '../../i18n';

/** Sigue un movimiento hasta que llega a la nube (o queda claro que espera internet) */
export function useStampEventStatus(eventId?: string | null) {
  const [status, setStatus] = useState<StampEventStatus | null>(eventId ? 'QUEUED' : null);
  const [settled, setSettled] = useState(false);
  useEffect(() => {
    if (!eventId) return;
    let stop = false;
    let timer: number | undefined;
    const started = Date.now();
    setStatus('QUEUED');
    setSettled(false);
    const tick = async () => {
      try {
        const e = await loyaltyAPI.event(eventId);
        if (stop) return;
        setStatus(e.status);
        if (e.status !== 'QUEUED') return setSettled(true);
      } catch {
        // el servidor local no respondió: se vuelve a intentar
      }
      // Los primeros segundos casi en vivo; después, si sigue en cola es que no hay internet
      const elapsed = Date.now() - started;
      if (elapsed > 6000) setSettled(true);
      if (!stop) timer = window.setTimeout(tick, elapsed < 15000 ? 1200 : 10000);
    };
    timer = window.setTimeout(tick, 600);
    return () => {
      stop = true;
      window.clearTimeout(timer);
    };
  }, [eventId]);
  return { status, settled };
}

/** Casillas de la tarjeta: las ganadas en color, las nuevas con un pequeño salto */
export function StampDots({ count, total, fresh = 0, size = 'md' }: { count: number; total: number; fresh?: number; size?: 'sm' | 'md' }) {
  const filled = Math.min(count, total);
  const box = size === 'sm' ? 'w-6 h-6 text-[10px]' : 'w-8 h-8 text-xs';
  return (
    <ol className="flex flex-wrap justify-center gap-1.5" aria-label={t('loyalty:lleva', { count: filled, total })}>
      {Array.from({ length: total }, (_, i) => {
        const on = i < filled;
        const isNew = on && i >= filled - fresh;
        return (
          <li
            key={i}
            className={`${box} rounded-full grid place-items-center font-black border-2 transition-colors ${
              on ? 'bg-amber-500 border-amber-600 text-white shadow-sm' : 'bg-white border-dashed border-amber-300 text-amber-300'
            } ${isNew ? 'motion-safe:animate-[stamp-pop_0.5s_cubic-bezier(0.34,1.56,0.64,1)_both]' : ''}`}
            style={isNew ? { animationDelay: `${(i - (filled - fresh)) * 120}ms` } : undefined}
          >
            {on ? <Check className="w-3.5 h-3.5" aria-hidden /> : i + 1}
          </li>
        );
      })}
    </ol>
  );
}

/** Una línea con el estado del envío a la tarjeta digital */
export function StampSyncLine({ status, settled, hasCard, linked = true }: { status: StampEventStatus | null; settled: boolean; hasCard: boolean; linked?: boolean }) {
  if (!status) return null;
  const view = !linked
    ? { icon: <Check className="w-4 h-4" aria-hidden />, text: t('loyalty:guardado_local'), tone: 'text-slate-700 bg-slate-50 border-slate-200' }
    : status === 'APPLIED'
      ? { icon: <Smartphone className="w-4 h-4" aria-hidden />, text: t('loyalty:en_su_tarjeta'), tone: 'text-emerald-700 bg-emerald-50 border-emerald-200' }
      : status === 'WAITING_SIGNUP'
        ? { icon: <UserPlus className="w-4 h-4" aria-hidden />, text: t('loyalty:espera_registro'), tone: 'text-sky-800 bg-sky-50 border-sky-200' }
        : settled
          ? { icon: <CloudOff className="w-4 h-4" aria-hidden />, text: t('loyalty:en_cola'), tone: 'text-amber-900 bg-amber-50 border-amber-200' }
          : { icon: <Loader2 className="w-4 h-4 animate-spin" aria-hidden />, text: t('loyalty:enviando'), tone: 'text-slate-700 bg-slate-50 border-slate-200' };
  return (
    <p role="status" aria-live="polite" className={`flex items-center justify-center gap-2 rounded-xl border px-3 py-2 text-xs font-semibold ${view.tone}`}>
      {view.icon}
      <span>{status === 'QUEUED' && !hasCard && settled ? t('loyalty:sin_tarjeta_digital') : view.text}</span>
    </p>
  );
}

/** Enlace de un solo uso para que el cliente abra su tarjeta en otro celular */
export function CardLinkDialog({ customer, businessName, onClose }: { customer: { id: string; name: string; phone?: string | null }; businessName: string; onClose: () => void }) {
  const [link, setLink] = useState<{ url: string; expiresAt: string; phone: string | null } | null>(null);
  const [qr, setQr] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    let alive = true;
    loyaltyAPI.cardLink(customer.id)
      .then(async (l) => {
        if (!alive) return;
        setLink(l);
        setQr(await QRCode.toDataURL(l.url, { width: 440, margin: 1, errorCorrectionLevel: 'M' }));
      })
      .catch((e) => alive && setError(errorMessage(e)));
    return () => {
      alive = false;
    };
  }, [customer.id]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  const phone = (link?.phone || customer.phone || '').replace(/\D/g, '');
  const waPhone = phone.length === 10 ? `57${phone}` : phone;
  const message = link ? t('loyalty:mensaje_whatsapp', { name: customer.name.split(' ')[0], business: businessName, url: link.url }) : '';
  const copy = async () => {
    if (!link) return;
    try {
      await navigator.clipboard.writeText(link.url);
      toast.success(t('loyalty:enlace_copiado'));
    } catch {
      toast.error(t('loyalty:no_se_pudo_copiar'));
    }
  };

  return createPortal(
    <div className="fixed inset-0 z-[80] flex items-center justify-center p-4 bg-black/50" onClick={onClose}>
      <div role="dialog" aria-modal="true" aria-labelledby="card-link-title" className="relative w-full max-w-sm rounded-2xl bg-surface border border-line shadow-xl p-6 text-center" onClick={(e) => e.stopPropagation()}>
        <button type="button" onClick={onClose} aria-label={t('loyalty:cerrar')} className="absolute top-3 right-3 p-2 rounded-lg text-fg-muted hover:text-fg hover:bg-surface-muted">
          <X className="w-4 h-4" />
        </button>
        <h2 id="card-link-title" className="text-lg font-bold text-fg">{t('loyalty:enlace_tarjeta')}</h2>
        <p className="mt-1 text-sm text-fg-secondary">{customer.name}</p>
        <p className="mt-2 text-xs text-fg-muted leading-relaxed">{t('loyalty:enlace_tarjeta_desc')}</p>
        {error ? (
          <p className="mt-5 rounded-xl border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900">{error}</p>
        ) : !qr ? (
          <div className="mx-auto mt-5 grid h-52 w-52 place-items-center rounded-2xl border border-line text-xs text-fg-muted">
            <Loader2 className="w-5 h-5 animate-spin" aria-label={t('loyalty:generando')} />
          </div>
        ) : (
          <>
            <img src={qr} alt="" className="mx-auto mt-5 h-52 w-52 rounded-2xl border border-line bg-white p-2" />
            <p className="mt-2 text-xs text-fg-muted">
              {t('loyalty:escanea_para_recuperar')} · {t('loyalty:vence', { time: new Date(link!.expiresAt).toLocaleTimeString(getLocale(), { hour: '2-digit', minute: '2-digit' }) })}
            </p>
            <div className="mt-4 grid grid-cols-2 gap-2">
              <button type="button" onClick={copy} className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl border border-line text-sm font-semibold text-fg hover:bg-surface-muted">
                <Copy className="w-4 h-4" aria-hidden /> {t('loyalty:copiar_enlace')}
              </button>
              <a
                href={`https://wa.me/${waPhone}?text=${encodeURIComponent(message)}`}
                target="_blank"
                rel="noreferrer"
                className={`inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl bg-emerald-600 text-sm font-semibold text-white hover:bg-emerald-700 ${waPhone ? '' : 'pointer-events-none opacity-50'}`}
              >
                <MessageCircle className="w-4 h-4" aria-hidden /> {t('loyalty:enviar_whatsapp')}
              </a>
            </div>
          </>
        )}
      </div>
    </div>,
    document.body,
  );
}
