// ============================================
// MOBILE - Activar la lectura de avisos de transferencia (Fase 4 · D · 3)
// ============================================
// Solo en la app Android, para ADMIN o CASHIER y con la función encendida. Explica qué
// lee Lantify y qué no, y abre la pantalla del sistema donde el dueño da el permiso.
// Android no deja que una app se dé ese permiso sola: lo da la persona en Ajustes.

import React, { useEffect, useState } from 'react';
import { ArrowLeft, BellRing, Check, ShieldCheck } from 'lucide-react';
import { t } from '../../i18n';
import { androidBridge } from '../../services/androidBridge';
import { useFeatureFlag } from '../../shared/features';

const readAccess = () => {
  try { return !!androidBridge()?.bankAccessEnabled?.(); } catch { return false; }
};

export const BankAccessScreen: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const [enabled, setEnabled] = useState(readAccess);

  // Al volver de Ajustes se relee el permiso
  useEffect(() => {
    const onVisible = () => { if (document.visibilityState === 'visible') setEnabled(readAccess()); };
    document.addEventListener('visibilitychange', onVisible);
    return () => document.removeEventListener('visibilitychange', onVisible);
  }, []);

  return (
    <div style={{ height: 'var(--app-h, 100dvh)' }} className="fixed inset-x-0 top-0 z-[60] bg-white flex flex-col pb-[env(safe-area-inset-bottom)]" role="dialog" aria-modal="true" aria-labelledby="bank-access-title">
      <div className="h-14 shrink-0 bg-slate-900 text-white flex items-center px-2 gap-2">
        <button type="button" onClick={onClose} aria-label={t('pos:cerrar')} className="w-12 h-12 flex items-center justify-center rounded-xl hover:bg-white/10"><ArrowLeft className="w-6 h-6" aria-hidden /></button>
        <h2 id="bank-access-title" className="text-lg font-bold font-heading">{t('v3:banco_titulo')}</h2>
      </div>
      <div className="flex-1 overflow-y-auto p-5 space-y-4 text-slate-700">
        <p className="text-base">{t('v3:banco_por_que')}</p>
        <ul className="space-y-2 text-sm">
          {(['banco_lee', 'banco_no_lee', 'banco_no_mueve'] as const).map((k) => (
            <li key={k} className="flex gap-2"><ShieldCheck className="w-4 h-4 mt-0.5 shrink-0 text-emerald-700" aria-hidden />{t(`v3:${k}`)}</li>
          ))}
        </ul>
        <div role="status" className={`rounded-2xl border p-4 text-sm font-bold flex items-center gap-2 ${enabled ? 'border-emerald-300 bg-emerald-50 text-emerald-900' : 'border-amber-300 bg-amber-50 text-amber-900'}`}>
          {enabled ? <Check className="w-5 h-5" aria-hidden /> : <BellRing className="w-5 h-5" aria-hidden />}
          {enabled ? t('v3:banco_activo') : t('v3:banco_inactivo')}
        </div>
        <button
          type="button"
          onClick={() => { try { androidBridge()?.openBankAccess?.(); } catch { /* el sistema no abrió Ajustes */ } }}
          className="w-full min-h-[52px] rounded-2xl bg-slate-900 text-white font-bold"
        >
          {enabled ? t('v3:banco_revisar') : t('v3:banco_abrir_ajustes')}
        </button>
        <p className="text-xs text-slate-500">{t('v3:banco_pasos')}</p>
      </div>
    </div>
  );
};

/** Fila de "Más opciones" que abre la pantalla (nada fuera de la app Android) */
export const BankAccessRow: React.FC<{ role?: string; onOpen: () => void }> = ({ role, onOpen }) => {
  const on = useFeatureFlag('bank_notifications');
  if (!on || !androidBridge()?.openBankAccess || (role !== 'ADMIN' && role !== 'CASHIER')) return null;
  return (
    <button type="button" onClick={onOpen} className="w-full min-h-[52px] px-4 rounded-xl bg-slate-100 text-slate-900 font-bold text-left flex items-center gap-2">
      <BellRing className="w-5 h-5" aria-hidden />{t('v3:banco_titulo')}
    </button>
  );
};
