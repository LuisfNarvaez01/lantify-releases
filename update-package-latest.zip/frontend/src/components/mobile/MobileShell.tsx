// ============================================
// MOBILE - Vista del POS en el celular (Lantify 3.0)
// ============================================
// Una disposición propia para pantallas angostas: tres destinos fijos abajo
// (Mesas, Pedidos, Avisos), botones grandes y el envío a cocina siempre a la mano.
// Reutiliza el mismo estado y las mismas reglas que la caja: lo que cada quien
// puede hacer lo siguen definiendo sus permisos.

import React, { useEffect, useMemo, useState } from 'react';
import { isProductPaused } from '../../shared/productState';
import { NotificationBell } from '../common/NotificationBell';
import { ArrowLeft, Bell, ChefHat, ClipboardList, LayoutGrid, LogOut, Menu, Plus, ReceiptText, Search, Settings, Radar, ShoppingBag, X } from 'lucide-react';
import { usePosStore } from '../../store/usePosStore';
import type { Product, Table } from '../../types';
import { t } from '../../i18n';
import { toast } from '../../shared/toast';
import { formatCurrency } from '../../shared/formatUtils';
import { useBusiness } from '../../shared/business';
import { tabAllowed, usePermissions } from '../../shared/permissions';
import { currentUserId, useFeatureFlag, useFloor } from '../../shared/features';
import { floorAPI } from '../../services/v3Api';
import { Cart } from '../pos/Cart';
import { VariantModal } from '../pos/VariantModal';
import { alertText, formatTableElapsed, useTableLook, useTableSelection, useTableSummaries } from '../pos/tableSelection';
import { useSendToKitchen } from '../pos/cart/useSendToKitchen';
import { ShiftButton } from './ShiftButton';
import { SuggestionsBar } from '../v3/SuggestionsBar';
import { AutopilotButton } from '../v3/AutopilotPanel';

type Screen = 'tables' | 'orders' | 'alerts';

interface MobileShellProps {
  user?: any;
  onLogout?: () => void;
  /** Ir a otra parte del POS (caja, ventas, reservas…) con la vista completa */
  onGoTab: (tab: string) => void;
  onOpenAdmin?: () => void;
}

const OTHER_TABS = ['cash', 'sales', 'reservations', 'delivery', 'analytics'] as const;

const chip = (active: boolean) =>
  `px-3.5 min-h-[40px] rounded-full text-sm font-semibold whitespace-nowrap border transition-colors ${
    active ? 'bg-slate-900 text-white border-slate-900' : 'bg-white text-slate-700 border-slate-200'
  }`;

export const MobileShell: React.FC<MobileShellProps> = ({ user, onLogout, onGoTab, onOpenAdmin }) => {
  const { tables, selectedTable, products, categories, addToCart, openVariantModal, clearCart, getCurrentCart, fetchTables } = usePosStore();
  const { usesTables } = useBusiness();
  const rolePerms = usePermissions((s) => s.perms);
  const { floor, refresh } = useFloor();
  const select = useTableSelection();
  const summaryOf = useTableSummaries();
  const lookOf = useTableLook();
  const { send, sending } = useSendToKitchen();
  const dirtyOn = useFeatureFlag('dirty_tables');

  const me = currentUserId();
  const role = String(user?.role || 'WAITER').toUpperCase();
  const [screen, setScreen] = useState<Screen>(usesTables ? 'tables' : 'orders');
  const [ordering, setOrdering] = useState(!usesTables);
  const [showCart, setShowCart] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [tableFilter, setTableFilter] = useState<string>('mine');
  const [category, setCategory] = useState<string>('all');
  const [query, setQuery] = useState('');
  const [onlyMine, setOnlyMine] = useState(role === 'WAITER');


  const myTableIds = useMemo(() => new Set(floor.tables.filter((x) => x.waiterId === me).map((x) => x.tableId)), [floor.tables, me]);
  const zones = useMemo(() => [...new Set(tables.map((x) => x.zone).filter((z): z is string => !!z))], [tables]);

  const visibleTables = useMemo(() => {
    if (tableFilter === 'all') return tables;
    if (tableFilter === 'mine') {
      const mine = tables.filter((x) => myTableIds.has(x.id));
      return mine.length ? mine : tables; // sin mesas propias, mejor ver todas que una pantalla vacía
    }
    return tables.filter((x) => x.zone === tableFilter);
  }, [tables, tableFilter, myTableIds]);
  const mineIsEmpty = tableFilter === 'mine' && myTableIds.size === 0;

  const cart = getCurrentCart();
  const newItems = cart.filter((i) => !i.isOrdered);
  const newCount = newItems.reduce((n, i) => n + i.quantity, 0);
  const newTotal = newItems.reduce((n, i) => n + i.quantity * i.unitPrice, 0);
  const cartTotal = cart.reduce((n, i) => n + i.quantity * i.unitPrice, 0);
  const tableInfo = selectedTable ? floor.tables.find((x) => x.tableId === selectedTable.id) : undefined;

  const openTable = async (table: Table) => {
    const opened = await select(table);
    if (!opened || table.status === 'DIRTY') return;
    setOrdering(true);
    setCategory('all');
    setQuery('');
  };

  const backToTables = () => {
    if (!usesTables) return;
    setOrdering(false);
    setShowCart(false);
    clearCart();
    usePosStore.getState().selectTable(null);
    refresh();
  };

  const pick = (product: Product) => {
    if (isProductPaused(product)) { addToCart(product, product.variants[0]); return; } // avisa que está pausado
    if (product.variants && product.variants.length > 1) openVariantModal(product);
    else if (product.variants && product.variants.length === 1) addToCart(product, product.variants[0]);
  };

  const requestBill = async () => {
    if (!selectedTable) return;
    try {
      if (tableInfo?.billRequestedAt) await floorAPI.undoBill(selectedTable.id);
      else await floorAPI.requestBill(selectedTable.id);
      await Promise.all([refresh(), fetchTables()]);
      toast.success(tableInfo?.billRequestedAt ? t('v3:cuenta_deshecha') : t('v3:cuenta_pedida_ok', { number: selectedTable.number }));
    } catch (err: any) {
      toast.error(err?.message || t('v3:no_se_guardo'));
    }
  };

  const activeProducts = useMemo(() => {
    const q = query.trim().toLowerCase();
    return products
      .filter((p) => p.isActive !== false && (p.variants || []).length > 0)
      .filter((p) => category === 'all' || p.categoryId === category)
      .filter((p) => !q || p.name.toLowerCase().includes(q));
  }, [products, category, query]);

  const qtyInCart = (productId: string) => newItems.filter((i) => i.productId === productId).reduce((n, i) => n + i.quantity, 0);

  const alerts = useMemo(
    () => (role === 'WAITER' ? floor.alerts.filter((a) => !a.waiterId || a.waiterId === me) : floor.alerts),
    [floor.alerts, role, me],
  );
  const dirtyTables = tables.filter((x) => x.status === 'DIRTY');
  const orders = useMemo(
    () => floor.tables.filter((x) => !onlyMine || x.waiterId === me).map((x) => ({ ...x, table: tables.find((tb) => tb.id === x.tableId) })).filter((x) => x.table),
    [floor.tables, onlyMine, me, tables],
  );
  const pickups = useMemo(
    () => (floor.pickups || []).filter((p) => role !== 'WAITER' || !p.waiterId || p.waiterId === me),
    [floor.pickups, role, me],
  );
  const served = async (tableId: string) => {
    try {
      await floorAPI.served(tableId);
      await refresh();
    } catch (err: any) {
      toast.error(err?.message || t('v3:no_se_guardo'));
    }
  };
  const notices = floor.notices || [];
  const badge = alerts.length + pickups.length + notices.length + (dirtyOn ? dirtyTables.length : 0);

  const title = ordering
    ? selectedTable ? t('pos:mesa_number', { number: selectedTable.number }) : t('pos:mostrador')
    : screen === 'tables' ? t('pos:mesas') : screen === 'orders' ? t('v3:mis_pedidos') : t('v3:avisos');

  const nav: { id: Screen; label: string; icon: React.ElementType }[] = [
    ...(usesTables ? [{ id: 'tables' as Screen, label: t('pos:mesas'), icon: LayoutGrid }] : []),
    { id: 'orders', label: usesTables ? t('layout:pedidos') : t('v3:pedir'), icon: usesTables ? ClipboardList : ShoppingBag },
    { id: 'alerts', label: t('v3:avisos'), icon: Bell },
  ];

  const goNav = (id: Screen) => {
    if (usesTables && ordering) backToTables();
    if (!usesTables) setOrdering(id === 'orders');
    setScreen(id);
  };

  return (
    <div className="flex-1 min-h-0 flex flex-col bg-slate-100 text-[16px]">
      {/* Barra superior */}
      <header className="shrink-0 bg-slate-900 text-white flex items-center gap-1 px-1.5 min-h-[3.5rem] pt-[env(safe-area-inset-top)]">
        {ordering && usesTables ? (
          <button type="button" onClick={backToTables} aria-label={t('v3:volver_a_mesas')} className="w-12 h-12 flex items-center justify-center rounded-xl hover:bg-white/10">
            <ArrowLeft className="w-6 h-6" aria-hidden />
          </button>
        ) : (
          <img src="/logo-lantify-white.svg" alt="Lantify" className="h-8 w-auto ml-1.5 mr-1 object-contain" />
        )}
        <div className="flex-1 min-w-0">
          <h1 className="text-lg font-bold font-heading truncate">{title}</h1>
          {ordering && tableInfo?.waiterName && <p className="text-xs text-slate-300 truncate -mt-0.5">{t('v3:atiende', { name: tableInfo.waiterName })}</p>}
        </div>
        <span className="text-xs text-slate-400 truncate max-w-[30%]">{user?.name || user?.username}</span>
        <AutopilotButton role={role} />
        <NotificationBell dark />
        <button type="button" onClick={() => setShowMenu(true)} aria-label={t('v3:mas_opciones')} className="w-12 h-12 flex items-center justify-center rounded-xl hover:bg-white/10">
          <Menu className="w-6 h-6" aria-hidden />
        </button>
      </header>

      <main className="flex-1 min-h-0 overflow-y-auto overscroll-contain">
        {/* ── Tomar el pedido ── */}
        {ordering && (
          <div className="p-3 space-y-2.5">
            <SuggestionsBar variant="phone" />
            <label className="relative block">
              <span className="sr-only">{t('pos:buscar_producto_codigo_de_barras_o_sku')}</span>
              <Search className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" aria-hidden />
              <input type="search" value={query} onChange={(e) => setQuery(e.target.value)} placeholder={t('v3:buscar_producto')} className="w-full min-h-[44px] pl-10 pr-3 rounded-xl border border-slate-300 bg-white text-base text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/40" />
            </label>
            <div className="flex gap-2 overflow-x-auto -mx-3 px-3 pb-1" role="tablist" aria-label={t('v3:categorias')}>
              <button type="button" role="tab" aria-selected={category === 'all'} className={chip(category === 'all')} onClick={() => setCategory('all')}>{t('pos:todas')}</button>
              {categories.filter((c) => c.isActive !== false).map((c) => (
                <button key={c.id} type="button" role="tab" aria-selected={category === c.id} className={chip(category === c.id)} onClick={() => setCategory(c.id)}>{c.name}</button>
              ))}
            </div>
            <ul className="bg-white rounded-2xl border border-slate-200 divide-y divide-slate-100 overflow-hidden">
              {activeProducts.map((p) => {
                const prices = p.variants.map((v) => v.price);
                const from = Math.min(...prices);
                const qty = qtyInCart(p.id);
                const paused = isProductPaused(p);
                return (
                  <li key={p.id}>
                    <button type="button" onClick={() => pick(p)} aria-disabled={paused} className={`w-full flex items-center gap-3 px-3 py-2.5 text-left active:bg-blue-50 ${paused ? 'opacity-60' : ''}`}>
                      <span className="flex-1 min-w-0">
                        <span className="block text-[0.9375rem] font-semibold text-slate-900 leading-snug">{p.name}{paused && <span className="ml-2 align-middle text-[0.6875rem] font-black uppercase px-1.5 py-0.5 rounded bg-slate-700 text-white">{t('pos:pausado')}</span>}</span>
                        <span className="block text-sm text-slate-500 tabular-nums">
                          {p.variants.length > 1 ? t('v3:desde', { precio: formatCurrency(from) }) : formatCurrency(from)}
                        </span>
                      </span>
                      {qty > 0 && <span className="min-w-[2rem] h-8 px-2 rounded-full bg-blue-100 text-blue-900 text-sm font-black flex items-center justify-center tabular-nums" aria-label={t('v3:en_el_pedido', { count: qty })}>{qty}</span>}
                      <span className="w-10 h-10 rounded-full bg-blue-700 text-white flex items-center justify-center shrink-0" aria-hidden><Plus className="w-5 h-5" /></span>
                    </button>
                  </li>
                );
              })}
              {activeProducts.length === 0 && <li className="text-center text-slate-500 py-10 bg-slate-100">{t('v3:sin_productos')}</li>}
            </ul>
          </div>
        )}

        {/* ── Mesas ── */}
        {!ordering && screen === 'tables' && (
          <div className="p-3 space-y-3">
            <div className="flex gap-2 overflow-x-auto -mx-3 px-3 pb-1">
              <button type="button" className={chip(tableFilter === 'mine')} aria-pressed={tableFilter === 'mine'} onClick={() => setTableFilter('mine')}>{t('v3:mis_mesas')}</button>
              <button type="button" className={chip(tableFilter === 'all')} aria-pressed={tableFilter === 'all'} onClick={() => setTableFilter('all')}>{t('pos:todas')}</button>
              {zones.map((z) => (
                <button key={z} type="button" className={chip(tableFilter === z)} aria-pressed={tableFilter === z} onClick={() => setTableFilter(z)}>{z}</button>
              ))}
            </div>
            {mineIsEmpty && <p className="text-sm text-slate-600">{t('v3:sin_mesas_propias')}</p>}
            <div className="grid grid-cols-3 gap-2.5">
              {visibleTables.map((table) => {
                const look = lookOf(table);
                const total = summaryOf(table.id).total || floor.tables.find((x) => x.tableId === table.id)?.total || 0;
                const line = look.alert ? look.label
                  : table.status === 'DIRTY' ? t('v3:toca_para_limpiar')
                    : table.status === 'AVAILABLE' ? look.label
                      : table.status === 'PENDING' ? look.label
                        : total > 0 ? formatCurrency(total) : look.label;
                return (
                  <button
                    key={table.id}
                    type="button"
                    onClick={() => openTable(table)}
                    className={`min-h-[84px] rounded-2xl border-2 p-2 flex flex-col items-center justify-center text-center ${look.card}`}
                  >
                    <span className="text-2xl font-black font-heading text-slate-900 leading-none">{table.number}</span>
                    <span className="mt-1.5 text-[0.8125rem] font-bold leading-tight text-slate-800">{line}</span>
                    {look.waiterName && table.status !== 'AVAILABLE' && table.status !== 'DIRTY' && (
                      <span className="mt-0.5 max-w-full truncate text-[0.6875rem] font-semibold text-slate-600">{look.waiterName.split(' ')[0]}</span>
                    )}
                  </button>
                );
              })}
            </div>
            {tables.length === 0 && <p className="text-center text-slate-500 py-10">{t('v3:sin_mesas')}</p>}
          </div>
        )}

        {/* ── Pedidos abiertos ── */}
        {!ordering && screen === 'orders' && (
          <div className="p-3 space-y-3">
            <div className="flex gap-2">
              <button type="button" className={chip(onlyMine)} aria-pressed={onlyMine} onClick={() => setOnlyMine(true)}>{t('v3:los_mios')}</button>
              <button type="button" className={chip(!onlyMine)} aria-pressed={!onlyMine} onClick={() => setOnlyMine(false)}>{t('v3:todos')}</button>
            </div>
            <ul className="space-y-2">
              {orders.map((o) => (
                <li key={o.orderId}>
                  <button type="button" onClick={() => openTable(o.table as Table)} className="w-full bg-white border border-slate-200 rounded-2xl p-3 flex items-center gap-3 text-left active:bg-blue-50">
                    <span className="w-14 h-14 rounded-xl bg-slate-100 flex items-center justify-center text-xl font-black font-heading text-slate-900 shrink-0">{(o.table as Table).number}</span>
                    <span className="flex-1 min-w-0">
                      <span className="block text-base font-bold text-slate-900 tabular-nums">{formatCurrency(o.total)}</span>
                      <span className="block text-sm text-slate-600 truncate">
                        {o.billRequestedAt ? t('v3:cuenta_pedida_hace', { tiempo: formatTableElapsed(o.billRequestedAt) })
                          : o.lastRoundAt ? t('v3:ultima_ronda_hace', { tiempo: formatTableElapsed(o.lastRoundAt) }) : t('v3:sin_enviar')}
                        {!onlyMine && o.waiterName ? ` · ${o.waiterName}` : ''}
                      </span>
                    </span>
                  </button>
                </li>
              ))}
            </ul>
            {orders.length === 0 && <p className="text-center text-slate-500 py-10">{t('v3:sin_pedidos')}</p>}
          </div>
        )}

        {/* ── Avisos ── */}
        {!ordering && screen === 'alerts' && (
          <div className="p-3 space-y-2">
            {notices.map((n) => (
              <div key={`notice-${n.id}`} className="w-full bg-blue-50 rounded-2xl p-3 flex items-center gap-3 border-2 border-blue-400" role="status">
                <span className="w-14 h-14 rounded-xl bg-blue-700 text-white flex items-center justify-center shrink-0"><Radar className="w-6 h-6" aria-hidden /></span>
                <span className="flex-1 min-w-0">
                  <span className="block text-xs font-bold uppercase tracking-wide text-blue-800">Autopilot</span>
                  <span className="block text-base font-bold text-slate-900">{t(`v3:ap_n_${n.message}`, n)}</span>
                </span>
              </div>
            ))}
            {pickups.map((p) => (
              <div key={`pick-${p.tableId}`} className="w-full bg-emerald-50 rounded-2xl p-3 flex items-center gap-3 border-2 border-emerald-500">
                <span className="w-14 h-14 rounded-xl bg-emerald-600 text-white flex items-center justify-center text-xl font-black font-heading shrink-0">{p.tableNumber}</span>
                <span className="flex-1 min-w-0">
                  <span className="block text-base font-bold text-slate-900">{t('v3:recoger_en_cocina')}</span>
                  <span className="block text-sm text-slate-600 truncate">{t('v3:platos_listos', { count: p.count })}{p.waiterName && role !== 'WAITER' ? ` · ${p.waiterName}` : ''}</span>
                </span>
                <button type="button" onClick={() => served(p.tableId)} className="min-h-[48px] px-4 rounded-xl bg-emerald-600 text-white font-bold shrink-0">{t('v3:entregado')}</button>
              </div>
            ))}
            {alerts.map((a) => {
              const table = tables.find((x) => x.id === a.tableId);
              return (
                <button key={`${a.tableId}-${a.kind}`} type="button" disabled={!table} onClick={() => table && openTable(table)} className={`w-full bg-white rounded-2xl p-3 flex items-center gap-3 text-left border-2 ${a.kind === 'bill' ? 'border-rose-400' : 'border-amber-400'}`}>
                  <span className="w-14 h-14 rounded-xl bg-slate-100 flex items-center justify-center text-xl font-black font-heading text-slate-900 shrink-0">{a.tableNumber}</span>
                  <span className="flex-1 min-w-0">
                    <span className="block text-base font-bold text-slate-900">{alertText(a)}</span>
                    <span className="block text-sm text-slate-600 truncate">{t(`v3:alerta_ayuda_${a.kind}`)}{a.waiterName && role !== 'WAITER' ? ` · ${a.waiterName}` : ''}</span>
                  </span>
                </button>
              );
            })}
            {dirtyOn && dirtyTables.map((table) => (
              <button key={table.id} type="button" onClick={() => openTable(table)} className="w-full bg-white rounded-2xl p-3 flex items-center gap-3 text-left border-2 border-dashed border-slate-400">
                <span className="w-14 h-14 rounded-xl bg-slate-100 flex items-center justify-center text-xl font-black font-heading text-slate-900 shrink-0">{table.number}</span>
                <span className="flex-1 min-w-0">
                  <span className="block text-base font-bold text-slate-900">{t('v3:por_limpiar')}</span>
                  <span className="block text-sm text-slate-600">{t('v3:toca_para_limpiar')}</span>
                </span>
              </button>
            ))}
            {badge === 0 && <p className="text-center text-slate-500 py-10">{t('v3:sin_avisos')}</p>}
          </div>
        )}
      </main>

      {/* Barra de acción del pedido: siempre visible sobre la navegación */}
      {ordering && (
        <div className="shrink-0 px-3 py-2 bg-white border-t border-slate-200 shadow-[0_-4px_12px_rgba(15,23,42,0.06)] flex gap-2">
          <button type="button" onClick={() => setShowCart(true)} disabled={cart.length === 0} className="min-h-[52px] px-3.5 rounded-xl bg-slate-100 text-slate-900 font-bold flex items-center gap-2 disabled:opacity-50">
            <ReceiptText className="w-5 h-5" aria-hidden />
            <span className="tabular-nums">{cart.length > 0 ? formatCurrency(cartTotal) : t('v3:pedido')}</span>
          </button>
          {newCount > 0 ? (
            <button type="button" onClick={() => send()} disabled={sending} className="flex-1 min-w-0 min-h-[52px] rounded-xl bg-blue-700 text-white font-bold flex items-center justify-center gap-2 px-3 disabled:opacity-70">
              <ChefHat className="w-5 h-5 shrink-0" aria-hidden />
              <span className="truncate">{sending ? t('pos:enviando') : t('v3:enviar_a_cocina', { count: newCount })}</span>
              <span className="tabular-nums shrink-0">{formatCurrency(newTotal)}</span>
            </button>
          ) : selectedTable && cart.length > 0 ? (
            <button type="button" onClick={requestBill} className={`flex-1 min-w-0 min-h-[52px] rounded-xl font-bold px-3 border-2 ${tableInfo?.billRequestedAt ? 'bg-violet-50 border-violet-400 text-violet-900' : 'bg-white border-blue-700 text-blue-800'}`}>
              {tableInfo?.billRequestedAt ? t('v3:cuenta_pedida_deshacer') : t('v3:pedir_cuenta')}
            </button>
          ) : (
            <p className="flex-1 flex items-center justify-center text-sm text-slate-600 text-center px-2">{t('v3:agrega_productos')}</p>
          )}
        </div>
      )}

      {/* Navegación fija: siempre los mismos tres lugares */}
      <nav className="shrink-0 bg-white border-t border-slate-200 flex min-h-[3.75rem] pb-[env(safe-area-inset-bottom)]" aria-label={t('v3:navegacion')}>
        {nav.map((item) => {
          const Icon = item.icon;
          const active = !ordering || !usesTables ? screen === item.id : item.id === 'tables';
          return (
            <button key={item.id} type="button" onClick={() => goNav(item.id)} aria-current={active ? 'page' : undefined} className={`flex-1 min-h-[3.75rem] flex flex-col items-center justify-center gap-0.5 text-xs font-bold relative ${active ? 'text-blue-700' : 'text-slate-600'}`}>
              <Icon className="w-6 h-6" aria-hidden />
              {item.label}
              {item.id === 'alerts' && badge > 0 && (
                <span className="absolute top-1.5 left-1/2 ml-2 min-w-[1.25rem] h-5 px-1 rounded-full bg-rose-600 text-white text-[0.6875rem] font-black flex items-center justify-center" aria-label={t('v3:avisos_pendientes', { count: badge })}>{badge}</span>
              )}
            </button>
          );
        })}
      </nav>

      {/* El pedido completo: el mismo carrito de la caja (notas, cantidades, cobro según permisos) */}
      {showCart && (
        <div style={{ height: 'var(--app-h, 100dvh)' }} className="fixed inset-x-0 top-0 h-screen z-40 bg-white flex flex-col pb-[env(safe-area-inset-bottom)]" role="dialog" aria-modal="true" aria-label={t('v3:pedido')}>
          <div className="h-14 shrink-0 bg-slate-900 text-white flex items-center px-2 gap-2">
            <button type="button" onClick={() => setShowCart(false)} aria-label={t('pos:cerrar')} className="w-12 h-12 flex items-center justify-center rounded-xl hover:bg-white/10"><ArrowLeft className="w-6 h-6" aria-hidden /></button>
            <h2 className="text-lg font-bold font-heading">{t('v3:pedido')} · {title}</h2>
          </div>
          <div className="flex-1 min-h-0 flex flex-col overflow-hidden">
            <Cart onOrderComplete={() => { setShowCart(false); if (usesTables) { setOrdering(false); setScreen('tables'); } refresh(); }} />
          </div>
        </div>
      )}

      {/* Más opciones */}
      {showMenu && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-end" role="presentation" onClick={(e) => { if (e.target === e.currentTarget) setShowMenu(false); }}>
          <div role="dialog" aria-modal="true" aria-label={t('v3:mas_opciones')} className="w-full bg-white rounded-t-3xl p-4 space-y-2 max-h-[85dvh] overflow-y-auto">
            <div className="flex items-center justify-between pb-1">
              <h2 className="text-lg font-bold font-heading text-slate-900">{t('v3:mas_opciones')}</h2>
              <button type="button" onClick={() => setShowMenu(false)} aria-label={t('pos:cerrar')} className="w-11 h-11 flex items-center justify-center rounded-xl hover:bg-slate-100 text-slate-600"><X className="w-5 h-5" aria-hidden /></button>
            </div>
            <ShiftButton variant="row" />
            {OTHER_TABS.filter((tab) => tabAllowed(rolePerms, role, tab)).map((tab) => (
              <button key={tab} type="button" onClick={() => { setShowMenu(false); onGoTab(tab); }} className="w-full min-h-[52px] px-4 rounded-xl bg-slate-100 text-slate-900 font-bold text-left">
                {t(`v3:ir_${tab}`)}
              </button>
            ))}
            {role === 'ADMIN' && onOpenAdmin && (
              <button type="button" onClick={() => { setShowMenu(false); onOpenAdmin(); }} className="w-full min-h-[52px] px-4 rounded-xl bg-slate-100 text-slate-900 font-bold text-left flex items-center gap-2">
                <Settings className="w-5 h-5" aria-hidden />{t('v3:configuracion')}
              </button>
            )}
            {onLogout && (
              <button type="button" onClick={onLogout} className="w-full min-h-[52px] px-4 rounded-xl bg-rose-50 text-rose-800 font-bold text-left flex items-center gap-2">
                <LogOut className="w-5 h-5" aria-hidden />{t('v3:cerrar_sesion')}
              </button>
            )}
          </div>
        </div>
      )}

      <VariantModal />
    </div>
  );
};

/** ¿La pantalla es de celular? (menos de 768 px) */
export function useIsPhone() {
  const query = '(max-width: 767px)';
  const [phone, setPhone] = useState(() => typeof window !== 'undefined' && window.matchMedia(query).matches);
  useEffect(() => {
    const mq = window.matchMedia(query);
    const onChange = () => setPhone(mq.matches);
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, []);
  return phone;
}
