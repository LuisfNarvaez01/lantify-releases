// ============================================
// COMPONENTS - Entrada de la app del celular (vincular con la caja)
// ============================================
// La app del celular necesita saber a qué caja pertenece. La primera vez se escanea
// el QR que muestra la caja (Administración → Celulares por internet). Después entra
// directo, por la red local o por internet. Nunca hay que borrar los datos de la app:
// "Cambiar de local" vuelve aquí. En la caja y en el navegador esto no aparece.

import React, { useEffect, useState } from 'react';
import { QrCode, Wifi, Globe, WifiOff, Link2 } from 'lucide-react';
import { useTransport, pairWith } from '../../services/transport';
import { t } from '../../i18n';
// Tipos del puente de la app Android (window.LantifyAndroid, window.__lantifyPair)
import '../../services/androidBridge';

const PairDevice: React.FC = () => {
  const [link, setLink] = useState('');
  const [error, setError] = useState<string | null>(null);
  const android = typeof window !== 'undefined' && !!window.LantifyAndroid;

  useEffect(() => {
    // El escáner nativo devuelve aquí lo que leyó
    window.__lantifyPair = (value: string) => {
      if (!pairWith(value)) setError(t('layout:pair_qr_invalido'));
    };
    return () => { delete window.__lantifyPair; };
  }, []);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pairWith(link.trim())) setError(t('layout:pair_qr_invalido'));
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col justify-center px-6 py-10">
      <img src="/logo-lantify-white.svg" alt="Lantify" className="h-9 w-auto self-start" />
      <h1 className="mt-8 text-[1.75rem] font-semibold tracking-tight">{t('layout:pair_titulo')}</h1>
      <p className="mt-2 text-slate-300 text-[0.95rem] leading-relaxed">{t('layout:pair_desc')}</p>

      {android ? (
        <button
          type="button"
          onClick={() => { setError(null); window.LantifyAndroid!.scanQr(); }}
          className="mt-8 h-14 rounded-2xl bg-blue-600 hover:bg-blue-500 font-semibold inline-flex items-center justify-center gap-2 active:scale-[0.98] transition"
        >
          <QrCode className="w-5 h-5" />
          {t('layout:pair_escanear')}
        </button>
      ) : (
        <p className="mt-8 rounded-2xl bg-white/5 border border-white/10 p-4 text-sm text-slate-200">{t('layout:pair_iphone')}</p>
      )}

      <form onSubmit={submit} className="mt-6">
        <label className="text-xs text-slate-400 inline-flex items-center gap-1.5"><Link2 className="w-3.5 h-3.5" />{t('layout:pair_pegar')}</label>
        <div className="mt-2 flex gap-2">
          <input
            value={link}
            onChange={(e) => setLink(e.target.value)}
            placeholder="https://…#pair=…"
            className="flex-1 h-11 rounded-xl bg-white/5 border border-white/10 px-3 text-sm placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
          />
          <button type="submit" className="h-11 px-4 rounded-xl bg-white/10 hover:bg-white/15 text-sm font-medium">{t('layout:pair_usar')}</button>
        </div>
      </form>
      {error && <p className="mt-4 text-sm text-amber-300">{error}</p>}
      <p className="mt-10 text-xs text-slate-500">{t('layout:pair_ayuda')}</p>
    </div>
  );
};

/** Aviso fino arriba cuando el celular no está en la red local de la caja */
const ConnectionStrip: React.FC = () => {
  const mode = useTransport((s) => s.mode);
  const hostOnline = useTransport((s) => s.hostOnline);
  if (mode === 'lan' || mode === 'unknown') return null;
  const offline = mode === 'offline';
  const label = offline ? t('layout:conn_sin_conexion') : hostOnline === false ? t('layout:conn_caja_apagada') : t('layout:conn_internet');
  return (
    <div
      role="status"
      className={`fixed inset-x-0 top-0 z-[70] h-5 flex items-center justify-center gap-1.5 text-[11px] font-medium pointer-events-none ${
        offline || hostOnline === false ? 'bg-amber-500 text-amber-950' : 'bg-slate-900 text-slate-100'
      }`}
    >
      {offline ? <WifiOff className="w-3 h-3" /> : hostOnline === false ? <Wifi className="w-3 h-3" /> : <Globe className="w-3 h-3" />}
      {label}
    </div>
  );
};

export const ClientGate: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const clientApp = useTransport((s) => s.clientApp);
  const paired = useTransport((s) => s.paired);
  if (!clientApp) return <>{children}</>;
  if (!paired) return <PairDevice />;
  return (
    <>
      <ConnectionStrip />
      {children}
    </>
  );
};
