// ============================================
// COMPONENTS - Entrada de la app del celular (vincular con la caja)
// ============================================
// La app del celular necesita saber a qué caja pertenece. La primera vez se escanea
// el QR que muestra la caja (Administración → Celulares por internet). Después entra
// directo: por internet y, si no hay, por la red local. Nunca hay que borrar los datos de la app:
// "Cambiar de local" vuelve aquí. En la caja y en el navegador esto no aparece.

import React, { useEffect, useState } from 'react';
import { QrCode, Wifi, Globe, WifiOff, Link2, Store, X, ChevronRight } from 'lucide-react';
import { useTransport, pairWith, switchToPairing, forgetPairing } from '../../services/transport';
import { t } from '../../i18n';
// Tipos del puente de la app Android (window.LantifyAndroid, window.__lantifyPair)
import '../../services/androidBridge';

const PairDevice: React.FC = () => {
  const [link, setLink] = useState('');
  const [error, setError] = useState<string | null>(null);
  const android = typeof window !== 'undefined' && !!window.LantifyAndroid;
  const saved = useTransport((st) => st.saved);

  useEffect(() => {
    // El escáner nativo devuelve aquí lo que leyó
    window.__lantifyPair = (value: string) => {
      if (!pairWith(value)) setError(t('layout:pair_qr_invalido'));
    };
    return () => { delete window.__lantifyPair; };
  }, []);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pairWith(link.trim())) setError(t('layout:pair_qr_invalido'));
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col justify-center px-6 py-10 overflow-y-auto">
      <img src="/logo-lantify-white.svg" alt="Lantify" className="h-9 w-auto self-start" />
      {saved.length > 0 && (
        <section className="mt-8" aria-labelledby="saved-title">
          <h2 id="saved-title" className="text-[1.35rem] font-semibold tracking-tight">{t('layout:pair_guardados')}</h2>
          <ul className="mt-3 space-y-2">
            {saved.map((x) => (
              <li key={x.key} className="flex items-center gap-2">
                <button type="button" onClick={() => switchToPairing(x.key)} className="flex-1 min-h-[60px] rounded-2xl bg-white/10 hover:bg-white/15 px-4 flex items-center gap-3 text-left active:scale-[0.99] transition">
                  <Store className="w-5 h-5 shrink-0 text-blue-300" aria-hidden />
                  <span className="flex-1 min-w-0">
                    <span className="block font-semibold truncate">{x.name || t('layout:pair_sin_nombre')}</span>
                    <span className="block text-xs text-slate-400">{x.pairing.t ? t('layout:pair_por_internet') : t('layout:pair_solo_wifi')}</span>
                  </span>
                  <ChevronRight className="w-5 h-5 text-slate-400" aria-hidden />
                </button>
                <button type="button" aria-label={t('layout:pair_olvidar', { name: x.name || '' })} onClick={() => forgetPairing(x.key)} className="w-12 h-12 grid place-items-center rounded-xl text-slate-400 hover:bg-white/10 hover:text-white">
                  <X className="w-5 h-5" aria-hidden />
                </button>
              </li>
            ))}
          </ul>
        </section>
      )}
      <h1 className="mt-8 text-[1.75rem] font-semibold tracking-tight">{saved.length ? t('layout:pair_otro') : t('layout:pair_titulo')}</h1>
      <p className="mt-2 text-slate-300 text-[0.95rem] leading-relaxed">{t('layout:pair_desc')}</p>

      {android ? (
        <button
          type="button"
          onClick={() => { setError(null); window.LantifyAndroid!.scanQr(); }}
          className="mt-8 h-14 rounded-2xl bg-blue-600 hover:bg-blue-500 font-semibold inline-flex items-center justify-center gap-2 active:scale-[0.98] transition"
        >
          <QrCode className="w-5 h-5" />
          {t('layout:pair_escanear')}
        </button>
      ) : (
        <p className="mt-8 rounded-2xl bg-white/5 border border-white/10 p-4 text-sm text-slate-200">{t('layout:pair_iphone')}</p>
      )}

      <form onSubmit={submit} className="mt-6">
        <label className="text-xs text-slate-400 inline-flex items-center gap-1.5"><Link2 className="w-3.5 h-3.5" />{t('layout:pair_pegar')}</label>
        <div className="mt-2 flex gap-2">
          <input
            value={link}
            onChange={(e) => setLink(e.target.value)}
            placeholder="https://…#pair=…"
            className="flex-1 h-11 rounded-xl bg-white/5 border border-white/10 px-3 text-sm placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
          />
          <button type="submit" className="h-11 px-4 rounded-xl bg-white/10 hover:bg-white/15 text-sm font-medium">{t('layout:pair_usar')}</button>
        </div>
      </form>
      {error && <p className="mt-4 text-sm text-amber-300">{error}</p>}
      <p className="mt-10 text-xs text-slate-500">{t('layout:pair_ayuda')}</p>
    </div>
  );
};

/** Aviso fino arriba cuando el celular no va por su camino normal (internet):
 *  sin internet va por el wifi del local, y sin ninguno guarda los pedidos */
const ConnectionStrip: React.FC = () => {
  const mode = useTransport((s) => s.mode);
  const hostOnline = useTransport((s) => s.hostOnline);
  if (mode === 'unknown' || (mode === 'relay' && hostOnline !== false)) return null;
  const offline = mode === 'offline';
  const warn = offline || (mode === 'relay' && hostOnline === false);
  const label = offline ? t('layout:conn_sin_conexion') : mode === 'lan' ? t('layout:conn_wifi_local') : t('layout:conn_caja_apagada');
  return (
    <div
      role="status"
      className={`fixed inset-x-0 top-0 z-[70] h-5 flex items-center justify-center gap-1.5 text-[11px] font-medium pointer-events-none ${
        warn ? 'bg-amber-500 text-amber-950' : 'bg-slate-900 text-slate-100'
      }`}
    >
      {offline ? <WifiOff className="w-3 h-3" /> : mode === 'lan' ? <Wifi className="w-3 h-3" /> : <Globe className="w-3 h-3" />}
      {label}
    </div>
  );
};

export const ClientGate: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const clientApp = useTransport((s) => s.clientApp);
  const paired = useTransport((s) => s.paired);
  if (!clientApp) return <>{children}</>;
  if (!paired) return <PairDevice />;
  return (
    <>
      <ConnectionStrip />
      {children}
    </>
  );
};
