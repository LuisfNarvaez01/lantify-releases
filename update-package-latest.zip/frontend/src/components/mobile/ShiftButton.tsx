// ============================================
// Marcar entrada y salida del turno (Lantify 3.0 · Personal)
// ============================================
// Solo aparece si el negocio usa "Personal". Cada quien marca desde su sesión.

import React, { useCallback, useEffect, useState } from 'react';
import { Clock } from 'lucide-react';
import { t } from '../../i18n';
import { toast } from '../../shared/toast';
import { useFeatureFlag } from '../../shared/features';
import { staffAPI, type Shift } from '../../services/v3Api';

const hour = (iso: string) => new Date(iso).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });

export const ShiftButton: React.FC<{ variant?: 'row' | 'compact' }> = ({ variant = 'compact' }) => {
  const enabled = useFeatureFlag('staff');
  const [open, setOpen] = useState<Shift | null>(null);
  const [known, setKnown] = useState(false);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const res = await staffAPI.myShift();
      setOpen(res.open);
      setKnown(!!res.employeeId);
    } catch {
      setKnown(false);
    }
  }, []);

  useEffect(() => { if (enabled) load(); }, [enabled, load]);

  if (!enabled || !known) return null;

  const toggle = async () => {
    setBusy(true);
    try {
      if (open) {
        await staffAPI.myClockOut();
        setOpen(null);
        toast.success(t('v3:salida_marcada'));
      } else {
        setOpen(await staffAPI.myClockIn());
        toast.success(t('v3:entrada_marcada'));
      }
    } catch (err: any) {
      toast.error(err?.message || t('v3:no_se_guardo'));
    } finally {
      setBusy(false);
    }
  };

  const label = open ? t('v3:marcar_salida') : t('v3:marcar_entrada');
  if (variant === 'row') {
    return (
      <button type="button" onClick={toggle} disabled={busy} className={`w-full min-h-[52px] px-4 rounded-xl font-bold text-left flex items-center gap-2 ${open ? 'bg-emerald-50 text-emerald-900' : 'bg-blue-50 text-blue-900'}`}>
        <Clock className="w-5 h-5" aria-hidden />
        <span className="flex-1">{label}</span>
        {open && <span className="text-sm font-semibold">{t('v3:desde_hora', { hora: hour(open.startAt) })}</span>}
      </button>
    );
  }
  return (
    <button type="button" onClick={toggle} disabled={busy} title={open ? t('v3:desde_hora', { hora: hour(open.startAt) }) : undefined} className={`hidden md:inline-flex items-center gap-1.5 px-3 min-h-[36px] rounded-xl text-xs font-bold border ${open ? 'bg-emerald-500/15 border-emerald-400/40 text-emerald-200' : 'bg-white/5 border-white/15 text-slate-200 hover:bg-white/10'}`}>
      <Clock className="w-4 h-4" aria-hidden />
      {label}
    </button>
  );
};
