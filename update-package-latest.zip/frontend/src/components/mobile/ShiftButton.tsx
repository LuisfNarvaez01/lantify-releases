// ============================================
// Marcar entrada y salida del turno (Lantify 3.0 · Personal)
// ============================================
// Solo aparece si el negocio usa "Personal". Cada quien marca desde su sesión.

import React, { useEffect, useRef, useState } from 'react';
import { Clock } from 'lucide-react';
import { t } from '../../i18n';
import { toast } from '../../shared/toast';
import { confirmDialog } from '../../shared/dialog';
import { useFeatureFlag } from '../../shared/features';
import { staffAPI, type Shift } from '../../services/v3Api';

const stamp = (iso: string) => new Date(iso).toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
const shiftChanged = 'lantify:shift-changed';

export const ShiftButton: React.FC<{ variant?: 'prompt' | 'row' | 'compact' }> = ({ variant = 'compact' }) => {
  const enabled = useFeatureFlag('staff');
  const [open, setOpen] = useState<Shift | null>(null);
  const [known, setKnown] = useState(false);
  const [busy, setBusy] = useState(false);
  const prompted = useRef(false);

  useEffect(() => {
    if (!enabled || busy || (variant === 'prompt' && prompted.current)) return;
    let active = true;
    let request = 0;
    const refresh = async () => {
      const current = ++request;
      try {
        const res = await staffAPI.myShift();
        if (!active || current !== request) return;
        setOpen(res.open);
        setKnown(!!res.employeeId);
      } catch {
        if (active && current === request) setKnown(false);
      }
    };
    void refresh();
    if (variant === 'prompt') return () => { active = false; };
    const timer = window.setInterval(() => { if (!document.hidden) void refresh(); }, 60_000);
    window.addEventListener('focus', refresh);
    window.addEventListener(shiftChanged, refresh);
    document.addEventListener('visibilitychange', refresh);
    return () => {
      active = false;
      window.clearInterval(timer);
      window.removeEventListener('focus', refresh);
      window.removeEventListener(shiftChanged, refresh);
      document.removeEventListener('visibilitychange', refresh);
    };
  }, [enabled, busy, variant]);

  useEffect(() => {
    if (variant !== 'prompt' || !enabled || !known || prompted.current) return;
    prompted.current = true;
    if (open) return;
    void confirmDialog({
      title: t('v3:iniciar_turno'),
      message: t('v3:iniciar_turno_desc'),
      confirmLabel: t('v3:marcar_entrada'),
      cancelLabel: t('v3:ahora_no'),
    }).then(async (confirmed) => {
      if (!confirmed) return;
      try {
        await staffAPI.myClockIn();
        window.dispatchEvent(new Event(shiftChanged));
        toast.success(t('v3:entrada_marcada'));
      } catch (err: any) {
        toast.error(err?.message || t('v3:no_se_guardo'));
      }
    });
  }, [variant, enabled, known, open]);

  if (variant === 'prompt' || !enabled || !known) return null;

  const toggle = async () => {
    setBusy(true);
    try {
      if (open) {
        await staffAPI.myClockOut();
        setOpen(null);
        toast.success(t('v3:salida_marcada'));
      } else {
        setOpen(await staffAPI.myClockIn());
        toast.success(t('v3:entrada_marcada'));
      }
    } catch (err: any) {
      toast.error(err?.message || t('v3:no_se_guardo'));
    } finally {
      window.dispatchEvent(new Event(shiftChanged));
      setBusy(false);
    }
  };

  const label = open ? t('v3:marcar_salida') : t('v3:marcar_entrada');
  if (variant === 'row') {
    return (
      <button type="button" onClick={toggle} disabled={busy} className={`w-full min-h-[52px] px-4 rounded-xl font-bold text-left flex items-center gap-2 ${open ? 'bg-emerald-50 text-emerald-900' : 'bg-blue-50 text-blue-900'}`}>
        <Clock className="w-5 h-5" aria-hidden />
        <span className="flex-1">{label}</span>
        {open && <span className="text-sm font-semibold">{stamp(open.startAt)}</span>}
      </button>
    );
  }
  return (
    <button type="button" onClick={toggle} disabled={busy} title={open ? stamp(open.startAt) : undefined} className={`hidden md:inline-flex items-center gap-1.5 px-3 min-h-[36px] rounded-xl text-xs font-bold border ${open ? 'bg-emerald-500/15 border-emerald-400/40 text-emerald-200' : 'bg-white/5 border-white/15 text-slate-200 hover:bg-white/10'}`}>
      <Clock className="w-4 h-4" aria-hidden />
      {label}
    </button>
  );
};
