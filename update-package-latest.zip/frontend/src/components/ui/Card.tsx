// ============================================
// UI - Card: la superficie base de Lantify
// ============================================
// default  → blanca con anillo fino (la mayoría de paneles)
// inverse  → negra: la tarjeta protagonista de una fila (un KPI principal, el total)
// sunken   → hundida en el lienzo (zonas secundarias dentro de otra tarjeta)

import React from 'react';

export type CardTone = 'default' | 'inverse' | 'sunken';

const TONE: Record<CardTone, string> = {
  default: 'bg-white text-slate-900 shadow-card',
  inverse: 'bg-slate-950 text-white shadow-raised [color-scheme:dark]',
  sunken: 'bg-slate-50 text-slate-900 ring-1 ring-inset ring-slate-200/70',
};

const PAD = { none: '', sm: 'p-3', md: 'p-4 sm:p-5', lg: 'p-5 sm:p-6' } as const;

export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  tone?: CardTone;
  padding?: keyof typeof PAD;
  /** Radio grande (22px) para tarjetas destacadas de tableros */
  large?: boolean;
  /** Reacciona al pasar el mouse (tarjetas que abren algo) */
  interactive?: boolean;
}

export const Card = React.forwardRef<HTMLDivElement, CardProps>(({
  tone = 'default', padding = 'md', large = false, interactive = false, className = '', ...props
}, ref) => (
  <div
    ref={ref}
    {...props}
    className={[
      large ? 'rounded-[22px]' : 'rounded-[14px]',
      TONE[tone],
      PAD[padding],
      interactive ? 'transition-shadow duration-base ease-out hover:shadow-raised cursor-pointer' : '',
      className,
    ].join(' ')}
  />
));
Card.displayName = 'Card';

/** Encabezado de tarjeta: título corto + acción opcional a la derecha */
export function CardHeader({ title, hint, action, className = '' }: { title: React.ReactNode; hint?: React.ReactNode; action?: React.ReactNode; className?: string }) {
  return (
    <div className={`mb-3 flex items-start justify-between gap-3 ${className}`}>
      <div className="min-w-0">
        <h3 className="text-[0.95rem] font-semibold leading-tight tracking-tight">{title}</h3>
        {hint && <p className="mt-0.5 text-xs text-current opacity-60">{hint}</p>}
      </div>
      {action && <div className="shrink-0">{action}</div>}
    </div>
  );
}

export default Card;
