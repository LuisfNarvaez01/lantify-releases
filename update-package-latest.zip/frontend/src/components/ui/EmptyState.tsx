// ============================================
// UI - EmptyState y Skeleton
// ============================================
// Vacío: dice qué falta y qué hacer, sin ilustraciones ni emojis.
// Skeleton: barrido suave mientras carga (clase .lt-skeleton de index.css).

import React from 'react';

export function EmptyState({ icon, title, description, action, compact = false, className = '' }: {
  icon?: React.ReactNode;
  title: React.ReactNode;
  description?: React.ReactNode;
  action?: React.ReactNode;
  compact?: boolean;
  className?: string;
}) {
  return (
    <div className={`lt-fade flex flex-col items-center justify-center text-center ${compact ? 'gap-2 py-6' : 'gap-3 py-12'} ${className}`}>
      {icon && (
        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-slate-100 text-slate-500 [&>svg]:h-5 [&>svg]:w-5">
          {icon}
        </div>
      )}
      <div className="max-w-sm">
        <p className="text-sm font-semibold text-slate-900">{title}</p>
        {description && <p className="mt-1 text-sm text-slate-500">{description}</p>}
      </div>
      {action && <div className="mt-1">{action}</div>}
    </div>
  );
}

export function Skeleton({ className = 'h-4 w-full' }: { className?: string }) {
  return <div aria-hidden className={`lt-skeleton ${className}`} />;
}

export default EmptyState;
