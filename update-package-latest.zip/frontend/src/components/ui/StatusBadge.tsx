// ============================================
// UI - StatusBadge: un estado de negocio, siempre con texto
// ============================================
// El color nunca va solo: el punto acompaña a la palabra. La selección (anillo
// azul) es otra cosa y la pinta quien contiene el badge, no el badge.
// `neutral` es para ceros y estados sin incidencia: el rojo se reserva a errores.

import React from 'react';

export type StatusTone = 'neutral' | 'success' | 'warning' | 'danger' | 'info' | 'accent';

const TONE: Record<StatusTone, { chip: string; dot: string }> = {
  neutral: { chip: 'bg-slate-100 text-slate-700 ring-slate-200', dot: 'bg-slate-400' },
  success: { chip: 'bg-emerald-50 text-emerald-800 ring-emerald-200/80', dot: 'bg-emerald-500' },
  warning: { chip: 'bg-amber-50 text-amber-800 ring-amber-200/80', dot: 'bg-amber-500' },
  danger: { chip: 'bg-rose-50 text-rose-800 ring-rose-200/80', dot: 'bg-rose-500' },
  info: { chip: 'bg-sky-50 text-sky-800 ring-sky-200/80', dot: 'bg-sky-500' },
  accent: { chip: 'bg-blue-50 text-blue-800 ring-blue-200/80', dot: 'bg-blue-600' },
};

export function StatusBadge({ tone = 'neutral', children, dot = true, size = 'md', className = '' }: {
  tone?: StatusTone; children: React.ReactNode; dot?: boolean; size?: 'sm' | 'md'; className?: string;
}) {
  const t = TONE[tone];
  return (
    <span className={[
      'inline-flex items-center gap-1.5 whitespace-nowrap rounded-full font-medium ring-1 ring-inset',
      size === 'sm' ? 'h-5 px-2 text-[0.75rem]' : 'h-6 px-2.5 text-xs',
      t.chip, className,
    ].join(' ')}>
      {dot && <span aria-hidden className={`h-1.5 w-1.5 shrink-0 rounded-full ${t.dot}`} />}
      {children}
    </span>
  );
}

/** Variación contra el período anterior: verde si sube, neutro si es 0, rosa si baja */
export function DeltaBadge({ value, suffix = '%', invert = false }: { value: number | null | undefined; suffix?: string; invert?: boolean }) {
  if (value === null || value === undefined || !Number.isFinite(value)) return null;
  const good = invert ? value < 0 : value > 0;
  const tone: StatusTone = value === 0 ? 'neutral' : good ? 'success' : 'danger';
  const sign = value > 0 ? '+' : value < 0 ? '−' : '';
  return (
    <StatusBadge tone={tone} dot={false} size="sm" className="num">
      {sign}{Math.abs(value).toLocaleString('es-CO', { maximumFractionDigits: 1 })}{suffix}
    </StatusBadge>
  );
}

export default StatusBadge;
