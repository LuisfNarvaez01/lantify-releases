// ============================================
// UI - Segmented: alternar vistas o períodos (Lista/Mapa, Hoy/Ayer/7 días...)
// ============================================
// La píldora activa se desliza entre opciones (layoutId de motion); con
// movimiento reducido salta sin animación.

import React, { useId } from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { transition } from '../../shared/motion';

export interface SegmentedOption<T extends string> {
  id: T;
  label: React.ReactNode;
  icon?: React.ReactNode;
  /** Texto para lectores de pantalla cuando label es solo un ícono */
  ariaLabel?: string;
}

export function Segmented<T extends string>({ value, onChange, options, size = 'md', tone = 'light', className = '', ariaLabel }: {
  value: T;
  onChange: (id: T) => void;
  options: SegmentedOption<T>[];
  size?: 'sm' | 'md';
  /** dark: sobre la cabecera o una tarjeta negra */
  tone?: 'light' | 'dark';
  className?: string;
  ariaLabel?: string;
}) {
  const group = useId();
  const reduce = useReducedMotion();
  const dark = tone === 'dark';
  return (
    <div
      role="tablist"
      aria-label={ariaLabel}
      className={[
        'inline-flex items-center gap-0.5 rounded-full p-1',
        dark ? 'bg-white/10' : 'bg-slate-200/60',
        className,
      ].join(' ')}
    >
      {options.map((o) => {
        const active = o.id === value;
        return (
          <button
            key={o.id}
            type="button"
            role="tab"
            aria-selected={active}
            aria-label={o.ariaLabel}
            onClick={() => onChange(o.id)}
            className={[
              'relative inline-flex items-center justify-center gap-1.5 rounded-full font-medium',
              size === 'sm' ? 'h-7 px-3 text-xs' : 'h-9 px-4 text-sm',
              active
                ? (dark ? 'text-slate-950' : 'text-slate-950')
                : (dark ? 'text-white/70 hover:text-white' : 'text-slate-600 hover:text-slate-900'),
            ].join(' ')}
          >
            {active && (
              <motion.span
                layoutId={reduce ? undefined : `seg-${group}`}
                transition={transition.spring}
                className="absolute inset-0 rounded-full bg-white shadow-card"
                aria-hidden
              />
            )}
            <span className="relative inline-flex items-center gap-1.5">{o.icon}{o.label}</span>
          </button>
        );
      })}
    </div>
  );
}

export default Segmented;
