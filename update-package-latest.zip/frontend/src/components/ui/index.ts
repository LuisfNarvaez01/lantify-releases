// Componentes base del sistema visual corporativo (rediseño 2026-11).
// Código nuevo: usar estos en lugar de clases sueltas.
export { Card, CardHeader } from './Card';
export type { CardTone } from './Card';
export { StatusBadge, DeltaBadge } from './StatusBadge';
export type { StatusTone } from './StatusBadge';
export { Segmented } from './Segmented';
export { EmptyState, Skeleton } from './EmptyState';
export { Button } from '../common/Button';
