// ============================================
// ONBOARDING - Vista previa en vivo
// ============================================
// Un POS en miniatura que cambia con cada decisión del asistente: nombre, color,
// zonas y mesas, productos (carta leída o de ejemplo) y un ticket con impuesto
// y propina. No guarda nada; solo muestra cómo va a quedar.

import { t } from '../../i18n';
import { formatCurrency } from '../../shared/formatUtils';
import { TAX_BY_REGIME } from '../../shared/businessPresets';
import type { MenuCategory, TaxRegime } from '../../services/api';

interface SetupPreviewProps {
  businessName: string;
  typeLabel: string;
  usesTables: boolean;
  zones: { name: string; tables: number }[];
  menu: MenuCategory[];
  sampleItems: { name: string; price: number }[];
  taxRegime: TaxRegime;
  tipEnabled: boolean;
  tipPercent: number;
  deliveryEnabled: boolean;
}

export function SetupPreview(p: SetupPreviewProps) {
  const items = (p.menu.length ? p.menu.flatMap((c) => c.items) : p.sampleItems).slice(0, 6);
  const zone = p.zones.find((z) => z.tables > 0);
  const tables = Math.min(zone?.tables || 0, 12);
  const totalTables = p.zones.reduce((n, z) => n + (Number(z.tables) || 0), 0);

  // Ticket de ejemplo: los dos primeros productos (precio con impuesto incluido)
  const lines = items.slice(0, 2).map((i, idx) => ({ ...i, qty: idx === 0 ? 2 : 1 }));
  const total = lines.reduce((n, l) => n + l.price * l.qty, 0);
  const tax = TAX_BY_REGIME[p.taxRegime];
  const taxAmount = tax.taxRate ? Math.round(total - total / (1 + tax.taxRate / 100)) : 0;
  const tip = p.tipEnabled ? Math.round((total * (Number(p.tipPercent) || 0)) / 100) : 0;

  return (
    <aside aria-label={t('onboarding:vista_previa')} className="rounded-3xl border border-slate-200 bg-white shadow-sm overflow-hidden sticky top-6">
      <p className="px-4 pt-3 pb-2 text-[11px] font-bold uppercase tracking-wider text-slate-500">{t('onboarding:vista_previa')}</p>

      <div className="mx-3 mb-3 rounded-2xl border border-slate-200 overflow-hidden bg-slate-50">
        <div className="px-3 py-2.5 flex items-center justify-between gap-2 text-white transition-colors duration-500" style={{ background: 'var(--lantify-header)' }}>
          <span key={p.businessName} className="ob-pop text-sm font-bold truncate">{p.businessName.trim() || t('onboarding:tu_negocio')}</span>
          <span className="shrink-0 text-[10px] font-semibold opacity-75">{p.typeLabel}</span>
        </div>

        {p.usesTables && zone ? (
          <div className="p-3 border-b border-slate-200">
            <div className="flex items-center justify-between mb-2">
              <span className="flex gap-1 min-w-0 overflow-hidden">
                {p.zones.filter((z) => z.tables > 0).slice(0, 4).map((z, i) => (
                  <span key={`${z.name}-${i}`} className={`shrink-0 px-1.5 py-0.5 rounded-md text-[10px] font-bold ${i === 0 ? 'bg-white border border-slate-200 text-slate-800' : 'text-slate-500'}`}>
                    {z.name || t('onboarding:zona_salon')}
                  </span>
                ))}
              </span>
              <span className="text-[10px] font-semibold text-slate-500">{t('onboarding:total_mesas', { count: totalTables })}</span>
            </div>
            <div className="grid grid-cols-6 gap-1.5">
              {Array.from({ length: tables }, (_, i) => (
                <span
                  key={`${zone.name}-${i}`}
                  className={`ob-pop aspect-square rounded-lg text-[10px] font-bold flex items-center justify-center ${i === 1 || i === 4 ? 'text-white' : 'bg-white border border-slate-200 text-slate-600'}`}
                  style={{ animationDelay: `${i * 25}ms`, ...(i === 1 || i === 4 ? { background: 'var(--lantify-primary)' } : {}) }}
                >
                  {i + 1}
                </span>
              ))}
            </div>
          </div>
        ) : (
          <div className="px-3 py-2 border-b border-slate-200 text-[11px] font-semibold text-slate-600">
            {t('onboarding:preview_mostrador')}{p.deliveryEnabled ? ` · ${t('onboarding:preview_domicilios')}` : ''}
          </div>
        )}

        <div className="p-3 grid grid-cols-3 gap-1.5">
          {items.map((i, idx) => (
            <div key={`${i.name}-${idx}`} className="ob-pop rounded-lg bg-white border border-slate-200 p-1.5 min-h-[3.25rem] flex flex-col justify-between" style={{ animationDelay: `${idx * 40}ms` }}>
              <span className="text-[10px] font-semibold text-slate-800 leading-tight line-clamp-2 break-words hyphens-auto">{i.name}</span>
              <span className="text-[10px] font-bold tabular-nums" style={{ color: 'var(--lantify-primary)' }}>{formatCurrency(i.price)}</span>
            </div>
          ))}
          {!items.length && <p className="col-span-3 text-[11px] text-slate-500">{t('onboarding:preview_sin_productos')}</p>}
        </div>
      </div>

      {lines.length > 0 && (
        <div className="mx-3 mb-4 rounded-2xl border border-dashed border-slate-300 p-3 font-mono text-[11px] text-slate-700 space-y-1">
          <p className="text-center font-bold text-slate-900 truncate">{p.businessName.trim() || t('onboarding:tu_negocio')}</p>
          {lines.map((l) => (
            <div key={l.name} className="flex justify-between gap-2">
              <span className="truncate">{l.qty} × {l.name}</span>
              <span className="tabular-nums">{formatCurrency(l.price * l.qty)}</span>
            </div>
          ))}
          {taxAmount > 0 && (
            <div className="flex justify-between text-slate-500">
              <span>{t('onboarding:preview_incluye_impuesto', { type: tax.taxType, rate: tax.taxRate })}</span>
              <span className="tabular-nums">{formatCurrency(taxAmount)}</span>
            </div>
          )}
          {tip > 0 && (
            <div key={p.tipPercent} className="ob-pop flex justify-between">
              <span>{t('onboarding:preview_propina', { pct: p.tipPercent })}</span>
              <span className="tabular-nums">{formatCurrency(tip)}</span>
            </div>
          )}
          <div className="flex justify-between border-t border-slate-300 pt-1 font-bold text-slate-900">
            <span>{t('onboarding:preview_total')}</span>
            <span className="tabular-nums">{formatCurrency(total + tip)}</span>
          </div>
        </div>
      )}
    </aside>
  );
}
