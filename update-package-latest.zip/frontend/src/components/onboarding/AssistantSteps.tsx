// ============================================
// ONBOARDING - Pasos con IA
// ============================================
//   DescribeStep: "Asadero en Medellín con 12 mesas y terraza" → configuración sugerida
//   MenuStep:     foto de la carta → categorías y productos (o menú de ejemplo, o vacío)
// La IA solo propone: todo queda en los pasos del asistente para revisarlo antes de guardar.

import { useRef, useState } from 'react';
import { Sparkles, Loader2, Camera, Trash2, Wand2, BookOpen, CircleSlash, ImagePlus, AlertCircle, Check } from 'lucide-react';
import { t } from '../../i18n';
import { setupAIAPI, MenuCategory, SetupSuggestion } from '../../services/api';
import { prepareInvoicePhoto } from '../../shared/image';
import { formatCurrency } from '../../shared/formatUtils';
import { ChoiceCard } from '../common/Choice';

const aiError = (err: any) => (err?.message === 'NOT_AN_IMAGE' ? t('errors:AI_BAD_IMAGE') : err?.message || t('errors:AI_UNAVAILABLE'));

// ── Describe tu negocio ────────────────────────────────────

interface DescribeStepProps {
  lang: string;
  description: string;
  onDescription: (v: string) => void;
  applied: SetupSuggestion | null;
  onApply: (s: SetupSuggestion) => void;
  /** Resumen de lo aplicado (lo arma el asistente con las etiquetas de cada paso) */
  appliedChips: string[];
}

export function DescribeStep({ lang, description, onDescription, applied, onApply, appliedChips }: DescribeStepProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const examples = [t('onboarding:ia_ejemplo_1'), t('onboarding:ia_ejemplo_2'), t('onboarding:ia_ejemplo_3')];

  const ask = async () => {
    if (description.trim().length < 8) {
      setError(t('onboarding:ia_describe_mas'));
      return;
    }
    setLoading(true);
    setError('');
    try {
      onApply(await setupAIAPI.suggest(description.trim(), lang));
    } catch (err) {
      setError(aiError(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-xl font-bold text-slate-900 font-heading">{t('onboarding:ia_titulo')}</h2>
        <p className="text-sm text-slate-500 mt-1">{t('onboarding:ia_desc')}</p>
      </div>

      <div className="relative">
        <label htmlFor="ob-describe" className="sr-only">{t('onboarding:ia_titulo')}</label>
        <textarea
          id="ob-describe"
          rows={4}
          maxLength={600}
          value={description}
          onChange={(e) => { onDescription(e.target.value); setError(''); }}
          placeholder={t('onboarding:ia_placeholder')}
          className="w-full px-4 py-3 border border-slate-300 rounded-2xl bg-white focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 text-slate-900 text-sm leading-relaxed resize-none"
          disabled={loading}
        />
        {loading && <div className="ob-shimmer pointer-events-none absolute inset-0 rounded-2xl" aria-hidden />}
      </div>

      <div className="flex flex-wrap gap-2" aria-label={t('onboarding:ia_ejemplos')}>
        {examples.map((ex) => (
          <button
            key={ex}
            type="button"
            disabled={loading}
            onClick={() => { onDescription(ex); setError(''); }}
            className="px-3 py-1.5 rounded-full border border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600 hover:border-blue-300 hover:text-blue-700 text-left"
          >
            {ex}
          </button>
        ))}
      </div>

      <button
        type="button"
        onClick={ask}
        disabled={loading}
        className="inline-flex items-center gap-2 px-5 min-h-[46px] rounded-xl text-sm font-bold text-white bg-slate-900 hover:bg-slate-800 disabled:opacity-70"
      >
        {loading ? <Loader2 className="w-4 h-4 animate-spin" aria-hidden /> : <Wand2 className="w-4 h-4" aria-hidden />}
        {loading ? t('onboarding:ia_pensando') : applied ? t('onboarding:ia_otra_vez') : t('onboarding:ia_boton')}
      </button>

      {error && (
        <div role="alert" className="rounded-xl bg-rose-50 border border-rose-200 text-rose-700 px-4 py-3 text-xs font-semibold flex items-start gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 mt-px" aria-hidden />
          <span>{error} {t('onboarding:ia_puedes_seguir')}</span>
        </div>
      )}

      {applied && !loading && (
        <div className="ob-rise rounded-2xl border border-emerald-200 bg-emerald-50/60 p-4" role="status">
          <p className="flex items-start gap-2 text-sm font-semibold text-emerald-900">
            <Sparkles className="w-4 h-4 mt-0.5 shrink-0 text-emerald-700" aria-hidden />
            {applied.summary || t('onboarding:ia_listo')}
          </p>
          <ul className="mt-3 flex flex-wrap gap-1.5">
            {appliedChips.map((c, i) => (
              <li key={c} className="ob-pop inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-white border border-emerald-200 text-xs font-semibold text-emerald-800" style={{ animationDelay: `${i * 60}ms` }}>
                <Check className="w-3 h-3" aria-hidden />
                {c}
              </li>
            ))}
          </ul>
          <p className="mt-3 text-xs text-emerald-900/80">{t('onboarding:ia_revisa')}</p>
        </div>
      )}
    </div>
  );
}

// ── Tu carta ───────────────────────────────────────────────

export type MenuMode = 'photo' | 'sample' | 'empty';

interface MenuStepProps {
  lang: string;
  mode: MenuMode;
  onMode: (m: MenuMode) => void;
  menu: MenuCategory[];
  onMenu: (m: MenuCategory[]) => void;
  typeLabel: string;
}

/** Une lo leído de otra foto con lo que ya había (mismas categorías se juntan) */
const mergeMenus = (base: MenuCategory[], extra: MenuCategory[]) => {
  const out = base.map((c) => ({ ...c, items: [...c.items] }));
  for (const c of extra) {
    const same = out.find((o) => o.name.toLowerCase() === c.name.toLowerCase());
    if (same) same.items.push(...c.items.filter((i) => !same.items.some((s) => s.name.toLowerCase() === i.name.toLowerCase())));
    else out.push(c);
  }
  return out.slice(0, 25);
};

export function MenuStep({ lang, mode, onMode, menu, onMenu, typeLabel }: MenuStepProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [photo, setPhoto] = useState('');
  const [reading, setReading] = useState(false);
  const [error, setError] = useState('');
  const count = menu.reduce((n, c) => n + c.items.length, 0);

  const read = async (file: File | undefined) => {
    if (!file) return;
    setError('');
    try {
      const img = await prepareInvoicePhoto(file);
      setPhoto(img.previewUrl);
      setReading(true);
      const res = await setupAIAPI.readMenu(img.base64, img.mimeType, lang);
      if (!res.categories.length) setError(t('onboarding:carta_sin_productos'));
      else onMenu(mergeMenus(menu, res.categories));
    } catch (err) {
      setError(aiError(err));
    } finally {
      setReading(false);
      if (inputRef.current) inputRef.current.value = '';
    }
  };

  const editItem = (ci: number, ii: number, patch: Partial<{ name: string; price: number }>) =>
    onMenu(menu.map((c, i) => (i !== ci ? c : { ...c, items: c.items.map((it, j) => (j === ii ? { ...it, ...patch } : it)) })));
  const removeItem = (ci: number, ii: number) =>
    onMenu(menu.map((c, i) => (i !== ci ? c : { ...c, items: c.items.filter((_, j) => j !== ii) })).filter((c) => c.items.length));

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-xl font-bold text-slate-900 font-heading">{t('onboarding:carta_titulo')}</h2>
        <p className="text-sm text-slate-500 mt-1">{t('onboarding:carta_desc')}</p>
      </div>

      <div role="radiogroup" aria-label={t('onboarding:carta_titulo')} className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <ChoiceCard active={mode === 'photo'} onClick={() => onMode('photo')} title={t('onboarding:carta_foto')} description={t('onboarding:carta_foto_desc')}
          icon={<span className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${mode === 'photo' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600'}`}><Camera className="w-5 h-5" aria-hidden /></span>} />
        <ChoiceCard active={mode === 'sample'} onClick={() => onMode('sample')} title={t('onboarding:carta_ejemplo')} description={t('onboarding:cargar_menu_ejemplo_desc', { type: typeLabel.toLowerCase() })}
          icon={<span className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${mode === 'sample' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600'}`}><BookOpen className="w-5 h-5" aria-hidden /></span>} />
        <ChoiceCard active={mode === 'empty'} onClick={() => onMode('empty')} title={t('onboarding:carta_vacia')} description={t('onboarding:carta_vacia_desc')}
          icon={<span className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${mode === 'empty' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600'}`}><CircleSlash className="w-5 h-5" aria-hidden /></span>} />
      </div>

      {mode === 'photo' && (
        <div className="ob-rise space-y-4">
          <input ref={inputRef} type="file" accept="image/*" capture="environment" className="sr-only" id="ob-menu-photo" onChange={(e) => read(e.target.files?.[0])} />

          {reading ? (
            <div className="relative h-48 rounded-2xl overflow-hidden border border-slate-200 bg-slate-900" role="status">
              {photo && <img src={photo} alt="" className="w-full h-full object-cover opacity-70" />}
              <div className="absolute inset-x-0 top-0 h-1/4 bg-gradient-to-b from-transparent via-emerald-300/40 to-transparent motion-safe:animate-[scanline_1.6s_ease-in-out_infinite]" aria-hidden />
              <p className="absolute bottom-3 left-3 inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/90 text-xs font-bold text-slate-800">
                <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden />
                {t('onboarding:carta_leyendo')}
              </p>
            </div>
          ) : (
            <label htmlFor="ob-menu-photo" className="w-full p-5 rounded-2xl border-2 border-dashed border-slate-300 text-sm font-bold text-slate-600 hover:border-blue-400 hover:text-blue-700 flex flex-col items-center justify-center gap-1.5 cursor-pointer">
              <ImagePlus className="w-6 h-6" aria-hidden />
              {count ? t('onboarding:carta_otra_foto') : t('onboarding:carta_subir')}
              <span className="text-xs font-medium text-slate-500">{t('onboarding:carta_subir_desc')}</span>
            </label>
          )}

          {error && (
            <div role="alert" className="rounded-xl bg-rose-50 border border-rose-200 text-rose-700 px-4 py-3 text-xs font-semibold flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-px" aria-hidden />
              <span>{error}</span>
            </div>
          )}

          {count > 0 && (
            <div className="rounded-2xl border border-slate-200 divide-y divide-slate-100">
              <p className="px-4 py-2.5 text-xs font-bold text-slate-700 flex justify-between">
                <span>{t('onboarding:carta_leidos', { count })}</span>
                <span className="font-semibold text-slate-500">{t('onboarding:carta_corrige')}</span>
              </p>
              {menu.map((c, ci) => (
                <div key={`${c.name}-${ci}`} className="px-4 py-3">
                  <p className="text-[0.7857rem] font-bold uppercase tracking-wider text-slate-500 mb-2">{c.name}</p>
                  <ul className="space-y-1.5">
                    {c.items.map((it, ii) => (
                      <li key={ii} className="ob-pop flex items-center gap-2" style={{ animationDelay: `${Math.min(ii, 10) * 30}ms` }}>
                        <input aria-label={t('onboarding:carta_nombre_producto')} value={it.name} maxLength={80} onChange={(e) => editItem(ci, ii, { name: e.target.value })}
                          className="flex-1 min-w-0 px-2.5 py-1.5 border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-none focus:border-blue-600" />
                        <input aria-label={t('onboarding:carta_precio')} inputMode="numeric" value={it.price || ''} onChange={(e) => editItem(ci, ii, { price: Number(e.target.value.replace(/[^\d]/g, '')) || 0 })}
                          className="w-28 px-2.5 py-1.5 border border-slate-200 rounded-lg text-sm text-right tabular-nums text-slate-900 focus:outline-none focus:border-blue-600" />
                        <span className="hidden sm:inline w-24 text-right text-xs text-slate-500 tabular-nums">{formatCurrency(it.price)}</span>
                        <button type="button" onClick={() => removeItem(ci, ii)} aria-label={t('onboarding:carta_quitar')} className="w-8 h-8 shrink-0 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 flex items-center justify-center">
                          <Trash2 className="w-4 h-4" aria-hidden />
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
