// ============================================
// ONBOARDING - Configuración inicial por tipo de negocio
// ============================================
// Aparece al administrador la primera vez (o desde Configuración → Mantenimiento).
// Nada se guarda hasta el último paso: ahí se aplica todo en una sola operación.
// En la primera vez la IA puede proponer la configuración (descripción) y leer la
// carta de una foto; a la derecha, una vista previa en vivo de cómo va quedando.

import { useFeatures, type FeatureKey } from '../../shared/features';
import { ToggleRight as FeaturesStepIcon } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import {
  Utensils, Coffee, Wine, Sandwich, Truck, Store, Check, ChevronLeft, ChevronRight,
  Plus, Trash2, Sparkles, FileCheck2, Building2, Users, Palette, Settings2, AlertCircle, Loader2, Wand2, BookOpen,
} from 'lucide-react';
import { t, getLocale, useLanguage } from '../../i18n';
import { LanguageSelector } from '../common/LanguageSelector';
import { ThemeModeSelector } from '../common/ThemeModeSelector';
import { BUSINESS_PRESETS, BusinessPreset, getPreset, TAX_BY_REGIME, TAX_REGIMES } from '../../shared/businessPresets';
import { THEME_PRESETS, saveTheme, getSavedTheme } from '../../shared/themeManager';
import { saveTableViewMode } from '../../shared/posSettings';
import { businessAPI, BusinessSettings, BusinessType, TaxRegime, MenuCategory, SetupSuggestion } from '../../services/api';
import { DescribeStep, MenuStep, MenuMode } from './AssistantSteps';
import { SetupPreview } from './SetupPreview';
import { useBusinessStore } from '../../shared/business';
import { useFeature } from '../../shared/plan';
import { Toggle, ChoiceCard, ToggleGrid } from '../common/Choice';

interface OnboardingWizardProps {
  user: any;
  /** Configuración actual (reconfigurar) o null en una instalación nueva */
  current: BusinessSettings | null;
  onDone: (settings: BusinessSettings) => void;
  /** Cerrar sin guardar. En la primera configuración pospone hasta el próximo ingreso. */
  onSkip: () => void;
}

interface StaffRow {
  name: string;
  username: string;
  password: string;
  role: 'CASHIER' | 'WAITER';
}

const ICONS: Record<BusinessPreset['icon'], typeof Utensils> = {
  utensils: Utensils,
  coffee: Coffee,
  wine: Wine,
  burger: Sandwich,
  truck: Truck,
  store: Store,
  services: Sparkles,
};

const fieldClass =
  'px-3.5 py-2.5 border border-slate-300 rounded-xl bg-white focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 text-slate-900 text-sm font-medium transition-all';
const inputClass = `w-full ${fieldClass}`;
const labelClass = 'block text-xs font-bold text-slate-700 mb-1.5';

const readLegacyConfig = () => {
  try {
    return JSON.parse(localStorage.getItem('posConfig') || '{}');
  } catch {
    return {};
  }
};

export function OnboardingWizard({ user, current, onDone, onSkip }: OnboardingWizardProps) {
  const { language } = useLanguage();
  const legacy = useMemo(readLegacyConfig, []);
  const isReconfigure = !!current?.onboardingCompletedAt;
  const setBusinessSettings = useBusinessStore((s) => s.setSettings);
  const hasDian = useFeature('dian');

  const [step, setStep] = useState(0);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  // ── Datos que se envían al final ──
  const [businessType, setBusinessType] = useState<BusinessType>(current?.businessType || 'RESTAURANT');
  const preset = getPreset(businessType);
  const [usesTables, setUsesTables] = useState(current ? current.usesTables : preset.usesTables);
  const [zones, setZones] = useState(() => preset.zones.map((z) => ({ name: z.name, tables: z.tables })));
  const [tipEnabled, setTipEnabled] = useState(current ? current.tipEnabled : preset.tipEnabled);
  const [tipPercent, setTipPercent] = useState(current?.tipPercent ?? 10);
  const [inventoryEnabled, setInventoryEnabled] = useState(current ? current.inventoryEnabled : preset.inventoryEnabled);
  const [deliveryEnabled, setDeliveryEnabled] = useState(current ? current.deliveryEnabled : preset.deliveryEnabled);

  const [businessName, setBusinessName] = useState(current?.businessName || (legacy.businessName && legacy.businessName !== 'Lantify POS' ? legacy.businessName : ''));
  const [legalName, setLegalName] = useState(current?.legalName || '');
  const [nit, setNit] = useState(current?.nit || (legacy.nit || '').split('-')[0] || '');
  const [dv, setDv] = useState(current?.dv || (legacy.nit || '').split('-')[1] || '');
  const [taxRegime, setTaxRegime] = useState<TaxRegime>(current?.taxRegime || preset.taxRegime);
  const [address, setAddress] = useState(current?.address || legacy.address || '');
  const [city, setCity] = useState(current?.city || '');
  const [phone, setPhone] = useState(current?.phone || legacy.phone || '');
  const [email, setEmail] = useState(current?.email || '');

  const [wantsInvoice, setWantsInvoice] = useState<boolean | null>(current ? current.wantsElectronicInvoice : null);

  const [staff, setStaff] = useState<StaffRow[]>([]);
  const [menuMode, setMenuMode] = useState<MenuMode>(isReconfigure ? 'empty' : 'sample');
  const [menu, setMenu] = useState<MenuCategory[]>([]);

  // Asistente con IA (solo la primera vez)
  const [description, setDescription] = useState('');
  const [suggestion, setSuggestion] = useState<SetupSuggestion | null>(null);
  // Resultado guardado: la celebración se muestra antes de entrar al POS
  const [finished, setFinished] = useState<{ settings: BusinessSettings; tablesCreated: number; staffCreated: number; sampleProducts: number } | null>(null);

  // El aviso de error desaparece en cuanto el usuario corrige algo
  useEffect(() => {
    setError('');
  }, [businessName, nit, email, zones, usesTables, wantsInvoice, staff, menu, menuMode]);

  // Funciones de la 3.0 que el negocio decide usar (lo apagado no aparece en la interfaz)
  const featureSettings = useFeatures((st) => st.settings);
  const [featureFlags, setFeatureFlags] = useState<Partial<Record<FeatureKey, boolean>>>({});
  const flagOn = (k: FeatureKey) => featureFlags[k] ?? featureSettings.flags[k];
  const WIZARD_FEATURES: FeatureKey[] = ['dirty_tables', 'table_alerts', 'shopping_list', 'close_report', 'staff', 'tip_split'];

  const STEPS = [
    { id: 'welcome', label: t('onboarding:paso_bienvenida'), icon: Palette },
    ...(isReconfigure ? [] : [{ id: 'assistant', label: t('onboarding:paso_ia'), icon: Wand2 }]),
    { id: 'type', label: t('onboarding:paso_tipo'), icon: Store },
    { id: 'operation', label: t('onboarding:paso_operacion'), icon: Settings2 },
    { id: 'features', label: t('v3:funciones_titulo'), icon: FeaturesStepIcon },
    { id: 'business', label: t('onboarding:paso_negocio'), icon: Building2 },
    // La factura electrónica solo se pregunta si el plan la incluye
    ...(hasDian ? [{ id: 'invoice', label: t('onboarding:paso_facturacion'), icon: FileCheck2 }] : []),
    ...(isReconfigure ? [] : [{ id: 'menu', label: t('onboarding:paso_carta'), icon: BookOpen }]),
    { id: 'team', label: t('onboarding:paso_equipo'), icon: Users },
  ];

  // Productos de muestra para la vista previa (los reales se crean en el servidor)
  const sampleItems = useMemo(() => {
    if (menuMode !== 'sample') return [];
    return t(`onboarding:preview_items_${businessType}`).split('|').map((row) => {
      const [name, price] = row.split('=');
      return { name, price: Number(price) || 0 };
    });
  }, [menuMode, businessType, language]);

  const selectType = (p: BusinessPreset) => {
    setBusinessType(p.id);
    setUsesTables(p.usesTables);
    setZones(p.zones.map((z) => ({ name: z.name, tables: z.tables })));
    setTipEnabled(p.tipEnabled);
    setInventoryEnabled(p.inventoryEnabled);
    setDeliveryEnabled(p.deliveryEnabled);
    setTaxRegime(p.taxRegime);
    // Vista previa del color sugerido para el tipo de negocio
    const colors = THEME_PRESETS.find((tp) => tp.id === p.themePresetId);
    if (colors) {
      saveTheme({
        ...getSavedTheme(),
        primaryColor: colors.primary,
        primaryHover: colors.hover,
        primaryLight: colors.light,
        headerColor: colors.header,
        accentColor: colors.accent,
      });
    }
  };

  const totalTables = zones.reduce((n, z) => n + (Number(z.tables) || 0), 0);

  /** La IA propone; aquí se vuelca en los pasos para que el dueño lo revise */
  const applySuggestion = (sug: SetupSuggestion) => {
    selectType(getPreset(sug.businessType));
    setUsesTables(sug.usesTables);
    if (sug.usesTables && sug.zones.length) setZones(sug.zones.slice(0, 20));
    setTipEnabled(sug.tipEnabled);
    if (sug.tipEnabled) setTipPercent(sug.tipPercent || 10);
    setTaxRegime(sug.taxRegime);
    setInventoryEnabled(sug.inventoryEnabled);
    setDeliveryEnabled(sug.deliveryEnabled);
    if (sug.businessName && !businessName.trim()) setBusinessName(sug.businessName);
    if (sug.city && !city.trim()) setCity(sug.city);
    setSuggestion(sug);
  };

  const suggestionChips = suggestion
    ? [
        getPreset(suggestion.businessType).label,
        suggestion.usesTables
          ? t('onboarding:total_mesas', { count: suggestion.zones.reduce((n, z) => n + z.tables, 0) })
          : t('onboarding:preview_mostrador'),
        ...(suggestion.zones.length > 1 ? [suggestion.zones.map((z) => z.name).join(' · ')] : []),
        suggestion.tipEnabled ? t('onboarding:preview_propina', { pct: suggestion.tipPercent }) : t('onboarding:ia_sin_propina'),
        TAX_REGIMES.find((r) => r.id === suggestion.taxRegime)?.label || suggestion.taxRegime,
        ...(suggestion.deliveryEnabled ? [t('onboarding:preview_domicilios')] : []),
        ...(suggestion.inventoryEnabled ? [t('onboarding:ia_con_inventario')] : []),
      ]
    : [];

  const validateStep = (): string => {
    if (STEPS[step].id === 'operation' && usesTables && !isReconfigure) {
      if (totalTables < 1) return t('onboarding:error_minimo_una_mesa');
      if (totalTables > 200) return t('onboarding:error_maximo_mesas');
    }
    if (STEPS[step].id === 'business') {
      if (!businessName.trim()) return t('onboarding:error_nombre_negocio');
      if (nit && !/^[0-9.\s]{5,15}$/.test(nit)) return t('onboarding:error_nit');
      if (email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return t('onboarding:error_email');
    }
    if (STEPS[step].id === 'invoice' && wantsInvoice === null) return t('onboarding:error_elige_facturacion');
    if (STEPS[step].id === 'menu' && menuMode === 'photo') {
      if (!menu.length) return t('onboarding:error_carta_vacia');
      if (menu.some((c) => c.items.some((i) => !i.name.trim() || !(i.price > 0)))) return t('onboarding:error_carta_incompleta');
    }
    if (STEPS[step].id === 'team') {
      for (const s of staff) {
        if (!s.name.trim() || !s.username.trim() || !s.password) return t('onboarding:error_usuario_incompleto');
        if (s.password.length < 8) return t('errors:AUTH_WEAK_PASSWORD');
      }
      const names = staff.map((s) => s.username.trim().toLowerCase());
      if (new Set(names).size !== names.length) return t('onboarding:error_usuario_repetido');
    }
    return '';
  };

  const next = () => {
    const problem = validateStep();
    setError(problem);
    if (problem) return;
    if (step < STEPS.length - 1) setStep(step + 1);
    else finish();
  };

  const back = () => {
    setError('');
    setStep(Math.max(0, step - 1));
  };

  const finish = async () => {
    setSaving(true);
    setError('');
    const tax = TAX_BY_REGIME[taxRegime];
    try {
      const result = await businessAPI.completeOnboarding({
        settings: {
          businessType,
          businessName: businessName.trim(),
          legalName: legalName.trim() || null,
          nit: nit.replace(/[^0-9]/g, '') || null,
          dv: dv.trim() || null,
          taxRegime,
          defaultTaxType: tax.taxType,
          defaultTaxRate: tax.taxRate,
          address: address.trim() || null,
          city: city.trim() || null,
          phone: phone.trim() || null,
          email: email.trim() || null,
          usesTables,
          tipEnabled,
          tipPercent: Number(tipPercent) || 0,
          inventoryEnabled,
          deliveryEnabled,
          wantsElectronicInvoice: !!wantsInvoice,
        },
        zones: usesTables ? zones.map((z) => ({ name: z.name.trim(), tables: Number(z.tables) || 0 })) : [],
        staff: staff.map((s) => ({ ...s, name: s.name.trim(), username: s.username.trim().toLowerCase() })),
        loadSampleMenu: menuMode === 'sample',
        menu: menuMode === 'photo' ? menu.map((c) => ({ name: c.name.trim(), items: c.items.map((i) => ({ name: i.name.trim(), price: i.price })) })) : undefined,
        language,
      });
      // Las funciones elegidas se guardan aparte; si fallan, el negocio ya quedó configurado
      if (Object.keys(featureFlags).length) await useFeatures.getState().save({ flags: featureFlags, seenWhatsNew: true }).catch(() => undefined);
      else await useFeatures.getState().save({ seenWhatsNew: true }).catch(() => undefined);
      saveTableViewMode(usesTables ? preset.tableViewMode : 'operational');
      // Reconfigurar vuelve directo; la primera vez se celebra antes de entrar
      if (isReconfigure) {
        setBusinessSettings(result.settings);
        onDone(result.settings);
      } else {
        setFinished(result);
      }
    } catch (err: any) {
      setError(err.message || t('onboarding:error_guardar'));
    } finally {
      setSaving(false);
    }
  };

  const updateZone = (i: number, patch: Partial<{ name: string; tables: number }>) =>
    setZones(zones.map((z, idx) => (idx === i ? { ...z, ...patch } : z)));

  const updateStaff = (i: number, patch: Partial<StaffRow>) =>
    setStaff(staff.map((s, idx) => (idx === i ? { ...s, ...patch } : s)));

  const enterPos = () => {
    if (!finished) return;
    setBusinessSettings(finished.settings);
    onDone(finished.settings);
  };

  const renderStep = () => {
    switch (STEPS[step].id) {
      case 'assistant':
        return (
          <DescribeStep
            lang={language}
            description={description}
            onDescription={setDescription}
            applied={suggestion}
            onApply={applySuggestion}
            appliedChips={suggestionChips}
          />
        );

      case 'menu':
        return <MenuStep lang={language} mode={menuMode} onMode={setMenuMode} menu={menu} onMenu={setMenu} typeLabel={preset.label} />;

      case 'welcome':
        return (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-bold text-slate-900 font-heading">
                {t('onboarding:hola_name', { name: user?.name || user?.username })}
              </h2>
              <p className="text-sm text-slate-500 mt-1">{t('onboarding:bienvenida_desc')}</p>
            </div>
            <section>
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">{t('common:idioma')}</h3>
              <LanguageSelector variant="cards" />
            </section>
            <section>
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">{t('common:tema_de_la_pantalla')}</h3>
              <ThemeModeSelector variant="cards" />
            </section>
          </div>
        );

      case 'type':
        return (
          <div className="space-y-5">
            <div>
              <h2 className="text-xl font-bold text-slate-900 font-heading">{t('onboarding:que_tipo_de_negocio')}</h2>
              <p className="text-sm text-slate-500 mt-1">{t('onboarding:tipo_desc')}</p>
            </div>
            <div role="radiogroup" aria-label={t('onboarding:paso_tipo')} className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3">
              {BUSINESS_PRESETS.map((p) => {
                const Icon = ICONS[p.icon];
                const active = businessType === p.id;
                return (
                  <ChoiceCard
                    key={p.id}
                    active={active}
                    onClick={() => selectType(p)}
                    title={p.label}
                    description={p.description}
                    icon={
                      <span className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${active ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600'}`}>
                        <Icon className="w-5 h-5" aria-hidden />
                      </span>
                    }
                  />
                );
              })}
            </div>
            <div className="rounded-2xl bg-slate-50 border border-slate-200 p-4">
              <p className="text-xs font-bold text-slate-700 mb-2">{t('onboarding:que_se_prepara', { type: preset.label })}</p>
              <ul className="flex flex-wrap gap-2">
                {preset.highlights.map((h) => (
                  <li key={h} className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white border border-slate-200 text-xs font-semibold text-slate-700">
                    <Check className="w-3.5 h-3.5 text-emerald-600" aria-hidden />
                    {h}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        );

      case 'features':
        return (
          <div className="space-y-4">
            <div>
              <h2 className="text-xl font-bold text-slate-900 font-heading">{t('v3:paso_funciones_titulo')}</h2>
              <p className="text-sm text-slate-500 mt-1">{t('v3:paso_funciones_desc')}</p>
            </div>
            {WIZARD_FEATURES.filter((k) => usesTables || (k !== 'dirty_tables' && k !== 'table_alerts')).map((k) => {
              const need = featureSettings.requires[k];
              const blocked = !!need && !flagOn(need);
              return (
                <Toggle
                  key={k}
                  id={`ob-ft-${k}`}
                  checked={flagOn(k) && !blocked}
                  disabled={blocked}
                  onChange={(v) => setFeatureFlags((f) => ({ ...f, [k]: v }))}
                  label={t(`v3:f_${k}`)}
                  description={blocked ? t('v3:requiere', { funcion: t(`v3:f_${need}`) }) : t(`v3:f_${k}_desc`)}
                />
              );
            })}
          </div>
        );

      case 'operation':
        return (
          <div className="space-y-4">
            <div>
              <h2 className="text-xl font-bold text-slate-900 font-heading">{t('onboarding:como_atiendes')}</h2>
              <p className="text-sm text-slate-500 mt-1">{t('onboarding:operacion_desc')}</p>
            </div>

            <Toggle id="ob-tables" checked={usesTables} onChange={setUsesTables} label={t('onboarding:atiendes_en_mesas')} description={t('onboarding:atiendes_en_mesas_desc')} />

            {usesTables && (
              isReconfigure ? (
                <p className="text-xs text-slate-500 px-1">{t('onboarding:mesas_existentes_se_conservan')}</p>
              ) : (
                <div className="rounded-2xl border border-slate-200 bg-white p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-bold text-slate-900">{t('onboarding:zonas_y_mesas')}</p>
                    <span className="text-xs font-semibold text-slate-500">{t('onboarding:total_mesas', { count: totalTables })}</span>
                  </div>
                  {zones.map((z, i) => (
                    <div key={i} className="flex items-end gap-2">
                      <div className="flex-1">
                        <label htmlFor={`zone-name-${i}`} className={labelClass}>{t('onboarding:nombre_zona')}</label>
                        <input id={`zone-name-${i}`} className={inputClass} value={z.name} maxLength={40} onChange={(e) => updateZone(i, { name: e.target.value })} />
                      </div>
                      <div className="w-28">
                        <label htmlFor={`zone-count-${i}`} className={labelClass}>{t('onboarding:mesas')}</label>
                        <input id={`zone-count-${i}`} type="number" min={0} max={200} className={inputClass} value={z.tables} onChange={(e) => updateZone(i, { tables: Math.max(0, parseInt(e.target.value) || 0) })} />
                      </div>
                      <button
                        type="button"
                        onClick={() => setZones(zones.filter((_, idx) => idx !== i))}
                        disabled={zones.length === 1}
                        aria-label={t('onboarding:quitar_zona')}
                        className="h-[42px] w-[42px] shrink-0 rounded-xl border border-slate-200 text-slate-500 hover:text-rose-600 hover:border-rose-200 disabled:opacity-40 flex items-center justify-center"
                      >
                        <Trash2 className="w-4 h-4" aria-hidden />
                      </button>
                    </div>
                  ))}
                  {zones.length < 20 && (
                    <button
                      type="button"
                      onClick={() => setZones([...zones, { name: '', tables: 4 }])}
                      className="inline-flex items-center gap-1.5 text-xs font-bold text-blue-700 hover:text-blue-800"
                    >
                      <Plus className="w-4 h-4" aria-hidden />
                      {t('onboarding:agregar_zona')}
                    </button>
                  )}
                </div>
              )
            )}

            <Toggle id="ob-tip" checked={tipEnabled} onChange={setTipEnabled} label={t('onboarding:manejas_propina')} description={t('onboarding:manejas_propina_desc')} />
            {tipEnabled && (
              <div className="flex items-center gap-3 px-1">
                <label htmlFor="ob-tip-pct" className="text-xs font-bold text-slate-700">{t('onboarding:porcentaje_sugerido')}</label>
                <input id="ob-tip-pct" type="number" min={0} max={30} className={`${fieldClass} w-24`} value={tipPercent} onChange={(e) => setTipPercent(Math.min(30, Math.max(0, Number(e.target.value) || 0)))} />
                <span className="text-sm font-bold text-slate-500">%</span>
              </div>
            )}
            <ToggleGrid>
              <Toggle id="ob-inventory" checked={inventoryEnabled} onChange={setInventoryEnabled} label={t('onboarding:usas_inventario')} description={t('onboarding:usas_inventario_desc')} />
              <Toggle id="ob-delivery" checked={deliveryEnabled} onChange={setDeliveryEnabled} label={t('onboarding:haces_domicilios')} description={t('onboarding:haces_domicilios_desc')} />
            </ToggleGrid>
          </div>
        );

      case 'business':
        return (
          <div className="space-y-5">
            <div>
              <h2 className="text-xl font-bold text-slate-900 font-heading">{t('onboarding:datos_del_negocio')}</h2>
              <p className="text-sm text-slate-500 mt-1">{t('onboarding:datos_desc')}</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2">
                <label htmlFor="ob-name" className={labelClass}>{t('onboarding:nombre_comercial')} *</label>
                <input id="ob-name" className={inputClass} value={businessName} maxLength={120} onChange={(e) => setBusinessName(e.target.value)} placeholder={t('onboarding:nombre_comercial_ph')} autoFocus />
              </div>
              <div className="sm:col-span-2">
                <label htmlFor="ob-legal" className={labelClass}>{t('onboarding:razon_social')}</label>
                <input id="ob-legal" className={inputClass} value={legalName} maxLength={160} onChange={(e) => setLegalName(e.target.value)} placeholder={t('onboarding:razon_social_ph')} />
              </div>
              <div className="grid grid-cols-[1fr_5rem] gap-2 sm:col-span-2">
                <div>
                  <label htmlFor="ob-nit" className={labelClass}>{t('onboarding:nit_o_cedula')}</label>
                  <input id="ob-nit" className={inputClass} value={nit} inputMode="numeric" maxLength={15} onChange={(e) => setNit(e.target.value.replace(/[^0-9.\s]/g, ''))} />
                </div>
                <div>
                  <label htmlFor="ob-dv" className={labelClass}>{t('onboarding:dv')}</label>
                  <input id="ob-dv" className={inputClass} value={dv} inputMode="numeric" maxLength={1} onChange={(e) => setDv(e.target.value.replace(/[^0-9]/g, ''))} />
                </div>
              </div>
              <div>
                <label htmlFor="ob-address" className={labelClass}>{t('onboarding:direccion')}</label>
                <input id="ob-address" className={inputClass} value={address} maxLength={200} onChange={(e) => setAddress(e.target.value)} />
              </div>
              <div>
                <label htmlFor="ob-city" className={labelClass}>{t('onboarding:ciudad')}</label>
                <input id="ob-city" className={inputClass} value={city} maxLength={80} onChange={(e) => setCity(e.target.value)} />
              </div>
              <div>
                <label htmlFor="ob-phone" className={labelClass}>{t('onboarding:telefono')}</label>
                <input id="ob-phone" className={inputClass} value={phone} maxLength={40} inputMode="tel" onChange={(e) => setPhone(e.target.value)} />
              </div>
              <div>
                <label htmlFor="ob-email" className={labelClass}>{t('onboarding:correo')}</label>
                <input id="ob-email" type="email" className={inputClass} value={email} maxLength={120} onChange={(e) => setEmail(e.target.value)} />
              </div>
            </div>

            <section>
              <h3 className="text-sm font-bold text-slate-900">{t('onboarding:regimen_tributario')}</h3>
              <p className="text-xs text-slate-500 mb-3">{t('onboarding:regimen_desc')}</p>
              <div role="radiogroup" aria-label={t('onboarding:regimen_tributario')} className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {TAX_REGIMES.map((r) => (
                  <ChoiceCard key={r.id} active={taxRegime === r.id} onClick={() => setTaxRegime(r.id)} title={r.label} description={r.description} />
                ))}
              </div>
            </section>
          </div>
        );

      case 'invoice':
        return (
          <div className="space-y-5">
            <div>
              <h2 className="text-xl font-bold text-slate-900 font-heading">{t('onboarding:necesitas_factura_electronica')}</h2>
              <p className="text-sm text-slate-500 mt-1">{t('onboarding:facturacion_desc')}</p>
            </div>
            <div role="radiogroup" aria-label={t('onboarding:paso_facturacion')} className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <ChoiceCard active={wantsInvoice === true} onClick={() => setWantsInvoice(true)} title={t('onboarding:si_la_necesito')} description={t('onboarding:si_la_necesito_desc')} />
              <ChoiceCard active={wantsInvoice === false} onClick={() => setWantsInvoice(false)} title={t('onboarding:por_ahora_no')} description={t('onboarding:por_ahora_no_desc')} />
            </div>
            {wantsInvoice && (
              <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-xs text-amber-900 leading-relaxed">
                {t('onboarding:facturacion_pasos')}
              </div>
            )}
          </div>
        );

      case 'team':
        return (
          <div className="space-y-5">
            <div>
              <h2 className="text-xl font-bold text-slate-900 font-heading">{t('onboarding:tu_equipo')}</h2>
              <p className="text-sm text-slate-500 mt-1">{t('onboarding:equipo_desc')}</p>
            </div>

            {staff.map((s, i) => (
              <div key={i} className="rounded-2xl border border-slate-200 bg-white p-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label htmlFor={`st-name-${i}`} className={labelClass}>{t('onboarding:nombre')}</label>
                  <input id={`st-name-${i}`} className={inputClass} value={s.name} maxLength={120} onChange={(e) => updateStaff(i, { name: e.target.value })} />
                </div>
                <div>
                  <label htmlFor={`st-role-${i}`} className={labelClass}>{t('onboarding:rol')}</label>
                  <select id={`st-role-${i}`} className={inputClass} value={s.role} onChange={(e) => updateStaff(i, { role: e.target.value as StaffRow['role'] })}>
                    <option value="CASHIER">{t('onboarding:rol_cajero')}</option>
                    <option value="WAITER">{t('onboarding:rol_mesero')}</option>
                  </select>
                </div>
                <div>
                  <label htmlFor={`st-user-${i}`} className={labelClass}>{t('onboarding:usuario')}</label>
                  <input id={`st-user-${i}`} className={inputClass} value={s.username} maxLength={32} autoComplete="off" onChange={(e) => updateStaff(i, { username: e.target.value.toLowerCase().replace(/\s+/g, '') })} />
                </div>
                <div>
                  <label htmlFor={`st-pass-${i}`} className={labelClass}>{t('onboarding:contrasena')}</label>
                  <input id={`st-pass-${i}`} type="password" className={inputClass} value={s.password} autoComplete="new-password" placeholder={t('auth:minimo_8_caracteres')} onChange={(e) => updateStaff(i, { password: e.target.value })} />
                </div>
                <button
                  type="button"
                  onClick={() => setStaff(staff.filter((_, idx) => idx !== i))}
                  className="sm:col-span-2 justify-self-start inline-flex items-center gap-1.5 text-xs font-bold text-rose-700 hover:text-rose-800"
                >
                  <Trash2 className="w-4 h-4" aria-hidden />
                  {t('onboarding:quitar_usuario')}
                </button>
              </div>
            ))}

            {staff.length < 20 && (
              <button
                type="button"
                onClick={() => setStaff([...staff, { name: '', username: '', password: '', role: usesTables ? 'WAITER' : 'CASHIER' }])}
                className="w-full p-4 rounded-2xl border-2 border-dashed border-slate-300 text-sm font-bold text-slate-600 hover:border-blue-400 hover:text-blue-700 inline-flex items-center justify-center gap-2"
              >
                <Plus className="w-4 h-4" aria-hidden />
                {t('onboarding:agregar_usuario')}
              </button>
            )}

          </div>
        );
    }
    return null;
  };

  const isLast = step === STEPS.length - 1;

  if (finished) {
    const stats = [
      { n: finished.tablesCreated, label: t('onboarding:fin_mesas', { count: finished.tablesCreated }) },
      { n: finished.sampleProducts, label: t('onboarding:fin_productos', { count: finished.sampleProducts }) },
      { n: finished.staffCreated, label: t('onboarding:fin_usuarios', { count: finished.staffCreated }) },
    ].filter((x) => x.n > 0);
    return (
      <div className="min-h-screen bg-slate-900 font-sans flex items-center justify-center px-4 relative overflow-hidden" lang={getLocale()}>
        <div className="ob-confetti" aria-hidden>
          {Array.from({ length: 28 }, (_, i) => (
            <span key={i} style={{ left: `${(i * 37) % 100}%`, animationDelay: `${(i % 7) * 120}ms`, background: ['var(--lantify-primary)', '#10b981', '#f59e0b', '#f8fafc'][i % 4] }} />
          ))}
        </div>
        <div className="ob-rise relative w-full max-w-md bg-white rounded-3xl p-8 text-center shadow-xl" role="status">
          <span className="ob-check mx-auto w-16 h-16 rounded-full bg-emerald-600 text-white flex items-center justify-center">
            <Check className="w-8 h-8" aria-hidden />
          </span>
          <h1 className="mt-5 text-2xl font-bold text-slate-900 font-heading">{t('onboarding:fin_titulo', { name: finished.settings.businessName })}</h1>
          <p className="mt-2 text-sm text-slate-500">{t('onboarding:fin_desc')}</p>
          {stats.length > 0 && (
            <ul className="mt-6 grid gap-2" style={{ gridTemplateColumns: `repeat(${stats.length}, minmax(0, 1fr))` }}>
              {stats.map((x, i) => (
                <li key={x.label} className="ob-pop rounded-2xl bg-slate-50 border border-slate-200 py-3" style={{ animationDelay: `${300 + i * 120}ms` }}>
                  <span className="block text-2xl font-bold text-slate-900 tabular-nums">{x.n}</span>
                  <span className="text-xs font-semibold text-slate-500">{x.label}</span>
                </li>
              ))}
            </ul>
          )}
          <button type="button" onClick={enterPos} autoFocus className="mt-7 w-full inline-flex items-center justify-center gap-2 min-h-[50px] rounded-xl text-sm font-bold text-white bg-emerald-700 hover:bg-emerald-800">
            <Sparkles className="w-4 h-4" aria-hidden />
            {t('onboarding:empezar_a_vender')}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100 font-sans flex flex-col" lang={getLocale()}>
      <header className="bg-slate-900 text-white px-4 sm:px-8 py-4 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3 min-w-0">
          <img src="/logo-lantify-white.svg" alt="Lantify POS" className="h-7 w-auto shrink-0" />
          <span className="hidden sm:inline text-sm font-semibold text-slate-300 truncate">
            {isReconfigure ? t('onboarding:reconfigurar_negocio') : t('onboarding:configuracion_inicial')}
          </span>
        </div>
        <button type="button" onClick={onSkip} className="text-xs font-semibold text-slate-300 hover:text-white">
          {isReconfigure ? t('common:cancelar') : t('onboarding:hacerlo_despues')}
        </button>
      </header>

      <div className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 py-6 grid grid-cols-1 lg:grid-cols-[14rem_1fr] xl:grid-cols-[14rem_1fr_19rem] gap-6 items-start">
        {/* Pasos */}
        <nav aria-label={t('onboarding:pasos')}>
          <p className="lg:hidden text-xs font-bold text-slate-500 mb-2">
            {t('onboarding:paso_n_de_m', { n: step + 1, m: STEPS.length })} · {STEPS[step].label}
          </p>
          <div className="lg:hidden h-1.5 rounded-full bg-slate-200 overflow-hidden">
            <div className="h-full bg-blue-600 transition-all" style={{ width: `${((step + 1) / STEPS.length) * 100}%` }} />
          </div>
          <ol className="hidden lg:block space-y-1">
            {STEPS.map((s, i) => {
              const Icon = s.icon;
              const done = i < step;
              const active = i === step;
              return (
                <li key={s.id}>
                  <button
                    type="button"
                    onClick={() => i < step && setStep(i)}
                    disabled={i > step}
                    aria-current={active ? 'step' : undefined}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold text-left transition-colors ${
                      active ? 'bg-white text-slate-900 shadow-sm' : done ? 'text-slate-700 hover:bg-white/70' : 'text-slate-400'
                    }`}
                  >
                    <span className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 ${
                      done ? 'bg-emerald-600 text-white' : active ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-500'
                    }`}>
                      {done ? <Check className="w-4 h-4" aria-hidden /> : <Icon className="w-3.5 h-3.5" aria-hidden />}
                    </span>
                    {s.label}
                  </button>
                </li>
              );
            })}
          </ol>
        </nav>

        <main className="bg-white rounded-3xl border border-slate-200 shadow-sm flex flex-col min-h-[32rem]">
          <div key={STEPS[step].id} className="ob-step flex-1 p-5 sm:p-8">
            {renderStep()}
          </div>

          {error && (
            <div role="alert" className="mx-5 sm:mx-8 mb-4 bg-rose-50 border border-rose-200 text-rose-700 px-4 py-3 rounded-xl text-xs font-semibold flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" aria-hidden />
              <span>{error}</span>
            </div>
          )}

          <footer className="sticky bottom-0 bg-white rounded-b-3xl border-t border-slate-200 px-5 sm:px-8 py-4 flex items-center justify-between gap-3">
            <button
              type="button"
              onClick={back}
              disabled={step === 0 || saving}
              className="inline-flex items-center gap-1.5 px-4 min-h-[44px] rounded-xl text-sm font-bold text-slate-700 hover:bg-slate-100 disabled:opacity-0"
            >
              <ChevronLeft className="w-4 h-4" aria-hidden />
              {t('onboarding:atras')}
            </button>
            <button
              type="button"
              onClick={next}
              disabled={saving}
              className={`inline-flex items-center gap-2 px-6 min-h-[48px] rounded-xl text-sm font-bold text-white shadow-sm disabled:opacity-60 ${
                isLast ? 'bg-emerald-700 hover:bg-emerald-800' : 'bg-blue-600 hover:bg-blue-700'
              }`}
            >
              {saving ? (
                <Loader2 className="w-4 h-4 animate-spin" aria-hidden />
              ) : isLast ? (
                <Sparkles className="w-4 h-4" aria-hidden />
              ) : null}
              {saving ? t('onboarding:guardando') : isLast ? (isReconfigure ? t('onboarding:guardar_cambios') : t('onboarding:empezar_a_vender')) : t('onboarding:siguiente')}
              {!isLast && !saving && <ChevronRight className="w-4 h-4" aria-hidden />}
            </button>
          </footer>
        </main>

        <div className="hidden xl:block">
          <SetupPreview
            businessName={businessName}
            typeLabel={preset.label}
            usesTables={usesTables}
            zones={zones}
            menu={menuMode === 'photo' ? menu : []}
            sampleItems={sampleItems}
            taxRegime={taxRegime}
            tipEnabled={tipEnabled}
            tipPercent={tipPercent}
            deliveryEnabled={deliveryEnabled}
          />
        </div>
      </div>
    </div>
  );
}
