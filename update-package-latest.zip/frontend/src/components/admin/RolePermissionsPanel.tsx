// ============================================
// ADMIN - Funciones de cada rol (cajero y mesero)
// ============================================
// El ADMIN marca qué puede hacer cada rol. Se aplica de inmediato en el servidor;
// las pantallas de los demás equipos lo toman al volver a entrar o al recargar.

import React, { useEffect, useMemo, useState } from 'react';
import { Check, RotateCcw, Shield } from 'lucide-react';
import { t } from '../../i18n';
import { toast } from '../../shared/toast';
import {
  CONFIGURABLE_ROLES, ConfigurableRole, DEFAULT_ROLE_PERMISSIONS, Permission, PERMISSIONS, RolePermissions, usePermissions,
} from '../../shared/permissions';

const ROLE_LABEL: Record<ConfigurableRole, string> = {
  get CASHIER() { return t('admin:cajero'); },
  get WAITER() { return t('admin:mesero'); },
};

const same = (a: RolePermissions, b: RolePermissions) =>
  CONFIGURABLE_ROLES.every((r) => a[r].length === b[r].length && a[r].every((p) => b[r].includes(p)));

export const RolePermissionsPanel: React.FC = () => {
  const { perms, load, save } = usePermissions();
  const [draft, setDraft] = useState<RolePermissions>(perms);
  const [saving, setSaving] = useState(false);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { setDraft(perms); }, [perms]);

  const dirty = useMemo(() => !same(draft, perms), [draft, perms]);
  const isDefault = useMemo(() => same(draft, DEFAULT_ROLE_PERMISSIONS), [draft]);

  const toggle = (role: ConfigurableRole, p: Permission) =>
    setDraft((d) => ({
      ...d,
      [role]: d[role].includes(p) ? d[role].filter((x) => x !== p) : PERMISSIONS.filter((x) => x === p || d[role].includes(x)),
    }));

  const handleSave = async () => {
    setSaving(true);
    try {
      await save(draft);
      toast.success(t('roles:guardado_desc'), t('roles:guardado'));
    } catch (err: any) {
      toast.error(err?.message || t('roles:no_se_guardo'));
    } finally {
      setSaving(false);
    }
  };

  return (
    <section className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm" aria-labelledby="role-perms-title">
      <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h3 id="role-perms-title" className="font-bold text-slate-900 text-base flex items-center gap-2">
            <Shield className="w-4 h-4 text-blue-600" />
            {t('roles:titulo')}
          </h3>
          <p className="text-xs text-slate-500 mt-1 max-w-xl">{t('roles:subtitulo')}</p>
        </div>
        <div className="flex items-center gap-2 self-start sm:self-auto">
          {!isDefault && (
            <button
              type="button"
              onClick={() => setDraft({ CASHIER: [...DEFAULT_ROLE_PERMISSIONS.CASHIER], WAITER: [...DEFAULT_ROLE_PERMISSIONS.WAITER] })}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              {t('roles:restablecer')}
            </button>
          )}
          <button
            type="button"
            onClick={handleSave}
            disabled={!dirty || saving}
            className="px-5 py-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-xl text-xs font-bold transition-colors"
          >
            {saving ? t('roles:guardando') : t('roles:guardar')}
          </button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-sm">
          <thead>
            <tr className="bg-slate-50/80 text-xs uppercase tracking-wider text-slate-500 font-bold border-b border-slate-100">
              <th className="py-3 px-5">{t('roles:funcion')}</th>
              <th className="py-3 px-3 text-center w-24">{t('admin:administrador')}</th>
              {CONFIGURABLE_ROLES.map((r) => (
                <th key={r} className="py-3 px-3 text-center w-24">{ROLE_LABEL[r]}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            <tr>
              <td className="py-3 px-5">
                <p className="font-semibold text-slate-800">{t('roles:p_orders')}</p>
                <p className="text-xs text-slate-500">{t('roles:p_orders_desc')}</p>
              </td>
              {[0, 1, 2].map((i) => (
                <td key={i} className="py-3 px-3 text-center">
                  <Check className="w-4 h-4 text-slate-400 inline" aria-label={t('roles:siempre')} />
                </td>
              ))}
            </tr>
            {PERMISSIONS.map((p) => (
              <tr key={p} className="hover:bg-slate-50/50">
                <td className="py-3 px-5">
                  <p className="font-semibold text-slate-800">{t(`roles:p_${p}`)}</p>
                  <p className="text-xs text-slate-500">{t(`roles:p_${p}_desc`)}</p>
                </td>
                <td className="py-3 px-3 text-center">
                  <Check className="w-4 h-4 text-slate-400 inline" aria-label={t('roles:siempre')} />
                </td>
                {CONFIGURABLE_ROLES.map((r) => {
                  const on = draft[r].includes(p);
                  return (
                    <td key={r} className="py-3 px-3 text-center">
                      <button
                        type="button"
                        role="switch"
                        aria-checked={on}
                        aria-label={`${ROLE_LABEL[r]}: ${t(`roles:p_${p}`)}`}
                        onClick={() => toggle(r, p)}
                        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500/40 ${on ? 'bg-blue-600' : 'bg-slate-300'}`}
                      >
                        <span className={`inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform ${on ? 'translate-x-5' : 'translate-x-0.5'}`} />
                      </button>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="px-5 py-3 text-xs text-slate-500 border-t border-slate-100 bg-slate-50/50">{t('roles:nota')}</p>
    </section>
  );
};
