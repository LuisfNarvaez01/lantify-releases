// ============================================
// ADMIN - Funciones del negocio (Lantify 3.0)
// ============================================
// El ADMIN elige qué usa. Lo apagado desaparece de la interfaz de todo el equipo.

import React, { useEffect, useState } from 'react';
import { Lock, Plus, X } from 'lucide-react';
import { t } from '../../i18n';
import { toast } from '../../shared/toast';
import { Toggle, ToggleGrid } from '../common/Choice';
import { Button } from '../common/Button';
import { FEATURE_PLAN, usePlan } from '../../shared/plan';
import { STAFF_GROUPS, useFeatures, type FeatureKey } from '../../shared/features';
import type { AlertSettings, StaffGroup, TipRules } from '../../../../src/domain/v3/features';

/** Qué funciones nuevas se configuran en cada sección de Administración */
export const FEATURE_PLACES = {
  salon: ['table_details', 'dirty_tables', 'table_alerts', 'kitchen_display', 'waiter_suggestions', 'autopilot'],
  inventory: ['shopping_list'],
  users: ['staff', 'tip_split'],
  business: ['close_report'],
} as const satisfies Record<string, readonly FeatureKey[]>;

const SOON: FeatureKey[] = [];

const field = 'rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 min-h-[44px] focus:outline-none focus:ring-2 focus:ring-blue-500/40';
const card = 'bg-white rounded-3xl shadow-sm p-6 sm:p-8 border border-slate-200/80 space-y-3';

interface Props {
  /** Sección de Administración donde se muestra */
  place: keyof typeof FEATURE_PLACES;
  /** Frases rápidas de los comentarios (van con el salón) */
  notes?: boolean;
}

export const FeaturesPanel: React.FC<Props> = ({ place, notes: withNotes = false }) => {
  const groupKeys: readonly FeatureKey[] = FEATURE_PLACES[place];
  const { settings, load, save } = useFeatures();
  const plan = usePlan();
  const [busy, setBusy] = useState<string | null>(null);
  const [alerts, setAlerts] = useState<AlertSettings>(settings.alerts);
  const [tips, setTips] = useState<TipRules>(settings.tips);
  const [notes, setNotes] = useState<string[]>(settings.quickNotes);
  const [newNote, setNewNote] = useState('');
  const [owner, setOwner] = useState(settings.ownerWhatsapp);
  const [email, setEmail] = useState(settings.reportEmail);

  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    setAlerts(settings.alerts); setTips(settings.tips); setNotes(settings.quickNotes); setOwner(settings.ownerWhatsapp); setEmail(settings.reportEmail);
  }, [settings]);

  const apply = async (id: string, patch: Parameters<typeof save>[0]) => {
    setBusy(id);
    try {
      await save(patch);
      toast.success(t('v3:guardado'));
    } catch (err: any) {
      toast.error(err?.message || t('v3:no_se_guardo'));
    } finally {
      setBusy(null);
    }
  };

  const tipSum = STAFF_GROUPS.reduce((a, g) => a + (Number(tips.groups[g]) || 0), 0);

  return (
    <div className="space-y-6">
      {[{ id: place, keys: groupKeys }].map((group) => (
        <section key={group.id} className={card} aria-labelledby={`fg-${group.id}`}>
          <div className="flex items-center gap-2 pb-1">
            <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[0.7143rem] font-bold uppercase tracking-wide text-emerald-800">{t('v3:nuevo_3')}</span>
            <h3 id={`fg-${group.id}`} className="text-base font-bold text-slate-900 font-heading">{t(`v3:lugar_${group.id}`)}</h3>
          </div>
          <ToggleGrid>
          {group.keys.map((key) => {
            const code = settings.plan[key];
            const soon = SOON.includes(key);
            const included = !code || plan.has(code);
            const need = settings.requires[key];
            const blocked = !!need && !settings.flags[need];
            return (
              <React.Fragment key={key}>
                <Toggle
                  id={`ft-${key}`}
                  checked={settings.flags[key] && included && !soon}
                  disabled={soon || !included || blocked || busy === key}
                  onChange={(v) => apply(key, { flags: { [key]: v } })}
                  label={t(`v3:f_${key}`)}
                  description={
                    soon ? t('v3:llega_despues')
                      : !included ? t('plan:disponible_en', { plan: t(`plan:plan_${FEATURE_PLAN[code as string] || 'pro'}`) })
                        : blocked ? t('v3:requiere', { funcion: t(`v3:f_${need}`) })
                          : t(`v3:f_${key}_desc`)
                  }
                  badge={
                    soon ? <span className="rounded-full bg-amber-100 px-2 py-0.5 text-[0.7143rem] font-bold uppercase tracking-wide text-amber-800">{t('plan:proximamente')}</span>
                      : !included ? <Lock className="w-3.5 h-3.5 text-slate-400" aria-label={t('plan:no_incluido')} /> : undefined
                  }
                />
              </React.Fragment>
            );
          })}
          </ToggleGrid>
          {group.keys.map((key) => {
            return (
              <React.Fragment key={`d-${key}`}>

                {key === 'table_alerts' && settings.flags.table_alerts && (
                  <div className="rounded-2xl bg-slate-50 border border-slate-200 p-4 space-y-3">
                    {([['idle', 'idleMin'], ['bill', 'billMin'], ['ready', 'readyMin']] as const).map(([on, min]) => (
                      <div key={on} className="flex flex-wrap items-center gap-3">
                        <label className="flex items-center gap-2 text-sm font-semibold text-slate-800 min-h-[44px] flex-1 min-w-[14rem]">
                          <input type="checkbox" className="w-5 h-5 accent-blue-600" checked={alerts[on]} onChange={(e) => setAlerts({ ...alerts, [on]: e.target.checked })} />
                          {t(`v3:alerta_${on}`)}
                        </label>
                        <input type="number" min={1} max={240} aria-label={t('v3:minutos')} className={`${field} w-20`} value={alerts[min]} onChange={(e) => setAlerts({ ...alerts, [min]: Number(e.target.value) || 1 })} />
                        <span className="text-sm text-slate-500">{t('v3:minutos')}</span>
                      </div>
                    ))}
                    <p className="text-xs text-slate-500">{t('v3:alerta_ready_nota')}</p>
                    <Button size="sm" isLoading={busy === 'alerts'} onClick={() => apply('alerts', { alerts })}>{t('v3:guardar_tiempos')}</Button>
                  </div>
                )}

                {key === 'close_report' && settings.flags.close_report && (
                  <div className="rounded-2xl bg-slate-50 border border-slate-200 p-4 space-y-3">
                    <div className="grid sm:grid-cols-2 gap-3">
                      <label className="text-xs font-bold text-slate-700 space-y-1 block">
                        {t('v3:whatsapp_dueno')}
                        <input inputMode="tel" className={`${field} w-full`} placeholder="3001234567" value={owner} onChange={(e) => setOwner(e.target.value)} />
                      </label>
                      <label className="text-xs font-bold text-slate-700 space-y-1 block">
                        {t('v3:correo_adicional')}
                        <input type="email" className={`${field} w-full`} placeholder="dueno@correo.com" value={email} onChange={(e) => setEmail(e.target.value)} />
                      </label>
                    </div>
                    <p className="text-xs text-slate-500">{t('v3:reporte_nota')}</p>
                    <Button size="sm" isLoading={busy === 'report'} onClick={() => apply('report', { ownerWhatsapp: owner, reportEmail: email })}>{t('v3:guardar')}</Button>
                  </div>
                )}

                {key === 'tip_split' && settings.flags.tip_split && (
                  <div className="rounded-2xl bg-slate-50 border border-slate-200 p-4 space-y-3">
                    <p className="text-sm font-semibold text-slate-800">{t('v3:propinas_porcentajes')}</p>
                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                      {STAFF_GROUPS.map((g: StaffGroup) => (
                        <label key={g} className="text-xs font-bold text-slate-700 space-y-1 block">
                          {t(`v3:puesto_${g}`)}
                          <span className="flex items-center gap-1">
                            <input type="number" min={0} max={100} className={`${field} w-full`} value={tips.groups[g]} onChange={(e) => setTips({ ...tips, groups: { ...tips.groups, [g]: Math.max(0, Math.min(100, Number(e.target.value) || 0)) } })} />
                            <span className="text-slate-500">%</span>
                          </span>
                        </label>
                      ))}
                    </div>
                    <p className={`text-xs font-semibold ${tipSum === 100 ? 'text-emerald-700' : 'text-rose-700'}`} role="status">{t('v3:suma_porcentajes', { suma: tipSum })}</p>
                    <div className="grid sm:grid-cols-2 gap-3">
                      <label className="text-xs font-bold text-slate-700 space-y-1 block">
                        {t('v3:entre_meseros')}
                        <select className={`${field} w-full`} value={tips.waiterMode} onChange={(e) => setTips({ ...tips, waiterMode: e.target.value as TipRules['waiterMode'] })}>
                          <option value="EQUAL">{t('v3:partes_iguales')}</option>
                          <option value="CONTRIBUTION">{t('v3:segun_aporte')}</option>
                        </select>
                      </label>
                      <label className="text-xs font-bold text-slate-700 space-y-1 block">
                        {t('v3:periodo_reparto')}
                        <select className={`${field} w-full`} value={tips.period} onChange={(e) => setTips({ ...tips, period: e.target.value as TipRules['period'] })}>
                          <option value="WEEK">{t('v3:periodo_WEEK')}</option>
                          <option value="SESSION">{t('v3:periodo_SESSION')}</option>
                          <option value="MONTH">{t('v3:periodo_MONTH')}</option>
                        </select>
                      </label>
                    </div>
                    <Button size="sm" disabled={tipSum !== 100} isLoading={busy === 'tips'} onClick={() => apply('tips', { tips })}>{t('v3:guardar_reglas')}</Button>
                  </div>
                )}
              </React.Fragment>
            );
          })}
        </section>
      ))}

      {withNotes && <section className={card} aria-labelledby="fg-notes">
        <div className="pb-1">
          <h3 id="fg-notes" className="text-base font-bold text-slate-900 font-heading">{t('v3:frases_titulo')}</h3>
          <p className="text-xs text-slate-500">{t('v3:frases_desc')}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {notes.map((n) => (
            <span key={n} className="inline-flex items-center gap-1 rounded-full bg-slate-100 border border-slate-200 pl-3 pr-1 py-1 text-sm font-semibold text-slate-800">
              {n}
              <button type="button" className="w-8 h-8 inline-flex items-center justify-center rounded-full hover:bg-slate-200" aria-label={t('v3:quitar_frase', { frase: n })} onClick={() => setNotes(notes.filter((x) => x !== n))}>
                <X className="w-4 h-4" aria-hidden />
              </button>
            </span>
          ))}
        </div>
        <form
          className="flex gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            const clean = newNote.trim().slice(0, 30);
            if (clean && !notes.some((n) => n.toLowerCase() === clean.toLowerCase()) && notes.length < 16) setNotes([...notes, clean]);
            setNewNote('');
          }}
        >
          <input className={`${field} flex-1`} maxLength={30} placeholder={t('v3:frase_nueva')} aria-label={t('v3:frase_nueva')} value={newNote} onChange={(e) => setNewNote(e.target.value)} />
          <Button type="submit" variant="secondary" leftIcon={<Plus className="w-4 h-4" />}>{t('v3:agregar')}</Button>
        </form>
        <Button size="sm" isLoading={busy === 'notes'} onClick={() => apply('notes', { quickNotes: notes })}>{t('v3:guardar_frases')}</Button>
      </section>}
    </div>
  );
};
