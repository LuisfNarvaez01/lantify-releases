// ============================================
// ADMIN - Proyecta (Lantify Música): la cabina del DJ del local
// ============================================
// Proyecta es el programa del DJ (pantallas y música). Vinculado al negocio, los clientes
// piden canciones desde la mesa (musica.lantifypos.com/<local>?mesa=<mesa>) con los colores
// de Mi página, y la caja puede escribirle al DJ. Todo pasa por la nube
// (cloud/api-worker/src/music.ts; contrato en docs/integraciones/lantify-musica.md).

import { useCallback, useEffect, useRef, useState } from 'react';
import QRCode from 'qrcode';
import { Download, Link2, MessageCircle, Music, Printer, QrCode, Send } from 'lucide-react';
import { t } from '../../i18n';
import { toast } from '../../shared/toast';
import { tablesAPI } from '../../services/api';
import { proyectaAPI, type ProyectaMessage, type ProyectaStatus } from '../../services/proyectaApi';
import { tableOrdersAPI } from '../../services/v3Api';
import { Button } from '../common/Button';
import { ProyectaDeskCard } from './ProyectaDesk';

const CHAT_POLL_MS = 5_000;
const STATUS_POLL_MS = 15_000;
const LINK_POLL_MS = 5_000;

const esc = (s: string) => s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c] as string));

/** Hoja carta con tres QR por fila: cada uno abre la página de música con su mesa */
const printSheet = (business: string, cards: { label: string; qr: string }[], hint = t('proyecta:qr_hint')) => {
  document.getElementById('proyecta-qr-print')?.remove();
  const iframe = document.createElement('iframe');
  iframe.id = 'proyecta-qr-print';
  iframe.title = 'QR';
  Object.assign(iframe.style, { position: 'fixed', right: '0', bottom: '0', width: '0', height: '0', border: '0' });
  document.body.appendChild(iframe);
  const doc = iframe.contentWindow?.document;
  if (!doc) return;
  doc.open();
  doc.write(`<!doctype html><html><head><meta charset="utf-8"><title>${esc(business)}</title><style>
    @page { size: letter; margin: 10mm; }
    body { font-family: system-ui, sans-serif; margin: 0; }
    .grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 6mm; }
    .card { border: 1px dashed #94a3b8; border-radius: 4mm; padding: 5mm; text-align: center; break-inside: avoid; }
    .card img { width: 100%; max-width: 50mm; }
    .mesa { font-size: 20pt; font-weight: 800; margin: 2mm 0 0; }
    .hint { font-size: 9pt; color: #334155; margin: 1mm 0 0; }
    .biz { font-size: 8pt; color: #64748b; margin: 1mm 0 0; }
  </style></head><body><div class="grid">${cards.map((c) => `<div class="card"><img src="${c.qr}" alt=""><p class="mesa">${esc(t('proyecta:mesa', { number: c.label }))}</p><p class="hint">${esc(hint)}</p><p class="biz">${esc(business)}</p></div>`).join('')}</div>
  <script>window.onload = function () { setTimeout(function () { window.focus(); window.print(); }, 200); };</script></body></html>`);
  doc.close();
};

const timeOf = (iso: string) => {
  try { return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); } catch { return ''; }
};

const mmss = (ms: number) => {
  const s = Math.max(0, Math.ceil(ms / 1000));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
};

// ── Estado y vínculo ────────────────────────────────────────

function LinkCard({ status, onLinked }: { status: ProyectaStatus | null; onLinked: () => void }) {
  const [code, setCode] = useState<{ code: string; expiresAt: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [now, setNow] = useState(Date.now());
  const startSeen = useRef<string | null>(null);

  const left = code ? Date.parse(code.expiresAt) - now : 0;
  const expired = !!code && left <= 0;

  useEffect(() => {
    if (!code || expired) return;
    const tick = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(tick);
  }, [code, expired]);

  // Mientras se muestra el código, se revisa si Proyecta ya lo usó
  useEffect(() => {
    if (!code || expired) return;
    const poll = setInterval(() => {
      proyectaAPI.status().then((s) => {
        const seen = s.venue ? `${s.venue.venueId}:${s.venue.lastSeenAt ?? ''}` : null;
        if (s.venue && seen !== startSeen.current) {
          setCode(null);
          toast.success(t('proyecta:vinculado_ok'));
          onLinked();
        }
      }).catch(() => undefined);
    }, LINK_POLL_MS);
    return () => clearInterval(poll);
  }, [code, expired, onLinked]);

  const generate = async () => {
    setBusy(true);
    try {
      startSeen.current = status?.venue ? `${status.venue.venueId}:${status.venue.lastSeenAt ?? ''}` : null;
      setCode(await proyectaAPI.linkCode());
      setNow(Date.now());
    } catch (err: any) {
      toast.error(err?.message || t('proyecta:error'));
    } finally {
      setBusy(false);
    }
  };

  const venue = status?.venue;
  const state = !venue ? 'none' : venue.online ? 'online' : 'offline';
  const chip = {
    none: 'bg-slate-100 text-slate-600',
    offline: 'bg-amber-50 text-amber-800',
    online: 'bg-emerald-50 text-emerald-700',
  }[state];

  return (
    <section className="space-y-4 rounded-3xl border border-slate-200/80 bg-white p-6 shadow-sm sm:p-8" aria-labelledby="proyecta-title">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-blue-50 text-blue-700"><Music className="h-5 w-5" aria-hidden /></span>
          <div>
            <h3 id="proyecta-title" className="font-heading text-base font-bold text-slate-900">{t('proyecta:titulo')}</h3>
            <p className="max-w-prose text-sm text-slate-500">{t('proyecta:desc')}</p>
          </div>
        </div>
        <span className={`inline-flex h-7 items-center gap-1.5 rounded-full px-3 text-xs font-medium ${chip}`} role="status">
          <span className={`h-1.5 w-1.5 rounded-full ${state === 'online' ? 'bg-emerald-500' : state === 'offline' ? 'bg-amber-500' : 'bg-slate-400'}`} aria-hidden />
          {t(`proyecta:estado_${state}`)}
        </span>
      </div>

      {venue && (
        <p className="text-sm text-slate-600">
          {t('proyecta:vinculado_a', { name: venue.name })}
          {!venue.online && venue.lastSeenAt && <> · {t('proyecta:visto', { time: new Date(venue.lastSeenAt).toLocaleString() })}</>}
        </p>
      )}

      {code && !expired ? (
        <div className="rounded-2xl bg-slate-950 p-5 text-white sm:p-6">
          <p className="text-sm text-slate-300">{t('proyecta:codigo_instrucciones')}</p>
          <p className="mt-3 font-heading text-4xl font-semibold tracking-[0.2em] tabular-nums" aria-live="polite">{code.code.slice(0, 4)} {code.code.slice(4)}</p>
          <p className="mt-2 text-sm tabular-nums text-slate-300">{t('proyecta:codigo_vence', { time: mmss(left) })}</p>
        </div>
      ) : (
        <div className="flex flex-wrap items-center gap-3">
          <Button onClick={generate} isLoading={busy} variant={venue ? 'outline' : 'primary'}>
            <Link2 className="h-4 w-4" aria-hidden /> {venue ? t('proyecta:vincular_otra') : t('proyecta:vincular')}
          </Button>
          {expired && <p className="text-sm text-amber-800">{t('proyecta:codigo_vencido')}</p>}
        </div>
      )}

      {/* Para instalarlo en el computador del DJ: siempre la última versión */}
      {!venue?.online && (
        <p className="flex flex-wrap items-center gap-x-2 gap-y-1 border-t border-slate-100 pt-4 text-sm text-slate-500">
          <span>{t('proyecta:descargar_desc')}</span>
          <a href="https://lantifypos.com/descargar#proyecta" target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 font-semibold text-blue-700 underline underline-offset-2">
            <Download className="h-3.5 w-3.5" aria-hidden /> {t('proyecta:descargar')}
          </a>
        </p>
      )}
    </section>
  );
}

// ── Chat con el DJ ──────────────────────────────────────────

function ChatCard() {
  const [messages, setMessages] = useState<ProyectaMessage[]>([]);
  const [online, setOnline] = useState(false);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [unseen, setUnseen] = useState(0);
  const listRef = useRef<HTMLOListElement>(null);
  const lastId = useRef<string | null>(null);
  const loaded = useRef(false);

  const atBottom = () => {
    const el = listRef.current;
    return !el || el.scrollHeight - el.scrollTop - el.clientHeight < 40;
  };
  const toBottom = () => requestAnimationFrame(() => { const el = listRef.current; if (el) el.scrollTop = el.scrollHeight; });

  const add = useCallback((incoming: ProyectaMessage[]) => {
    if (!incoming.length) return;
    lastId.current = incoming[incoming.length - 1].id;
    const stick = atBottom();
    setMessages((prev) => {
      const ids = new Set(prev.map((m) => m.id));
      return [...prev, ...incoming.filter((m) => !ids.has(m.id))].slice(-200);
    });
    const fromDj = incoming.filter((m) => m.from === 'dj').length;
    if (loaded.current && fromDj) {
      toast.info(t('proyecta:chat_nuevo', { count: fromDj }));
      if (!stick) setUnseen((n) => n + fromDj);
    }
    if (stick || !loaded.current) toBottom();
  }, []);

  useEffect(() => {
    let alive = true;
    const poll = async () => {
      if (document.visibilityState === 'hidden' && loaded.current) return;
      try {
        const r = await proyectaAPI.chat(lastId.current);
        if (!alive) return;
        setOnline(r.online);
        add(r.messages);
        loaded.current = true;
      } catch { /* sin nube: se reintenta en el próximo sondeo */ }
    };
    poll();
    const timer = setInterval(poll, CHAT_POLL_MS);
    return () => { alive = false; clearInterval(timer); };
  }, [add]);

  const send = async (e: React.FormEvent) => {
    e.preventDefault();
    const clean = text.trim();
    if (!clean || sending) return;
    setSending(true);
    try {
      const msg = await proyectaAPI.send(clean);
      setText('');
      add([msg]);
      toBottom();
    } catch (err: any) {
      toast.error(err?.message || t('proyecta:error'));
    } finally {
      setSending(false);
    }
  };

  return (
    <section className="space-y-4 rounded-3xl border border-slate-200/80 bg-white p-6 shadow-sm sm:p-8" aria-labelledby="proyecta-chat-title">
      <div className="flex items-start gap-3">
        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-blue-50 text-blue-700"><MessageCircle className="h-5 w-5" aria-hidden /></span>
        <div>
          <h3 id="proyecta-chat-title" className="font-heading text-base font-bold text-slate-900">{t('proyecta:chat_titulo')}</h3>
          <p className="text-sm text-slate-500">{online ? t('proyecta:chat_desc_online') : t('proyecta:chat_desc_offline')}</p>
        </div>
      </div>

      <div className="relative">
        <ol ref={listRef} onScroll={() => atBottom() && setUnseen(0)} className="max-h-80 min-h-[10rem] space-y-2 overflow-y-auto rounded-2xl bg-slate-50 p-3" aria-live="polite" aria-label={t('proyecta:chat_titulo')}>
          {messages.length === 0 && <li className="py-8 text-center text-sm text-slate-500">{t('proyecta:chat_vacio')}</li>}
          {messages.map((m) => (
            <li key={m.id} className={`flex ${m.from === 'pos' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[80%] rounded-2xl px-3 py-2 text-sm ${m.from === 'pos' ? 'bg-blue-600 text-white' : 'bg-white text-slate-900 ring-1 ring-slate-200'}`}>
                <p className={`text-xs font-medium ${m.from === 'pos' ? 'text-blue-100' : 'text-slate-500'}`}>{m.from === 'dj' ? `${m.author} · DJ` : m.author} · <span className="tabular-nums">{timeOf(m.at)}</span></p>
                <p className="whitespace-pre-wrap break-words">{m.text}</p>
              </div>
            </li>
          ))}
        </ol>
        {unseen > 0 && (
          <button type="button" onClick={() => { setUnseen(0); toBottom(); }} className="absolute bottom-3 left-1/2 -translate-x-1/2 rounded-full bg-slate-950 px-3 py-1.5 text-xs font-semibold text-white shadow-lg">
            {t('proyecta:chat_ver_nuevos', { count: unseen })}
          </button>
        )}
      </div>

      <form onSubmit={send} className="flex gap-2">
        <label htmlFor="proyecta-chat-input" className="sr-only">{t('proyecta:chat_placeholder')}</label>
        <input
          id="proyecta-chat-input"
          value={text}
          maxLength={280}
          onChange={(e) => setText(e.target.value)}
          placeholder={t('proyecta:chat_placeholder')}
          className="min-h-[44px] flex-1 rounded-xl border border-slate-200 bg-white px-3 text-sm text-slate-900 focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/30"
        />
        <Button type="submit" isLoading={sending} disabled={!text.trim()}>
          <Send className="h-4 w-4" aria-hidden /> {t('proyecta:chat_enviar')}
        </Button>
      </form>
    </section>
  );
}

// ── QR de las mesas ─────────────────────────────────────────

function TablesQrCard({ tableUrl, business }: { tableUrl: string; business: string }) {
  // Cada mesa lleva un solo QR: con el pedido desde la mesa publicado es el de la mesa
  // (carta + canciones); si no, el de la página de música (que enlaza a la carta si hay página)
  const [tables, setTables] = useState<{ id: string; number: string; url: string }[]>([]);
  const [unified, setUnified] = useState(false);
  const [qrs, setQrs] = useState<Record<string, string>>({});

  useEffect(() => {
    let alive = true;
    Promise.all([
      tablesAPI.getAll().catch(() => []),
      tableOrdersAPI.qr().catch(() => null),
    ]).then(([list, sheet]) => {
      if (!alive) return;
      const withUrl = sheet?.enabled && sheet.published ? sheet.tables.filter((x) => x.url) : [];
      if (withUrl.length) {
        setUnified(true);
        setTables(withUrl.map((x) => ({ id: x.id, number: x.label || x.number, url: x.url! })));
        return;
      }
      setUnified(false);
      setTables((Array.isArray(list) ? list : []).filter((x: any) => x?.id && x?.number)
        .map((x: any) => ({ id: x.id, number: String(x.number), url: tableUrl + encodeURIComponent(String(x.number)) })));
    });
    return () => { alive = false; };
  }, [tableUrl]);

  useEffect(() => {
    let alive = true;
    Promise.all(tables.map(async (x) => [x.id, await QRCode.toDataURL(x.url, { margin: 1, width: 480, errorCorrectionLevel: 'M' })] as const))
      .then((pairs) => alive && setQrs(Object.fromEntries(pairs)))
      .catch(() => undefined);
    return () => { alive = false; };
  }, [tables]);

  const ready = tables.filter((x) => qrs[x.id]);
  const hint = unified ? t('proyecta:qr_hint_unico') : t('proyecta:qr_hint');

  return (
    <section className="space-y-4 rounded-3xl border border-slate-200/80 bg-white p-6 shadow-sm sm:p-8" aria-labelledby="proyecta-qr-title">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-blue-50 text-blue-700"><QrCode className="h-5 w-5" aria-hidden /></span>
          <div>
            <h3 id="proyecta-qr-title" className="font-heading text-base font-bold text-slate-900">{t(unified ? 'proyecta:qr_titulo_unico' : 'proyecta:qr_titulo')}</h3>
            <p className="max-w-prose text-sm text-slate-500">{t(unified ? 'proyecta:qr_desc_unico' : 'proyecta:qr_desc')}</p>
          </div>
        </div>
        <Button onClick={() => printSheet(business, ready.map((x) => ({ label: x.number, qr: qrs[x.id] })), hint)} disabled={!ready.length}>
          <Printer className="h-4 w-4" aria-hidden /> {t('proyecta:qr_imprimir', { count: ready.length })}
        </Button>
      </div>
      {tables.length === 0 && <p className="text-sm text-slate-500">{t('proyecta:qr_sin_mesas')}</p>}
      <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {tables.map((x) => (
          <li key={x.id} className="flex flex-col items-center gap-2 rounded-2xl border border-slate-200 p-3 text-center">
            {qrs[x.id] ? <img src={qrs[x.id]} alt={t('proyecta:mesa', { number: x.number })} className="aspect-square w-full max-w-[9rem]" /> : <span className="grid aspect-square w-full max-w-[9rem] place-items-center rounded-xl bg-slate-50 text-slate-300"><QrCode className="h-10 w-10" aria-hidden /></span>}
            <span className="font-heading text-lg font-black text-slate-900">{t('proyecta:mesa', { number: x.number })}</span>
            <button type="button" disabled={!qrs[x.id]} onClick={() => printSheet(business, [{ label: x.number, qr: qrs[x.id] }], hint)} className="inline-flex min-h-[36px] items-center gap-1 rounded-lg px-2 text-xs font-semibold text-blue-700 hover:bg-blue-50 disabled:opacity-50">
              <Printer className="h-3.5 w-3.5" aria-hidden /> {t('proyecta:qr_imprimir_una')}
            </button>
          </li>
        ))}
      </ul>
    </section>
  );
}

// ── Pantalla ────────────────────────────────────────────────

export function ProyectaPanel() {
  const [status, setStatus] = useState<ProyectaStatus | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(() => proyectaAPI.status()
    .then((s) => { setStatus(s); setError(null); })
    .catch((err: any) => setError(err?.message || t('proyecta:error'))), []);

  useEffect(() => {
    load();
    const timer = setInterval(load, STATUS_POLL_MS);
    return () => clearInterval(timer);
  }, [load]);

  return (
    <div className="space-y-6">
      {error && <p className="rounded-xl bg-amber-50 p-3 text-sm text-amber-900" role="alert">{error}</p>}
      <LinkCard status={status} onLinked={load} />
      {status?.venue && status.desk && <ProyectaDeskCard desk={status.desk} isAdmin onChange={load} />}
      {status?.venue && <ChatCard key={status.venue.venueId} />}
      {status?.venue && status.tableUrl && <TablesQrCard tableUrl={status.tableUrl} business={status.venue.name} />}
    </div>
  );
}
