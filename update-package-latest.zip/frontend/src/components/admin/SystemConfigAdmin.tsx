// ============================================
// ADMIN - System Configuration & Thermal Printing Subtabs
// ============================================

import React, { useState, useEffect } from 'react';
import { 
  Palette, Wrench, Save, Check, 
  Sliders, Type, Database, ShieldCheck, RefreshCw, Eye, Sparkles
} from 'lucide-react';
import { THEME_PRESETS, FONT_SCALE_PRESETS, DEFAULT_THEME, applyTheme, adjustColorBrightness, ThemeConfig, ThemePreset } from '../../shared/themeManager';
import { ThemeModeSelector } from '../common/ThemeModeSelector';
import { LanguageSelector } from '../common/LanguageSelector';
import { DianBillingAdmin } from './DianBillingAdmin';
import { BusinessSettingsPanel } from './BusinessSettingsPanel';
import { SubscriptionPanel } from './SubscriptionPanel';
import { AiSettingsPanel } from './AiSettingsPanel';
import { PrintingSettingsPanel } from './PrintingSettingsPanel';
import { PlanLocked } from '../common/PlanLocked';
import { useFeature } from '../../shared/plan';
import { openOnboarding } from '../../shared/business';
import { systemAPI } from '../../services/api';
import { toast } from '../../shared/toast';

import { t, getLocale } from '../../i18n';
type Section = 'business' | 'subscription' | 'ai' | 'dian' | 'printers' | 'appearance' | 'maintenance';

interface SystemConfigAdminProps {
  /** Sección que se muestra (el menú de Administración elige cuál) */
  section: Section;
  config: any;
  setConfig: React.Dispatch<React.SetStateAction<any>>;
  onFindDuplicates: () => void;
  isSearchingDuplicates: boolean;
}

export function SystemConfigAdmin({
  section,
  config,
  setConfig,
  onFindDuplicates,
  isSearchingDuplicates
}: SystemConfigAdminProps) {
  const subTab = section;
  const hasDian = useFeature('dian');
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [backups, setBackups] = useState<any[]>([]);
  const [isLoadingBackups, setIsLoadingBackups] = useState(false);
  const [isCreatingBackup, setIsCreatingBackup] = useState(false);

  const fetchBackups = async () => {
    setIsLoadingBackups(true);
    try {
      const res = await systemAPI.getBackups();
      setBackups(res.backups || []);
    } catch (err: any) {
      console.warn('Error fetching backups:', err);
    } finally {
      setIsLoadingBackups(false);
    }
  };

  useEffect(() => {
    if (subTab === 'maintenance') {
      fetchBackups();
    }
  }, [subTab]);

  const handleCreateManualBackup = async () => {
    setIsCreatingBackup(true);
    try {
      const res = await systemAPI.createBackup();
      toast.success(t('settings:copia_creada_name_sizekb', { name: res.backup?.name, sizeKB: res.backup?.sizeKB }), t('settings:respaldo_exitoso'));
      await fetchBackups();
    } catch (err: any) {
      toast.error(err.message || 'Error al generar la copia de seguridad', 'Error');
    } finally {
      setIsCreatingBackup(false);
    }
  };

  const handleSave = () => {
    localStorage.setItem('posConfig', JSON.stringify(config));
    if (config.theme) {
      applyTheme(config.theme);
    }
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleThemePresetSelect = (preset: ThemePreset) => {
    const newTheme: ThemeConfig = {
      ...(config.theme || DEFAULT_THEME),
      primaryColor: preset.primary,
      primaryHover: preset.hover,
      primaryLight: preset.light,
      headerColor: preset.header,
      accentColor: preset.accent,
    };
    setConfig({ ...config, theme: newTheme });
    applyTheme(newTheme);
  };

  const handleCustomColorChange = (zone: 'primary' | 'header' | 'accent', color: string) => {
    const currentTheme = config.theme || DEFAULT_THEME;
    const newTheme: ThemeConfig = { ...currentTheme };

    if (zone === 'primary') {
      newTheme.primaryColor = color;
      newTheme.primaryHover = adjustColorBrightness(color, -20);
      newTheme.primaryLight = adjustColorBrightness(color, 85);
      if (!currentTheme.headerColor) {
        newTheme.headerColor = adjustColorBrightness(color, -65);
      }
      if (!currentTheme.accentColor) {
        newTheme.accentColor = adjustColorBrightness(color, 35);
      }
    } else if (zone === 'header') {
      newTheme.headerColor = color;
    } else if (zone === 'accent') {
      newTheme.accentColor = color;
    }

    setConfig({ ...config, theme: newTheme });
    applyTheme(newTheme);
  };

  const handleFontScaleChange = (fontScale: string) => {
    const newTheme: ThemeConfig = {
      ...(config.theme || DEFAULT_THEME),
      fontScale,
    };
    setConfig({ ...config, theme: newTheme });
    applyTheme(newTheme);
  };

  return (
    <div className="space-y-6 pb-16">
      {subTab === 'appearance' && (
        <>
      {/* Header bar with save button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center shrink-0 shadow-xs">
            <Sliders className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900 font-heading">{t('settings:panel_de_configuracion')}</h2>
            <p className="text-xs text-slate-500">{t('settings:parametros_del_negocio_tickets_termicos_colores_y')}</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {savedSuccess && (
            <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200 animate-in fade-in duration-200">
              {t('settings:guardado_correctamente')}
            </span>
          )}
          <button
            onClick={handleSave}
            className="flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white px-6 py-2.5 rounded-2xl font-bold text-xs shadow-sm transition-all shrink-0"
          >
            <Save className="w-4 h-4" />
            {t('settings:guardar_cambios')}
          </button>
        </div>
      </div>

        </>
      )}

      {/* ──────────────────────────────────────────
          SUBTAB 1: NEGOCIO & FISCAL
      ────────────────────────────────────────── */}
      {subTab === 'business' && (
        <BusinessSettingsPanel
          onSaved={(b) => setConfig((c: any) => ({
            ...c,
            businessName: b.businessName,
            address: [b.address, b.city].filter(Boolean).join(', '),
            phone: b.phone || '',
            nit: b.nit ? (b.dv ? `${b.nit}-${b.dv}` : b.nit) : '',
          }))}
        />
      )}

      {/* ──────────────────────────────────────────
          SUBTAB: FACTURACIÓN ELECTRÓNICA DIAN (SOFTWARE PROPIO)
      ────────────────────────────────────────── */}
      {subTab === 'subscription' && <SubscriptionPanel />}

      {subTab === 'ai' && <AiSettingsPanel />}

      {subTab === 'dian' && (hasDian ? <DianBillingAdmin /> : <PlanLocked feature="dian" />)}

      {/* ──────────────────────────────────────────
          SUBTAB 2: IMPRESIÓN & TICKETS
      ────────────────────────────────────────── */}
      {subTab === 'printers' && <PrintingSettingsPanel />}

      {/* ──────────────────────────────────────────
          SUBTAB 3: APARIENCIA & COLORES
      ────────────────────────────────────────── */}
      {subTab === 'appearance' && (
        <div className="bg-white rounded-3xl shadow-sm p-8 border border-slate-200/80 space-y-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
            <div>
              <h3 className="text-base font-bold text-slate-900 font-heading flex items-center gap-2.5">
                <Palette className="w-5 h-5 text-blue-600" />
                {t('settings:sistema_de_colores_y_escala_tipografica')}
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                {t('settings:personaliza_la_identidad_visual_de_botones_y')}
              </p>
            </div>
            <span className="self-start md:self-auto px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-xs font-bold border border-blue-200/60 flex items-center gap-1.5 shadow-xs">
              <span className="w-2 h-2 rounded-full bg-blue-600 animate-pulse"></span>
              {t('settings:en_vivo')}
            </span>
          </div>

          {/* Tema claro / oscuro (preferencia de cada usuario) */}
          <div className="space-y-3">
            <div>
              <h4 className="text-sm font-bold text-slate-900">{t('settings:tema_de_la_pantalla')}</h4>
              <p className="text-xs text-slate-500 mt-0.5">{t('settings:se_guarda_para_tu_usuario_cada_persona')}</p>
            </div>
            <ThemeModeSelector />
          </div>

          {/* Idioma de la interfaz (preferencia de cada usuario) */}
          <div className="space-y-3">
            <div>
              <h4 className="text-sm font-bold text-slate-900">{t('settings:idioma_de_la_pantalla')}</h4>
              <p className="text-xs text-slate-500 mt-0.5">{t('settings:idioma_de_la_pantalla_desc')}</p>
            </div>
            <LanguageSelector />
          </div>

          {/* Paletas de Colores de Amplia Gama */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <label className="block font-bold text-slate-800 uppercase tracking-wider text-xs flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  {t('settings:gama_de_temas_e_identidades_comerciales')}
                </label>
                <p className="text-xs text-slate-500 mt-0.5">
                  {t('settings:selecciona_una_paleta_predisenada_segun_el_tipo')}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-3.5">
              {THEME_PRESETS.map((preset) => {
                const currentPrimary = config.theme?.primaryColor || DEFAULT_THEME.primaryColor;
                const isSelected = currentPrimary.toLowerCase() === preset.primary.toLowerCase();
                return (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() => handleThemePresetSelect(preset)}
                    className={`flex items-start gap-3.5 p-4 rounded-2xl border-2 transition-all text-left relative overflow-hidden group ${
                      isSelected
                        ? 'border-blue-600 bg-blue-50/40 shadow-sm ring-2 ring-blue-600/20'
                        : 'border-slate-200 hover:border-slate-300 bg-white hover:shadow-xs'
                    }`}
                  >
                    {/* Visual Color Swatches preview */}
                    <div className="flex flex-col gap-1 shrink-0 pt-0.5">
                      <div
                        className="w-9 h-9 rounded-xl shadow-inner flex items-center justify-center text-white"
                        style={{ backgroundColor: preset.primary }}
                      >
                        {isSelected && <Check className="w-4 h-4 drop-shadow font-black" />}
                      </div>
                      <div className="flex gap-1 justify-center">
                        <span
                          className="w-4 h-2 rounded-full border border-white/50 shadow-xs"
                          style={{ backgroundColor: preset.header }}
                          title={t('settings:color_de_encabezado')}
                        />
                        <span
                          className="w-4 h-2 rounded-full border border-white/50 shadow-xs"
                          style={{ backgroundColor: preset.accent }}
                          title={t('settings:color_de_acento')}
                        />
                      </div>
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1 mb-0.5">
                        <span className="font-bold text-xs text-slate-900 truncate group-hover:text-blue-600 transition-colors">
                          {preset.name}
                        </span>
                        <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 border border-slate-200 shrink-0">
                          {preset.category}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 leading-snug line-clamp-2">
                        {preset.description}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Personalización Fina por Zonas del Sistema */}
          <div className="space-y-4 pt-4 border-t border-slate-100">
            <div>
              <label className="block font-bold text-slate-800 uppercase tracking-wider text-xs flex items-center gap-2">
                <Palette className="w-4 h-4 text-blue-600" />
                {t('settings:personalizacion_fina_por_zonas_del_sistema')}
              </label>
              <p className="text-xs text-slate-500 mt-0.5">
                {t('settings:ajusta_independientemente_el_color_de_cada_area')}
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Zona 1: Color Primario */}
              <div className="p-4 rounded-2xl border-2 border-slate-200 bg-white space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="font-bold text-xs text-slate-800 block">{t('settings:color_primario')}</span>
                    <span className="text-xs text-slate-400">{t('settings:botones_cobros_y_tablas')}</span>
                  </div>
                  <div
                    className="w-8 h-8 rounded-xl shadow-xs border border-black/10 shrink-0"
                    style={{ backgroundColor: config.theme?.primaryColor || DEFAULT_THEME.primaryColor }}
                  />
                </div>
                <div className="flex items-center gap-2 pt-1 border-t border-slate-100">
                  <input
                    type="color"
                    id="pickerPrimary"
                    value={config.theme?.primaryColor || DEFAULT_THEME.primaryColor}
                    onChange={(e) => handleCustomColorChange('primary', e.target.value)}
                    className="w-8 h-8 rounded-lg cursor-pointer border-0 p-0 bg-transparent shrink-0"
                  />
                  <input
                    type="text"
                    value={config.theme?.primaryColor || DEFAULT_THEME.primaryColor}
                    onChange={(e) => handleCustomColorChange('primary', e.target.value)}
                    className="flex-1 px-2.5 py-1.5 text-xs font-mono uppercase bg-slate-50 border border-slate-200 rounded-lg text-center"
                    placeholder="#1e40af"
                  />
                </div>
              </div>

              {/* Zona 2: Color de Encabezado */}
              <div className="p-4 rounded-2xl border-2 border-slate-200 bg-white space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="font-bold text-xs text-slate-800 block">{t('settings:barra_superior')}</span>
                    <span className="text-xs text-slate-400">{t('settings:encabezado_y_fondo_del_header')}</span>
                  </div>
                  <div
                    className="w-8 h-8 rounded-xl shadow-xs border border-black/10 shrink-0"
                    style={{ backgroundColor: config.theme?.headerColor || DEFAULT_THEME.headerColor }}
                  />
                </div>
                <div className="flex items-center gap-2 pt-1 border-t border-slate-100">
                  <input
                    type="color"
                    id="pickerHeader"
                    value={config.theme?.headerColor || DEFAULT_THEME.headerColor}
                    onChange={(e) => handleCustomColorChange('header', e.target.value)}
                    className="w-8 h-8 rounded-lg cursor-pointer border-0 p-0 bg-transparent shrink-0"
                  />
                  <input
                    type="text"
                    value={config.theme?.headerColor || DEFAULT_THEME.headerColor}
                    onChange={(e) => handleCustomColorChange('header', e.target.value)}
                    className="flex-1 px-2.5 py-1.5 text-xs font-mono uppercase bg-slate-50 border border-slate-200 rounded-lg text-center"
                    placeholder="#0f172a"
                  />
                </div>
              </div>

              {/* Zona 3: Color de Acento */}
              <div className="p-4 rounded-2xl border-2 border-slate-200 bg-white space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="font-bold text-xs text-slate-800 block">{t('settings:color_de_acento')}</span>
                    <span className="text-xs text-slate-400">{t('settings:badges_etiquetas_y_luces')}</span>
                  </div>
                  <div
                    className="w-8 h-8 rounded-xl shadow-xs border border-black/10 shrink-0"
                    style={{ backgroundColor: config.theme?.accentColor || DEFAULT_THEME.accentColor }}
                  />
                </div>
                <div className="flex items-center gap-2 pt-1 border-t border-slate-100">
                  <input
                    type="color"
                    id="pickerAccent"
                    value={config.theme?.accentColor || DEFAULT_THEME.accentColor}
                    onChange={(e) => handleCustomColorChange('accent', e.target.value)}
                    className="w-8 h-8 rounded-lg cursor-pointer border-0 p-0 bg-transparent shrink-0"
                  />
                  <input
                    type="text"
                    value={config.theme?.accentColor || DEFAULT_THEME.accentColor}
                    onChange={(e) => handleCustomColorChange('accent', e.target.value)}
                    className="flex-1 px-2.5 py-1.5 text-xs font-mono uppercase bg-slate-50 border border-slate-200 rounded-lg text-center"
                    placeholder="#38bdf8"
                  />
                </div>
              </div>
            </div>

            {/* Live System Preview Mockup */}
            <div className="mt-4 p-4 rounded-2xl bg-slate-900 border border-slate-800 text-white space-y-3">
              <div className="flex items-center justify-between text-xs font-bold text-slate-300 border-b border-slate-800 pb-2">
                <span className="flex items-center gap-1.5">
                  <Eye className="w-3.5 h-3.5 text-blue-400" />
                  {t('settings:previsualizacion_en_tiempo_real_del_sistema')}
                </span>
                <span className="text-xs text-emerald-400 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                  {t('settings:reactivo_al_instante')}
                </span>
              </div>

              {/* Mock App Window */}
              <div className="rounded-xl overflow-hidden border border-slate-700/80 shadow-md">
                {/* Mock Header */}
                <div
                  className="px-4 py-2.5 flex items-center justify-between transition-colors"
                  style={{ backgroundColor: config.theme?.headerColor || DEFAULT_THEME.headerColor }}
                >
                  <div className="flex items-center gap-2">
                    <img src="/logo-lantify-white.svg" alt="Lantify" className="h-6 w-auto" />
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span
                      className="px-2.5 py-1 rounded-md text-xs font-bold text-white shadow-xs"
                      style={{ backgroundColor: config.theme?.primaryColor || DEFAULT_THEME.primaryColor }}
                    >
                      {t('settings:mesas_pedidos')}
                    </span>
                    <span className="px-2 py-1 text-xs text-slate-300 font-medium">{t('settings:catalogo')}</span>
                    <span className="px-2 py-1 text-xs text-slate-300 font-medium">{t('settings:ventas')}</span>
                  </div>
                  <div>
                    <span
                      className="text-xs font-black uppercase px-2 py-0.5 rounded-full text-slate-900"
                      style={{ backgroundColor: config.theme?.accentColor || DEFAULT_THEME.accentColor }}
                    >
                      {t('settings:caja_abierta')}
                    </span>
                  </div>
                </div>

                {/* Mock Body */}
                <div className="bg-slate-50 p-4 text-slate-800 flex items-center justify-between gap-4">
                  <div className="space-y-1">
                    <p className="text-xs font-bold text-slate-900">{t('settings:mesa_04_salon_principal')}</p>
                    <p className="text-xs text-slate-500">{t('settings:2_comensales_64_000_consumo')}</p>
                  </div>
                  <button
                    type="button"
                    className="px-4 py-1.5 rounded-xl text-xs font-bold text-white shadow-xs transition-transform active:scale-95"
                    style={{ backgroundColor: config.theme?.primaryColor || DEFAULT_THEME.primaryColor }}
                  >
                    {t('settings:cobrar_pedido')}
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Escala Tipográfica Global */}
          <div className="space-y-3 pt-2 border-t border-slate-100">
            <label className="block font-bold text-slate-800 uppercase tracking-wider text-xs flex items-center gap-1.5">
              <Type className="w-4 h-4 text-blue-600" />
              {t('settings:densidad_y_escala_tipografica')}
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {FONT_SCALE_PRESETS.map((scale) => {
                const isSelected = (config.theme?.fontScale || DEFAULT_THEME.fontScale) === scale.size;
                return (
                  <button
                    key={scale.id}
                    type="button"
                    onClick={() => handleFontScaleChange(scale.size)}
                    className={`p-3.5 rounded-2xl border-2 text-left transition-all ${
                      isSelected
                        ? 'border-blue-600 bg-blue-50/50 shadow-sm ring-2 ring-blue-600/20'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="flex justify-between items-center mb-1">
                      <span className="font-bold text-xs text-slate-900">{scale.label}</span>
                      <span className="text-xs font-mono px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 font-bold">
                        {scale.size}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 leading-tight">{scale.description}</p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Previsualización en Vivo de Componentes */}
          <div className="p-5 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-3">
            <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              {t('settings:previsualizacion_de_componentes_con_el_tema_activo')}
            </p>
            <div className="flex flex-wrap items-center gap-3">
              <button
                type="button"
                className="px-5 py-2.5 rounded-xl font-bold text-xs text-white shadow-sm flex items-center gap-2 transition-all"
                style={{ backgroundColor: config.theme?.primaryColor || DEFAULT_THEME.primaryColor }}
              >
                <Check className="w-4 h-4" />
                {t('settings:boton_primario')}
              </button>
              <button
                type="button"
                className="px-5 py-2.5 rounded-xl font-bold text-xs border-2 transition-all bg-white"
                style={{
                  borderColor: config.theme?.primaryColor || DEFAULT_THEME.primaryColor,
                  color: config.theme?.primaryColor || DEFAULT_THEME.primaryColor,
                }}
              >
                {t('settings:boton_secundario')}
              </button>
              <span
                className="px-3 py-1.5 rounded-full text-xs font-bold"
                style={{
                  backgroundColor: config.theme?.primaryLight || DEFAULT_THEME.primaryLight,
                  color: config.theme?.primaryColor || DEFAULT_THEME.primaryColor
                }}
              >
                {t('settings:insignia_activa')}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* ──────────────────────────────────────────
          SUBTAB 5: MANTENIMIENTO
      ────────────────────────────────────────── */}
      {subTab === 'maintenance' && (
        <div className="bg-white rounded-3xl shadow-sm p-8 border border-slate-200/80 space-y-6">
          <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100">
            <Wrench className="w-5 h-5 text-slate-700" />
            <div>
              <h3 className="text-base font-bold text-slate-900 font-heading">{t('settings:herramientas_de_mantenimiento')}</h3>
              <p className="text-xs text-slate-500">{t('settings:optimizacion_de_catalogo_e_integridad_de_base')}</p>
            </div>
          </div>

          {/* Volver a pasar por la configuración inicial */}
          <div className="p-6 bg-slate-50 border border-slate-200 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h4 className="font-bold text-sm text-slate-900">{t('settings:reconfigurar_el_negocio')}</h4>
              <p className="text-xs text-slate-500 mt-1 max-w-xl">{t('settings:asistente_de_configuracion_desc')}</p>
            </div>
            <button
              type="button"
              onClick={openOnboarding}
              className="flex items-center justify-center gap-2 bg-white text-slate-700 border border-slate-300 px-6 py-2.5 rounded-xl font-bold hover:bg-slate-100 transition-all text-xs shadow-xs shrink-0"
            >
              <Sparkles className="w-4 h-4" />
              {t('settings:abrir_asistente')}
            </button>
          </div>

          {/* Limpieza de duplicados */}
          <div className="p-6 bg-slate-50 border border-slate-200 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h4 className="font-bold text-sm text-slate-900">{t('settings:limpieza_de_productos_duplicados')}</h4>
              <p className="text-xs text-slate-500 mt-1 max-w-xl">
                {t('settings:detecta_y_fusiona_automaticamente_productos_con_el')}
              </p>
            </div>
            <button
              onClick={onFindDuplicates}
              disabled={isSearchingDuplicates}
              className="flex items-center justify-center gap-2 bg-white text-slate-700 border border-slate-300 px-6 py-2.5 rounded-xl font-bold hover:bg-slate-100 transition-all text-xs shadow-xs shrink-0 disabled:opacity-50"
            >
              {isSearchingDuplicates ? t('settings:buscando') : t('settings:buscar_productos_repetidos')}
            </button>
          </div>

          {/* Copias de Seguridad (SQLite) */}
          <div className="p-6 bg-slate-50 border border-slate-200 rounded-2xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center shrink-0">
                  <Database className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-slate-900">{t('settings:copias_de_seguridad_del_sistema_sqlite')}</h4>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {t('settings:respaldos_automaticos_verificados_con_rotacion_seg')}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={fetchBackups}
                  disabled={isLoadingBackups}
                  className="p-2.5 bg-white border border-slate-200 text-slate-600 hover:text-slate-900 rounded-xl transition-all"
                  title={t('settings:actualizar_lista_de_respaldos')}
                >
                  <RefreshCw className={`w-4 h-4 ${isLoadingBackups ? 'animate-spin' : ''}`} />
                </button>
                <button
                  type="button"
                  onClick={handleCreateManualBackup}
                  disabled={isCreatingBackup}
                  className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-xl font-bold text-xs shadow-sm transition-all disabled:opacity-50"
                >
                  <ShieldCheck className="w-4 h-4" />
                  {isCreatingBackup ? t('settings:generando_copia') : t('settings:generar_respaldo_ahora')}
                </button>
              </div>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
              <div className="px-4 py-2.5 bg-slate-100/70 border-b border-slate-200 flex items-center justify-between text-xs font-bold text-slate-600 uppercase tracking-wider">
                <span>{t('settings:archivo_de_respaldo')}</span>
                <span>{t('settings:tamano_fecha')}</span>
              </div>

              <div className="divide-y divide-slate-100 max-h-56 overflow-y-auto">
                {backups.length === 0 ? (
                  <div className="p-6 text-center text-xs text-slate-400">
                    {isLoadingBackups ? t('settings:cargando_respaldos') : t('settings:no_hay_respaldos_generados_aun')}
                  </div>
                ) : (
                  backups.map((b) => (
                    <div key={b.name} className="px-4 py-2.5 flex items-center justify-between text-xs hover:bg-slate-50/60 transition-colors">
                      <div className="flex items-center gap-2 truncate">
                        <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
                        <span className="font-mono text-slate-800 font-medium truncate">{b.name}</span>
                      </div>
                      <div className="flex items-center gap-4 shrink-0 text-slate-500 text-xs">
                        <span className="font-bold text-slate-700 tabular-nums">{b.sizeKB}</span>
                        <span>{new Date(b.createdAt).toLocaleString(getLocale())}</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            <p className="text-xs text-slate-500 font-medium">
              💡 <em>{t('settings:el_sistema_genera_automaticamente_un_respaldo_inte')}</em>
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
