// ============================================
// ADMIN - Users and Roles Management
// ============================================

import React, { useState, useEffect } from 'react';
import { confirmDialog } from '../../shared/dialog';
import { authAPI } from '../../services/api';
import { User, UserRole } from '../../types';
import { Users, UserPlus, Shield, Edit2, Trash2, X, Lock, CheckCircle2 } from 'lucide-react';
import { RolePermissionsPanel } from './RolePermissionsPanel';
import { TabletsPanel } from './TabletsPanel';
import { toast } from '../../shared/toast';

import { t } from '../../i18n';
interface UsersAdminProps {
  currentUser?: any;
}

const ROLE_DEFINITIONS: Record<UserRole, { label: string; badge: string; desc: string }> = {
  ADMIN: {
    get label() { return t('admin:administrador'); },
    badge: 'bg-blue-100 text-blue-800 border-blue-200',
    get desc() { return t('admin:acceso_total_e_irrestricto_al_sistema_configuracio'); },
  },
  CASHIER: {
    get label() { return t('admin:cajero'); },
    badge: 'bg-emerald-100 text-emerald-800 border-emerald-200',
    get desc() { return t('admin:operacion_de_venta_cobro_de_cuentas_cierre'); },
  },
  WAITER: {
    get label() { return t('admin:mesero'); },
    badge: 'bg-amber-100 text-amber-800 border-amber-200',
    get desc() { return t('admin:atencion_en_salon_toma_agil_de_pedidos'); },
  }
};

export const UsersAdmin: React.FC<UsersAdminProps> = ({ currentUser }) => {
  const [users, setUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Form State
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<UserRole>('CASHIER');

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    setIsLoading(true);
    try {
      const data = await authAPI.getUsers();
      setUsers(data);
    } catch (err: any) {
      console.error('Error loading users:', err);
      setError(err.message || t('admin:error_al_cargar_usuarios'));
    } finally {
      setIsLoading(false);
    }
  };

  const openCreateModal = () => {
    setEditingUser(null);
    setName('');
    setUsername('');
    setPassword('');
    setRole('CASHIER');
    setError(null);
    setIsModalOpen(true);
  };

  const openEditModal = (user: User) => {
    setEditingUser(user);
    setName(user.name);
    setUsername(user.username);
    setPassword('');
    setRole(user.role);
    setError(null);
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    try {
      if (editingUser) {
        // Update user
        await authAPI.updateUser(editingUser.id, {
          name,
          role,
          ...(password ? { password } : {})
        });
        setSuccessMsg(t('admin:usuario_name_actualizado_con_exito', { name }));
      } else {
        // Create user
        if (!password || password.length < 8) {
          setError(t('admin:la_contrasena_debe_tener_al_menos_8'));
          return;
        }
        await authAPI.register(username.trim().toLowerCase(), password, name, role);
        setSuccessMsg(t('admin:usuario_name_creado_exitosamente', { name }));
      }

      setIsModalOpen(false);
      await loadUsers();
      setTimeout(() => setSuccessMsg(null), 4000);
    } catch (err: any) {
      setError(err.message || t('admin:error_al_procesar_la_solicitud'));
    }
  };

  const handleDelete = async (user: User) => {
    if (user.username === 'admin') {
      toast.warning(t('admin:no_es_posible_desactivar_al_usuario_administrador'));
      return;
    }

    if (currentUser?.username === user.username) {
      toast.warning(t('admin:no_puedes_desactivar_tu_propia_cuenta_en'));
      return;
    }

    if (!(await confirmDialog({ title: t('admin:desactivar_a_name', { name: user.name }), message: t('admin:username_no_podra_volver_a_iniciar_sesion', { username: user.username }), confirmLabel: t('admin:desactivar'), tone: 'danger' }))) {
      return;
    }

    try {
      await authAPI.deleteUser(user.id);
      toast.success(t('admin:usuario_name_desactivado', { name: user.name }));
      await loadUsers();
    } catch (err: any) {
      toast.error(err.message || 'Error al desactivar usuario');
    }
  };

  return (
    <div className="space-y-8">
      {/* Header and Call to Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200">
        <div>
          <h2 className="text-2xl font-black text-slate-900 tracking-tight font-heading flex items-center gap-2.5">
            <Users className="w-7 h-7 text-blue-600" />
            {t('admin:control_de_usuarios_y_roles')}
          </h2>
          <p className="text-sm text-slate-500 mt-1">
            {t('admin:define_quien_opera_la_terminal_y_delimita')}
          </p>
        </div>
        <button
          onClick={openCreateModal}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-5 py-3 rounded-2xl font-bold text-sm shadow-md hover:shadow-lg transition-all self-start sm:self-auto"
        >
          <UserPlus className="w-5 h-5" />
          {t('admin:nuevo_usuario')}
        </button>
      </div>

      {successMsg && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-2xl text-sm font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          {successMsg}
        </div>
      )}

      {/* Users Table */}
      <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <h3 className="font-bold text-slate-900 text-base">{t('admin:personal_registrado')}</h3>
          <span className="text-xs font-bold text-slate-500 bg-slate-100 px-3 py-1 rounded-full">
            {users.length} {users.length === 1 ? t('admin:usuario_activo') : t('admin:usuarios_activos')}
          </span>
        </div>

        {isLoading ? (
          <div className="p-12 text-center text-slate-400 font-medium">{t('admin:cargando_usuarios')}</div>
        ) : users.length === 0 ? (
          <div className="p-12 text-center text-slate-400 font-medium">{t('admin:no_hay_usuarios_registrados')}</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50/80 text-xs uppercase tracking-wider text-slate-500 font-bold border-b border-slate-100">
                  <th className="py-3.5 px-6">{t('admin:usuario')}</th>
                  <th className="py-3.5 px-6">{t('admin:nombre_completo')}</th>
                  <th className="py-3.5 px-6">{t('admin:rol_de_sistema')}</th>
                  <th className="py-3.5 px-6 text-right">{t('admin:acciones')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {users.map((u) => {
                  const roleMeta = ROLE_DEFINITIONS[u.role] || ROLE_DEFINITIONS.CASHIER;
                  const isCurrent = currentUser?.username === u.username;
                  return (
                    <tr key={u.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="py-4 px-6 font-mono font-bold text-slate-900 flex items-center gap-2">
                        <span className="w-8 h-8 rounded-full bg-slate-100 text-slate-700 flex items-center justify-center text-xs font-sans font-bold">
                          {u.name.charAt(0).toUpperCase()}
                        </span>
                        @{u.username}
                        {isCurrent && (
                          <span className="text-xs bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full font-sans font-bold">
                            {t('admin:tu')}
                          </span>
                        )}
                      </td>
                      <td className="py-4 px-6 font-medium text-slate-800">{u.name}</td>
                      <td className="py-4 px-6">
                        <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold border ${roleMeta.badge}`}>
                          <Shield className="w-3.5 h-3.5" />
                          {roleMeta.label}
                        </span>
                      </td>
                      <td className="py-4 px-6 text-right space-x-2">
                        <button
                          onClick={() => openEditModal(u)}
                          className="p-2 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all"
                          title={t('admin:editar_usuario')}
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        {u.username !== 'admin' && (
                          <button
                            onClick={() => handleDelete(u)}
                            className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-all"
                            title={t('admin:desactivar_usuario')}
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <RolePermissionsPanel />

      <TabletsPanel />

      {/* Modal Crear / Editar Usuario */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center z-[110] p-4">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden border border-slate-200">
            {/* Modal Header */}
            <div className="bg-slate-900 px-6 py-5 flex items-center justify-between text-white">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-600 rounded-xl text-white shadow-sm">
                  {editingUser ? <Edit2 className="w-5 h-5" /> : <UserPlus className="w-5 h-5" />}
                </div>
                <h3 className="text-lg font-bold font-heading">
                  {editingUser ? t('admin:editar_usuario_2') : t('admin:nuevo_usuario')}
                </h3>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {error && (
                <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-xl text-xs font-semibold">
                  {error}
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  {t('admin:nombre_completo')}
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder={t('admin:ej_laura_gomez')}
                  required
                  className="w-full px-4 py-2.5 border border-slate-300 rounded-xl bg-slate-50 text-sm font-medium focus:bg-white focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  {t('admin:nombre_de_usuario_login')}
                </label>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder={t('admin:ej_laurag')}
                  required
                  disabled={!!editingUser}
                  className="w-full px-4 py-2.5 border border-slate-300 rounded-xl bg-slate-50 text-sm font-mono font-medium focus:bg-white focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 disabled:opacity-60"
                />
                {editingUser && (
                  <p className="text-xs text-slate-400 mt-1">{t('admin:el_nombre_de_usuario_no_se_puede')}</p>
                )}
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  {editingUser ? t('admin:nueva_contrasena_dejar_en_blanco_para_no') : t('admin:contrasena_de_acceso')}
                </label>
                <div className="relative">
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder={t('admin:minimo_8_caracteres')}
                    required={!editingUser}
                    className="w-full px-4 py-2.5 pl-10 border border-slate-300 rounded-xl bg-slate-50 text-sm font-medium focus:bg-white focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20"
                  />
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  {t('admin:rol_y_nivel_de_acceso')}
                </label>
                <div className="space-y-2">
                  {(['ADMIN', 'CASHIER', 'WAITER'] as UserRole[]).map((rOption) => {
                    const rInfo = ROLE_DEFINITIONS[rOption];
                    const isSelected = role === rOption;
                    return (
                      <label
                        key={rOption}
                        className={`flex items-start gap-3 p-3 rounded-xl border-2 cursor-pointer transition-all ${
                          isSelected
                            ? 'border-blue-600 bg-blue-50/50 ring-2 ring-blue-600/10'
                            : 'border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <input
                          type="radio"
                          name="userRole"
                          value={rOption}
                          checked={isSelected}
                          onChange={() => setRole(rOption)}
                          className="mt-0.5 text-blue-600 focus:ring-blue-500"
                        />
                        <div>
                          <p className="text-xs font-bold text-slate-900">{rInfo.label}</p>
                          <p className="text-xs text-slate-500 leading-tight mt-0.5">{rInfo.desc}</p>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-5 py-2.5 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
                >
                  {t('admin:cancelar')}
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-sm transition-all"
                >
                  {editingUser ? t('admin:guardar_cambios') : t('admin:crear_usuario')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
