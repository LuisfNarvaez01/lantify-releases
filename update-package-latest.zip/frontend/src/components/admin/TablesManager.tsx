// ============================================
// ADMIN - Salón y mesas (un solo lugar)
// ============================================
// Antes las mesas se creaban en una pestaña y se acomodaban en otra. Aquí se
// decide si el negocio atiende en mesas, cómo se ven en la caja y, en el mismo
// plano, se crean, numeran, mueven, agrupan por zona y eliminan.

import { useState } from 'react';
import { Check, LayoutGrid, Store } from 'lucide-react';
import { Toggle } from '../common/Choice';
import { FloorPlan } from '../pos/FloorPlan';
import { TABLE_VIEW_MODES, saveTableViewMode, getTableViewMode, TableViewMode } from '../../shared/posSettings';
import { useBusiness, useBusinessStore } from '../../shared/business';
import { businessAPI } from '../../services/api';
import { errorMessage } from '../../services/apiErrors';
import { toast } from '../../shared/toast';
import { t } from '../../i18n';

export function TablesManager() {
  const { settings, usesTables } = useBusiness();
  const setSettings = useBusinessStore((s) => s.setSettings);
  const [mode, setMode] = useState<TableViewMode>(() => getTableViewMode());
  const [saving, setSaving] = useState(false);

  const toggleTables = async (value: boolean) => {
    setSaving(true);
    try {
      setSettings(await businessAPI.update({ usesTables: value }));
      toast.success(value ? t('admin:mesas_activadas') : t('admin:mesas_desactivadas'));
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-slate-900 font-heading">{t('admin:salon_y_mesas')}</h2>
        <p className="mt-1 text-sm text-slate-500">{t('admin:salon_y_mesas_desc')}</p>
      </div>

      <div className="bg-white rounded-3xl shadow-sm p-6 border border-slate-200/80">
        <Toggle
          id="salon-uses-tables"
          checked={usesTables}
          onChange={(v) => !saving && settings && toggleTables(v)}
          label={t('onboarding:atiendes_en_mesas')}
          description={t('onboarding:atiendes_en_mesas_desc')}
        />
      </div>

      {usesTables ? (
        <>
          <div className="bg-white rounded-3xl shadow-sm p-6 border border-slate-200/80 space-y-4">
            <div>
              <h3 className="text-base font-bold text-slate-900 font-heading flex items-center gap-2">
                <LayoutGrid className="w-5 h-5 text-blue-600" aria-hidden />
                {t('settings:modalidad_de_mesas_y_atencion')}
              </h3>
              <p className="text-xs text-slate-500 mt-1">{t('admin:modo_por_equipo')}</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {TABLE_VIEW_MODES.map((m) => {
                const selected = mode === m.id;
                return (
                  <button
                    key={m.id}
                    type="button"
                    aria-pressed={selected}
                    onClick={() => {
                      setMode(m.id);
                      saveTableViewMode(m.id);
                    }}
                    className={`p-4 rounded-2xl border-2 text-left transition-all ${
                      selected ? 'border-blue-600 bg-blue-50/50 ring-2 ring-blue-600/20' : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-extrabold text-sm text-slate-900">{m.label}</span>
                      {selected && <Check className="w-4 h-4 text-blue-600" aria-hidden />}
                    </div>
                    <p className="text-xs text-slate-500 leading-relaxed">{m.description}</p>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="space-y-3">
            <div>
              <h3 className="text-base font-bold text-slate-900 font-heading">{t('settings:editor_del_plano_de_salon')}</h3>
              <p className="text-xs text-slate-500 mt-1">{t('admin:plano_desc')}</p>
            </div>
            <FloorPlan editor />
          </div>
        </>
      ) : (
        <div className="flex items-start gap-3 rounded-3xl border border-slate-200 bg-slate-50 p-6 text-sm text-slate-700">
          <Store className="w-5 h-5 shrink-0 text-slate-500" aria-hidden />
          <p>{t('admin:sin_mesas_desc')}</p>
        </div>
      )}
    </div>
  );
}
