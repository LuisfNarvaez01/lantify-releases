// ============================================
// ADMIN - Mi página
// ============================================
// La página pública del negocio (lantifypos.dpdns.org/m/<dirección>): qué muestra
// (carta, pedidos en línea, reservas, registro, juego), su perfil, el juego con sus premios y quién
// responde por los datos de los clientes. Desde aquí se ve lo que llega: clientes
// registrados, premios entregados y los cumpleaños de la semana.

import { useEffect, useMemo, useState } from 'react';
import {
  Globe, UtensilsCrossed, CalendarDays, UserPlus, Gift, Plus, Trash2, Loader2, RefreshCw, MessageCircle, Cake, AlertTriangle, ShoppingBag, Award, Star,
  Palette, Search, Eye, EyeOff, Building2, BarChart2,
} from 'lucide-react';
import { pageAPI, PageState, PageConfigData, PagePrize, BirthdayRow, OrderPayment } from '../../services/api';
import { errorMessage } from '../../services/apiErrors';
import { toast } from '../../shared/toast';
import { useFeature, showPlanLock } from '../../shared/plan';
import { LockBadge } from '../common/PlanLocked';
import { PublicLink, ReservationSettingsPanel } from '../reservations/ReservationSettingsPanel';
import { PageDesignPanel } from './PageDesignPanel';
import { whatsappNumber } from './SuppliersPanel';
import { t, getLocale } from '../../i18n';
import { mediaSrc } from '../../shared/media';

const inputCls = 'w-full min-h-[42px] px-3 rounded-xl border border-slate-200 bg-white text-sm text-slate-900 focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20';
// Campos cortos (números): sin w-full, que le ganaría al ancho fijo
const shortCls = inputCls.replace('w-full ', '');
const labelCls = 'text-xs font-bold text-slate-600';
const card = 'rounded-3xl border border-slate-200 bg-white p-6 space-y-4';

type PageTab = 'design' | 'menu' | 'loyalty' | 'social' | 'orders' | 'profile' | 'activity';

const newPrize = (n: number): PagePrize => ({
  id: `premio-${Date.now().toString(36)}-${n}`,
  label: '',
  kind: 'PERCENT',
  value: 10,
  minPurchase: null,
  weight: 10,
  dailyLimit: 5,
  totalLimit: null,
  validDays: 7,
});

function Field({ label, value, onChange, placeholder, max = 160, type = 'text' }: { label: string; value: string | null; onChange: (v: string) => void; placeholder?: string; max?: number; type?: string }) {
  return (
    <label className="block">
      <span className={labelCls}>{label}</span>
      <input type={type} value={value || ''} maxLength={max} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} className={`${inputCls} mt-1`} />
    </label>
  );
}

function SectionToggle({ icon: Icon, title, desc, checked, onChange, locked, onLocked, extra }: {
  icon: typeof Globe; title: string; desc: string; checked: boolean; onChange: (v: boolean) => void; locked?: boolean; onLocked?: () => void; extra?: React.ReactNode;
}) {
  return (
    <div className={`flex items-start gap-4 rounded-2xl border p-4 ${checked && !locked ? 'border-blue-200 bg-blue-50/40' : 'border-slate-200'}`}>
      <span className={`w-10 h-10 shrink-0 rounded-xl flex items-center justify-center ${checked && !locked ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-500'}`}>
        <Icon className="w-5 h-5" aria-hidden />
      </span>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-black text-slate-900 flex items-center gap-2">{title} {locked && <LockBadge />}</p>
        <p className="text-xs text-slate-500 mt-0.5">{desc}</p>
        {extra}
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={checked && !locked}
        aria-label={title}
        onClick={() => (locked ? onLocked?.() : onChange(!checked))}
        className={`relative mt-1 w-12 h-7 shrink-0 rounded-full transition-colors ${checked && !locked ? 'bg-blue-600' : 'bg-slate-300'}`}
      >
        <span className={`absolute top-1 w-5 h-5 rounded-full bg-white shadow transition-all ${checked && !locked ? 'left-6' : 'left-1'}`} />
      </button>
    </div>
  );
}

export function PageModule() {
  const [activeTab, setActiveTab] = useState<PageTab>('design');
  const [state, setState] = useState<PageState | null>(null);
  const [draft, setDraft] = useState<(PageConfigData & { slug: string }) | null>(null);
  const [birthdays, setBirthdays] = useState<BirthdayRow[]>([]);
  const [saving, setSaving] = useState(false);
  const [bookingOpen, setBookingOpen] = useState(false);
  const [productSearch, setProductSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('ALL');

  const hasLoyalty = useFeature('loyalty');
  const hasReservations = useFeature('reservations');
  const hasOrders = useFeature('webstore');

  const draftOf = (s: PageState) => ({
    sections: s.sections,
    profile: s.profile,
    games: s.games,
    legal: s.legal,
    ordering: s.ordering,
    theme: s.theme,
    loyalty: s.loyalty || {
      enabled: true,
      minSpendPerStamp: 20000,
      spendPerGamePlay: 30000,
      stampsRequired: 10,
      rewardText: '1 Plato / Café / Postre Gratis en Caja',
    },
    social: s.social || {
      googleReviewUrl: null,
      instagram: null,
      tiktok: null,
      facebook: null,
      whatsapp: null,
    },
    hiddenProductIds: s.hiddenProductIds || [],
    slug: s.slug || s.suggestedSlug,
  });

  const load = async () => {
    try {
      const s = await pageAPI.get();
      setState(s);
      setDraft(draftOf(s));
    } catch (e) {
      toast.error(errorMessage(e));
    }
    pageAPI.birthdays().then(setBirthdays).catch(() => setBirthdays([]));
  };
  useEffect(() => {
    load();
  }, []);

  const totalWeight = useMemo(() => (draft ? draft.games.noPrizeWeight + draft.games.prizes.reduce((n, p) => n + p.weight, 0) : 0), [draft]);

  const catalogList = useMemo(() => state?.catalog || [], [state?.catalog]);
  const categories = useMemo(() => {
    const setCats = new Set<string>();
    catalogList.forEach((p) => setCats.add(p.categoryName || 'General'));
    return Array.from(setCats).sort();
  }, [catalogList]);

  const hiddenSet = useMemo(() => new Set(draft?.hiddenProductIds || []), [draft?.hiddenProductIds]);

  const filteredCatalog = useMemo(() => {
    return catalogList.filter((p) => {
      if (categoryFilter !== 'ALL' && p.categoryName !== categoryFilter) return false;
      if (productSearch.trim()) {
        const q = productSearch.toLowerCase().trim();
        return p.name.toLowerCase().includes(q) || (p.categoryName && p.categoryName.toLowerCase().includes(q));
      }
      return true;
    });
  }, [catalogList, categoryFilter, productSearch]);

  if (!state || !draft) return <div className="flex justify-center py-20"><Loader2 className="w-6 h-6 animate-spin text-slate-400" aria-hidden /></div>;

  const set = <K extends keyof PageConfigData>(k: K, v: PageConfigData[K]) => setDraft({ ...draft, [k]: v });
  const setProfile = (k: keyof PageConfigData['profile'], v: string) => set('profile', { ...draft.profile, [k]: v || null });
  const setLegal = (k: keyof PageConfigData['legal'], v: string) => set('legal', { ...draft.legal, [k]: v || null });
  const setPrize = (i: number, patch: Partial<PagePrize>) => set('games', { ...draft.games, prizes: draft.games.prizes.map((p, j) => (j === i ? { ...p, ...patch } : p)) });
  const pct = (w: number) => (totalWeight > 0 ? Math.round((w / totalWeight) * 100) : 0);
  const setOrdering = (patch: Partial<PageConfigData['ordering']>) => set('ordering', { ...draft.ordering, ...patch });
  const setLoyalty = (patch: Partial<PageConfigData['loyalty']>) => set('loyalty', { ...draft.loyalty, ...patch });
  const setSocial = (k: keyof PageConfigData['social'], v: string) => set('social', { ...draft.social, [k]: v || null });
  const togglePayment = (p: OrderPayment) => {
    const has = draft.ordering.payments.includes(p);
    const payments = has ? draft.ordering.payments.filter((x) => x !== p) : [...draft.ordering.payments, p];
    if (payments.length) setOrdering({ payments });
  };

  const toggleProductVisibility = (productId: string) => {
    const setIds = new Set(draft.hiddenProductIds || []);
    if (setIds.has(productId)) {
      setIds.delete(productId);
    } else {
      setIds.add(productId);
    }
    setDraft({ ...draft, hiddenProductIds: Array.from(setIds) });
  };

  const showAllProducts = () => {
    setDraft({ ...draft, hiddenProductIds: [] });
  };

  const hideAllFilteredProducts = (filteredIds: string[]) => {
    const setIds = new Set(draft.hiddenProductIds || []);
    filteredIds.forEach((id) => setIds.add(id));
    setDraft({ ...draft, hiddenProductIds: Array.from(setIds) });
  };

  const save = async () => {
    setSaving(true);
    try {
      const saved = await pageAPI.save(draft);
      setState(saved);
      setDraft(draftOf(saved));
      if (saved.publish && !saved.publish.ok) toast.warning(t(`reservations:publicar_${saved.publish.code || 'error'}`, { defaultValue: t('reservations:publicar_error') }), t('reservations:guardado_local'));
      else toast.success(t('page:publicada'));
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setSaving(false);
    }
  };

  const publishNow = async () => {
    try {
      const r = await pageAPI.publish();
      setState({ ...state, ...r });
      if (r.publish && !r.publish.ok) toast.warning(t(`reservations:publicar_${r.publish.code || 'error'}`, { defaultValue: t('reservations:publicar_error') }));
      else toast.success(t('page:publicada'));
    } catch (e) {
      toast.error(errorMessage(e));
    }
  };

  const greet = (b: BirthdayRow) => t('page:wa_cumple', { name: b.name.split(' ')[0], favorite: b.favorite ? t('page:wa_cumple_favorito', { favorite: b.favorite }) : '' });
  const dateLabel = (iso: string) => new Date(iso).toLocaleDateString(getLocale(), { day: 'numeric', month: 'short' });

  return (
    <div className="space-y-6 pb-24">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 font-heading">{t('page:titulo')}</h2>
          <p className="mt-1 text-sm text-slate-500 max-w-2xl">{t('page:bajada')}</p>
        </div>
        {state.url && (
          <button type="button" onClick={publishNow} className="inline-flex items-center gap-2 min-h-[44px] px-4 rounded-xl border border-slate-200 bg-white text-sm font-bold text-slate-700 hover:bg-slate-50">
            <RefreshCw className="w-4 h-4" aria-hidden /> {t('page:publicar_ahora')}
          </button>
        )}
      </div>

      {!state.linked && (
        <p className="flex items-start gap-2 rounded-2xl bg-amber-50 border border-amber-200 px-4 py-3 text-sm text-amber-900">
          <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" aria-hidden /> {t('reservations:publicar_NOT_LINKED')}
        </p>
      )}

      {state.url && state.publishedAt ? (
        <div className="space-y-1">
          <PublicLink url={state.url} />
          <p className="text-xs text-slate-500 px-1">{t('page:estado_publicada', { when: new Date(state.publishedAt).toLocaleString(getLocale(), { dateStyle: 'medium', timeStyle: 'short' }) })}</p>
        </div>
      ) : (
        <p className="rounded-2xl bg-slate-50 border border-slate-200 px-4 py-3 text-sm text-slate-600">{t('page:aun_no_publicada')}</p>
      )}

      {/* Subpestañas del Módulo Mi Página */}
      <div className="flex flex-wrap gap-2 border-b border-slate-200 pb-3">
        {[
          { id: 'design' as PageTab, label: 'Diseño & Plantilla', icon: Palette },
          { id: 'menu' as PageTab, label: 'Carta & Visibilidad', icon: UtensilsCrossed, badge: `${catalogList.length - hiddenSet.size}/${catalogList.length}` },
          { id: 'loyalty' as PageTab, label: 'Fidelidad & Sellos', icon: Award, locked: !hasLoyalty, lockFeature: 'loyalty' as const },
          { id: 'social' as PageTab, label: 'Redes & Google Reviews', icon: Star },
          { id: 'orders' as PageTab, label: 'Pedidos en Línea', icon: ShoppingBag, locked: !hasOrders, lockFeature: 'webstore' as const },
          { id: 'profile' as PageTab, label: 'Perfil & Datos Legales', icon: Building2 },
          { id: 'activity' as PageTab, label: 'Actividad & Cumpleaños', icon: BarChart2, badge: birthdays.length > 0 ? birthdays.length : undefined },
        ].map((tab) => {
          const Icon = tab.icon;
          const active = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => {
                if (tab.locked) {
                  showPlanLock(tab.lockFeature);
                  return;
                }
                setActiveTab(tab.id);
              }}
              className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition-all ${
                active
                  ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/25 ring-2 ring-blue-600/20'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <Icon className={`w-4 h-4 ${active ? 'text-white' : 'text-slate-400'}`} />
              <span>{tab.label}</span>
              {tab.locked && <LockBadge />}
              {tab.badge && (
                <span className={`px-2 py-0.5 rounded-full text-[11px] font-black ${
                  active ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'
                }`}>
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Pestaña: Diseño & Plantilla */}
      {activeTab === 'design' && (
        <PageDesignPanel
          state={state}
          theme={draft.theme}
          tagline={draft.profile.tagline}
          onTheme={(theme) => set('theme', theme)}
          onTagline={(v) => setProfile('tagline', v)}
        />
      )}

      {/* Pestaña: Carta & Visibilidad de Productos */}
      {activeTab === 'menu' && (
        <div className="space-y-6">
          <section className={card}>
            <h3 className="text-base font-black text-slate-900">Secciones Activas de la Carta</h3>
            <div className="grid sm:grid-cols-3 gap-4">
              <SectionToggle
                icon={UtensilsCrossed}
                title={t('page:sec_carta')}
                desc={t('page:sec_carta_desc', { count: state.menuSummary.items })}
                checked={draft.sections.menu}
                onChange={(v) => set('sections', { ...draft.sections, menu: v })}
              />
              <SectionToggle
                icon={ShoppingBag}
                title={t('page:sec_pedidos')}
                desc={t('page:sec_pedidos_desc')}
                checked={draft.sections.orders}
                locked={!hasOrders}
                onLocked={() => showPlanLock('webstore')}
                onChange={(v) => set('sections', { ...draft.sections, orders: v, menu: v ? true : draft.sections.menu })}
              />
              <SectionToggle
                icon={CalendarDays}
                title={t('page:sec_reservas')}
                desc={draft.sections.booking ? t('page:sec_reservas_on') : t('page:sec_reservas_off')}
                checked={draft.sections.booking}
                locked={!hasReservations}
                onLocked={() => showPlanLock('reservations')}
                onChange={() => setBookingOpen(true)}
                extra={hasReservations && (
                  <button type="button" onClick={() => setBookingOpen(true)} className="mt-2 text-xs font-bold text-blue-700 hover:underline">{t('page:configurar_reservas')}</button>
                )}
              />
            </div>
          </section>

          <section className={card}>
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-black text-slate-900">Visibilidad de Productos en la Web</h3>
                <p className="text-xs text-slate-500">
                  Selecciona qué productos se muestran en el menú público y en los pedidos web. Los productos ocultos siguen activos en tu POS físico.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={showAllProducts}
                  className="px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 hover:bg-slate-50"
                >
                  Mostrar Todos ({catalogList.length})
                </button>
                <button
                  type="button"
                  onClick={() => hideAllFilteredProducts(filteredCatalog.map((p) => p.id))}
                  className="px-3 py-1.5 rounded-xl border border-rose-200 bg-rose-50 text-xs font-bold text-rose-700 hover:bg-rose-100"
                >
                  Ocultar Filtrados ({filteredCatalog.length})
                </button>
              </div>
            </div>

            {/* Barra de Búsqueda y Filtro de Categoría */}
            <div className="flex flex-wrap gap-3 pt-2">
              <div className="relative flex-1 min-w-[220px]">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                <input
                  type="text"
                  placeholder="Buscar producto por nombre o categoría..."
                  value={productSearch}
                  onChange={(e) => setProductSearch(e.target.value)}
                  className={`${inputCls} pl-9`}
                />
              </div>
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                aria-label="Filtrar por categoría"
                className="min-h-[42px] px-3 rounded-xl border border-slate-200 bg-white text-sm text-slate-800 font-bold focus:outline-none focus:border-blue-600"
              >
                <option value="ALL">Todas las Categorías ({categories.length})</option>
                {categories.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>

            {/* Resumen de Conteo */}
            <div className="flex items-center gap-4 text-xs font-bold text-slate-500 px-1">
              <span className="text-emerald-700">✓ {catalogList.length - hiddenSet.size} visibles en la web</span>
              <span className="text-rose-600">✕ {hiddenSet.size} ocultos de la web</span>
              {productSearch && <span>({filteredCatalog.length} coincidencias)</span>}
            </div>

            {/* Lista de Productos */}
            <div className="border border-slate-200 rounded-2xl overflow-hidden divide-y divide-slate-100 max-h-[500px] overflow-y-auto">
              {filteredCatalog.length === 0 ? (
                <div className="p-8 text-center text-sm text-slate-400">
                  No se encontraron productos que coincidan con la búsqueda.
                </div>
              ) : (
                filteredCatalog.map((p) => {
                  const isVisible = !hiddenSet.has(p.id);
                  return (
                    <div
                      key={p.id}
                      className={`flex items-center justify-between gap-4 p-3.5 transition-colors ${
                        isVisible ? 'bg-white hover:bg-slate-50/80' : 'bg-slate-50/80 opacity-75'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        {p.imageUrl ? (
                          <img src={mediaSrc(p.imageUrl)} alt={p.name} className="w-11 h-11 rounded-xl object-cover border border-slate-200 shrink-0" />
                        ) : (
                          <div className="w-11 h-11 rounded-xl bg-slate-100 text-slate-400 flex items-center justify-center shrink-0">
                            <UtensilsCrossed className="w-5 h-5" />
                          </div>
                        )}
                        <div className="min-w-0">
                          <p className="text-sm font-black text-slate-900 truncate">{p.name}</p>
                          <div className="flex items-center gap-2 mt-0.5">
                            <span className="text-xs text-slate-500">{p.categoryName}</span>
                            <span className="text-xs font-black text-slate-700">${Number(p.price || 0).toLocaleString()}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 shrink-0">
                        <span className={`px-2.5 py-1 rounded-full text-xs font-black inline-flex items-center gap-1 ${
                          isVisible
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-rose-50 text-rose-700 border border-rose-200'
                        }`}>
                          {isVisible ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                          {isVisible ? 'Visible en Web' : 'Oculto en Web'}
                        </span>
                        <button
                          type="button"
                          onClick={() => toggleProductVisibility(p.id)}
                          className={`min-h-[36px] px-3 rounded-xl text-xs font-black transition-all ${
                            isVisible
                              ? 'border border-slate-200 text-slate-700 hover:border-rose-300 hover:bg-rose-50 hover:text-rose-700'
                              : 'bg-blue-600 text-white shadow-sm hover:bg-blue-700'
                          }`}
                        >
                          {isVisible ? 'Ocultar' : 'Hacer Visible'}
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </section>
        </div>
      )}

      {/* Pestaña: Fidelidad & Sellos */}
      {activeTab === 'loyalty' && (
        <div className="grid gap-6 xl:grid-cols-2">
          {/* Qué ve el cliente en la página: sin esto, Únete y Juega no se publican */}
          <section className={`${card} xl:col-span-2`}>
            <h3 className="text-base font-black text-slate-900">Secciones en tu página</h3>
            <div className="grid sm:grid-cols-2 gap-4">
              <SectionToggle
                icon={UserPlus}
                title={t('page:sec_registro')}
                desc={t('page:sec_registro_desc')}
                checked={draft.sections.signup}
                locked={!hasLoyalty}
                onLocked={() => showPlanLock('loyalty')}
                onChange={(v) => set('sections', { ...draft.sections, signup: v, games: v ? draft.sections.games : false })}
              />
              <SectionToggle
                icon={Gift}
                title={t('page:sec_juego')}
                desc={t('page:sec_juego_desc')}
                checked={draft.sections.games}
                locked={!hasLoyalty}
                onLocked={() => showPlanLock('loyalty')}
                onChange={(v) => set('sections', { ...draft.sections, games: v, signup: v ? true : draft.sections.signup })}
              />
            </div>
          </section>

          <section className={card}>
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 rounded-xl bg-amber-100 text-amber-700">
                  <Award className="w-5 h-5" aria-hidden />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">Tarjeta de Fidelidad (Sellos por Compra)</h3>
                  <p className="text-xs text-slate-500">Sellos automáticos en tickets y reclamo dinámico por código QR</p>
                </div>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={draft.loyalty?.enabled ?? true}
                onClick={() => setLoyalty({ enabled: !(draft.loyalty?.enabled ?? true) })}
                className={`relative w-12 h-7 shrink-0 rounded-full transition-colors ${
                  (draft.loyalty?.enabled ?? true) ? 'bg-amber-500' : 'bg-slate-300'
                }`}
              >
                <span
                  className={`absolute top-1 w-5 h-5 rounded-full bg-white shadow transition-all ${
                    (draft.loyalty?.enabled ?? true) ? 'left-6' : 'left-1'
                  }`}
                />
              </button>
            </div>

            {(draft.loyalty?.enabled ?? true) && (
              <div className="space-y-4 pt-2">
                <div className="rounded-2xl bg-amber-50/80 border border-amber-200/70 p-3.5 text-xs text-amber-900 leading-relaxed">
                  💡 <b>¿Cómo funciona?</b> Al cobrar una venta en el POS que supere el <b>Monto mínimo por sello</b>, el sistema imprime automáticamente un código QR de reclamo al pie del ticket y muestra el QR en pantalla. El cliente lo escanea desde su móvil y ve sus sellos sumarse al instante.
                </div>

                <div className="grid sm:grid-cols-2 gap-3">
                  <label className="block">
                    <span className={labelCls}>Monto mínimo de compra por cada sello (COP)</span>
                    <span className="text-[11px] block text-slate-400 mb-1">Ej. $20.000 da 1 sello, $40.000 da 2 sellos</span>
                    <input
                      type="number"
                      min={1000}
                      step={1000}
                      value={draft.loyalty?.minSpendPerStamp ?? 20000}
                      onChange={(e) => setLoyalty({ minSpendPerStamp: Math.max(1000, Number(e.target.value) || 20000) })}
                      className={inputCls}
                    />
                  </label>

                  <label className="block">
                    <span className={labelCls}>Monto de compra para 1 jugada en la ruleta/juegos (COP)</span>
                    <span className="text-[11px] block text-slate-400 mb-1">Permite tiradas extra acumuladas</span>
                    <input
                      type="number"
                      min={1000}
                      step={1000}
                      value={draft.loyalty?.spendPerGamePlay ?? 30000}
                      onChange={(e) => setLoyalty({ spendPerGamePlay: Math.max(1000, Number(e.target.value) || 30000) })}
                      className={inputCls}
                    />
                  </label>
                </div>

                <div className="grid sm:grid-cols-2 gap-3">
                  <label className="block">
                    <span className={labelCls}>Sellos para completar la tarjeta</span>
                    <span className="text-[11px] block text-slate-400 mb-1">Meta estándar recomendada: 10</span>
                    <input
                      type="number"
                      min={3}
                      max={20}
                      value={draft.loyalty?.stampsRequired ?? 10}
                      onChange={(e) => setLoyalty({ stampsRequired: Math.min(20, Math.max(3, Number(e.target.value) || 10)) })}
                      className={inputCls}
                    />
                  </label>

                  <label className="block">
                    <span className={labelCls}>Premio al completar la tarjeta</span>
                    <span className="text-[11px] block text-slate-400 mb-1">Lo que el cliente reclama gratis</span>
                    <input
                      type="text"
                      maxLength={100}
                      placeholder="Ej. 1 Hamburguesa Especial gratis"
                      value={draft.loyalty?.rewardText ?? ''}
                      onChange={(e) => setLoyalty({ rewardText: e.target.value })}
                      className={inputCls}
                    />
                  </label>
                </div>
              </div>
            )}
          </section>

          {/* Juegos & Premios Ruleta */}
          <section className={card}>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-black text-slate-900">{t('page:juego_titulo')}</h3>
                <p className="text-xs text-slate-500">Ruleta de la suerte, raspa y gana o trivia interactiva</p>
              </div>
              <div className="flex gap-1 rounded-xl border border-slate-200 p-1" role="radiogroup" aria-label={t('page:tipo_juego')}>
                {(['wheel', 'scratch', 'trivia'] as const).map((k) => (
                  <button key={k} type="button" role="radio" aria-checked={draft.games.type === k} onClick={() => set('games', { ...draft.games, type: k })}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold ${draft.games.type === k ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'}`}>
                    {t(`page:juego_${k}`)}
                  </button>
                ))}
              </div>
            </div>
            <Field label={t('page:titulo_juego')} value={draft.games.title} max={60} onChange={(v) => set('games', { ...draft.games, title: v })} />
            <label className="flex items-center gap-3 text-sm text-slate-700">
              <span className="flex-1">{t('page:sin_premio')}</span>
              <input type="number" min={0} max={1000} value={draft.games.noPrizeWeight} onChange={(e) => set('games', { ...draft.games, noPrizeWeight: Math.max(0, Number(e.target.value) || 0) })} className={`${shortCls} w-24 shrink-0 text-right`} />
              <span className="w-24 text-xs text-slate-500 tabular-nums">{t('page:pct_jugadas', { pct: pct(draft.games.noPrizeWeight) })}</span>
            </label>
            {draft.games.type === 'wheel' && (
              <label className="flex items-center gap-3 text-sm text-slate-700">
                <span className="flex-1">{t('page:casillas_sigue')}<span className="block text-xs text-slate-500">{t('page:casillas_sigue_desc')}</span></span>
                <input type="number" min={0} max={12} value={draft.games.tryAgainSlots} onChange={(e) => set('games', { ...draft.games, tryAgainSlots: Math.min(12, Math.max(0, Number(e.target.value) || 0)) })} className={`${shortCls} w-24 shrink-0 text-right`} />
                <span className="w-24" />
              </label>
            )}

            <ul className="space-y-3">
              {draft.games.prizes.map((p, i) => (
                <li key={p.id} className="rounded-2xl border border-slate-200 p-4 space-y-3">
                  <div className="flex gap-2">
                    <input value={p.label} maxLength={80} placeholder={t('page:premio_ej')} aria-label={t('page:premio')} onChange={(e) => setPrize(i, { label: e.target.value })} className={`${inputCls} flex-1`} />
                    <button type="button" onClick={() => set('games', { ...draft.games, prizes: draft.games.prizes.filter((_, j) => j !== i) })} className="w-10 shrink-0 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 flex items-center justify-center" aria-label={t('page:quitar_premio')}>
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    <label className="block"><span className={labelCls}>{t('page:descuento')}</span>
                      <span className="mt-1 flex gap-1">
                        <select value={p.kind} onChange={(e) => setPrize(i, { kind: e.target.value as PagePrize['kind'] })} className={`${shortCls} w-16 shrink-0 px-1`}>
                          <option value="PERCENT">%</option><option value="AMOUNT">$</option>
                        </select>
                        <input type="number" min={1} value={p.value} onChange={(e) => setPrize(i, { value: Number(e.target.value) || 0 })} className={inputCls} />
                      </span>
                    </label>
                    <label className="block"><span className={labelCls}>{t('page:compra_minima')}</span>
                      <input type="number" min={0} value={p.minPurchase ?? ''} placeholder="—" onChange={(e) => setPrize(i, { minPurchase: Number(e.target.value) || null })} className={`${inputCls} mt-1`} /></label>
                    <label className="block"><span className={labelCls}>{t('page:max_dia')}</span>
                      <input type="number" min={1} value={p.dailyLimit ?? ''} placeholder="∞" onChange={(e) => setPrize(i, { dailyLimit: Number(e.target.value) || null })} className={`${inputCls} mt-1`} /></label>
                    <label className="block"><span className={labelCls}>{t('page:vigencia')}</span>
                      <input type="number" min={1} max={90} value={p.validDays} onChange={(e) => setPrize(i, { validDays: Math.max(1, Number(e.target.value) || 1) })} className={`${inputCls} mt-1`} /></label>
                  </div>
                  <label className="flex items-center gap-3 text-xs text-slate-600">
                    <span className="flex-1">{t('page:peso')}</span>
                    <input type="number" min={1} max={1000} value={p.weight} onChange={(e) => setPrize(i, { weight: Math.max(1, Number(e.target.value) || 1) })} className={`${shortCls} w-24 shrink-0 text-right`} />
                    <span className="w-24 tabular-nums font-bold text-slate-700">{t('page:pct_jugadas', { pct: pct(p.weight) })}</span>
                  </label>
                </li>
              ))}
            </ul>
            {draft.games.prizes.length < 12 && (
              <button type="button" onClick={() => set('games', { ...draft.games, prizes: [...draft.games.prizes, newPrize(draft.games.prizes.length)] })}
                className="w-full inline-flex items-center justify-center gap-2 min-h-[44px] rounded-xl border-2 border-dashed border-slate-300 text-sm font-bold text-slate-600 hover:border-blue-400 hover:text-blue-700">
                <Plus className="w-4 h-4" aria-hidden /> {t('page:agregar_premio')}
              </button>
            )}
          </section>
        </div>
      )}

      {/* Pestaña: Redes & Google Reviews */}
      {activeTab === 'social' && (
        <section className={card}>
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-xl bg-indigo-100 text-indigo-700">
              <Star className="w-5 h-5 fill-indigo-600 text-indigo-600" aria-hidden />
            </div>
            <div>
              <h3 className="text-base font-black text-slate-900">Reseñas de Google & Redes Sociales</h3>
              <p className="text-xs text-slate-500">Se mostrarán en el menú lateral y pie de página de tu web</p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="rounded-2xl bg-amber-50 border border-amber-200/80 p-4 space-y-2">
              <div className="flex items-center gap-2 text-amber-900 font-bold text-sm">
                <Star className="w-4 h-4 fill-amber-500 text-amber-500" />
                Botón "Califícanos en Google ⭐⭐⭐⭐⭐" (SEO Local)
              </div>
              <p className="text-xs text-amber-800 leading-relaxed">
                Pega el enlace de opiniones de Google Maps / Google My Business (ej. <code>https://g.page/r/.../review</code> o <code>https://maps.app.goo.gl/...</code>). Se destacará como una tarjeta dorada en el menú lateral de tu web para impulsar tu posicionamiento local.
              </p>
              <input
                type="url"
                placeholder="https://g.page/r/.../review o https://maps.app.goo.gl/..."
                value={draft.social?.googleReviewUrl || ''}
                onChange={(e) => setSocial('googleReviewUrl', e.target.value)}
                className={`${inputCls} mt-1`}
              />
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <Field
                label="Instagram (@usuario o URL)"
                value={draft.social?.instagram || draft.profile.instagram}
                placeholder="@mirestaurante o https://instagram.com/..."
                onChange={(v) => {
                  setSocial('instagram', v);
                  setProfile('instagram', v);
                }}
              />
              <Field
                label="TikTok (@usuario o URL)"
                value={draft.social?.tiktok}
                placeholder="@mirestaurante o https://tiktok.com/@..."
                onChange={(v) => setSocial('tiktok', v)}
              />
              <Field
                label="Facebook (URL de página)"
                value={draft.social?.facebook}
                placeholder="https://facebook.com/mirestaurante"
                onChange={(v) => setSocial('facebook', v)}
              />
              <Field
                label="WhatsApp de Atención"
                value={draft.social?.whatsapp || draft.profile.whatsapp}
                placeholder="+57 300 000 0000"
                onChange={(v) => {
                  setSocial('whatsapp', v);
                  setProfile('whatsapp', v);
                }}
              />
            </div>
          </div>
        </section>
      )}

      {/* Pestaña: Pedidos en Línea */}
      {activeTab === 'orders' && (
        <section className={card}>
          <h3 className="text-base font-black text-slate-900">{t('page:pedidos_titulo')}</h3>
          <p className="text-xs text-slate-500">{t('page:pedidos_desc')}</p>
          <div className="flex flex-wrap gap-2">
            {(['delivery', 'pickup'] as const).map((k) => (
              <label key={k} className={`inline-flex items-center gap-2 min-h-[40px] px-3 rounded-xl border text-sm font-bold cursor-pointer ${draft.ordering[k] ? 'border-blue-300 bg-blue-50 text-blue-800' : 'border-slate-200 text-slate-600'}`}>
                <input type="checkbox" checked={draft.ordering[k]} onChange={(e) => {
                  const next = { ...draft.ordering, [k]: e.target.checked };
                  if (next.delivery || next.pickup) setOrdering({ [k]: e.target.checked });
                }} />
                {t(`page:pedido_${k}`)}
              </label>
            ))}
          </div>
          <div className="grid sm:grid-cols-2 gap-3">
            {draft.ordering.delivery && (
              <label className="block"><span className={labelCls}>{t('page:valor_domicilio')}</span>
                <input type="number" min={0} step={500} value={draft.ordering.deliveryFee} onChange={(e) => setOrdering({ deliveryFee: Math.max(0, Number(e.target.value) || 0) })} className={`${inputCls} mt-1`} /></label>
            )}
            <label className="block"><span className={labelCls}>{t('page:pedido_minimo')}</span>
              <input type="number" min={0} step={1000} value={draft.ordering.minOrder} onChange={(e) => setOrdering({ minOrder: Math.max(0, Number(e.target.value) || 0) })} className={`${inputCls} mt-1`} /></label>
          </div>
          <div>
            <span className={labelCls}>{t('page:medios_pago')}</span>
            <div className="mt-1 flex flex-wrap gap-2">
              {(['CASH', 'NEQUI', 'DAVIPLATA', 'CARD', 'TRANSFER'] as OrderPayment[]).map((p) => (
                <button key={p} type="button" aria-pressed={draft.ordering.payments.includes(p)} onClick={() => togglePayment(p)}
                  className={`min-h-[36px] px-3 rounded-xl border text-xs font-bold ${draft.ordering.payments.includes(p) ? 'border-blue-600 bg-blue-600 text-white' : 'border-slate-200 text-slate-600 hover:bg-slate-50'}`}>
                  {t(`page:pago_${p}`)}
                </button>
              ))}
            </div>
          </div>
          <Field label={t('page:tiempo_estimado')} value={draft.ordering.eta} max={40} placeholder={t('page:tiempo_estimado_ej')} onChange={(v) => setOrdering({ eta: v || null })} />
          <Field label={t('page:aviso_pedidos')} value={draft.ordering.notice} max={240} placeholder={t('page:aviso_pedidos_ej')} onChange={(v) => setOrdering({ notice: v || null })} />
          <p className="text-xs text-slate-500">{t('page:pedidos_fotos')}</p>
        </section>
      )}

      {/* Pestaña: Perfil & Datos Legales */}
      {activeTab === 'profile' && (
        <div className="grid gap-6 xl:grid-cols-2">
          <section className={card}>
            <h3 className="text-base font-black text-slate-900">{t('page:perfil')}</h3>
            <label className="block">
              <span className={labelCls}>{t('reservations:direccion')}</span>
              <span className="mt-1 flex items-center rounded-xl border border-slate-200 overflow-hidden focus-within:border-blue-600">
                <span className="px-3 text-xs text-slate-500 bg-slate-50 self-stretch flex items-center">lantifypos.dpdns.org/m/</span>
                <input value={draft.slug} maxLength={40} onChange={(e) => setDraft({ ...draft, slug: e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, '-') })} className="flex-1 min-h-[42px] px-2 text-sm font-bold outline-none" />
              </span>
            </label>
            <Field label={t('page:frase')} value={draft.profile.tagline} max={140} placeholder={t('page:frase_ej')} onChange={(v) => setProfile('tagline', v)} />
            <div className="grid sm:grid-cols-2 gap-3">
              <Field label={t('page:direccion_local')} value={draft.profile.address} onChange={(v) => setProfile('address', v)} />
              <Field label={t('page:ciudad')} value={draft.profile.city} max={60} onChange={(v) => setProfile('city', v)} />
              <Field label={t('page:whatsapp')} value={draft.profile.whatsapp} max={20} placeholder="+57 300 000 0000" onChange={(v) => setProfile('whatsapp', v)} />
              <Field label={t('page:instagram')} value={draft.profile.instagram} max={40} placeholder="@mirestaurante" onChange={(v) => setProfile('instagram', v)} />
            </div>
            <Field label={t('page:horario')} value={draft.profile.hours} max={200} placeholder={t('page:horario_ej')} onChange={(v) => setProfile('hours', v)} />
          </section>

          <section className={card}>
            <h3 className="text-base font-black text-slate-900">{t('page:datos_titulo')}</h3>
            <p className="text-xs text-slate-500">{t('page:datos_desc')}</p>
            <div className="grid sm:grid-cols-2 gap-3">
              <Field label={t('page:razon_social')} value={draft.legal.owner} onChange={(v) => setLegal('owner', v)} />
              <Field label="NIT" value={draft.legal.nit} max={20} onChange={(v) => setLegal('nit', v)} />
            </div>
            <Field label={t('page:correo_datos')} type="email" value={draft.legal.email} max={120} placeholder="datos@minegocio.co" onChange={(v) => setLegal('email', v)} />
          </section>
        </div>
      )}

      {/* Pestaña: Actividad & Cumpleaños */}
      {activeTab === 'activity' && (
        <div className="grid gap-6 xl:grid-cols-2">
          <section className={card}>
            <h3 className="text-base font-black text-slate-900">{t('page:actividad')}</h3>
            <dl className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                ['members', state.stats.members],
                ['marketing', state.stats.marketing],
                ['prizes_awarded', state.stats.prizesAwarded],
                ['prizes_redeemed', state.stats.prizesRedeemed],
              ].map(([k, v]) => (
                <div key={k} className="rounded-2xl bg-slate-50 border border-slate-200 p-3">
                  <dt className="text-[11px] font-bold text-slate-500">{t(`page:stat_${k}`)}</dt>
                  <dd className="text-2xl font-black text-slate-900 tabular-nums">{v}</dd>
                </div>
              ))}
            </dl>
            {state.activity.members.length === 0 && state.activity.prizes.length === 0 ? (
              <p className="text-sm text-slate-500">{t('page:sin_actividad')}</p>
            ) : (
              <ul className="divide-y divide-slate-100 text-sm">
                {state.activity.prizes.map((p) => (
                  <li key={p.code} className="flex items-center justify-between gap-3 py-2">
                    <span className="min-w-0"><Gift className="inline w-4 h-4 mr-1.5 text-violet-600" aria-hidden />{p.customer || '—'} · <span className="text-slate-500">{(p.description || '').replace(/^Premio de la página: /, '')}</span></span>
                    <span className={`shrink-0 text-xs font-bold ${p.redeemed ? 'text-emerald-700' : 'text-slate-500'}`}>{p.redeemed ? t('page:canjeado') : p.code}</span>
                  </li>
                ))}
                {state.activity.members.map((m) => (
                  <li key={m.id} className="flex items-center justify-between gap-3 py-2">
                    <span className="min-w-0"><UserPlus className="inline w-4 h-4 mr-1.5 text-blue-600" aria-hidden />{m.name}</span>
                    <span className="shrink-0 text-xs text-slate-500">{dateLabel(m.createdAt)}</span>
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section className={card}>
            <h3 className="text-base font-black text-slate-900 flex items-center gap-2"><Cake className="w-5 h-5 text-rose-500" aria-hidden /> {t('page:cumpleanos')}</h3>
            {birthdays.length === 0 ? (
              <p className="text-sm text-slate-500">{t('page:sin_cumpleanos')}</p>
            ) : (
              <ul className="space-y-2">
                {birthdays.map((b) => (
                  <li key={b.id} className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-slate-200 px-4 py-3">
                    <div className="min-w-0">
                      <p className="text-sm font-black text-slate-900">{b.name} <span className="font-semibold text-slate-500">· {b.inDays === 0 ? t('page:hoy') : t('page:en_dias', { count: b.inDays })}</span></p>
                      <p className="text-xs text-slate-500">{b.favorite ? t('page:le_gusta', { favorite: b.favorite }) : t('page:sin_compras')}</p>
                    </div>
                    {b.phone && b.marketingOptIn ? (
                      <a href={`https://wa.me/${whatsappNumber(b.phone)}?text=${encodeURIComponent(greet(b))}`} target="_blank" rel="noreferrer"
                        className="inline-flex items-center gap-1.5 min-h-[36px] px-3 rounded-xl bg-emerald-600 text-xs font-bold text-white hover:bg-emerald-700">
                        <MessageCircle className="w-3.5 h-3.5" aria-hidden /> {t('page:saludar')}
                      </a>
                    ) : (
                      <span className="text-xs text-slate-400">{t('page:sin_permiso_mensajes')}</span>
                    )}
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>
      )}

      <div className="fixed bottom-0 inset-x-0 z-30 border-t border-slate-200 bg-white/95 backdrop-blur px-4 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-end gap-3">
          <p className="hidden sm:block flex-1 text-xs text-slate-500">{t('page:guardar_desc')}</p>
          <button type="button" onClick={save} disabled={saving} className="inline-flex items-center gap-2 min-h-[46px] px-6 rounded-xl bg-blue-600 text-sm font-bold text-white shadow-sm hover:bg-blue-700 disabled:opacity-50">
            {saving ? <Loader2 className="w-4 h-4 animate-spin" aria-hidden /> : <Globe className="w-4 h-4" aria-hidden />}
            {saving ? t('page:publicando') : t('page:guardar_publicar')}
          </button>
        </div>
      </div>

      {bookingOpen && <ReservationSettingsPanel onClose={() => setBookingOpen(false)} onSaved={() => { setBookingOpen(false); load(); }} />}
    </div>
  );
}
