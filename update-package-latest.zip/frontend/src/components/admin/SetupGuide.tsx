// ============================================
// ADMIN - Guía de configuración por funciones
// ============================================
// 1) Pregunta función por función qué va a usar el negocio: solo las de su plan.
// 2) Arma el paso a paso de lo elegido; cada paso lleva a su pantalla y explica
//    cómo se hace. Lo que el sistema comprueba se marca solo.
// 3) Lo descartado se puede volver a agregar; lo de otros planes solo se informa.

import React, { useEffect, useState } from 'react';
import { Check, ChevronDown, Circle, Compass, HelpCircle, Lock, Plus, RotateCcw, X, ArrowRight } from 'lucide-react';
import { t } from '../../i18n';
import { toast } from '../../shared/toast';
import { FEATURE_PLAN } from '../../shared/plan';
import { useGuideStore } from '../../guide/guideStore';
import { GuideFunction, GuideSection, GuideStep, isChosen, useGuideProgress, useSetupGuide } from '../../shared/setupGuide';

interface Props {
  onGo: (section: GuideSection) => void;
}

export const SetupGuide: React.FC<Props> = ({ onGo }) => {
  const { state, checks, load, save } = useSetupGuide();
  const { loaded, available, locked, progress } = useGuideProgress();
  const [open, setOpen] = useState<string | null>(null);

  useEffect(() => { load(); }, [load]);

  const persist = (next: typeof state) => save(next).catch(() => toast.error(t('setup:no_se_guardo')));
  const choose = (id: string, choice: 'use' | 'skip') => {
    persist({ ...state, choices: { ...state.choices, [id]: choice } });
    if (choice === 'use') setOpen(id);
  };
  const undecide = (id: string) => {
    const { [id]: _removed, ...rest } = state.choices;
    persist({ ...state, choices: rest });
  };
  const toggleDone = (stepId: string) =>
    persist({ ...state, done: state.done.includes(stepId) ? state.done.filter((d) => d !== stepId) : [...state.done, stepId] });

  const isDone = (s: GuideStep) => !!checks[s.id] || state.done.includes(s.id);
  const pending = available.filter((f) => !f.essential && !state.choices[f.id]);
  const chosen = available.filter((f) => isChosen(f, state));
  const skipped = available.filter((f) => !f.essential && state.choices[f.id] === 'skip');
  // La primera función sin terminar queda abierta
  const firstOpen = open ?? chosen.find((f) => f.steps.some((s) => !isDone(s)))?.id ?? null;
  const pct = progress.total ? Math.round((progress.done / progress.total) * 100) : 0;

  if (!loaded) return <p className="text-sm text-slate-500 py-10 text-center">{t('setup:cargando')}</p>;

  return (
    <div className="space-y-6 pb-16">
      {/* Avance */}
      <section className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-700 flex items-center justify-center shrink-0">
            <Compass className="w-6 h-6" aria-hidden />
          </div>
          <div className="flex-1 min-w-0">
            <h2 className="text-xl font-bold text-slate-900 font-heading">{t('setup:titulo')}</h2>
            <p className="text-sm text-slate-600 mt-1 max-w-2xl">{t('setup:subtitulo')}</p>
            <div className="mt-4 flex items-center gap-3">
              <div className="flex-1 h-2.5 rounded-full bg-slate-100 overflow-hidden" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100} aria-label={t('setup:avance')}>
                <div className="h-full bg-blue-600 rounded-full transition-all" style={{ width: `${pct}%` }} />
              </div>
              <span className="text-sm font-bold text-slate-700 tabular-nums whitespace-nowrap">{t('setup:pasos_n', { done: progress.done, total: progress.total })}</span>
            </div>
            {progress.complete && <p className="mt-3 text-sm font-semibold text-emerald-700">{t('setup:todo_listo')}</p>}
          </div>
        </div>
      </section>

      {/* 1. Qué va a usar */}
      {pending.length > 0 && (
        <section aria-labelledby="setup-pick" className="space-y-3">
          <div>
            <h3 id="setup-pick" className="text-base font-bold text-slate-900">{t('setup:elige_titulo', { count: pending.length })}</h3>
            <p className="text-xs text-slate-500 mt-0.5">{t('setup:elige_desc')}</p>
          </div>
          <div className="grid gap-3 md:grid-cols-2">
            {pending.map((f) => (
              <article key={f.id} className="bg-white rounded-2xl border border-slate-200 p-4 flex flex-col">
                <h4 className="text-sm font-bold text-slate-900">{t(`setup:fn_${f.id}_t`)}</h4>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed flex-1">{t(`setup:fn_${f.id}_d`)}</p>
                <div className="mt-3 flex gap-2">
                  <button type="button" onClick={() => choose(f.id, 'use')} className="h-10 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold inline-flex items-center gap-1.5">
                    <Plus className="w-4 h-4" aria-hidden /> {t('setup:lo_usare')}
                  </button>
                  <button type="button" onClick={() => choose(f.id, 'skip')} className="h-10 px-4 rounded-xl text-sm font-semibold text-slate-600 hover:bg-slate-100">
                    {t('setup:no_lo_necesito')}
                  </button>
                </div>
              </article>
            ))}
          </div>
        </section>
      )}

      {/* 2. Paso a paso de lo elegido */}
      <section aria-labelledby="setup-steps" className="space-y-3">
        <h3 id="setup-steps" className="text-base font-bold text-slate-900">{t('setup:tu_paso_a_paso')}</h3>
        {chosen.map((f) => (
          <FunctionCard
            key={f.id}
            fn={f}
            expanded={firstOpen === f.id}
            onToggle={() => setOpen(firstOpen === f.id ? '' : f.id)}
            isDone={isDone}
            auto={(s) => !!checks[s.id]}
            onGo={onGo}
            onMark={toggleDone}
            onDrop={f.essential ? undefined : () => choose(f.id, 'skip')}
          />
        ))}
      </section>

      {/* 3. Descartadas */}
      {skipped.length > 0 && (
        <section aria-labelledby="setup-skipped" className="space-y-2">
          <h3 id="setup-skipped" className="text-sm font-bold text-slate-700">{t('setup:descartadas')}</h3>
          <ul className="flex flex-wrap gap-2">
            {skipped.map((f) => (
              <li key={f.id}>
                <button type="button" onClick={() => undecide(f.id)} className="h-9 px-3 rounded-full border border-slate-200 bg-white text-xs font-semibold text-slate-600 hover:border-blue-300 hover:text-blue-700 inline-flex items-center gap-1.5" title={t('setup:volver_a_preguntar')}>
                  <RotateCcw className="w-3.5 h-3.5" aria-hidden /> {t(`setup:fn_${f.id}_t`)}
                </button>
              </li>
            ))}
          </ul>
        </section>
      )}

      {/* 4. En otros planes: solo se informan, no se configuran */}
      {locked.length > 0 && (
        <section aria-labelledby="setup-locked" className="space-y-2">
          <h3 id="setup-locked" className="text-sm font-bold text-slate-700">{t('setup:otros_planes')}</h3>
          <ul className="grid gap-2 md:grid-cols-2">
            {locked.map((f) => (
              <li key={f.id} className="flex items-start gap-3 p-3 rounded-2xl border border-dashed border-slate-300 bg-slate-50/60">
                <Lock className="w-4 h-4 text-slate-400 mt-0.5 shrink-0" aria-hidden />
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-slate-700">{t(`setup:fn_${f.id}_t`)}</p>
                  <p className="text-xs text-slate-500">{t('plan:disponible_en', { plan: t(`plan:plan_${FEATURE_PLAN[f.feature!] || 'premium'}`) })}</p>
                </div>
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
};

function FunctionCard({ fn, expanded, onToggle, isDone, auto, onGo, onMark, onDrop }: {
  fn: GuideFunction;
  expanded: boolean;
  onToggle: () => void;
  isDone: (s: GuideStep) => boolean;
  auto: (s: GuideStep) => boolean;
  onGo: (section: GuideSection) => void;
  onMark: (stepId: string) => void;
  onDrop?: () => void;
}) {
  const done = fn.steps.filter(isDone).length;
  const complete = done === fn.steps.length;
  return (
    <article className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
      <button type="button" onClick={onToggle} aria-expanded={expanded} className="w-full flex items-center gap-3 p-4 text-left hover:bg-slate-50">
        <span className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${complete ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-500'}`}>
          {complete ? <Check className="w-4 h-4" aria-hidden /> : <span className="text-xs font-bold tabular-nums">{done}/{fn.steps.length}</span>}
        </span>
        <span className="flex-1 min-w-0">
          <span className="block text-sm font-bold text-slate-900">{t(`setup:fn_${fn.id}_t`)}</span>
          <span className="block text-xs text-slate-500 truncate">{t(`setup:fn_${fn.id}_d`)}</span>
        </span>
        <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${expanded ? 'rotate-180' : ''}`} aria-hidden />
      </button>
      {expanded && (
        <div className="border-t border-slate-100">
          <ol className="divide-y divide-slate-100">
            {fn.steps.map((s, i) => {
              const ok = isDone(s);
              const isAuto = auto(s);
              return (
                <li key={s.id} className="p-4 flex flex-col sm:flex-row sm:items-start gap-3">
                  <div className="flex items-start gap-3 flex-1 min-w-0">
                    {ok ? <Check className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" aria-label={t('setup:hecho')} /> : <Circle className="w-5 h-5 text-slate-300 shrink-0 mt-0.5" aria-label={t('setup:pendiente')} />}
                    <div className="min-w-0">
                      <p className={`text-sm font-semibold ${ok ? 'text-slate-500' : 'text-slate-900'}`}>{i + 1}. {t(`setup:st_${s.id}_t`)}</p>
                      <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">{t(`setup:st_${s.id}_d`)}</p>
                      {s.article && (
                        <button type="button" onClick={() => useGuideStore.getState().openHelp('help', s.article!)} className="mt-1.5 text-xs font-semibold text-slate-500 hover:text-blue-700 inline-flex items-center gap-1">
                          <HelpCircle className="w-3.5 h-3.5" aria-hidden /> {t('setup:como_se_hace')}
                        </button>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 pl-8 sm:pl-0 shrink-0">
                    {!s.auto && (
                      <button type="button" onClick={() => onMark(s.id)} className="h-9 px-3 rounded-xl text-xs font-semibold border border-slate-200 text-slate-600 hover:bg-slate-50">
                        {ok ? t('setup:desmarcar') : t('setup:marcar_hecho')}
                      </button>
                    )}
                    {s.auto && !isAuto && <span className="text-xs text-slate-500">{t('setup:se_marca_solo')}</span>}
                    <button type="button" onClick={() => onGo(s.section)} className="h-9 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold inline-flex items-center gap-1">
                      {t('setup:ir')} <ArrowRight className="w-3.5 h-3.5" aria-hidden />
                    </button>
                  </div>
                </li>
              );
            })}
          </ol>
          {onDrop && (
            <div className="px-4 py-3 border-t border-slate-100 bg-slate-50/60">
              <button type="button" onClick={onDrop} className="text-xs font-semibold text-slate-500 hover:text-rose-700 inline-flex items-center gap-1">
                <X className="w-3.5 h-3.5" aria-hidden /> {t('setup:ya_no_la_usare')}
              </button>
            </div>
          )}
        </div>
      )}
    </article>
  );
}
