// ============================================
// ADMIN - Guía de configuración por funciones
// ============================================
// 1) Pregunta función por función qué va a usar el negocio: solo las de su plan.
// 2) Arma el paso a paso de lo elegido; cada paso lleva a su pantalla y explica
//    cómo se hace. Lo que el sistema comprueba se marca solo.
// 3) Lo descartado se puede volver a agregar; lo de otros planes solo se informa.

import React, { useEffect, useState } from 'react';
import { Check, ChevronDown, Circle, Compass, HelpCircle, Lock, Plus, RotateCcw, X, ArrowRight, ShieldCheck } from 'lucide-react';
import { t } from '../../i18n';
import { toast } from '../../shared/toast';
import { FEATURE_PLAN } from '../../shared/plan';
import { useGuideStore } from '../../guide/guideStore';
import { GuideFunction, GuideSection, GuideStep, isChosen, useGuideProgress, useSetupGuide } from '../../shared/setupGuide';

interface Props {
  onGo: (section: GuideSection) => void;
}

export const SetupGuide: React.FC<Props> = ({ onGo }) => {
  const { state, checks, load, save } = useSetupGuide();
  const { loaded, available, locked, progress } = useGuideProgress();
  const [open, setOpen] = useState<string | null>(null);

  useEffect(() => { load(); }, [load]);

  const persist = (next: typeof state) => save(next).catch(() => toast.error(t('setup:no_se_guardo')));
  const choose = (id: string, choice: 'use' | 'skip') => {
    persist({ ...state, choices: { ...state.choices, [id]: choice } });
    if (choice === 'use') setOpen(id);
  };
  const undecide = (id: string) => {
    const { [id]: _removed, ...rest } = state.choices;
    persist({ ...state, choices: rest });
  };
  const toggleDone = (stepId: string) =>
    persist({ ...state, done: state.done.includes(stepId) ? state.done.filter((d) => d !== stepId) : [...state.done, stepId] });

  const isDone = (s: GuideStep) => !!checks[s.id] || state.done.includes(s.id);
  const pending = available.filter((f) => !f.essential && !state.choices[f.id]).sort((a, b) => Number(!!b.isNew) - Number(!!a.isNew));
  const chosen = available.filter((f) => isChosen(f, state));
  // Lo esencial (vender) va primero y aparte; lo demás se activa con calma
  const essential = chosen.filter((f) => f.essential);
  const extras = chosen.filter((f) => !f.essential);
  const essentialLeft = essential.reduce((n, f) => n + f.steps.filter((st) => !(!!checks[st.id] || state.done.includes(st.id))).length, 0);
  const skipped = available.filter((f) => !f.essential && state.choices[f.id] === 'skip');
  // La primera función sin terminar queda abierta
  const firstOpen = open ?? chosen.find((f) => f.steps.some((s) => !isDone(s)))?.id ?? null;
  const pct = progress.total ? Math.round((progress.done / progress.total) * 100) : 0;

  if (!loaded) return <p className="text-sm text-slate-500 py-10 text-center">{t('setup:cargando')}</p>;

  return (
    <div className="space-y-6 pb-16">
      {/* Avance */}
      <section className="rounded-[22px] bg-white p-6 shadow-card">
        <div className="flex items-start gap-4">
          <div className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-blue-50 text-blue-700">
            <Compass className="w-6 h-6" aria-hidden />
          </div>
          <div className="flex-1 min-w-0">
            <h2 className="text-xl font-semibold tracking-tight text-slate-950">{t('setup:titulo')}</h2>
            <p className="text-sm text-slate-600 mt-1 max-w-2xl">{t('setup:subtitulo')}</p>
            <div className="mt-4 flex items-center gap-3">
              <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-slate-100" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100} aria-label={t('setup:avance')}>
                <div className="h-full rounded-full bg-blue-600 transition-[width] duration-slow ease-out" style={{ width: `${pct}%` }} />
              </div>
              <span className="whitespace-nowrap text-sm font-medium text-slate-700 num">{t('setup:pasos_n', { done: progress.done, total: progress.total })}</span>
            </div>
            {progress.complete
              ? <p className="mt-3 text-sm font-medium text-emerald-700">{t('setup:todo_listo')}</p>
              : essential.length > 0 && (
                <p className={`mt-3 inline-flex items-center gap-2 rounded-full px-3 py-1 text-sm font-medium ${essentialLeft === 0 ? 'bg-emerald-50 text-emerald-800' : 'bg-amber-50 text-amber-900'}`}>
                  <span aria-hidden className={`h-2 w-2 rounded-full ${essentialLeft === 0 ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                  {essentialLeft === 0 ? t('setup:listo_para_vender') : t('setup:falta_para_vender', { count: essentialLeft })}
                </p>
              )}
          </div>
        </div>
      </section>

      {/* 1. Qué va a usar */}
      {pending.length > 0 && (
        <section aria-labelledby="setup-pick" className="space-y-3">
          <div>
            <h3 id="setup-pick" className="text-base font-semibold text-slate-900">{t('setup:elige_titulo', { count: pending.length })}</h3>
            <p className="text-xs text-slate-500 mt-0.5">{t('setup:elige_desc')}</p>
          </div>
          <div className="grid gap-3 md:grid-cols-2">
            {pending.map((f) => (
              <article key={f.id} className="flex flex-col rounded-[14px] bg-white p-4 shadow-card">
                <h4 className="flex items-center gap-2 text-[0.95rem] font-semibold text-slate-900">{t(`setup:fn_${f.id}_t`)}{f.isNew && <NewBadge />}</h4>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed flex-1">{t(`setup:fn_${f.id}_d`)}</p>
                <div className="mt-3 flex gap-2">
                  <button type="button" onClick={() => choose(f.id, 'use')} className="h-10 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold inline-flex items-center gap-1.5">
                    <Plus className="w-4 h-4" aria-hidden /> {t('setup:lo_usare')}
                  </button>
                  <button type="button" onClick={() => choose(f.id, 'skip')} className="h-10 px-4 rounded-xl text-sm font-semibold text-slate-600 hover:bg-slate-100">
                    {t('setup:no_lo_necesito')}
                  </button>
                </div>
              </article>
            ))}
          </div>
        </section>
      )}

      {/* 2. Paso a paso: primero lo esencial para vender, después lo adicional */}
      {[
        { id: 'essential', list: essential, title: t('setup:esencial_titulo'), desc: t('setup:esencial_desc') },
        { id: 'extras', list: extras, title: t('setup:adicionales_titulo'), desc: t('setup:adicionales_desc') },
      ].filter((g) => g.list.length > 0).map((g) => (
        <section key={g.id} aria-labelledby={`setup-${g.id}`} className="space-y-3">
          <div>
            <h3 id={`setup-${g.id}`} className="text-base font-semibold text-slate-900">{g.title}</h3>
            <p className="mt-0.5 text-xs text-slate-500">{g.desc}</p>
          </div>
          {g.list.map((f) => (
            <FunctionCard
              key={f.id}
              fn={f}
              expanded={firstOpen === f.id}
              onToggle={() => setOpen(firstOpen === f.id ? '' : f.id)}
              isDone={isDone}
              auto={(st) => !!checks[st.id]}
              onGo={onGo}
              onMark={toggleDone}
              onDrop={f.essential ? undefined : () => choose(f.id, 'skip')}
            />
          ))}
        </section>
      ))}

      {/* 3. Descartadas */}
      {skipped.length > 0 && (
        <section aria-labelledby="setup-skipped" className="space-y-2">
          <h3 id="setup-skipped" className="text-sm font-bold text-slate-700">{t('setup:descartadas')}</h3>
          <ul className="flex flex-wrap gap-2">
            {skipped.map((f) => (
              <li key={f.id}>
                <button type="button" onClick={() => undecide(f.id)} className="h-9 px-3 rounded-full border border-slate-200 bg-white text-xs font-semibold text-slate-600 hover:border-blue-300 hover:text-blue-700 inline-flex items-center gap-1.5" title={t('setup:volver_a_preguntar')}>
                  <RotateCcw className="w-3.5 h-3.5" aria-hidden /> {t(`setup:fn_${f.id}_t`)}
                </button>
              </li>
            ))}
          </ul>
        </section>
      )}

      {/* 4. En otros planes: solo se informan, no se configuran */}
      {locked.length > 0 && (
        <section aria-labelledby="setup-locked" className="space-y-2">
          <h3 id="setup-locked" className="text-sm font-bold text-slate-700">{t('setup:otros_planes')}</h3>
          <ul className="grid gap-2 md:grid-cols-2">
            {locked.map((f) => (
              <li key={f.id} className="flex items-start gap-3 p-3 rounded-2xl border border-dashed border-slate-300 bg-slate-50/60">
                <Lock className="w-4 h-4 text-slate-400 mt-0.5 shrink-0" aria-hidden />
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-slate-700">{t(`setup:fn_${f.id}_t`)}</p>
                  <p className="text-xs text-slate-500">{t('plan:disponible_en', { plan: t(`plan:plan_${FEATURE_PLAN[f.feature!] || 'premium'}`) })}</p>
                </div>
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
};

function FunctionCard({ fn, expanded, onToggle, isDone, auto, onGo, onMark, onDrop }: {
  fn: GuideFunction;
  expanded: boolean;
  onToggle: () => void;
  isDone: (s: GuideStep) => boolean;
  auto: (s: GuideStep) => boolean;
  onGo: (section: GuideSection) => void;
  onMark: (stepId: string) => void;
  onDrop?: () => void;
}) {
  const done = fn.steps.filter(isDone).length;
  const complete = done === fn.steps.length;
  return (
    <article className="overflow-hidden rounded-[14px] bg-white shadow-card">
      <button type="button" onClick={onToggle} aria-expanded={expanded} className="w-full flex items-center gap-3 p-4 text-left hover:bg-slate-50">
        <span className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${complete ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-500'}`}>
          {complete ? <Check className="w-4 h-4" aria-hidden /> : <span className="text-xs font-semibold num">{done}/{fn.steps.length}</span>}
        </span>
        <span className="flex-1 min-w-0">
          <span className="flex items-center gap-2 text-[0.95rem] font-semibold text-slate-900">{t(`setup:fn_${fn.id}_t`)}</span>
          <span className="block text-xs text-slate-500 truncate">{t(`setup:fn_${fn.id}_d`)}</span>
        </span>
        <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${expanded ? 'rotate-180' : ''}`} aria-hidden />
      </button>
      {expanded && (
        <div className="border-t border-slate-100">
          <ol className="divide-y divide-slate-100">
            {fn.steps.map((s, i) => {
              const ok = isDone(s);
              const isAuto = auto(s);
              return (
                <li key={s.id} className="p-4 flex flex-col sm:flex-row sm:items-start gap-3">
                  <div className="flex items-start gap-3 flex-1 min-w-0">
                    {ok && isAuto
                      ? <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-emerald-600" aria-label={t('setup:verificado_auto')} />
                      : ok
                        ? <Check className="mt-0.5 h-5 w-5 shrink-0 text-slate-500" aria-label={t('setup:confirmado_manual')} />
                        : <Circle className="mt-0.5 h-5 w-5 shrink-0 text-slate-300" aria-label={t('setup:pendiente')} />}
                    <div className="min-w-0">
                      <p className={`text-sm font-medium ${ok ? 'text-slate-500' : 'text-slate-900'}`}>{i + 1}. {t(`setup:st_${s.id}_t`)}</p>
                      {ok && (
                        <p className={`mt-0.5 text-xs font-medium ${isAuto ? 'text-emerald-700' : 'text-slate-500'}`}>
                          {isAuto ? t('setup:verificado_auto') : t('setup:confirmado_manual')}
                        </p>
                      )}
                      <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">{t(`setup:st_${s.id}_d`)}</p>
                      {s.article && (
                        <button type="button" onClick={() => useGuideStore.getState().openHelp('help', s.article!)} className="mt-1.5 inline-flex items-center gap-1 text-sm font-medium text-slate-600 hover:text-blue-700">
                          <HelpCircle className="w-3.5 h-3.5" aria-hidden /> {t('setup:como_se_hace')}
                        </button>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 pl-8 sm:pl-0 shrink-0">
                    {!s.auto && (
                      <button type="button" onClick={() => onMark(s.id)} className="h-9 rounded-[10px] px-3 text-xs font-medium text-slate-600 ring-1 ring-inset ring-slate-200 hover:bg-slate-50">
                        {ok ? t('setup:desmarcar') : t('setup:marcar_hecho')}
                      </button>
                    )}
                    {s.auto && !isAuto && <span className="text-xs text-slate-500">{t('setup:se_marca_solo')}</span>}
                    <button type="button" onClick={() => onGo(s.section)} className="inline-flex h-9 items-center gap-1 rounded-[10px] bg-slate-950 px-3 text-xs font-medium text-white hover:bg-slate-800">
                      {t('setup:ir')} <ArrowRight className="w-3.5 h-3.5" aria-hidden />
                    </button>
                  </div>
                </li>
              );
            })}
          </ol>
          {onDrop && (
            <div className="px-4 py-3 border-t border-slate-100 bg-slate-50/60">
              <button type="button" onClick={onDrop} className="inline-flex items-center gap-1 text-xs font-medium text-slate-600 hover:text-rose-700">
                <X className="w-3.5 h-3.5" aria-hidden /> {t('setup:ya_no_la_usare')}
              </button>
              <span className="ml-2 text-xs text-slate-500">{t('setup:omitir_desc')}</span>
            </div>
          )}
        </div>
      )}
    </article>
  );
}

const NewBadge = () => (
  <span className="rounded-full bg-blue-50 px-2 py-0.5 text-[0.72rem] font-medium text-blue-800">{t('v3:nuevo_3')}</span>
);
