// ============================================
// ADMIN - Datos del negocio en subpestañas
// ============================================
// Antes era una sola página larga (datos, QR de pago, puerta y funciones) y la
// exportación contable vivía escondida en el informe mensual de la caja. Ahora cada
// cosa tiene su pestaña, y Puerta trae una guía paso a paso que se marca sola.

import React, { useEffect, useState } from 'react';
import { Building2, Calculator, Check, CircleDashed, DoorOpen, QrCode, ToggleRight } from 'lucide-react';
import { t } from '../../i18n';
import { authAPI } from '../../services/api';
import { useBusinessStore } from '../../shared/business';
import { useFeatureFlag } from '../../shared/features';
import { usePosStore } from '../../store/usePosStore';
import { BusinessSettingsPanel } from './BusinessSettingsPanel';
import { PaymentQrPanel } from './PaymentQrPanel';
import { DoorSettingsPanel } from './DoorSettingsPanel';
import { FeaturesPanel } from './FeaturesPanel';
import { AccountingExportTab } from '../pos/AccountingExportTab';

const TABS = [
  ['datos', Building2],
  ['cobros', QrCode],
  ['funciones', ToggleRight],
  ['puerta', DoorOpen],
  ['contabilidad', Calculator],
] as const;
export type BusinessTab = (typeof TABS)[number][0];
const KEY = 'lantify.businessTab';

const initial = (): BusinessTab => {
  try {
    const v = localStorage.getItem(KEY);
    if (TABS.some(([id]) => id === v)) return v as BusinessTab;
  } catch { /* sin almacenamiento */ }
  return 'datos';
};

// ── Guía paso a paso (se marca sola con lo que ya está hecho) ──

export interface GuideStep {
  id: string;
  done: boolean;
  title: string;
  desc: string;
  action?: { label: string; onClick: () => void };
}

export const GuidedSteps: React.FC<{ title: string; intro: string; steps: GuideStep[]; after?: React.ReactNode }> = ({ title, intro, steps, after }) => {
  const done = steps.filter((s) => s.done).length;
  const next = steps.find((s) => !s.done)?.id;
  return (
    <section className="space-y-4 rounded-3xl border border-blue-100 bg-blue-50/40 p-6 sm:p-8" aria-labelledby={`guia-${title}`}>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 id={`guia-${title}`} className="font-heading text-base font-bold text-slate-900">{title}</h3>
          <p className="mt-1 max-w-2xl text-sm text-slate-600">{intro}</p>
        </div>
        <span className="rounded-full bg-white px-3 py-1 text-xs font-bold text-slate-700 shadow-sm">{t('v3:guia_pasos_listos', { done, total: steps.length })}</span>
      </div>
      <ol className="space-y-2">
        {steps.map((s, i) => (
          <li key={s.id} className={`flex flex-wrap items-start gap-3 rounded-2xl border bg-white p-4 ${s.id === next ? 'border-blue-400 ring-2 ring-blue-100' : 'border-slate-200'}`}>
            <span className={`grid h-8 w-8 shrink-0 place-items-center rounded-full text-sm font-black ${s.done ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600'}`} aria-hidden>
              {s.done ? <Check className="h-4 w-4" /> : i + 1}
            </span>
            <div className="min-w-0 flex-1">
              <p className="font-bold text-slate-900">
                {s.title}
                <span className="sr-only">{s.done ? ` (${t('v3:guia_hecho')})` : ` (${t('v3:guia_pendiente')})`}</span>
              </p>
              <p className="text-sm text-slate-600">{s.desc}</p>
            </div>
            {s.action && !s.done && (
              <button type="button" onClick={s.action.onClick} className="min-h-[40px] rounded-xl bg-slate-900 px-4 text-sm font-bold text-white hover:bg-slate-800">
                {s.action.label}
              </button>
            )}
            {s.done && <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-700"><Check className="h-3.5 w-3.5" aria-hidden />{t('v3:guia_hecho')}</span>}
          </li>
        ))}
      </ol>
      {after}
    </section>
  );
};

/** Puerta: qué hay que dejar listo y cómo se usa en la noche */
const DoorGuide: React.FC<{ onGo: (tab: string) => void; onTab: (tab: BusinessTab) => void }> = ({ onGo, onTab }) => {
  const on = useFeatureFlag('door');
  const capacity = useBusinessStore((s) => s.settings?.maxCapacity);
  const products = usePosStore((s) => s.products);
  const [hasDoorUser, setHasDoorUser] = useState(false);
  useEffect(() => {
    authAPI.getUsers().then((list: any[]) => setHasDoorUser(list.some((u) => u.role === 'DOOR' && u.isActive !== false))).catch(() => undefined);
    if (!usePosStore.getState().products.length) usePosStore.getState().fetchProducts().catch(() => undefined);
  }, []);
  const hasCover = products.some((p: any) => p.isCover);
  const scrollToCapacity = () => document.getElementById('puerta-title')?.scrollIntoView({ behavior: 'smooth', block: 'start' });

  return (
    <GuidedSteps
      title={t('v3:puerta_guia_titulo')}
      intro={t('v3:puerta_guia_intro')}
      steps={[
        { id: 'on', done: on, title: t('v3:puerta_guia_1'), desc: t('v3:puerta_guia_1_desc'), action: { label: t('v3:guia_ir'), onClick: () => onTab('funciones') } },
        { id: 'aforo', done: on && !!capacity, title: t('v3:puerta_guia_2'), desc: t('v3:puerta_guia_2_desc'), action: on ? { label: t('v3:guia_ir'), onClick: scrollToCapacity } : undefined },
        { id: 'cover', done: hasCover, title: t('v3:puerta_guia_3'), desc: t('v3:puerta_guia_3_desc'), action: { label: t('v3:guia_ir_productos'), onClick: () => onGo('products') } },
        { id: 'portero', done: hasDoorUser, title: t('v3:puerta_guia_4'), desc: t('v3:puerta_guia_4_desc'), action: { label: t('v3:guia_ir_usuarios'), onClick: () => onGo('users') } },
      ]}
      after={(
        <div className="rounded-2xl bg-white p-4 text-sm text-slate-700">
          <p className="font-bold text-slate-900">{t('v3:puerta_guia_noche')}</p>
          <ul className="mt-2 space-y-1.5">
            {(['puerta_guia_noche_1', 'puerta_guia_noche_2', 'puerta_guia_noche_3', 'puerta_guia_noche_4'] as const).map((k) => (
              <li key={k} className="flex gap-2"><CircleDashed className="mt-0.5 h-4 w-4 shrink-0 text-blue-600" aria-hidden />{t(`v3:${k}`)}</li>
            ))}
          </ul>
        </div>
      )}
    />
  );
};

/** Contabilidad: el mismo exportador del informe mensual, con su propio selector de mes */
const AccountingPanel: React.FC<{ onTab: (tab: BusinessTab) => void }> = ({ onTab }) => {
  const on = useFeatureFlag('accounting_export');
  const [month, setMonth] = useState(() => {
    const d = new Date();
    d.setDate(1);
    d.setMonth(d.getMonth() - 1);
    return d.toLocaleDateString('en-CA').slice(0, 7);
  });
  const label = (() => {
    const [y, m] = month.split('-').map(Number);
    return new Date(y, m - 1, 1).toLocaleDateString(undefined, { month: 'long', year: 'numeric' });
  })();
  if (!on) {
    return (
      <div className="rounded-3xl border border-slate-200 bg-white p-6 text-sm text-slate-700 sm:p-8">
        <p className="font-bold text-slate-900">{t('v3:contab_apagada')}</p>
        <p className="mt-1">{t('v3:contab_apagada_desc')}</p>
        <button type="button" onClick={() => onTab('funciones')} className="mt-3 min-h-[40px] rounded-xl bg-slate-900 px-4 font-bold text-white">{t('v3:guia_ir')}</button>
      </div>
    );
  }
  return (
    <div className="space-y-4">
      <label className="flex max-w-xs flex-col gap-1 text-xs font-bold text-slate-700">{t('v3:contab_mes')}
        <input type="month" value={month} max={new Date().toLocaleDateString('en-CA').slice(0, 7)} onChange={(e) => e.target.value && setMonth(e.target.value)} className="min-h-[44px] rounded-xl border border-slate-300 bg-white px-3 text-sm text-slate-900" />
      </label>
      <AccountingExportTab key={month} month={month} monthLabel={label} />
    </div>
  );
};

export const BusinessTabs: React.FC<{ onSaved: (b: any) => void; onGo: (adminTab: string) => void }> = ({ onSaved, onGo }) => {
  const [tab, setTab] = useState<BusinessTab>(initial);
  const pick = (id: BusinessTab) => {
    setTab(id);
    try { localStorage.setItem(KEY, id); } catch { /* sin almacenamiento */ }
  };
  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-2xl font-bold text-slate-900 font-heading">{t('admin:datos_del_negocio')}</h2>
        <p className="mt-1 text-sm text-slate-500">{t('v3:negocio_tabs_desc')}</p>
      </div>
      <div className="-mx-1 overflow-x-auto px-1 pb-1">
        <div className="inline-flex gap-1 rounded-2xl bg-slate-100 p-1" role="tablist" aria-label={t('admin:datos_del_negocio')}>
          {TABS.map(([id, Icon]) => (
            <button key={id} type="button" role="tab" aria-selected={tab === id} onClick={() => pick(id)} className={`inline-flex min-h-[40px] items-center gap-2 whitespace-nowrap rounded-xl px-4 text-sm font-bold ${tab === id ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}>
              <Icon className="h-4 w-4" aria-hidden />{t(`v3:negocio_tab_${id}`)}
            </button>
          ))}
        </div>
      </div>
      <div role="tabpanel" className="space-y-6">
        {tab === 'datos' && <BusinessSettingsPanel onSaved={onSaved} />}
        {tab === 'cobros' && <PaymentQrPanel />}
        {tab === 'funciones' && <FeaturesPanel place="business" />}
        {tab === 'puerta' && (
          <>
            <DoorGuide onGo={onGo} onTab={pick} />
            <DoorSettingsPanel />
          </>
        )}
        {tab === 'contabilidad' && <AccountingPanel onTab={pick} />}
      </div>
    </div>
  );
};
