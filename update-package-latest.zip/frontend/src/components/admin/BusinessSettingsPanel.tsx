// ============================================
// ADMIN - Datos del negocio, impuestos y módulos (se guardan en el servidor)
// ============================================

import { useEffect, useRef, useState } from 'react';
import { Building2, Save, Sparkles, Loader2, Lock } from 'lucide-react';
import { t } from '../../i18n';
import { businessAPI, BusinessSettings, TaxType } from '../../services/api';
import { useBusinessStore, openOnboarding } from '../../shared/business';
import { BUSINESS_PRESETS, TAX_BY_REGIME, TAX_REGIMES } from '../../shared/businessPresets';
import { Toggle, ChoiceCard, ToggleGrid } from '../common/Choice';
import { toast } from '../../shared/toast';
import { usePlan, FEATURE_PLAN } from '../../shared/plan';
import { ImageField } from '../common/ImageField';

const fieldClass =
  'px-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-slate-900 outline-none text-sm font-medium';
const inputClass = `w-full ${fieldClass}`;
const labelClass = 'block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5';

type Editable = Omit<BusinessSettings, 'onboardingCompletedAt'>;

const EDITABLE_FIELDS: (keyof Editable)[] = [
  'businessType', 'businessName', 'legalName', 'nit', 'dv', 'taxRegime', 'address', 'city', 'phone', 'email',
  'ticketFooter', 'deliveryEnabled', 'whatsappEnabled', 'rappiEnabled', 'inventoryEnabled', 'tipEnabled', 'tipPercent',
  'defaultTaxType', 'defaultTaxRate', 'wantsElectronicInvoice',
];

interface BusinessSettingsPanelProps {
  /** Mantiene sincronizado el formulario local de Configuración (tickets) */
  onSaved?: (s: BusinessSettings) => void;
}

export function BusinessSettingsPanel({ onSaved }: BusinessSettingsPanelProps) {
  const stored = useBusinessStore((s) => s.settings);
  const setStored = useBusinessStore((s) => s.setSettings);
  const load = useBusinessStore((s) => s.load);
  const [form, setForm] = useState<Editable | null>(stored);
  const [saving, setSaving] = useState(false);
  const plan = usePlan();
  // El logo se guarda al subirlo: no debe borrar lo que se está escribiendo en el formulario
  const onlyLogo = useRef(false);

  useEffect(() => {
    if (!stored) load();
  }, [stored, load]);

  useEffect(() => {
    if (!stored) return;
    if (onlyLogo.current) {
      onlyLogo.current = false;
      setForm((f) => (f ? { ...f, logoUrl: stored.logoUrl } : stored));
    } else setForm(stored);
  }, [stored]);

  const saveLogo = async (url: string | null) => {
    try {
      const saved = await businessAPI.update({ logoUrl: url });
      onlyLogo.current = true;
      setStored(saved);
      toast.success(url ? t('settings:logo_guardado') : t('settings:logo_quitado'));
    } catch (err: any) {
      toast.error(err.message || t('onboarding:error_guardar'));
    }
  };

  if (!form) {
    return (
      <div className="bg-white rounded-3xl p-8 border border-slate-200/80 flex justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-slate-400" aria-hidden />
      </div>
    );
  }

  const set = <K extends keyof Editable>(key: K, value: Editable[K]) => setForm({ ...form, [key]: value });

  const setTax = (taxType: TaxType, taxRate: number) => setForm({ ...form, defaultTaxType: taxType, defaultTaxRate: taxRate });

  const save = async () => {
    if (!form.businessName.trim()) {
      toast.warning(t('onboarding:error_nombre_negocio'));
      return;
    }
    setSaving(true);
    try {
      // Solo los campos editables (el servidor rechaza id, fechas u otros campos)
      const payload = Object.fromEntries(EDITABLE_FIELDS.map((k) => [k, form[k]])) as Partial<Editable>;
      const saved = await businessAPI.update({
        ...payload,
        email: form.email?.trim() || null,
        nit: form.nit?.replace(/[^0-9]/g, '') || null,
      });
      setStored(saved);
      onSaved?.(saved);
      toast.success(t('settings:negocio_guardado'));
    } catch (err: any) {
      toast.error(err.message || t('onboarding:error_guardar'));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-3xl shadow-sm p-6 sm:p-8 border border-slate-200/80 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <Building2 className="w-5 h-5 text-blue-600" aria-hidden />
            <div>
              <h3 className="text-base font-bold text-slate-900 font-heading">{t('settings:datos_comerciales_del_establecimiento')}</h3>
              <p className="text-xs text-slate-500">{t('settings:datos_negocio_compartidos')}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={save}
            disabled={saving}
            className="inline-flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-5 min-h-[44px] rounded-xl font-bold text-xs shadow-sm disabled:opacity-60"
          >
            {saving ? <Loader2 className="w-4 h-4 animate-spin" aria-hidden /> : <Save className="w-4 h-4" aria-hidden />}
            {t('settings:guardar_datos_del_negocio')}
          </button>
        </div>

        <ImageField
          kind="logo"
          id="bs-logo"
          label={t('settings:logo_del_negocio')}
          hint={t('settings:logo_del_negocio_hint')}
          value={form.logoUrl}
          onChange={saveLogo}
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div>
            <label htmlFor="bs-name" className={labelClass}>{t('onboarding:nombre_comercial')}</label>
            <input id="bs-name" className={inputClass} value={form.businessName} maxLength={120} onChange={(e) => set('businessName', e.target.value)} />
          </div>
          <div>
            <label htmlFor="bs-legal" className={labelClass}>{t('onboarding:razon_social')}</label>
            <input id="bs-legal" className={inputClass} value={form.legalName || ''} maxLength={160} onChange={(e) => set('legalName', e.target.value)} />
          </div>
          <div className="grid grid-cols-[1fr_5.5rem] gap-2">
            <div>
              <label htmlFor="bs-nit" className={labelClass}>{t('onboarding:nit_o_cedula')}</label>
              <input id="bs-nit" className={inputClass} value={form.nit || ''} inputMode="numeric" maxLength={15} onChange={(e) => set('nit', e.target.value.replace(/[^0-9.\s]/g, ''))} />
            </div>
            <div>
              <label htmlFor="bs-dv" className={labelClass}>{t('onboarding:dv')}</label>
              <input id="bs-dv" className={inputClass} value={form.dv || ''} inputMode="numeric" maxLength={1} onChange={(e) => set('dv', e.target.value.replace(/[^0-9]/g, ''))} />
            </div>
          </div>
          <div>
            <label htmlFor="bs-type" className={labelClass}>{t('onboarding:paso_tipo')}</label>
            <select id="bs-type" className={inputClass} value={form.businessType} onChange={(e) => set('businessType', e.target.value as Editable['businessType'])}>
              {BUSINESS_PRESETS.map((p) => (
                <option key={p.id} value={p.id}>{p.label}</option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="bs-address" className={labelClass}>{t('onboarding:direccion')}</label>
            <input id="bs-address" className={inputClass} value={form.address || ''} maxLength={200} onChange={(e) => set('address', e.target.value)} />
          </div>
          <div>
            <label htmlFor="bs-city" className={labelClass}>{t('onboarding:ciudad')}</label>
            <input id="bs-city" className={inputClass} value={form.city || ''} maxLength={80} onChange={(e) => set('city', e.target.value)} />
          </div>
          <div>
            <label htmlFor="bs-phone" className={labelClass}>{t('onboarding:telefono')}</label>
            <input id="bs-phone" className={inputClass} value={form.phone || ''} maxLength={40} inputMode="tel" onChange={(e) => set('phone', e.target.value)} />
          </div>
          <div>
            <label htmlFor="bs-email" className={labelClass}>{t('onboarding:correo')}</label>
            <input id="bs-email" type="email" className={inputClass} value={form.email || ''} maxLength={120} onChange={(e) => set('email', e.target.value)} />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-3xl shadow-sm p-6 sm:p-8 border border-slate-200/80 space-y-4">
        <div>
          <h3 className="text-base font-bold text-slate-900 font-heading">{t('onboarding:regimen_tributario')}</h3>
          <p className="text-xs text-slate-500">{t('settings:impuesto_por_defecto_desc')}</p>
        </div>
        <div role="radiogroup" aria-label={t('onboarding:regimen_tributario')} className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {TAX_REGIMES.map((r) => (
            <ChoiceCard
              key={r.id}
              active={form.taxRegime === r.id}
              onClick={() => {
                const tax = TAX_BY_REGIME[r.id];
                setForm({ ...form, taxRegime: r.id, defaultTaxType: tax.taxType, defaultTaxRate: tax.taxRate });
              }}
              title={r.label}
              description={r.description}
            />
          ))}
        </div>
        {form.defaultTaxType !== 'NONE' && (
          <div className="flex flex-wrap items-center gap-3">
            <label htmlFor="bs-taxrate" className="text-xs font-bold text-slate-700">
              {t('settings:tarifa_por_defecto', { tax: form.defaultTaxType === 'IVA' ? t('settings:iva') : t('settings:impoconsumo') })}
            </label>
            <input
              id="bs-taxrate"
              type="number"
              min={1}
              max={100}
              step="0.01"
              className={`${fieldClass} w-28`}
              value={form.defaultTaxRate}
              onChange={(e) => setTax(form.defaultTaxType, Number(e.target.value) || 0)}
            />
            <span className="text-sm font-bold text-slate-500">%</span>
            <span className="text-xs text-slate-500">{t('settings:cada_producto_puede_tener_otra')}</span>
          </div>
        )}
      </div>

      <div className="bg-white rounded-3xl shadow-sm p-6 sm:p-8 border border-slate-200/80 space-y-3">
        <div className="pb-1">
          <h3 className="text-base font-bold text-slate-900 font-heading">{t('onboarding:paso_operacion')}</h3>
          <p className="text-xs text-slate-500">{t('onboarding:operacion_desc')}</p>
        </div>
        <Toggle id="bs-tip" checked={form.tipEnabled} onChange={(v) => set('tipEnabled', v)} label={t('onboarding:manejas_propina')} description={t('onboarding:manejas_propina_desc')} />
        {form.tipEnabled && (
          <div className="flex items-center gap-3 px-1">
            <label htmlFor="bs-tip-pct" className="text-xs font-bold text-slate-700">{t('onboarding:porcentaje_sugerido')}</label>
            <input id="bs-tip-pct" type="number" min={0} max={30} className={`${fieldClass} w-24`} value={form.tipPercent} onChange={(e) => set('tipPercent', Math.min(30, Math.max(0, Number(e.target.value) || 0)))} />
            <span className="text-sm font-bold text-slate-500">%</span>
          </div>
        )}
        <ToggleGrid>
          <Toggle id="bs-inventory" checked={form.inventoryEnabled} onChange={(v) => set('inventoryEnabled', v)} label={t('onboarding:usas_inventario')} description={t('onboarding:usas_inventario_desc')} />
          <Toggle id="bs-delivery" checked={form.deliveryEnabled} onChange={(v) => set('deliveryEnabled', v)} label={t('onboarding:haces_domicilios')} description={t('onboarding:haces_domicilios_desc')} />
        </ToggleGrid>
      </div>

      {/* Canales de venta del plan Premium: se encienden aquí y aparecen en la pestaña Delivery */}
      <div className="bg-white rounded-3xl shadow-sm p-6 sm:p-8 border border-slate-200/80 space-y-3">
        <div className="pb-1">
          <h3 className="text-base font-bold text-slate-900 font-heading">{t('settings:canales_de_venta')}</h3>
          <p className="text-xs text-slate-500">{t('settings:canales_de_venta_desc')}</p>
        </div>
        {([
          ['whatsappEnabled', 'whatsapp', 'bs-whatsapp', 'canal_whatsapp'],
          ['rappiEnabled', 'delivery', 'bs-rappi', 'canal_rappi'],
        ] as const).map(([key, feature, id, label]) => {
          const included = plan.has(feature);
          return (
            <Toggle
              key={id}
              id={id}
              checked={!!form[key] && included}
              disabled={!included}
              onChange={(v) => set(key, v)}
              label={t(`settings:${label}`)}
              description={included ? t(`settings:${label}_desc`) : t('plan:disponible_en', { plan: t(`plan:plan_${FEATURE_PLAN[feature]}`) })}
              badge={
                <>
                  {!included && <Lock className="w-3.5 h-3.5 text-slate-400" aria-label={t('plan:no_incluido')} />}
                  <span className="rounded-full bg-amber-100 px-2 py-0.5 text-[0.7143rem] font-bold uppercase tracking-wide text-amber-800">{t('plan:proximamente')}</span>
                </>
              }
            />
          );
        })}
      </div>

      <div className="bg-white rounded-3xl shadow-sm p-6 border border-slate-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-sm font-bold text-slate-900">{t('settings:asistente_de_configuracion')}</h3>
          <p className="text-xs text-slate-500">{t('settings:asistente_de_configuracion_desc')}</p>
        </div>
        <button
          type="button"
          onClick={openOnboarding}
          className="inline-flex items-center justify-center gap-2 px-5 min-h-[44px] rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-50 font-bold text-xs shrink-0"
        >
          <Sparkles className="w-4 h-4" aria-hidden />
          {t('settings:abrir_asistente')}
        </button>
      </div>
    </div>
  );
}
