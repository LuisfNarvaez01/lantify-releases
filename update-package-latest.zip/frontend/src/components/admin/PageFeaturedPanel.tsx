// ============================================
// ADMIN - Mi página → Carta: favoritos de la casa
// ============================================
// Los productos que la página muestra arriba de la carta. Por defecto salen
// solos: los más vendidos de los últimos 60 días. El ADMIN puede elegirlos a
// mano (hasta 8) y ordenarlos.

import { useMemo, useState } from 'react';
import { ArrowDown, ArrowUp, Search, Star, X } from 'lucide-react';
import type { PageCatalogProduct } from '../../services/api';
import { mediaSrc } from '../../shared/media';
import { t } from '../../i18n';

const MAX = 8;

type Featured = { mode: 'auto' | 'manual'; productIds: string[] };

function Thumb({ p }: { p?: PageCatalogProduct }) {
  return p?.imageUrl
    ? <img src={mediaSrc(p.imageUrl)} alt="" className="h-9 w-9 shrink-0 rounded-lg object-cover border border-slate-200" />
    : <span aria-hidden className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-amber-50 text-amber-500"><Star className="h-4 w-4" /></span>;
}

export function PageFeaturedPanel({ card, catalog, bestSellers, value, onChange }: {
  card: string;
  catalog: PageCatalogProduct[];
  bestSellers: string[];
  value: Featured;
  onChange: (v: Featured) => void;
}) {
  const [q, setQ] = useState('');
  const byId = useMemo(() => new Map(catalog.map((p) => [p.id, p])), [catalog]);
  const chosen = value.productIds.filter((id) => byId.has(id));
  const auto = bestSellers.map((id) => byId.get(id)).filter((p): p is PageCatalogProduct => !!p && p.visible);
  const results = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return [];
    return catalog.filter((p) => p.visible && !chosen.includes(p.id) && `${p.name} ${p.categoryName}`.toLowerCase().includes(s)).slice(0, 8);
  }, [q, catalog, chosen]);

  const setIds = (productIds: string[]) => onChange({ mode: 'manual', productIds });
  const move = (i: number, d: -1 | 1) => {
    const next = [...chosen];
    [next[i], next[i + d]] = [next[i + d], next[i]];
    setIds(next);
  };

  return (
    <section className={card} aria-labelledby="favoritos-titulo">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="flex items-start gap-3">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-amber-100 text-amber-600" aria-hidden><Star className="h-5 w-5" /></span>
          <div>
            <h3 id="favoritos-titulo" className="text-base font-black text-slate-900">{t('page:fav_titulo')}</h3>
            <p className="mt-1 text-xs text-slate-500 max-w-xl">{t('page:fav_desc')}</p>
          </div>
        </div>
        <div className="inline-flex rounded-xl border border-slate-200 bg-white p-0.5" role="radiogroup" aria-label={t('page:fav_titulo')}>
          {(['auto', 'manual'] as const).map((m) => (
            <button key={m} type="button" role="radio" aria-checked={value.mode === m}
              onClick={() => onChange({ ...value, mode: m })}
              className={`rounded-lg px-3 py-1.5 text-xs font-bold ${value.mode === m ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-50'}`}>
              {t(`page:fav_modo_${m}`)}
            </button>
          ))}
        </div>
      </div>

      {value.mode === 'auto' ? (
        <div className="space-y-2">
          <p className="text-xs font-bold text-slate-600">{t('page:fav_auto_hoy')}</p>
          {auto.length ? (
            <ul className="flex flex-wrap gap-2">
              {auto.map((p) => (
                <li key={p.id} className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white py-1 pl-1 pr-3 text-sm font-semibold text-slate-800">
                  <Thumb p={p} /> {p.name}
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-slate-500">{t('page:fav_auto_vacio')}</p>
          )}
        </div>
      ) : (
        <div className="space-y-3">
          {chosen.length > 0 ? (
            <ol className="divide-y divide-slate-100 rounded-2xl border border-slate-200 bg-white">
              {chosen.map((id, i) => {
                const p = byId.get(id);
                return (
                  <li key={id} className="flex items-center gap-3 p-2.5">
                    <span className="w-5 text-center text-xs font-black text-slate-400 tabular-nums">{i + 1}</span>
                    <Thumb p={p} />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-bold text-slate-900">{p?.name}</p>
                      <p className="truncate text-xs text-slate-500">{p?.categoryName}{p && !p.visible ? ` · ${t('page:fav_oculto')}` : ''}</p>
                    </div>
                    <button type="button" onClick={() => move(i, -1)} disabled={i === 0} aria-label={t('page:fav_subir')} className="grid h-8 w-8 place-items-center rounded-lg text-slate-500 hover:bg-slate-100 disabled:opacity-30"><ArrowUp className="h-4 w-4" /></button>
                    <button type="button" onClick={() => move(i, 1)} disabled={i === chosen.length - 1} aria-label={t('page:fav_bajar')} className="grid h-8 w-8 place-items-center rounded-lg text-slate-500 hover:bg-slate-100 disabled:opacity-30"><ArrowDown className="h-4 w-4" /></button>
                    <button type="button" onClick={() => setIds(chosen.filter((x) => x !== id))} aria-label={t('page:fav_quitar', { name: p?.name || '' })} className="grid h-8 w-8 place-items-center rounded-lg text-slate-500 hover:bg-rose-50 hover:text-rose-700"><X className="h-4 w-4" /></button>
                  </li>
                );
              })}
            </ol>
          ) : (
            <p className="text-sm text-slate-500">{t('page:fav_manual_vacio')}</p>
          )}

          {chosen.length < MAX ? (
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-slate-400" aria-hidden />
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('page:fav_buscar', { left: MAX - chosen.length })} aria-label={t('page:fav_buscar', { left: MAX - chosen.length })}
                className="w-full min-h-[42px] rounded-xl border border-slate-200 bg-white pl-9 pr-3 text-sm focus:border-blue-600 focus:outline-none" />
              {results.length > 0 && (
                <ul className="mt-1 divide-y divide-slate-100 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
                  {results.map((p) => (
                    <li key={p.id}>
                      <button type="button" onClick={() => { setIds([...chosen, p.id]); setQ(''); }}
                        className="flex w-full items-center gap-3 p-2 text-left hover:bg-amber-50">
                        <Thumb p={p} />
                        <span className="min-w-0 flex-1">
                          <span className="block truncate text-sm font-bold text-slate-900">{p.name}</span>
                          <span className="block truncate text-xs text-slate-500">{p.categoryName}</span>
                        </span>
                        <Star className="h-4 w-4 text-amber-500" aria-hidden />
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          ) : (
            <p className="text-xs text-slate-500">{t('page:fav_max', { max: MAX })}</p>
          )}
          {chosen.length === 0 && <p className="text-xs text-slate-500">{t('page:fav_manual_nota')}</p>}
        </div>
      )}
    </section>
  );
}
