// ============================================
// ADMIN - Plan y suscripción (Configuración)
// ============================================
// Lo que dice la licencia firmada: plan, estado de pago, funciones incluidas
// y la última sincronización con Lantify Cloud. Más la exportación de datos.

import { useEffect } from 'react';
import { Check, Lock, RefreshCw } from 'lucide-react';
import { usePlanStore, FEATURE_PLAN, PLAN_PRICE, PlanCode, hasFeature, daysUntil } from '../../shared/plan';
import { exportAPI } from '../../services/api';
import { formatCurrency } from '../../shared/formatUtils';
import { ExportDataButtons } from '../common/ExportDataButtons';
import { getLocale, t } from '../../i18n';

// Lo que se muestra en la lista (las funciones base de todos los planes van aparte)
const LISTED = ['customers', 'dian', 'analytics_adv', 'inventory', 'multi_terminal', 'ai_copilot', 'expense_ocr', 'suppliers', 'coupons', 'ai_agents', 'delivery', 'whatsapp', 'webstore'];

const STATUS_TONE: Record<string, string> = {
  TRIAL: 'bg-info-soft text-info-text border-info-border',
  ACTIVE: 'bg-success-soft text-success-text border-success-border',
  PAST_DUE: 'bg-warning-soft text-warning-text border-warning-border',
  GRACE: 'bg-danger-soft text-danger-text border-danger-border',
  SUSPENDED: 'bg-danger-soft text-danger-text border-danger-border',
};

const fmtDate = (iso?: string | null, withTime = false) =>
  iso ? new Date(iso).toLocaleString(getLocale(), withTime ? { dateStyle: 'medium', timeStyle: 'short' } : { dateStyle: 'long' }) : '—';

export function SubscriptionPanel() {
  const info = usePlanStore((s) => s.info);
  const load = usePlanStore((s) => s.load);
  useEffect(() => {
    load();
  }, [load]);

  const exportSection = (
    <section className="bg-surface border border-line rounded-2xl p-6">
      <h3 className="text-sm font-bold text-fg">{t('plan:tus_datos')}</h3>
      <p className="mt-1 text-xs text-fg-secondary leading-relaxed">{t('plan:tus_datos_desc')}</p>
      <ExportDataButtons className="mt-4" getToken={async () => (await exportAPI.token()).exportToken} />
    </section>
  );

  if (!info?.linked) {
    return (
      <div className="space-y-4 max-w-3xl">
        <section className="bg-surface border border-line rounded-2xl p-6">
          <h3 className="text-sm font-bold text-fg">{t('plan:sin_vincular')}</h3>
          <p className="mt-1 text-xs text-fg-secondary leading-relaxed">{t('plan:sin_vincular_desc')}</p>
        </section>
        {exportSection}
      </div>
    );
  }

  const plan = (info.plan || 'basic') as PlanCode;
  const status = info.subStatus || 'ACTIVE';
  const days = daysUntil(info.periodEnd);

  return (
    <div className="space-y-4 max-w-3xl">
      <section className="bg-surface border border-line rounded-2xl p-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-fg-muted">{info.tenant?.name}</p>
            <h3 className="mt-1 text-xl font-bold text-fg">{t('plan:plan_nombre', { plan: t(`plan:plan_${plan}`) })}</h3>
            <p className="mt-1 text-sm text-fg-secondary tabular-nums">{t('plan:precio_mes', { price: formatCurrency(PLAN_PRICE[plan]) })}</p>
          </div>
          <span className={`inline-flex items-center px-3 py-1 rounded-full border text-xs font-bold ${STATUS_TONE[status]}`}>
            {t(`plan:estado_${status}`)}
          </span>
        </div>

        <dl className="mt-5 grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
          <div>
            <dt className="text-xs text-fg-muted">{status === 'TRIAL' ? t('plan:prueba_hasta') : t('plan:pagado_hasta')}</dt>
            <dd className="mt-0.5 font-semibold text-fg">
              {fmtDate(info.periodEnd)}
              {days !== null && days > 0 && <span className="ml-1 font-normal text-fg-muted">({t('plan:en_dias', { count: days })})</span>}
            </dd>
          </div>
          {(status === 'PAST_DUE' || status === 'GRACE') && (
            <div>
              <dt className="text-xs text-fg-muted">{t('plan:se_suspende')}</dt>
              <dd className="mt-0.5 font-semibold text-danger-text">{fmtDate(info.graceUntil)}</dd>
            </div>
          )}
          <div>
            <dt className="text-xs text-fg-muted">{t('plan:ultima_sincronizacion')}</dt>
            <dd className="mt-0.5 font-semibold text-fg">{fmtDate(info.lastSyncAt, true)}</dd>
          </div>
        </dl>
        <p className="mt-4 text-xs text-fg-muted leading-relaxed">{t('plan:como_cambiar')}</p>
      </section>

      <section className="bg-surface border border-line rounded-2xl p-6">
        <div className="flex items-center justify-between gap-3">
          <h3 className="text-sm font-bold text-fg">{t('plan:funciones')}</h3>
          <button
            type="button"
            onClick={() => load()}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-primary-text hover:underline"
          >
            <RefreshCw className="w-3.5 h-3.5" aria-hidden />
            {t('plan:actualizar')}
          </button>
        </div>
        <ul className="mt-3 divide-y divide-line">
          {LISTED.map((f) => {
            const included = hasFeature(info, f);
            return (
              <li key={f} className="flex items-center gap-3 py-2.5 text-sm">
                {included
                  ? <Check className="w-4 h-4 text-success-text shrink-0" aria-hidden />
                  : <Lock className="w-4 h-4 text-fg-subtle shrink-0" aria-hidden />}
                <span className={`flex-1 ${included ? 'text-fg' : 'text-fg-muted'}`}>{t(`plan:f_${f}`)}</span>
                {!included && (
                  <span className="text-xs font-semibold text-primary-text">{t(`plan:plan_${FEATURE_PLAN[f] || 'pro'}`)}</span>
                )}
                <span className="sr-only">{included ? t('plan:incluido') : t('plan:no_incluido')}</span>
              </li>
            );
          })}
        </ul>
      </section>

      {exportSection}
    </div>
  );
}
