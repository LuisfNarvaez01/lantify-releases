// ============================================
// ADMIN - Personal → Horario de la semana (Fase 4 · mejoras)
// ============================================
// Antes el horario se armaba empleado por empleado y turno por turno. Ahora es
// una cuadrícula (personas × días) que se pinta con turnos tipo, como marcar
// casillas: eliges "Mañana" y tocas (o arrastras sobre) las casillas. Tocar el
// nombre llena toda la semana; tocar el día lo llena para todo el equipo. Abajo
// se ve cuántas personas hay cada día y, por persona, las horas y lo que cuesta.

import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Eraser, Paintbrush, Pencil, Plus, Trash2, Undo2 } from 'lucide-react';
import { t, getLocale } from '../../i18n';
import { toast } from '../../shared/toast';
import { Button } from '../common/Button';
import { attendanceAPI, featuresAPI, type Employee, type ScheduleSlot } from '../../services/v3Api';
import { errorMessage } from '../../services/apiErrors';
import { formatCurrency } from '../../shared/formatUtils';
import { useFeatures } from '../../shared/features';
import type { ShiftTemplate } from '../../../../src/domain/v3/features';

// Lunes primero, como se piensa la semana en el local
const WEEK = [1, 2, 3, 4, 5, 6, 0];
const dayShort = (d: number) => new Date(2026, 10, 22 + d).toLocaleDateString(getLocale(), { weekday: 'short' });
const ERASER = '__erase';
const TONES = ['bg-sky-100 text-sky-900 ring-sky-300', 'bg-amber-100 text-amber-900 ring-amber-300', 'bg-violet-100 text-violet-900 ring-violet-300', 'bg-emerald-100 text-emerald-900 ring-emerald-300', 'bg-rose-100 text-rose-900 ring-rose-300', 'bg-lime-100 text-lime-900 ring-lime-300', 'bg-cyan-100 text-cyan-900 ring-cyan-300', 'bg-orange-100 text-orange-900 ring-orange-300'];
const field = 'rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 min-h-[40px] focus:outline-none focus:ring-2 focus:ring-blue-500/40';

type Cell = { start: string; end: string }[];
type Grid = Record<string, Record<number, Cell>>;

/** Minutos de un turno (si termina antes de empezar, pasa la medianoche) */
const minutesOf = (s: { start: string; end: string }) => {
  const [a, b] = [s.start, s.end].map((x) => { const [h, m] = x.split(':').map(Number); return h * 60 + m; });
  return b > a ? b - a : 24 * 60 - a + b;
};
const sameSlot = (a: { start: string; end: string }, b: { start: string; end: string }) => a.start === b.start && a.end === b.end;
const hm = (min: number) => (min % 60 ? `${Math.floor(min / 60)} h ${min % 60}` : `${min / 60} h`);

function TemplatesEditor({ templates, onClose }: { templates: ShiftTemplate[]; onClose: () => void }) {
  const [list, setList] = useState<ShiftTemplate[]>(templates.map((x) => ({ ...x })));
  const [busy, setBusy] = useState(false);
  const save = async () => {
    setBusy(true);
    try {
      await featuresAPI.save({ shiftTemplates: list } as any);
      await useFeatures.getState().load();
      toast.success(t('v3:guardado'));
      onClose();
    } catch (err) { toast.error(errorMessage(err)); } finally { setBusy(false); }
  };
  return (
    <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 space-y-3">
      <p className="text-sm font-bold text-slate-900">{t('v3:hor_turnos_tipo')}</p>
      {list.map((x, i) => (
        <div key={x.id} className="flex flex-wrap items-center gap-2">
          <input className={`${field} w-36`} maxLength={24} value={x.name} aria-label={t('v3:nombre')} onChange={(e) => setList((l) => l.map((y, j) => (j === i ? { ...y, name: e.target.value } : y)))} />
          <input type="time" className={field} value={x.start} aria-label={t('v3:asis_entra')} onChange={(e) => setList((l) => l.map((y, j) => (j === i ? { ...y, start: e.target.value } : y)))} />
          <span className="text-slate-400">–</span>
          <input type="time" className={field} value={x.end} aria-label={t('v3:asis_sale')} onChange={(e) => setList((l) => l.map((y, j) => (j === i ? { ...y, end: e.target.value } : y)))} />
          <span className="text-xs text-slate-500">{hm(minutesOf(x))}</span>
          <button type="button" onClick={() => setList((l) => l.filter((_, j) => j !== i))} className="rounded-xl p-2 text-slate-400 hover:bg-rose-50 hover:text-rose-700" aria-label={t('v3:quitar')}><Trash2 className="h-4 w-4" /></button>
        </div>
      ))}
      <div className="flex flex-wrap gap-2">
        {list.length < 8 && <Button size="sm" variant="outline" leftIcon={<Plus className="h-4 w-4" />} onClick={() => setList((l) => [...l, { id: `t${Date.now().toString(36)}`, name: t('v3:hor_turno_nuevo'), start: '10:00', end: '18:00' }])}>{t('v3:hor_agregar_tipo')}</Button>}
        <span className="flex-1" />
        <Button size="sm" variant="ghost" onClick={onClose}>{t('v3:cancelar')}</Button>
        <Button size="sm" isLoading={busy} onClick={save}>{t('v3:guardar')}</Button>
      </div>
    </div>
  );
}

export const ScheduleTab: React.FC<{ team: Employee[] }> = ({ team }) => {
  const templates = useFeatures((s) => (s.settings as any).shiftTemplates as ShiftTemplate[] | undefined) || [];
  const active = useMemo(() => team.filter((e) => e.isActive), [team]);
  const [saved, setSaved] = useState<Grid>({});
  const [grid, setGrid] = useState<Grid>({});
  const [brush, setBrush] = useState<string>('');
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const painting = useRef<null | 'add' | 'remove'>(null);

  useEffect(() => { if (!brush && templates[0]) setBrush(templates[0].id); }, [templates, brush]);

  const toGrid = (slots: ScheduleSlot[]) => {
    const g: Grid = {};
    for (const s of slots) {
      if (!s.employeeId) continue;
      g[s.employeeId] ||= {};
      (g[s.employeeId][s.weekday] ||= []).push({ start: s.start, end: s.end });
    }
    return g;
  };
  useEffect(() => {
    attendanceAPI.schedule().then((all) => { const g = toGrid(all); setSaved(g); setGrid(g); }).catch((err) => toast.error(errorMessage(err))).finally(() => setLoaded(true));
  }, []);

  const tone = (slot: { start: string; end: string }) => {
    const i = templates.findIndex((x) => sameSlot(x, slot));
    return i >= 0 ? TONES[i % TONES.length] : 'bg-slate-100 text-slate-800 ring-slate-300';
  };
  const label = (slot: { start: string; end: string }) => templates.find((x) => sameSlot(x, slot))?.name || `${slot.start}–${slot.end}`;
  const brushSlot = brush === ERASER ? null : templates.find((x) => x.id === brush) || null;
  const cell = (g: Grid, emp: string, d: number): Cell => g[emp]?.[d] || [];

  /** Pinta una casilla: con turno, la deja con ese turno; con borrador, la vacía */
  const paint = useCallback((g: Grid, emp: string, d: number, mode: 'add' | 'remove'): Grid => {
    const next = { ...g, [emp]: { ...(g[emp] || {}) } };
    if (mode === 'remove' || !brushSlot) next[emp][d] = [];
    else next[emp][d] = [{ start: brushSlot.start, end: brushSlot.end }];
    return next;
  }, [brushSlot]);

  const has = (g: Grid, emp: string, d: number) => (brushSlot ? cell(g, emp, d).some((s) => sameSlot(s, brushSlot)) : cell(g, emp, d).length === 0);

  const down = (emp: string, d: number) => {
    const mode: 'add' | 'remove' = !brushSlot || has(grid, emp, d) ? 'remove' : 'add';
    painting.current = mode;
    setGrid((g) => paint(g, emp, d, mode));
  };
  const enter = (emp: string, d: number) => { if (painting.current) setGrid((g) => paint(g, emp, d, painting.current!)); };
  useEffect(() => {
    const up = () => { painting.current = null; };
    window.addEventListener('pointerup', up);
    return () => window.removeEventListener('pointerup', up);
  }, []);

  const fillRow = (emp: string) => setGrid((g) => {
    const all = WEEK.every((d) => has(g, emp, d));
    return WEEK.reduce((acc, d) => paint(acc, emp, d, brushSlot && !all ? 'add' : 'remove'), g);
  });
  const fillDay = (d: number) => setGrid((g) => {
    const all = active.every((e) => has(g, e.id, d));
    return active.reduce((acc, e) => paint(acc, e.id, d, brushSlot && !all ? 'add' : 'remove'), g);
  });
  /** Copia el lunes de esa persona en el resto de la semana */
  const copyMonday = (emp: string) => setGrid((g) => ({ ...g, [emp]: Object.fromEntries(WEEK.map((d) => [d, [...cell(g, emp, 1)]])) }));

  const dirty = useMemo(() => active.filter((e) => JSON.stringify(WEEK.map((d) => cell(grid, e.id, d))) !== JSON.stringify(WEEK.map((d) => cell(saved, e.id, d)))), [active, grid, saved]);

  const save = async () => {
    setSaving(true);
    try {
      for (const e of dirty) {
        const slots = WEEK.flatMap((d) => cell(grid, e.id, d).map((s) => ({ weekday: d, start: s.start, end: s.end })));
        await attendanceAPI.setSchedule(e.id, slots);
      }
      setSaved(grid);
      toast.success(t('v3:hor_guardado', { count: dirty.length }));
    } catch (err) { toast.error(errorMessage(err)); } finally { setSaving(false); }
  };

  const weekMin = (emp: string) => WEEK.reduce((n, d) => n + cell(grid, emp, d).reduce((m, s) => m + minutesOf(s), 0), 0);
  const weekShifts = (emp: string) => WEEK.reduce((n, d) => n + cell(grid, emp, d).length, 0);
  /** Lo que cuesta la semana programada según cómo se le paga */
  const cost = (e: Employee) => (e.payType === 'HOUR' ? (weekMin(e.id) / 60) * e.payAmount : e.payType === 'SHIFT' ? weekShifts(e.id) * e.payAmount : null);
  const total = active.reduce((n, e) => n + (cost(e) || 0), 0);
  const perDay = (d: number) => active.filter((e) => cell(grid, e.id, d).length > 0).length;

  if (!active.length) return <p className="rounded-3xl border border-slate-200 bg-white p-6 text-sm text-slate-500">{t('v3:hor_sin_equipo')}</p>;

  return (
    <section className="space-y-4 rounded-3xl border border-slate-200/80 bg-white p-5 shadow-sm" aria-labelledby="hor-titulo">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 id="hor-titulo" className="text-base font-bold text-slate-900">{t('v3:hor_titulo')}</h3>
          <p className="max-w-2xl text-sm text-slate-500">{t('v3:hor_desc')}</p>
        </div>
      </div>

      {/* Pincel: el turno con el que se pintan las casillas */}
      <div className="flex flex-wrap items-center gap-2" role="radiogroup" aria-label={t('v3:hor_pincel')}>
        <Paintbrush className="h-4 w-4 text-slate-400" aria-hidden />
        {templates.map((x, i) => (
          <button key={x.id} type="button" role="radio" aria-checked={brush === x.id} onClick={() => setBrush(x.id)} className={`inline-flex min-h-[40px] items-center gap-2 rounded-xl px-3 text-sm font-bold ring-1 transition ${TONES[i % TONES.length]} ${brush === x.id ? 'ring-2 ring-offset-2 ring-offset-white scale-[1.03] shadow-sm' : 'opacity-80 hover:opacity-100'}`}>
            {x.name}<span className="font-semibold opacity-70">{x.start}–{x.end}</span>
          </button>
        ))}
        <button type="button" role="radio" aria-checked={brush === ERASER} onClick={() => setBrush(ERASER)} className={`inline-flex min-h-[40px] items-center gap-1.5 rounded-xl px-3 text-sm font-bold ring-1 ring-slate-300 transition ${brush === ERASER ? 'bg-slate-900 text-white ring-2' : 'bg-white text-slate-700 hover:bg-slate-50'}`}>
          <Eraser className="h-4 w-4" aria-hidden />{t('v3:asis_descanso')}
        </button>
        <button type="button" onClick={() => setEditing((v) => !v)} className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl px-3 text-sm font-bold text-blue-700 hover:bg-blue-50"><Pencil className="h-4 w-4" aria-hidden />{t('v3:hor_editar_tipos')}</button>
      </div>
      {editing && <TemplatesEditor templates={templates} onClose={() => setEditing(false)} />}

      <div className="overflow-x-auto rounded-2xl border border-slate-200">
        <table className="w-full min-w-[760px] table-fixed select-none border-collapse text-sm">
          <colgroup><col className="w-[11rem]" />{WEEK.map((d) => <col key={d} />)}<col className="w-[8rem]" /></colgroup>
          <thead className="bg-slate-50">
            <tr>
              <th className="px-3 py-2 text-left text-xs font-bold uppercase tracking-wider text-slate-500">{t('v3:empleado')}</th>
              {WEEK.map((d) => (
                <th key={d} className="px-1 py-2">
                  <button type="button" onClick={() => fillDay(d)} className="w-full rounded-lg px-2 py-1 text-xs font-black uppercase text-slate-700 hover:bg-slate-200" title={t('v3:hor_llenar_dia')} aria-label={`${dayShort(d)}: ${t('v3:hor_llenar_dia')}`}>{dayShort(d)}</button>
                </th>
              ))}
              <th className="px-3 py-2 text-right text-xs font-bold uppercase tracking-wider text-slate-500">{t('v3:hor_semana')}</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {active.map((e) => {
              const c = cost(e);
              return (
                <tr key={e.id}>
                  <th scope="row" className="px-3 py-2 text-left">
                    <button type="button" onClick={() => fillRow(e.id)} className="max-w-[11rem] truncate rounded-lg px-1 text-left font-bold text-slate-900 hover:text-blue-700" title={t('v3:hor_llenar_semana')}>{e.name}</button>
                    <span className="block px-1 text-xs font-normal text-slate-500">{t(`v3:puesto_${e.position}`)}</span>
                  </th>
                  {WEEK.map((d) => {
                    const slots = cell(grid, e.id, d);
                    return (
                      <td key={d} className="p-1">
                        <button
                          type="button"
                          onPointerDown={(ev) => { ev.preventDefault(); down(e.id, d); }}
                          onPointerEnter={() => enter(e.id, d)}
                          onKeyDown={(ev) => { if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); down(e.id, d); painting.current = null; } }}
                          aria-label={`${e.name}, ${dayShort(d)}: ${slots.length ? slots.map(label).join(', ') : t('v3:asis_descanso')}`}
                          className={`flex min-h-[52px] w-full flex-col items-center justify-center gap-0.5 rounded-xl text-xs font-bold transition hover:ring-2 hover:ring-blue-400 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 ${slots.length ? '' : 'border border-dashed border-slate-200 text-slate-300'}`}
                        >
                          {slots.length === 0 ? '—' : slots.map((s, i) => (
                            <span key={i} className={`display-pop w-full rounded-lg px-1 py-1 ring-1 ${tone(s)}`}>
                              <span className="block truncate">{label(s)}</span>
                              <span className="block text-[10px] font-semibold opacity-70">{s.start}–{s.end}</span>
                            </span>
                          ))}
                        </button>
                      </td>
                    );
                  })}
                  <td className="px-3 py-2 text-right">
                    <span className="block font-bold tabular-nums text-slate-900">{hm(weekMin(e.id))}</span>
                    <span className="block text-xs tabular-nums text-slate-500">{c !== null ? formatCurrency(c) : t('v3:hor_fijo')}</span>
                    {cell(grid, e.id, 1).length > 0 && <button type="button" onClick={() => copyMonday(e.id)} className="mt-0.5 text-[11px] font-bold text-blue-700 hover:underline">{t('v3:hor_copiar_lunes')}</button>}
                  </td>
                </tr>
              );
            })}
          </tbody>
          <tfoot className="border-t border-slate-200 bg-slate-50">
            <tr>
              <th scope="row" className="px-3 py-2 text-left text-xs font-bold text-slate-600">{t('v3:hor_personas_dia')}</th>
              {WEEK.map((d) => <td key={d} className="px-1 py-2 text-center text-sm font-black tabular-nums text-slate-800">{perDay(d)}</td>)}
              <td className="px-3 py-2 text-right text-sm font-black tabular-nums text-slate-900">{formatCurrency(total)}</td>
            </tr>
          </tfoot>
        </table>
      </div>
      {!loaded && <p className="text-sm text-slate-500">{t('v3:cargando')}</p>}
      {/* Guardar siempre en el mismo lugar (abajo y pegado al borde), para que nada se mueva al pintar */}
      <div className="sticky bottom-3 z-10 flex flex-wrap items-center justify-end gap-2 rounded-2xl border border-slate-200 bg-white/95 p-2 shadow-lg backdrop-blur">
        <span className="mr-auto px-2 text-sm text-slate-600">{dirty.length ? t('v3:hor_sin_guardar', { count: dirty.length }) : t('v3:hor_todo_guardado')}</span>
        {dirty.length > 0 && <Button variant="ghost" leftIcon={<Undo2 className="h-4 w-4" />} onClick={() => setGrid(saved)}>{t('v3:hor_deshacer')}</Button>}
        <Button onClick={save} isLoading={saving} disabled={!dirty.length}>{t('v3:guardar')}</Button>
      </div>
      <p className="text-xs text-slate-500">{t('v3:hor_ayuda')}</p>
    </section>
  );
};
