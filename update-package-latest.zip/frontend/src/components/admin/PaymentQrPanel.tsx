// ============================================
// ADMIN - Ajustes → Pagos: QR de pago del negocio (Fase 4)
// ============================================
// La imagen del QR de Nequi, Daviplata o Bre-B que el negocio ya tiene. Se muestra
// en la pantalla del cliente y en el kiosco. Lantify no cobra ni ve el pago: el
// cliente paga con su app y la caja confirma como siempre.

import { useEffect, useState } from 'react';
import { QrCode } from 'lucide-react';
import { t } from '../../i18n';
import { businessAPI } from '../../services/api';
import { useBusinessStore } from '../../shared/business';
import { toast } from '../../shared/toast';
import { ImageField } from '../common/ImageField';
import { Button } from '../common/Button';

const field = 'w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-slate-900 outline-none text-sm font-medium';

export function PaymentQrPanel() {
  const stored = useBusinessStore((s) => s.settings);
  const setStored = useBusinessStore((s) => s.setSettings);
  const [label, setLabel] = useState(stored?.paymentQrLabel || '');
  const [busy, setBusy] = useState(false);
  useEffect(() => { setLabel(stored?.paymentQrLabel || ''); }, [stored?.paymentQrLabel]);
  if (!stored) return null;

  const save = async (data: { paymentQrUrl?: string | null; paymentQrLabel?: string | null }, ok: string) => {
    setBusy(true);
    try {
      setStored(await businessAPI.update(data));
      toast.success(ok);
    } catch (err: any) {
      toast.error(err?.message || t('v3:no_se_guardo'));
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="bg-white rounded-3xl shadow-sm p-6 sm:p-8 border border-slate-200/80 space-y-4" aria-labelledby="pagos-title">
      <div className="flex items-start gap-3">
        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-blue-50 text-blue-700"><QrCode className="h-5 w-5" aria-hidden /></span>
        <div>
          <h3 id="pagos-title" className="text-base font-bold text-slate-900 font-heading">{t('v3:pagos_titulo')}</h3>
          <p className="text-sm text-slate-500">{t('v3:pagos_desc')}</p>
        </div>
      </div>
      <ImageField
        kind="logo"
        id="pay-qr"
        label={t('v3:pagos_qr')}
        hint={t('v3:pagos_qr_hint')}
        value={stored.paymentQrUrl}
        onChange={(url) => save({ paymentQrUrl: url }, url ? t('v3:pagos_qr_ok') : t('v3:pagos_qr_quitado'))}
      />
      <div className="flex flex-wrap items-end gap-3">
        <label className="flex-1 min-w-[14rem] space-y-1 text-xs font-bold text-slate-700">{t('v3:pagos_texto')}
          <input className={field} maxLength={60} value={label} onChange={(e) => setLabel(e.target.value)} placeholder={t('v3:pagos_texto_ej')} />
        </label>
        <Button onClick={() => save({ paymentQrLabel: label.trim() || null }, t('v3:guardado'))} isLoading={busy} disabled={label === (stored.paymentQrLabel || '')}>{t('v3:guardar')}</Button>
      </div>
    </section>
  );
}
