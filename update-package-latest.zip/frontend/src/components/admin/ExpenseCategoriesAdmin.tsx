import React, { useState, useEffect } from 'react';
import { confirmDialog } from '../../shared/dialog';
import { expenseCategoriesAPI } from '../../services/api';
import { ExpenseCategory } from '../../types';
import { Plus, Edit2, Trash2, FolderPlus, Palette, Tag, X, Check } from 'lucide-react';
import { toast } from '../../shared/toast';


import { t } from '../../i18n';
const PRESET_COLORS = [
  '#2563eb', // Lantify Blue (Primary)
  '#0284c7', // Sky
  '#10b981', // Emerald
  '#f59e0b', // Amber
  '#ef4444', // Red
  '#8b5cf6', // Violet
  '#ec4899', // Pink
  '#0f172a', // Slate Dark
  '#64748b'  // Slate Gray
];

export const ExpenseCategoriesAdmin: React.FC = () => {
  const [categories, setCategories] = useState<ExpenseCategory[]>([]);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<ExpenseCategory | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Form State
  const [form, setForm] = useState({
    name: '',
    description: '',
    color: '#2563eb'
  });

  useEffect(() => {
    loadCategories();
  }, []);

  const loadCategories = async () => {
    try {
      const data = await expenseCategoriesAPI.getAll();
      setCategories(data);
    } catch (err) {
      console.error('Error loading expense categories:', err);
    }
  };

  const openCreateForm = () => {
    setEditingCategory(null);
    setForm({
      name: '',
      description: '',
      color: '#2563eb'
    });
    setError(null);
    setIsFormOpen(true);
  };

  const openEditForm = (cat: ExpenseCategory) => {
    setEditingCategory(cat);
    setForm({
      name: cat.name,
      description: cat.description || '',
      color: cat.color || '#2563eb'
    });
    setError(null);
    setIsFormOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!form.name.trim()) {
      setError(t('admin:el_nombre_de_la_categoria_es_obligatorio'));
      return;
    }

    try {
      if (editingCategory) {
        await expenseCategoriesAPI.update(editingCategory.id, form);
      } else {
        await expenseCategoriesAPI.create(form);
      }
      setIsFormOpen(false);
      loadCategories();
    } catch (err: any) {
      console.error('Error saving expense category:', err);
      setError(err.message || t('admin:error_al_guardar_la_categoria'));
    }
  };

  const handleDelete = async (cat: ExpenseCategory) => {
    const expenseCount = (cat as any)._count?.expenses || 0;
    
    const confirmMsg = expenseCount > 0
      ? t('admin:tiene_expensecount_egresos_asociados_los_egresos_s', { expenseCount })
      : t('admin:no_podras_elegirla_para_egresos_nuevos');

    if (!(await confirmDialog({ title: t('admin:desactivar_la_categoria_name', { name: cat.name }), message: confirmMsg, confirmLabel: t('admin:desactivar'), tone: 'danger' }))) return;

    try {
      await expenseCategoriesAPI.delete(cat.id);
      toast.success(t('admin:categoria_name_desactivada', { name: cat.name }));
      loadCategories();
    } catch (err: any) {
      console.error('Error deactivating expense category:', err);
      toast.error(err.message || 'Error al desactivar la categoría');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Panel */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm flex flex-col md:flex-row gap-4 items-center justify-between">
        <div>
          <h3 className="font-bold text-lg text-slate-900 font-heading flex items-center gap-2">
            <Tag className="w-5 h-5 text-blue-600" />
            {t('admin:categorias_de_egresos_y_gastos')}
          </h3>
          <p className="text-xs text-slate-500 mt-1 font-medium">
            {t('admin:clasifica_tus_comprobantes_y_gastos_para_informes')}
          </p>
        </div>
        
        <button
          onClick={openCreateForm}
          className="w-full md:w-auto flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-2xl font-bold transition-all shadow-sm"
        >
          <Plus className="w-5 h-5" />
          {t('admin:nueva_categoria')}
        </button>
      </div>

      {/* Categories Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {categories.length === 0 ? (
          <div className="col-span-full bg-white p-12 rounded-3xl border border-slate-200 text-center text-slate-400 font-medium">
            {t('admin:no_hay_categorias_de_egresos_registradas')}
          </div>
        ) : (
          categories.map((cat) => {
            const expenseCount = (cat as any)._count?.expenses || 0;
            return (
              <div
                key={cat.id}
                className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between"
              >
                <div className="space-y-3">
                  <div className="flex justify-between items-start">
                    <div className="flex items-center gap-2.5">
                      <span
                        className="w-4 h-4 rounded-full shadow-inner border border-white"
                        style={{ backgroundColor: cat.color || '#64748b' }}
                      />
                      <h4 className="font-bold text-base text-slate-900">{cat.name}</h4>
                    </div>
                    <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700">
                      {expenseCount === 1 ? t('admin:1_egreso') : t('admin:expensecount_egresos', { expenseCount })}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 font-medium leading-relaxed">
                    {cat.description || <span className="text-slate-400 italic">{t('admin:sin_descripcion')}</span>}
                  </p>
                </div>

                <div className="flex justify-end gap-1.5 border-t border-slate-100 pt-4 mt-4">
                  <button
                    onClick={() => openEditForm(cat)}
                    className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                    title={t('admin:editar')}
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(cat)}
                    className="p-2 text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                    title={t('admin:eliminar')}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Category Form Modal */}
      {isFormOpen && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center z-[100] p-4">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden border border-slate-200">
            <div className="bg-slate-900 px-6 py-4 flex justify-between items-center text-white">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-blue-600 rounded-xl text-white shadow-sm">
                  <FolderPlus className="w-5 h-5" />
                </div>
                <h3 className="text-base font-bold font-heading">
                  {editingCategory ? t('admin:editar_categoria_de_egreso') : t('admin:registrar_nueva_categoria')}
                </h3>
              </div>
              <button
                onClick={() => setIsFormOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {error && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold rounded-xl">
                  {error}
                </div>
              )}

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 ml-1">{t('admin:nombre_de_la_categoria')}</label>
                <input
                  type="text"
                  required
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder={t('admin:ej_aseo_hielo_insumos_servicios')}
                  className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-slate-900 outline-none text-sm"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 ml-1">{t('admin:descripcion')}</label>
                <textarea
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                  placeholder={t('admin:ej_compras_de_articulos_de_aseo_e')}
                  rows={3}
                  className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-slate-900 outline-none text-sm"
                />
              </div>

              {/* Color Picker */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-700 ml-1 flex items-center gap-1">
                  <Palette className="w-3.5 h-3.5 text-blue-600" />
                  {t('admin:color_identificador')}
                </label>
                <div className="flex flex-wrap gap-2.5 p-3.5 bg-slate-50 border border-slate-200 rounded-2xl">
                  {PRESET_COLORS.map((color) => (
                    <button
                      key={color}
                      type="button"
                      onClick={() => setForm({ ...form, color })}
                      className="w-8 h-8 rounded-full border border-slate-300 flex items-center justify-center transition-transform hover:scale-110 relative"
                      style={{ backgroundColor: color }}
                    >
                      {form.color === color && (
                        <Check className="w-4 h-4 text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.5)]" />
                      )}
                    </button>
                  ))}
                  <div className="w-full flex items-center gap-2 mt-2 pt-2 border-t border-slate-200">
                    <span className="text-xs font-bold text-slate-500">{t('admin:codigo_hex')}</span>
                    <input
                      type="text"
                      value={form.color}
                      onChange={(e) => setForm({ ...form, color: e.target.value })}
                      className="w-24 px-2 py-1 text-xs border border-slate-200 rounded-lg text-slate-900 font-mono focus:ring-1 focus:ring-blue-500 outline-none"
                    />
                  </div>
                </div>
              </div>

              <div className="flex gap-3 pt-4 border-t border-slate-100">
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl font-bold shadow-sm transition-all text-sm"
                >
                  {editingCategory ? t('admin:actualizar_categoria') : t('admin:registrar_categoria')}
                </button>
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="flex-1 bg-white text-slate-700 border border-slate-300 py-3 rounded-xl font-bold hover:bg-slate-50 transition-all text-sm"
                >
                  {t('admin:cancelar')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
