// ============================================
// ADMIN - Mi página → Diseño
// ============================================
// Cómo se ve la página del negocio: un estilo base por tipo de negocio, colores,
// modo claro u oscuro, tipografía, esquinas, carta en tarjetas o en lista, portada
// y logo. "Recomendar con IA" propone todo a partir del nombre, el tipo de negocio
// y la carta (solo nombres); el dueño lo ajusta antes de publicar. La vista previa
// usa las mismas reglas de color que la página (src/domain/pageTheme.ts).

import { useEffect, useMemo, useState } from 'react';
import { Sparkles, Loader2, Palette, Wand2, UtensilsCrossed, Wine, Coffee, Flame, Check, Croissant, Music, Beef } from 'lucide-react';
import { pageAPI, businessAPI, PageState, PageTheme } from '../../services/api';
import { ImageField } from '../common/ImageField';
import { mediaSrc } from '../../shared/media';
import { useBusiness, useBusinessStore } from '../../shared/business';
import { errorMessage } from '../../services/apiErrors';
import { toast } from '../../shared/toast';
import { normalizeTheme, themeVars, THEME_PRESETS, THEME_PRESET_KEYS, THEME_FONTS, BUSINESS_TEMPLATES, BUSINESS_TEMPLATE_KEYS, BusinessTemplate } from '../../../../src/domain/pageTheme';
import { t, getLanguage } from '../../i18n';

const labelCls = 'text-xs font-bold text-slate-600';

function Segmented<T extends string>({ label, value, options, onChange }: { label: string; value: T; options: { v: T; text: string }[]; onChange: (v: T) => void }) {
  return (
    <div>
      <span className={labelCls}>{label}</span>
      <div className="mt-1 flex gap-1 rounded-xl border border-slate-200 p-1" role="radiogroup" aria-label={label}>
        {options.map((o) => (
          <button key={o.v} type="button" role="radio" aria-checked={value === o.v} onClick={() => onChange(o.v)}
            className={`flex-1 min-h-[34px] rounded-lg px-2 text-xs font-bold ${value === o.v ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'}`}>
            {o.text}
          </button>
        ))}
      </div>
    </div>
  );
}

/** Vista previa de la página con el tema (encabezado, portada y un plato) */
function Preview({ theme, name, tagline }: { theme: PageTheme; name: string; tagline: string | null }) {
  const v = themeVars(theme);
  const c = (k: string, a = 1) => `rgb(${v[k]} / ${a})`;
  const r = v['--lp-r'];
  const head = { fontFamily: THEME_FONTS[theme.font].family, fontStretch: theme.font === 'moderna' ? '112%' : 'normal' };
  const initials = name.split(/\s+/).filter((w) => w.length > 2).slice(0, 2).map((w) => w[0]).join('').toUpperCase() || name[0] || 'L';
  return (
    <div className="overflow-hidden rounded-2xl border border-slate-200 shadow-sm" style={{ background: c('--ground'), color: c('--ink') }} aria-label={t('page:vista_previa')}>
      <div className="flex items-center justify-between px-3 py-2" style={{ borderBottom: `1px solid ${c('--rule')}` }}>
        <span className="flex min-w-0 items-center gap-2">
          {theme.logoImage
            ? <img src={mediaSrc(theme.logoImage)} alt="" className="h-7 w-7 object-cover" style={{ borderRadius: r }} />
            : <span className="grid h-7 w-7 shrink-0 place-items-center text-[10px] font-black text-white" style={{ background: c('--brand'), borderRadius: r }}>{initials}</span>}
          <span className="truncate text-sm font-extrabold" style={head}>{name || t('page:prev_nombre')}</span>
        </span>
        <span className="shrink-0 whitespace-nowrap px-2.5 py-1 text-[10px] font-bold text-white" style={{ background: c('--brand'), borderRadius: r }}>{t('page:prev_pedido')}</span>
      </div>
      <div className="relative px-4 py-6 text-white" style={{ background: theme.coverImage ? `linear-gradient(100deg, ${c('--night', 0.94)}, ${c('--night', 0.3)}), url("${mediaSrc(theme.coverImage)}") center/cover` : `radial-gradient(120% 90% at 85% 10%, ${c('--accent', 0.35)}, transparent 55%), ${c('--night')}` }}>
        <span className="inline-block px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider mb-2 bg-white/20 backdrop-blur-sm border border-white/25">
          {(BUSINESS_TEMPLATES[theme.template] ?? BUSINESS_TEMPLATES.gourmet).category}
        </span>
        <p className="text-xl font-extrabold leading-tight" style={head}>{name || t('page:prev_nombre')}</p>
        <p className="mt-1 text-xs opacity-85">{tagline || t('page:prev_frase')}</p>
        <span className="mt-3 inline-block px-3 py-1.5 text-[11px] font-bold" style={{ background: c('--accent'), color: `rgb(${v['--on-accent']})`, borderRadius: r }}>{t('page:prev_pedir')}</span>
      </div>
      <div className="space-y-2 p-3">
        {[t('page:prev_plato1'), t('page:prev_plato2')].map((dish, i) => (
          <div key={dish} className="flex items-center justify-between gap-2 p-2.5" style={{ background: c('--raised'), border: `1px solid ${c('--rule')}`, borderRadius: r }}>
            <span>
              <span className="block text-xs font-bold">{dish}</span>
              <span className="block text-[11px]" style={{ color: c('--ink-soft') }}>{i ? '$9.500' : '$32.000'}</span>
            </span>
            <span className="px-2 py-1 text-[10px] font-bold" style={{ background: c('--brand-wash'), color: c('--brand-ink'), borderRadius: r }}>+ {t('page:prev_agregar')}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function PageDesignPanel({ state, theme, tagline, onTheme, onTagline }: {
  state: PageState; theme: PageTheme; tagline: string | null; onTheme: (t: PageTheme) => void; onTagline: (v: string) => void;
}) {
  const [busy, setBusy] = useState(false);
  // Tipografías de la vista previa (si no hay internet, se ve con la del sistema)
  useEffect(() => {
    for (const f of Object.values(THEME_FONTS)) {
      if (!f.google || document.querySelector(`link[data-lp-font="${f.google}"]`)) continue;
      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = `https://fonts.googleapis.com/css2?family=${f.google}&display=swap`;
      link.dataset.lpFont = f.google;
      document.head.appendChild(link);
    }
  }, []);
  const { settings: business } = useBusiness();
  const setBusiness = useBusinessStore((st) => st.setSettings);
  const [advice, setAdvice] = useState<{ why: string; tagline: string | null } | null>(null);
  const shown = useMemo(() => normalizeTheme(theme), [theme]);
  const set = (patch: Partial<PageTheme>) => onTheme({ ...theme, ...patch });
  const adjusted = theme.primary.toUpperCase() !== shown.primary;

  const applyPreset = (key: string) => onTheme({ ...theme, preset: key, ...THEME_PRESETS[key] });

  const applyTemplate = (tmplId: BusinessTemplate) => {
    const meta = BUSINESS_TEMPLATES[tmplId];
    const p = THEME_PRESETS[meta.recommendedPreset];
    onTheme({
      ...theme,
      template: tmplId,
      preset: meta.recommendedPreset,
      primary: p.primary,
      accent: p.accent,
      font: meta.recommendedFont,
      mode: meta.recommendedMode,
      radius: meta.recommendedRadius,
      menuLayout: meta.recommendedLayout,
    });
  };

  const recommend = async () => {
    setBusy(true);
    setAdvice(null);
    try {
      const r = await pageAPI.designAI({
        businessName: state.business.name, businessType: state.business.type, city: state.profile.city || state.business.city,
        tagline, categories: state.menuNames.categories, items: state.menuNames.items, lang: getLanguage(),
      });
      // La portada y el logo son del negocio: la IA no los cambia
      onTheme({ ...r.theme, coverImage: theme.coverImage, logoImage: theme.logoImage });
      setAdvice({ why: r.why, tagline: r.tagline });
      if (!tagline && r.tagline) onTagline(r.tagline);
      toast.success(t('page:ia_aplicado'));
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="rounded-3xl border border-slate-200 bg-white p-6 space-y-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 className="text-base font-black text-slate-900 flex items-center gap-2"><Palette className="w-5 h-5 text-blue-600" aria-hidden /> {t('page:diseno_titulo')}</h3>
          <p className="mt-1 text-xs text-slate-500 max-w-md">{t('page:diseno_desc')}</p>
        </div>
        <button type="button" onClick={recommend} disabled={busy}
          className="inline-flex items-center gap-2 min-h-[42px] px-4 rounded-xl bg-gradient-to-r from-violet-600 to-blue-600 text-sm font-bold text-white shadow-sm hover:opacity-95 disabled:opacity-60">
          {busy ? <Loader2 className="w-4 h-4 animate-spin" aria-hidden /> : <Sparkles className="w-4 h-4" aria-hidden />}
          {busy ? t('page:ia_pensando') : t('page:ia_recomendar')}
        </button>
      </div>

      {advice && (
        <div className="rounded-2xl border border-violet-200 bg-violet-50 px-4 py-3 text-sm text-violet-950 space-y-2">
          <p className="flex gap-2"><Wand2 className="w-4 h-4 mt-0.5 shrink-0" aria-hidden /> {advice.why}</p>
          {advice.tagline && advice.tagline !== tagline && (
            <p className="flex flex-wrap items-center gap-2 text-xs">
              {t('page:ia_frase')} <b>“{advice.tagline}”</b>
              <button type="button" onClick={() => onTagline(advice.tagline!)} className="font-bold text-violet-700 underline">{t('page:ia_usar_frase')}</button>
            </p>
          )}
        </div>
      )}

      <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_16rem]">
        <div className="space-y-4">
          {/* Selector de plantillas: cada una cambia toda la página, no solo los colores */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className={labelCls}>Plantilla de negocio</span>
              <span className="text-[11px] font-semibold text-blue-600">{BUSINESS_TEMPLATE_KEYS.length} diseños completos</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
              {BUSINESS_TEMPLATE_KEYS.map((tmplId) => {
                const meta = BUSINESS_TEMPLATES[tmplId];
                const active = (shown.template || 'gourmet') === tmplId;
                const Icon = tmplId === 'gourmet' ? UtensilsCrossed : tmplId === 'bakery' ? Croissant : tmplId === 'nightlife' ? Music : tmplId === 'bar' ? Wine : tmplId === 'cafe' ? Coffee : tmplId === 'grill' ? Beef : Flame;
                return (
                  <button
                    key={tmplId}
                    type="button"
                    onClick={() => applyTemplate(tmplId)}
                    aria-pressed={active}
                    className={`relative p-3 rounded-2xl border text-left transition-all ${
                      active
                        ? 'border-blue-600 bg-blue-50/50 ring-2 ring-blue-500/20 shadow-sm'
                        : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50/50'
                    }`}
                  >
                    <div className="flex items-start gap-2.5">
                      <div className={`p-2 rounded-xl shrink-0 ${active ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-700'}`}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-1">
                          <p className="text-xs font-black text-slate-900 truncate">{meta.name}</p>
                          {active && <Check className="w-3.5 h-3.5 text-blue-600 shrink-0" />}
                        </div>
                        <p className="text-[11px] font-medium text-slate-500 line-clamp-1">{meta.category}</p>
                        <p className="mt-1 text-[11px] leading-snug text-slate-600 line-clamp-3">{meta.description}</p>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <span className={labelCls}>{t('page:estilo_base')}</span>
            <div className="mt-1 grid grid-cols-2 sm:grid-cols-4 gap-2">
              {THEME_PRESET_KEYS.map((k) => {
                const p = THEME_PRESETS[k];
                return (
                  <button key={k} type="button" onClick={() => applyPreset(k)} aria-pressed={theme.preset === k}
                    className={`flex items-center gap-2 rounded-xl border px-2.5 py-2 text-left text-xs font-bold ${theme.preset === k ? 'border-blue-600 ring-2 ring-blue-500/20' : 'border-slate-200 hover:border-slate-300'}`}>
                    <span aria-hidden className="flex shrink-0 overflow-hidden rounded-md">
                      <span className="h-6 w-3" style={{ background: p.primary }} /><span className="h-6 w-3" style={{ background: p.accent }} />
                    </span>
                    <span className="text-slate-800">{t(`page:preset_${k}`)}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {(['primary', 'accent'] as const).map((k) => (
              <label key={k} className="block">
                <span className={labelCls}>{t(`page:color_${k}`)}</span>
                <span className="mt-1 flex items-center gap-2 rounded-xl border border-slate-200 px-2 py-1.5">
                  <input type="color" value={theme[k]} onChange={(e) => set({ [k]: e.target.value.toUpperCase() })} className="h-8 w-10 cursor-pointer rounded border-0 bg-transparent p-0" aria-label={t(`page:color_${k}`)} />
                  <span className="font-mono text-xs text-slate-600">{shown[k]}</span>
                </span>
              </label>
            ))}
          </div>
          {adjusted && <p className="text-xs text-amber-700">{t('page:color_ajustado', { color: shown.primary })}</p>}

          <div className="grid gap-3 sm:grid-cols-2">
            <Segmented label={t('page:modo')} value={theme.mode} onChange={(mode) => set({ mode })} options={[{ v: 'light', text: t('page:modo_claro') }, { v: 'dark', text: t('page:modo_oscuro') }]} />
            <Segmented label={t('page:esquinas')} value={theme.radius} onChange={(radius) => set({ radius })} options={[{ v: 'recto', text: t('page:esq_recto') }, { v: 'suave', text: t('page:esq_suave') }, { v: 'redondo', text: t('page:esq_redondo') }]} />
            <Segmented label={t('page:carta_estilo')} value={theme.menuLayout} onChange={(menuLayout) => set({ menuLayout })} options={[{ v: 'tarjetas', text: t('page:carta_tarjetas') }, { v: 'lista', text: t('page:carta_lista') }]} />
            <Segmented label={t('page:portada')} value={theme.heroStyle} onChange={(heroStyle) => set({ heroStyle })} options={[{ v: 'foto', text: t('page:portada_foto') }, { v: 'color', text: t('page:portada_color') }]} />
          </div>

          <div>
            <span className={labelCls}>{t('page:tipografia')}</span>
            <div className="mt-1 grid grid-cols-2 sm:grid-cols-4 gap-2">
              {(['moderna', 'elegante', 'calida', 'amigable'] as const).map((f) => (
                <button key={f} type="button" onClick={() => set({ font: f })} aria-pressed={theme.font === f}
                  className={`rounded-xl border px-3 py-2 text-left ${theme.font === f ? 'border-blue-600 ring-2 ring-blue-500/20' : 'border-slate-200 hover:border-slate-300'}`}>
                  <span className="block text-lg font-extrabold text-slate-900" style={{ fontFamily: THEME_FONTS[f].family }}>{t('page:prev_letra')}</span>
                  <span className="text-xs font-bold text-slate-600">{t(`page:font_${f}`)}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="grid gap-4 xl:grid-cols-2">
            <ImageField
              kind="cover"
              id="page-cover"
              label={t('page:foto_portada')}
              hint={t('page:portada_hint')}
              value={theme.coverImage}
              onChange={(url) => set({ coverImage: url })}
            />
            <ImageField
              kind="logo"
              id="page-logo"
              label={t('page:logo')}
              hint={theme.logoImage || !business?.logoUrl ? t('page:logo_hint') : t('page:logo_hint_negocio')}
              value={theme.logoImage || business?.logoUrl || null}
              canRemove={!!theme.logoImage}
              removeLabel={business?.logoUrl && business.logoUrl !== theme.logoImage ? t('page:usar_logo_negocio') : undefined}
              onChange={async (url) => {
                set({ logoImage: url });
                // Primer logo: también queda como logo del negocio (tickets e informes)
                if (url && !business?.logoUrl) {
                  try {
                    setBusiness(await businessAPI.update({ logoUrl: url }));
                  } catch {
                    // la página lo guarda igual al guardar
                  }
                }
              }}
            />
          </div>
        </div>

        <div className="space-y-2">
          <span className={labelCls}>{t('page:vista_previa')}</span>
          <Preview theme={shown} name={state.business.name} tagline={tagline} />
        </div>
      </div>
    </section>
  );
}
