// ============================================
// ADMIN - Productos: la carta y los precios por horario (Fase 4)
// ============================================

import { useState } from 'react';
import { t } from '../../i18n';
import { Segmented } from '../ui';
import { ProductsAdmin } from './ProductsAdmin';
import { PriceRulesPanel } from './PriceRulesPanel';

export function ProductsTabs() {
  const [tab, setTab] = useState<'products' | 'hours'>('products');
  return (
    <div className="space-y-6">
      <Segmented
        value={tab}
        onChange={setTab}
        ariaLabel={t('products:pr_tab_productos')}
        options={[
          { id: 'products', label: t('products:pr_tab_productos') },
          { id: 'hours', label: t('products:pr_tab_horario') },
        ]}
      />
      {tab === 'products' ? <ProductsAdmin /> : <PriceRulesPanel />}
    </div>
  );
}
