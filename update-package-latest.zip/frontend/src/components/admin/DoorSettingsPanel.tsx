// ============================================
// ADMIN - Ajustes del negocio → Puerta: aforo e informe de la noche (Fase 4)
// ============================================
// El aforo es el máximo de personas adentro; la pantalla Puerta avisa al 90 %.
// El informe de cada noche (de mediodía a mediodía) muestra covers cobrados,
// entradas, salidas y el pico de ocupación.

import { useEffect, useState } from 'react';
import { DoorOpen } from 'lucide-react';
import { t } from '../../i18n';
import { businessAPI } from '../../services/api';
import { doorAPI, type DoorReport } from '../../services/v3Api';
import { useBusinessStore } from '../../shared/business';
import { useFeatureFlag } from '../../shared/features';
import { toast } from '../../shared/toast';
import { Button } from '../common/Button';

const field = 'w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-slate-900 outline-none text-sm font-medium';

/** La noche que empezó hoy (o ayer, si aún no es mediodía) */
const tonight = () => {
  const d = new Date();
  if (d.getHours() < 12) d.setDate(d.getDate() - 1);
  return d.toLocaleDateString('en-CA');
};

export function DoorSettingsPanel() {
  const on = useFeatureFlag('door');
  const stored = useBusinessStore((s) => s.settings);
  const setStored = useBusinessStore((s) => s.setSettings);
  const [capacity, setCapacity] = useState(stored?.maxCapacity ? String(stored.maxCapacity) : '');
  const [busy, setBusy] = useState(false);
  const [date, setDate] = useState(tonight);
  const [report, setReport] = useState<DoorReport | null>(null);
  useEffect(() => { setCapacity(stored?.maxCapacity ? String(stored.maxCapacity) : ''); }, [stored?.maxCapacity]);
  useEffect(() => {
    if (!on) return;
    doorAPI.report(date).then(setReport).catch(() => setReport(null));
  }, [on, date]);
  if (!on || !stored) return null;

  const save = async () => {
    const n = capacity.trim() ? Math.round(Number(capacity)) : null;
    if (n !== null && (!Number.isFinite(n) || n < 1)) return toast.error(t('v3:puerta_aforo_invalido'));
    setBusy(true);
    try {
      setStored(await businessAPI.update({ maxCapacity: n }));
      toast.success(t('v3:guardado'));
    } catch (err: any) {
      toast.error(err?.message || t('v3:no_se_guardo'));
    } finally {
      setBusy(false);
    }
  };

  const stat = (label: string, value: string | number) => (
    <div className="rounded-2xl bg-slate-50 p-3">
      <dt className="text-xs font-semibold text-slate-500">{label}</dt>
      <dd className="font-heading text-2xl font-black tabular-nums text-slate-900">{value}</dd>
    </div>
  );

  return (
    <section className="space-y-4 rounded-3xl border border-slate-200/80 bg-white p-6 shadow-sm sm:p-8" aria-labelledby="puerta-title">
      <div className="flex items-start gap-3">
        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-fuchsia-50 text-fuchsia-700"><DoorOpen className="h-5 w-5" aria-hidden /></span>
        <div>
          <h3 id="puerta-title" className="font-heading text-base font-bold text-slate-900">{t('v3:puerta_titulo')}</h3>
          <p className="text-sm text-slate-500">{t('v3:puerta_ajustes_desc')}</p>
        </div>
      </div>
      <div className="flex flex-wrap items-end gap-3">
        <label className="min-w-[12rem] flex-1 space-y-1 text-xs font-bold text-slate-700">{t('v3:puerta_aforo')}
          <input className={field} type="number" inputMode="numeric" min={1} max={100000} value={capacity} onChange={(e) => setCapacity(e.target.value)} placeholder={t('v3:puerta_aforo_ej')} />
        </label>
        <Button onClick={save} isLoading={busy} disabled={capacity === (stored.maxCapacity ? String(stored.maxCapacity) : '')}>{t('v3:guardar')}</Button>
      </div>
      <div className="space-y-3 border-t border-slate-100 pt-4">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <h4 className="text-sm font-bold text-slate-900">{t('v3:puerta_informe')}</h4>
          <label className="space-y-1 text-xs font-bold text-slate-700">{t('v3:puerta_noche_del')}
            <input className={field} type="date" value={date} max={tonight()} onChange={(e) => setDate(e.target.value || tonight())} />
          </label>
        </div>
        {report && (
          <dl className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            {stat(t('v3:puerta_covers'), report.coversSold)}
            {stat(t('v3:puerta_entradas'), report.entries)}
            {stat(t('v3:puerta_salidas'), report.exits)}
            {stat(t('v3:puerta_pico'), report.peakPct !== null ? `${report.peak} · ${report.peakPct}%` : report.peak)}
          </dl>
        )}
        {report?.peakAt && <p className="text-xs text-slate-500">{t('v3:puerta_pico_hora', { hora: new Date(report.peakAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) })}</p>}
      </div>
    </section>
  );
}
