// ============================================
// ADMIN - Inteligencia artificial (Configuración)
// ============================================
// El ADMIN decide si Lantify puede enviar a la IA datos del negocio (fotos de
// facturas y resúmenes para los agentes). Apagado por defecto. El asistente de
// ayuda no necesita este permiso: solo recibe la pregunta y la pantalla.

import { useEffect, useState } from 'react';
import { ShieldCheck, Sparkles } from 'lucide-react';
import { Toggle } from '../common/Choice';
import { aiSettingsAPI, AiSettings } from '../../services/api';
import { errorMessage } from '../../services/apiErrors';
import { toast } from '../../shared/toast';
import { useFeature } from '../../shared/plan';
import { LockBadge } from '../common/PlanLocked';
import { t, getLocale } from '../../i18n';

export function AiSettingsPanel() {
  const [s, setS] = useState<AiSettings | null>(null);
  const [busy, setBusy] = useState(false);
  const hasOcr = useFeature('expense_ocr');
  const hasAgents = useFeature('ai_agents');

  useEffect(() => {
    aiSettingsAPI.get().then(setS).catch((e) => toast.error(errorMessage(e)));
  }, []);

  const update = async (data: Parameters<typeof aiSettingsAPI.update>[0]) => {
    setBusy(true);
    try {
      setS(await aiSettingsAPI.update(data));
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusy(false);
    }
  };

  if (!s) return null;

  return (
    <div className="space-y-4 max-w-3xl">
      <section className="bg-white rounded-3xl shadow-sm p-6 sm:p-8 border border-slate-200/80 space-y-4">
        <div className="flex items-start gap-3">
          <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-violet-50 text-violet-600">
            <Sparkles className="w-5 h-5" aria-hidden />
          </span>
          <div>
            <h3 className="text-base font-bold text-slate-900 font-heading">{t('ai:titulo')}</h3>
            <p className="mt-1 text-sm text-slate-600 leading-relaxed">{t('ai:bajada')}</p>
          </div>
        </div>

        <Toggle
          id="ai-consent"
          checked={s.consent}
          onChange={(v) => !busy && update({ consent: v })}
          label={t('ai:permitir')}
          description={t('ai:consent_que_se_envia')}
        />
        <p className="text-xs text-slate-500 leading-relaxed px-1">{t('ai:consent_proveedor')}</p>
        {s.consent && s.consentAt && (
          <p className="flex items-center gap-1.5 text-xs font-semibold text-emerald-700 px-1">
            <ShieldCheck className="w-3.5 h-3.5" aria-hidden />
            {t('ai:autorizado_por', { name: s.consentBy || '—', date: new Date(s.consentAt).toLocaleDateString(getLocale(), { dateStyle: 'long' }) })}
          </p>
        )}
      </section>

      <section className="bg-white rounded-3xl shadow-sm p-6 sm:p-8 border border-slate-200/80 space-y-3">
        <h3 className="flex items-center gap-2 text-base font-bold text-slate-900 font-heading">
          {t('ai:facturas_titulo')} {!hasOcr && <LockBadge />}
        </h3>
        <Toggle
          id="ai-auto-expense"
          checked={s.expenseAutoRegister}
          onChange={(v) => !busy && s.consent && hasOcr && update({ expenseAutoRegister: v })}
          label={t('ai:automatico')}
          description={!s.consent ? t('ai:requiere_permiso') : t('ai:automatico_desc')}
        />
      </section>

      <section className="bg-white rounded-3xl shadow-sm p-6 sm:p-8 border border-slate-200/80">
        <h3 className="flex items-center gap-2 text-base font-bold text-slate-900 font-heading">
          {t('ai:agentes_titulo')} {!hasAgents && <LockBadge />}
        </h3>
        <p className="mt-1 text-sm text-slate-600">{t('ai:agentes_desc')}</p>
      </section>
    </div>
  );
}
