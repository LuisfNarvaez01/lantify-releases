// ============================================
// ADMIN - Productos: catálogo, fotos, variantes e importación
// ============================================
// Cada producto tiene una foto opcional (con su carátula ajustable) y una o más
// variantes (presentaciones: 12 oz, grande, doble…), cada una con su SKU y precio.
// Para cargar rápido: importar un CSV (filas con el mismo nombre = variantes del
// mismo producto) y subir fotos en lote, asignadas por el nombre del archivo.

import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Package, Plus, Upload, Trash2, X, FileUp, Edit2, Save, Check, Info, Download, ImagePlus, GalleryHorizontalEnd as Images, Search, Loader2, Camera,
} from 'lucide-react';
import { productsAPI } from '../../services/api';
import { confirmDialog } from '../../shared/dialog';
import { toast } from '../../shared/toast';
import { formatCurrency } from '../../shared/formatUtils';
import { useBusiness, formatTaxLabel } from '../../shared/business';
import { ACCEPTED_IMAGE_TYPES, CENTERED, Framing, mediaSrc, readImageFile, uploadImage } from '../../shared/media';
import { ImageField, imageErrorText } from '../common/ImageField';
import { ImageCropper } from '../common/ImageCropper';
import { ImageGuide } from '../common/ImageGuide';
import { API_URL } from '../../config';
import { t } from '../../i18n';

// Impuesto del producto en el formulario: '' = el del negocio, 'NONE' o 'TIPO:tarifa'
const TAX_OPTIONS = ['', 'INC:8', 'IVA:19', 'IVA:5', 'NONE'];
const encodeTaxOption = (taxType?: string | null, taxRate?: number | null) => {
  if (!taxType) return '';
  if (taxType === 'NONE') return 'NONE';
  return `${taxType}:${taxRate ?? 0}`;
};
const decodeTaxOption = (value: string): { taxType: string | null; taxRate: number | null } => {
  if (!value) return { taxType: null, taxRate: null };
  if (value === 'NONE') return { taxType: 'NONE', taxRate: 0 };
  const [taxType, rate] = value.split(':');
  return { taxType, taxRate: Number(rate) };
};

const inputCls = 'w-full px-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-slate-900 outline-none';
const cellInputCls = 'w-full px-3 py-2 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-sm text-slate-900 outline-none';

interface VariantRow {
  key: string;
  id?: string;
  name: string;
  sku: string;
  price: string;
  cost: string;
  stock: string;
}

interface ProductForm {
  name: string;
  description: string;
  category: string;
  tax: string;
  imageUrl: string | null;
  variants: VariantRow[];
}

let rowSeq = 0;
const newRow = (v: Partial<VariantRow> = {}): VariantRow => ({ key: `v${++rowSeq}`, name: '', sku: '', price: '', cost: '', stock: '', ...v });
const EMPTY_FORM = (): ProductForm => ({ name: '', description: '', category: '', tax: '', imageUrl: null, variants: [newRow()] });

/** Para comparar nombres de archivo con productos: sin tildes, minúsculas, solo letras y números */
export const normalizeName = (s: string) =>
  s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\.[a-z0-9]{2,4}$/, '').replace(/[^a-z0-9]+/g, ' ').trim();

const activeVariants = (p: any): any[] => (p.variants || []).filter((v: any) => v.isActive !== false);

/** SKU legible cuando se deja vacío: CAPU-12OZ-4821 */
const suggestSku = (product: string, variant: string, taken: Set<string>) => {
  const part = (s: string) => normalizeName(s).replace(/ /g, '').slice(0, 4).toUpperCase();
  for (let i = 0; i < 50; i++) {
    const sku = [part(product) || 'PROD', part(variant), String(1000 + Math.floor(Math.random() * 9000))].filter(Boolean).join('-');
    if (!taken.has(sku)) return sku;
  }
  return `PROD-${Date.now()}`;
};

const priceRange = (p: any) => {
  const prices = activeVariants(p).map((v) => Number(v.price) || 0);
  if (!prices.length) return formatCurrency(0);
  const min = Math.min(...prices);
  const max = Math.max(...prices);
  return min === max ? formatCurrency(min) : `${formatCurrency(min)} – ${formatCurrency(max)}`;
};

export function ProductsAdmin() {
  const { settings: business } = useBusiness();
  const businessTaxLabel = formatTaxLabel(business?.defaultTaxType, business?.defaultTaxRate) || t('admin:sin_impuesto');
  const [products, setProducts] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState<ProductForm>(EMPTY_FORM);
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [query, setQuery] = useState('');
  const [onlyNoPhoto, setOnlyNoPhoto] = useState(false);
  const [selectionMode, setSelectionMode] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [showImport, setShowImport] = useState(false);
  const [showBulk, setShowBulk] = useState(false);
  const [showNewCategory, setShowNewCategory] = useState(false);
  const [quick, setQuick] = useState<{ product: any; img: HTMLImageElement; revoke: string } | null>(null);
  const [quickBusy, setQuickBusy] = useState(false);
  const quickInput = useRef<HTMLInputElement>(null);
  const quickTarget = useRef<any>(null);
  const formRef = useRef<HTMLDivElement>(null);

  const load = async () => {
    try {
      const [p, c] = await Promise.all([productsAPI.getAll(), productsAPI.getCategories()]);
      setProducts(p);
      setCategories(c);
    } catch (err) {
      console.error('Error loading products:', err);
    } finally {
      setLoaded(true);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const withoutPhoto = products.filter((p) => !p.imageUrl).length;
  const visible = useMemo(() => {
    const q = normalizeName(query);
    return products.filter((p) => {
      if (onlyNoPhoto && p.imageUrl) return false;
      if (!q) return true;
      const hay = normalizeName([p.name, p.category?.name, ...activeVariants(p).flatMap((v) => [v.name, v.sku])].join(' '));
      return hay.includes(q);
    });
  }, [products, query, onlyNoPhoto]);

  const openNew = () => {
    setEditing(null);
    setForm(EMPTY_FORM());
    setFormError(null);
    setShowForm(true);
    requestAnimationFrame(() => formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }));
  };

  const openEdit = (product: any) => {
    const variants = activeVariants(product);
    setEditing(product);
    setForm({
      name: product.name,
      description: product.description || '',
      category: product.categoryId || '',
      tax: encodeTaxOption(product.taxType, product.taxRate),
      imageUrl: product.imageUrl || null,
      variants: (variants.length ? variants : [{}]).map((v: any) =>
        newRow({ id: v.id, name: v.name || '', sku: v.sku || '', price: v.price?.toString() ?? '', cost: v.cost?.toString() ?? '', stock: v.stock?.toString() ?? '0' }),
      ),
    });
    setFormError(null);
    setShowForm(true);
    requestAnimationFrame(() => formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }));
  };

  const closeForm = () => {
    setShowForm(false);
    setEditing(null);
    setFormError(null);
  };

  const setVariant = (key: string, patch: Partial<VariantRow>) =>
    setForm((f) => ({ ...f, variants: f.variants.map((v) => (v.key === key ? { ...v, ...patch } : v)) }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    if (!form.name.trim()) return setFormError(t('admin:el_nombre_del_producto_es_obligatorio'));
    if (!form.variants.length) return setFormError(t('products:al_menos_una_variante'));

    // SKU: los que deja vacíos se generan; no se repiten dentro del mismo producto ni del catálogo
    const taken = new Set<string>(products.flatMap((p) => activeVariants(p).filter((v) => !form.variants.some((r) => r.id === v.id)).map((v) => v.sku)));
    const rows = form.variants.map((v, i) => {
      const name = v.name.trim() || (form.variants.length === 1 ? t('products:variante_unica') : `${t('products:variante')} ${i + 1}`);
      const sku = v.sku.trim() || suggestSku(form.name, form.variants.length === 1 ? '' : name, taken);
      taken.add(sku);
      return { ...v, name, sku };
    });
    const skus = rows.map((r) => r.sku.toLowerCase());
    if (new Set(skus).size !== skus.length) return setFormError(t('products:sku_repetido'));
    for (const r of rows) {
      const price = Number(r.price.replace(',', '.'));
      if (!r.price.trim() || !Number.isFinite(price) || price < 0) return setFormError(t('products:precio_invalido', { variant: r.name }));
    }
    const toVariant = (r: VariantRow) => ({
      name: r.name,
      sku: r.sku,
      price: Number(r.price.replace(',', '.')) || 0,
      cost: r.cost.trim() ? Number(r.cost.replace(',', '.')) || 0 : 0,
      stock: parseInt(r.stock) || 0,
    });
    const productData = {
      name: form.name.trim(),
      description: form.description.trim() || null,
      categoryId: form.category || null,
      imageUrl: form.imageUrl,
      ...decodeTaxOption(form.tax),
    };

    setSaving(true);
    try {
      if (editing) {
        await productsAPI.update(editing.id, productData);
        const keep = new Set(rows.filter((r) => r.id).map((r) => r.id));
        for (const old of activeVariants(editing)) if (!keep.has(old.id)) await productsAPI.deleteVariant(old.id);
        for (const r of rows) {
          if (r.id) await productsAPI.updateVariant(r.id, toVariant(r));
          else await productsAPI.createVariant({ productId: editing.id, ...toVariant(r) });
        }
        toast.success(t('products:producto_actualizado'));
      } else {
        await productsAPI.create({ ...productData, variants: rows.map(toVariant) });
        toast.success(t('products:producto_creado'));
      }
      closeForm();
      load();
    } catch (err: any) {
      setFormError(err.message || t('admin:error_al_guardar_el_producto_por_favor'));
      // Lo que alcanzó a guardarse se ve en la lista
      load();
    } finally {
      setSaving(false);
    }
  };

  const remove = async (id: string) => {
    if (!(await confirmDialog({ title: t('admin:eliminar_este_producto'), message: t('admin:dejara_de_aparecer_en_el_catalogo_las'), confirmLabel: t('admin:eliminar'), tone: 'danger' }))) return;
    try {
      await productsAPI.delete(id);
      toast.success(t('admin:producto_eliminado'));
      load();
    } catch (err: any) {
      toast.error(err.message || t('products:no_se_pudo_eliminar'));
    }
  };

  const removeSelected = async () => {
    if (!(await confirmDialog({ title: t('admin:eliminar_size_productos', { size: selected.size }), message: t('admin:dejaran_de_aparecer_en_el_catalogo_las'), confirmLabel: t('admin:eliminar'), tone: 'danger' }))) return;
    try {
      for (const id of selected) await productsAPI.delete(id);
      setSelected(new Set());
      setSelectionMode(false);
    } catch (err: any) {
      toast.error(err.message || t('products:no_se_pudo_eliminar'));
    }
    load();
  };

  const toggle = (id: string) =>
    setSelected((s) => {
      const n = new Set(s);
      if (n.has(id)) n.delete(id);
      else n.add(id);
      return n;
    });

  // ── Foto rápida desde la lista ──
  const pickQuickPhoto = (product: any) => {
    quickTarget.current = product;
    quickInput.current?.click();
  };
  const onQuickFile = async (file: File | undefined) => {
    if (!file || !quickTarget.current) return;
    try {
      const { img, url } = await readImageFile(file);
      setQuick({ product: quickTarget.current, img, revoke: url });
    } catch (e) {
      toast.error(imageErrorText(e));
    }
  };
  const closeQuick = () => {
    if (quick) URL.revokeObjectURL(quick.revoke);
    setQuick(null);
  };
  const saveQuick = async (f: Framing) => {
    if (!quick) return;
    setQuickBusy(true);
    try {
      const url = await uploadImage(quick.img, 'product', f);
      await productsAPI.update(quick.product.id, { imageUrl: url });
      setProducts((list) => list.map((p) => (p.id === quick.product.id ? { ...p, imageUrl: url } : p)));
      toast.success(t('products:foto_guardada', { name: quick.product.name }));
      closeQuick();
    } catch (e) {
      toast.error(imageErrorText(e));
    } finally {
      setQuickBusy(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Acciones */}
      <div className="flex flex-wrap gap-3 items-center">
        <button onClick={openNew} className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-5 py-3 rounded-2xl font-bold transition-all shadow-sm">
          <Plus className="w-5 h-5" /> {t('admin:nuevo_producto')}
        </button>
        <button onClick={() => setShowImport(true)} className="flex items-center gap-2 bg-white text-slate-700 border border-slate-300 px-5 py-3 rounded-2xl font-bold hover:bg-slate-50 transition-all shadow-sm">
          <Upload className="w-5 h-5 text-slate-500" /> {t('admin:importar_csv')}
        </button>
        {products.length > 0 && (
          <button onClick={() => setShowBulk(true)} className="flex items-center gap-2 bg-white text-slate-700 border border-slate-300 px-5 py-3 rounded-2xl font-bold hover:bg-slate-50 transition-all shadow-sm">
            <Images className="w-5 h-5 text-slate-500" /> {t('media:lote_boton')}
          </button>
        )}
        {products.length > 0 && (
          <button
            onClick={() => {
              setSelectionMode((m) => !m);
              setSelected(new Set());
            }}
            className={`flex items-center gap-2 px-5 py-3 rounded-2xl font-bold transition-all shadow-sm ${selectionMode ? 'bg-slate-900 text-white' : 'bg-white text-blue-600 border border-blue-200 hover:bg-blue-50'}`}
          >
            {selectionMode ? t('admin:cancelar_seleccion') : t('admin:seleccion_multiple')}
          </button>
        )}
        {selectionMode && selected.size > 0 && (
          <button onClick={removeSelected} className="flex items-center gap-2 bg-rose-600 text-white px-5 py-3 rounded-2xl font-bold hover:bg-rose-700 transition-all shadow-sm">
            <Trash2 className="w-5 h-5" /> {t('admin:eliminar_size', { size: selected.size })}
          </button>
        )}
      </div>

      {/* Formulario */}
      {showForm && (
        <div ref={formRef} className="bg-white rounded-3xl shadow-sm p-6 sm:p-8 border border-slate-200/80 scroll-mt-4">
          <div className="flex items-center justify-between gap-3 mb-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center text-blue-600">
                <Package className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 font-heading">{editing ? t('admin:editar_producto') : t('admin:nuevo_producto')}</h3>
            </div>
            <button type="button" onClick={closeForm} aria-label={t('admin:cancelar')} className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100">
              <X className="w-5 h-5" />
            </button>
          </div>

          {formError && (
            <div role="alert" className="mb-6 p-4 bg-rose-50 border border-rose-200 text-rose-700 rounded-2xl flex items-start gap-3">
              <X className="w-5 h-5 mt-0.5 cursor-pointer shrink-0" onClick={() => setFormError(null)} />
              <span className="font-medium text-sm">{formError}</span>
            </div>
          )}

          <form onSubmit={submit} className="space-y-8">
            <div className="grid grid-cols-1 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.4fr)] gap-6">
              <ImageField
                kind="product"
                id="product-photo"
                label={t('products:foto')}
                hint={t('products:foto_hint')}
                value={form.imageUrl}
                onChange={(url) => setForm((f) => ({ ...f, imageUrl: url }))}
              />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1 sm:col-span-2">
                  <label htmlFor="product-name" className="text-sm font-semibold text-slate-700 ml-1">{t('admin:nombre')}</label>
                  <input id="product-name" type="text" placeholder={t('admin:nombre_del_producto')} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className={inputCls} required autoFocus={!editing} />
                </div>
                <div className="space-y-1 sm:col-span-2">
                  <label htmlFor="product-desc" className="text-sm font-semibold text-slate-700 ml-1">{t('admin:descripcion')}</label>
                  <input id="product-desc" type="text" placeholder={t('products:descripcion_placeholder')} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className={inputCls} />
                </div>
                <div className="space-y-1">
                  <label htmlFor="product-category" className="text-sm font-semibold text-slate-700 ml-1">{t('admin:categoria')}</label>
                  <div className="flex gap-2">
                    <select id="product-category" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className={`${inputCls} flex-1 min-w-0`}>
                      <option value="">{t('admin:sin_categoria')}</option>
                      {categories.map((cat) => (
                        <option key={cat.id} value={cat.id}>{cat.name}</option>
                      ))}
                    </select>
                    <button type="button" onClick={() => setShowNewCategory(true)} className="p-3 bg-blue-50 text-blue-600 rounded-xl hover:bg-blue-100 transition-colors border border-blue-100" title={t('admin:nueva_categoria')} aria-label={t('admin:nueva_categoria')}>
                      <Plus className="w-5 h-5" />
                    </button>
                  </div>
                </div>
                <div className="space-y-1">
                  <label htmlFor="product-tax" className="text-sm font-semibold text-slate-700 ml-1">{t('admin:impuesto_incluido')}</label>
                  <select id="product-tax" value={form.tax} onChange={(e) => setForm({ ...form, tax: e.target.value })} className={inputCls}>
                    <option value="">{t('admin:impuesto_del_negocio', { tax: businessTaxLabel })}</option>
                    <option value="INC:8">{t('admin:impoconsumo_8')}</option>
                    <option value="IVA:19">{t('admin:iva_19')}</option>
                    <option value="IVA:5">{t('admin:iva_5')}</option>
                    <option value="NONE">{t('admin:sin_impuesto_excluido')}</option>
                    {form.tax && !TAX_OPTIONS.includes(form.tax) && <option value={form.tax}>{form.tax.replace(':', ' ')} %</option>}
                  </select>
                </div>
              </div>
            </div>

            {/* Variantes */}
            <fieldset className="space-y-3">
              <div className="flex flex-wrap items-end justify-between gap-2">
                <div>
                  <legend className="text-sm font-bold text-slate-900">{t('products:variantes_titulo')}</legend>
                  <p className="text-xs text-slate-500">{t('products:variantes_ayuda')}</p>
                </div>
                <button type="button" onClick={() => setForm((f) => ({ ...f, variants: [...f.variants, newRow()] }))} className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-blue-50 text-blue-700 border border-blue-100 text-xs font-bold hover:bg-blue-100">
                  <Plus className="w-4 h-4" /> {t('products:agregar_variante')}
                </button>
              </div>
              <div className="overflow-x-auto rounded-2xl border border-slate-200">
                <table className="w-full min-w-[640px] text-sm">
                  <thead>
                    <tr className="bg-slate-50 text-xs font-semibold text-slate-500 text-left">
                      <th scope="col" className="px-3 py-2">{t('products:col_variante')}</th>
                      <th scope="col" className="px-3 py-2">{t('products:col_sku')}</th>
                      <th scope="col" className="px-3 py-2">{t('products:col_precio')}</th>
                      <th scope="col" className="px-3 py-2">{t('products:col_costo')}</th>
                      <th scope="col" className="px-3 py-2">{t('products:col_stock')}</th>
                      <th scope="col" className="px-2 py-2 w-10"><span className="sr-only">{t('admin:acciones')}</span></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {form.variants.map((v, i) => (
                      <tr key={v.key}>
                        <td className="px-3 py-2">
                          <input aria-label={t('products:col_variante')} placeholder={form.variants.length === 1 ? t('products:variante_unica') : t('products:variante_placeholder')} value={v.name} onChange={(e) => setVariant(v.key, { name: e.target.value })} className={cellInputCls} />
                        </td>
                        <td className="px-3 py-2">
                          <input aria-label={t('products:col_sku')} placeholder={t('products:sku_auto')} value={v.sku} onChange={(e) => setVariant(v.key, { sku: e.target.value })} className={`${cellInputCls} font-mono`} />
                        </td>
                        <td className="px-3 py-2">
                          <input aria-label={t('products:col_precio')} inputMode="decimal" required value={v.price} onChange={(e) => setVariant(v.key, { price: e.target.value })} className={`${cellInputCls} font-mono tabular-nums`} placeholder="0" />
                        </td>
                        <td className="px-3 py-2">
                          <input aria-label={t('products:col_costo')} inputMode="decimal" value={v.cost} onChange={(e) => setVariant(v.key, { cost: e.target.value })} className={`${cellInputCls} font-mono tabular-nums`} placeholder="0" />
                        </td>
                        <td className="px-3 py-2">
                          <input aria-label={t('products:col_stock')} inputMode="numeric" value={v.stock} onChange={(e) => setVariant(v.key, { stock: e.target.value })} className={`${cellInputCls} font-mono tabular-nums`} placeholder="0" />
                        </td>
                        <td className="px-2 py-2">
                          <button
                            type="button"
                            disabled={form.variants.length === 1}
                            onClick={() => setForm((f) => ({ ...f, variants: f.variants.filter((r) => r.key !== v.key) }))}
                            aria-label={t('products:quitar_variante', { n: i + 1 })}
                            className="p-2 rounded-lg text-rose-500 hover:bg-rose-50 disabled:opacity-30 disabled:hover:bg-transparent"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {editing && <p className="text-xs text-slate-500">{t('products:quitar_variante_nota')}</p>}
            </fieldset>

            <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-slate-100">
              <button type="submit" disabled={saving} className="flex-1 inline-flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3.5 rounded-xl font-bold shadow-sm transition-all disabled:opacity-60">
                {saving ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
                {t('admin:guardar_cambios')}
              </button>
              <button type="button" onClick={closeForm} className="flex-1 bg-white text-slate-700 px-6 py-3.5 rounded-xl font-bold hover:bg-slate-50 transition-all border border-slate-300">
                {t('admin:cancelar')}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Búsqueda y filtro */}
      {products.length > 0 && (
        <div className="flex flex-wrap items-center gap-3">
          <label className="relative flex-1 min-w-[220px] max-w-md">
            <span className="sr-only">{t('products:buscar')}</span>
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" aria-hidden />
            <input type="search" value={query} onChange={(e) => setQuery(e.target.value)} placeholder={t('products:buscar_placeholder')} className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none" />
          </label>
          {withoutPhoto > 0 && (
            <button
              type="button"
              aria-pressed={onlyNoPhoto}
              onClick={() => setOnlyNoPhoto((v) => !v)}
              className={`inline-flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-xs font-bold border transition-colors ${onlyNoPhoto ? 'bg-amber-100 border-amber-300 text-amber-900' : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'}`}
            >
              <Camera className="w-4 h-4" aria-hidden /> {t('products:sin_foto_n', { count: withoutPhoto })}
            </button>
          )}
          {selectionMode && (
            <button onClick={() => setSelected(selected.size === visible.length ? new Set() : new Set(visible.map((p) => p.id)))} className="text-blue-700 text-xs font-bold bg-white px-3.5 py-2.5 rounded-xl border border-blue-200">
              {selected.size === visible.length ? t('admin:deseleccionar_todo') : t('admin:seleccionar_todo')} · {t('admin:size_de_length_productos_seleccionados', { size: selected.size, length: products.length })}
            </button>
          )}
        </div>
      )}

      {/* Lista */}
      <div className="bg-white rounded-3xl shadow-sm overflow-hidden border border-slate-200/80">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-slate-900 text-slate-200 text-xs font-semibold uppercase tracking-wider">
                {selectionMode && <th className="px-4 py-4 w-12"><span className="sr-only">{t('admin:seleccionar_todo')}</span></th>}
                <th className="px-4 py-4 text-left w-20">{t('products:foto')}</th>
                <th className="px-4 py-4 text-left">{t('admin:producto')}</th>
                <th className="px-4 py-4 text-left">{t('admin:categoria')}</th>
                <th className="px-4 py-4 text-left">{t('admin:precio')}</th>
                <th className="px-4 py-4 text-left">{t('admin:stock')}</th>
                <th className="px-4 py-4 text-center w-28">{t('admin:acciones')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {visible.map((product) => {
                const variants = activeVariants(product);
                const stock = variants.reduce((n, v) => n + (Number(v.stock) || 0), 0);
                return (
                  <tr key={product.id} className={`hover:bg-slate-50/80 transition-colors ${selected.has(product.id) ? 'bg-blue-50/40' : ''}`}>
                    {selectionMode && (
                      <td className="px-4 py-3">
                        <button
                          onClick={() => toggle(product.id)}
                          aria-label={product.name}
                          aria-pressed={selected.has(product.id)}
                          className={`w-6 h-6 border-2 rounded-lg flex items-center justify-center transition-all ${selected.has(product.id) ? 'bg-blue-600 border-blue-600' : 'border-slate-300'}`}
                        >
                          {selected.has(product.id) && <Check className="w-4 h-4 text-white" />}
                        </button>
                      </td>
                    )}
                    <td className="px-4 py-3">
                      <button
                        type="button"
                        onClick={() => pickQuickPhoto(product)}
                        title={product.imageUrl ? t('products:cambiar_foto') : t('products:agregar_foto')}
                        aria-label={`${product.imageUrl ? t('products:cambiar_foto') : t('products:agregar_foto')}: ${product.name}`}
                        className="group relative w-14 h-14 rounded-xl overflow-hidden border border-slate-200 bg-slate-50 grid place-items-center hover:border-blue-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
                      >
                        {product.imageUrl ? (
                          <img src={mediaSrc(product.imageUrl)} alt="" loading="lazy" className="w-full h-full object-cover" />
                        ) : (
                          <ImagePlus className="w-5 h-5 text-slate-300 group-hover:text-blue-500" aria-hidden />
                        )}
                        <span className="absolute inset-x-0 bottom-0 bg-slate-900/70 text-white text-[10px] font-bold py-0.5 opacity-0 group-hover:opacity-100 group-focus-visible:opacity-100 transition-opacity">
                          {product.imageUrl ? t('media:cambiar') : t('products:agregar')}
                        </span>
                      </button>
                    </td>
                    <td className="px-4 py-3">
                      <div className="font-bold text-slate-900">{product.name}</div>
                      {product.description && <div className="text-xs text-slate-500 truncate max-w-xs">{product.description}</div>}
                      {variants.length > 1 && (
                        <div className="mt-1.5 flex flex-wrap gap-1">
                          {variants.map((v) => (
                            <span key={v.id} className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 text-xs font-medium">
                              {v.name} · <span className="tabular-nums">{formatCurrency(v.price)}</span>
                            </span>
                          ))}
                        </div>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <span className="px-2.5 py-1 bg-slate-100 text-slate-700 text-xs font-semibold rounded-lg">{product.category?.name || t('admin:varios')}</span>
                    </td>
                    <td className="px-4 py-3 font-bold text-emerald-700 tabular-nums whitespace-nowrap">{priceRange(product)}</td>
                    <td className="px-4 py-3 tabular-nums">
                      <span className={`font-bold ${stock < 10 ? 'text-rose-600' : 'text-slate-700'}`}>{stock}</span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-center gap-1">
                        <button onClick={() => openEdit(product)} className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors" title={t('admin:editar')} aria-label={`${t('admin:editar')}: ${product.name}`}>
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button onClick={() => remove(product.id)} className="p-2 text-rose-500 hover:bg-rose-50 rounded-lg transition-colors" title={t('admin:eliminar')} aria-label={`${t('admin:eliminar')}: ${product.name}`}>
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {loaded && products.length === 0 && (
          <div className="p-12 text-center text-slate-400">
            <Package className="w-16 h-16 mx-auto mb-4 opacity-20" />
            <p className="text-base font-medium">{t('admin:no_hay_productos_en_catalogo_agrega_uno')}</p>
          </div>
        )}
        {products.length > 0 && visible.length === 0 && <p className="p-10 text-center text-sm text-slate-500">{t('products:sin_resultados')}</p>}
      </div>

      <input ref={quickInput} type="file" accept={ACCEPTED_IMAGE_TYPES} className="sr-only" tabIndex={-1} aria-hidden onChange={(e) => { onQuickFile(e.target.files?.[0]); e.target.value = ''; }} />
      {quick && <ImageCropper img={quick.img} kind="product" title={t('products:foto_de', { name: quick.product.name })} busy={quickBusy} onCancel={closeQuick} onConfirm={saveQuick} />}
      {showImport && <ImportCsvModal onClose={() => setShowImport(false)} onImported={load} />}
      {showBulk && <BulkPhotosModal products={products} onClose={() => setShowBulk(false)} onSaved={load} />}
      {showNewCategory && (
        <NewCategoryModal
          onClose={() => setShowNewCategory(false)}
          onCreated={async (cat) => {
            setShowNewCategory(false);
            setCategories(await productsAPI.getCategories());
            if (cat?.id) setForm((f) => ({ ...f, category: cat.id }));
          }}
        />
      )}
    </div>
  );
}

// ── Ventana base: siempre cabe en la pantalla (el contenido se desplaza, los botones no) ──
function Modal({ title, icon, onClose, children, footer, wide }: { title: string; icon: React.ReactNode; onClose: () => void; children: React.ReactNode; footer?: React.ReactNode; wide?: boolean }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);
  return (
    <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center z-[100] p-3 sm:p-4" role="dialog" aria-modal="true" aria-label={title}>
      <div className={`bg-white rounded-3xl shadow-2xl w-full ${wide ? 'max-w-4xl' : 'max-w-2xl'} max-h-[calc(100dvh-1.5rem)] flex flex-col overflow-hidden border border-slate-200`}>
        <div className="bg-slate-900 px-6 py-4 flex justify-between items-center text-white shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-600 rounded-xl text-white shadow-sm">{icon}</div>
            <h3 className="text-lg font-bold font-heading">{title}</h3>
          </div>
          <button onClick={onClose} aria-label={t('admin:cerrar')} className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="flex-1 min-h-0 overflow-y-auto p-6 space-y-5">{children}</div>
        {footer && <div className="shrink-0 px-6 py-4 border-t border-slate-200 bg-slate-50 flex flex-col sm:flex-row gap-3">{footer}</div>}
      </div>
    </div>
  );
}

// ── Importar CSV ─────────────────────────────────────────────

const HEADER_MAP: Record<string, string> = {
  nombre: 'name', name: 'name', 'descripción': 'description', descripcion: 'description', description: 'description',
  'categoría': 'category', categoria: 'category', category: 'category', variante: 'variant', variant: 'variant', variantname: 'variant',
  sku: 'sku', 'código': 'sku', codigo: 'sku', precio: 'price', price: 'price', costo: 'cost', cost: 'cost', stock: 'stock', inventario: 'stock',
  imagen: 'image', foto: 'image', image: 'image', imageurl: 'image', photo: 'image',
};

const splitLine = (line: string, sep: string) => {
  const out: string[] = [];
  let cur = '';
  let quoted = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (c === '"') {
      if (quoted && line[i + 1] === '"') {
        cur += '"';
        i++;
      } else quoted = !quoted;
    } else if (c === sep && !quoted) {
      out.push(cur);
      cur = '';
    } else cur += c;
  }
  out.push(cur);
  return out.map((v) => v.trim());
};

/** Vista previa: cómo quedará agrupado (mismo nombre = un producto con varias variantes) */
export const previewCsv = (content: string) => {
  const lines = content.replace(/^﻿/, '').split(/\r?\n/).filter((l) => l.trim());
  if (lines.length < 2) return null;
  const sep = (lines[0].match(/;/g) || []).length > (lines[0].match(/,/g) || []).length ? ';' : ',';
  const headers = splitLine(lines[0], sep).map((h) => HEADER_MAP[h.toLowerCase()] || h.toLowerCase());
  const missing = ['name', 'sku', 'price'].filter((h) => !headers.includes(h));
  const groups = new Map<string, { name: string; category: string; variants: { name: string; price: string; sku: string }[]; image: boolean }>();
  let incomplete = 0;
  for (const line of lines.slice(1)) {
    const cells = splitLine(line, sep);
    const row: Record<string, string> = {};
    headers.forEach((h, i) => (row[h] = cells[i] || ''));
    if (!row.name || !row.sku || !row.price) {
      incomplete++;
      continue;
    }
    const key = `${row.name.toLowerCase()}|${(row.category || '').toLowerCase()}`;
    const g = groups.get(key) || { name: row.name, category: row.category || '', variants: [], image: false };
    g.variants.push({ name: row.variant || 'Normal', price: row.price, sku: row.sku });
    g.image = g.image || !!row.image;
    groups.set(key, g);
  }
  return { missing, incomplete, rows: lines.length - 1, products: [...groups.values()] };
};

function ImportCsvModal({ onClose, onImported }: { onClose: () => void; onImported: () => void }) {
  const [file, setFile] = useState<File | null>(null);
  const [content, setContent] = useState('');
  const [result, setResult] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const [over, setOver] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);
  const preview = useMemo(() => (content.trim() ? previewCsv(content) : null), [content]);
  const variantCount = preview?.products.reduce((n, p) => n + p.variants.length, 0) || 0;

  const pick = async (f: File | undefined) => {
    if (!f) return;
    setFile(f);
    setResult(null);
    setContent(await f.text());
  };

  const downloadTemplate = async () => {
    try {
      const res = await fetch(`${API_URL}/products/import/template`, { headers: { Authorization: `Bearer ${localStorage.getItem('token') || ''}` } });
      if (!res.ok) throw new Error();
      const url = URL.createObjectURL(await res.blob());
      const a = document.createElement('a');
      a.href = url;
      a.download = 'plantilla_productos.csv';
      a.click();
      URL.revokeObjectURL(url);
      toast.success(t('admin:plantilla_csv_descargada'));
    } catch {
      toast.error(t('products:plantilla_error'));
    }
  };

  const run = async () => {
    if (!content.trim()) return;
    setBusy(true);
    setResult(null);
    try {
      const r = await productsAPI.importCSV(content);
      setResult(r);
      onImported();
    } catch (err: any) {
      setResult({ success: 0, errors: [err.message] });
    } finally {
      setBusy(false);
    }
  };

  const columns: [string, boolean][] = [
    [t('admin:nombre_2'), true], [t('admin:sku'), true], [t('admin:precio_2'), true], [t('admin:variante'), false],
    [t('admin:categoria_2'), false], [t('admin:descripcion_2'), false], [t('admin:costo_2'), false], [t('admin:stock_2'), false], [t('products:col_imagen'), false],
  ];

  return (
    <Modal
      title={t('admin:importar_productos')}
      icon={<Upload className="w-5 h-5" />}
      onClose={onClose}
      wide
      footer={
        result ? (
          <button onClick={onClose} className="flex-1 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-bold text-sm">{t('admin:cerrar')}</button>
        ) : (
          <>
            <button onClick={onClose} className="sm:w-40 bg-white text-slate-700 px-6 py-3 rounded-xl font-bold text-sm border border-slate-300 hover:bg-slate-50">{t('admin:cancelar')}</button>
            <button onClick={run} disabled={!preview || preview.products.length === 0 || preview.missing.length > 0 || busy} className="flex-1 inline-flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-bold text-sm disabled:opacity-50">
              {busy && <Loader2 className="w-4 h-4 animate-spin" />}
              {preview && preview.products.length ? t('products:importar_n', { products: preview.products.length, variants: variantCount }) : t('admin:iniciar_importacion')}
            </button>
          </>
        )
      }
    >
      {!result && (
        <>
          <div className="bg-blue-50/60 border border-blue-200/80 p-4 rounded-2xl space-y-3">
            <h4 className="font-bold text-slate-900 flex items-center gap-2 text-sm"><Info className="w-4 h-4 text-blue-600" /> {t('admin:instrucciones_del_formato')}</h4>
            <p className="text-xs text-slate-700 leading-relaxed">{t('products:import_ayuda')}</p>
            <div className="flex flex-wrap gap-1.5">
              {columns.map(([c, req]) => (
                <span key={c} className={`px-2 py-1 rounded-lg text-xs font-mono border ${req ? 'bg-white border-blue-200 text-slate-900' : 'bg-white/60 border-slate-200 text-slate-500'}`}>
                  {c}{req && <span className="text-rose-600 font-bold"> *</span>}
                </span>
              ))}
            </div>
            <div className="flex flex-wrap justify-between items-center gap-2">
              <p className="text-xs text-slate-500">{t('admin:soporta_comas_punto_y_coma_y_decimales')}</p>
              <button onClick={downloadTemplate} className="text-blue-700 text-xs font-bold hover:underline flex items-center gap-1 bg-white px-2.5 py-1.5 rounded-lg border border-blue-200">
                <Download className="w-3.5 h-3.5" /> {t('admin:descargar_plantilla')}
              </button>
            </div>
          </div>

          <div
            role="button"
            tabIndex={0}
            onClick={() => fileInput.current?.click()}
            onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && fileInput.current?.click()}
            onDragOver={(e) => { e.preventDefault(); setOver(true); }}
            onDragLeave={() => setOver(false)}
            onDrop={(e) => { e.preventDefault(); setOver(false); pick(e.dataTransfer.files?.[0]); }}
            className={`border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer transition-all ${over ? 'border-blue-500 bg-blue-50/60' : file ? 'border-emerald-400 bg-emerald-50/50' : 'border-slate-300 bg-slate-50/50 hover:bg-blue-50/30 hover:border-blue-500'}`}
          >
            <input ref={fileInput} type="file" accept=".csv,.txt,text/csv" onChange={(e) => pick(e.target.files?.[0])} className="hidden" />
            <FileUp className={`w-8 h-8 mx-auto mb-2 ${file ? 'text-emerald-600' : 'text-blue-600'}`} />
            {file ? (
              <>
                <p className="text-sm font-bold text-slate-900">{file.name}</p>
                <p className="text-xs text-emerald-700 font-bold mt-1">{t('products:otro_archivo')}</p>
              </>
            ) : (
              <>
                <p className="text-sm font-bold text-slate-800">{t('admin:seleccionar_archivo_csv')}</p>
                <p className="text-xs text-slate-500 mt-1">{t('admin:o_arrastra_y_suelta_el_archivo_aqui')}</p>
              </>
            )}
          </div>

          {!file && (
            <details className="group">
              <summary className="cursor-pointer text-xs font-bold text-slate-500 uppercase tracking-wider">{t('admin:o_pegar_contenido')}</summary>
              <textarea
                value={content}
                onChange={(e) => { setContent(e.target.value); setResult(null); }}
                aria-label={t('admin:o_pegar_contenido')}
                placeholder={'Nombre,Variante,SKU,Precio\nCapuchino,12 oz,CAP012,7500\nCapuchino,16 oz,CAP016,9000'}
                className="mt-2 w-full h-28 px-4 py-3 bg-white border border-slate-200 rounded-xl font-mono text-xs focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none resize-y"
              />
            </details>
          )}

          {preview && (
            <div className="space-y-2">
              {preview.missing.length > 0 ? (
                <p role="alert" className="text-sm font-semibold text-rose-700 bg-rose-50 border border-rose-200 rounded-xl px-4 py-3">
                  {t('products:faltan_columnas', { cols: preview.missing.map((m) => t(`products:col_${m === 'name' ? 'nombre' : m === 'price' ? 'precio' : 'sku'}`)).join(', ') })}
                </p>
              ) : (
                <>
                  <p className="text-sm font-bold text-slate-900">
                    {t('products:vista_previa', { products: preview.products.length, variants: variantCount })}
                    {preview.incomplete > 0 && <span className="ml-2 text-xs font-semibold text-amber-700">{t('products:filas_incompletas', { count: preview.incomplete })}</span>}
                  </p>
                  <div className="max-h-64 overflow-y-auto rounded-xl border border-slate-200 divide-y divide-slate-100">
                    {preview.products.slice(0, 200).map((p) => (
                      <div key={`${p.name}|${p.category}`} className="px-4 py-2.5 flex flex-wrap items-baseline gap-x-3 gap-y-1">
                        <span className="font-semibold text-sm text-slate-900">{p.name}</span>
                        {p.category && <span className="text-xs text-slate-500">{p.category}</span>}
                        <span className="flex flex-wrap gap-1">
                          {p.variants.map((v) => (
                            <span key={v.sku} className="px-2 py-0.5 rounded-md bg-slate-100 text-xs text-slate-700">{v.name} · {v.price}</span>
                          ))}
                        </span>
                      </div>
                    ))}
                  </div>
                </>
              )}
            </div>
          )}
        </>
      )}

      {result && (
        <div className="space-y-4">
          <div className={`p-4 rounded-2xl flex items-start gap-3 ${result.success > 0 ? 'bg-emerald-50 border border-emerald-200' : 'bg-rose-50 border border-rose-200'}`}>
            <div className={`p-1.5 rounded-lg ${result.success > 0 ? 'bg-emerald-600' : 'bg-rose-600'} text-white`}>{result.success > 0 ? <Check className="w-4 h-4" /> : <X className="w-4 h-4" />}</div>
            <div>
              <p className={`font-bold text-sm ${result.success > 0 ? 'text-emerald-900' : 'text-rose-900'}`}>
                {result.success > 0 ? t('products:import_resultado', { products: result.products?.length ?? 0, created: result.created ?? result.success, updated: result.updated ?? 0 }) : t('admin:hubo_un_problema_con_la_importacion')}
              </p>
              {result.success > 0 && <p className="text-xs text-emerald-800 mt-0.5">{t('products:import_siguiente')}</p>}
            </div>
          </div>
          {result.products?.length > 0 && (
            <div className="max-h-56 overflow-y-auto rounded-xl border border-slate-200 divide-y divide-slate-100">
              {result.products.map((p: any) => (
                <div key={p.name} className="px-4 py-2 text-sm"><span className="font-semibold">{p.name}</span> <span className="text-xs text-slate-500">· {p.variants.join(', ')}</span></div>
              ))}
            </div>
          )}
          {result.errors?.length > 0 && (
            <ul className="space-y-1 max-h-40 overflow-y-auto text-xs text-rose-700 font-semibold">
              {result.errors.map((err: string, i: number) => <li key={i}>• {err}</li>)}
            </ul>
          )}
        </div>
      )}
    </Modal>
  );
}

// ── Fotos en lote ────────────────────────────────────────────

interface BulkRow {
  key: string;
  file: File;
  preview: string;
  productId: string;
  auto: boolean;
  status: 'idle' | 'saving' | 'done' | 'error';
}

/** Producto que corresponde a un archivo: por SKU exacto, nombre exacto o el nombre más largo contenido */
export const matchProduct = (fileName: string, products: any[]): any | null => {
  const n = normalizeName(fileName);
  if (!n) return null;
  const compact = n.replace(/ /g, '');
  for (const p of products) for (const v of activeVariants(p)) if (normalizeName(v.sku).replace(/ /g, '') === compact) return p;
  const exact = products.find((p) => normalizeName(p.name) === n);
  if (exact) return exact;
  let best: any = null;
  for (const p of products) {
    const name = normalizeName(p.name);
    if (name.length >= 3 && (` ${n} `.includes(` ${name} `) || ` ${name} `.includes(` ${n} `)) && (!best || name.length > normalizeName(best.name).length)) best = p;
  }
  return best;
};

function BulkPhotosModal({ products, onClose, onSaved }: { products: any[]; onClose: () => void; onSaved: () => void }) {
  const [rows, setRows] = useState<BulkRow[]>([]);
  const [busy, setBusy] = useState(false);
  const [over, setOver] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  const sorted = useMemo(() => [...products].sort((a, b) => Number(!!a.imageUrl) - Number(!!b.imageUrl) || a.name.localeCompare(b.name)), [products]);
  const assigned = rows.filter((r) => r.productId && r.status !== 'done');
  const done = rows.filter((r) => r.status === 'done').length;

  useEffect(() => () => rows.forEach((r) => URL.revokeObjectURL(r.preview)), []); // eslint-disable-line react-hooks/exhaustive-deps

  const add = (files: FileList | null) => {
    if (!files) return;
    const taken = new Set(rows.map((r) => r.productId).filter(Boolean));
    const next: BulkRow[] = [];
    for (const file of Array.from(files)) {
      if (!/^image\/(jpeg|png|webp)$/.test(file.type)) {
        toast.error(`${file.name}: ${t('media:error_type')}`);
        continue;
      }
      const match = matchProduct(file.name, products);
      const productId = match && !taken.has(match.id) ? match.id : '';
      if (productId) taken.add(productId);
      next.push({ key: `${file.name}-${file.size}-${Math.random()}`, file, preview: URL.createObjectURL(file), productId, auto: !!productId, status: 'idle' });
    }
    setRows((r) => [...r, ...next]);
  };

  const save = async () => {
    setBusy(true);
    let ok = 0;
    let failed = 0;
    for (const row of assigned) {
      setRows((rs) => rs.map((r) => (r.key === row.key ? { ...r, status: 'saving' } : r)));
      try {
        const { img, url } = await readImageFile(row.file);
        const media = await uploadImage(img, 'product', CENTERED);
        URL.revokeObjectURL(url);
        await productsAPI.update(row.productId, { imageUrl: media });
        ok++;
        setRows((rs) => rs.map((r) => (r.key === row.key ? { ...r, status: 'done' } : r)));
      } catch {
        failed++;
        setRows((rs) => rs.map((r) => (r.key === row.key ? { ...r, status: 'error' } : r)));
      }
    }
    setBusy(false);
    if (ok) toast.success(t('media:lote_listo', { count: ok }));
    if (failed) toast.error(t('media:lote_fallo', { count: failed }));
    onSaved();
  };

  return (
    <Modal
      title={t('media:lote_titulo')}
      icon={<Images className="w-5 h-5" />}
      onClose={busy ? () => {} : onClose}
      wide
      footer={
        <>
          <button onClick={onClose} disabled={busy} className="sm:w-40 bg-white text-slate-700 px-6 py-3 rounded-xl font-bold text-sm border border-slate-300 hover:bg-slate-50">{t('admin:cerrar')}</button>
          <button onClick={save} disabled={busy || assigned.length === 0} className="flex-1 inline-flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-bold text-sm disabled:opacity-50">
            {busy && <Loader2 className="w-4 h-4 animate-spin" />}
            {busy ? t('media:lote_guardando', { done, count: done + assigned.length }) : t('media:lote_guardar', { count: assigned.length })}
          </button>
        </>
      }
    >
      <div className="flex items-start gap-2">
        <p className="text-sm text-slate-600 leading-relaxed flex-1">{t('media:lote_ayuda')}</p>
        <ImageGuide kind="product" align="right" />
      </div>
      <div
        role="button"
        tabIndex={0}
        onClick={() => input.current?.click()}
        onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && input.current?.click()}
        onDragOver={(e) => { e.preventDefault(); setOver(true); }}
        onDragLeave={() => setOver(false)}
        onDrop={(e) => { e.preventDefault(); setOver(false); add(e.dataTransfer.files); }}
        className={`border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer transition-all ${over ? 'border-blue-500 bg-blue-50/60' : 'border-slate-300 bg-slate-50/50 hover:border-blue-500'}`}
      >
        <input ref={input} type="file" multiple accept={ACCEPTED_IMAGE_TYPES} className="hidden" onChange={(e) => { add(e.target.files); e.target.value = ''; }} />
        <Images className="w-8 h-8 mx-auto mb-2 text-blue-600" />
        <p className="text-sm font-bold text-slate-800">{t('media:lote_elegir')}</p>
        <p className="text-xs text-slate-500 mt-1">{t('media:lote_soltar')}</p>
      </div>
      <p className="text-xs text-slate-500">{t('media:lote_recorte')}</p>

      {rows.length === 0 ? (
        <p className="text-sm text-slate-400 text-center py-4">{t('media:lote_vacio')}</p>
      ) : (
        <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {rows.map((row) => {
            const product = products.find((p) => p.id === row.productId);
            return (
              <li key={row.key} className={`flex gap-3 p-3 rounded-2xl border ${row.status === 'done' ? 'border-emerald-200 bg-emerald-50/50' : row.status === 'error' ? 'border-rose-200 bg-rose-50/50' : 'border-slate-200 bg-white'}`}>
                <img src={row.preview} alt="" className="w-16 h-16 rounded-xl object-cover border border-slate-200 shrink-0" />
                <div className="min-w-0 flex-1 space-y-1.5">
                  <p className="text-xs font-mono text-slate-500 truncate" title={row.file.name}>{row.file.name}</p>
                  <select
                    aria-label={`${t('media:lote_producto')}: ${row.file.name}`}
                    value={row.productId}
                    disabled={busy || row.status === 'done'}
                    onChange={(e) => setRows((rs) => rs.map((r) => (r.key === row.key ? { ...r, productId: e.target.value, auto: false, status: 'idle' } : r)))}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm outline-none focus:border-blue-600"
                  >
                    <option value="">{t('media:lote_sin_asignar')}</option>
                    {sorted.map((p) => <option key={p.id} value={p.id}>{p.name}{p.imageUrl ? ' ●' : ''}</option>)}
                  </select>
                  <p className="text-xs">
                    {row.status === 'done' ? <span className="text-emerald-700 font-semibold">✓ {t('products:foto_guardada_corta')}</span>
                      : row.status === 'saving' ? <span className="text-blue-700 font-semibold">{t('media:guardando')}</span>
                        : row.status === 'error' ? <span className="text-rose-700 font-semibold">{t('media:error_subir')}</span>
                          : product?.imageUrl ? <span className="text-amber-700">{t('media:lote_reemplaza')}</span>
                            : row.auto ? <span className="text-slate-500">{t('media:lote_auto')}</span> : null}
                  </p>
                </div>
                {row.status !== 'done' && (
                  <button type="button" disabled={busy} onClick={() => { URL.revokeObjectURL(row.preview); setRows((rs) => rs.filter((r) => r.key !== row.key)); }} aria-label={`${t('media:lote_quitar')}: ${row.file.name}`} className="self-start p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50">
                    <X className="w-4 h-4" />
                  </button>
                )}
              </li>
            );
          })}
        </ul>
      )}
    </Modal>
  );
}

// ── Nueva categoría ──────────────────────────────────────────

function NewCategoryModal({ onClose, onCreated }: { onClose: () => void; onCreated: (cat: any) => void }) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [error, setError] = useState<string | null>(null);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    try {
      onCreated(await productsAPI.createCategory({ name: name.trim(), description }));
    } catch (err: any) {
      setError(err.message || t('admin:error_al_crear_la_categoria'));
    }
  };
  return (
    <Modal title={t('admin:nueva_categoria')} icon={<Plus className="w-5 h-5" />} onClose={onClose}>
      <form onSubmit={submit} className="space-y-4">
        {error && <p role="alert" className="text-sm text-rose-700 bg-rose-50 border border-rose-200 rounded-xl px-3 py-2">{error}</p>}
        <div className="space-y-1">
          <label htmlFor="cat-name" className="text-xs font-semibold text-slate-700 ml-1">{t('admin:nombre')}</label>
          <input id="cat-name" type="text" placeholder={t('admin:ej_bebidas_comida_postres')} value={name} onChange={(e) => setName(e.target.value)} className={inputCls} required autoFocus />
        </div>
        <div className="space-y-1">
          <label htmlFor="cat-desc" className="text-xs font-semibold text-slate-700 ml-1">{t('admin:descripcion_opcional')}</label>
          <input id="cat-desc" type="text" placeholder={t('admin:breve_descripcion')} value={description} onChange={(e) => setDescription(e.target.value)} className={inputCls} />
        </div>
        <div className="flex gap-3 pt-2">
          <button type="submit" className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl font-bold shadow-sm flex items-center justify-center gap-2 text-sm">
            <Save className="w-4 h-4" /> {t('admin:crear_categoria')}
          </button>
          <button type="button" onClick={onClose} className="flex-1 bg-white text-slate-700 py-3 rounded-xl font-bold border border-slate-300 hover:bg-slate-50 text-sm">{t('admin:cancelar')}</button>
        </div>
      </form>
    </Modal>
  );
}
