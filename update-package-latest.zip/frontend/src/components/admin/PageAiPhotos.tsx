// ============================================
// ADMIN - Mi página → Carta: fotos con IA para los productos sin foto
// ============================================
// La IA hace una foto ilustrativa de cada producto publicado sin foto. Esas fotos
// viven en Lantify Cloud y SOLO se ven en la página pública (marcadas como
// ilustrativas): los productos del POS no cambian. Si después se sube la foto
// real del producto, la página usa la real. Se hacen de a tres por llamada.

import { useEffect, useRef, useState } from 'react';
import { ImagePlus, Loader2, Sparkles } from 'lucide-react';
import { pageAiImagesAPI, AiImagesStatus } from '../../services/api';
import { errorMessage } from '../../services/apiErrors';
import { confirmDialog } from '../../shared/dialog';
import { toast } from '../../shared/toast';
import { t } from '../../i18n';

export function PageAiPhotos({ card }: { card: string }) {
  const [status, setStatus] = useState<AiImagesStatus | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState<{ done: number; total: number } | null>(null);
  const stop = useRef(false);

  const load = () => pageAiImagesAPI.status().then((s) => { setStatus(s); setError(null); }).catch((e) => setError(errorMessage(e)));
  useEffect(() => {
    load();
    return () => { stop.current = true; };
  }, []);

  const fill = async () => {
    if (!status) return;
    stop.current = false;
    setRunning(true);
    const total = status.missing;
    let done = 0;
    let failed = 0;
    setProgress({ done, total });
    try {
      while (!stop.current) {
        const r = await pageAiImagesAPI.fill();
        done += r.generated;
        failed += r.failed;
        setProgress({ done, total });
        setStatus({ withoutPhoto: r.withoutPhoto, covered: r.covered, missing: r.remaining });
        // Sin avance (todas fallaron) o ya no falta ninguna: se para
        if (!r.remaining || !r.generated) break;
      }
      if (done) toast.success(t('page:ia_fotos_listas', { count: done }));
      if (failed) toast.warning(t('page:ia_fotos_fallidas', { count: failed }));
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setRunning(false);
      setProgress(null);
    }
  };

  const clear = async () => {
    if (!(await confirmDialog({ title: t('page:ia_fotos_quitar_titulo'), message: t('page:ia_fotos_quitar_desc'), confirmLabel: t('page:ia_fotos_quitar'), tone: 'danger' }))) return;
    try {
      await pageAiImagesAPI.clear();
      await load();
      toast.success(t('page:ia_fotos_quitadas'));
    } catch (e) {
      toast.error(errorMessage(e));
    }
  };

  return (
    <section className={card} aria-labelledby="ia-fotos-titulo">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="flex items-start gap-3 min-w-0">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-violet-100 text-violet-700" aria-hidden>
            <ImagePlus className="h-5 w-5" />
          </span>
          <div className="min-w-0">
            <h3 id="ia-fotos-titulo" className="text-base font-black text-slate-900">{t('page:ia_fotos_titulo')}</h3>
            <p className="mt-1 text-xs text-slate-500 max-w-xl">{t('page:ia_fotos_desc')}</p>
          </div>
        </div>
        {status && status.missing > 0 && (
          running ? (
            <button type="button" onClick={() => { stop.current = true; }}
              className="inline-flex items-center gap-2 min-h-[42px] px-4 rounded-xl border border-slate-200 bg-white text-sm font-bold text-slate-700 hover:bg-slate-50">
              <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
              {t('page:ia_fotos_progreso', { done: progress?.done ?? 0, total: progress?.total ?? status.missing })} · {t('page:ia_fotos_detener')}
            </button>
          ) : (
            <button type="button" onClick={fill}
              className="inline-flex items-center gap-2 min-h-[42px] px-4 rounded-xl bg-gradient-to-r from-violet-600 to-blue-600 text-sm font-bold text-white shadow-sm hover:opacity-95">
              <Sparkles className="h-4 w-4" aria-hidden /> {t('page:ia_fotos_completar', { count: status.missing })}
            </button>
          )
        )}
      </div>

      {error && <p className="text-xs text-amber-700">{t('page:ia_fotos_sin_conexion')}</p>}
      {status && (
        <p className="text-sm text-slate-700" role="status">
          {status.withoutPhoto === 0
            ? t('page:ia_fotos_todas_con_foto')
            : status.missing === 0
              ? t('page:ia_fotos_completas', { count: status.covered })
              : t('page:ia_fotos_estado', { missing: status.missing, covered: status.covered })}
        </p>
      )}
      {status && status.covered > 0 && !running && (
        <button type="button" onClick={clear} className="text-xs font-bold text-slate-500 hover:text-red-700 hover:underline">{t('page:ia_fotos_quitar')}</button>
      )}
    </section>
  );
}
