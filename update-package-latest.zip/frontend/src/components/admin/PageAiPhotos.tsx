// ============================================
// ADMIN - Mi página → Carta: fotos con IA para los productos sin foto
// ============================================
// Por cada producto sin foto, el ADMIN cuenta cómo es ("vaso plástico con tapa
// domo, fresas y crema") y la IA propone tres fotos; el negocio elige una. Esas
// fotos viven en Lantify Cloud y SOLO se ven en la página pública (marcadas como
// ilustrativas): los productos del POS no cambian. Si después se sube la foto
// real del producto, la página usa la real. Cada foto hecha gasta del cupo
// (diario y mensual), aunque no se elija, para no agotar la IA.

import { useEffect, useMemo, useRef, useState } from 'react';
import { Check, ImagePlus, Loader2, RefreshCw, Search, Sparkles, Trash2, Wand2, X } from 'lucide-react';
import { pageAiImagesAPI, AiImageProduct, AiImagesQuota, AiImagesStatus } from '../../services/api';
import { errorMessage } from '../../services/apiErrors';
import { confirmDialog } from '../../shared/dialog';
import { toast } from '../../shared/toast';
import { t } from '../../i18n';

const STYLE_KEY = 'lantify.aiPhotoStyle';
const PAGE = 30;

type Filter = 'missing' | 'done' | 'all';

/** Un producto: lo que se cuenta a la IA, las opciones propuestas y la elegida */
function ProductRow({ product, style, quota, onQuota, onImage }: {
  product: AiImageProduct;
  style: string;
  quota: AiImagesQuota | null;
  onQuota: (q: AiImagesQuota) => void;
  onImage: (key: string, image: string | null) => void;
}) {
  const [open, setOpen] = useState(false);
  const [hint, setHint] = useState(product.description || '');
  const [options, setOptions] = useState<{ id: string; url: string }[]>([]);
  const [busy, setBusy] = useState<'gen' | 'choose' | 'remove' | null>(null);
  const noRoom = !!quota && quota.left <= 0;

  const propose = async () => {
    setBusy('gen');
    try {
      const r = await pageAiImagesAPI.options(product.key, hint.trim(), style.trim());
      setOptions(r.options);
      onQuota(r.quota);
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusy(null);
    }
  };

  const choose = async (id: string) => {
    setBusy('choose');
    try {
      const r = await pageAiImagesAPI.choose(product.key, id);
      onImage(product.key, r.image);
      setOptions([]);
      setOpen(false);
      toast.success(t('page:ia_foto_elegida', { name: product.name }));
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusy(null);
    }
  };

  const remove = async () => {
    setBusy('remove');
    try {
      await pageAiImagesAPI.remove(product.key);
      onImage(product.key, null);
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusy(null);
    }
  };

  return (
    <li className="p-3">
      <div className="flex items-center gap-3">
        {product.image
          ? <img src={product.image} alt="" className="h-12 w-12 shrink-0 rounded-xl object-cover border border-slate-200" />
          : <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-slate-100 text-slate-400" aria-hidden><ImagePlus className="h-5 w-5" /></span>}
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-bold text-slate-900">{product.name}</p>
          <p className="truncate text-xs text-slate-500">
            {product.category} · {product.image ? t('page:ia_foto_con_ia') : t('page:ia_foto_sin')}
          </p>
        </div>
        <button type="button" onClick={() => setOpen((v) => !v)} aria-expanded={open}
          className={`inline-flex min-h-[36px] items-center gap-1.5 rounded-xl px-3 text-xs font-bold ${open ? 'bg-slate-100 text-slate-700' : 'border border-violet-200 bg-violet-50 text-violet-700 hover:bg-violet-100'}`}>
          {open ? <X className="h-3.5 w-3.5" aria-hidden /> : <Wand2 className="h-3.5 w-3.5" aria-hidden />}
          {open ? t('page:ia_foto_cerrar') : product.image ? t('page:ia_foto_cambiar') : t('page:ia_foto_elegir')}
        </button>
      </div>

      {open && (
        <div className="mt-3 space-y-3 rounded-2xl border border-slate-200 bg-slate-50/70 p-3">
          <label className="block">
            <span className="text-xs font-bold text-slate-700">{t('page:ia_foto_como_es')}</span>
            <textarea value={hint} onChange={(e) => setHint(e.target.value.slice(0, 240))} rows={2}
              placeholder={t('page:ia_foto_como_es_ej')}
              className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-800 focus:border-violet-500 focus:outline-none" />
            <span className="text-[0.7rem] text-slate-500">{t('page:ia_foto_como_es_ayuda')}</span>
          </label>

          <div className="flex flex-wrap items-center gap-2">
            <button type="button" onClick={propose} disabled={!!busy || noRoom}
              className="inline-flex min-h-[38px] items-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-blue-600 px-4 text-xs font-bold text-white shadow-sm hover:opacity-95 disabled:opacity-50">
              {busy === 'gen' ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : options.length ? <RefreshCw className="h-4 w-4" aria-hidden /> : <Sparkles className="h-4 w-4" aria-hidden />}
              {busy === 'gen' ? t('page:ia_foto_creando') : options.length ? t('page:ia_foto_otras') : t('page:ia_foto_proponer')}
            </button>
            <span className="text-[0.7rem] text-slate-500">{noRoom ? t('page:ia_cupo_agotado') : t('page:ia_foto_gasta')}</span>
            {product.image && (
              <button type="button" onClick={remove} disabled={!!busy}
                className="ml-auto inline-flex items-center gap-1 text-xs font-bold text-slate-500 hover:text-red-700">
                {busy === 'remove' ? <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden /> : <Trash2 className="h-3.5 w-3.5" aria-hidden />} {t('page:ia_foto_quitar_una')}
              </button>
            )}
          </div>

          {busy === 'gen' && (
            <div className="grid grid-cols-3 gap-2" aria-hidden>
              {[0, 1, 2].map((i) => <div key={i} className="aspect-square animate-pulse rounded-xl bg-slate-200" />)}
            </div>
          )}
          {options.length > 0 && busy !== 'gen' && (
            <div>
              <p className="mb-1.5 text-xs font-bold text-slate-700">{t('page:ia_foto_toca_una')}</p>
              <div className="grid grid-cols-3 gap-2">
                {options.map((o, i) => (
                  <button key={o.id} type="button" onClick={() => choose(o.id)} disabled={!!busy}
                    aria-label={t('page:ia_foto_opcion', { n: i + 1 })}
                    className="group relative overflow-hidden rounded-xl border-2 border-transparent bg-white hover:border-violet-500 focus-visible:border-violet-500 focus-visible:outline-none disabled:opacity-60">
                    <img src={o.url} alt="" className="aspect-square w-full object-cover" />
                    <span className="absolute inset-x-0 bottom-0 flex items-center justify-center gap-1 bg-violet-600/90 py-1 text-[0.7rem] font-bold text-white opacity-0 transition-opacity group-hover:opacity-100 group-focus-visible:opacity-100">
                      <Check className="h-3.5 w-3.5" aria-hidden /> {t('page:ia_foto_usar')}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </li>
  );
}

export function PageAiPhotos({ card }: { card: string }) {
  const [status, setStatus] = useState<AiImagesStatus | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState<{ done: number; total: number } | null>(null);
  const [style, setStyle] = useState(() => localStorage.getItem(STYLE_KEY) || '');
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<Filter>('missing');
  const [shown, setShown] = useState(PAGE);
  const stop = useRef(false);

  const load = () => pageAiImagesAPI.status().then((s) => { setStatus(s); setError(null); }).catch((e) => setError(errorMessage(e)));
  useEffect(() => {
    load();
    return () => { stop.current = true; };
  }, []);
  useEffect(() => {
    localStorage.setItem(STYLE_KEY, style);
  }, [style]);

  const quota = status?.quota ?? null;
  const setQuota = (q: AiImagesQuota) => setStatus((s) => (s ? { ...s, quota: q } : s));
  const setImage = (key: string, image: string | null) =>
    setStatus((s) => {
      if (!s) return s;
      const before = s.products?.find((p) => p.key === key)?.image ?? null;
      const delta = (image ? 1 : 0) - (before ? 1 : 0);
      return { ...s, covered: s.covered + delta, missing: s.missing - delta, products: s.products?.map((p) => (p.key === key ? { ...p, image } : p)) };
    });

  const products = useMemo(() => {
    const q = search.trim().toLowerCase();
    return (status?.products || []).filter((p) =>
      (filter === 'all' || (filter === 'missing' ? !p.image : !!p.image)) &&
      (!q || p.name.toLowerCase().includes(q) || p.category.toLowerCase().includes(q)));
  }, [status?.products, search, filter]);

  const fill = async () => {
    if (!status) return;
    const ok = await confirmDialog({
      title: t('page:ia_fotos_completar_titulo'),
      message: t('page:ia_fotos_completar_desc', { count: Math.min(status.missing, quota?.left ?? status.missing) }),
      confirmLabel: t('page:ia_fotos_completar_si'),
    });
    if (!ok) return;
    stop.current = false;
    setRunning(true);
    const total = status.missing;
    let done = 0;
    let failed = 0;
    setProgress({ done, total });
    try {
      while (!stop.current) {
        const r = await pageAiImagesAPI.fill(style.trim());
        done += r.generated;
        failed += r.failed;
        setProgress({ done, total });
        setStatus((s) => (s ? { ...s, withoutPhoto: r.withoutPhoto, covered: r.covered, missing: r.remaining, quota: r.quota ?? s.quota } : s));
        // Sin avance (todas fallaron) o ya no falta ninguna: se para
        if (!r.remaining || !r.generated) break;
      }
      if (done) toast.success(t('page:ia_fotos_listas', { count: done }));
      if (failed) toast.warning(t('page:ia_fotos_fallidas', { count: failed }));
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setRunning(false);
      setProgress(null);
      load();
    }
  };

  const clear = async () => {
    if (!(await confirmDialog({ title: t('page:ia_fotos_quitar_titulo'), message: t('page:ia_fotos_quitar_desc'), confirmLabel: t('page:ia_fotos_quitar'), tone: 'danger' }))) return;
    try {
      await pageAiImagesAPI.clear();
      await load();
      toast.success(t('page:ia_fotos_quitadas'));
    } catch (e) {
      toast.error(errorMessage(e));
    }
  };

  const filters: { v: Filter; label: string }[] = [
    { v: 'missing', label: t('page:ia_filtro_sin', { count: status?.missing ?? 0 }) },
    { v: 'done', label: t('page:ia_filtro_con', { count: status?.covered ?? 0 }) },
    { v: 'all', label: t('page:ia_filtro_todos', { count: status?.withoutPhoto ?? 0 }) },
  ];

  return (
    <section className={card} aria-labelledby="ia-fotos-titulo">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="flex items-start gap-3 min-w-0">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-violet-100 text-violet-700" aria-hidden>
            <ImagePlus className="h-5 w-5" />
          </span>
          <div className="min-w-0">
            <h3 id="ia-fotos-titulo" className="text-base font-black text-slate-900">{t('page:ia_fotos_titulo')}</h3>
            <p className="mt-1 text-xs text-slate-500 max-w-xl">{t('page:ia_fotos_desc')}</p>
          </div>
        </div>
        {quota && (
          <p className={`rounded-full px-3 py-1 text-xs font-bold ${quota.left > 0 ? 'bg-violet-50 text-violet-800' : 'bg-amber-50 text-amber-800'}`} role="status">
            {quota.left > 0
              ? t('page:ia_cupo', { left: quota.left, month: Math.max(0, quota.monthLimit - quota.monthUsed), monthLimit: quota.monthLimit })
              : t('page:ia_cupo_agotado')}
          </p>
        )}
      </div>

      {error && <p className="text-xs text-amber-700">{t('page:ia_fotos_sin_conexion')}</p>}
      {status && (
        <p className="text-sm text-slate-700" role="status">
          {status.items === 0
            ? t('page:ia_fotos_sin_carta')
            : status.withoutPhoto === 0
            ? t('page:ia_fotos_todas_con_foto')
            : status.missing === 0
              ? t('page:ia_fotos_completas', { count: status.covered })
              : t('page:ia_fotos_estado', { missing: status.missing, covered: status.covered })}
        </p>
      )}

      {status && status.withoutPhoto > 0 && (
        <>
          <label className="block">
            <span className="text-xs font-bold text-slate-700">{t('page:ia_estilo')}</span>
            <input value={style} onChange={(e) => setStyle(e.target.value.slice(0, 160))} placeholder={t('page:ia_estilo_ej')}
              className="mt-1 w-full min-h-[42px] rounded-xl border border-slate-200 bg-white px-3 text-sm text-slate-800 focus:border-violet-500 focus:outline-none" />
            <span className="text-[0.7rem] text-slate-500">{t('page:ia_estilo_ayuda')}</span>
          </label>

          <div className="flex flex-wrap items-center gap-2">
            <div className="relative min-w-[200px] flex-1">
              <Search className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-slate-400" aria-hidden />
              <input value={search} onChange={(e) => { setSearch(e.target.value); setShown(PAGE); }} placeholder={t('page:ia_buscar')} aria-label={t('page:ia_buscar')}
                className="w-full min-h-[40px] rounded-xl border border-slate-200 bg-white pl-9 pr-3 text-sm focus:border-violet-500 focus:outline-none" />
            </div>
            <div className="inline-flex rounded-xl border border-slate-200 bg-white p-0.5" role="group">
              {filters.map((f) => (
                <button key={f.v} type="button" onClick={() => { setFilter(f.v); setShown(PAGE); }} aria-pressed={filter === f.v}
                  className={`rounded-lg px-2.5 py-1.5 text-xs font-bold ${filter === f.v ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-50'}`}>
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          <ul className="max-h-[560px] overflow-y-auto rounded-2xl border border-slate-200 divide-y divide-slate-100 bg-white">
            {products.length === 0 && <li className="p-6 text-center text-sm text-slate-400">{t('page:ia_ninguno')}</li>}
            {products.slice(0, shown).map((p) => (
              <ProductRow key={p.key} product={p} style={style} quota={quota} onQuota={setQuota} onImage={setImage} />
            ))}
            {products.length > shown && (
              <li className="p-2 text-center">
                <button type="button" onClick={() => setShown((n) => n + PAGE)} className="text-xs font-bold text-blue-700 hover:underline">
                  {t('page:ia_ver_mas', { count: products.length - shown })}
                </button>
              </li>
            )}
          </ul>

          <div className="flex flex-wrap items-center gap-3 border-t border-slate-100 pt-3">
            {status.missing > 0 && (
              running ? (
                <button type="button" onClick={() => { stop.current = true; }}
                  className="inline-flex items-center gap-2 min-h-[38px] px-3 rounded-xl border border-slate-200 bg-white text-xs font-bold text-slate-700 hover:bg-slate-50">
                  <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                  {t('page:ia_fotos_progreso', { done: progress?.done ?? 0, total: progress?.total ?? status.missing })} · {t('page:ia_fotos_detener')}
                </button>
              ) : (
                <button type="button" onClick={fill} disabled={!!quota && quota.left <= 0}
                  className="inline-flex items-center gap-2 min-h-[38px] px-3 rounded-xl border border-violet-200 bg-white text-xs font-bold text-violet-700 hover:bg-violet-50 disabled:opacity-50">
                  <Sparkles className="h-4 w-4" aria-hidden /> {t('page:ia_fotos_completar', { count: status.missing })}
                </button>
              )
            )}
            {status.covered > 0 && !running && (
              <button type="button" onClick={clear} className="text-xs font-bold text-slate-500 hover:text-red-700 hover:underline">{t('page:ia_fotos_quitar')}</button>
            )}
          </div>
        </>
      )}
    </section>
  );
}
