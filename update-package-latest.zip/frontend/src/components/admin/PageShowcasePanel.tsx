// ============================================
// ADMIN - Mi página → Diseño: vitrina animada de la portada
// ============================================
// El negocio sube la foto de su producto estrella SIN FONDO y decide:
//   · el movimiento según lo que es (flota, tapa, capas, se parte) y dónde se
//     corta la foto (líneas que se arrastran sobre la imagen)
//   · el ambiente (el de la plantilla u otro), cuándo se abre y los ingredientes
//   · el tamaño y la ubicación, arrastrándola en la vista previa
// La vista previa es la portada REAL de la página (lantifypos.dpdns.org) dentro
// de un marco: lo que se ve aquí es lo que verá el cliente.

import { PointerEvent as RPointerEvent, useEffect, useMemo, useRef, useState } from 'react';
import { BookOpen, ChevronDown, Loader2, Minus, Monitor, Plus, RotateCcw, Smartphone, Trash2, Play } from 'lucide-react';
import { mediaAPI, PageCatalogProduct, PageState, PageTheme } from '../../services/api';
import { ACCEPTED_IMAGE_TYPES, MAX_SOURCE_BYTES, mediaSrc, readImageFile } from '../../shared/media';
import { toast } from '../../shared/toast';
import { t } from '../../i18n';
import {
  BUSINESS_TEMPLATES, SHOWCASE_EFFECTS, SHOWCASE_MOTIONS, SHOWCASE_TRIGGERS, TEMPLATE_SHOWCASE_EFFECT, defaultCuts,
  type ShowcaseMotion,
} from '../../../../src/domain/pageTheme';

type Showcase = NonNullable<PageTheme['showcase']>;
const MAX_EXTRAS = 4;
// La nube acepta fotos de hasta 600 KB
const MAX_BYTES = 560 * 1024;
const PREVIEW_ORIGIN = 'https://lantifypos.dpdns.org';
const PREVIEW_URL = `${PREVIEW_ORIGIN}/m-previa/portada`;

// ── Subir recortes ──────────────────────────────────────────
/** ¿Tiene fondo transparente? Mira el borde de la imagen */
const hasTransparency = (img: HTMLImageElement) => {
  const c = document.createElement('canvas');
  const size = 64;
  c.width = size;
  c.height = size;
  const ctx = c.getContext('2d', { willReadFrequently: true })!;
  ctx.drawImage(img, 0, 0, size, size);
  const d = ctx.getImageData(0, 0, size, size).data;
  let clear = 0;
  let edge = 0;
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      if (x > 1 && y > 1 && x < size - 2 && y < size - 2) continue;
      edge++;
      if (d[(y * size + x) * 4 + 3] < 40) clear++;
    }
  }
  return clear / edge > 0.5;
};

/** Reduce sin recortar y conserva la transparencia (WebP; si el navegador no puede, PNG) */
const encode = (img: HTMLImageElement, maxSide: number) => {
  let side = maxSide;
  for (let i = 0; i < 6; i++) {
    const scale = Math.min(1, side / Math.max(img.naturalWidth, img.naturalHeight));
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(img.naturalWidth * scale));
    c.height = Math.max(1, Math.round(img.naturalHeight * scale));
    const ctx = c.getContext('2d')!;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(img, 0, 0, c.width, c.height);
    let data = c.toDataURL('image/webp', 0.86);
    if (!data.startsWith('data:image/webp')) data = c.toDataURL('image/png');
    if ((data.length * 3) / 4 <= MAX_BYTES) return data;
    side = Math.round(side * 0.8);
  }
  throw new Error(t('page:vitrina_pesada'));
};

function CutoutButton({ label, maxSide, onUploaded, className, icon = true }: { label: string; maxSide: number; onUploaded: (url: string) => void; className: string; icon?: boolean }) {
  const input = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const pick = async (file?: File) => {
    if (!file) return;
    if (file.size > MAX_SOURCE_BYTES) return toast.error(t('media:error_size'));
    setBusy(true);
    try {
      const { img, url } = await readImageFile(file);
      URL.revokeObjectURL(url);
      if (!hasTransparency(img)) toast.warning(t('page:vitrina_con_fondo'));
      onUploaded((await mediaAPI.upload(encode(img, maxSide))).url);
    } catch (e) {
      toast.error((e as Error)?.message || t('media:error_subir'));
    } finally {
      setBusy(false);
    }
  };
  return (
    <>
      <input ref={input} type="file" accept={ACCEPTED_IMAGE_TYPES} className="sr-only" tabIndex={-1} aria-hidden
        onChange={(e) => { pick(e.target.files?.[0]); e.target.value = ''; }} />
      <button type="button" onClick={() => input.current?.click()} disabled={busy} className={className}>
        {busy ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : icon && <Plus className="h-4 w-4" aria-hidden />} {label}
      </button>
    </>
  );
}

// ── Íconos de los movimientos (trazo simple) ────────────────
function MotionIcon({ kind }: { kind: ShowcaseMotion }) {
  const common = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.6, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const };
  return (
    <svg viewBox="0 0 40 40" className="h-9 w-9" aria-hidden>
      {kind === 'lift' && <><path {...common} d="M14 30h12l2-14H12z" /><path {...common} d="M20 11V4m-3 3 3-3 3 3" /><ellipse cx="20" cy="36" rx="7" ry="1.4" fill="currentColor" opacity=".25" /></>}
      {kind === 'lid' && <><path {...common} d="M13 34h14l2-16H11z" /><path {...common} d="M10 12c0-4 4-6 10-6s10 2 10 6z" transform="rotate(-14 10 12) translate(-1 -3)" /></>}
      {kind === 'stack' && <><path {...common} d="M9 11c0-4 5-6 11-6s11 2 11 6z" /><path {...common} d="M9 20h22" /><path {...common} d="M10 27h20" /><path {...common} d="M10 33c0 1.5 3 2.5 10 2.5s10-1 10-2.5" /></>}
      {kind === 'split' && <><path {...common} d="M18 9c-6 1-10 7-10 14s3 10 9 10l2-12z" transform="rotate(-10 18 22)" /><path {...common} d="M22 9c6 1 10 7 10 14s-3 10-9 10l-2-12z" transform="rotate(10 22 22)" /></>}
    </svg>
  );
}

// ── Editor de cortes ────────────────────────────────────────
const checker = 'bg-[repeating-conic-gradient(#e2e8f0_0_25%,#fff_0_50%)] [background-size:16px_16px]';

function CutEditor({ image, motion, cuts, onChange }: { image: string; motion: ShowcaseMotion; cuts: number[]; onChange: (c: number[]) => void }) {
  const box = useRef<HTMLDivElement>(null);
  const dragging = useRef<number | null>(null);
  const vertical = motion === 'split';
  const [lo, hi] = vertical ? [20, 80] : [5, 90];
  const at = (e: RPointerEvent) => {
    const r = box.current!.getBoundingClientRect();
    const v = vertical ? ((e.clientX - r.left) / r.width) * 100 : ((e.clientY - r.top) / r.height) * 100;
    return Math.round(Math.min(hi, Math.max(lo, v)));
  };
  const update = (i: number, v: number) => onChange(cuts.map((c, j) => (j === i ? v : c)).sort((a, b) => a - b));
  return (
    <div className="space-y-2">
      <div ref={box} className={`relative aspect-square w-full touch-none select-none overflow-hidden rounded-xl ring-1 ring-slate-200 ${checker} ${vertical ? 'cursor-ew-resize' : 'cursor-ns-resize'}`}
        onPointerDown={(e) => {
          const v = at(e);
          let best = 0;
          cuts.forEach((c, i) => { if (Math.abs(c - v) < Math.abs(cuts[best] - v)) best = i; });
          dragging.current = best;
          (e.target as HTMLElement).setPointerCapture(e.pointerId);
          update(best, v);
        }}
        onPointerMove={(e) => dragging.current !== null && update(dragging.current, at(e))}
        onPointerUp={() => { dragging.current = null; }}>
        <img src={mediaSrc(image)} alt="" draggable={false} className="pointer-events-none absolute inset-0 h-full w-full object-contain" />
        {cuts.map((c, i) => (
          <div key={i} aria-hidden className={`pointer-events-none absolute ${vertical ? 'inset-y-0 w-0 border-l-2' : 'inset-x-0 h-0 border-t-2'} border-dashed border-fuchsia-600`}
            style={vertical ? { left: `${c}%` } : { top: `${c}%` }}>
            <span className={`absolute grid h-6 w-6 place-items-center rounded-full bg-fuchsia-600 text-[0.65rem] font-black text-white shadow ${vertical ? '-left-3 top-2' : '-top-3 right-2'}`}>{i + 1}</span>
          </div>
        ))}
      </div>
      <div className="flex flex-wrap items-center gap-2">
        {cuts.map((c, i) => (
          <label key={i} className="flex items-center gap-1 text-[0.7rem] font-bold text-slate-600">
            {i + 1}
            <input type="number" min={lo} max={hi} value={c} onChange={(e) => update(i, Math.min(hi, Math.max(lo, Number(e.target.value) || lo)))}
              className="w-14 rounded-lg border border-slate-200 px-1.5 py-1 text-xs" aria-label={t('page:vitrina_corte_n', { n: i + 1 })} />%
          </label>
        ))}
        {motion === 'stack' && (
          <span className="ml-auto flex gap-1">
            <button type="button" disabled={cuts.length <= 1} onClick={() => onChange(cuts.slice(0, -1))} aria-label={t('page:vitrina_menos_capas')}
              className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 bg-white text-slate-700 disabled:opacity-40"><Minus className="h-4 w-4" /></button>
            <button type="button" disabled={cuts.length >= 3} aria-label={t('page:vitrina_mas_capas')}
              onClick={() => {
                const b = [0, ...cuts, 100];
                let gap = 0;
                for (let i = 1; i < b.length - 1; i++) if (b[i + 1] - b[i] > b[gap + 1] - b[gap]) gap = i;
                onChange([...cuts, Math.round((b[gap] + b[gap + 1]) / 2)].sort((a, z) => a - z));
              }}
              className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 bg-white text-slate-700 disabled:opacity-40"><Plus className="h-4 w-4" /></button>
          </span>
        )}
      </div>
      <p className="text-[0.7rem] leading-snug text-slate-500">{t(`page:vitrina_cortes_ayuda_${motion}`)}</p>
    </div>
  );
}

// ── Vista previa en vivo (la portada real en un marco) ──────
const dataUrlCache = new Map<string, string>();
/** Las fotos que todavía están en el equipo se mandan como datos al marco */
const toPreviewSrc = async (url: string | null | undefined) => {
  if (!url) return null;
  if (!url.startsWith('/api/')) return url;
  const hit = dataUrlCache.get(url);
  if (hit) return hit;
  const blob = await (await fetch(mediaSrc(url)!)).blob();
  const data = await new Promise<string>((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result));
    r.onerror = reject;
    r.readAsDataURL(blob);
  });
  dataUrlCache.set(url, data);
  return data;
};

function LivePreview({ theme, state, tagline, itemName, itemPrice, onLayout }: {
  theme: PageTheme; state: PageState; tagline: string | null; itemName: string | null; itemPrice: number; onLayout: (l: Showcase['layout']) => void;
}) {
  const frame = useRef<HTMLIFrameElement>(null);
  const wrap = useRef<HTMLDivElement>(null);
  const [ready, setReady] = useState(false);
  const [failed, setFailed] = useState(false);
  const [device, setDevice] = useState<'desktop' | 'mobile'>('desktop');
  const [open, setOpen] = useState<'auto' | 'open' | 'closed'>('auto');
  const [cw, setCw] = useState(640);
  const readyRef = useRef(false);
  readyRef.current = ready;
  const size = device === 'desktop' ? { w: 1280, h: 800 } : { w: 390, h: 780 };
  const k = Math.min(1, cw / size.w, device === 'mobile' ? 560 / size.h : 1);

  useEffect(() => {
    if (!wrap.current) return;
    const ro = new ResizeObserver(([e]) => setCw(e.contentRect.width));
    ro.observe(wrap.current);
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    const onMsg = (e: MessageEvent) => {
      if (e.origin !== PREVIEW_ORIGIN || e.source !== frame.current?.contentWindow) return;
      if (e.data?.type === 'lantify-preview-ready') {
        setReady(true);
        setFailed(false);
      }
      if (e.data?.type === 'lantify-preview-layout' && e.data.layout) onLayout(e.data.layout);
    };
    window.addEventListener('message', onMsg);
    const timer = window.setTimeout(() => setFailed(!readyRef.current), 15000);
    return () => {
      window.removeEventListener('message', onMsg);
      window.clearTimeout(timer);
    };
  }, [onLayout]);

  // Cada cambio se manda al marco (las fotos locales, convertidas a datos)
  const payloadKey = JSON.stringify({ theme, tagline, itemName, itemPrice, open });
  useEffect(() => {
    if (!ready || !theme.showcase) return;
    let stale = false;
    const id = window.setTimeout(async () => {
      try {
        const s = theme.showcase!;
        const [image, logo, ...extras] = await Promise.all([toPreviewSrc(s.image), toPreviewSrc(theme.logoImage), ...s.extras.map(toPreviewSrc)]);
        if (stale) return;
        frame.current?.contentWindow?.postMessage({
          type: 'lantify-preview',
          payload: {
            theme: { ...theme, logoImage: logo, coverImage: null, showcase: { ...s, image, extras: extras.filter(Boolean) } },
            businessName: state.business.name, tagline,
            place: [state.profile.address, state.profile.city].filter(Boolean).join(', ') || null, hours: state.profile.hours,
            item: itemName ? { name: itemName, price: itemPrice } : null,
            open, editable: true,
          },
        }, PREVIEW_ORIGIN);
      } catch {
        /* la foto aún no está lista */
      }
    }, 120);
    return () => {
      stale = true;
      window.clearTimeout(id);
    };
  }, [ready, payloadKey]); // eslint-disable-line react-hooks/exhaustive-deps

  const seg = (active: boolean) => `inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-bold ${active ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'}`;
  return (
    <div className="space-y-2">
      <div className="flex flex-wrap items-center gap-2">
        <div className="inline-flex rounded-xl border border-slate-200 bg-white p-0.5" role="group" aria-label={t('page:vitrina_vista_dispositivo')}>
          <button type="button" className={seg(device === 'desktop')} onClick={() => { setDevice('desktop'); setReady(false); }} aria-pressed={device === 'desktop'}><Monitor className="h-3.5 w-3.5" aria-hidden /> {t('page:vitrina_vista_pc')}</button>
          <button type="button" className={seg(device === 'mobile')} onClick={() => { setDevice('mobile'); setReady(false); }} aria-pressed={device === 'mobile'}><Smartphone className="h-3.5 w-3.5" aria-hidden /> {t('page:vitrina_vista_cel')}</button>
        </div>
        <div className="inline-flex rounded-xl border border-slate-200 bg-white p-0.5" role="group" aria-label={t('page:vitrina_vista_estado')}>
          {(['auto', 'open', 'closed'] as const).map((o) => (
            <button key={o} type="button" className={seg(open === o)} onClick={() => setOpen(o)} aria-pressed={open === o}>{t(`page:vitrina_vista_${o}`)}</button>
          ))}
        </div>
        <button type="button" onClick={() => frame.current?.contentWindow?.postMessage({ type: 'lantify-preview-replay' }, PREVIEW_ORIGIN)}
          className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-xs font-bold text-slate-700 hover:bg-slate-50">
          <Play className="h-3.5 w-3.5" aria-hidden /> {t('page:vitrina_vista_repetir')}
        </button>
      </div>
      <div ref={wrap} className="relative overflow-hidden rounded-2xl border border-slate-200 bg-slate-900">
        <div className="mx-auto" style={{ width: size.w * k, height: size.h * k }}>
          <iframe ref={frame} key={device} src={PREVIEW_URL} title={t('page:vitrina_vista_titulo')}
            style={{ width: size.w, height: size.h, transform: `scale(${k})`, transformOrigin: 'top left', border: 0, display: 'block' }} />
        </div>
        {!ready && (
          <div className="absolute inset-0 grid place-items-center bg-slate-900/90 p-6 text-center text-sm text-white/80">
            {failed ? t('page:vitrina_vista_sin_internet') : <span className="inline-flex items-center gap-2"><Loader2 className="h-4 w-4 animate-spin" aria-hidden />{t('page:vitrina_vista_cargando')}</span>}
          </div>
        )}
      </div>
      <p className="text-[0.7rem] text-slate-500">{t('page:vitrina_vista_ayuda')}</p>
    </div>
  );
}

// ── Panel ───────────────────────────────────────────────────
const EFFECT_SWATCH: Record<string, string> = {
  aura: 'bg-[conic-gradient(from_90deg,#a78bfa,#f472b6,#fbbf24,#a78bfa)]',
  splash: 'bg-[radial-gradient(circle_at_35%_35%,#fff_0_12%,#38bdf8_14%_60%,#0369a1)]',
  steam: 'bg-[linear-gradient(180deg,#e2e8f0,#94a3b8)]',
  sparkle: 'bg-[radial-gradient(circle,#fef3c7_0_20%,#f59e0b_45%,#78350f)]',
  embers: 'bg-[radial-gradient(circle_at_50%_70%,#fde68a_0_15%,#f97316_40%,#7c2d12)]',
  club: 'bg-[conic-gradient(from_200deg,#7c3aed,#ec4899,#06b6d4,#7c3aed)]',
  pop: 'bg-[radial-gradient(#111_1.2px,transparent_1.4px)_0_0/6px_6px,#facc15]',
};

export function PageShowcasePanel({ theme, catalog, state, tagline, onChange }: {
  theme: PageTheme;
  catalog: PageCatalogProduct[];
  state: PageState;
  tagline: string | null;
  onChange: (s: Showcase | null) => void;
}) {
  const s = theme.showcase;
  const set = (patch: Partial<Showcase>) => s && onChange({ ...s, ...patch });
  const options = useMemo(() => catalog.filter((p) => p.visible).flatMap((p) =>
    (p.variants?.length ? p.variants : []).map((v) => ({ id: v.id, price: v.price, label: p.variants!.length > 1 ? `${p.name} · ${v.name}` : p.name }))), [catalog]);
  const linked = options.find((o) => o.id === s?.itemId) || null;
  const templateFx = TEMPLATE_SHOWCASE_EFFECT[theme.template];
  // La ubicación llega desde el marco: se aplica sobre la vitrina más reciente
  const latest = useRef(s);
  latest.current = s;
  const change = useRef(onChange);
  change.current = onChange;
  const onLayout = useMemo(() => (layout: Showcase['layout']) => {
    if (latest.current) change.current({ ...latest.current, layout });
  }, []);

  const section = 'space-y-2';
  const label = 'text-xs font-black uppercase tracking-wide text-slate-500';
  const card = (active: boolean) => `rounded-xl border p-2.5 text-left transition-colors ${active ? 'border-slate-900 bg-slate-900 text-white' : 'border-slate-200 bg-white text-slate-800 hover:border-slate-400'}`;

  return (
    <section className="space-y-4 rounded-3xl border border-slate-200 bg-white p-6" aria-labelledby="vitrina-titulo">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 id="vitrina-titulo" className="text-base font-black text-slate-900">{t('page:vitrina_titulo')}</h3>
          <p className="mt-1 max-w-2xl text-xs text-slate-500">{t('page:vitrina_desc')}</p>
        </div>
        {s && (
          <button type="button" onClick={() => onChange(null)} className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-rose-700">
            <Trash2 className="h-3.5 w-3.5" aria-hidden /> {t('page:vitrina_quitar')}
          </button>
        )}
      </div>

      <details open={!s} className="group rounded-2xl border border-slate-200 bg-slate-50 p-4">
        <summary className="flex cursor-pointer list-none items-center gap-2 text-sm font-bold text-slate-800">
          <BookOpen className="h-4 w-4 text-slate-500" aria-hidden /> {t('page:vitrina_guia_titulo')}
          <ChevronDown className="ml-auto h-4 w-4 transition-transform group-open:rotate-180" aria-hidden />
        </summary>
        <ol className="mt-3 grid gap-3 text-xs leading-relaxed text-slate-700 md:grid-cols-5">
          {[1, 2, 3, 4, 5].map((n) => (
            <li key={n} className="rounded-xl bg-white p-3 ring-1 ring-slate-200">
              <span className="block text-[0.65rem] font-black uppercase tracking-wider text-slate-400">{t('page:vitrina_paso', { n })}</span>
              <span className="mt-1 block font-bold text-slate-900">{t(`page:vitrina_paso_${n}_t`)}</span>
              <span className="mt-1 block">{t(`page:vitrina_paso_${n}`)}</span>
            </li>
          ))}
        </ol>
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          <p className="rounded-xl bg-emerald-50 p-3 text-xs leading-snug text-emerald-900"><b>{t('page:vitrina_bien')}</b> {t('page:vitrina_bien_texto')}</p>
          <p className="rounded-xl bg-rose-50 p-3 text-xs leading-snug text-rose-900"><b>{t('page:vitrina_mal')}</b> {t('page:vitrina_mal_texto')}</p>
        </div>
      </details>

      {!s ? (
        <div className="flex flex-wrap items-center gap-3">
          <CutoutButton label={t('page:vitrina_subir')} maxSide={1000}
            onUploaded={(image) => onChange({ image, motion: 'lift', cuts: [], extras: [], itemId: null, effect: 'auto', trigger: 'hover', layout: { x: 0, y: 0, size: 100 } })}
            className="inline-flex min-h-[42px] items-center gap-2 rounded-xl bg-slate-900 px-4 text-sm font-bold text-white hover:bg-slate-800 disabled:opacity-60" />
          <p className="max-w-md text-xs leading-snug text-slate-500">{t('page:vitrina_como_quitar_fondo')}</p>
        </div>
      ) : (
        <div className="grid gap-6 xl:grid-cols-[22rem_minmax(0,1fr)]">
          <div className="space-y-5">
            <div className={section}>
              <p className={label}>{t('page:vitrina_movimiento')}</p>
              <div className="grid grid-cols-2 gap-2" role="radiogroup" aria-label={t('page:vitrina_movimiento')}>
                {SHOWCASE_MOTIONS.map((m) => (
                  <button key={m} type="button" role="radio" aria-checked={s.motion === m} className={card(s.motion === m)}
                    onClick={() => set({ motion: m, cuts: m === s.motion ? s.cuts : defaultCuts(m) })}>
                    <MotionIcon kind={m} />
                    <span className="mt-1 block text-xs font-black">{t(`page:vitrina_mov_${m}`)}</span>
                    <span className={`mt-0.5 block text-[0.68rem] leading-snug ${s.motion === m ? 'text-white/70' : 'text-slate-500'}`}>{t(`page:vitrina_mov_${m}_desc`)}</span>
                  </button>
                ))}
              </div>
            </div>

            {s.motion !== 'lift' && (
              <div className={section}>
                <p className={label}>{t('page:vitrina_cortes')}</p>
                <CutEditor image={s.image} motion={s.motion} cuts={s.cuts} onChange={(cuts) => set({ cuts })} />
              </div>
            )}

            <div className={section}>
              <p className={label}>{t('page:vitrina_ambiente')}</p>
              <div className="grid grid-cols-2 gap-2" role="radiogroup" aria-label={t('page:vitrina_ambiente')}>
                {SHOWCASE_EFFECTS.map((e) => {
                  const active = s.effect === e;
                  const swatch = EFFECT_SWATCH[e === 'auto' ? templateFx : e];
                  return (
                    <button key={e} type="button" role="radio" aria-checked={active} onClick={() => set({ effect: e })} className={`flex items-start gap-2 ${card(active)}`}>
                      <span aria-hidden className={`mt-0.5 h-5 w-5 shrink-0 rounded-full ring-1 ring-black/10 ${swatch}`} />
                      <span className="min-w-0">
                        <span className="block text-xs font-black">{e === 'auto' ? t('page:vitrina_fx_auto', { plantilla: BUSINESS_TEMPLATES[theme.template]?.name || '' }) : t(`page:vitrina_fx_${e}`)}</span>
                        <span className={`block text-[0.68rem] leading-snug ${active ? 'text-white/70' : 'text-slate-500'}`}>{e === 'auto' ? t(`page:vitrina_fx_${templateFx}`) : t(`page:vitrina_fx_${e}_desc`)}</span>
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className={section}>
              <p className={label}>{t('page:vitrina_cuando')}</p>
              <div className="grid gap-2" role="radiogroup" aria-label={t('page:vitrina_cuando')}>
                {SHOWCASE_TRIGGERS.map((k) => (
                  <button key={k} type="button" role="radio" aria-checked={s.trigger === k} onClick={() => set({ trigger: k })} className={card(s.trigger === k)}>
                    <span className="block text-xs font-black">{t(`page:vitrina_cuando_${k}`)}</span>
                    <span className={`block text-[0.68rem] leading-snug ${s.trigger === k ? 'text-white/70' : 'text-slate-500'}`}>{t(`page:vitrina_cuando_${k}_desc`)}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className={section}>
              <p className={label}>{t('page:vitrina_ingredientes')}</p>
              <div className="flex flex-wrap items-center gap-2">
                {s.extras.map((u, i) => (
                  <span key={u} className={`relative h-14 w-14 overflow-hidden rounded-xl ring-1 ring-slate-200 ${checker}`}>
                    <img src={mediaSrc(u)} alt="" className="h-full w-full object-contain" />
                    <button type="button" onClick={() => set({ extras: s.extras.filter((_, j) => j !== i) })} aria-label={t('page:vitrina_quitar_ingrediente')}
                      className="absolute right-0.5 top-0.5 grid h-5 w-5 place-items-center rounded-full bg-white/90 text-slate-600 shadow hover:text-rose-700">
                      <Minus className="h-3 w-3" />
                    </button>
                  </span>
                ))}
                {s.extras.length < MAX_EXTRAS && (
                  <CutoutButton label={t('page:vitrina_agregar_ingrediente')} maxSide={420}
                    onUploaded={(u) => set({ extras: [...s.extras, u].slice(0, MAX_EXTRAS) })}
                    className="inline-flex min-h-[42px] items-center gap-1.5 rounded-xl border border-dashed border-slate-300 bg-white px-3 text-xs font-bold text-slate-700 hover:border-slate-500 disabled:opacity-60" />
                )}
              </div>
              <p className="text-[0.7rem] text-slate-500">{t('page:vitrina_ingredientes_ayuda')}</p>
            </div>

            <label className={`block ${section}`}>
              <span className={label}>{t('page:vitrina_producto')}</span>
              <select value={s.itemId || ''} onChange={(e) => set({ itemId: e.target.value || null })}
                className="w-full min-h-[42px] rounded-xl border border-slate-200 bg-white px-3 text-sm text-slate-800 focus:border-slate-900 focus:outline-none">
                <option value="">{t('page:vitrina_producto_ninguno')}</option>
                {options.map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}
              </select>
              <span className="block text-[0.7rem] text-slate-500">{t('page:vitrina_producto_ayuda')}</span>
            </label>

            <CutoutButton label={t('page:vitrina_cambiar')} maxSide={1000} icon={false} onUploaded={(image) => set({ image })}
              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 text-xs font-bold text-slate-700 hover:bg-slate-50 disabled:opacity-60" />
          </div>

          <div className="min-w-0 space-y-3">
            <LivePreview theme={theme} state={state} tagline={tagline} itemName={linked?.label ?? null} itemPrice={linked?.price ?? 0} onLayout={onLayout} />
            <div className="flex flex-wrap items-center gap-4 rounded-2xl border border-slate-200 p-3">
              <label className="flex min-w-[220px] flex-1 items-center gap-3">
                <span className="text-xs font-bold text-slate-700">{t('page:vitrina_tamano')}</span>
                <input type="range" min={50} max={160} step={1} value={s.layout.size} onChange={(e) => set({ layout: { ...s.layout, size: Number(e.target.value) } })} className="flex-1 accent-slate-900" />
                <span className="w-12 text-right font-mono text-xs text-slate-600">{s.layout.size}%</span>
              </label>
              <span className="font-mono text-xs text-slate-500">{t('page:vitrina_posicion', { x: s.layout.x, y: s.layout.y })}</span>
              <button type="button" onClick={() => set({ layout: { x: 0, y: 0, size: 100 } })}
                className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-xs font-bold text-slate-700 hover:bg-slate-50">
                <RotateCcw className="h-3.5 w-3.5" aria-hidden /> {t('page:vitrina_centrar')}
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
