// ============================================
// ADMIN - Facturación electrónica DIAN y cola sin internet
// ============================================
// Lantify es la casa de software: su nube emite las facturas ante la DIAN por medio
// de un proveedor tecnológico autorizado. El negocio no configura credenciales ni
// hace envíos de prueba: aquí ve si Lantify ya le activó la facturación, su
// resolución y sus facturas (las que esperan respuesta se reenvían solas).

import { useEffect, useState } from 'react';
import { AlertCircle, Check, CheckCircle2, Clock, Copy, ExternalLink, FileText, RefreshCw, Send, ShieldCheck } from 'lucide-react';
import { dianAPI, DianStatus } from '../../services/api';
import { errorMessage } from '../../services/apiErrors';
import { toast } from '../../shared/toast';
import { formatCurrency } from '../../shared/formatUtils';
import { copyText } from '../../shared/browser';
import { t, getLocale } from '../../i18n';

type Filter = 'ALL' | 'PENDING_QUEUE' | 'ACCEPTED' | 'REJECTED';

const fmtDate = (iso?: string | null, withTime = false) =>
  iso ? new Date(iso).toLocaleString(getLocale(), withTime ? { dateStyle: 'short', timeStyle: 'short' } : { dateStyle: 'medium' }) : '—';

const isProvisional = (number: string) => number.startsWith('EN-COLA-');

function StatusPill({ status }: { status: string }) {
  const base = 'inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-bold';
  if (status === 'ACCEPTED') return <span className={`${base} border-success-border bg-success-soft text-success-text`}><CheckCircle2 className="h-3 w-3" aria-hidden />{t('dian:aceptada_dian')}</span>;
  if (status === 'REJECTED') return <span className={`${base} border-danger-border bg-danger-soft text-danger-text`}><AlertCircle className="h-3 w-3" aria-hidden />{t('dian:rechazada')}</span>;
  if (status === 'TRANSMITTING') return <span className={`${base} border-info-border bg-info-soft text-info-text`}><RefreshCw className="h-3 w-3 animate-spin" aria-hidden />{t('dian:transmitiendo_2')}</span>;
  return <span className={`${base} border-warning-border bg-warning-soft text-warning-text`}><Clock className="h-3 w-3" aria-hidden />{t('dian:fe_en_cola')}</span>;
}

export function DianBillingAdmin() {
  const [status, setStatus] = useState<DianStatus | null>(null);
  const [stats, setStats] = useState<any>(null);
  const [invoices, setInvoices] = useState<any[]>([]);
  const [filter, setFilter] = useState<Filter>('ALL');
  const [checking, setChecking] = useState(false);
  const [sending, setSending] = useState(false);
  const [retrying, setRetrying] = useState<string | null>(null);
  const [cufe, setCufe] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const load = async (refresh = false) => {
    try {
      const [s, st, q] = await Promise.all([dianAPI.getStatus(refresh), dianAPI.getStats(), dianAPI.getQueue()]);
      setStatus(s.status);
      setStats(st);
      setInvoices(q?.invoices || []);
    } catch (err) {
      console.warn('Facturación electrónica:', err);
    }
  };

  useEffect(() => {
    load();
    const interval = setInterval(() => load(), 30000);
    return () => clearInterval(interval);
  }, []);

  const refreshStatus = async () => {
    setChecking(true);
    await load(true);
    setChecking(false);
  };

  const sendQueue = async () => {
    setSending(true);
    try {
      const res = await dianAPI.processQueue();
      toast.info(res.message);
      await load();
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setSending(false);
    }
  };

  const retry = async (id: string) => {
    setRetrying(id);
    try {
      const res = await dianAPI.retryInvoice(id);
      if (res.invoice?.status === 'ACCEPTED') toast.success(res.message);
      else toast.warning(res.message);
      await load();
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setRetrying(null);
    }
  };

  const shown = invoices.filter((inv) => filter === 'ALL' || inv.status === filter || (filter === 'PENDING_QUEUE' && inv.status === 'TRANSMITTING'));
  const active = !!status?.active;

  return (
    <div className="space-y-4 max-w-5xl pb-20">
      <section className="bg-surface border border-line rounded-2xl p-6" aria-labelledby="fe-titulo">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="flex items-start gap-3 min-w-0">
            <span className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl ${active ? 'bg-success-soft text-success-text' : 'bg-surface-sunken text-fg-muted'}`} aria-hidden>
              <ShieldCheck className="h-5 w-5" />
            </span>
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <h2 id="fe-titulo" className="text-lg font-bold text-fg">{t('dian:fe_titulo')}</h2>
                {status && (
                  <span className={`rounded-full px-2.5 py-0.5 text-xs font-bold ${active ? 'bg-success-soft text-success-text' : 'bg-surface-sunken text-fg-muted'}`}>
                    {active ? t('dian:fe_activa') : t('dian:fe_no_activa')}
                  </span>
                )}
              </div>
              <p className="mt-1 text-sm text-fg-secondary max-w-2xl">{active ? t('dian:fe_activa_desc') : t('dian:fe_no_activa_desc')}</p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <button type="button" onClick={refreshStatus} disabled={checking}
              className="inline-flex min-h-[40px] items-center gap-2 rounded-xl border border-line px-4 text-xs font-bold text-fg hover:bg-surface-muted disabled:opacity-60">
              <RefreshCw className={`h-4 w-4 ${checking ? 'animate-spin' : ''}`} aria-hidden /> {t('dian:fe_actualizar')}
            </button>
            {active && (
              <button type="button" onClick={sendQueue} disabled={sending || !stats?.queue?.pending}
                className="inline-flex min-h-[40px] items-center gap-2 rounded-xl bg-primary px-4 text-xs font-bold text-white hover:opacity-95 disabled:opacity-50">
                <Send className="h-4 w-4" aria-hidden /> {sending ? t('dian:fe_enviando') : t('dian:fe_enviar_cola')}
              </button>
            )}
          </div>
        </div>

        {active && status ? (
          <dl className="mt-5 grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
            {[
              [t('dian:fe_documento'), status.documentKind === 'pos' ? t('dian:fe_doc_pos') : t('dian:fe_doc_invoice')],
              [t('dian:fe_resolucion'), status.resolutionNumber || '—'],
              [t('dian:fe_rango'), `${status.prefix ? `${status.prefix} ` : ''}${status.rangeFrom}–${status.rangeTo}`],
              [t('dian:fe_vigente_hasta'), fmtDate(status.validUntil)],
            ].map(([label, value]) => (
              <div key={label} className="rounded-xl bg-surface-sunken px-3 py-2 min-w-0">
                <dt className="text-[0.7857rem] text-fg-muted">{label}</dt>
                <dd className="font-bold text-fg tabular-nums truncate">{value}</dd>
              </div>
            ))}
          </dl>
        ) : status && (
          <div className="mt-5 rounded-xl border border-line bg-surface-sunken p-4">
            <h3 className="text-sm font-bold text-fg">{t('dian:fe_requisitos_titulo')}</h3>
            <ul className="mt-2 space-y-1.5 text-sm text-fg-secondary">
              {['fe_req_rut', 'fe_req_habilitacion', 'fe_req_resolucion'].map((k) => (
                <li key={k} className="flex items-start gap-2"><Check className="mt-0.5 h-4 w-4 shrink-0 text-fg-muted" aria-hidden />{t(`dian:${k}`)}</li>
              ))}
            </ul>
            <p className="mt-3 text-xs text-fg-muted">{t('dian:fe_pidela')}</p>
          </div>
        )}
        {status?.checkedAt && <p className="mt-3 text-[0.7857rem] text-fg-muted">{t('dian:fe_consultado', { date: fmtDate(status.checkedAt, true) })}</p>}
      </section>

      {(active || invoices.length > 0) && (
        <section className="bg-surface border border-line rounded-2xl p-6 space-y-4" aria-labelledby="fe-facturas">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div>
              <h3 id="fe-facturas" className="text-base font-bold text-fg">{t('dian:fe_facturas_titulo')}</h3>
              <p className="text-xs text-fg-muted">{t('dian:fe_facturas_desc')}</p>
            </div>
            <div className="flex flex-wrap gap-1.5" role="tablist">
              {([
                ['ALL', t('dian:todas'), stats?.queue?.total],
                ['PENDING_QUEUE', t('dian:fe_en_cola'), stats?.queue?.pending],
                ['ACCEPTED', t('dian:fe_validadas'), stats?.queue?.accepted],
                ['REJECTED', t('dian:fe_rechazadas'), stats?.queue?.rejected],
              ] as [Filter, string, number | undefined][]).map(([id, label, count]) => (
                <button key={id} type="button" role="tab" aria-selected={filter === id} onClick={() => setFilter(id)}
                  className={`rounded-xl px-3 py-1.5 text-xs font-bold ${filter === id ? 'bg-fg text-surface' : 'bg-surface-sunken text-fg-secondary hover:bg-surface-muted'}`}>
                  {label} <span className="tabular-nums opacity-70">{count ?? 0}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-line text-[0.7857rem] font-bold uppercase tracking-wide text-fg-muted">
                  <th className="py-2.5 px-2">{t('dian:factura')}</th>
                  <th className="py-2.5 px-2">{t('dian:fecha')}</th>
                  <th className="py-2.5 px-2">{t('dian:fe_cliente')}</th>
                  <th className="py-2.5 px-2 text-right">{t('dian:total')}</th>
                  <th className="py-2.5 px-2">{t('dian:estado_dian')}</th>
                  <th className="py-2.5 px-2 text-right"><span className="sr-only">{t('dian:acciones')}</span></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {shown.length === 0 ? (
                  <tr><td colSpan={6} className="py-8 text-center text-fg-muted">{t('dian:fe_sin_facturas')}</td></tr>
                ) : shown.map((inv) => (
                  <tr key={inv.id} className="align-top">
                    <td className="py-3 px-2 font-mono font-bold text-fg whitespace-nowrap">
                      {isProvisional(inv.invoiceNumber) ? <span className="font-sans font-semibold text-fg-muted">{t('dian:fe_numero_pendiente')}</span> : inv.invoiceNumber}
                      {inv.sale?.saleNumber && <div className="font-sans font-normal text-[0.7857rem] text-fg-muted">{t('dian:fe_venta', { number: inv.sale.saleNumber })}</div>}
                    </td>
                    <td className="py-3 px-2 text-fg-secondary whitespace-nowrap">{fmtDate(inv.issueDate || inv.createdAt, true)}</td>
                    <td className="py-3 px-2">
                      <div className="font-semibold text-fg">{inv.customerName}</div>
                      <div className="font-mono text-[0.7857rem] text-fg-muted">{inv.customerNit}</div>
                    </td>
                    <td className="py-3 px-2 text-right font-bold text-fg tabular-nums">{formatCurrency(inv.total)}</td>
                    <td className="py-3 px-2 max-w-[260px]">
                      <StatusPill status={inv.status} />
                      {inv.status !== 'ACCEPTED' && inv.dianResponseDesc && <p className="mt-1 text-[0.7857rem] leading-snug text-fg-muted">{inv.dianResponseDesc}</p>}
                    </td>
                    <td className="py-3 px-2">
                      <div className="flex items-center justify-end gap-1">
                        {inv.cufe && (
                          <button type="button" onClick={() => setCufe(inv.cufe)} title={t('dian:fe_ver_cufe')} aria-label={t('dian:fe_ver_cufe')}
                            className="rounded-lg p-1.5 text-fg-muted hover:bg-surface-muted hover:text-fg">
                            <Copy className="h-4 w-4" aria-hidden />
                          </button>
                        )}
                        {inv.publicUrl && (
                          <a href={inv.publicUrl} target="_blank" rel="noreferrer" title={t('dian:fe_ver_pdf')} aria-label={t('dian:fe_ver_pdf')}
                            className="rounded-lg p-1.5 text-fg-muted hover:bg-surface-muted hover:text-fg">
                            <FileText className="h-4 w-4" aria-hidden />
                          </a>
                        )}
                        {inv.qrCode?.startsWith('https://') && (
                          <a href={inv.qrCode} target="_blank" rel="noreferrer" title={t('dian:fe_ver_en_dian')} aria-label={t('dian:fe_ver_en_dian')}
                            className="rounded-lg p-1.5 text-fg-muted hover:bg-surface-muted hover:text-fg">
                            <ExternalLink className="h-4 w-4" aria-hidden />
                          </a>
                        )}
                        {inv.status !== 'ACCEPTED' && active && (
                          <button type="button" onClick={() => retry(inv.id)} disabled={retrying === inv.id}
                            className="inline-flex items-center gap-1 rounded-lg px-2 py-1.5 font-bold text-primary-text hover:bg-surface-muted disabled:opacity-50">
                            <Send className="h-3.5 w-3.5" aria-hidden /> {t('dian:fe_reintentar')}
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {cufe && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" role="dialog" aria-modal="true" aria-labelledby="fe-cufe" onClick={() => setCufe(null)}>
          <div className="w-full max-w-lg space-y-4 rounded-2xl border border-line bg-surface p-6 shadow-xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <h4 id="fe-cufe" className="text-sm font-bold text-fg">CUFE</h4>
              <button type="button" onClick={() => setCufe(null)} className="rounded-lg px-2 text-sm font-bold text-fg-muted hover:text-fg" aria-label={t('dian:cerrar')}>✕</button>
            </div>
            <p className="select-all break-all rounded-xl bg-surface-sunken p-3 font-mono text-xs text-fg">{cufe}</p>
            <div className="flex justify-end">
              <button type="button"
                onClick={() => { copyText(cufe).catch(() => undefined); setCopied(true); setTimeout(() => setCopied(false), 2000); }}
                className="inline-flex items-center gap-2 rounded-xl bg-fg px-4 py-2 text-xs font-bold text-surface">
                {copied ? <Check className="h-4 w-4" aria-hidden /> : <Copy className="h-4 w-4" aria-hidden />}
                {copied ? t('dian:copiado_2') : t('dian:copiar_cufe')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
