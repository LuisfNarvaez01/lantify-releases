// ============================================
// ADMIN - Varias sedes: copiar la carta (Fase 4)
// ============================================
// Exporta la carta de esta sede (JSON) e importa la de otra: primero muestra qué
// se crea y qué cambia, y solo aplica al confirmar. Por nombre: importar dos veces
// el mismo archivo no cambia nada. Nunca toca existencias, costos, ventas ni fotos.

import { useRef, useState } from 'react';
import { Download, Upload } from 'lucide-react';
import { t } from '../../i18n';
import { toast } from '../../shared/toast';
import { Button } from '../common/Button';
import { gestionAPI } from '../../services/v3Api';
import type { MenuPlan } from '../../../../src/domain/menuTransfer';

export function MenuTransferPanel() {
  const input = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<{ name: string; data: unknown } | null>(null);
  const [plan, setPlan] = useState<MenuPlan | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  const exportMenu = async () => {
    setBusy('export');
    try {
      const menu = await gestionAPI.exportMenu();
      const url = URL.createObjectURL(new Blob([JSON.stringify(menu, null, 2)], { type: 'application/json' }));
      const a = document.createElement('a');
      a.href = url;
      a.download = `lantify-carta-${(menu.business || 'sede').normalize('NFD').replace(/[^\w]+/g, '-').toLowerCase()}-${menu.exportedAt.slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 2000);
      toast.success(t('v3:carta_exportada', { n: menu.products.length }));
    } catch (e: any) {
      toast.error(e?.message || t('v3:no_se_guardo'));
    } finally {
      setBusy(null);
    }
  };

  const pick = async (f: File | undefined) => {
    if (!f) return;
    setPlan(null);
    setBusy('preview');
    try {
      const data = JSON.parse(await f.text());
      setFile({ name: f.name, data });
      setPlan(await gestionAPI.previewMenu(data));
    } catch (e: any) {
      setFile(null);
      toast.error(e instanceof SyntaxError ? t('v3:carta_no_valida') : e?.message || t('v3:carta_no_valida'));
    } finally {
      setBusy(null);
      if (input.current) input.current.value = '';
    }
  };

  const apply = async () => {
    if (!file) return;
    setBusy('import');
    try {
      const done = await gestionAPI.importMenu(file.data);
      toast.success(t('v3:carta_importada', { nuevos: done.summary.newProducts, cambiados: done.summary.updatedProducts }));
      setPlan(null);
      setFile(null);
    } catch (e: any) {
      toast.error(e?.message || t('v3:no_se_guardo'));
    } finally {
      setBusy(null);
    }
  };

  const s = plan?.summary;
  const nothing = !!plan && !s!.categories && !s!.ingredients && !s!.newProducts && !s!.updatedProducts;

  return (
    <div className="rounded-2xl bg-slate-50 border border-slate-200 p-4 space-y-3">
      <p className="text-sm font-semibold text-slate-800">{t('v3:carta_titulo')}</p>
      <p className="text-xs text-slate-500">{t('v3:carta_desc')}</p>
      <div className="flex flex-wrap gap-2">
        <Button size="sm" variant="secondary" isLoading={busy === 'export'} onClick={exportMenu}><Download className="w-4 h-4" aria-hidden /> {t('v3:carta_exportar')}</Button>
        <Button size="sm" variant="secondary" isLoading={busy === 'preview'} onClick={() => input.current?.click()}><Upload className="w-4 h-4" aria-hidden /> {t('v3:carta_importar')}</Button>
        <input ref={input} type="file" accept="application/json,.json" className="sr-only" aria-label={t('v3:carta_importar')} onChange={(e) => pick(e.target.files?.[0])} />
      </div>
      {plan && s && (
        <div className="rounded-xl bg-white border border-slate-200 p-4 space-y-2" role="status">
          <p className="text-sm font-semibold text-slate-900">{t('v3:carta_previa', { archivo: file?.name || '' })}</p>
          {nothing ? <p className="text-sm text-emerald-700">{t('v3:carta_igual')}</p> : (
            <ul className="text-sm text-slate-700 list-disc pl-5 space-y-0.5">
              {s.newProducts > 0 && <li>{t('v3:carta_p_nuevos', { n: s.newProducts })}</li>}
              {s.updatedProducts > 0 && <li>{t('v3:carta_p_cambian', { n: s.updatedProducts, precios: s.priceChanges })}</li>}
              {s.categories > 0 && <li>{t('v3:carta_p_categorias', { n: s.categories })}</li>}
              {s.newVariants > 0 && <li>{t('v3:carta_p_presentaciones', { n: s.newVariants })}</li>}
              {s.recipeLines > 0 && <li>{t('v3:carta_p_receta', { n: s.recipeLines })}</li>}
              {s.ingredients > 0 && <li>{t('v3:carta_p_insumos', { n: s.ingredients })}</li>}
              {s.unchanged > 0 && <li>{t('v3:carta_p_iguales', { n: s.unchanged })}</li>}
            </ul>
          )}
          {plan.updateProducts.some((u) => u.prices.length) && (
            <details className="text-xs text-slate-600">
              <summary className="cursor-pointer font-semibold">{t('v3:carta_ver_precios')}</summary>
              <ul className="mt-1 space-y-0.5">
                {plan.updateProducts.flatMap((u) => u.prices.map((p) => <li key={p.variantId}>{u.name} · {p.name}: {p.from.toLocaleString()} → {p.to.toLocaleString()}</li>))}
              </ul>
            </details>
          )}
          <p className="text-xs text-slate-500">{t('v3:carta_no_toca')}</p>
          <div className="flex gap-2">
            {!nothing && <Button size="sm" isLoading={busy === 'import'} onClick={apply}>{t('v3:carta_aplicar')}</Button>}
            <Button size="sm" variant="ghost" onClick={() => { setPlan(null); setFile(null); }}>{t('v3:carta_cancelar')}</Button>
          </div>
        </div>
      )}
    </div>
  );
}
