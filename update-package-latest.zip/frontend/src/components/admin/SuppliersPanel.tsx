// ============================================
// ADMIN - Proveedores y sus precios (pestaña de Gastos)
// ============================================
// A quién le compras cada cosa y a qué precio. Los precios se escriben aquí o se
// llenan solos con las facturas leídas con IA. Es la base del agente de compras.

import { FormEvent, useEffect, useMemo, useState } from 'react';
import { MessageCircle, Plus, Sparkles, Trash2, Truck } from 'lucide-react';
import { suppliersAPI, Supplier } from '../../services/api';
import { errorMessage } from '../../services/apiErrors';
import { formatCurrency } from '../../shared/formatUtils';
import { toast } from '../../shared/toast';
import { useFeature } from '../../shared/plan';
import { PlanLocked } from '../common/PlanLocked';
import { t, getLocale } from '../../i18n';

const inputCls = 'w-full min-h-[42px] px-3 rounded-xl border border-slate-200 bg-white text-sm focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20';

/** Número de WhatsApp: si es un celular colombiano sin indicativo, se agrega el 57 */
export const whatsappNumber = (phone: string | null) => {
  if (!phone) return null;
  const digits = phone.replace(/\D/g, '');
  if (digits.length === 10 && digits.startsWith('3')) return `57${digits}`;
  return digits.length >= 10 ? digits : null;
};

export function SuppliersPanel() {
  const allowed = useFeature('suppliers');
  const [list, setList] = useState<Supplier[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [form, setForm] = useState({ name: '', phone: '', nit: '', contactName: '' });
  const [price, setPrice] = useState({ itemName: '', unit: '', price: '' });
  const [creating, setCreating] = useState(false);

  const load = async () => {
    try {
      const data = await suppliersAPI.list();
      setList(data);
      setSelectedId((id) => id ?? data[0]?.id ?? null);
    } catch (e) {
      toast.error(errorMessage(e));
    }
  };
  useEffect(() => {
    if (allowed) load();
  }, [allowed]);

  const selected = list.find((s) => s.id === selectedId) || null;

  // Para cada producto, el precio más bajo entre proveedores (para marcar al mejor)
  const cheapest = useMemo(() => {
    const map = new Map<string, number>();
    for (const s of list) for (const p of s.prices) {
      const k = p.itemName.toLowerCase().trim();
      map.set(k, Math.min(map.get(k) ?? Infinity, p.price));
    }
    return map;
  }, [list]);

  if (!allowed) return <PlanLocked feature="suppliers" />;

  const create = async (e: FormEvent) => {
    e.preventDefault();
    try {
      const s = await suppliersAPI.create(form);
      setForm({ name: '', phone: '', nit: '', contactName: '' });
      setCreating(false);
      await load();
      setSelectedId(s.id);
    } catch (err) {
      toast.error(errorMessage(err));
    }
  };

  const addPrice = async (e: FormEvent) => {
    e.preventDefault();
    if (!selected) return;
    try {
      await suppliersAPI.savePrices(selected.id, [{ itemName: price.itemName, unit: price.unit || null, price: Number(price.price) }]);
      setPrice({ itemName: '', unit: '', price: '' });
      await load();
    } catch (err) {
      toast.error(errorMessage(err));
    }
  };

  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,0.8fr)_minmax(0,1.2fr)]">
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <p className="text-sm font-bold text-slate-700">{t('suppliers:n_proveedores', { count: list.length })}</p>
          <button type="button" onClick={() => setCreating((v) => !v)} className="inline-flex items-center gap-1.5 min-h-[40px] px-3 rounded-xl bg-blue-600 text-white text-sm font-bold hover:bg-blue-700">
            <Plus className="w-4 h-4" aria-hidden /> {t('suppliers:nuevo')}
          </button>
        </div>
        {creating && (
          <form onSubmit={create} className="space-y-2 rounded-2xl border border-slate-200 bg-white p-4">
            <input className={inputCls} placeholder={t('suppliers:nombre')} aria-label={t('suppliers:nombre')} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required maxLength={120} />
            <div className="grid grid-cols-2 gap-2">
              <input className={inputCls} placeholder={t('suppliers:whatsapp')} aria-label={t('suppliers:whatsapp')} value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} inputMode="tel" />
              <input className={inputCls} placeholder="NIT" aria-label="NIT" value={form.nit} onChange={(e) => setForm({ ...form, nit: e.target.value })} />
            </div>
            <input className={inputCls} placeholder={t('suppliers:contacto')} aria-label={t('suppliers:contacto')} value={form.contactName} onChange={(e) => setForm({ ...form, contactName: e.target.value })} />
            <button type="submit" className="w-full min-h-[42px] rounded-xl bg-slate-900 text-white text-sm font-bold">{t('suppliers:guardar')}</button>
          </form>
        )}
        {list.length === 0 && !creating ? (
          <div className="rounded-2xl border border-dashed border-slate-300 bg-white px-5 py-10 text-center">
            <Truck className="mx-auto w-8 h-8 text-slate-300" aria-hidden />
            <p className="mt-2 text-sm font-bold text-slate-700">{t('suppliers:vacio')}</p>
            <p className="mt-1 text-xs text-slate-500">{t('suppliers:vacio_desc')}</p>
          </div>
        ) : (
          <ul className="space-y-1.5">
            {list.map((s) => (
              <li key={s.id}>
                <button
                  type="button"
                  onClick={() => setSelectedId(s.id)}
                  aria-pressed={s.id === selectedId}
                  className={`w-full rounded-xl border px-4 py-3 text-left ${s.id === selectedId ? 'border-blue-500 bg-blue-50' : 'border-slate-200 bg-white hover:bg-slate-50'}`}
                >
                  <span className="block font-bold text-slate-800">{s.name}</span>
                  <span className="text-xs text-slate-500">{t('suppliers:n_precios', { count: s.prices.length })}{s.phone ? ` · ${s.phone}` : ''}</span>
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      {selected && (
        <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <h3 className="text-lg font-black text-slate-900">{selected.name}</h3>
              <p className="text-xs text-slate-500">{[selected.nit && `NIT ${selected.nit}`, selected.contactName].filter(Boolean).join(' · ')}</p>
            </div>
            {whatsappNumber(selected.phone) && (
              <a href={`https://wa.me/${whatsappNumber(selected.phone)}`} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 min-h-[40px] px-3 rounded-xl bg-emerald-600 text-white text-sm font-bold hover:bg-emerald-700">
                <MessageCircle className="w-4 h-4" aria-hidden /> WhatsApp
              </a>
            )}
          </div>

          <form onSubmit={addPrice} className="grid grid-cols-[minmax(0,1fr)_5rem_7rem_auto] gap-2">
            <input className={inputCls} placeholder={t('suppliers:producto')} aria-label={t('suppliers:producto')} value={price.itemName} onChange={(e) => setPrice({ ...price, itemName: e.target.value })} required />
            <input className={inputCls} placeholder={t('suppliers:unidad')} aria-label={t('suppliers:unidad')} value={price.unit} onChange={(e) => setPrice({ ...price, unit: e.target.value })} />
            <input className={inputCls} placeholder={t('suppliers:precio')} aria-label={t('suppliers:precio')} value={price.price} onChange={(e) => setPrice({ ...price, price: e.target.value })} inputMode="numeric" type="number" min={1} required />
            <button type="submit" className="min-h-[42px] px-3 rounded-xl bg-slate-900 text-white" aria-label={t('suppliers:agregar_precio')}><Plus className="w-4 h-4" /></button>
          </form>

          {selected.prices.length === 0 ? (
            <p className="text-sm text-slate-500">{t('suppliers:sin_precios')}</p>
          ) : (
            <ul className="divide-y divide-slate-100">
              {selected.prices.map((p) => {
                const best = cheapest.get(p.itemName.toLowerCase().trim()) === p.price;
                return (
                  <li key={p.id} className="flex items-center gap-3 py-2.5 text-sm">
                    <span className="flex-1 min-w-0">
                      <span className="font-semibold text-slate-800">{p.itemName}</span>
                      {p.source === 'INVOICE' && (
                        <span className="ml-2 inline-flex items-center gap-1 text-xs text-violet-700"><Sparkles className="w-3 h-3" aria-hidden />{t('suppliers:de_factura')}</span>
                      )}
                      <span className="block text-xs text-slate-400">{new Date(p.updatedAt).toLocaleDateString(getLocale(), { day: '2-digit', month: 'short' })}</span>
                    </span>
                    {best && list.length > 1 && <span className="rounded-full bg-emerald-50 px-2 py-0.5 text-xs font-bold text-emerald-700">{t('suppliers:mas_barato')}</span>}
                    <span className="tabular-nums font-bold text-slate-900">{formatCurrency(p.price)}{p.unit ? <span className="font-normal text-slate-500"> / {p.unit}</span> : ''}</span>
                    <button type="button" onClick={async () => { await suppliersAPI.deletePrice(selected.id, p.id); load(); }} className="p-1.5 rounded-lg text-slate-400 hover:bg-rose-50 hover:text-rose-700" aria-label={t('suppliers:quitar_precio')}>
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
