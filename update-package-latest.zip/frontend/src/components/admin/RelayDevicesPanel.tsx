// ============================================
// COMPONENTS - Celulares por internet (vincular y quitar)
// ============================================
// Cada mesero vincula su celular una vez escaneando un QR propio. Después el celular
// usa la red local cuando está cerca y el relevo de Lantify Cloud cuando se aleja.

import React, { useCallback, useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { Globe, Plus, Trash2, X } from 'lucide-react';
import { API_URL } from '../../config';
import { t, getLocale } from '../../i18n';
import { toast } from '../../shared/toast';
import { confirmDialog } from '../../shared/dialog';

interface RelayDevice { id: string; name: string; createdAt: string; lastSeenAt: string | null }
interface RelayInfo { status: { enabled: boolean; connected: boolean; devices: number; lastError: string | null }; devices: RelayDevice[] }

const call = async (method: string, path: string, body?: unknown) => {
  const res = await fetch(`${API_URL}${path}`, { method, headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
  const data = await res.json().catch(() => null);
  if (!res.ok) throw Object.assign(new Error(data?.error || data?.code || 'Error'), { code: data?.code });
  return data;
};

export const RelayDevicesPanel: React.FC = () => {
  const [info, setInfo] = useState<RelayInfo | null>(null);
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);
  const [qr, setQr] = useState<{ name: string; image: string } | null>(null);
  const [notLinked, setNotLinked] = useState(false);

  const load = useCallback(() => { call('GET', '/relay/devices').then(setInfo).catch(() => setInfo(null)); }, []);
  useEffect(() => { load(); const id = setInterval(load, 20_000); return () => clearInterval(id); }, [load]);

  const create = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      const out = await call('POST', '/relay/devices', { name });
      const image = await QRCode.toDataURL(out.link, { margin: 1, width: 360, errorCorrectionLevel: 'M' });
      setQr({ name: out.device.name, image });
      setName('');
      load();
    } catch (err: any) {
      if (err?.code === 'RELAY_NOT_LINKED') setNotLinked(true);
      else toast.error(err.message);
    }
    setBusy(false);
  };

  const revoke = async (d: RelayDevice) => {
    if (!(await confirmDialog({ title: t('layout:relay_revocar'), message: t('layout:relay_revocar_confirmar', { name: d.name }) }))) return;
    try { await call('DELETE', `/relay/devices/${d.id}`); load(); } catch (err: any) { toast.error(err.message); }
  };

  const when = (d: string) => new Date(d).toLocaleString(getLocale(), { dateStyle: 'short', timeStyle: 'short' });

  return (
    <section className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4">
      <div className="flex items-start gap-3">
        <span className="w-9 h-9 rounded-xl bg-slate-100 text-slate-700 inline-flex items-center justify-center"><Globe className="w-4.5 h-4.5" /></span>
        <div className="flex-1">
          <h3 className="font-semibold text-slate-900">{t('layout:relay_titulo')}</h3>
          <p className="text-sm text-slate-500 mt-0.5">{t('layout:relay_desc')}</p>
          <p className="text-sm text-slate-500 mt-1">
            {t('layout:relay_sin_app')}{' '}
            <a href="https://lantifypos.com/descargar#celular" target="_blank" rel="noreferrer" className="font-semibold text-blue-700 underline underline-offset-2">lantifypos.com/descargar</a>
          </p>
          {info?.status.enabled && (
            <p className="mt-2 inline-flex items-center gap-1.5 text-xs text-slate-600">
              <span className={`w-1.5 h-1.5 rounded-full ${info.status.connected ? 'bg-emerald-500' : 'bg-amber-500'}`} />
              {info.status.connected ? t('layout:relay_conectado') : t('layout:relay_desconectado')}
            </p>
          )}
        </div>
      </div>

      {notLinked && <p className="text-sm rounded-xl bg-amber-50 text-amber-900 px-3 py-2">{t('layout:relay_no_vinculado')}</p>}

      <form onSubmit={create} className="flex gap-2">
        <input value={name} onChange={(e) => setName(e.target.value)} maxLength={60} placeholder={t('layout:relay_nombre')}
          className="flex-1 h-10 px-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-blue-500" />
        <button type="submit" disabled={busy} className="h-10 px-4 rounded-xl bg-blue-600 text-white text-sm font-semibold inline-flex items-center gap-1.5 hover:bg-blue-700 disabled:opacity-60">
          <Plus className="w-4 h-4" />{t('layout:relay_vincular')}
        </button>
      </form>

      {qr && (
        <div className="relative rounded-2xl border border-slate-200 p-4 flex flex-col items-center text-center">
          <button type="button" aria-label="Cerrar" onClick={() => setQr(null)} className="absolute right-2 top-2 p-1.5 rounded-lg hover:bg-slate-100"><X className="w-4 h-4" /></button>
          <p className="font-semibold text-slate-900">{t('layout:relay_qr_titulo')} · {qr.name}</p>
          <img src={qr.image} alt="QR" className="w-56 h-56 mt-3" />
          <p className="text-xs text-slate-500 mt-2 max-w-xs">{t('layout:relay_qr_desc')}</p>
        </div>
      )}

      <ul className="divide-y divide-slate-100">
        {(info?.devices || []).map((d) => (
          <li key={d.id} className="py-2.5 flex items-center gap-3">
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-slate-800 truncate">{d.name}</p>
              <p className="text-xs text-slate-500">{d.lastSeenAt ? t('layout:relay_visto', { when: when(d.lastSeenAt) }) : t('layout:relay_nunca')}</p>
            </div>
            <button type="button" onClick={() => void revoke(d)} className="h-8 px-2.5 rounded-lg text-xs text-slate-600 hover:bg-red-50 hover:text-red-700 inline-flex items-center gap-1">
              <Trash2 className="w-3.5 h-3.5" />{t('layout:relay_revocar')}
            </button>
          </li>
        ))}
        {info && !info.devices.length && <li className="py-3 text-sm text-slate-500">{t('layout:relay_ninguno')}</li>}
      </ul>
    </section>
  );
};
