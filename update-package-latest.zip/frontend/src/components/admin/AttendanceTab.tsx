// ============================================
// ADMIN - Personal → Asistencia (Fase 4 · 13)
// ============================================
// PIN de cada empleado (para marcar en la caja o en la pantalla de asistencia),
// horario de la semana y el informe de llegadas tarde y horas contra lo programado.

import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Copy, KeyRound, MonitorSmartphone, Trash2 } from 'lucide-react';
import { t, getLocale } from '../../i18n';
import { toast } from '../../shared/toast';
import { promptDialog, confirmDialog } from '../../shared/dialog';
import { Button } from '../common/Button';
import { attendanceAPI, displaysAPI, type AttendanceReport, type DisplayInfo, type Employee } from '../../services/v3Api';
import { permissionsAPI } from '../../services/api';
import { copyText } from '../../shared/browser';
import { errorMessage } from '../../services/apiErrors';

const field = 'rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 min-h-[44px] focus:outline-none focus:ring-2 focus:ring-blue-500/40';
const card = 'bg-white rounded-3xl shadow-sm border border-slate-200/80';
const th = 'text-left text-xs font-bold uppercase tracking-wider text-slate-500 px-4 py-3';
const td = 'px-4 py-3 text-sm text-slate-800 align-middle';
const hm = (min: number) => `${Math.floor(min / 60)} h ${String(min % 60).padStart(2, '0')}`;
const toIso = (d: string, end = false) => new Date(`${d}T${end ? '23:59:59.999' : '00:00:00'}`).toISOString();
const dayStr = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

function PinSection({ team, reload }: { team: Employee[]; reload: () => Promise<void> }) {
  const setPin = async (e: Employee) => {
    const pin = await promptDialog({ title: t('v3:asis_pin_de', { name: e.name }), label: t('v3:asis_pin_label'), placeholder: '4–6', confirmLabel: t('v3:guardar'), required: true, inputMode: 'numeric', inputType: 'password' });
    if (!pin) return;
    try {
      await attendanceAPI.setPin(e.id, pin.trim());
      toast.success(t('v3:asis_pin_ok'));
      await reload();
    } catch (err) { toast.error(errorMessage(err)); }
  };
  const removePin = async (e: Employee) => {
    if (!(await confirmDialog({ title: t('v3:asis_quitar_pin'), message: t('v3:asis_quitar_pin_desc', { name: e.name }), tone: 'danger', confirmLabel: t('v3:quitar') }))) return;
    try { await attendanceAPI.setPin(e.id, null); await reload(); } catch (err) { toast.error(errorMessage(err)); }
  };
  return (
    <section className={`${card} overflow-x-auto`} aria-labelledby="asis-pins">
      <div className="p-5 pb-3">
        <h3 id="asis-pins" className="text-base font-bold text-slate-900">{t('v3:asis_pins_titulo')}</h3>
        <p className="text-sm text-slate-500">{t('v3:asis_pins_desc')}</p>
      </div>
      <table className="w-full min-w-[520px]">
        <tbody className="divide-y divide-slate-100 border-t border-slate-100">
          {team.filter((e) => e.isActive).map((e) => (
            <tr key={e.id}>
              <td className={`${td} font-bold text-slate-900`}>{e.name}</td>
              <td className={td}>{e.hasPin ? <span className="rounded-full bg-emerald-100 px-2.5 py-1 text-xs font-bold text-emerald-800">{t('v3:asis_con_pin')}</span> : <span className="text-slate-500">{t('v3:asis_sin_pin_corto')}</span>}</td>
              <td className={`${td} text-right whitespace-nowrap`}>
                <Button size="sm" variant="outline" leftIcon={<KeyRound className="h-4 w-4" />} onClick={() => setPin(e)}>{e.hasPin ? t('v3:asis_cambiar_pin') : t('v3:asis_poner_pin')}</Button>
                {e.hasPin && <button type="button" onClick={() => removePin(e)} className="ml-2 rounded-xl p-2 text-slate-400 hover:bg-rose-50 hover:text-rose-700" aria-label={t('v3:asis_quitar_pin')}><Trash2 className="h-4 w-4" /></button>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </section>
  );
}

/**
 * Pantalla de asistencia: una tablet o TV en la entrada del personal donde cada
 * uno toca su nombre y marca con su PIN. Se crea aquí mismo y se conecta con el
 * código, sin ir a Salón y mesas.
 */
function ScreenSection() {
  const [list, setList] = useState<DisplayInfo[] | null>(null);
  const [pairing, setPairing] = useState<{ code: string; expiresAt: string } | null>(null);
  const [lan, setLan] = useState<string | null>(null);
  const load = useCallback(() => displaysAPI.list().then((l) => setList(l.filter((d) => d.type === 'ATTENDANCE'))).catch(() => setList([])), []);
  useEffect(() => { load(); permissionsAPI.devices().then((d) => setLan(d.urls?.[0] || null)).catch(() => undefined); }, [load]);
  useEffect(() => {
    if (!pairing) return;
    const id = setInterval(() => { displaysAPI.list().then((l) => { const a = l.filter((d) => d.type === 'ATTENDANCE'); setList(a); if (a.some((d) => d.connected)) { setPairing(null); toast.success(t('v3:pantalla_conectada')); } }).catch(() => undefined); }, 3000);
    return () => clearInterval(id);
  }, [pairing]);
  const local = ['localhost', '127.0.0.1'].includes(window.location.hostname);
  const url = `${local && lan ? lan : window.location.origin}/pantalla`;
  const create = async () => {
    try {
      const existing = list?.[0];
      const r = existing ? await displaysAPI.code(existing.id) : await displaysAPI.create({ name: t('v3:asis_pantalla_nombre'), type: 'ATTENDANCE', station: null });
      setPairing({ code: r.code, expiresAt: r.expiresAt });
      load();
    } catch (err) { toast.error(errorMessage(err)); }
  };
  const connected = list?.some((d) => d.connected);
  return (
    <section className={`${card} p-5 space-y-3`} aria-labelledby="asis-pantalla">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-blue-50 text-blue-700"><MonitorSmartphone className="h-5 w-5" aria-hidden /></span>
          <div>
            <h3 id="asis-pantalla" className="text-base font-bold text-slate-900">{t('v3:asis_pantalla_titulo')}</h3>
            <p className="text-sm text-slate-500 max-w-xl">{t('v3:asis_pantalla_desc')}</p>
          </div>
        </div>
        {connected
          ? <span className="rounded-full bg-emerald-100 px-3 py-1 text-xs font-bold text-emerald-800">{t('v3:conectada')}</span>
          : <Button onClick={create}>{list?.length ? t('v3:nuevo_codigo') : t('v3:asis_pantalla_crear')}</Button>}
      </div>
      {pairing && (
        <div className="rounded-2xl border-2 border-blue-600 bg-blue-50 p-4" role="status">
          <p className="text-sm font-semibold text-blue-900">{t('v3:pantalla_paso1')}</p>
          <p className="mt-1 flex flex-wrap items-center gap-2 font-mono text-base font-bold text-slate-900 break-all">{url}
            <button type="button" onClick={() => copyText(url).then(() => toast.success(t('v3:copiado')))} className="rounded-lg p-1.5 text-blue-800 hover:bg-blue-100" aria-label={t('v3:copiar')}><Copy className="h-4 w-4" /></button>
          </p>
          <p className="mt-3 text-sm font-semibold text-blue-900">{t('v3:pantalla_paso2')}</p>
          <p className="mt-1 font-mono text-5xl font-black tracking-[0.3em] text-slate-900 tabular-nums">{pairing.code}</p>
        </div>
      )}
      {connected && <p className="text-xs text-slate-500">{t('v3:asis_pantalla_ok')}</p>}
    </section>
  );
}

function ReportSection({ team }: { team: Employee[] }) {
  const today = new Date();
  const monday = new Date(today); monday.setDate(today.getDate() - ((today.getDay() + 6) % 7));
  const [from, setFrom] = useState(dayStr(monday));
  const [to, setTo] = useState(dayStr(today));
  const [report, setReport] = useState<AttendanceReport | null>(null);
  const names = useMemo(() => new Map(team.map((e) => [e.id, e.name])), [team]);
  const load = useCallback(() => { attendanceAPI.report(toIso(from), toIso(to, true)).then(setReport).catch((err) => toast.error(errorMessage(err))); }, [from, to]);
  useEffect(() => { load(); }, [load]);
  const when = (iso: string) => new Date(iso).toLocaleString(getLocale(), { weekday: 'short', day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' });
  return (
    <section className={`${card} overflow-x-auto`} aria-labelledby="asis-informe">
      <div className="flex flex-wrap items-end justify-between gap-3 p-5 pb-3">
        <div>
          <h3 id="asis-informe" className="text-base font-bold text-slate-900">{t('v3:asis_informe_titulo')}</h3>
          <p className="text-sm text-slate-500">{t('v3:asis_informe_desc')}</p>
        </div>
        <div className="flex gap-2">
          <input type="date" aria-label={t('v3:asis_desde')} className={field} value={from} onChange={(e) => setFrom(e.target.value)} />
          <input type="date" aria-label={t('v3:asis_hasta')} className={field} value={to} onChange={(e) => setTo(e.target.value)} />
        </div>
      </div>
      <table className="w-full min-w-[640px]">
        <thead className="bg-slate-50 border-y border-slate-200"><tr>
          <th className={th}>{t('v3:empleado')}</th><th className={th}>{t('v3:asis_programado')}</th><th className={th}>{t('v3:asis_trabajado')}</th><th className={th}>{t('v3:asis_tardes')}</th><th className={th}>{t('v3:asis_ausencias')}</th>
        </tr></thead>
        <tbody className="divide-y divide-slate-100">
          {(report?.rows || []).map((r) => (
            <tr key={r.employeeId}>
              <td className={`${td} font-bold text-slate-900`}>{r.name}</td>
              <td className={`${td} tabular-nums`}>{hm(r.scheduledMin)}</td>
              <td className={`${td} tabular-nums ${r.scheduledMin && r.workedMin < r.scheduledMin ? 'text-amber-700 font-semibold' : ''}`}>{hm(r.workedMin)}</td>
              <td className={`${td} tabular-nums`}>{r.lateCount ? t('v3:asis_tardes_n', { count: r.lateCount, min: r.lateMin }) : '—'}</td>
              <td className={`${td} tabular-nums ${r.absences ? 'text-rose-700 font-semibold' : ''}`}>{r.absences || '—'}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {report && report.late.length > 0 && (
        <div className="border-t border-slate-200 p-5">
          <h4 className="text-sm font-bold text-slate-900">{t('v3:asis_llegadas_tarde')}</h4>
          <ul className="mt-2 space-y-1 text-sm text-slate-700">
            {report.late.slice(0, 30).map((l, i) => (
              <li key={i}>{t('v3:asis_tarde_linea', { name: names.get(l.employeeId) || '', programado: when(l.scheduledAt), llego: new Date(l.arrivedAt).toLocaleTimeString(getLocale(), { hour: 'numeric', minute: '2-digit' }), min: l.minutesLate })}</li>
            ))}
          </ul>
        </div>
      )}
    </section>
  );
}

export const AttendanceTab: React.FC<{ team: Employee[]; reload: () => Promise<void> }> = ({ team, reload }) => (
  <div className="space-y-6">
    <ScreenSection />
    <PinSection team={team} reload={reload} />
    <ReportSection team={team} />
  </div>
);
