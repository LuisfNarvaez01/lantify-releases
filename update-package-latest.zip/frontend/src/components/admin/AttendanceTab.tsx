// ============================================
// ADMIN - Personal → Asistencia (Fase 4 · 13)
// ============================================
// PIN de cada empleado (para marcar en la caja o en la pantalla de asistencia),
// horario de la semana y el informe de llegadas tarde y horas contra lo programado.

import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { KeyRound, Plus, Trash2 } from 'lucide-react';
import { t, getLocale } from '../../i18n';
import { toast } from '../../shared/toast';
import { promptDialog, confirmDialog } from '../../shared/dialog';
import { Button } from '../common/Button';
import { attendanceAPI, type AttendanceReport, type Employee, type ScheduleSlot } from '../../services/v3Api';
import { errorMessage } from '../../services/apiErrors';

const field = 'rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 min-h-[44px] focus:outline-none focus:ring-2 focus:ring-blue-500/40';
const card = 'bg-white rounded-3xl shadow-sm border border-slate-200/80';
const th = 'text-left text-xs font-bold uppercase tracking-wider text-slate-500 px-4 py-3';
const td = 'px-4 py-3 text-sm text-slate-800 align-middle';
// Lunes primero, como se piensa la semana en el local
const WEEK = [1, 2, 3, 4, 5, 6, 0];
const dayName = (d: number) => new Date(2026, 10, 22 + d).toLocaleDateString(getLocale(), { weekday: 'long' });
const hm = (min: number) => `${Math.floor(min / 60)} h ${String(min % 60).padStart(2, '0')}`;
const toIso = (d: string, end = false) => new Date(`${d}T${end ? '23:59:59.999' : '00:00:00'}`).toISOString();
const dayStr = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

function PinSection({ team, reload }: { team: Employee[]; reload: () => Promise<void> }) {
  const setPin = async (e: Employee) => {
    const pin = await promptDialog({ title: t('v3:asis_pin_de', { name: e.name }), label: t('v3:asis_pin_label'), placeholder: '4–6', confirmLabel: t('v3:guardar'), required: true, inputMode: 'numeric', inputType: 'password' });
    if (!pin) return;
    try {
      await attendanceAPI.setPin(e.id, pin.trim());
      toast.success(t('v3:asis_pin_ok'));
      await reload();
    } catch (err) { toast.error(errorMessage(err)); }
  };
  const removePin = async (e: Employee) => {
    if (!(await confirmDialog({ title: t('v3:asis_quitar_pin'), message: t('v3:asis_quitar_pin_desc', { name: e.name }), tone: 'danger', confirmLabel: t('v3:quitar') }))) return;
    try { await attendanceAPI.setPin(e.id, null); await reload(); } catch (err) { toast.error(errorMessage(err)); }
  };
  return (
    <section className={`${card} overflow-x-auto`} aria-labelledby="asis-pins">
      <div className="p-5 pb-3">
        <h3 id="asis-pins" className="text-base font-bold text-slate-900">{t('v3:asis_pins_titulo')}</h3>
        <p className="text-sm text-slate-500">{t('v3:asis_pins_desc')}</p>
      </div>
      <table className="w-full min-w-[520px]">
        <tbody className="divide-y divide-slate-100 border-t border-slate-100">
          {team.filter((e) => e.isActive).map((e) => (
            <tr key={e.id}>
              <td className={`${td} font-bold text-slate-900`}>{e.name}</td>
              <td className={td}>{e.hasPin ? <span className="rounded-full bg-emerald-100 px-2.5 py-1 text-xs font-bold text-emerald-800">{t('v3:asis_con_pin')}</span> : <span className="text-slate-500">{t('v3:asis_sin_pin_corto')}</span>}</td>
              <td className={`${td} text-right whitespace-nowrap`}>
                <Button size="sm" variant="outline" leftIcon={<KeyRound className="h-4 w-4" />} onClick={() => setPin(e)}>{e.hasPin ? t('v3:asis_cambiar_pin') : t('v3:asis_poner_pin')}</Button>
                {e.hasPin && <button type="button" onClick={() => removePin(e)} className="ml-2 rounded-xl p-2 text-slate-400 hover:bg-rose-50 hover:text-rose-700" aria-label={t('v3:asis_quitar_pin')}><Trash2 className="h-4 w-4" /></button>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </section>
  );
}

function ScheduleSection({ team }: { team: Employee[] }) {
  const active = team.filter((e) => e.isActive);
  const [employeeId, setEmployeeId] = useState('');
  const [all, setAll] = useState<ScheduleSlot[]>([]);
  const [slots, setSlots] = useState<ScheduleSlot[]>([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => { attendanceAPI.schedule().then(setAll).catch(() => setAll([])); }, []);
  useEffect(() => { if (!employeeId && active[0]) setEmployeeId(active[0].id); }, [active, employeeId]);
  useEffect(() => { setSlots(all.filter((s) => s.employeeId === employeeId).map(({ weekday, start, end }) => ({ weekday, start, end }))); }, [all, employeeId]);

  const save = async () => {
    setSaving(true);
    try {
      const saved = await attendanceAPI.setSchedule(employeeId, slots);
      setAll((a) => [...a.filter((s) => s.employeeId !== employeeId), ...saved]);
      toast.success(t('v3:guardado'));
    } catch (err) { toast.error(errorMessage(err)); } finally { setSaving(false); }
  };
  const patch = (i: number, p: Partial<ScheduleSlot>) => setSlots((s) => s.map((x, j) => (j === i ? { ...x, ...p } : x)));

  return (
    <section className={`${card} p-5 space-y-4`} aria-labelledby="asis-horario">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h3 id="asis-horario" className="text-base font-bold text-slate-900">{t('v3:asis_horario_titulo')}</h3>
          <p className="text-sm text-slate-500">{t('v3:asis_horario_desc')}</p>
        </div>
        <label className="text-xs font-bold text-slate-700 space-y-1 block">{t('v3:empleado')}
          <select className={`${field} block min-w-[14rem]`} value={employeeId} onChange={(e) => setEmployeeId(e.target.value)}>
            {active.map((e) => <option key={e.id} value={e.id}>{e.name}</option>)}
          </select>
        </label>
      </div>
      <ul className="divide-y divide-slate-100 rounded-2xl border border-slate-200">
        {WEEK.map((d) => {
          const mine = slots.map((s, i) => ({ s, i })).filter((x) => x.s.weekday === d);
          return (
            <li key={d} className="flex flex-wrap items-center gap-3 px-4 py-3">
              <span className="w-28 text-sm font-bold capitalize text-slate-900">{dayName(d)}</span>
              {mine.length === 0 && <span className="text-sm text-slate-400">{t('v3:asis_descanso')}</span>}
              {mine.map(({ s, i }) => (
                <span key={i} className="inline-flex items-center gap-1.5">
                  <input type="time" aria-label={t('v3:asis_entra')} className={field} value={s.start} onChange={(e) => patch(i, { start: e.target.value })} />
                  <span className="text-slate-400">–</span>
                  <input type="time" aria-label={t('v3:asis_sale')} className={field} value={s.end} onChange={(e) => patch(i, { end: e.target.value })} />
                  <button type="button" onClick={() => setSlots((x) => x.filter((_, j) => j !== i))} className="rounded-xl p-2 text-slate-400 hover:bg-rose-50 hover:text-rose-700" aria-label={t('v3:quitar')}><Trash2 className="h-4 w-4" /></button>
                </span>
              ))}
              <button type="button" onClick={() => setSlots((x) => [...x, { weekday: d, start: '08:00', end: '16:00' }])} className="ml-auto inline-flex min-h-[40px] items-center gap-1 rounded-xl px-3 text-xs font-bold text-blue-700 hover:bg-blue-50"><Plus className="h-4 w-4" aria-hidden />{t('v3:asis_agregar_turno')}</button>
            </li>
          );
        })}
      </ul>
      <div className="flex justify-end"><Button onClick={save} isLoading={saving} disabled={!employeeId}>{t('v3:guardar')}</Button></div>
    </section>
  );
}

function ReportSection({ team }: { team: Employee[] }) {
  const today = new Date();
  const monday = new Date(today); monday.setDate(today.getDate() - ((today.getDay() + 6) % 7));
  const [from, setFrom] = useState(dayStr(monday));
  const [to, setTo] = useState(dayStr(today));
  const [report, setReport] = useState<AttendanceReport | null>(null);
  const names = useMemo(() => new Map(team.map((e) => [e.id, e.name])), [team]);
  const load = useCallback(() => { attendanceAPI.report(toIso(from), toIso(to, true)).then(setReport).catch((err) => toast.error(errorMessage(err))); }, [from, to]);
  useEffect(() => { load(); }, [load]);
  const when = (iso: string) => new Date(iso).toLocaleString(getLocale(), { weekday: 'short', day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' });
  return (
    <section className={`${card} overflow-x-auto`} aria-labelledby="asis-informe">
      <div className="flex flex-wrap items-end justify-between gap-3 p-5 pb-3">
        <div>
          <h3 id="asis-informe" className="text-base font-bold text-slate-900">{t('v3:asis_informe_titulo')}</h3>
          <p className="text-sm text-slate-500">{t('v3:asis_informe_desc')}</p>
        </div>
        <div className="flex gap-2">
          <input type="date" aria-label={t('v3:asis_desde')} className={field} value={from} onChange={(e) => setFrom(e.target.value)} />
          <input type="date" aria-label={t('v3:asis_hasta')} className={field} value={to} onChange={(e) => setTo(e.target.value)} />
        </div>
      </div>
      <table className="w-full min-w-[640px]">
        <thead className="bg-slate-50 border-y border-slate-200"><tr>
          <th className={th}>{t('v3:empleado')}</th><th className={th}>{t('v3:asis_programado')}</th><th className={th}>{t('v3:asis_trabajado')}</th><th className={th}>{t('v3:asis_tardes')}</th><th className={th}>{t('v3:asis_ausencias')}</th>
        </tr></thead>
        <tbody className="divide-y divide-slate-100">
          {(report?.rows || []).map((r) => (
            <tr key={r.employeeId}>
              <td className={`${td} font-bold text-slate-900`}>{r.name}</td>
              <td className={`${td} tabular-nums`}>{hm(r.scheduledMin)}</td>
              <td className={`${td} tabular-nums ${r.scheduledMin && r.workedMin < r.scheduledMin ? 'text-amber-700 font-semibold' : ''}`}>{hm(r.workedMin)}</td>
              <td className={`${td} tabular-nums`}>{r.lateCount ? t('v3:asis_tardes_n', { count: r.lateCount, min: r.lateMin }) : '—'}</td>
              <td className={`${td} tabular-nums ${r.absences ? 'text-rose-700 font-semibold' : ''}`}>{r.absences || '—'}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {report && report.late.length > 0 && (
        <div className="border-t border-slate-200 p-5">
          <h4 className="text-sm font-bold text-slate-900">{t('v3:asis_llegadas_tarde')}</h4>
          <ul className="mt-2 space-y-1 text-sm text-slate-700">
            {report.late.slice(0, 30).map((l, i) => (
              <li key={i}>{t('v3:asis_tarde_linea', { name: names.get(l.employeeId) || '', programado: when(l.scheduledAt), llego: new Date(l.arrivedAt).toLocaleTimeString(getLocale(), { hour: 'numeric', minute: '2-digit' }), min: l.minutesLate })}</li>
            ))}
          </ul>
        </div>
      )}
    </section>
  );
}

export const AttendanceTab: React.FC<{ team: Employee[]; reload: () => Promise<void> }> = ({ team, reload }) => (
  <div className="space-y-6">
    <PinSection team={team} reload={reload} />
    <ScheduleSection team={team} />
    <ReportSection team={team} />
  </div>
);
