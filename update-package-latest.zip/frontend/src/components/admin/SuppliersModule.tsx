// ============================================
// ADMIN - Proveedores y categorías de gasto
// ============================================
// Los gastos se registran desde la caja, arqueo a arqueo (Caja → Gastos del
// turno). Aquí quedan los proveedores (con su lista de precios, base del agente
// de compras) y las categorías con que se clasifican los gastos.

import { useState } from 'react';
import { ExpenseCategoriesAdmin } from './ExpenseCategoriesAdmin';
import { SuppliersPanel } from './SuppliersPanel';
import { t } from '../../i18n';

export function SuppliersModule() {
  const [tab, setTab] = useState<'suppliers' | 'categories'>('suppliers');
  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 font-heading">{t('expenses:proveedores_titulo')}</h2>
          <p className="mt-1 text-sm text-slate-500">{t('expenses:proveedores_bajada')}</p>
        </div>
        <div className="flex gap-1 rounded-xl border border-slate-200 bg-white p-1" role="tablist">
          {(['suppliers', 'categories'] as const).map((k) => (
            <button
              key={k}
              type="button"
              role="tab"
              aria-selected={tab === k}
              onClick={() => setTab(k)}
              className={`px-4 py-2 rounded-lg text-sm font-bold ${tab === k ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'}`}
            >
              {t(`expenses:tab_${k}`)}
            </button>
          ))}
        </div>
      </div>
      {tab === 'categories' ? <ExpenseCategoriesAdmin /> : <SuppliersPanel />}
    </div>
  );
}
