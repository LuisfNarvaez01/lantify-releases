// ============================================
// ADMIN - Proyecta · cabina sin DJ
// ============================================
// Cuando el DJ marca en Proyecta que no está en cabina, los pedidos de canciones que esperan
// decisión llegan aquí y la caja los aprueba o rechaza. El piloto automático (lo aplica el PC
// de Proyecta, solo sin DJ) aprueba solo hasta un número de canciones por hora y por mesa, y
// salta las que no cargan. Con DJ en cabina no llega nada: él decide.

import { useEffect, useState } from 'react';
import { AlertTriangle, Bot, Check, Headphones, Music, X } from 'lucide-react';
import { t } from '../../i18n';
import { toast } from '../../shared/toast';
import { proyectaAPI, type ProyectaAutopilot, type ProyectaDesk } from '../../services/proyectaApi';
import { Button } from '../common/Button';

const timeOf = (iso: string) => {
  try { return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); } catch { return ''; }
};

const who = (r: { guest?: string; table?: string }) =>
  r.guest ? t('proyecta:cabina_por', { name: r.guest }) : r.table ? t('proyecta:cabina_por_mesa', { number: r.table }) : t('proyecta:cabina_por_alguien');

export function ProyectaDeskCard({ desk, isAdmin, onChange }: { desk: ProyectaDesk; isAdmin: boolean; onChange: (decidedId?: string) => void }) {
  const [busy, setBusy] = useState<string | null>(null);
  const [rules, setRules] = useState<ProyectaAutopilot>(desk.autopilot);
  const [saving, setSaving] = useState(false);

  useEffect(() => setRules(desk.autopilot), [desk.autopilot]);

  const decide = async (id: string, action: 'approve' | 'reject') => {
    setBusy(id);
    try {
      await proyectaAPI.decide(id, action);
      toast.success(t(action === 'approve' ? 'proyecta:cabina_aprobada' : 'proyecta:cabina_rechazada'));
      onChange(id);
    } catch (err: any) {
      toast.error(err?.message || t('proyecta:error'));
    } finally {
      setBusy(null);
    }
  };

  const save = async (next: ProyectaAutopilot) => {
    setRules(next);
    setSaving(true);
    try {
      setRules(await proyectaAPI.setAutopilot(next));
      toast.success(t('proyecta:piloto_guardado'));
    } catch (err: any) {
      toast.error(err?.message || t('proyecta:error'));
      setRules(desk.autopilot);
    } finally {
      setSaving(false);
    }
  };

  const stateText = !desk.online ? t('proyecta:cabina_sin_pc') : desk.djPresent ? t('proyecta:cabina_con_dj') : t('proyecta:cabina_sin_dj');

  return (
    <section className="space-y-5 rounded-3xl border border-slate-200/80 bg-white p-6 shadow-sm sm:p-8" aria-labelledby="proyecta-desk-title">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-blue-50 text-blue-700"><Headphones className="h-5 w-5" aria-hidden /></span>
          <div>
            <h3 id="proyecta-desk-title" className="font-heading text-base font-bold text-slate-900">{t('proyecta:cabina_titulo')}</h3>
            <p className="max-w-prose text-sm text-slate-500">{stateText}</p>
          </div>
        </div>
        <span className={`inline-flex h-7 items-center gap-1.5 rounded-full px-3 text-xs font-medium ${desk.djPresent ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-800'}`} role="status">
          <span className={`h-1.5 w-1.5 rounded-full ${desk.djPresent ? 'bg-emerald-500' : 'bg-amber-500'}`} aria-hidden />
          {desk.djPresent ? t('proyecta:cabina_chip_dj') : t('proyecta:cabina_chip_sin_dj')}
        </span>
      </div>

      {!desk.djPresent && desk.online && (
        <>
          <div>
            <h4 className="text-sm font-semibold text-slate-900">{t('proyecta:cabina_pendientes', { count: desk.pending.length })}</h4>
            {desk.pending.length === 0 ? (
              <p className="mt-2 rounded-2xl bg-slate-50 p-4 text-sm text-slate-500">{rules.enabled ? t('proyecta:cabina_vacio_piloto') : t('proyecta:cabina_vacio')}</p>
            ) : (
              <ul className="mt-2 divide-y divide-slate-100 rounded-2xl border border-slate-200">
                {desk.pending.map((r) => (
                  <li key={r.id} className="flex items-center gap-3 p-3">
                    {r.thumbnailUrl
                      ? <img src={r.thumbnailUrl} alt="" className="h-12 w-20 shrink-0 rounded-lg object-cover" />
                      : <span className="grid h-12 w-20 shrink-0 place-items-center rounded-lg bg-slate-100 text-slate-400"><Music className="h-5 w-5" aria-hidden /></span>}
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold text-slate-900">{r.title}</p>
                      <p className="truncate text-xs text-slate-500">{who(r)} · <span className="tabular-nums">{timeOf(r.at)}</span></p>
                    </div>
                    <Button size="sm" variant="outline" disabled={!!busy} onClick={() => decide(r.id, 'reject')} aria-label={t('proyecta:cabina_rechazar_de', { title: r.title })}>
                      <X className="h-4 w-4" aria-hidden />
                    </Button>
                    <Button size="sm" isLoading={busy === r.id} disabled={!!busy && busy !== r.id} onClick={() => decide(r.id, 'approve')}>
                      <Check className="h-4 w-4" aria-hidden /> {t('proyecta:cabina_aprobar')}
                    </Button>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {desk.alerts.length > 0 && (
            <ul className="space-y-2" aria-label={t('proyecta:cabina_avisos')}>
              {desk.alerts.slice().reverse().slice(0, 5).map((a) => (
                <li key={a.id} className="flex items-start gap-2 rounded-xl bg-amber-50 p-3 text-sm text-amber-900">
                  <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
                  <span className="flex-1">{a.text}</span>
                  <span className="tabular-nums text-xs text-amber-700">{timeOf(a.at)}</span>
                </li>
              ))}
            </ul>
          )}
        </>
      )}

      {isAdmin && (
        <fieldset className="space-y-3 border-t border-slate-100 pt-5" disabled={saving}>
          <legend className="sr-only">{t('proyecta:piloto_titulo')}</legend>
          <label className="flex cursor-pointer items-start gap-3">
            <input type="checkbox" className="mt-1 h-4 w-4 accent-blue-600" checked={rules.enabled} onChange={(e) => save({ ...rules, enabled: e.target.checked })} />
            <span>
              <span className="flex items-center gap-1.5 text-sm font-semibold text-slate-900"><Bot className="h-4 w-4 text-blue-700" aria-hidden /> {t('proyecta:piloto_titulo')}</span>
              <span className="block text-sm text-slate-500">{t('proyecta:piloto_desc')}</span>
            </span>
          </label>
          {rules.enabled && (
            <div className="grid gap-3 pl-7 sm:grid-cols-2">
              <label className="text-sm text-slate-700">
                {t('proyecta:piloto_por_hora')}
                <input type="number" min={0} max={60} value={rules.maxPerHour}
                  onChange={(e) => setRules({ ...rules, maxPerHour: Math.max(0, Math.min(60, Number(e.target.value) || 0)) })}
                  onBlur={() => save(rules)}
                  className="mt-1 block min-h-[40px] w-full rounded-xl border border-slate-200 px-3 tabular-nums focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/30" />
              </label>
              <label className="text-sm text-slate-700">
                {t('proyecta:piloto_por_mesa')}
                <input type="number" min={0} max={20} value={rules.maxPerTable}
                  onChange={(e) => setRules({ ...rules, maxPerTable: Math.max(0, Math.min(20, Number(e.target.value) || 0)) })}
                  onBlur={() => save(rules)}
                  className="mt-1 block min-h-[40px] w-full rounded-xl border border-slate-200 px-3 tabular-nums focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/30" />
              </label>
              <label className="flex cursor-pointer items-center gap-2 text-sm text-slate-700 sm:col-span-2">
                <input type="checkbox" className="h-4 w-4 accent-blue-600" checked={rules.skipOnLoadError} onChange={(e) => save({ ...rules, skipOnLoadError: e.target.checked })} />
                {t('proyecta:piloto_saltar')}
              </label>
            </div>
          )}
        </fieldset>
      )}
    </section>
  );
}
