// ============================================
// ADMIN - Personal: equipo, turnos, pagos y propinas (Lantify 3.0)
// ============================================
// Control interno de cada empleado. No calcula seguridad social ni prestaciones.
// Con la función apagada, esta sección es la de siempre: usuarios y permisos.

import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { AlertTriangle, Check, Clock, Plus, Trash2 } from 'lucide-react';
import { t, getLocale } from '../../i18n';
import { toast } from '../../shared/toast';
import { confirmDialog } from '../../shared/dialog';
import { formatCurrency } from '../../shared/formatUtils';
import { Button } from '../common/Button';
import { STAFF_GROUPS, useFeatureFlag, useFeatures } from '../../shared/features';
import { staffAPI, type Employee, type Payroll, type PayrollRow, type Shift, type StaffMovement, type TipPreview, type TipSplit } from '../../services/v3Api';
import { UsersAdmin } from './UsersAdmin';

type Tab = 'users' | 'team' | 'shifts' | 'pay' | 'tips';

const field = 'rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 min-h-[44px] focus:outline-none focus:ring-2 focus:ring-blue-500/40';
const card = 'bg-white rounded-3xl shadow-sm border border-slate-200/80 overflow-hidden';
const th = 'text-left text-xs font-bold uppercase tracking-wider text-slate-500 px-4 py-3';
const td = 'px-4 py-3 text-sm text-slate-800 align-middle';

const day = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
const weekStart = () => { const d = new Date(); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return day(d); };
const fromIso = (d: string) => new Date(`${d}T00:00:00`).toISOString();
const toIso = (d: string) => new Date(`${d}T23:59:59.999`).toISOString();
const when = (iso: string) => new Date(iso).toLocaleString(getLocale(), { weekday: 'short', day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' });
const localInput = (iso: string) => { const d = new Date(iso); return `${day(d)}T${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; };
const hoursOf = (s: Shift) => (s.endAt ? Math.round(((+new Date(s.endAt) - +new Date(s.startAt)) / 3_600_000) * 10) / 10 : null);

const errorToast = (err: any) => toast.error(err?.message || t('v3:no_se_guardo'));

function Period({ from, to, onChange }: { from: string; to: string; onChange: (from: string, to: string) => void }) {
  return (
    <div className="flex flex-wrap items-end gap-3">
      <label className="text-xs font-bold text-slate-700 space-y-1 block">{t('v3:desde_fecha')}<input type="date" className={`${field} block`} value={from} max={to} onChange={(e) => onChange(e.target.value, to)} /></label>
      <label className="text-xs font-bold text-slate-700 space-y-1 block">{t('v3:hasta_fecha')}<input type="date" className={`${field} block`} value={to} min={from} onChange={(e) => onChange(from, e.target.value)} /></label>
    </div>
  );
}

export const StaffModule: React.FC<{ currentUser: any }> = ({ currentUser }) => {
  const staffOn = useFeatureFlag('staff');
  const tipsOn = useFeatureFlag('tip_split');
  const tipPeriod = useFeatures((s) => s.settings.tips.period);
  const [tab, setTab] = useState<Tab>('team');
  const [team, setTeam] = useState<Employee[]>([]);
  const [from, setFrom] = useState(weekStart());
  const [to, setTo] = useState(day(new Date()));

  const loadTeam = useCallback(async () => {
    try { setTeam(await staffAPI.list()); } catch (err) { errorToast(err); }
  }, []);
  useEffect(() => { if (staffOn) loadTeam(); }, [staffOn, loadTeam]);

  if (!staffOn) return <UsersAdmin currentUser={currentUser} />;

  const tabs: Tab[] = ['team', 'shifts', 'pay', ...(tipsOn ? ['tips' as Tab] : []), 'users'];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-slate-900 font-heading">{t('v3:personal')}</h2>
        <p className="text-sm text-slate-500 mt-1 max-w-2xl">{t('v3:personal_desc')}</p>
      </div>
      <div className="flex gap-2 overflow-x-auto pb-1" role="tablist">
        {tabs.map((id) => (
          <button key={id} type="button" role="tab" aria-selected={tab === id} onClick={() => setTab(id)} className={`px-4 min-h-[44px] rounded-xl text-sm font-bold whitespace-nowrap border ${tab === id ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'}`}>
            {t(`v3:tab_${id}`)}
          </button>
        ))}
      </div>
      {tab === 'users' && <UsersAdmin currentUser={currentUser} />}
      {tab === 'team' && <TeamTab team={team} reload={loadTeam} />}
      {tab === 'shifts' && <ShiftsTab team={team} from={from} to={to} setPeriod={(a, b) => { setFrom(a); setTo(b); }} reloadTeam={loadTeam} />}
      {tab === 'pay' && <PayTab team={team} from={from} to={to} setPeriod={(a, b) => { setFrom(a); setTo(b); }} />}
      {tab === 'tips' && tipsOn && <TipsTab from={from} to={to} periodType={tipPeriod} setPeriod={(a, b) => { setFrom(a); setTo(b); }} />}
    </div>
  );
};

// ── Equipo: ficha de cada empleado ──────────────────────────

function TeamTab({ team, reload }: { team: Employee[]; reload: () => Promise<void> }) {
  const [editing, setEditing] = useState<Partial<Employee> | null>(null);
  const [saving, setSaving] = useState(false);

  const save = async () => {
    if (!editing) return;
    setSaving(true);
    try {
      const data = { name: editing.name, position: editing.position, phone: editing.phone, payType: editing.payType, payAmount: Number(editing.payAmount) || 0, isActive: editing.isActive };
      if (editing.id) await staffAPI.update(editing.id, data);
      else await staffAPI.create(data);
      setEditing(null);
      await reload();
      toast.success(t('v3:guardado'));
    } catch (err) { errorToast(err); } finally { setSaving(false); }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center gap-3 flex-wrap">
        <p className="text-sm text-slate-600 max-w-xl">{t('v3:equipo_desc')}</p>
        <Button leftIcon={<Plus className="w-4 h-4" />} onClick={() => setEditing({ name: '', position: 'KITCHEN', payType: 'SHIFT', payAmount: 0, isActive: true })}>{t('v3:nuevo_empleado')}</Button>
      </div>

      {editing && (
        <form className={`${card} p-5 grid sm:grid-cols-2 lg:grid-cols-5 gap-3 items-end`} onSubmit={(e) => { e.preventDefault(); save(); }}>
          <label className="text-xs font-bold text-slate-700 space-y-1 block lg:col-span-2">{t('v3:nombre')}<input required autoFocus className={`${field} w-full`} value={editing.name || ''} onChange={(e) => setEditing({ ...editing, name: e.target.value })} /></label>
          <label className="text-xs font-bold text-slate-700 space-y-1 block">{t('v3:puesto')}
            <select className={`${field} w-full`} value={editing.position} onChange={(e) => setEditing({ ...editing, position: e.target.value as Employee['position'] })}>
              {STAFF_GROUPS.map((g) => <option key={g} value={g}>{t(`v3:puesto_${g}`)}</option>)}
            </select>
          </label>
          <label className="text-xs font-bold text-slate-700 space-y-1 block">{t('v3:forma_pago')}
            <select className={`${field} w-full`} value={editing.payType} onChange={(e) => setEditing({ ...editing, payType: e.target.value as Employee['payType'] })}>
              {(['SHIFT', 'HOUR', 'FIXED'] as const).map((p) => <option key={p} value={p}>{t(`v3:pago_${p}`)}</option>)}
            </select>
          </label>
          <label className="text-xs font-bold text-slate-700 space-y-1 block">{t('v3:valor')}<input type="number" min={0} step={1} className={`${field} w-full`} value={editing.payAmount ?? 0} onChange={(e) => setEditing({ ...editing, payAmount: Number(e.target.value) })} /></label>
          <label className="text-xs font-bold text-slate-700 space-y-1 block lg:col-span-2">{t('v3:telefono')}<input inputMode="tel" className={`${field} w-full`} value={editing.phone || ''} onChange={(e) => setEditing({ ...editing, phone: e.target.value })} /></label>
          {editing.id && (
            <label className="flex items-center gap-2 text-sm font-semibold text-slate-800 min-h-[44px]"><input type="checkbox" className="w-5 h-5 accent-blue-600" checked={editing.isActive !== false} onChange={(e) => setEditing({ ...editing, isActive: e.target.checked })} />{t('v3:activo')}</label>
          )}
          <div className="flex gap-2 lg:col-span-2 lg:justify-end">
            <Button type="button" variant="secondary" onClick={() => setEditing(null)}>{t('v3:cancelar')}</Button>
            <Button type="submit" isLoading={saving}>{t('v3:guardar')}</Button>
          </div>
        </form>
      )}

      <div className={`${card} overflow-x-auto`}>
        <table className="w-full min-w-[640px]">
          <thead className="bg-slate-50 border-b border-slate-200"><tr><th className={th}>{t('v3:nombre')}</th><th className={th}>{t('v3:puesto')}</th><th className={th}>{t('v3:forma_pago')}</th><th className={th}>{t('v3:usuario')}</th><th className={th} /></tr></thead>
          <tbody className="divide-y divide-slate-100">
            {team.map((e) => (
              <tr key={e.id} className={e.isActive ? '' : 'opacity-60'}>
                <td className={`${td} font-bold text-slate-900`}>{e.name}{!e.isActive && <span className="ml-2 text-xs font-semibold text-slate-500">({t('v3:inactivo')})</span>}</td>
                <td className={td}>{t(`v3:puesto_${e.position}`)}</td>
                <td className={`${td} tabular-nums`}>{formatCurrency(e.payAmount)} · {t(`v3:pago_${e.payType}`)}</td>
                <td className={td}>{e.user ? e.user.username : <span className="text-slate-500">{t('v3:sin_usuario')}</span>}</td>
                <td className={`${td} text-right`}><Button size="sm" variant="outline" onClick={() => setEditing(e)}>{t('v3:editar')}</Button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── Turnos ──────────────────────────────────────────────────

/** Horario de la semana: quién trabajó qué día (✓ con horas) y qué días le tocan (casillas) */
function WeekGrid({ team, reloadTeam, onEdit, version }: { team: Employee[]; reloadTeam: () => Promise<void>; onEdit: (s: Shift) => void; version: number }) {
  const [monday, setMonday] = useState(() => {
    const d = new Date(); d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() - ((d.getDay() + 6) % 7));
    return d;
  });
  const [shifts, setShifts] = useState<Shift[]>([]);
  const days = Array.from({ length: 7 }, (_, i) => { const d = new Date(monday); d.setDate(d.getDate() + i); return d; });
  const end = new Date(monday); end.setDate(end.getDate() + 7);

  useEffect(() => {
    staffAPI.shifts(monday.toISOString(), end.toISOString()).then(setShifts).catch(() => setShifts([]));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [monday, version]);

  const move = (weeks: number) => setMonday((m) => { const d = new Date(m); d.setDate(d.getDate() + weeks * 7); return d; });
  const planned = (e: Employee) => new Set((e.workDays || '').split(',').filter(Boolean).map(Number));
  const togglePlan = async (e: Employee, wd: number) => {
    const set = planned(e);
    if (set.has(wd)) set.delete(wd); else set.add(wd);
    try { await staffAPI.update(e.id, { workDays: [...set] } as any); await reloadTeam(); } catch (err) { errorToast(err); }
  };
  const hours = (s: Shift) => s.endAt ? (new Date(s.endAt).getTime() - new Date(s.startAt).getTime()) / 3_600_000 : null;
  const hhmm = (iso: string) => new Date(iso).toLocaleTimeString(getLocale(), { hour: 'numeric', minute: '2-digit' });
  const fmtDay = (d: Date) => d.toLocaleDateString(getLocale(), { weekday: 'short', day: 'numeric' });

  return (
    <section className={`${card} overflow-x-auto`} aria-labelledby="week-title">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 px-4 py-3">
        <h3 id="week-title" className="text-base font-bold text-slate-900 font-heading">{t('v3:horario_semana')}</h3>
        <div className="flex items-center gap-1">
          <button type="button" onClick={() => move(-1)} className="min-h-[36px] rounded-lg px-2.5 text-sm font-bold text-slate-600 hover:bg-slate-100" aria-label={t('v3:semana_anterior')}>‹</button>
          <span className="text-sm font-semibold text-slate-700 tabular-nums">{days[0].toLocaleDateString(getLocale(), { day: 'numeric', month: 'short' })} – {days[6].toLocaleDateString(getLocale(), { day: 'numeric', month: 'short' })}</span>
          <button type="button" onClick={() => move(1)} className="min-h-[36px] rounded-lg px-2.5 text-sm font-bold text-slate-600 hover:bg-slate-100" aria-label={t('v3:semana_siguiente')}>›</button>
        </div>
      </div>
      <table className="w-full min-w-[720px] text-sm">
        <thead className="bg-slate-50 text-xs font-bold uppercase tracking-wide text-slate-500">
          <tr><th className="px-3 py-2 text-left">{t('v3:empleado')}</th>{days.map((d) => <th key={d.toISOString()} className={`px-2 py-2 text-center ${d.toDateString() === new Date().toDateString() ? 'text-blue-700' : ''}`}>{fmtDay(d)}</th>)}<th className="px-3 py-2 text-right">{t('v3:horas')}</th></tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {team.map((e) => {
            const plan = planned(e);
            let total = 0;
            return (
              <tr key={e.id}>
                <td className="px-3 py-2 font-semibold text-slate-900 whitespace-nowrap">{e.name}</td>
                {days.map((d) => {
                  const mine = shifts.filter((s) => s.employeeId === e.id && new Date(s.startAt).toDateString() === d.toDateString());
                  mine.forEach((s) => { total += hours(s) || 0; });
                  const wd = d.getDay();
                  if (mine.length) {
                    return (
                      <td key={wd} className="px-1 py-1 text-center">
                        {mine.map((s) => (
                          <button key={s.id} type="button" onClick={() => onEdit(s)} title={t('v3:editar_turno')} className={`block w-full rounded-lg px-1 py-1 text-[11px] font-bold leading-tight ${s.needsReview ? 'bg-amber-100 text-amber-900' : s.endAt ? 'bg-emerald-100 text-emerald-900' : 'bg-blue-100 text-blue-900'}`}>
                            ✓ {hhmm(s.startAt)}–{s.endAt ? hhmm(s.endAt) : '…'}{hours(s) !== null ? <span className="block font-semibold opacity-80">{hours(s)!.toFixed(1)} h</span> : null}
                          </button>
                        ))}
                      </td>
                    );
                  }
                  return (
                    <td key={wd} className="px-1 py-1 text-center">
                      <label className="inline-flex h-9 w-9 cursor-pointer items-center justify-center rounded-lg hover:bg-slate-100" title={t('v3:le_toca')}>
                        <input type="checkbox" className="h-4 w-4 accent-blue-600" checked={plan.has(wd)} onChange={() => togglePlan(e, wd)} aria-label={t('v3:le_toca_dia', { name: e.name, day: fmtDay(d) })} />
                      </label>
                    </td>
                  );
                })}
                <td className="px-3 py-2 text-right font-bold tabular-nums text-slate-900">{total ? `${total.toFixed(1)} h` : '—'}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
      <p className="px-4 py-2 text-xs text-slate-500">{t('v3:horario_ayuda')}</p>
    </section>
  );
}

function ShiftsTab({ team, from, to, setPeriod, reloadTeam }: { team: Employee[]; from: string; to: string; setPeriod: (a: string, b: string) => void; reloadTeam: () => Promise<void> }) {
  const [shifts, setShifts] = useState<Shift[]>([]);
  const [edit, setEdit] = useState<{ id: string | null; employeeId: string; startAt: string; endAt: string } | null>(null);

  const load = useCallback(async () => {
    try { setShifts(await staffAPI.shifts(fromIso(from), toIso(to))); } catch (err) { errorToast(err); }
  }, [from, to]);
  useEffect(() => { load(); }, [load]);

  const mark = async (e: Employee) => {
    try {
      if (e.openShift) await staffAPI.clockOut(e.id); else await staffAPI.clockIn(e.id);
      await Promise.all([reloadTeam(), load()]);
    } catch (err) { errorToast(err); }
  };

  const save = async () => {
    if (!edit) return;
    try {
      await staffAPI.saveShift(edit.id, { employeeId: edit.employeeId, startAt: new Date(edit.startAt).toISOString(), endAt: edit.endAt ? new Date(edit.endAt).toISOString() : null });
      setEdit(null);
      await Promise.all([reloadTeam(), load()]);
      toast.success(t('v3:guardado'));
    } catch (err) { errorToast(err); }
  };

  const remove = async (s: Shift) => {
    if (!(await confirmDialog({ title: t('v3:eliminar_turno'), message: t('v3:eliminar_turno_desc'), tone: 'danger' }))) return;
    try { await staffAPI.deleteShift(s.id); await Promise.all([reloadTeam(), load()]); } catch (err) { errorToast(err); }
  };

  const active = team.filter((e) => e.isActive);
  return (
    <div className="space-y-4">
      <section className={`${card} p-5 space-y-3`}>
        <h3 className="text-base font-bold text-slate-900 font-heading">{t('v3:marcar_hoy')}</h3>
        <p className="text-xs text-slate-500">{t('v3:marcar_hoy_desc')}</p>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-2">
          {active.map((e) => (
            <button key={e.id} type="button" onClick={() => mark(e)} className={`min-h-[52px] px-3 rounded-xl border-2 text-left flex items-center gap-2 ${e.openShift ? 'border-emerald-500 bg-emerald-50' : 'border-slate-200 bg-white hover:border-slate-400'}`}>
              <Clock className={`w-5 h-5 shrink-0 ${e.openShift ? 'text-emerald-700' : 'text-slate-400'}`} aria-hidden />
              <span className="flex-1 min-w-0"><span className="block text-sm font-bold text-slate-900 truncate">{e.name}</span>
                <span className="block text-xs text-slate-600">{e.openShift ? t('v3:en_turno_desde', { hora: new Date(e.openShift.startAt).toLocaleTimeString(getLocale(), { hour: 'numeric', minute: '2-digit' }) }) : t('v3:fuera_de_turno')}</span></span>
              <span className="text-xs font-bold text-slate-700">{e.openShift ? t('v3:marcar_salida') : t('v3:marcar_entrada')}</span>
            </button>
          ))}
        </div>
      </section>

      <WeekGrid team={active} reloadTeam={reloadTeam} onEdit={(s) => setEdit({ id: s.id, employeeId: s.employeeId, startAt: localInput(s.startAt), endAt: s.endAt ? localInput(s.endAt) : '' })} version={shifts.length} />

      <div className="flex flex-wrap items-end justify-between gap-3">
        <Period from={from} to={to} onChange={setPeriod} />
        <Button variant="secondary" leftIcon={<Plus className="w-4 h-4" />} onClick={() => setEdit({ id: null, employeeId: active[0]?.id || '', startAt: localInput(new Date().toISOString()), endAt: '' })}>{t('v3:agregar_turno')}</Button>
      </div>

      {edit && (
        <form className={`${card} p-5 grid sm:grid-cols-4 gap-3 items-end`} onSubmit={(e) => { e.preventDefault(); save(); }}>
          <label className="text-xs font-bold text-slate-700 space-y-1 block">{t('v3:empleado')}
            <select disabled={!!edit.id} className={`${field} w-full`} value={edit.employeeId} onChange={(e) => setEdit({ ...edit, employeeId: e.target.value })}>{team.map((e) => <option key={e.id} value={e.id}>{e.name}</option>)}</select>
          </label>
          <label className="text-xs font-bold text-slate-700 space-y-1 block">{t('v3:entrada')}<input required type="datetime-local" className={`${field} w-full`} value={edit.startAt} onChange={(e) => setEdit({ ...edit, startAt: e.target.value })} /></label>
          <label className="text-xs font-bold text-slate-700 space-y-1 block">{t('v3:salida')}<input type="datetime-local" className={`${field} w-full`} value={edit.endAt} onChange={(e) => setEdit({ ...edit, endAt: e.target.value })} /></label>
          <div className="flex gap-2"><Button type="button" variant="secondary" onClick={() => setEdit(null)}>{t('v3:cancelar')}</Button><Button type="submit">{t('v3:guardar')}</Button></div>
        </form>
      )}

      <div className={`${card} overflow-x-auto`}>
        <table className="w-full min-w-[640px]">
          <thead className="bg-slate-50 border-b border-slate-200"><tr><th className={th}>{t('v3:empleado')}</th><th className={th}>{t('v3:entrada')}</th><th className={th}>{t('v3:salida')}</th><th className={th}>{t('v3:horas')}</th><th className={th} /></tr></thead>
          <tbody className="divide-y divide-slate-100">
            {shifts.map((s) => (
              <tr key={s.id} className={s.needsReview ? 'bg-amber-50' : ''}>
                <td className={`${td} font-bold text-slate-900`}>{s.employee?.name}</td>
                <td className={td}>{when(s.startAt)}</td>
                <td className={td}>{s.endAt ? when(s.endAt) : <span className="font-semibold text-emerald-700">{t('v3:en_turno')}</span>}
                  {s.needsReview && <span className="ml-2 inline-flex items-center gap-1 text-xs font-bold text-amber-800"><AlertTriangle className="w-3.5 h-3.5" aria-hidden />{t('v3:por_revisar')}</span>}</td>
                <td className={`${td} tabular-nums`}>{hoursOf(s) ?? '—'}</td>
                <td className={`${td} text-right whitespace-nowrap`}>
                  <Button size="sm" variant="outline" onClick={() => setEdit({ id: s.id, employeeId: s.employeeId, startAt: localInput(s.startAt), endAt: s.endAt ? localInput(s.endAt) : '' })}>{s.needsReview ? t('v3:revisar') : t('v3:editar')}</Button>
                  <button type="button" onClick={() => remove(s)} aria-label={t('v3:eliminar_turno')} className="ml-1 w-9 h-9 inline-flex items-center justify-center rounded-lg text-slate-500 hover:bg-rose-50 hover:text-rose-700"><Trash2 className="w-4 h-4" aria-hidden /></button>
                </td>
              </tr>
            ))}
            {shifts.length === 0 && <tr><td colSpan={5} className={`${td} text-center text-slate-500 py-8`}>{t('v3:sin_turnos')}</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── Pagos: adelantos, descuentos y liquidación ──────────────

function PayTab({ team, from, to, setPeriod }: { team: Employee[]; from: string; to: string; setPeriod: (a: string, b: string) => void }) {
  const [rows, setRows] = useState<PayrollRow[]>([]);
  const [history, setHistory] = useState<Payroll[]>([]);
  const [moves, setMoves] = useState<StaffMovement[]>([]);
  const [move, setMove] = useState({ employeeId: '', type: 'ADVANCE' as 'ADVANCE' | 'DEDUCTION', amount: '', reason: '' });

  const load = useCallback(async () => {
    try {
      const [a, b, c] = await Promise.all([staffAPI.payrollPreview(fromIso(from), toIso(to)), staffAPI.payrolls(), staffAPI.movements(fromIso(from), toIso(to))]);
      setRows(a); setHistory(b); setMoves(c);
    } catch (err) { errorToast(err); }
  }, [from, to]);
  useEffect(() => { load(); }, [load]);

  const addMove = async () => {
    try {
      await staffAPI.addMovement({ employeeId: move.employeeId || team[0]?.id, type: move.type, amount: Number(move.amount), reason: move.reason });
      setMove({ ...move, amount: '', reason: '' });
      await load();
    } catch (err) { errorToast(err); }
  };

  const settle = async (r: PayrollRow) => {
    if (!(await confirmDialog({ title: t('v3:liquidar_a', { name: r.name }), message: t('v3:liquidar_desc', { total: formatCurrency(r.total) }) }))) return;
    try { await staffAPI.createPayroll(r.employeeId, fromIso(from), toIso(to)); await load(); toast.success(t('v3:liquidacion_guardada')); } catch (err) { errorToast(err); }
  };

  const pay = async (p: Payroll) => {
    const asExpense = await confirmDialog({ title: t('v3:registrar_gasto'), message: t('v3:registrar_gasto_desc'), confirmLabel: t('v3:si_registrar'), cancelLabel: t('v3:solo_marcar') });
    try { await staffAPI.payPayroll(p.id, asExpense); await load(); } catch (err) { errorToast(err); }
  };

  const undo = async (p: Payroll) => {
    try { await staffAPI.deletePayroll(p.id); await load(); } catch (err) { errorToast(err); }
  };

  return (
    <div className="space-y-5">
      <form className={`${card} p-5 grid sm:grid-cols-2 lg:grid-cols-5 gap-3 items-end`} onSubmit={(e) => { e.preventDefault(); addMove(); }}>
        <label className="text-xs font-bold text-slate-700 space-y-1 block">{t('v3:empleado')}
          <select className={`${field} w-full`} value={move.employeeId || team[0]?.id || ''} onChange={(e) => setMove({ ...move, employeeId: e.target.value })}>{team.filter((e) => e.isActive).map((e) => <option key={e.id} value={e.id}>{e.name}</option>)}</select>
        </label>
        <label className="text-xs font-bold text-slate-700 space-y-1 block">{t('v3:tipo')}
          <select className={`${field} w-full`} value={move.type} onChange={(e) => setMove({ ...move, type: e.target.value as 'ADVANCE' | 'DEDUCTION' })}><option value="ADVANCE">{t('v3:adelanto')}</option><option value="DEDUCTION">{t('v3:descuento')}</option></select>
        </label>
        <label className="text-xs font-bold text-slate-700 space-y-1 block">{t('v3:valor')}<input required type="number" min={1} step={1} className={`${field} w-full`} value={move.amount} onChange={(e) => setMove({ ...move, amount: e.target.value })} /></label>
        <label className="text-xs font-bold text-slate-700 space-y-1 block">{t('v3:motivo')}<input className={`${field} w-full`} maxLength={200} value={move.reason} onChange={(e) => setMove({ ...move, reason: e.target.value })} /></label>
        <Button type="submit" variant="secondary" leftIcon={<Plus className="w-4 h-4" />}>{t('v3:registrar')}</Button>
      </form>

      {moves.filter((m) => !m.payrollId).length > 0 && (
        <ul className={`${card} divide-y divide-slate-100`}>
          {moves.filter((m) => !m.payrollId).map((m) => (
            <li key={m.id} className="px-4 py-2.5 flex items-center gap-3 text-sm">
              <span className="font-bold text-slate-900">{m.employee?.name}</span>
              <span className="text-slate-600">{m.type === 'ADVANCE' ? t('v3:adelanto') : t('v3:descuento')}{m.reason ? ` · ${m.reason}` : ''}</span>
              <span className="ml-auto tabular-nums font-bold text-slate-900">{formatCurrency(m.amount)}</span>
              <button type="button" aria-label={t('v3:eliminar')} onClick={async () => { try { await staffAPI.deleteMovement(m.id); await load(); } catch (err) { errorToast(err); } }} className="w-9 h-9 inline-flex items-center justify-center rounded-lg text-slate-500 hover:bg-rose-50 hover:text-rose-700"><Trash2 className="w-4 h-4" aria-hidden /></button>
            </li>
          ))}
        </ul>
      )}

      <div>
        <div className="flex flex-wrap items-end justify-between gap-3 mb-3">
          <h3 className="text-base font-bold text-slate-900 font-heading">{t('v3:liquidacion_periodo')}</h3>
          <Period from={from} to={to} onChange={setPeriod} />
        </div>
        <div className={`${card} overflow-x-auto`}>
          <table className="w-full min-w-[820px]">
            <thead className="bg-slate-50 border-b border-slate-200"><tr>
              <th className={th}>{t('v3:empleado')}</th><th className={th}>{t('v3:trabajado')}</th><th className={`${th} text-right`}>{t('v3:pago_base')}</th><th className={`${th} text-right`}>{t('v3:propinas')}</th>
              <th className={`${th} text-right`}>{t('v3:adelantos')}</th><th className={`${th} text-right`}>{t('v3:descuentos')}</th><th className={`${th} text-right`}>{t('v3:a_pagar')}</th><th className={th} />
            </tr></thead>
            <tbody className="divide-y divide-slate-100">
              {rows.map((r) => (
                <tr key={r.employeeId}>
                  <td className={`${td} font-bold text-slate-900`}>{r.name}</td>
                  <td className={td}>{r.payType === 'HOUR' ? t('v3:n_horas', { n: r.hours }) : r.payType === 'SHIFT' ? t('v3:n_dias', { n: r.days }) : t('v3:pago_FIXED')}
                    {r.pendingShifts > 0 && <span className="block text-xs font-bold text-amber-800">{t('v3:turnos_pendientes', { n: r.pendingShifts })}</span>}</td>
                  <td className={`${td} text-right tabular-nums`}>{formatCurrency(r.base)}</td>
                  <td className={`${td} text-right tabular-nums`}>{formatCurrency(r.tips)}</td>
                  <td className={`${td} text-right tabular-nums`}>{r.advances ? `− ${formatCurrency(r.advances)}` : '—'}</td>
                  <td className={`${td} text-right tabular-nums`}>{r.deductions ? `− ${formatCurrency(r.deductions)}` : '—'}</td>
                  <td className={`${td} text-right tabular-nums font-black text-slate-900`}>{formatCurrency(r.total)}</td>
                  <td className={`${td} text-right`}><Button size="sm" onClick={() => settle(r)}>{t('v3:liquidar')}</Button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {history.length > 0 && (
        <div>
          <h3 className="text-base font-bold text-slate-900 font-heading mb-3">{t('v3:liquidaciones')}</h3>
          <ul className={`${card} divide-y divide-slate-100`}>
            {history.map((p) => (
              <li key={p.id} className="px-4 py-3 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm">
                <span className="font-bold text-slate-900">{p.employee?.name}</span>
                <span className="text-slate-600">{new Date(p.periodFrom).toLocaleDateString(getLocale())} – {new Date(p.periodTo).toLocaleDateString(getLocale())}</span>
                <span className="ml-auto tabular-nums font-black text-slate-900">{formatCurrency(p.total)}</span>
                {p.status === 'PAID'
                  ? <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-800 bg-emerald-100 rounded-full px-2.5 py-1"><Check className="w-3.5 h-3.5" aria-hidden />{t('v3:pagada')}</span>
                  : <><Button size="sm" variant="success" onClick={() => pay(p)}>{t('v3:marcar_pagada')}</Button><Button size="sm" variant="ghost" onClick={() => undo(p)}>{t('v3:deshacer')}</Button></>}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

// ── Propinas: reparto del periodo ───────────────────────────

function TipsTab({ from, to, periodType, setPeriod }: { from: string; to: string; periodType: string; setPeriod: (a: string, b: string) => void }) {
  const [preview, setPreview] = useState<TipPreview | null>(null);
  const [amounts, setAmounts] = useState<Record<string, number>>({});
  const [splits, setSplits] = useState<TipSplit[]>([]);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const [p, s] = await Promise.all([staffAPI.tipPreview(fromIso(from), toIso(to)), staffAPI.tipSplits()]);
      setPreview(p); setSplits(s);
      setAmounts(Object.fromEntries(p.shares.map((x) => [x.employeeId, x.amount])));
    } catch (err) { errorToast(err); }
  }, [from, to]);
  useEffect(() => { load(); }, [load]);

  const assigned = useMemo(() => Object.values(amounts).reduce((a, n) => a + (Number(n) || 0), 0), [amounts]);
  const left = (preview?.total || 0) - assigned;

  const confirm = async () => {
    if (!preview) return;
    setBusy(true);
    try {
      await staffAPI.confirmTips({ from: fromIso(from), to: toIso(to), periodType, shares: Object.entries(amounts).map(([employeeId, amount]) => ({ employeeId, amount: Number(amount) || 0 })) });
      toast.success(t('v3:reparto_confirmado'));
      await load();
    } catch (err) { errorToast(err); } finally { setBusy(false); }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <Period from={from} to={to} onChange={setPeriod} />
        {preview && <p className="text-sm text-slate-700">{t('v3:propinas_del_periodo')} <strong className="text-lg text-slate-900 tabular-nums">{formatCurrency(preview.total)}</strong></p>}
      </div>

      {preview && preview.alreadyConfirmed && <p className="rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-sm font-semibold p-4">{t('v3:periodo_ya_repartido')}</p>}
      {preview && !preview.alreadyConfirmed && preview.total <= 0 && <p className="rounded-2xl bg-slate-50 border border-slate-200 text-slate-700 text-sm p-4">{t('v3:sin_propinas')}</p>}

      {preview && !preview.alreadyConfirmed && preview.total > 0 && (
        <section className={`${card} p-5 space-y-4`}>
          <p className="text-sm text-slate-600">{t('v3:reparto_desc')}</p>
          <ul className="divide-y divide-slate-100">
            {preview.employees.map((e) => (
              <li key={e.id} className="py-2 flex items-center gap-3">
                <span className="flex-1 min-w-0"><span className="block text-sm font-bold text-slate-900 truncate">{e.name}</span><span className="block text-xs text-slate-600">{t(`v3:puesto_${e.group}`)}</span></span>
                <input type="number" min={0} step={100} aria-label={t('v3:propina_de', { name: e.name })} className={`${field} w-36 text-right tabular-nums`} value={amounts[e.id] ?? 0} onChange={(ev) => setAmounts({ ...amounts, [e.id]: Math.max(0, Math.round(Number(ev.target.value) || 0)) })} />
              </li>
            ))}
          </ul>
          <p role="status" className={`text-sm font-bold ${left === 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
            {left === 0 ? t('v3:reparto_completo') : left > 0 ? t('v3:falta_asignar', { valor: formatCurrency(left) }) : t('v3:sobra_asignar', { valor: formatCurrency(-left) })}
          </p>
          {preview.unassigned.length > 0 && <p className="text-xs text-amber-800 font-semibold">{t('v3:grupos_sin_personas', { grupos: preview.unassigned.map((u) => t(`v3:puesto_${u.group}`)).join(', ') })}</p>}
          <Button disabled={left !== 0} isLoading={busy} onClick={confirm}>{t('v3:confirmar_reparto')}</Button>
        </section>
      )}

      {splits.length > 0 && (
        <div>
          <h3 className="text-base font-bold text-slate-900 font-heading mb-3">{t('v3:repartos_confirmados')}</h3>
          <ul className="space-y-3">
            {splits.map((s) => (
              <li key={s.id} className={`${card} p-4`}>
                <div className="flex flex-wrap items-center gap-3">
                  <span className="text-sm font-bold text-slate-900">{new Date(s.periodFrom).toLocaleDateString(getLocale())} – {new Date(s.periodTo).toLocaleDateString(getLocale())}</span>
                  <span className="tabular-nums font-black text-slate-900">{formatCurrency(s.total)}</span>
                  <span className="ml-auto flex gap-2">
                    {s.status === 'PAID'
                      ? <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-800 bg-emerald-100 rounded-full px-2.5 py-1"><Check className="w-3.5 h-3.5" aria-hidden />{t('v3:pagada')}</span>
                      : <><Button size="sm" variant="success" onClick={async () => { try { await staffAPI.payTips(s.id); await load(); } catch (err) { errorToast(err); } }}>{t('v3:marcar_pagada')}</Button>
                        <Button size="sm" variant="ghost" onClick={async () => { try { await staffAPI.deleteTipSplit(s.id); await load(); } catch (err) { errorToast(err); } }}>{t('v3:deshacer')}</Button></>}
                  </span>
                </div>
                <p className="mt-2 text-sm text-slate-700">{s.shares.map((x) => `${x.employee.name} ${formatCurrency(x.amount)}`).join(' · ')}</p>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
