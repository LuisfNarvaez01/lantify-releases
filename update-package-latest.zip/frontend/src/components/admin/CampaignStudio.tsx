// ============================================
// Mi página › Campañas: asistente paso a paso
// ============================================
// 1 Tipo · 2 Productos · 3 Colores · 4 Textos · 5 Vista previa · 6 Publicar o descargar.
// El dibujo es el mismo de la página pública (web/src/lib/campaignRender.ts), así que
// lo que se ve aquí es exactamente lo que se publica y lo que se descarga en video.

import { useEffect, useMemo, useRef, useState } from 'react';
import { ArrowLeft, ArrowRight, Check, Download, Loader2, RotateCcw, Square, RectangleVertical, Image as ImageIcon, CupSoda, Sparkles } from 'lucide-react';
import { t } from '../../i18n';
import { mediaSrc } from '../../shared/media';
import { toast } from '../../shared/toast';
import type { PageCatalogProduct, PageTheme } from '../../services/api';
import { Card, Segmented } from '../ui';
import { CutoutButton } from './PageShowcasePanel';
import {
  normalizeCampaign, campaignDuration, PageCampaign, CampaignFlavor,
  CAMPAIGN_MIN_FLAVORS, CAMPAIGN_MAX_FLAVORS, DEFAULT_STAMP, EXAMPLE_CAMPAIGN, CampaignStyle,
} from '../../../../src/domain/campaign';
import { drawCampaign, loadCampaignImages, recordCampaign, videoMimeType, CampaignFormat } from '../../../../web/src/lib/campaignRender';
import { flavorColor } from '../../../../web/src/lib/flavors';

type Step = 1 | 2 | 3 | 4 | 5 | 6;
const STEPS: Step[] = [1, 2, 3, 4, 5, 6];

// ── Vista previa en vivo (mismo dibujo que la página) ────────
function CampaignCanvas({ campaign, format }: { campaign: PageCampaign; format: CampaignFormat }) {
  const wrap = useRef<HTMLDivElement>(null);
  const canvas = useRef<HTMLCanvasElement>(null);
  const [images, setImages] = useState<(HTMLImageElement | null)[]>([]);
  useEffect(() => {
    let alive = true;
    loadCampaignImages(campaign, (u) => mediaSrc(u) || u, true).then((imgs) => { if (alive) setImages(imgs); });
    return () => { alive = false; };
  }, [campaign]);
  useEffect(() => {
    const el = wrap.current;
    const cv = canvas.current;
    const ctx = cv?.getContext('2d');
    if (!el || !cv || !ctx) return;
    const fit = () => {
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      cv.width = Math.round(el.clientWidth * dpr);
      cv.height = Math.round(el.clientHeight * dpr);
    };
    fit();
    const ro = new ResizeObserver(fit);
    ro.observe(el);
    let raf = 0;
    const start = performance.now();
    const loop = () => {
      drawCampaign(ctx, cv.width, cv.height, campaign, images, (performance.now() - start) / 1000);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => { cancelAnimationFrame(raf); ro.disconnect(); };
  }, [campaign, images]);
  return (
    <div ref={wrap} className={`relative mx-auto w-full overflow-hidden rounded-[22px] shadow-raised ${format === 'story' ? 'aspect-[9/16] max-w-[300px]' : 'aspect-square max-w-[440px]'}`}>
      <canvas ref={canvas} className="absolute inset-0 h-full w-full" role="img" aria-label={t('page:camp_vista_previa')} />
    </div>
  );
}

// ── Asistente ────────────────────────────────────────────────
export function CampaignStudio({ theme, catalog, onTheme }: {
  theme: PageTheme;
  catalog: PageCatalogProduct[];
  onTheme: (theme: PageTheme) => void;
}) {
  const saved = theme.campaign;
  const [step, setStep] = useState<Step>(saved ? 5 : 1);
  const [flavors, setFlavors] = useState<CampaignFlavor[]>(saved?.flavors ?? []);
  const [headline, setHeadline] = useState(saved?.headline ?? t('page:camp_titular_def'));
  const [stamp, setStamp] = useState(saved?.stamp ?? DEFAULT_STAMP);
  const [cta, setCta] = useState(saved?.cta ?? t('page:camp_cta_def'));
  const [onPage, setOnPage] = useState(saved?.onPage ?? true);
  const [style, setStyle] = useState<CampaignStyle>(saved?.style ?? 'photo');
  const [format, setFormat] = useState<CampaignFormat>('square');
  const [recording, setRecording] = useState<number | null>(null);

  // La campaña tal como quedaría guardada (null si aún no alcanza)
  const campaign = useMemo(
    () => normalizeCampaign({ kind: 'flavors', style, headline, stamp, cta, flavors, onPage }),
    [style, headline, stamp, cta, flavors, onPage],
  );

  const withPhoto = useMemo(() => catalog.filter((p) => p.visible), [catalog]);
  const selectedIds = flavors.map((f) => f.itemId);
  const toggle = (p: PageCatalogProduct) => {
    if (selectedIds.includes(p.id)) { setFlavors(flavors.filter((f) => f.itemId !== p.id)); return; }
    if (flavors.length >= CAMPAIGN_MAX_FLAVORS) { toast.warning(t('page:camp_max', { n: CAMPAIGN_MAX_FLAVORS })); return; }
    setFlavors([...flavors, { name: p.name, image: p.imageUrl, color: flavorColor(p.name, flavors.length), itemId: p.id }]);
  };
  const patch = (i: number, v: Partial<CampaignFlavor>) => setFlavors(flavors.map((f, k) => (k === i ? { ...f, ...v } : f)));

  const canNext = step !== 2 || flavors.length >= CAMPAIGN_MIN_FLAVORS;
  const save = (next: Partial<{ onPage: boolean }> = {}) => {
    const c = normalizeCampaign({ kind: 'flavors', style, headline, stamp, cta, flavors, onPage, ...next });
    onTheme({ ...theme, campaign: c });
    return c;
  };
  // El ejemplo de la casa: tres sabores en lata, listo para ver y adaptar
  const useExample = () => {
    setStyle(EXAMPLE_CAMPAIGN.style);
    setFlavors(EXAMPLE_CAMPAIGN.flavors.map((f) => ({ ...f })));
    setHeadline(EXAMPLE_CAMPAIGN.headline || '');
    setStamp(EXAMPLE_CAMPAIGN.stamp);
    setCta(EXAMPLE_CAMPAIGN.cta || '');
    setStep(5);
  };
  const remove = () => {
    onTheme({ ...theme, campaign: null });
    setFlavors([]);
    setStep(1);
    toast.success(t('page:camp_quitada'));
  };

  const download = async () => {
    if (!campaign) return;
    if (!videoMimeType()) { toast.error(t('page:camp_sin_video')); return; }
    setRecording(0);
    try {
      const images = await loadCampaignImages(campaign, (u) => mediaSrc(u) || u, true);
      // Dos vueltas: queda de 10 a 26 segundos, buen largo para historias y reels
      const { blob, ext } = await recordCampaign(campaign, images, format, campaignDuration(campaign) * 2, setRecording);
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `campana-${format === 'story' ? 'historia' : 'cuadrado'}.${ext}`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 4000);
      toast.success(ext === 'mp4' ? t('page:camp_video_listo') : t('page:camp_video_webm'));
    } catch (e) {
      toast.error((e as Error)?.name === 'SecurityError' ? t('page:camp_foto_bloqueada') : t('page:camp_sin_video'));
    } finally {
      setRecording(null);
    }
  };

  const STEP_LABEL: Record<Step, string> = {
    1: t('page:camp_p1'), 2: t('page:camp_p2'), 3: t('page:camp_p3'), 4: t('page:camp_p4'), 5: t('page:camp_p5'), 6: t('page:camp_p6'),
  };
  const field = 'mt-1 block h-11 w-full rounded-[10px] border border-slate-200 bg-white px-3 text-sm text-slate-900 focus:border-blue-600 focus:outline-none';

  return (
    <div className="space-y-5">
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-xl font-semibold tracking-tight text-slate-950">{t('page:camp_titulo')}</h2>
          <p className="mt-1 max-w-2xl text-sm text-slate-500">{t('page:camp_bajada')}</p>
        </div>
        {saved && (
          <button type="button" onClick={remove} className="inline-flex h-9 items-center gap-1.5 rounded-full px-3 text-sm text-slate-600 hover:bg-rose-50 hover:text-rose-700">
            <RotateCcw className="h-4 w-4" aria-hidden /> {t('page:camp_quitar')}
          </button>
        )}
      </header>

      {/* Pasos */}
      <ol className="flex flex-wrap gap-2">
        {STEPS.map((s) => {
          const done = s < step;
          const reachable = s <= step || (s <= 6 && flavors.length >= CAMPAIGN_MIN_FLAVORS);
          return (
            <li key={s}>
              <button
                type="button"
                disabled={!reachable}
                onClick={() => setStep(s)}
                aria-current={s === step ? 'step' : undefined}
                className={`inline-flex h-9 items-center gap-2 rounded-full px-3.5 text-sm font-medium transition-colors duration-fast disabled:opacity-40 ${
                  s === step ? 'bg-slate-950 text-white' : done ? 'bg-white text-slate-900 shadow-card' : 'bg-slate-100 text-slate-500'
                }`}
              >
                <span className={`grid h-5 w-5 place-items-center rounded-full text-[0.7rem] num ${s === step ? 'bg-white/15' : done ? 'bg-blue-600 text-white' : 'bg-white'}`}>
                  {done ? <Check className="h-3 w-3" aria-hidden /> : s}
                </span>
                {STEP_LABEL[s]}
              </button>
            </li>
          );
        })}
      </ol>

      <div className="grid gap-5 lg:grid-cols-[1fr_440px]">
        <Card large className="lt-enter min-h-[420px]" key={step}>
          {step === 1 && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">{t('page:camp_p1_titulo')}</h3>
              <button type="button" className="w-full rounded-[14px] bg-slate-950 p-5 text-left text-white ring-2 ring-blue-600 ring-offset-2" aria-pressed>
                <p className="text-base font-semibold">{t('page:camp_sabores')}</p>
                <p className="mt-1 text-sm text-white/70">{t('page:camp_sabores_desc')}</p>
              </button>
              <p className="text-sm text-slate-500">{t('page:camp_p1_nota')}</p>
              <div className="rounded-[14px] bg-slate-50 p-4 ring-1 ring-inset ring-slate-200/70">
                <p className="text-sm font-semibold text-slate-900">{t('page:camp_ejemplo_titulo')}</p>
                <p className="mt-1 text-sm italic text-slate-600">“{t('page:camp_ejemplo_prompt')}”</p>
                <button type="button" onClick={useExample} className="mt-3 inline-flex h-10 items-center gap-2 rounded-[10px] bg-blue-600 px-4 text-sm font-medium text-white hover:bg-blue-700">
                  <Sparkles className="h-4 w-4" aria-hidden /> {t('page:camp_usar_ejemplo')}
                </button>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <h3 className="text-lg font-semibold">{t('page:camp_p2_titulo')}</h3>
                <span className="text-sm text-slate-500 num">{t('page:camp_elegidos', { n: flavors.length, max: CAMPAIGN_MAX_FLAVORS })}</span>
              </div>
              <p className="text-sm text-slate-500">{t('page:camp_p2_nota')}</p>
              <ul className="grid max-h-[420px] gap-2 overflow-y-auto pr-1 [grid-template-columns:repeat(auto-fill,minmax(10rem,1fr))]">
                {withPhoto.map((p) => {
                  const pos = selectedIds.indexOf(p.id);
                  const on = pos >= 0;
                  return (
                    <li key={p.id}>
                      <button type="button" onClick={() => toggle(p)} aria-pressed={on}
                        className={`relative flex w-full items-center gap-2.5 rounded-[12px] bg-white p-2 text-left shadow-card transition-shadow duration-fast hover:shadow-raised ${on ? 'ring-2 ring-blue-600' : ''}`}>
                        {p.imageUrl
                          ? <img src={mediaSrc(p.imageUrl)} alt="" className="h-10 w-10 shrink-0 rounded-lg object-cover" />
                          : <span aria-hidden className="h-10 w-10 shrink-0 rounded-lg" style={{ background: flavorColor(p.name) }} />}
                        <span className="line-clamp-2 text-sm font-medium leading-snug">{p.name}</span>
                        {on && <span className="absolute -right-1.5 -top-1.5 grid h-6 w-6 place-items-center rounded-full bg-blue-600 text-xs font-semibold text-white num">{pos + 1}</span>}
                      </button>
                    </li>
                  );
                })}
              </ul>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">{t('page:camp_p3_titulo')}</h3>
              <Segmented
                value={style}
                onChange={setStyle}
                ariaLabel={t('page:camp_estilo')}
                options={[
                  { id: 'photo', label: t('page:camp_estilo_foto'), icon: <ImageIcon className="h-4 w-4" aria-hidden /> },
                  { id: 'can', label: t('page:camp_estilo_lata'), icon: <CupSoda className="h-4 w-4" aria-hidden /> },
                ]}
              />
              <p className="text-sm text-slate-500">{style === 'can' ? t('page:camp_lata_nota') : t('page:camp_p3_nota')}</p>
              <ul className="space-y-3">
                {flavors.map((f, i) => (
                  <li key={`${f.itemId}-${i}`} className="flex flex-wrap items-center gap-3 rounded-[12px] bg-slate-50 p-3">
                    <label className="relative h-11 w-11 shrink-0 cursor-pointer overflow-hidden rounded-full ring-1 ring-black/10" style={{ background: f.color }} title={t('page:camp_cambiar_color')}>
                      <input type="color" value={f.color} onChange={(e) => patch(i, { color: e.target.value.toUpperCase() })} className="absolute inset-0 cursor-pointer opacity-0" aria-label={t('page:camp_color_de', { name: f.name })} />
                    </label>
                    <input value={f.name} maxLength={40} onChange={(e) => patch(i, { name: e.target.value })} className={`${field} mt-0 min-w-[10rem] flex-1`} aria-label={t('page:camp_nombre_sabor')} />
                    {style === 'photo' && f.image && <img src={mediaSrc(f.image)} alt="" className="h-11 w-11 rounded-lg object-cover" />}
                    {style === 'photo' && <CutoutButton
                      label={t('page:camp_foto_sin_fondo')}
                      maxSide={900}
                      onUploaded={(url) => patch(i, { image: url })}
                      className="inline-flex h-11 items-center gap-1.5 rounded-[10px] px-3 text-sm font-medium text-slate-700 ring-1 ring-inset ring-slate-200 hover:bg-white"
                    />}
                    <button type="button" onClick={() => patch(i, { color: flavorColor(f.name, i) })} className="h-11 rounded-[10px] px-3 text-sm text-slate-500 hover:bg-white">{t('page:camp_sugerido')}</button>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {step === 4 && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">{t('page:camp_p4_titulo')}</h3>
              <label className="block text-sm font-medium text-slate-700">{t('page:camp_titular')}
                <input value={headline} maxLength={60} onChange={(e) => setHeadline(e.target.value)} className={field} />
              </label>
              <label className="block text-sm font-medium text-slate-700">{t('page:camp_sello')}
                <input value={stamp} maxLength={40} onChange={(e) => setStamp(e.target.value.toUpperCase())} className={field} />
              </label>
              <label className="block text-sm font-medium text-slate-700">{t('page:camp_cta')}
                <input value={cta} maxLength={30} onChange={(e) => setCta(e.target.value)} className={field} />
              </label>
              <p className="text-xs text-slate-500">{t('page:camp_p4_nota')}</p>
            </div>
          )}

          {step === 5 && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">{t('page:camp_p5_titulo')}</h3>
              <p className="text-sm text-slate-500">{t('page:camp_p5_nota', { s: campaign ? Math.round(campaignDuration(campaign)) : 0 })}</p>
              <Segmented
                value={format}
                onChange={setFormat}
                ariaLabel={t('page:camp_formato')}
                options={[
                  { id: 'square', label: t('page:camp_cuadrado'), icon: <Square className="h-4 w-4" aria-hidden /> },
                  { id: 'story', label: t('page:camp_historia'), icon: <RectangleVertical className="h-4 w-4" aria-hidden /> },
                ]}
              />
            </div>
          )}

          {step === 6 && (
            <div className="space-y-5">
              <h3 className="text-lg font-semibold">{t('page:camp_p6_titulo')}</h3>
              <label className="flex cursor-pointer items-start gap-3 rounded-[12px] bg-slate-50 p-4">
                <input type="checkbox" checked={onPage} onChange={(e) => setOnPage(e.target.checked)} className="mt-1 h-5 w-5 accent-blue-600" />
                <span>
                  <span className="block font-medium text-slate-900">{t('page:camp_en_portada')}</span>
                  <span className="block text-sm text-slate-500">{t('page:camp_en_portada_desc')}</span>
                </span>
              </label>
              <div className="flex flex-wrap gap-2">
                <button type="button" disabled={!campaign} onClick={() => { save(); toast.success(t('page:camp_guardada')); }}
                  className="inline-flex h-11 items-center gap-2 rounded-[10px] bg-blue-600 px-4 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-50">
                  <Check className="h-4 w-4" aria-hidden /> {t('page:camp_guardar')}
                </button>
                <button type="button" disabled={!campaign || recording !== null} onClick={download}
                  className="inline-flex h-11 items-center gap-2 rounded-[10px] bg-slate-950 px-4 text-sm font-medium text-white hover:bg-slate-800 disabled:opacity-50">
                  {recording !== null ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <Download className="h-4 w-4" aria-hidden />}
                  {recording !== null ? t('page:camp_grabando', { pct: Math.round(recording * 100) }) : t('page:camp_descargar', { formato: format === 'story' ? t('page:camp_historia') : t('page:camp_cuadrado') })}
                </button>
              </div>
              <p className="text-xs text-slate-500">{t('page:camp_p6_nota')}</p>
            </div>
          )}

          {/* Navegación */}
          <div className="mt-6 flex items-center justify-between border-t border-slate-100 pt-4">
            <button type="button" disabled={step === 1} onClick={() => setStep((s) => (s - 1) as Step)}
              className="inline-flex h-10 items-center gap-1.5 rounded-[10px] px-3 text-sm font-medium text-slate-600 hover:bg-slate-100 disabled:opacity-30">
              <ArrowLeft className="h-4 w-4" aria-hidden /> {t('page:camp_atras')}
            </button>
            {step < 6 && (
              <button type="button" disabled={!canNext} onClick={() => setStep((s) => (s + 1) as Step)}
                className="inline-flex h-10 items-center gap-1.5 rounded-[10px] bg-slate-950 px-4 text-sm font-medium text-white hover:bg-slate-800 disabled:opacity-40">
                {t('page:camp_siguiente')} <ArrowRight className="h-4 w-4" aria-hidden />
              </button>
            )}
          </div>
          {step === 2 && !canNext && <p className="mt-2 text-right text-xs text-slate-500">{t('page:camp_min', { n: CAMPAIGN_MIN_FLAVORS })}</p>}
        </Card>

        {/* Vista previa siempre visible desde que hay sabores */}
        <div className="lg:sticky lg:top-4 lg:self-start">
          {campaign ? <CampaignCanvas campaign={campaign} format={format} /> : (
            <div className="grid aspect-square w-full place-items-center rounded-[22px] bg-slate-100 p-8 text-center text-sm text-slate-500">
              {t('page:camp_elige_para_ver', { n: CAMPAIGN_MIN_FLAVORS })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default CampaignStudio;
