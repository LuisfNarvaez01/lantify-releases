// ============================================
// ADMIN - Productos → Precios por horario (Fase 4 · 7)
// ============================================
// Happy hour y promociones por días y horas. Cada regla baja el precio de toda la
// carta, de unas categorías o de unos productos: un porcentaje o un precio especial.
// La caja, el celular y la página lo muestran solos; el servidor lo revisa al cobrar.

import React, { useEffect, useMemo, useState } from 'react';
import { Clock, Pencil, Plus, Trash2 } from 'lucide-react';
import { t, getLanguage } from '../../i18n';
import { toast } from '../../shared/toast';
import { confirmDialog } from '../../shared/dialog';
import { formatCurrency } from '../../shared/formatUtils';
import { productsAPI } from '../../services/api';
import { priceRulesAPI } from '../../services/v3Api';
import { usePriceRules } from '../../shared/priceRules';
import { useFeatureFlag } from '../../shared/features';
import { Button } from '../common/Button';
import { FeaturesPanel } from './FeaturesPanel';
import { appliesTo, daysLabel, hourLabel, isRuleActive, rulePrice, type PriceRule } from '../../../../src/domain/priceRules';
import type { Product } from '../../types';

type Draft = Omit<PriceRule, 'id'> & { id?: string };

const EMPTY: Draft = { name: 'Happy hour', weekdays: 0b0111110, start: '17:00', end: '19:00', scope: { categoryIds: [], variantIds: [] }, kind: 'PERCENT', value: 20, active: true };
const DAYS = [1, 2, 3, 4, 5, 6, 0];
const DAY_ES = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
const DAY_EN = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

const field = 'rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 min-h-[44px] focus:outline-none focus:ring-2 focus:ring-blue-500/40';
const card = 'bg-white rounded-3xl shadow-sm p-6 sm:p-8 border border-slate-200/80';

export const PriceRulesPanel: React.FC = () => {
  const on = useFeatureFlag('price_rules');
  const lang = getLanguage() === 'en' ? 'en' : 'es';
  const [rules, setRules] = useState<PriceRule[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [busy, setBusy] = useState(false);
  const [scopeMode, setScopeMode] = useState<'all' | 'categories' | 'products'>('all');

  const load = async () => {
    try { setRules(await priceRulesAPI.list()); } catch { /* sin plan o sin conexión */ }
  };
  useEffect(() => {
    load();
    productsAPI.getAll().then((p: Product[]) => setProducts(Array.isArray(p) ? p.filter((x) => x.isActive) : [])).catch(() => undefined);
  }, []);

  const categories = useMemo(() => {
    const m = new Map<string, string>();
    for (const p of products) if (p.category?.id) m.set(p.category.id, p.category.name);
    return [...m.entries()].map(([id, name]) => ({ id, name })).sort((a, b) => a.name.localeCompare(b.name));
  }, [products]);

  const variants = useMemo(() => products.flatMap((p) => p.variants.filter((v) => v.isActive !== false).map((v) => ({
    id: v.id, price: v.price, categoryId: p.categoryId || p.category?.id || null,
    label: p.variants.length > 1 ? `${p.name} · ${v.name}` : p.name,
  }))), [products]);

  const open = (rule?: PriceRule) => {
    const d = rule ? { ...rule } : { ...EMPTY, scope: { categoryIds: [], variantIds: [] } };
    setScopeMode(d.scope.variantIds.length ? 'products' : d.scope.categoryIds.length ? 'categories' : 'all');
    setDraft(d);
  };

  const save = async () => {
    if (!draft) return;
    const scope = scopeMode === 'all' ? { categoryIds: [], variantIds: [] }
      : scopeMode === 'categories' ? { categoryIds: draft.scope.categoryIds, variantIds: [] }
        : { categoryIds: [], variantIds: draft.scope.variantIds };
    const { id, ...body } = { ...draft, scope };
    setBusy(true);
    try {
      if (id) await priceRulesAPI.update(id, body);
      else await priceRulesAPI.create(body);
      toast.success(t('products:pr_guardada'));
      setDraft(null);
      await load();
      usePriceRules.getState().load(true);
    } catch (e: any) {
      toast.error(e?.message || t('v3:no_se_guardo'));
    } finally {
      setBusy(false);
    }
  };

  const toggle = async (rule: PriceRule) => {
    const { id, ...body } = rule;
    try {
      await priceRulesAPI.update(id, { ...body, active: !rule.active });
      await load();
      usePriceRules.getState().load(true);
    } catch (e: any) {
      toast.error(e?.message || t('v3:no_se_guardo'));
    }
  };

  const remove = async (rule: PriceRule) => {
    if (!(await confirmDialog({ title: t('products:pr_borrar'), message: t('products:pr_borrar_confirma', { name: rule.name }), tone: 'danger' }))) return;
    try {
      await priceRulesAPI.remove(rule.id);
      toast.success(t('products:pr_borrada'));
      await load();
      usePriceRules.getState().load(true);
    } catch (e: any) {
      toast.error(e?.message || t('v3:no_se_guardo'));
    }
  };

  const describe = (r: Pick<PriceRule, 'kind' | 'value'>) => (r.kind === 'PERCENT' ? t('products:pr_desc_pct', { value: r.value }) : t('products:pr_desc_fijo', { price: formatCurrency(r.value) }));

  // Vista previa: hasta 8 productos con el precio que quedaría
  const preview = useMemo(() => {
    if (!draft) return [];
    const scope = scopeMode === 'all' ? { categoryIds: [], variantIds: [] } : scopeMode === 'categories' ? { categoryIds: draft.scope.categoryIds, variantIds: [] } : { categoryIds: [], variantIds: draft.scope.variantIds };
    if (scopeMode !== 'all' && !scope.categoryIds.length && !scope.variantIds.length) return [];
    const rule = { ...draft, id: 'preview', scope } as PriceRule;
    return variants.filter((v) => appliesTo(rule, v.id, v.categoryId)).slice(0, 8).map((v) => ({ ...v, after: rulePrice(rule, v.price) }));
  }, [draft, scopeMode, variants]);

  const toggleIn = (list: string[], id: string) => (list.includes(id) ? list.filter((x) => x !== id) : [...list, id]);
  const names = lang === 'en' ? DAY_EN : DAY_ES;

  return (
    <div className="space-y-6">
      <FeaturesPanel place="products" />
      <section className={card} aria-labelledby="pr-title">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h3 id="pr-title" className="text-base font-semibold text-slate-900">{t('products:pr_titulo')}</h3>
            <p className="mt-1 text-sm text-slate-500">{t('products:pr_sub')}</p>
          </div>
          {!draft && <Button onClick={() => open()}><Plus className="w-4 h-4" aria-hidden /> {t('products:pr_nueva')}</Button>}
        </div>
        {!on && <p className="mt-4 rounded-xl bg-amber-50 px-3 py-2 text-sm text-amber-800">{t('products:pr_apagada')}</p>}

        {draft && (
          <div className="mt-5 space-y-4 rounded-2xl border border-slate-200 bg-slate-50 p-4">
            <div className="grid gap-3 sm:grid-cols-2">
              <label className="block text-sm font-semibold text-slate-700">{t('products:pr_nombre')}
                <input className={`${field} mt-1 w-full`} value={draft.name} maxLength={40} placeholder={t('products:pr_nombre_ph')} onChange={(e) => setDraft({ ...draft, name: e.target.value })} />
              </label>
              <div className="grid grid-cols-2 gap-3">
                <label className="block text-sm font-semibold text-slate-700">{t('products:pr_desde')}
                  <input type="time" className={`${field} mt-1 w-full`} value={draft.start} onChange={(e) => setDraft({ ...draft, start: e.target.value })} />
                </label>
                <label className="block text-sm font-semibold text-slate-700">{t('products:pr_hasta')}
                  <input type="time" className={`${field} mt-1 w-full`} value={draft.end} onChange={(e) => setDraft({ ...draft, end: e.target.value })} />
                </label>
              </div>
            </div>
            {draft.end < draft.start && <p className="text-xs text-slate-500">{t('products:pr_cruza')}</p>}
            <fieldset>
              <legend className="text-sm font-semibold text-slate-700">{t('products:pr_dias')}</legend>
              <div className="mt-1 flex flex-wrap gap-1.5">
                {DAYS.map((d) => {
                  const active = ((draft.weekdays >> d) & 1) === 1;
                  return (
                    <button key={d} type="button" aria-pressed={active} onClick={() => setDraft({ ...draft, weekdays: draft.weekdays ^ (1 << d) })}
                      className={`min-h-[44px] min-w-[52px] rounded-xl border px-3 text-sm font-semibold ${active ? 'border-blue-600 bg-blue-600 text-white' : 'border-slate-300 bg-white text-slate-700'}`}>
                      {names[d]}
                    </button>
                  );
                })}
              </div>
            </fieldset>
            <div className="grid gap-3 sm:grid-cols-2">
              <label className="block text-sm font-semibold text-slate-700">{t('products:pr_tipo')}
                <select className={`${field} mt-1 w-full`} value={draft.kind} onChange={(e) => setDraft({ ...draft, kind: e.target.value as PriceRule['kind'] })}>
                  <option value="PERCENT">{t('products:pr_porcentaje')}</option>
                  <option value="FIXED">{t('products:pr_fijo')}</option>
                </select>
              </label>
              <label className="block text-sm font-semibold text-slate-700">{t('products:pr_valor')}
                <input type="number" min={1} className={`${field} mt-1 w-full`} value={draft.value} onChange={(e) => setDraft({ ...draft, value: Number(e.target.value) || 0 })} />
              </label>
            </div>
            <fieldset>
              <legend className="text-sm font-semibold text-slate-700">{t('products:pr_alcance')}</legend>
              <div className="mt-1 flex flex-wrap gap-1.5">
                {(['all', 'categories', 'products'] as const).map((m) => (
                  <button key={m} type="button" aria-pressed={scopeMode === m} onClick={() => setScopeMode(m)}
                    className={`min-h-[44px] rounded-xl border px-3 text-sm font-semibold ${scopeMode === m ? 'border-blue-600 bg-blue-600 text-white' : 'border-slate-300 bg-white text-slate-700'}`}>
                    {t(m === 'all' ? 'products:pr_toda_carta' : m === 'categories' ? 'products:pr_categorias' : 'products:pr_productos')}
                  </button>
                ))}
              </div>
              {scopeMode === 'categories' && (
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {categories.map((c) => (
                    <label key={c.id} className="inline-flex min-h-[40px] items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 text-sm">
                      <input type="checkbox" className="h-4 w-4 accent-blue-600" checked={draft.scope.categoryIds.includes(c.id)} onChange={() => setDraft({ ...draft, scope: { ...draft.scope, categoryIds: toggleIn(draft.scope.categoryIds, c.id) } })} />
                      {c.name}
                    </label>
                  ))}
                </div>
              )}
              {scopeMode === 'products' && (
                <div className="mt-2 max-h-56 overflow-y-auto rounded-xl border border-slate-200 bg-white p-2">
                  {variants.map((v) => (
                    <label key={v.id} className="flex min-h-[40px] items-center gap-2 px-2 text-sm">
                      <input type="checkbox" className="h-4 w-4 accent-blue-600" checked={draft.scope.variantIds.includes(v.id)} onChange={() => setDraft({ ...draft, scope: { ...draft.scope, variantIds: toggleIn(draft.scope.variantIds, v.id) } })} />
                      <span className="flex-1">{v.label}</span>
                      <span className="tabular-nums text-slate-500">{formatCurrency(v.price)}</span>
                    </label>
                  ))}
                </div>
              )}
            </fieldset>
            <div>
              <p className="text-sm font-semibold text-slate-700">{t('products:pr_vista_previa')}</p>
              {preview.length ? (
                <ul className="mt-1 divide-y divide-slate-200 rounded-xl border border-slate-200 bg-white">
                  {preview.map((v) => (
                    <li key={v.id} className="flex items-center justify-between gap-3 px-3 py-2 text-sm">
                      <span className="truncate">{v.label}</span>
                      <span className="tabular-nums"><s className="mr-2 text-slate-400">{formatCurrency(v.price)}</s><b>{formatCurrency(v.after)}</b></span>
                    </li>
                  ))}
                </ul>
              ) : <p className="mt-1 text-sm text-slate-500">{t('products:pr_vista_vacia')}</p>}
            </div>
            <div className="flex gap-2">
              <Button onClick={save} disabled={busy}>{t('products:pr_guardar')}</Button>
              <Button variant="secondary" onClick={() => setDraft(null)}>{t('products:pr_cancelar')}</Button>
            </div>
          </div>
        )}

        <ul className="mt-5 space-y-2">
          {!rules.length && !draft && <li className="text-sm text-slate-500">{t('products:pr_vacio')}</li>}
          {rules.map((r) => {
            const live = isRuleActive(r, new Date());
            return (
              <li key={r.id} className="flex flex-wrap items-center gap-3 rounded-2xl border border-slate-200 p-3">
                <Clock className="h-5 w-5 text-slate-400" aria-hidden />
                <div className="min-w-0 flex-1">
                  <p className="font-semibold text-slate-900">{r.name} <span className="font-normal text-slate-500">· {describe(r)}</span></p>
                  <p className="text-xs text-slate-500">{daysLabel(r.weekdays, lang)} · {hourLabel(r.start, lang)} – {hourLabel(r.end, lang)}</p>
                </div>
                {live && on && <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-xs font-bold text-emerald-800">{t('products:pr_vigente')}</span>}
                {!r.active && <span className="rounded-full bg-slate-100 px-2 py-0.5 text-xs font-bold text-slate-600">{t('products:pr_pausada')}</span>}
                <button type="button" onClick={() => toggle(r)} className="min-h-[44px] rounded-xl px-3 text-sm font-semibold text-slate-700 hover:bg-slate-100">{r.active ? t('products:pr_pausar') : t('products:pr_activar')}</button>
                <button type="button" onClick={() => open(r)} aria-label={t('products:pr_editar')} className="inline-flex h-11 w-11 items-center justify-center rounded-xl text-slate-600 hover:bg-slate-100"><Pencil className="h-4 w-4" aria-hidden /></button>
                <button type="button" onClick={() => remove(r)} aria-label={t('products:pr_borrar')} className="inline-flex h-11 w-11 items-center justify-center rounded-xl text-rose-600 hover:bg-rose-50"><Trash2 className="h-4 w-4" aria-hidden /></button>
              </li>
            );
          })}
        </ul>
      </section>
    </div>
  );
};

export default PriceRulesPanel;
