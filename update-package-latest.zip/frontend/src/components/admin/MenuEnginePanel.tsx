// ============================================
// ADMIN - Motor de menú (Lantify 3.0 · bloque 4)
// ============================================
// Ingeniería de menú con las ventas de los últimos 60 días: qué cuidar, qué
// subir de precio, qué empujar y qué revisar, con el porqué de cada uno.

import React, { useEffect, useMemo, useState } from 'react';
import { Gem, HelpCircle, Loader2, RefreshCw, Star, Tractor, TrendingDown, TrendingUp, XCircle } from 'lucide-react';
import { menuAPI } from '../../services/v3Api';
import { errorMessage } from '../../services/apiErrors';
import { formatCurrency } from '../../shared/formatUtils';
import { useFeature } from '../../shared/plan';
import { PlanLocked } from '../common/PlanLocked';
import { t } from '../../i18n';
import type { MenuClass, MenuReading } from '../../../../src/domain/v3/menuEngine';

const CLASSES: { id: MenuClass; icon: typeof Star; tone: string }[] = [
  { id: 'STAR', icon: Star, tone: 'bg-emerald-50 text-emerald-800 border-emerald-200' },
  { id: 'PLOWHORSE', icon: Tractor, tone: 'bg-blue-50 text-blue-800 border-blue-200' },
  { id: 'PUZZLE', icon: Gem, tone: 'bg-violet-50 text-violet-800 border-violet-200' },
  { id: 'DOG', icon: XCircle, tone: 'bg-rose-50 text-rose-800 border-rose-200' },
  { id: 'NO_COST', icon: HelpCircle, tone: 'bg-slate-50 text-slate-700 border-slate-200' },
];

export const MenuEnginePanel: React.FC = () => {
  const allowed = useFeature('autopilot');
  const [data, setData] = useState<MenuReading | null>(null);
  const [error, setError] = useState('');
  const [filter, setFilter] = useState<MenuClass | 'ALL'>('ALL');
  const [busy, setBusy] = useState(false);

  const load = async (fresh = false) => {
    setBusy(true);
    try { setData(await menuAPI.reading(fresh)); setError(''); } catch (e) { setError(errorMessage(e)); } finally { setBusy(false); }
  };
  useEffect(() => { if (allowed) load(); }, [allowed]);

  const counts = useMemo(() => Object.fromEntries(CLASSES.map((c) => [c.id, data?.items.filter((i) => i.klass === c.id).length || 0])), [data]);
  const names = useMemo(() => new Map((data?.items || []).map((i) => [i.productId, i.name])), [data]);
  if (!allowed) return <PlanLocked feature="autopilot" />;

  const items = (data?.items || []).filter((i) => filter === 'ALL' || i.klass === filter);
  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-slate-900 font-heading">{t('v3:me_titulo')}</h2>
          <p className="mt-1 max-w-2xl text-sm text-slate-500">{t('v3:me_desc', { sales: data?.sales ?? 0 })}</p>
        </div>
        <button type="button" onClick={() => load(true)} disabled={busy} className="inline-flex min-h-[40px] items-center gap-2 rounded-xl border border-slate-300 bg-white px-3 text-sm font-bold text-slate-700 hover:bg-slate-50 disabled:opacity-60">
          {busy ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <RefreshCw className="h-4 w-4" aria-hidden />}{t('v3:me_actualizar')}
        </button>
      </div>
      {error && <p role="alert" className="rounded-xl bg-rose-50 p-3 text-sm text-rose-800">{error}</p>}

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5" role="tablist" aria-label={t('v3:me_clases')}>
        {CLASSES.map(({ id, icon: Icon, tone }) => (
          <button key={id} type="button" role="tab" aria-selected={filter === id} onClick={() => setFilter(filter === id ? 'ALL' : id)} className={`rounded-2xl border p-4 text-left transition ${tone} ${filter === id ? 'ring-2 ring-slate-900' : ''}`}>
            <span className="flex items-center justify-between"><Icon className="h-5 w-5" aria-hidden /><span className="text-2xl font-black tabular-nums">{counts[id]}</span></span>
            <span className="mt-2 block font-bold">{t(`v3:me_${id}`)}</span>
            <span className="block text-xs opacity-80">{t(`v3:me_${id}_d`)}</span>
          </button>
        ))}
      </div>

      <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-left text-xs font-bold uppercase tracking-wide text-slate-500">
            <tr>
              <th className="px-4 py-3">{t('v3:me_producto')}</th>
              <th className="px-4 py-3 text-right">{t('v3:me_unidades')}</th>
              <th className="px-4 py-3 text-right">{t('v3:me_margen')}</th>
              <th className="px-4 py-3 text-right">{t('v3:me_tendencia')}</th>
              <th className="px-4 py-3">{t('v3:me_que_hacer')}</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {items.map((i) => {
              const pair = data?.pairings.find((p) => p.a === i.productId);
              return (
                <tr key={i.productId}>
                  <td className="px-4 py-3">
                    <span className="font-semibold text-slate-900">{i.name}</span>
                    <span className="block text-xs text-slate-500">{t(`v3:me_${i.klass}`)}{i.prepMedian !== null ? ` · ${t('v3:me_prep', { min: Math.round(i.prepMedian) })}` : ''}{pair ? ` · ${t('v3:me_pareja', { name: names.get(pair.b), pct: Math.round(pair.confidence * 100) })}` : ''}</span>
                  </td>
                  <td className="px-4 py-3 text-right tabular-nums">{i.units}</td>
                  <td className="px-4 py-3 text-right tabular-nums">{i.unitMargin !== null ? <>{formatCurrency(i.unitMargin)}<span className="block text-xs text-slate-500">{i.marginPct} %</span></> : '—'}</td>
                  <td className="px-4 py-3 text-right tabular-nums">
                    {i.trendPct === null ? '—' : <span className={`inline-flex items-center gap-1 font-bold ${i.trendPct >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>{i.trendPct >= 0 ? <TrendingUp className="h-4 w-4" aria-hidden /> : <TrendingDown className="h-4 w-4" aria-hidden />}{i.trendPct > 0 ? '+' : ''}{i.trendPct} %</span>}
                  </td>
                  <td className="px-4 py-3 text-slate-700">{t(`v3:me_accion_${i.klass}`)}</td>
                </tr>
              );
            })}
            {items.length === 0 && <tr><td colSpan={5} className="px-4 py-10 text-center text-slate-500">{data ? t('v3:me_vacio') : <Loader2 className="mx-auto h-5 w-5 animate-spin" aria-label={t('v3:cargando')} />}</td></tr>}
          </tbody>
        </table>
      </div>
      <p className="text-xs text-slate-500">{t('v3:me_nota')}</p>
    </div>
  );
};
