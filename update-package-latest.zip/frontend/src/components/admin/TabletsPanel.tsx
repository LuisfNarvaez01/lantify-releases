// ============================================
// ADMIN - Conectar tablets y celulares de los meseros
// ============================================
// Muestra la dirección actual de este equipo en la red y un código QR para
// abrirla con la cámara. Si el router le cambia la IP, basta volver a escanear:
// no hace falta configurar nada en el router.

import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { Copy, RefreshCw, Smartphone, WifiOff } from 'lucide-react';
import { t } from '../../i18n';
import { toast } from '../../shared/toast';
import { copyText } from '../../shared/browser';
import { DevicesInfo, permissionsAPI } from '../../services/api';

export const TabletsPanel: React.FC = () => {
  const [info, setInfo] = useState<DevicesInfo | null>(null);
  const [selected, setSelected] = useState(0);
  const [qr, setQr] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const refresh = async () => {
    setLoading(true);
    try {
      setInfo(await permissionsAPI.devices());
      setSelected(0);
    } catch {
      setInfo(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { refresh(); }, []);

  const url = info?.lanEnabled ? info.urls[selected] : undefined;

  useEffect(() => {
    if (!url) { setQr(null); return; }
    QRCode.toDataURL(url, { margin: 1, width: 360, errorCorrectionLevel: 'M' }).then(setQr).catch(() => setQr(null));
  }, [url]);

  const copy = async () => {
    if (!url) return;
    try {
      await copyText(url);
      toast.success(t('roles:tablet_copiado'));
    } catch {
      // el texto sigue visible para copiarlo a mano
    }
  };

  return (
    <section className="bg-white rounded-3xl border border-slate-200 shadow-sm p-5" aria-labelledby="tablets-title">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 id="tablets-title" className="font-bold text-slate-900 text-base flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-blue-600" />
            {t('roles:tablet_titulo')}
          </h3>
          <p className="text-xs text-slate-500 mt-1 max-w-xl">{t('roles:tablet_subtitulo')}</p>
        </div>
        <button
          type="button"
          onClick={refresh}
          disabled={loading}
          className="p-2 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-xl"
          title={t('roles:tablet_actualizar')}
          aria-label={t('roles:tablet_actualizar')}
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {info && !info.lanEnabled ? (
        <div className="mt-4 p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-sm flex gap-3">
          <WifiOff className="w-5 h-5 shrink-0 mt-0.5" />
          <div>
            <p className="font-bold">{t('roles:tablet_apagado')}</p>
            <p className="text-xs mt-1">{t('roles:tablet_apagado_desc')}</p>
          </div>
        </div>
      ) : info && info.urls.length === 0 ? (
        <div className="mt-4 p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-sm flex gap-3">
          <WifiOff className="w-5 h-5 shrink-0 mt-0.5" />
          <p>{t('roles:tablet_sin_red')}</p>
        </div>
      ) : url ? (
        <div className="mt-4 flex flex-col sm:flex-row gap-5 items-center sm:items-start">
          {qr && <img src={qr} alt={t('roles:tablet_qr_alt')} className="w-44 h-44 rounded-2xl border border-slate-200 bg-white p-2" />}
          <div className="flex-1 min-w-0 space-y-3 w-full">
            <ol className="text-sm text-slate-700 space-y-1.5 list-decimal pl-5">
              <li>{t('roles:tablet_paso1')}</li>
              <li>{t('roles:tablet_paso2')}</li>
              <li>{t('roles:tablet_paso3')}</li>
            </ol>
            <div className="flex items-center gap-2">
              <code className="flex-1 min-w-0 truncate px-3 py-2 rounded-xl bg-slate-100 text-slate-900 font-mono text-sm">{url}</code>
              <button
                type="button"
                onClick={copy}
                className="p-2 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-xl"
                title={t('roles:tablet_copiar')}
                aria-label={t('roles:tablet_copiar')}
              >
                <Copy className="w-4 h-4" />
              </button>
            </div>
            {info && info.urls.length > 1 && (
              <label className="block text-xs text-slate-500">
                {t('roles:tablet_otra_red')}{' '}
                <select
                  value={selected}
                  onChange={(e) => setSelected(Number(e.target.value))}
                  className="ml-1 px-2 py-1 border border-slate-300 rounded-lg bg-white text-slate-800 text-xs"
                >
                  {info.urls.map((u, i) => <option key={u} value={i}>{u}</option>)}
                </select>
              </label>
            )}
            <p className="text-xs text-slate-500">{t('roles:tablet_ip_cambia')}</p>
          </div>
        </div>
      ) : null}
    </section>
  );
};
