// ============================================
// ADMIN - Impresión: impresoras, papel y ticket
// ============================================
// Impresión directa: el ticket sale solo, sin ventanas, en la impresora elegida
// (instalada en Windows o de red por IP). Cada función tiene su impresora: caja
// (recibos y pre-cuentas) y cocina (comandas). La vista previa es el ticket real.

import { useEffect, useMemo, useState } from 'react';
import { Printer, RefreshCw, Loader2, Save, Wifi, Usb, CheckCircle2, AlertTriangle, Zap, MonitorSmartphone, ChefHat, Receipt, ImageOff } from 'lucide-react';
import { printingAPI, InstalledPrinter } from '../../services/api';
import { buildKitchenDoc, buildReceiptDoc, buildTestDoc, sampleReceiptData, TicketContext } from '../../services/ticketBuilder';
import { renderTicketBody, ticketCss } from '../../services/ticketHtml';
import { logoBitmap } from '../../services/printService';
import { usePrintSettings, PrintSettings, PrinterTarget } from '../../shared/printSettings';
import { useBusiness } from '../../shared/business';
import { MonoBitmap } from '../../shared/media';
import { Toggle, ChoiceCard } from '../common/Choice';
import { toast } from '../../shared/toast';
import { t } from '../../i18n';

const selectCls = 'w-full px-3 py-2.5 bg-white border border-slate-200 rounded-xl text-sm font-medium text-slate-800 outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20';
const labelCls = 'block text-xs font-bold text-slate-700 mb-1.5';

type Role = 'receipt' | 'kitchen';

const targetKey = (tg: PrinterTarget | null) => (!tg ? '' : tg.type === 'windows' ? `win:${tg.name}` : 'net');
const targetName = (tg: PrinterTarget | null) => (!tg ? '' : tg.type === 'windows' ? tg.name : `${tg.host}:${tg.port}`);

function PrinterPicker({ role, value, onChange, printers, sameAsReceipt, onTest, testing }: {
  role: Role;
  value: PrinterTarget | null;
  onChange: (tg: PrinterTarget | null) => void;
  printers: InstalledPrinter[];
  sameAsReceipt?: boolean;
  onTest: () => void;
  testing: boolean;
}) {
  const key = targetKey(value);
  const missing = value?.type === 'windows' && printers.length > 0 && !printers.some((p) => p.name === value.name);
  const Icon = role === 'receipt' ? Receipt : ChefHat;
  return (
    <div className="rounded-2xl border border-slate-200 p-4 space-y-3">
      <div className="flex items-center gap-2">
        <Icon className="w-4 h-4 text-blue-600" aria-hidden />
        <h5 className="text-sm font-bold text-slate-900">{t(`printing:rol_${role}`)}</h5>
      </div>
      <p className="text-xs text-slate-500 -mt-1">{t(`printing:rol_${role}_desc`)}</p>
      <label className="block">
        <span className="sr-only">{t(`printing:rol_${role}`)}</span>
        <select
          className={selectCls}
          value={key}
          onChange={(e) => {
            const v = e.target.value;
            if (!v) onChange(null);
            else if (v === 'net') onChange({ type: 'network', host: value?.type === 'network' ? value.host : '', port: value?.type === 'network' ? value.port : 9100 });
            else onChange({ type: 'windows', name: v.slice(4) });
          }}
        >
          <option value="">{role === 'kitchen' ? t('printing:misma_de_caja') : t('printing:elige_impresora')}</option>
          {printers.length > 0 && (
            <optgroup label={t('printing:instaladas_windows')}>
              {printers.map((p) => (
                <option key={p.name} value={`win:${p.name}`} disabled={p.virtual}>
                  {p.name}{p.isDefault ? ` · ${t('printing:predeterminada')}` : ''}{p.offline ? ` · ${t('printing:desconectada')}` : ''}{p.virtual ? ` · ${t('printing:no_es_de_recibos')}` : ''}
                </option>
              ))}
            </optgroup>
          )}
          {missing && <option value={key}>{value?.type === 'windows' ? value.name : ''} · {t('printing:no_encontrada')}</option>}
          <option value="net">{t('printing:red_ip')}</option>
        </select>
      </label>
      {value?.type === 'network' && (
        <div className="grid grid-cols-[1fr_6rem] gap-2">
          <label className="block">
            <span className={labelCls}>{t('printing:ip')}</span>
            <input className={selectCls} value={value.host} inputMode="decimal" placeholder="192.168.1.100" onChange={(e) => onChange({ ...value, host: e.target.value.trim() })} />
          </label>
          <label className="block">
            <span className={labelCls}>{t('printing:puerto')}</span>
            <input className={selectCls} value={value.port} inputMode="numeric" onChange={(e) => onChange({ ...value, port: Number(e.target.value.replace(/\D/g, '')) || 9100 })} />
          </label>
        </div>
      )}
      {missing && <p className="text-xs font-medium text-amber-800">{t('printing:aviso_no_encontrada')}</p>}
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs text-slate-500 inline-flex items-center gap-1.5">
          {value ? (value.type === 'network' ? <Wifi className="w-3.5 h-3.5" aria-hidden /> : <Usb className="w-3.5 h-3.5" aria-hidden />) : null}
          {value ? targetName(value) : sameAsReceipt ? t('printing:usa_la_de_caja') : t('printing:sin_impresora')}
        </span>
        <button type="button" onClick={onTest} disabled={testing || (!value && !sameAsReceipt)} className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs font-bold text-slate-700 hover:bg-slate-50 disabled:opacity-50">
          {testing ? <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden /> : <Printer className="w-3.5 h-3.5" aria-hidden />}
          {t('printing:imprimir_prueba')}
        </button>
      </div>
    </div>
  );
}

export function PrintingSettingsPanel() {
  const stored = usePrintSettings((s) => s.settings);
  const loadStored = usePrintSettings((s) => s.load);
  const setStored = usePrintSettings((s) => s.setSettings);
  const { settings: business } = useBusiness();
  const [form, setForm] = useState<PrintSettings>(stored);
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [printers, setPrinters] = useState<InstalledPrinter[]>([]);
  const [supported, setSupported] = useState(true);
  const [scanning, setScanning] = useState(false);
  const [testing, setTesting] = useState<Role | null>(null);
  const [preview, setPreview] = useState<'receipt' | 'kitchen'>('receipt');
  const [logo, setLogo] = useState<MonoBitmap | null>(null);

  useEffect(() => {
    loadStored().then((s) => {
      setForm(s);
      setDirty(false);
    });
    scan();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    let alive = true;
    logoBitmap(business?.logoUrl, form.paperWidth).then((b) => alive && setLogo(b));
    return () => {
      alive = false;
    };
  }, [business?.logoUrl, form.paperWidth]);

  const scan = async () => {
    setScanning(true);
    try {
      const r = await printingAPI.printers();
      setPrinters(r.printers);
      setSupported(r.supported);
    } catch (e: any) {
      setPrinters([]);
      toast.error(e.message || t('printing:no_se_listaron'));
    } finally {
      setScanning(false);
    }
  };

  const set = (patch: Partial<PrintSettings>) => {
    setForm((f) => ({ ...f, ...patch }));
    setDirty(true);
  };

  const ctx: TicketContext = useMemo(() => ({ settings: form, business, logo }), [form, business, logo]);

  const previewHtml = useMemo(() => {
    const doc = preview === 'receipt'
      ? buildReceiptDoc(sampleReceiptData(ctx), ctx).blocks
      : buildKitchenDoc({ items: [{ quantity: 2, productName: 'Capuchino', variantName: '12 oz' }, { quantity: 1, productName: 'Sándwich de pollo', variantName: 'Normal', notes: t('printing:nota_ejemplo') }], tableNumber: `${t('ticket:mesa')} 4`, roundNumber: 2, waiterName: 'Ana' }, ctx).blocks;
    return `<style>${ticketCss(form)}</style>${renderTicketBody({ title: 'preview', blocks: doc }, form)}`;
  }, [ctx, form, preview]);

  const test = async (role: Role) => {
    const target = role === 'kitchen' ? form.kitchen || form.receipt : form.receipt;
    if (!target) return;
    setTesting(role);
    try {
      const doc = role === 'kitchen'
        ? buildKitchenDoc({ items: [{ quantity: 1, productName: t('printing:prueba_cocina') }], tableNumber: t('ticket:prueba_titulo') }, ctx)
        : buildTestDoc(ctx, targetName(target));
      await printingAPI.test(target, doc, form, role === 'receipt' && form.openDrawer);
      toast.success(t('printing:prueba_enviada', { name: targetName(target) }));
    } catch (e: any) {
      toast.error(e.message || t('printing:prueba_fallo'), t('printing:prueba_fallo_titulo'));
    } finally {
      setTesting(null);
    }
  };

  const save = async () => {
    if (form.mode === 'direct' && !form.receipt) {
      toast.warning(t('printing:falta_impresora_caja'));
      return;
    }
    if (form.receipt?.type === 'network' && !form.receipt.host) return toast.warning(t('printing:falta_ip'));
    if (form.kitchen?.type === 'network' && !form.kitchen.host) return toast.warning(t('printing:falta_ip'));
    setSaving(true);
    try {
      const saved = await printingAPI.saveSettings(form);
      setStored(saved);
      setForm(saved);
      setDirty(false);
      toast.success(t('printing:guardado'));
    } catch (e: any) {
      toast.error(e.message || t('printing:no_se_guardo'));
    } finally {
      setSaving(false);
    }
  };

  const direct = form.mode === 'direct';
  const realPrinters = printers.filter((p) => !p.virtual);

  return (
    <div className="space-y-6">
      {/* Modo */}
      <section className="bg-white rounded-3xl shadow-sm p-6 border border-slate-200/80 space-y-4">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h4 className="font-bold text-base text-slate-900 flex items-center gap-2"><Printer className="w-5 h-5 text-blue-600" aria-hidden /> {t('printing:como_imprimir')}</h4>
            <p className="text-xs text-slate-500 mt-0.5 max-w-2xl">{t('printing:como_imprimir_desc')}</p>
          </div>
          <button type="button" onClick={save} disabled={saving || !dirty} className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-5 min-h-[44px] rounded-xl font-bold text-xs shadow-sm disabled:opacity-50">
            {saving ? <Loader2 className="w-4 h-4 animate-spin" aria-hidden /> : <Save className="w-4 h-4" aria-hidden />}
            {dirty ? t('printing:guardar') : t('printing:sin_cambios')}
          </button>
        </div>
        <div role="radiogroup" aria-label={t('printing:como_imprimir')} className="grid gap-3 md:grid-cols-2">
          <ChoiceCard active={direct} onClick={() => set({ mode: 'direct' })} title={t('printing:modo_directo')} description={t('printing:modo_directo_desc')} icon={<Zap className="w-5 h-5 text-blue-600 mb-2" aria-hidden />} />
          <ChoiceCard active={!direct} onClick={() => set({ mode: 'browser' })} title={t('printing:modo_navegador')} description={t('printing:modo_navegador_desc')} icon={<MonitorSmartphone className="w-5 h-5 text-slate-500 mb-2" aria-hidden />} />
        </div>
      </section>

      <div className="grid grid-cols-1 xl:grid-cols-[minmax(0,1fr)_22rem] gap-6 items-start">
        <div className="space-y-6 min-w-0">
          {/* Impresoras */}
          {direct && (
            <section className="bg-white rounded-3xl shadow-sm p-6 border border-slate-200/80 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h4 className="font-bold text-sm text-slate-900">{t('printing:impresoras')}</h4>
                  <p className="text-xs text-slate-500">
                    {!supported ? t('printing:solo_windows') : realPrinters.length ? t('printing:encontradas', { count: realPrinters.length }) : t('printing:ninguna_encontrada')}
                  </p>
                </div>
                <button type="button" onClick={scan} disabled={scanning} className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs font-bold text-slate-700 hover:bg-slate-50">
                  <RefreshCw className={`w-3.5 h-3.5 ${scanning ? 'animate-spin' : ''}`} aria-hidden /> {t('printing:buscar_impresoras')}
                </button>
              </div>
              {supported && !scanning && realPrinters.length === 0 && (
                <div className="flex gap-2 rounded-2xl bg-amber-50 border border-amber-200 p-3 text-xs text-amber-900">
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" aria-hidden />
                  <p>{t('printing:como_instalar')}</p>
                </div>
              )}
              <div className="grid gap-4 lg:grid-cols-2">
                <PrinterPicker role="receipt" value={form.receipt} printers={printers} onChange={(receipt) => set({ receipt })} onTest={() => test('receipt')} testing={testing === 'receipt'} />
                <PrinterPicker role="kitchen" value={form.kitchen} printers={printers} sameAsReceipt={!!form.receipt} onChange={(kitchen) => set({ kitchen })} onTest={() => test('kitchen')} testing={testing === 'kitchen'} />
              </div>
              <p className="text-xs text-slate-500 flex gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" aria-hidden /> {t('printing:respaldo_navegador')}</p>
            </section>
          )}

          {/* Papel y ticket */}
          <section className="bg-white rounded-3xl shadow-sm p-6 border border-slate-200/80 space-y-5">
            <h4 className="font-bold text-sm text-slate-900">{t('printing:papel_y_ticket')}</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <label className="block">
                <span className={labelCls}>{t('settings:ancho_de_papel_rollo')}</span>
                <select className={selectCls} value={form.paperWidth} onChange={(e) => set({ paperWidth: e.target.value as PrintSettings['paperWidth'] })}>
                  <option value="80mm">{t('settings:80_mm_rollo_estandar_ancho')}</option>
                  <option value="58mm">{t('settings:58_mm_rollo_pequeno_compacto')}</option>
                </select>
              </label>
              <label className="block">
                <span className={labelCls}>{t('settings:idioma_de_los_tickets')}</span>
                <select className={selectCls} value={form.language} onChange={(e) => set({ language: e.target.value as PrintSettings['language'] })}>
                  <option value="es">{t('settings:espanol')}</option>
                  <option value="en">{t('settings:ingles')}</option>
                </select>
              </label>
              <label className="block">
                <span className={labelCls}>{t('printing:copias_recibo')}</span>
                <select className={selectCls} value={form.receiptCopies} onChange={(e) => set({ receiptCopies: Number(e.target.value) })}>
                  {[1, 2, 3].map((n) => <option key={n} value={n}>{n}</option>)}
                </select>
              </label>
              <label className="block">
                <span className={labelCls}>{t('printing:copias_comanda')}</span>
                <select className={selectCls} value={form.kitchenCopies} onChange={(e) => set({ kitchenCopies: Number(e.target.value) })}>
                  {[1, 2, 3].map((n) => <option key={n} value={n}>{n}</option>)}
                </select>
              </label>
              <label className="block sm:col-span-2">
                <span className={labelCls}>{t('settings:mensaje_de_despedida_al_pie_del_ticket')}</span>
                <input className={selectCls} value={form.footer} maxLength={200} placeholder={t('ticket:gracias')} onChange={(e) => set({ footer: e.target.value })} />
                <span className="block text-xs text-slate-500 mt-1">{t('printing:pie_lantify')}</span>
              </label>
            </div>

            <div className="grid gap-3 md:grid-cols-2">
              <Toggle id="pr-logo" checked={form.showLogo} onChange={(v) => set({ showLogo: v })} label={t('printing:imprimir_logo')} description={business?.logoUrl ? t('printing:imprimir_logo_desc') : t('printing:sin_logo')} badge={!business?.logoUrl ? <ImageOff className="w-3.5 h-3.5 text-slate-400" aria-hidden /> : undefined} />
              <Toggle id="pr-auto-receipt" checked={form.autoPrintReceipt} onChange={(v) => set({ autoPrintReceipt: v })} label={t('printing:auto_recibo')} description={t('printing:auto_recibo_desc')} />
              <Toggle id="pr-auto-kitchen" checked={form.autoPrintKitchen} onChange={(v) => set({ autoPrintKitchen: v })} label={t('printing:auto_comanda')} description={t('printing:auto_comanda_desc')} />
              {direct && <Toggle id="pr-cut" checked={form.cut} onChange={(v) => set({ cut: v })} label={t('printing:cortar')} description={t('printing:cortar_desc')} />}
              {direct && <Toggle id="pr-drawer" checked={form.openDrawer} onChange={(v) => set({ openDrawer: v })} label={t('printing:cajon')} description={t('printing:cajon_desc')} />}
            </div>

            <details className="rounded-2xl border border-slate-200 px-4 py-3">
              <summary className="cursor-pointer text-xs font-bold text-slate-700">{t('printing:avanzado')}</summary>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
                <label className="block">
                  <span className={labelCls}>{t('settings:tamano_del_texto')}</span>
                  <select className={selectCls} value={form.fontSize} onChange={(e) => set({ fontSize: e.target.value as PrintSettings['fontSize'] })}>
                    <option value="compact">{t('settings:compacto_ahorro_de_papel')}</option>
                    <option value="medium">{t('settings:mediano_legibilidad_equilibrada')}</option>
                    <option value="large">{t('settings:grande_maxima_visibilidad')}</option>
                  </select>
                  <span className="block text-xs text-slate-500 mt-1">{t('printing:solo_navegador')}</span>
                </label>
                <label className="block">
                  <span className={labelCls}>{t('settings:tipografia_de_impresion')}</span>
                  <select className={selectCls} value={form.font} onChange={(e) => set({ font: e.target.value as PrintSettings['font'] })}>
                    <option value="sans-serif">{t('settings:sans_serif_moderna_y_nitida')}</option>
                    <option value="monospace">{t('settings:monospace_termica_clasica')}</option>
                  </select>
                  <span className="block text-xs text-slate-500 mt-1">{t('printing:solo_navegador')}</span>
                </label>
                <label className="block">
                  <span className={labelCls}>{t('settings:margen_del_ticket')}</span>
                  <select className={selectCls} value={form.margin} onChange={(e) => set({ margin: e.target.value as PrintSettings['margin'] })}>
                    <option value="0mm">{t('settings:0_mm_aprovechar_todo_el_papel')}</option>
                    <option value="2mm">{t('settings:2_mm_recomendado_estandar')}</option>
                    <option value="4mm">{t('settings:4_mm_margen_amplio')}</option>
                  </select>
                  <span className="block text-xs text-slate-500 mt-1">{t('printing:solo_navegador')}</span>
                </label>
                <label className="block">
                  <span className={labelCls}>{t('printing:caracteres')}</span>
                  <select className={selectCls} value={form.codepage} onChange={(e) => set({ codepage: e.target.value as PrintSettings['codepage'] })}>
                    <option value="cp850">{t('printing:cp850')}</option>
                    <option value="cp1252">{t('printing:cp1252')}</option>
                    <option value="ascii">{t('printing:ascii')}</option>
                  </select>
                  <span className="block text-xs text-slate-500 mt-1">{t('printing:caracteres_desc')}</span>
                </label>
              </div>
            </details>
          </section>
        </div>

        {/* Vista previa */}
        <aside className="xl:sticky xl:top-4 bg-slate-900 rounded-3xl p-5 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <p className="text-xs font-bold text-slate-300 uppercase tracking-widest">{t('printing:vista_previa', { paper: form.paperWidth })}</p>
            <div role="tablist" className="flex rounded-lg bg-slate-800 p-0.5">
              {(['receipt', 'kitchen'] as const).map((k) => (
                <button key={k} role="tab" aria-selected={preview === k} type="button" onClick={() => setPreview(k)} className={`px-2.5 py-1 rounded-md text-xs font-bold ${preview === k ? 'bg-white text-slate-900' : 'text-slate-300 hover:text-white'}`}>
                  {k === 'receipt' ? t('printing:recibo') : t('printing:comanda')}
                </button>
              ))}
            </div>
          </div>
          <div className="bg-white rounded-md shadow-2xl py-4 px-2 max-h-[70vh] overflow-y-auto" dangerouslySetInnerHTML={{ __html: previewHtml }} />
        </aside>
      </div>
    </div>
  );
}
