// ============================================
// ADMIN - Pantallas de cocina, entregas y salón (Lantify 3.0 · bloque 2)
// ============================================
// El administrador crea la pantalla y obtiene un código de 6 dígitos. En el TV
// se abre http://<ip-de-la-caja>:5000/pantalla y se escribe el código.

import React, { useEffect, useState } from 'react';
import { BookOpen, ChefHat, Copy, LayoutGrid, MonitorSmartphone, Plus, RefreshCw, Trash2, Unplug, Users } from 'lucide-react';
import { displaysAPI, type DisplayInfo } from '../../services/v3Api';
import { errorMessage } from '../../services/apiErrors';
import { usePrintSettings } from '../../shared/printSettings';
import { useFeatureFlag } from '../../shared/features';
import { copyText } from '../../shared/browser';
import { confirmDialog } from '../../shared/dialog';
import { toast } from '../../shared/toast';
import { Button } from '../common/Button';
import { t } from '../../i18n';
import type { DisplayType } from '../../../../src/domain/v3/kitchen';

const TYPE_ICON: Record<DisplayType, typeof ChefHat> = { KITCHEN: ChefHat, PICKUP: Users, FLOOR: LayoutGrid };
const field = 'rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 min-h-[44px] focus:outline-none focus:ring-2 focus:ring-blue-500/40';

/** Dirección que se abre en el TV: la de este equipo en la red local */
const displayUrl = () => {
  const { protocol, hostname, port } = window.location;
  const host = hostname === 'localhost' || hostname === '127.0.0.1' ? t('v3:ip_de_la_caja') : hostname;
  // En desarrollo la interfaz va por 5173; en el programa instalado, por 5000
  return `${protocol}//${host}${port ? `:${port}` : ''}/pantalla`;
};

/** Cómo y dónde poner cada pantalla, paso a paso */
function SetupGuide({ open, onToggle }: { open: boolean; onToggle: () => void }) {
  const places: { type: DisplayType; icon: typeof ChefHat }[] = [{ type: 'KITCHEN', icon: ChefHat }, { type: 'PICKUP', icon: Users }, { type: 'FLOOR', icon: LayoutGrid }];
  return (
    <div className="rounded-2xl border border-slate-200 bg-slate-50">
      <button type="button" onClick={onToggle} aria-expanded={open} className="flex w-full items-center justify-between gap-3 px-4 py-3 text-left">
        <span className="flex items-center gap-2 font-bold text-slate-900"><BookOpen className="h-5 w-5 text-blue-700" aria-hidden />{t('v3:guia_pantallas')}</span>
        <span className="text-sm font-semibold text-blue-700">{open ? t('v3:ocultar') : t('v3:ver_paso_a_paso')}</span>
      </button>
      {open && (
        <div className="space-y-5 border-t border-slate-200 px-4 py-4">
          <div className="grid gap-3 md:grid-cols-3">
            {places.map(({ type, icon: Icon }) => (
              <article key={type} className="rounded-xl border border-slate-200 bg-white p-4">
                <Icon className="h-6 w-6 text-blue-700" aria-hidden />
                <h4 className="mt-2 font-bold text-slate-900">{t(`v3:pantalla_tipo_${type}`)}</h4>
                <p className="mt-1 text-sm text-slate-600"><span className="font-semibold text-slate-800">{t('v3:guia_donde')}:</span> {t(`v3:guia_donde_${type}`)}</p>
                <p className="mt-1 text-sm text-slate-600"><span className="font-semibold text-slate-800">{t('v3:guia_quien')}:</span> {t(`v3:guia_quien_${type}`)}</p>
              </article>
            ))}
          </div>
          <div>
            <h4 className="font-bold text-slate-900">{t('v3:guia_que_necesitas')}</h4>
            <ul className="mt-1 list-disc space-y-1 pl-5 text-sm text-slate-700">
              {[1, 2, 3].map((i) => <li key={i}>{t(`v3:guia_necesitas_${i}`)}</li>)}
            </ul>
          </div>
          <div>
            <h4 className="font-bold text-slate-900">{t('v3:guia_pasos')}</h4>
            <ol className="mt-2 space-y-2">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <li key={i} className="flex gap-3 text-sm text-slate-700">
                  <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-blue-700 text-xs font-black text-white">{i}</span>
                  <span>{t(`v3:guia_paso_${i}`, { url: displayUrl() })}</span>
                </li>
              ))}
            </ol>
          </div>
          <div className="rounded-xl bg-amber-50 p-3 text-sm text-amber-900">
            <p className="font-bold">{t('v3:guia_si_falla')}</p>
            <ul className="mt-1 list-disc space-y-1 pl-5">{[1, 2, 3].map((i) => <li key={i}>{t(`v3:guia_falla_${i}`)}</li>)}</ul>
          </div>
        </div>
      )}
    </div>
  );
}

export const DisplaysPanel: React.FC = () => {
  const on = useFeatureFlag('kitchen_display');
  const stations = usePrintSettings((s) => s.settings.stations);
  const [list, setList] = useState<DisplayInfo[]>([]);
  const [name, setName] = useState('');
  const [type, setType] = useState<DisplayType>('KITCHEN');
  const [station, setStation] = useState('');
  const [pairing, setPairing] = useState<{ id: string; code: string; expiresAt: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [guide, setGuide] = useState(true);

  const load = () => displaysAPI.list().then((l) => { setList(l); if (l.some((d) => d.connected)) setGuide(false); }).catch(() => setList([]));
  useEffect(() => { if (on) load(); }, [on]);
  // Mientras se muestra un código, se revisa si el TV ya se conectó
  useEffect(() => {
    if (!pairing) return;
    const id = setInterval(async () => {
      const fresh = await displaysAPI.list().catch(() => null);
      if (!fresh) return;
      setList(fresh);
      if (fresh.find((d) => d.id === pairing.id)?.connected) {
        toast.success(t('v3:pantalla_conectada'));
        setPairing(null);
      }
    }, 3000);
    return () => clearInterval(id);
  }, [pairing]);

  if (!on) return null;

  const create = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    setBusy(true);
    try {
      const r = await displaysAPI.create({ name: name.trim(), type, station: type === 'KITCHEN' && station ? station : null });
      setPairing({ id: r.display.id, code: r.code, expiresAt: r.expiresAt });
      setName('');
      load();
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  const newCode = async (d: DisplayInfo) => {
    try {
      const r = await displaysAPI.code(d.id);
      setPairing({ id: d.id, code: r.code, expiresAt: r.expiresAt });
      load();
    } catch (err) {
      toast.error(errorMessage(err));
    }
  };

  const stationName = (id: string | null) => (!id ? t('v3:todas_estaciones') : id === 'kitchen' ? t('v3:cocina_principal') : stations.find((s) => s.id === id)?.name || id);

  return (
    <section className="bg-white rounded-3xl shadow-sm p-6 sm:p-8 border border-slate-200/80 space-y-4" aria-labelledby="displays-title">
      <div className="flex items-start gap-3">
        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-blue-50 text-blue-700"><MonitorSmartphone className="h-5 w-5" aria-hidden /></span>
        <div>
          <h3 id="displays-title" className="text-base font-bold text-slate-900 font-heading">{t('v3:pantallas_titulo')}</h3>
          <p className="text-sm text-slate-500">{t('v3:pantallas_desc')}</p>
        </div>
      </div>

      <SetupGuide open={guide} onToggle={() => setGuide((g) => !g)} />

      {pairing && (
        <div className="rounded-2xl border-2 border-blue-600 bg-blue-50 p-5" role="status">
          <p className="text-sm font-semibold text-blue-900">{t('v3:pantalla_paso1')}</p>
          <p className="mt-1 flex flex-wrap items-center gap-2 font-mono text-base font-bold text-slate-900 break-all">
            {displayUrl()}
            <button type="button" onClick={() => copyText(displayUrl()).then(() => toast.success(t('v3:copiado')))} className="rounded-lg p-1.5 text-blue-800 hover:bg-blue-100" aria-label={t('v3:copiar')}><Copy className="h-4 w-4" /></button>
          </p>
          <p className="mt-3 text-sm font-semibold text-blue-900">{t('v3:pantalla_paso2')}</p>
          <p className="mt-1 font-mono text-5xl font-black tracking-[0.3em] text-slate-900 tabular-nums">{pairing.code}</p>
          <p className="mt-2 text-xs text-blue-900/80">{t('v3:pantalla_vence', { hora: new Date(pairing.expiresAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) })}</p>
        </div>
      )}

      {list.length > 0 && (
        <ul className="divide-y divide-slate-100 rounded-2xl border border-slate-200">
          {list.map((d) => {
            const Icon = TYPE_ICON[d.type];
            return (
              <li key={d.id} className="flex flex-wrap items-center gap-3 px-4 py-3">
                <Icon className="h-5 w-5 text-slate-500" aria-hidden />
                <div className="min-w-0 flex-1">
                  <p className="font-semibold text-slate-900">{d.name}</p>
                  <p className="text-xs text-slate-500">{t(`v3:pantalla_tipo_${d.type}`)}{d.type === 'KITCHEN' ? ` · ${stationName(d.station)}` : ''}</p>
                </div>
                <span className={`rounded-full px-2.5 py-1 text-xs font-bold ${d.connected ? 'bg-emerald-100 text-emerald-800' : d.pairing ? 'bg-blue-100 text-blue-800' : 'bg-slate-100 text-slate-600'}`}>
                  {d.connected ? t('v3:conectada') : d.pairing ? t('v3:esperando_codigo') : t('v3:sin_conectar')}
                </span>
                <button type="button" onClick={() => newCode(d)} className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl px-3 text-xs font-bold text-slate-700 hover:bg-slate-100"><RefreshCw className="h-4 w-4" aria-hidden />{t('v3:nuevo_codigo')}</button>
                {d.connected && (
                  <button type="button" onClick={async () => { await displaysAPI.disconnect(d.id); load(); }} className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl px-3 text-xs font-bold text-slate-700 hover:bg-slate-100"><Unplug className="h-4 w-4" aria-hidden />{t('v3:desconectar')}</button>
                )}
                <button
                  type="button"
                  onClick={async () => {
                    if (!(await confirmDialog({ title: t('v3:quitar_pantalla'), message: t('v3:quitar_pantalla_desc', { name: d.name }), tone: 'danger', confirmLabel: t('v3:quitar') }))) return;
                    await displaysAPI.remove(d.id);
                    load();
                  }}
                  className="rounded-xl p-2 text-slate-400 hover:bg-rose-50 hover:text-rose-700"
                  aria-label={t('v3:quitar_pantalla')}
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </li>
            );
          })}
        </ul>
      )}

      <form onSubmit={create} className="grid gap-3 sm:grid-cols-[1fr_12rem_12rem_auto] sm:items-end">
        <label className="space-y-1 text-xs font-bold text-slate-700">{t('v3:nombre_pantalla')}
          <input className={`${field} w-full`} maxLength={40} value={name} onChange={(e) => setName(e.target.value)} placeholder={t('v3:nombre_pantalla_ej')} />
        </label>
        <label className="space-y-1 text-xs font-bold text-slate-700">{t('v3:tipo')}
          <select className={`${field} w-full`} value={type} onChange={(e) => setType(e.target.value as DisplayType)}>
            {(['KITCHEN', 'PICKUP', 'FLOOR'] as DisplayType[]).map((x) => <option key={x} value={x}>{t(`v3:pantalla_tipo_${x}`)}</option>)}
          </select>
        </label>
        <label className="space-y-1 text-xs font-bold text-slate-700">{t('v3:estacion')}
          <select className={`${field} w-full`} value={station} disabled={type !== 'KITCHEN'} onChange={(e) => setStation(e.target.value)}>
            <option value="">{t('v3:todas_estaciones')}</option>
            <option value="kitchen">{t('v3:cocina_principal')}</option>
            {stations.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
        </label>
        <Button type="submit" isLoading={busy} disabled={!name.trim()} leftIcon={<Plus className="h-4 w-4" />}>{t('v3:agregar_pantalla')}</Button>
      </form>
      <p className="text-xs text-slate-500">{t('v3:pantallas_nota')}</p>
    </section>
  );
};
