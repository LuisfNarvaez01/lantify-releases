// ============================================
// COMPONENTS - Inventory Module (Admin Panel)
// ============================================

import { useState, useEffect, Fragment } from 'react';
import {
  Package, ToggleLeft, ToggleRight, Plus, Minus,
  ClipboardCheck, AlertTriangle, History, RefreshCw,
  Search, X, Check, Archive
} from 'lucide-react';
import { inventoryAPI } from '../../services/api';
import { toast } from '../../shared/toast';
import { useFeature, showPlanLock } from '../../shared/plan';

import { t, getLocale } from '../../i18n';
interface InventoryItem {
  variantId: string;
  productId: string;
  productName: string;
  variantName: string;
  sku: string;
  categoryName: string;
  stock: number;
  trackInventory: boolean;
  cost: number | null;
  price: number;
  lowStock: boolean;
  outOfStock: boolean;
}

export const InventoryModule = () => {
  const hasCounts = useFeature('inventory');
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAll, setShowAll] = useState(false);
  const [search, setSearch] = useState('');
  const [countModal, setCountModal] = useState<InventoryItem | null>(null);
  const [countValue, setCountValue] = useState('');
  const [justification, setJustification] = useState('');
  const [countError, setCountError] = useState('');
  const [adjustModal, setAdjustModal] = useState<{ item: InventoryItem; type: 'add' | 'remove' } | null>(null);
  const [adjustQty, setAdjustQty] = useState('');
  const [adjustNotes, setAdjustNotes] = useState('');
  const [expandedMovements, setExpandedMovements] = useState<string | null>(null);
  const [movements, setMovements] = useState<any[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => { loadInventory(); }, [showAll]);

  const loadInventory = async () => {
    setLoading(true);
    try {
      const data = await inventoryAPI.getStatus(!showAll);
      setItems(data);
    } catch (err) {
      console.error('Error loading inventory:', err);
    }
    setLoading(false);
  };

  const handleToggleTrack = async (item: InventoryItem) => {
    try {
      await inventoryAPI.toggleTrack(item.variantId, !item.trackInventory);
      toast.success(item.trackInventory ? t('inventory:control_de_stock_desactivado') : t('inventory:control_de_stock_activado'));
      loadInventory();
    } catch (err: any) {
      toast.error(err.message || 'Error al modificar control de stock');
    }
  };

  const handleAdjust = async () => {
    if (!adjustModal || !adjustQty) return;
    setIsSubmitting(true);
    try {
      await inventoryAPI.adjustStock(
        adjustModal.item.variantId,
        parseInt(adjustQty),
        adjustModal.type === 'add' ? 'MANUAL_ADD' : 'MANUAL_REMOVE',
        adjustNotes || undefined
      );
      toast.success(t('inventory:ajuste_de_inventario_aplicado_con_exito'));
      setAdjustModal(null);
      setAdjustQty('');
      setAdjustNotes('');
      loadInventory();
    } catch (err: any) {
      toast.error(err.message || 'Error al ajustar stock');
    }
    setIsSubmitting(false);
  };

  const handleSubmitCount = async () => {
    if (!countModal || countValue === '') return;
    setCountError('');
    setIsSubmitting(true);
    try {
      const counted = parseInt(countValue);
      const diff = counted - countModal.stock;
      if (diff !== 0 && !justification.trim()) {
        setCountError(t('inventory:diferencia_de_value_diff_unidades_debe_justificar', { value: diff > 0 ? '+' : '', diff }));
        setIsSubmitting(false);
        return;
      }
      await inventoryAPI.submitCount(
        countModal.variantId,
        counted,
        justification || undefined
      );
      setCountModal(null);
      setCountValue('');
      setJustification('');
      loadInventory();
    } catch (err: any) {
      setCountError(err.message || t('inventory:error_al_aplicar_conteo'));
    }
    setIsSubmitting(false);
  };

  const loadMovements = async (variantId: string) => {
    if (expandedMovements === variantId) {
      setExpandedMovements(null);
      return;
    }
    try {
      const data = await inventoryAPI.getMovements(variantId);
      setMovements(data);
      setExpandedMovements(variantId);
    } catch (err) {
      console.error('Error loading movements:', err);
    }
  };

  const filtered = items.filter(i =>
    i.productName.toLowerCase().includes(search.toLowerCase()) ||
    i.variantName.toLowerCase().includes(search.toLowerCase()) ||
    i.sku.toLowerCase().includes(search.toLowerCase())
  );

  const tracked = filtered.filter(i => i.trackInventory);
  const untracked = filtered.filter(i => !i.trackInventory);
  const lowStockCount = tracked.filter(i => i.lowStock).length;
  const outOfStockCount = tracked.filter(i => i.outOfStock).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-amber-100 rounded-xl flex items-center justify-center">
            <Archive className="w-6 h-6 text-amber-600" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-gray-800">{t('inventory:inventario')}</h2>
            <p className="text-xs text-gray-500">{tracked.length}{' '}{t('inventory:productos_con_seguimiento')}</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={loadInventory}
            className="p-2 text-gray-500 hover:bg-gray-100 rounded-xl transition-colors"
          >
            <RefreshCw className="w-5 h-5" />
          </button>
          <label className="flex items-center gap-2 text-sm font-medium text-gray-600 bg-gray-50 px-4 py-2 rounded-xl border border-gray-200 cursor-pointer hover:bg-gray-100 transition-colors">
            <input
              type="checkbox"
              checked={showAll}
              onChange={() => setShowAll(!showAll)}
              className="accent-blue-600"
            />
            {t('inventory:mostrar_todos')}
          </label>
        </div>
      </div>

      {/* KPI Cards */}
      {tracked.length > 0 && (
        <div className="grid grid-cols-3 gap-4">
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm">
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">{t('inventory:productos_rastreados')}</p>
            <p className="text-2xl font-black text-slate-900 mt-1 font-mono tabular-nums">{tracked.length}</p>
          </div>
          <div className={`rounded-2xl p-5 border shadow-sm ${lowStockCount > 0 ? 'bg-amber-50 border-amber-200' : 'bg-white border-slate-200'}`}>
            <p className="text-xs font-bold text-amber-600 uppercase tracking-wider">{t('inventory:stock_bajo')}</p>
            <p className="text-2xl font-black text-amber-700 mt-1 font-mono tabular-nums">{lowStockCount}</p>
          </div>
          <div className={`rounded-2xl p-5 border shadow-sm ${outOfStockCount > 0 ? 'bg-rose-50 border-rose-200' : 'bg-white border-slate-200'}`}>
            <p className="text-xs font-bold text-rose-500 uppercase tracking-wider">{t('inventory:sin_stock')}</p>
            <p className="text-2xl font-black text-rose-700 mt-1 font-mono tabular-nums">{outOfStockCount}</p>
          </div>
        </div>
      )}

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
        <input
          type="text"
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder={t('inventory:buscar_producto_variante_o_sku')}
          className="w-full pl-12 pr-4 py-3 bg-white border border-slate-200 rounded-2xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-slate-900 outline-none text-sm"
        />
      </div>

      {/* Loading */}
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <RefreshCw className="w-8 h-8 text-blue-600 animate-spin" />
        </div>
      ) : (
        <>
          {/* Tracked Products Table */}
          <div className="bg-white rounded-3xl shadow-sm overflow-hidden border border-slate-200/80">
            <div className="bg-slate-900 px-6 py-4 flex items-center justify-between">
              <span className="text-slate-100 font-bold font-heading">{t('inventory:productos_con_seguimiento_de_inventario')}</span>
              <span className="text-xs text-blue-400 font-semibold">{tracked.length}{' '}{t('inventory:productos')}</span>
            </div>
            {tracked.length === 0 ? (
              <div className="text-center py-16 text-gray-400">
                <Package className="w-12 h-12 mx-auto mb-3 opacity-30" />
                <p className="font-medium">{t('inventory:no_hay_productos_con_seguimiento_de_inventario')}</p>
                <p className="text-xs mt-1">{t('inventory:activa_el_toggle_en_un_producto_para')}</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-100">
                      <th className="px-6 py-3 text-left font-bold text-gray-600 text-xs uppercase tracking-wider">{t('inventory:producto')}</th>
                      <th className="px-4 py-3 text-left font-bold text-gray-600 text-xs uppercase tracking-wider">SKU</th>
                      <th className="px-4 py-3 text-center font-bold text-gray-600 text-xs uppercase tracking-wider">{t('inventory:stock')}</th>
                      <th className="px-4 py-3 text-center font-bold text-gray-600 text-xs uppercase tracking-wider">{t('inventory:estado')}</th>
                      <th className="px-4 py-3 text-center font-bold text-gray-600 text-xs uppercase tracking-wider">{t('inventory:seguimiento')}</th>
                      <th className="px-4 py-3 text-center font-bold text-gray-600 text-xs uppercase tracking-wider w-64">{t('inventory:acciones')}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {tracked.map(item => (
                      <Fragment key={item.variantId}>
                        <tr className="hover:bg-amber-50/30 transition-colors">
                          <td className="px-6 py-3">
                            <div className="font-bold text-gray-800">{item.productName}</div>
                            <div className="text-xs text-gray-500">{item.variantName} · {item.categoryName}</div>
                          </td>
                          <td className="px-4 py-3 font-mono text-xs text-gray-500">{item.sku}</td>
                          <td className="px-4 py-3 text-center">
                            <span className={`text-lg font-black ${item.outOfStock ? 'text-red-600' : item.lowStock ? 'text-amber-600' : 'text-green-700'}`}>
                              {item.stock}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-center">
                            {item.outOfStock ? (
                              <span className="text-xs font-bold bg-red-100 text-red-700 px-2 py-1 rounded-full">{t('inventory:sin_stock_2')}</span>
                            ) : item.lowStock ? (
                              <span className="text-xs font-bold bg-amber-100 text-amber-700 px-2 py-1 rounded-full">{t('inventory:bajo')}</span>
                            ) : (
                              <span className="text-xs font-bold bg-green-100 text-green-700 px-2 py-1 rounded-full">OK</span>
                            )}
                          </td>
                          <td className="px-4 py-3 text-center">
                            <button onClick={() => handleToggleTrack(item)} className="text-green-600 hover:text-green-800">
                              <ToggleRight className="w-7 h-7" />
                            </button>
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex items-center justify-center gap-1">
                              <button
                                onClick={() => setAdjustModal({ item, type: 'add' })}
                                className="p-1.5 bg-green-50 text-green-600 hover:bg-green-100 rounded-lg transition-colors"
                                title={t('inventory:agregar_stock')}
                              >
                                <Plus className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => setAdjustModal({ item, type: 'remove' })}
                                className="p-1.5 bg-red-50 text-red-600 hover:bg-red-100 rounded-lg transition-colors"
                                title={t('inventory:quitar_stock')}
                              >
                                <Minus className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => {
                                  // Conteos físicos: plan Pro en adelante
                                  if (!hasCounts) return showPlanLock('inventory');
                                  setCountModal(item); setCountValue(''); setJustification(''); setCountError('');
                                }}
                                className={`p-1.5 rounded-lg transition-colors ${hasCounts ? 'bg-blue-50 text-blue-600 hover:bg-blue-100' : 'bg-gray-50 text-gray-400 hover:bg-gray-100'}`}
                                title={hasCounts ? t('inventory:conteo_fisico') : `${t('inventory:conteo_fisico')} · ${t('plan:no_incluido')}`}
                              >
                                <ClipboardCheck className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => loadMovements(item.variantId)}
                                className={`p-1.5 rounded-lg transition-colors ${expandedMovements === item.variantId ? 'bg-gray-200 text-gray-800' : 'bg-gray-50 text-gray-500 hover:bg-gray-100'}`}
                                title={t('inventory:historial')}
                              >
                                <History className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                        {/* Expanded movements row */}
                        {expandedMovements === item.variantId && (
                          <tr key={`${item.variantId}-movements`}>
                            <td colSpan={6} className="px-6 py-4 bg-gray-50/50">
                              <p className="text-xs font-bold text-gray-600 uppercase tracking-wider mb-3">{t('inventory:ultimos_movimientos_de_stock')}</p>
                              {movements.length === 0 ? (
                                <p className="text-sm text-gray-400 text-center py-4">{t('inventory:sin_movimientos_registrados')}</p>
                              ) : (
                                <div className="space-y-1.5 max-h-48 overflow-y-auto">
                                  {movements.map((m: any) => (
                                    <div key={m.id} className="flex items-center justify-between bg-white px-4 py-2 rounded-xl border border-gray-100 text-xs">
                                      <div className="flex items-center gap-3">
                                        <span className={`px-2 py-0.5 rounded-md font-bold text-xs ${
                                          m.type === 'SALE' ? 'bg-blue-100 text-blue-700' :
                                          m.type === 'COUNT' ? 'bg-purple-100 text-purple-700' :
                                          m.type === 'MANUAL_ADD' ? 'bg-green-100 text-green-700' :
                                          'bg-red-100 text-red-700'
                                        }`}>{m.type}</span>
                                        <span className="text-gray-600">{m.notes || '-'}</span>
                                      </div>
                                      <div className="flex items-center gap-4">
                                        <span className={`font-bold ${m.quantity >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                                          {m.quantity >= 0 ? '+' : ''}{m.quantity}
                                        </span>
                                        <span className="text-gray-400">{m.previousStock} → {m.newStock}</span>
                                        <span className="text-gray-400">{new Date(m.createdAt).toLocaleDateString(getLocale(), { day: '2-digit', month: 'short' })}</span>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </td>
                          </tr>
                        )}
                      </Fragment>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Untracked products (show when showAll) */}
          {showAll && untracked.length > 0 && (
            <div className="bg-white rounded-3xl shadow-sm overflow-hidden border border-gray-200">
              <div className="bg-gray-100 px-6 py-3 flex items-center justify-between">
                <span className="text-gray-600 font-bold text-sm">{t('inventory:productos_sin_seguimiento')}</span>
                <span className="text-xs text-gray-400 font-bold">{untracked.length}{' '}{t('inventory:productos')}</span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <tbody className="divide-y divide-gray-50">
                    {untracked.map(item => (
                      <tr key={item.variantId} className="hover:bg-gray-50/50 transition-colors">
                        <td className="px-6 py-3">
                          <div className="font-bold text-gray-700">{item.productName}</div>
                          <div className="text-xs text-gray-400">{item.variantName}</div>
                        </td>
                        <td className="px-4 py-3 font-mono text-xs text-gray-400">{item.sku}</td>
                        <td className="px-4 py-3 text-center text-gray-300 text-sm">—</td>
                        <td className="px-4 py-3 text-center">
                          <button onClick={() => handleToggleTrack(item)} className="text-gray-300 hover:text-green-600 transition-colors">
                            <ToggleLeft className="w-7 h-7" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </>
      )}

      {/* Count Modal */}
      {countModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full p-8">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
                  <ClipboardCheck className="w-5 h-5 text-blue-600" />
                </div>
                <h3 className="text-lg font-bold text-gray-800">{t('inventory:conteo_fisico_2')}</h3>
              </div>
              <button onClick={() => setCountModal(null)} className="p-1 hover:bg-gray-100 rounded-lg">
                <X className="w-5 h-5 text-gray-400" />
              </button>
            </div>

            <div className="bg-slate-50 rounded-2xl p-4 mb-4 border border-slate-200">
              <p className="font-bold text-slate-900">{countModal.productName}</p>
              <p className="text-xs text-slate-500">{countModal.variantName}{' '}{t('inventory:sku')}{' '}{countModal.sku}</p>
              <p className="text-sm mt-2">{t('inventory:stock_actual_del_sistema')}{' '}<span className="font-black text-slate-900 font-mono">{countModal.stock}</span></p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-bold text-gray-600 mb-1">{t('inventory:cantidad_contada')}</label>
                <input
                  type="number"
                  min="0"
                  value={countValue}
                  onChange={e => {
                    setCountValue(e.target.value);
                    setCountError('');
                  }}
                  className="w-full px-4 py-3 bg-white border-2 border-gray-200 rounded-2xl text-lg font-bold focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="0"
                  autoFocus
                />
              </div>

              {countValue !== '' && parseInt(countValue) !== countModal.stock && (
                <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4">
                  <div className="flex items-start gap-2">
                    <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-bold text-amber-800">
                        {t('inventory:diferencia_value_value2_unidades', { value: parseInt(countValue) - countModal.stock > 0 ? '+' : '', value2: parseInt(countValue) - countModal.stock })}
                      </p>
                      <p className="text-xs text-amber-600 mt-1">{t('inventory:debe_justificar_la_diferencia')}</p>
                    </div>
                  </div>
                  <textarea
                    value={justification}
                    onChange={e => { setJustification(e.target.value); setCountError(''); }}
                    className="w-full mt-3 px-3 py-2 border border-amber-200 rounded-xl text-sm bg-white focus:ring-2 focus:ring-amber-400"
                    placeholder={t('inventory:motivo_de_la_diferencia')}
                    rows={2}
                  />
                </div>
              )}

              {countError && (
                <div className="bg-red-50 border border-red-200 rounded-xl p-3 text-sm text-red-700 font-medium">
                  {countError}
                </div>
              )}

              <div className="flex gap-3 pt-2">
                <button
                  onClick={handleSubmitCount}
                  disabled={countValue === '' || isSubmitting}
                  className="flex-1 py-3 text-white rounded-2xl font-bold shadow-lg hover:scale-[1.02] transition-all disabled:opacity-50"
                  style={{ background: 'linear-gradient(135deg, #2e7d32, #1b5e20)' }}
                >
                  <Check className="w-5 h-5 inline mr-2" />
                  {isSubmitting ? t('inventory:aplicando') : t('inventory:aplicar_conteo')}
                </button>
                <button
                  onClick={() => setCountModal(null)}
                  className="flex-1 py-3 bg-gray-100 text-gray-600 rounded-2xl font-bold hover:bg-gray-200 transition-all border border-gray-200"
                >
                  {t('inventory:cancelar')}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Adjust Modal */}
      {adjustModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl shadow-2xl max-w-sm w-full p-8">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold text-gray-800">
                {adjustModal.type === 'add' ? t('inventory:agregar_stock_2') : t('inventory:quitar_stock_2')}
              </h3>
              <button onClick={() => setAdjustModal(null)} className="p-1 hover:bg-gray-100 rounded-lg">
                <X className="w-5 h-5 text-gray-400" />
              </button>
            </div>

            <p className="text-sm text-gray-600 mb-1 font-bold">{adjustModal.item.productName}</p>
            <p className="text-xs text-gray-400 mb-4">{adjustModal.item.variantName}{' '}{t('inventory:stock_actual')}{' '}{adjustModal.item.stock}</p>

            <div className="space-y-3">
              <input
                type="number"
                min="1"
                value={adjustQty}
                onChange={e => setAdjustQty(e.target.value)}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-2xl font-bold focus:ring-2 focus:ring-amber-500"
                placeholder={t('inventory:cantidad')}
                autoFocus
              />
              <input
                type="text"
                value={adjustNotes}
                onChange={e => setAdjustNotes(e.target.value)}
                className="w-full px-4 py-2 border border-gray-200 rounded-xl text-sm"
                placeholder={t('inventory:nota_opcional')}
              />
              <div className="flex gap-3">
                <button
                  onClick={handleAdjust}
                  disabled={!adjustQty || isSubmitting}
                  className={`flex-1 py-3 text-white rounded-2xl font-bold shadow-lg disabled:opacity-50 ${
                    adjustModal.type === 'add' ? 'bg-green-600 hover:bg-green-700' : 'bg-red-600 hover:bg-red-700'
                  }`}
                >
                  {isSubmitting ? t('inventory:procesando') : adjustModal.type === 'add' ? t('inventory:agregar') : t('inventory:quitar')}
                </button>
                <button
                  onClick={() => setAdjustModal(null)}
                  className="flex-1 py-3 bg-gray-100 text-gray-600 rounded-2xl font-bold hover:bg-gray-200 border border-gray-200"
                >
                  {t('inventory:cancelar')}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default InventoryModule;
