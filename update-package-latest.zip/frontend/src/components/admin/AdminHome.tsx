// ============================================
// Administración · Inicio: cómo va el día
// ============================================
// Hoy contra ayer hasta la misma hora, ventas por hora, los últimos 7 días, lo
// más vendido y cómo te pagan. Disponible en todos los planes (GET /sales/day-summary).
// Si la guía de configuración no está completa, la muestra arriba con su avance.

import { useCallback, useEffect, useState } from 'react';
import { ArrowRight, Compass, RefreshCw } from 'lucide-react';
import { t, getLocale } from '../../i18n';
import { salesAPI } from '../../services/api';
import { formatCurrency } from '../../shared/formatUtils';
import { useGuideProgress } from '../../shared/setupGuide';
import { Card, CardHeader, EmptyState, Skeleton } from '../ui';
import { BarChart, RankList, StackBar, SLICE_TONES } from '../charts/charts';
import { KpiCard } from '../analytics/OverviewTab';
import { Kpis, int, delta, fmtDay, hourLabel, paymentLabel } from '../analytics/types';

interface DaySummary {
  range: { from: string; to: string };
  kpis: Kpis;
  prev: Kpis;
  hourly: { hour: number; revenue: number; sales: number }[];
  payments: { method: string; amount: number; count: number }[];
  products: { productId: string; name: string; category: string | null; units: number; revenue: number }[];
  week: { date: string; revenue: number; sales: number }[];
  weekRevenue: number;
  weekPrevRevenue: number;
}

export function AdminHome({ userName, onOpenGuide }: { userName?: string; onOpenGuide: () => void }) {
  const guide = useGuideProgress();
  const [data, setData] = useState<DaySummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(false);
    try { setData(await salesAPI.getDaySummary()); } catch { setError(true); } finally { setLoading(false); }
  }, []);
  useEffect(() => { load(); }, [load]);

  const hour = new Date().getHours();
  const greeting = hour < 12 ? t('stats:hola_manana') : hour < 19 ? t('stats:hola_tarde') : t('stats:hola_noche');
  const firstName = (userName || '').split(/\s+/)[0];
  const todayLabel = new Date().toLocaleDateString(getLocale(), { weekday: 'long', day: 'numeric', month: 'long' });

  return (
    <div className="space-y-5">
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-sm capitalize text-slate-500">{todayLabel}</p>
          <h1 className="mt-0.5 text-[1.75rem] font-semibold tracking-tight text-slate-950">{firstName ? `${greeting}, ${firstName}` : greeting}</h1>
        </div>
        <button
          type="button" onClick={load} disabled={loading}
          className="inline-flex h-9 items-center gap-2 rounded-full bg-white px-4 text-sm font-medium text-slate-700 shadow-card hover:bg-slate-50 disabled:opacity-50"
        >
          <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} aria-hidden /> {t('stats:actualizar')}
        </button>
      </header>

      {guide.loaded && !guide.progress.complete && guide.progress.total > 0 && (
        <GuideCard done={guide.progress.done} total={guide.progress.total} onOpen={onOpenGuide} />
      )}

      {error ? (
        <Card large><EmptyState title={t('stats:error_cargar')} action={<button type="button" onClick={load} className="h-10 rounded-[10px] bg-slate-950 px-4 text-sm font-medium text-white hover:bg-slate-800">{t('stats:reintentar')}</button>} /></Card>
      ) : !data ? <HomeSkeleton /> : (
        <div className={`space-y-4 transition-opacity duration-base ${loading ? 'opacity-60' : ''}`}>
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <KpiCard inverse label={t('stats:ingresos_hoy')} value={data.kpis.revenue} format={formatCurrency} now={data.kpis.revenue} before={data.prev.revenue} foot={t('stats:vs_ayer_hora')} />
            <KpiCard label={t('stats:ventas')} value={data.kpis.sales} format={int} now={data.kpis.sales} before={data.prev.sales} foot={t('stats:vs_ayer_hora')} />
            <KpiCard label={t('stats:ticket_promedio')} value={data.kpis.avgTicket} format={formatCurrency} now={data.kpis.avgTicket} before={data.prev.avgTicket} foot={t('stats:vs_ayer_hora')} />
            <KpiCard label={t('stats:productos_vendidos')} value={data.kpis.items} format={int} now={data.kpis.items} before={data.prev.items} foot={t('stats:vs_ayer_hora')} />
          </div>

          <div className="grid gap-4 lg:grid-cols-12">
            <Card large className="lg:col-span-7">
              <CardHeader title={t('stats:ventas_por_hora')} hint={t('stats:hoy_hasta_ahora')} />
              {data.kpis.sales === 0 ? <EmptyState compact title={t('stats:sin_ventas_hoy')} description={t('stats:sin_ventas_hoy_desc')} /> : (
                <BarChart
                  height={220}
                  showAverage={false}
                  data={visibleHours(data.hourly).map((h) => ({
                    key: String(h.hour), label: String(h.hour), value: h.revenue, highlight: h.hour === hour,
                    tooltip: { title: `${hourLabel(h.hour)} – ${hourLabel((h.hour + 1) % 24)}`, rows: [{ label: t('stats:ingresos'), value: formatCurrency(h.revenue), accent: true }, { label: t('stats:ventas'), value: int(h.sales) }] },
                  }))}
                />
              )}
            </Card>
            <Card large className="lg:col-span-5">
              <CardHeader title={t('stats:ultimos_7_dias')} hint={weekHint(data)} />
              <BarChart
                height={220}
                averageLabel={t('stats:prom')}
                data={data.week.map((d, i) => ({
                  key: d.date, label: fmtDay(d.date, { weekday: 'short' }).slice(0, 3), value: d.revenue, highlight: i === data.week.length - 1,
                  tooltip: { title: fmtDay(d.date, { weekday: 'long', day: 'numeric', month: 'short' }), rows: [{ label: t('stats:ingresos'), value: formatCurrency(d.revenue), accent: true }, { label: t('stats:ventas'), value: int(d.sales) }] },
                }))}
              />
            </Card>
          </div>

          <div className="grid gap-4 lg:grid-cols-2">
            <Card large>
              <CardHeader title={t('stats:lo_mas_vendido_hoy')} />
              {!data.products.length ? <EmptyState compact title={t('stats:sin_ventas_hoy')} /> : (
                <RankList numbered items={data.products.map((p) => ({ key: p.productId, label: p.name, sub: p.category || undefined, value: p.revenue, display: formatCurrency(p.revenue), aside: <span className="text-xs text-slate-500 num">{t('stats:n_unidades', { n: int(p.units) })}</span> }))} />
              )}
            </Card>
            <Card large>
              <CardHeader title={t('stats:medios_de_pago')} hint={t('stats:hoy_hasta_ahora')} />
              <PaymentsToday payments={data.payments} />
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}

/** Horas desde la primera hasta la actual (o la última con ventas), para no mostrar la madrugada vacía */
const visibleHours = (hourly: DaySummary['hourly']) => {
  const used = hourly.filter((h) => h.sales > 0).map((h) => h.hour);
  const now = new Date().getHours();
  const from = used.length ? Math.min(...used) : now;
  const to = Math.max(now, used.length ? Math.max(...used) : now);
  return hourly.slice(Math.max(0, Math.min(from, to - 5)), to + 1);
};

const weekHint = (d: DaySummary) => {
  const ch = delta(d.weekRevenue, d.weekPrevRevenue);
  const total = formatCurrency(d.weekRevenue);
  return ch === null ? total : t('stats:semana_vs', { amount: total, pct: `${ch > 0 ? '+' : ''}${ch.toFixed(1)}%` });
};

function PaymentsToday({ payments }: { payments: DaySummary['payments'] }) {
  const total = payments.reduce((a, p) => a + p.amount, 0);
  if (total <= 0) return <EmptyState compact title={t('stats:sin_pagos')} />;
  const slices = payments.map((p) => ({ key: p.method, label: paymentLabel(p.method), value: p.amount }));
  return (
    <div className="space-y-4">
      <StackBar slices={slices} />
      <ul className="space-y-2.5">
        {slices.map((s, i) => (
          <li key={s.key} className="flex items-center justify-between gap-3 text-sm">
            <span className="flex items-center gap-2">
              <span className={`h-2.5 w-2.5 rounded-sm ${SLICE_TONES[Math.min(i, SLICE_TONES.length - 1)]}`} aria-hidden />
              <span className="text-slate-700">{s.label}</span>
              <span className="text-xs text-slate-400 num">{Math.round((s.value / total) * 100)}%</span>
            </span>
            <span className="whitespace-nowrap font-medium text-slate-900 num">{formatCurrency(s.value)}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function GuideCard({ done, total, onOpen }: { done: number; total: number; onOpen: () => void }) {
  const pct = Math.round((done / total) * 100);
  return (
    <Card large className="lt-enter flex flex-col gap-4 sm:flex-row sm:items-center">
      <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-blue-50 text-blue-700"><Compass className="h-5 w-5" aria-hidden /></span>
      <div className="min-w-0 flex-1">
        <p className="font-semibold text-slate-900">{t('stats:guia_titulo')}</p>
        <div className="mt-2 flex items-center gap-3">
          <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-slate-100" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100}>
            <div className="h-full rounded-full bg-blue-600 transition-[width] duration-slow ease-out" style={{ width: `${pct}%` }} />
          </div>
          <span className="whitespace-nowrap text-xs text-slate-500 num">{t('stats:guia_avance', { done, total })}</span>
        </div>
      </div>
      <button type="button" onClick={onOpen} className="inline-flex h-10 shrink-0 items-center gap-2 rounded-[10px] bg-slate-950 px-4 text-sm font-medium text-white hover:bg-slate-800">
        {t('stats:guia_continuar')} <ArrowRight className="h-4 w-4" aria-hidden />
      </button>
    </Card>
  );
}

function HomeSkeleton() {
  return (
    <div className="space-y-4" aria-busy>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-[148px] rounded-[22px]" />)}</div>
      <div className="grid gap-4 lg:grid-cols-12"><Skeleton className="h-[300px] rounded-[22px] lg:col-span-7" /><Skeleton className="h-[300px] rounded-[22px] lg:col-span-5" /></div>
    </div>
  );
}

export default AdminHome;
