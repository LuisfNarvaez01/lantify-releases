// ============================================
// ADMIN - Salón y mesas → QR de las mesas (Fase 4 · pedido desde la mesa)
// ============================================
// Cada mesa tiene su QR: el cliente lo escanea, ve la carta y pide; el pedido llega
// al mesero para aceptarlo. Se imprimen todos de una vez o mesa por mesa (hoja carta,
// para recortar y poner en un portamenú). Si un QR se pierde o lo copian, se cambia el de esa mesa.

import { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { Printer, QrCode, RefreshCw } from 'lucide-react';
import { t } from '../../i18n';
import { toast } from '../../shared/toast';
import { confirmDialog } from '../../shared/dialog';
import { useFeatureFlag } from '../../shared/features';
import { tableOrdersAPI, type TableQrSheet } from '../../services/v3Api';
import { Button } from '../common/Button';

const esc = (s: string) => s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c] as string));

/** Hoja para imprimir: tres QR por fila con el número de la mesa */
const printSheet = (business: string, cards: { label: string; qr: string }[]) => {
  document.getElementById('table-qr-print')?.remove();
  const iframe = document.createElement('iframe');
  iframe.id = 'table-qr-print';
  iframe.title = 'QR';
  Object.assign(iframe.style, { position: 'fixed', right: '0', bottom: '0', width: '0', height: '0', border: '0' });
  document.body.appendChild(iframe);
  const doc = iframe.contentWindow?.document;
  if (!doc) return;
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>${esc(business)}</title><style>
    @page { size: letter; margin: 10mm; }
    body { font-family: system-ui, sans-serif; margin: 0; }
    .grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 6mm; }
    .card { border: 1px dashed #94a3b8; border-radius: 4mm; padding: 5mm; text-align: center; break-inside: avoid; }
    .card img { width: 100%; max-width: 50mm; }
    .mesa { font-size: 20pt; font-weight: 800; margin: 2mm 0 0; }
    .hint { font-size: 9pt; color: #334155; margin: 1mm 0 0; }
    .biz { font-size: 8pt; color: #64748b; margin: 1mm 0 0; }
  </style></head><body><div class="grid">${cards.map((c) => `<div class="card"><img src="${c.qr}" alt=""><p class="mesa">${esc(t('v3:mesa_qr_mesa', { number: c.label }))}</p><p class="hint">${esc(t('v3:mesa_qr_hint'))}</p><p class="biz">${esc(business)}</p></div>`).join('')}</div>
  <script>window.onload = function () { setTimeout(function () { window.focus(); window.print(); }, 200); };</script></body></html>`;
  doc.open();
  doc.write(html);
  doc.close();
};

export function TableQrPanel() {
  const on = useFeatureFlag('table_ordering');
  const [sheet, setSheet] = useState<TableQrSheet | null>(null);
  const [qrs, setQrs] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);

  const load = () => tableOrdersAPI.qr().then(setSheet).catch((err) => toast.error(err?.message || t('v3:no_se_guardo')));
  useEffect(() => { load(); }, []);
  useEffect(() => {
    if (!sheet) return;
    let alive = true;
    Promise.all(sheet.tables.filter((x) => x.url).map(async (x) => [x.id, await QRCode.toDataURL(x.url!, { margin: 1, width: 480, errorCorrectionLevel: 'M' })] as const))
      .then((pairs) => alive && setQrs(Object.fromEntries(pairs)))
      .catch(() => undefined);
    return () => { alive = false; };
  }, [sheet]);

  const rotate = async (id: string, label: string) => {
    if (!(await confirmDialog({ title: t('v3:mesa_qr_cambiar_titulo', { number: label }), message: t('v3:mesa_qr_cambiar_desc'), tone: 'danger' }))) return;
    setBusy(true);
    try {
      setSheet(await tableOrdersAPI.rotate(id));
      toast.success(t('v3:mesa_qr_cambiado', { number: label }));
    } catch (err: any) {
      toast.error(err?.message || t('v3:no_se_guardo'));
    } finally {
      setBusy(false);
    }
  };

  const ready = sheet?.tables.filter((x) => qrs[x.id]) || [];

  return (
    <section className="space-y-4 rounded-3xl border border-slate-200/80 bg-white p-6 shadow-sm sm:p-8" aria-labelledby="mesa-qr-title">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-blue-50 text-blue-700"><QrCode className="h-5 w-5" aria-hidden /></span>
          <div>
            <h3 id="mesa-qr-title" className="font-heading text-base font-bold text-slate-900">{t('v3:mesa_qr_titulo')}</h3>
            <p className="text-sm text-slate-500">{t('v3:mesa_qr_desc')}</p>
          </div>
        </div>
        <Button onClick={() => sheet && printSheet(sheet.businessName, ready.map((x) => ({ label: x.label, qr: qrs[x.id] })))} disabled={!ready.length}>
          <Printer className="h-4 w-4" aria-hidden /> {t('v3:mesa_qr_imprimir', { count: ready.length })}
        </Button>
      </div>
      {!on && <p className="rounded-xl bg-amber-50 p-3 text-sm text-amber-900">{t('v3:mesa_qr_apagado')}</p>}
      {sheet && !sheet.published && <p className="rounded-xl bg-amber-50 p-3 text-sm text-amber-900">{t('v3:mesa_qr_sin_pagina')}</p>}
      {sheet && sheet.tables.length === 0 && <p className="text-sm text-slate-500">{t('v3:mesa_qr_sin_mesas')}</p>}
      <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {sheet?.tables.map((x) => (
          <li key={x.id} className="flex flex-col items-center gap-2 rounded-2xl border border-slate-200 p-3 text-center">
            {qrs[x.id] ? <img src={qrs[x.id]} alt={t('v3:mesa_qr_mesa', { number: x.label })} className="aspect-square w-full max-w-[9rem]" /> : <span className="grid aspect-square w-full max-w-[9rem] place-items-center rounded-xl bg-slate-50 text-slate-300"><QrCode className="h-10 w-10" aria-hidden /></span>}
            <span className="font-heading text-lg font-black text-slate-900">{t('v3:mesa_qr_mesa', { number: x.label })}</span>
            <div className="flex flex-wrap justify-center gap-1">
              <button type="button" disabled={!qrs[x.id]} onClick={() => sheet && printSheet(sheet.businessName, [{ label: x.label, qr: qrs[x.id] }])} className="inline-flex min-h-[36px] items-center gap-1 rounded-lg px-2 text-xs font-semibold text-blue-700 hover:bg-blue-50 disabled:opacity-50">
                <Printer className="h-3.5 w-3.5" aria-hidden /> {t('v3:mesa_qr_imprimir_una')}
              </button>
              <button type="button" disabled={busy} onClick={() => rotate(x.id, x.label)} className="inline-flex min-h-[36px] items-center gap-1 rounded-lg px-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 disabled:opacity-50">
                <RefreshCw className="h-3.5 w-3.5" aria-hidden /> {t('v3:mesa_qr_cambiar')}
              </button>
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}
