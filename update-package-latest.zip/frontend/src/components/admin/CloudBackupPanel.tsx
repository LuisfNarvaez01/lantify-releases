// ============================================
// ADMIN - Copia de seguridad en Lantify Cloud
// ============================================
// Una copia liviana y cifrada de la base, una por negocio (cada una reemplaza la anterior).
// Se sube sola una vez al día y al cerrar la caja. Desde aquí se sube a mano o se restaura
// (de la nube o del archivo que el cliente descargó en Mi cuenta).

import { useEffect, useRef, useState } from 'react';
import { UploadCloud, Download, FileUp, Loader2, ShieldCheck } from 'lucide-react';
import { CloudBackupStatus, systemAPI } from '../../services/api';
import { errorMessage } from '../../services/apiErrors';
import { confirmDialog } from '../../shared/dialog';
import { toast } from '../../shared/toast';
import { getLocale, t } from '../../i18n';

const size = (bytes: number) => (bytes >= 1048576 ? `${(bytes / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(bytes / 1024))} KB`);
const when = (iso: string | null | undefined) => (iso ? new Date(iso).toLocaleString(getLocale(), { dateStyle: 'medium', timeStyle: 'short' }) : '—');

export function CloudBackupPanel() {
  const [status, setStatus] = useState<CloudBackupStatus | null>(null);
  const [busy, setBusy] = useState<'upload' | 'restore' | null>(null);
  const [restarting, setRestarting] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);

  const load = () => systemAPI.cloudBackupStatus().then(setStatus).catch(() => setStatus(null));
  useEffect(() => {
    load();
  }, []);

  const upload = async () => {
    setBusy('upload');
    try {
      await systemAPI.cloudBackupUpload();
      toast.success(t('settings:nube_subida'));
      await load();
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusy(null);
    }
  };

  // Tras restaurar, Lantify reinicia su servidor: se espera a que vuelva y se recarga la caja
  const waitAndReload = () => {
    setRestarting(true);
    const started = Date.now();
    const poll = async () => {
      try {
        // Cualquier respuesta del servidor (aunque pida volver a entrar) significa que ya arrancó
        await fetch(`${window.location.origin}/health`, { cache: 'no-store' });
        if (Date.now() - started > 6000) return window.location.reload();
      } catch {
        /* reiniciando */
      }
      if (Date.now() - started < 5 * 60 * 1000) setTimeout(poll, 1500);
    };
    setTimeout(poll, 2500);
  };

  const restore = async (file?: File) => {
    const ok = await confirmDialog({
      title: t('settings:nube_restaurar_titulo'),
      message: file ? t('settings:nube_restaurar_archivo_desc', { name: file.name }) : t('settings:nube_restaurar_desc', { date: when(status?.cloud?.createdAt) }),
      confirmLabel: t('settings:nube_restaurar_confirmar'),
      tone: 'danger',
    });
    if (!ok) return;
    setBusy('restore');
    try {
      if (file) await systemAPI.cloudBackupRestoreFile(file);
      else await systemAPI.cloudBackupRestore();
      waitAndReload();
    } catch (e) {
      toast.error(errorMessage(e));
      setBusy(null);
    }
  };

  const cloud = status?.cloud;
  const counts = cloud?.counts ? Object.entries(cloud.counts).filter(([, n]) => n > 0) : [];

  return (
    <div className="p-6 bg-slate-50 border border-slate-200 rounded-2xl space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-sky-100 text-sky-700 flex items-center justify-center shrink-0">
            <UploadCloud className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-bold text-sm text-slate-900">{t('settings:nube_titulo')}</h4>
            <p className="text-xs text-slate-500 mt-0.5 max-w-xl">{t('settings:nube_desc')}</p>
          </div>
        </div>
        <button
          type="button"
          onClick={upload}
          disabled={!!busy || restarting || status?.linked === false}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-xl font-bold text-xs shadow-sm transition-all disabled:opacity-50 shrink-0"
        >
          {busy === 'upload' ? <Loader2 className="w-4 h-4 animate-spin" /> : <UploadCloud className="w-4 h-4" />}
          {busy === 'upload' ? t('settings:nube_subiendo') : t('settings:nube_subir_ahora')}
        </button>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 p-4 text-sm" role="status">
        {restarting ? (
          <p className="flex items-center gap-2 font-bold text-slate-800">
            <Loader2 className="w-4 h-4 animate-spin" /> {t('settings:nube_reiniciando')}
          </p>
        ) : !status ? (
          <p className="text-slate-400 text-xs">{t('settings:cargando_respaldos')}</p>
        ) : status.linked === false ? (
          <p className="text-slate-600">{t('settings:nube_sin_vincular')}</p>
        ) : cloud ? (
          <div className="space-y-1">
            <p className="flex items-center gap-2 font-bold text-slate-900">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              {t('settings:nube_ultima', { date: when(cloud.createdAt), size: size(cloud.sizeBytes) })}
            </p>
            <p className="text-xs text-slate-500">
              {[cloud.device, counts.map(([k, n]) => `${n} ${t(`settings:nube_cuenta_${k}`, { defaultValue: k })}`).join(' · ')].filter(Boolean).join(' · ')}
            </p>
          </div>
        ) : status.cloudError && status.cloudError !== 'BACKUP_NOT_FOUND' ? (
          <p className="text-amber-700 text-xs">{t('settings:nube_sin_conexion')}</p>
        ) : (
          <p className="text-slate-600">{t('settings:nube_aun_no')}</p>
        )}
        {status?.lastError && !restarting && (
          <p className="mt-2 text-xs text-amber-700">{t('settings:nube_ultimo_error', { date: when(status.lastAttemptAt), code: status.lastError })}</p>
        )}
      </div>

      {status?.canRestore && !restarting && (
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => restore()}
            disabled={!!busy || !cloud}
            className="flex items-center gap-2 bg-white border border-slate-200 text-slate-700 hover:border-red-300 hover:text-red-700 px-4 py-2 rounded-xl font-bold text-xs transition-all disabled:opacity-50"
          >
            {busy === 'restore' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
            {t('settings:nube_restaurar')}
          </button>
          <button
            type="button"
            onClick={() => fileInput.current?.click()}
            disabled={!!busy}
            className="flex items-center gap-2 bg-white border border-slate-200 text-slate-700 hover:border-red-300 hover:text-red-700 px-4 py-2 rounded-xl font-bold text-xs transition-all disabled:opacity-50"
          >
            <FileUp className="w-4 h-4" /> {t('settings:nube_restaurar_archivo')}
          </button>
          <input
            ref={fileInput}
            type="file"
            accept=".gz,application/gzip"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              e.target.value = '';
              if (f) restore(f);
            }}
          />
        </div>
      )}
      <p className="text-xs text-slate-500">{t('settings:nube_nota')}</p>
    </div>
  );
}
