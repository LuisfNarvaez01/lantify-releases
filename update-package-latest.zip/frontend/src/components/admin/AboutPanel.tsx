// ============================================
// ADMIN - Acerca de Lantify (Configuración)
// ============================================
// La versión instalada, sus novedades y buscar actualizaciones (antes estaba en
// el encabezado). Debajo, "Recomienda Lantify": el enlace del negocio para invitar
// a otros; cuando el invitado hace su primer pago, este negocio gana dos meses.

import { useEffect, useState } from 'react';
import { CheckCircle2, Copy, Check, Gift, Loader2, RefreshCw, Share2 } from 'lucide-react';
import { versionAPI, referralAPI, ReferralInfo } from '../../services/api';
import { UpdateModal } from '../common/UpdateModal';
import { errorMessage } from '../../services/apiErrors';
import { toast } from '../../shared/toast';
import { getLocale, t } from '../../i18n';

interface VersionInfo {
  version?: string;
  buildDate?: string;
  releaseName?: string;
  changelog?: string;
  features?: string[];
}

const fmtDate = (iso?: string | null) => (iso ? new Date(iso).toLocaleDateString(getLocale(), { dateStyle: 'medium' }) : '—');

function ReferralCard() {
  const [info, setInfo] = useState<ReferralInfo | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    referralAPI.get().then(setInfo).catch((e) => setError(errorMessage(e)));
  }, []);

  const copy = async () => {
    if (!info) return;
    try {
      await navigator.clipboard.writeText(info.link);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // sin portapapeles: el enlace queda seleccionable en pantalla
    }
  };
  const shareText = info ? t('about:mensaje_compartir', { link: info.link }) : '';

  return (
    <section className="bg-surface border border-line rounded-2xl p-6" aria-labelledby="referidos-titulo">
      <div className="flex items-start gap-3">
        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-amber-100 text-amber-700" aria-hidden>
          <Gift className="h-5 w-5" />
        </span>
        <div className="min-w-0">
          <h3 id="referidos-titulo" className="text-sm font-bold text-fg">{t('about:referidos_titulo', { months: info?.rewardMonths ?? 2 })}</h3>
          <p className="mt-1 text-xs text-fg-secondary leading-relaxed max-w-lg">{t('about:referidos_desc', { months: info?.rewardMonths ?? 2 })}</p>
        </div>
      </div>

      {error && <p className="mt-4 text-xs text-fg-muted">{t('about:referidos_sin_conexion')}</p>}
      {!info && !error && <p className="mt-4 flex items-center gap-2 text-xs text-fg-muted"><Loader2 className="h-4 w-4 animate-spin" aria-hidden /> {t('about:cargando')}</p>}

      {info && (
        <>
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <code className="min-w-0 flex-1 truncate select-all rounded-xl border border-line bg-surface-sunken px-3 py-2.5 text-xs text-fg">{info.link}</code>
            <button type="button" onClick={copy}
              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-line px-3 text-xs font-bold text-fg hover:bg-surface-muted">
              {copied ? <Check className="h-4 w-4" aria-hidden /> : <Copy className="h-4 w-4" aria-hidden />}
              {copied ? t('about:copiado') : t('about:copiar_enlace')}
            </button>
            <a href={`https://wa.me/?text=${encodeURIComponent(shareText)}`} target="_blank" rel="noreferrer"
              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl bg-emerald-600 px-3 text-xs font-bold text-white hover:bg-emerald-700">
              <Share2 className="h-4 w-4" aria-hidden /> {t('about:compartir_whatsapp')}
            </a>
          </div>
          <p className="mt-2 text-[11px] text-fg-muted">{t('about:tu_codigo', { code: info.code })}</p>

          <dl className="mt-4 grid grid-cols-2 gap-3 text-sm">
            <div className="rounded-xl bg-surface-sunken px-3 py-2">
              <dt className="text-[11px] text-fg-muted">{t('about:invitados')}</dt>
              <dd className="font-bold text-fg tabular-nums">{info.invited.length}</dd>
            </div>
            <div className="rounded-xl bg-surface-sunken px-3 py-2">
              <dt className="text-[11px] text-fg-muted">{t('about:meses_ganados')}</dt>
              <dd className="font-bold text-fg tabular-nums">{info.monthsEarned}</dd>
            </div>
          </dl>

          {info.invited.length > 0 && (
            <ul className="mt-3 divide-y divide-line text-xs">
              {info.invited.slice(0, 8).map((r, i) => (
                <li key={`${r.createdAt}-${i}`} className="flex items-center justify-between gap-2 py-2">
                  <span className="truncate text-fg">{r.name}</span>
                  <span className={`shrink-0 rounded-full px-2 py-0.5 font-bold ${r.status === 'REWARDED' ? 'bg-success-soft text-success-text' : 'bg-surface-sunken text-fg-muted'}`}>
                    {r.status === 'REWARDED' ? t('about:estado_premiado', { date: fmtDate(r.rewardedAt) }) : t('about:estado_pendiente')}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </>
      )}
    </section>
  );
}

export function AboutPanel() {
  const [version, setVersion] = useState<VersionInfo | null>(null);
  const [checking, setChecking] = useState(false);
  const [update, setUpdate] = useState<any>(null);

  useEffect(() => {
    versionAPI.get().then(setVersion).catch(() => setVersion({}));
  }, []);

  const checkUpdates = async () => {
    setChecking(true);
    try {
      const res = await versionAPI.checkUpdate();
      if (res?.updateAvailable) setUpdate(res);
      else toast.success(t('about:al_dia'));
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setChecking(false);
    }
  };

  return (
    <div className="space-y-4 max-w-3xl">
      <section className="bg-surface border border-line rounded-2xl p-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <img src="/logo-lantify.svg" alt="" className="h-10 w-auto" />
            <div>
              <h3 className="text-xl font-bold text-fg">Lantify POS</h3>
              <p className="text-sm text-fg-secondary tabular-nums">
                {t('about:version', { value: version?.version || '—' })} · {fmtDate(version?.buildDate)}
              </p>
            </div>
          </div>
          <button type="button" onClick={checkUpdates} disabled={checking}
            className="inline-flex min-h-[40px] items-center gap-2 rounded-xl border border-line px-4 text-xs font-bold text-fg hover:bg-surface-muted disabled:opacity-60">
            <RefreshCw className={`h-4 w-4 ${checking ? 'animate-spin' : ''}`} aria-hidden />
            {checking ? t('about:buscando') : t('about:buscar_actualizaciones')}
          </button>
        </div>

        {version?.features && version.features.length > 0 && (
          <div className="mt-5">
            <h4 className="text-xs font-bold text-fg-muted">{t('about:novedades')}</h4>
            <ul className="mt-2 space-y-1.5">
              {version.features.map((f) => (
                <li key={f} className="flex items-start gap-2 text-sm text-fg">
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-success-text" aria-hidden />
                  <span>{f}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </section>

      <ReferralCard />

      {update && <UpdateModal updateData={update} onClose={() => setUpdate(null)} />}
    </div>
  );
}
