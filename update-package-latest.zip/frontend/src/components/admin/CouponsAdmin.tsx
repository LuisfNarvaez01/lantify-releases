// ============================================
// ADMIN - Cupones y promociones
// ============================================
// La caja aplica el cupón al cobrar y el servidor calcula el descuento. Aquí se
// crean a mano o llegan del agente de marketing (marcados con ✨).

import { FormEvent, useEffect, useState } from 'react';
import { Plus, Sparkles, Ticket } from 'lucide-react';
import { couponsAPI, Coupon } from '../../services/api';
import { errorMessage } from '../../services/apiErrors';
import { formatCurrency } from '../../shared/formatUtils';
import { toast } from '../../shared/toast';
import { useFeature } from '../../shared/plan';
import { PlanLocked } from '../common/PlanLocked';
import { t, getLocale } from '../../i18n';

const inputCls = 'w-full min-h-[42px] px-3 rounded-xl border border-slate-200 bg-white text-sm focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20';
const empty = { code: '', description: '', type: 'PERCENT' as 'PERCENT' | 'AMOUNT', value: '', minPurchase: '', endsAt: '', maxUses: '' };

const label = (c: Coupon) => (c.type === 'PERCENT' ? `${c.value} %` : formatCurrency(c.value));
const statusOf = (c: Coupon) => {
  if (!c.isActive) return 'inactivo';
  if (c.endsAt && new Date(c.endsAt) < new Date()) return 'vencido';
  if (c.maxUses && c.uses >= c.maxUses) return 'agotado';
  return 'activo';
};

export function CouponsAdmin() {
  const allowed = useFeature('coupons');
  const [list, setList] = useState<Coupon[]>([]);
  const [form, setForm] = useState(empty);
  const [open, setOpen] = useState(false);

  const load = () => couponsAPI.list().then(setList).catch((e) => toast.error(errorMessage(e)));
  useEffect(() => {
    if (allowed) load();
  }, [allowed]);

  if (!allowed) return <PlanLocked feature="coupons" />;

  const create = async (e: FormEvent) => {
    e.preventDefault();
    try {
      await couponsAPI.create({
        code: form.code,
        description: form.description || null,
        type: form.type,
        value: Number(form.value),
        minPurchase: form.minPurchase ? Number(form.minPurchase) : null,
        endsAt: form.endsAt ? `${form.endsAt}T23:59:59` : null,
        maxUses: form.maxUses ? Number(form.maxUses) : null,
      });
      toast.success(t('coupons:creado', { code: form.code.toUpperCase() }));
      setForm(empty);
      setOpen(false);
      load();
    } catch (err) {
      toast.error(errorMessage(err));
    }
  };

  const toggle = async (c: Coupon) => {
    try {
      await couponsAPI.update(c.id, { isActive: !c.isActive });
      load();
    } catch (err) {
      toast.error(errorMessage(err));
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 font-heading">{t('coupons:titulo')}</h2>
          <p className="mt-1 text-sm text-slate-500">{t('coupons:bajada')}</p>
        </div>
        <button type="button" onClick={() => setOpen((v) => !v)} className="inline-flex items-center gap-2 min-h-[46px] px-5 rounded-xl bg-blue-600 text-sm font-bold text-white hover:bg-blue-700">
          <Plus className="w-4 h-4" aria-hidden /> {t('coupons:nuevo')}
        </button>
      </div>

      {open && (
        <form onSubmit={create} className="grid gap-3 rounded-2xl border border-slate-200 bg-white p-5 sm:grid-cols-3">
          <label className="block sm:col-span-1">
            <span className="text-xs font-bold text-slate-600">{t('coupons:codigo')}</span>
            <input className={`${inputCls} mt-1 uppercase font-bold tracking-wide`} value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })} placeholder="MARTES20" maxLength={24} required />
          </label>
          <label className="block">
            <span className="text-xs font-bold text-slate-600">{t('coupons:tipo')}</span>
            <select className={`${inputCls} mt-1`} value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value as 'PERCENT' | 'AMOUNT' })}>
              <option value="PERCENT">{t('coupons:porcentaje')}</option>
              <option value="AMOUNT">{t('coupons:valor_fijo')}</option>
            </select>
          </label>
          <label className="block">
            <span className="text-xs font-bold text-slate-600">{form.type === 'PERCENT' ? t('coupons:descuento_pct') : t('coupons:descuento_valor')}</span>
            <input className={`${inputCls} mt-1`} type="number" min={1} max={form.type === 'PERCENT' ? 100 : undefined} value={form.value} onChange={(e) => setForm({ ...form, value: e.target.value })} required />
          </label>
          <label className="block">
            <span className="text-xs font-bold text-slate-600">{t('coupons:compra_minima')}</span>
            <input className={`${inputCls} mt-1`} type="number" min={0} value={form.minPurchase} onChange={(e) => setForm({ ...form, minPurchase: e.target.value })} placeholder={t('coupons:opcional')} />
          </label>
          <label className="block">
            <span className="text-xs font-bold text-slate-600">{t('coupons:vence')}</span>
            <input className={`${inputCls} mt-1`} type="date" value={form.endsAt} onChange={(e) => setForm({ ...form, endsAt: e.target.value })} />
          </label>
          <label className="block">
            <span className="text-xs font-bold text-slate-600">{t('coupons:usos_maximos')}</span>
            <input className={`${inputCls} mt-1`} type="number" min={1} value={form.maxUses} onChange={(e) => setForm({ ...form, maxUses: e.target.value })} placeholder={t('coupons:sin_limite')} />
          </label>
          <label className="block sm:col-span-3">
            <span className="text-xs font-bold text-slate-600">{t('coupons:descripcion')}</span>
            <input className={`${inputCls} mt-1`} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} maxLength={200} placeholder={t('coupons:descripcion_ej')} />
          </label>
          <div className="sm:col-span-3">
            <button type="submit" className="min-h-[44px] px-6 rounded-xl bg-slate-900 text-sm font-bold text-white">{t('coupons:crear')}</button>
          </div>
        </form>
      )}

      {list.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-slate-300 bg-white px-6 py-14 text-center">
          <Ticket className="mx-auto w-10 h-10 text-slate-300" aria-hidden />
          <p className="mt-3 font-bold text-slate-700">{t('coupons:vacio')}</p>
          <p className="mt-1 text-sm text-slate-500">{t('coupons:vacio_desc')}</p>
        </div>
      ) : (
        <ul className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {list.map((c) => {
            const st = statusOf(c);
            return (
              <li key={c.id} className={`rounded-2xl border bg-white p-4 ${st === 'activo' ? 'border-slate-200' : 'border-slate-200 opacity-60'}`}>
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-black tracking-wide text-slate-900">{c.code}</p>
                    <p className="text-2xl font-black tabular-nums text-blue-700">-{label(c)}</p>
                  </div>
                  <span className={`rounded-full px-2.5 py-0.5 text-xs font-bold ${st === 'activo' ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-600'}`}>{t(`coupons:estado_${st}`)}</span>
                </div>
                {c.description && <p className="mt-2 text-sm text-slate-600">{c.description}</p>}
                <p className="mt-2 text-xs text-slate-500">
                  {c.minPurchase ? `${t('coupons:desde', { amount: formatCurrency(c.minPurchase) })} · ` : ''}
                  {t('coupons:usos', { uses: c.uses, max: c.maxUses ?? '∞' })}
                  {c.endsAt ? ` · ${t('coupons:hasta', { date: new Date(c.endsAt).toLocaleDateString(getLocale(), { day: '2-digit', month: 'short' }) })}` : ''}
                </p>
                <div className="mt-3 flex items-center justify-between">
                  {c.source === 'AGENT' ? (
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-violet-700"><Sparkles className="w-3 h-3" aria-hidden />{t('coupons:del_agente')}</span>
                  ) : <span />}
                  <button type="button" onClick={() => toggle(c)} className="text-xs font-bold text-slate-600 hover:text-slate-900 underline">
                    {c.isActive ? t('coupons:desactivar') : t('coupons:activar')}
                  </button>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
