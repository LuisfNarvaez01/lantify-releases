// ============================================
// ADMIN - Probar conexión de celulares y tablets (Lantify 3.0)
// ============================================
// Revisa desde la caja lo que impide que un celular entre y dice cómo arreglarlo.
// Lo que no se puede ver desde la caja (datos móviles, red de invitados) se explica.

import React, { useState } from 'react';
import { AlertTriangle, CheckCircle2, Loader2, ShieldCheck, Stethoscope, Wifi } from 'lucide-react';
import { API_URL } from '../../config';
import { responseError, errorMessage } from '../../services/apiErrors';
import { toast } from '../../shared/toast';
import { t } from '../../i18n';

interface Diagnosis {
  platform: string; lanEnabled: boolean; port: number; uiPort: number; program: string;
  addresses: { ip: string; iface: string; virtual: boolean }[];
  firewall: { allowed: boolean; blocked: number } | null;
  networks: { alias: string; category: string }[];
  problems: string[];
}

const call = async <T,>(method: string, path: string): Promise<T> => {
  const token = localStorage.getItem('token');
  const res = await fetch(`${API_URL}${path}`, { method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) } });
  const body = await res.json().catch(() => null);
  if (!res.ok) throw responseError(res.status, body);
  return body as T;
};

const FIXABLE = new Set(['FIREWALL', 'PUBLIC_NETWORK']);

export const ConnectionDoctor: React.FC = () => {
  const [d, setD] = useState<Diagnosis | null>(null);
  const [busy, setBusy] = useState<'check' | 'repair' | null>(null);

  const check = async () => {
    setBusy('check');
    try { setD(await call<Diagnosis>('GET', '/permissions/devices/doctor')); } catch (e) { toast.error(errorMessage(e)); } finally { setBusy(null); }
  };
  const fix = async () => {
    setBusy('repair');
    try {
      const r = await call<{ ok: boolean; diagnosis: Diagnosis }>('POST', '/permissions/devices/repair');
      setD(r.diagnosis);
      if (r.ok) toast.success(t('roles:doc_reparado')); else toast.warning(t('roles:doc_no_reparado'));
    } catch (e) { toast.error(errorMessage(e)); } finally { setBusy(null); }
  };

  const real = d?.addresses.filter((a) => !a.virtual) || [];
  const ok = d && d.problems.length === 0;
  return (
    <div className="mt-5 space-y-3 border-t border-slate-100 pt-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="flex items-center gap-2 text-sm font-bold text-slate-900"><Stethoscope className="h-4 w-4 text-blue-700" aria-hidden />{t('roles:doc_titulo')}</p>
        <button type="button" onClick={check} disabled={busy !== null} className="inline-flex min-h-[40px] items-center gap-2 rounded-xl bg-slate-900 px-4 text-sm font-bold text-white disabled:opacity-60">
          {busy === 'check' ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <Stethoscope className="h-4 w-4" aria-hidden />}{t('roles:doc_probar')}
        </button>
      </div>

      {d && (
        <div className={`rounded-2xl border p-4 ${ok ? 'border-emerald-200 bg-emerald-50' : 'border-amber-200 bg-amber-50'}`} role="status">
          {ok ? (
            <p className="flex items-center gap-2 font-bold text-emerald-900"><CheckCircle2 className="h-5 w-5" aria-hidden />{t('roles:doc_ok')}</p>
          ) : (
            <ul className="space-y-3">
              {d.problems.map((p) => (
                <li key={p} className="flex gap-2 text-sm text-amber-950">
                  <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-700" aria-hidden />
                  <span>
                    <span className="block font-bold">{t(`roles:doc_p_${p}`)}</span>
                    <span className="block">{t(`roles:doc_s_${p}`, { ips: real.map((a) => `${a.ip} (${a.iface})`).join(', '), networks: d.networks.map((n) => n.alias).join(', ') })}</span>
                  </span>
                </li>
              ))}
            </ul>
          )}
          {d.problems.some((p) => FIXABLE.has(p)) && (
            <button type="button" onClick={fix} disabled={busy !== null} className="mt-3 inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-blue-700 px-4 text-sm font-bold text-white disabled:opacity-60">
              {busy === 'repair' ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <ShieldCheck className="h-4 w-4" aria-hidden />}{t('roles:doc_reparar')}
            </button>
          )}
        </div>
      )}

      <details className="rounded-2xl border border-slate-200 bg-slate-50 p-4 text-sm text-slate-700">
        <summary className="flex cursor-pointer items-center gap-2 font-bold text-slate-900"><Wifi className="h-4 w-4" aria-hidden />{t('roles:doc_celular_titulo')}</summary>
        <ol className="mt-3 list-decimal space-y-1.5 pl-5">
          {[1, 2, 3, 4, 5].map((i) => <li key={i}>{t(`roles:doc_celular_${i}`)}</li>)}
        </ol>
      </details>
    </div>
  );
};
