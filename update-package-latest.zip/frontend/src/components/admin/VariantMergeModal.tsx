// ============================================
// ADMIN - Productos: unificar productos sueltos en variantes
// ============================================
// Lantify busca productos que en realidad son presentaciones del mismo producto
// ("Batido de fresa 12 oz" y "Batido de fresa 16 oz", "Jugo de mora en agua" y
// "en leche") y propone juntarlos. Se pueden unir todos los marcados de una vez
// o revisarlos uno por uno: cambiar el nombre del producto, el de cada
// presentación o sacar alguno del grupo. Ventas, inventario y precios se conservan.

import { useEffect, useMemo, useState } from 'react';
import { Check, Layers, Loader2, X } from 'lucide-react';
import { productsAPI, VariantGroup } from '../../services/api';
import { errorMessage } from '../../services/apiErrors';
import { confirmDialog } from '../../shared/dialog';
import { toast } from '../../shared/toast';
import { formatCurrency } from '../../shared/formatUtils';
import { mediaSrc } from '../../shared/media';
import { t } from '../../i18n';

interface Draft {
  on: boolean;
  base: string;
  include: Record<string, boolean>;
  labels: Record<string, string>;
}

const draftOf = (g: VariantGroup): Draft => ({
  on: true,
  base: g.base,
  include: Object.fromEntries(g.items.map((i) => [i.productId, true])),
  labels: Object.fromEntries(g.items.map((i) => [i.productId, i.label])),
});

export function VariantMergeModal({ onClose, onMerged }: { onClose: () => void; onMerged: () => void }) {
  const [groups, setGroups] = useState<VariantGroup[] | null>(null);
  const [drafts, setDrafts] = useState<Record<string, Draft>>({});
  const [busy, setBusy] = useState<string | null>(null);

  const load = async () => {
    try {
      const g = await productsAPI.variantGroups();
      setGroups(g);
      setDrafts(Object.fromEntries(g.map((x) => [x.key, draftOf(x)])));
    } catch (e) {
      toast.error(errorMessage(e));
      setGroups([]);
    }
  };
  useEffect(() => {
    load();
  }, []);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && !busy && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [busy, onClose]);

  const patch = (key: string, p: Partial<Draft>) => setDrafts((d) => ({ ...d, [key]: { ...d[key], ...p } }));
  const chosenIds = (key: string) => Object.entries(drafts[key]?.include || {}).filter(([, v]) => v).map(([id]) => id);
  const ready = useMemo(() => (groups || []).filter((g) => drafts[g.key]?.on && chosenIds(g.key).length >= 2), [groups, drafts]); // eslint-disable-line react-hooks/exhaustive-deps

  const mergeOne = async (g: VariantGroup) => {
    const d = drafts[g.key];
    const ids = chosenIds(g.key);
    await productsAPI.mergeVariants({ base: d.base.trim(), productIds: ids, labels: Object.fromEntries(ids.map((id) => [id, d.labels[id] || ''])) });
  };

  const runOne = async (g: VariantGroup) => {
    setBusy(g.key);
    try {
      await mergeOne(g);
      toast.success(t('products:unir_listo_uno', { name: drafts[g.key].base }));
      setGroups((gs) => (gs || []).filter((x) => x.key !== g.key));
      onMerged();
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusy(null);
    }
  };

  const runAll = async () => {
    if (!ready.length) return;
    if (!(await confirmDialog({ title: t('products:unir_todos_titulo', { count: ready.length }), message: t('products:unir_todos_desc'), confirmLabel: t('products:unir_todos_si') }))) return;
    setBusy('*');
    let ok = 0;
    const failed: string[] = [];
    for (const g of ready) {
      try {
        await mergeOne(g);
        ok++;
      } catch {
        failed.push(drafts[g.key].base);
      }
    }
    setBusy(null);
    if (ok) toast.success(t('products:unir_listo', { count: ok }));
    if (failed.length) toast.error(t('products:unir_fallo', { names: failed.join(', ') }));
    onMerged();
    load();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-sm" role="dialog" aria-modal="true" aria-labelledby="merge-title">
      <div className="flex max-h-[92vh] w-full max-w-3xl flex-col overflow-hidden rounded-3xl bg-white shadow-2xl">
        <div className="flex items-start justify-between gap-4 border-b border-slate-100 p-5">
          <div className="flex items-start gap-3">
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-blue-50 text-blue-600" aria-hidden><Layers className="h-5 w-5" /></span>
            <div>
              <h2 id="merge-title" className="text-lg font-black text-slate-900">{t('products:unir_titulo')}</h2>
              <p className="mt-0.5 max-w-xl text-xs text-slate-500">{t('products:unir_desc')}</p>
            </div>
          </div>
          <button type="button" onClick={onClose} disabled={!!busy} aria-label={t('admin:cerrar')} className="rounded-xl p-2 text-slate-400 hover:bg-slate-100 hover:text-slate-700"><X className="h-5 w-5" /></button>
        </div>

        <div className="flex-1 space-y-4 overflow-y-auto bg-slate-50/60 p-5">
          {!groups ? (
            <p className="flex items-center gap-2 text-sm text-slate-500"><Loader2 className="h-4 w-4 animate-spin" /> {t('products:unir_buscando')}</p>
          ) : groups.length === 0 ? (
            <div className="rounded-2xl border border-slate-200 bg-white p-8 text-center">
              <Check className="mx-auto h-8 w-8 text-emerald-500" aria-hidden />
              <p className="mt-2 font-bold text-slate-900">{t('products:unir_nada')}</p>
              <p className="mt-1 text-xs text-slate-500">{t('products:unir_nada_ayuda')}</p>
            </div>
          ) : (
            groups.map((g) => {
              const d = drafts[g.key];
              if (!d) return null;
              const n = chosenIds(g.key).length;
              return (
                <section key={g.key} className={`rounded-2xl border bg-white p-4 transition-opacity ${d.on ? 'border-slate-200' : 'border-slate-100 opacity-60'}`}>
                  <div className="flex flex-wrap items-center gap-3">
                    <input type="checkbox" checked={d.on} onChange={(e) => patch(g.key, { on: e.target.checked })} aria-label={t('products:unir_incluir_grupo', { name: d.base })} className="h-5 w-5 accent-blue-600" />
                    <label className="min-w-[200px] flex-1">
                      <span className="sr-only">{t('products:unir_nombre')}</span>
                      <input value={d.base} onChange={(e) => patch(g.key, { base: e.target.value })}
                        className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm font-black text-slate-900 focus:border-blue-600 focus:outline-none" />
                    </label>
                    <span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-bold text-slate-600">{g.categoryName}</span>
                    <button type="button" onClick={() => runOne(g)} disabled={!!busy || n < 2 || d.base.trim().length < 2}
                      className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl bg-blue-600 px-3 text-xs font-bold text-white hover:bg-blue-700 disabled:opacity-50">
                      {busy === g.key ? <Loader2 className="h-4 w-4 animate-spin" /> : <Layers className="h-4 w-4" />} {t('products:unir_este', { count: n })}
                    </button>
                  </div>
                  <ul className="mt-3 space-y-2">
                    {g.items.map((i) => (
                      <li key={i.productId} className="flex items-center gap-3 rounded-xl bg-slate-50 p-2">
                        <input type="checkbox" checked={!!d.include[i.productId]} onChange={(e) => patch(g.key, { include: { ...d.include, [i.productId]: e.target.checked } })}
                          aria-label={t('products:unir_incluir', { name: i.name })} className="h-4 w-4 accent-blue-600" />
                        {i.imageUrl
                          ? <img src={mediaSrc(i.imageUrl)} alt="" className="h-9 w-9 rounded-lg object-cover" />
                          : <span aria-hidden className="h-9 w-9 rounded-lg bg-slate-200" />}
                        <span className="min-w-0 flex-1 truncate text-sm text-slate-600" title={i.name}>{i.name}{i.variants > 1 ? ` · ${t('products:unir_ya_tiene', { count: i.variants })}` : ''}</span>
                        <span aria-hidden className="text-slate-400">→</span>
                        <label>
                          <span className="sr-only">{t('products:unir_presentacion', { name: i.name })}</span>
                          <input value={d.labels[i.productId] || ''} onChange={(e) => patch(g.key, { labels: { ...d.labels, [i.productId]: e.target.value.slice(0, 40) } })}
                            className="w-32 rounded-lg border border-slate-200 bg-white px-2 py-1.5 text-sm font-bold text-slate-900 focus:border-blue-600 focus:outline-none" />
                        </label>
                        <span className="w-24 text-right text-sm font-bold tabular-nums text-slate-700">{formatCurrency(i.price)}</span>
                      </li>
                    ))}
                  </ul>
                </section>
              );
            })
          )}
        </div>

        <div className="flex flex-col gap-2 border-t border-slate-100 p-4 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-xs text-slate-500">{t('products:unir_nota')}</p>
          <div className="flex gap-2">
            <button type="button" onClick={onClose} disabled={!!busy} className="rounded-xl border border-slate-300 bg-white px-5 py-2.5 text-sm font-bold text-slate-700 hover:bg-slate-50">{t('admin:cerrar')}</button>
            {groups && groups.length > 0 && (
              <button type="button" onClick={runAll} disabled={!!busy || !ready.length}
                className="inline-flex items-center gap-2 rounded-xl bg-blue-600 px-5 py-2.5 text-sm font-bold text-white hover:bg-blue-700 disabled:opacity-50">
                {busy === '*' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Layers className="h-4 w-4" />} {t('products:unir_todos', { count: ready.length })}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
