// ============================================
// COMPONENTS - Cash Movements Tab (Arqueo & Flujo de Caja)
// ============================================

import React, { useState, useMemo } from 'react';
import {
  ArrowDownLeft, ArrowUpRight, ShoppingBag,
  Search, DollarSign, Wallet
} from 'lucide-react';
import { ReportButton } from '../common/ReportButton';
import { buildMovementsReport } from '../../services/cashReport';
import { paidBy } from '../../services/salesReport';
import { formatCurrency } from '../../shared/formatUtils';

import { t, getLocale } from '../../i18n';
type MovementType = 'SALE' | 'INCOME' | 'EXPENSE';

interface CashMovement {
  id: string;
  type: MovementType;
  date: Date;
  amount: number; // always positive for calculation
  isInflow: boolean;
  motive: string;
  description?: string;
  paymentMethod?: string;
  sessionNumber: string;
  cashSessionId: string;
  isCancelled?: boolean;
  referenceId?: string;
  /** Parte en efectivo: una venta con tarjeta o transferencia no entra al cajón */
  cash: number;
}

interface CashMovementsTabProps {
  sessions: any[];
  sales: any[];
  selectedMonth: string;
  config?: any;
}

export const CashMovementsTab: React.FC<CashMovementsTabProps> = ({
  sessions,
  sales,
  selectedMonth
}) => {
  const [filterType, setFilterType] = useState<string>('all'); // all, SALE, INCOME, EXPENSE
  const [filterPaymentMethod, setFilterPaymentMethod] = useState<string>('all');
  const [filterSessionId, setFilterSessionId] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [includeCancelled, setIncludeCancelled] = useState<boolean>(false);

  // 1. Filtrar sesiones del mes
  const monthSessions = useMemo(() => {
    if (!selectedMonth) return sessions;
    return sessions.filter((s: any) => {
      const date = new Date(s.openedAt);
      const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      return key === selectedMonth;
    });
  }, [sessions, selectedMonth]);

  const monthSessionIds = useMemo(() => new Set(monthSessions.map(s => s.id)), [monthSessions]);

  // 2. Construir lista unificada de movimientos
  const allMovements: CashMovement[] = useMemo(() => {
    const list: CashMovement[] = [];

    // A. Ventas
    sales.forEach((s: any) => {
      if (monthSessionIds.has(s.cashSessionId)) {
        const sess = monthSessions.find(ms => ms.id === s.cashSessionId);
        list.push({
          id: `sale-${s.id}`,
          type: 'SALE',
          date: new Date(s.createdAt),
          amount: s.total || 0,
          isInflow: true,
          motive: t('cash:venta_salenumber', { saleNumber: s.saleNumber }),
          description: s.notes || (s.table ? t('cash:mesa_number', { number: s.table.number }) : t('cash:venta_rapida')),
          paymentMethod: s.paymentMethod || 'CASH',
          sessionNumber: sess?.sessionNumber || t('cash:s_n'),
          cashSessionId: s.cashSessionId,
          isCancelled: s.status === 'CANCELLED',
          referenceId: s.saleNumber,
          cash: paidBy(s, 'CASH'),
        });
      }
    });

    // B. Ingresos manuales
    monthSessions.forEach((sess: any) => {
      (sess.incomesDetails ?? []).forEach((inc: any) => {
        list.push({
          id: `inc-${inc.id}`,
          type: 'INCOME',
          date: new Date(inc.createdAt),
          amount: inc.amount || 0,
          isInflow: true,
          motive: inc.motive || t('cash:ingreso_manual'),
          description: inc.description || '',
          paymentMethod: 'CASH',
          sessionNumber: sess.sessionNumber || t('cash:s_n'),
          cashSessionId: sess.id,
          isCancelled: inc.isCancelled,
          referenceId: inc.id,
          cash: inc.amount || 0,
        });
      });

      // C. Egresos manuales
      (sess.expensesDetails ?? []).forEach((exp: any) => {
        if ((exp.paymentSource ?? 'CASH_DRAWER') !== 'CASH_DRAWER') return;
        list.push({
          id: `exp-${exp.id}`,
          type: 'EXPENSE',
          date: new Date(exp.createdAt),
          amount: exp.amount || 0,
          isInflow: false,
          motive: exp.motive || t('cash:egreso_manual'),
          description: exp.category ? `[${exp.category.name}] ${exp.description || ''}` : exp.description || '',
          paymentMethod: 'CASH',
          sessionNumber: sess.sessionNumber || t('cash:s_n'),
          cashSessionId: sess.id,
          isCancelled: exp.isCancelled,
          referenceId: exp.id,
          cash: exp.amount || 0,
        });
      });
    });

    // Ordenar cronológicamente (más recientes primero)
    return list.sort((a, b) => b.date.getTime() - a.date.getTime());
  }, [monthSessions, monthSessionIds, sales]);

  // 3. Aplicar filtros
  const filteredMovements = useMemo(() => {
    return allMovements.filter(m => {
      if (filterType !== 'all' && m.type !== filterType) return false;
      if (filterPaymentMethod !== 'all' && m.paymentMethod !== filterPaymentMethod) return false;
      if (filterSessionId !== 'all' && m.cashSessionId !== filterSessionId) return false;
      if (!includeCancelled && m.isCancelled) return false;

      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase();
        const motiveMatch = m.motive.toLowerCase().includes(q);
        const descMatch = (m.description || '').toLowerCase().includes(q);
        const sessMatch = m.sessionNumber.toLowerCase().includes(q);
        if (!motiveMatch && !descMatch && !sessMatch) return false;
      }

      return true;
    });
  }, [allMovements, filterType, filterPaymentMethod, filterSessionId, includeCancelled, searchTerm]);

  // 4. Totales y KPIs
  const kpis = useMemo(() => {
    let totalSales = 0;
    let totalIncomes = 0;
    let totalExpenses = 0;

    filteredMovements.forEach(m => {
      if (m.isCancelled) return;
      if (m.type === 'SALE') totalSales += m.amount;
      if (m.type === 'INCOME') totalIncomes += m.amount;
      if (m.type === 'EXPENSE') totalExpenses += m.amount;
    });

    const totalInflow = totalSales + totalIncomes;
    const netFlow = totalInflow - totalExpenses;

    return {
      totalSales,
      totalIncomes,
      totalExpenses,
      totalInflow,
      netFlow,
      count: filteredMovements.length
    };
  }, [filteredMovements]);

  // 5. Informe (PDF o Excel) con los filtros que se están viendo
  const buildReport = () => {
    const scope: string[] = [];
    const sess = monthSessions.find((x: any) => x.id === filterSessionId);
    if (sess) scope.push(t('reports:filtro_arqueo', { n: sess.sessionNumber }));
    if (filterType !== 'all') scope.push(t(`reports:tipo_${filterType}`));
    if (filterPaymentMethod !== 'all') scope.push(t(`reports:metodo_${filterPaymentMethod}`, { defaultValue: filterPaymentMethod }));
    if (searchTerm.trim()) scope.push(t('reports:filtro_busqueda', { q: searchTerm.trim() }));
    if (includeCancelled) scope.push(t('reports:incluye_anulados'));
    return buildMovementsReport(filteredMovements, selectedMonth || t('cash:todos_los_periodos'), scope.join(' · ') || undefined);
  };

  return (
    <div className="space-y-6">
      {/* Controles superiores */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-50 flex items-center justify-center text-blue-600">
              <Wallet className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-black text-slate-900">{t('cash:movimientos_de_caja_unificados')}</h3>
              <p className="text-xs text-slate-500">
                {t('cash:linea_de_tiempo_completa_de_ventas_entradas')}
              </p>
            </div>
          </div>

          <ReportButton build={buildReport} fileName={`movimientos-${selectedMonth || 'todos'}`} />
        </div>

        {/* Filtros */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2 border-t border-slate-100">
          {/* Tipo de Movimiento */}
          <div className="space-y-1">
            <label className="text-xs font-black uppercase tracking-wider text-slate-500">
              {t('cash:tipo_de_movimiento')}
            </label>
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none transition-all"
            >
              <option value="all">{t('cash:todos_los_tipos')}</option>
              <option value="SALE">{t('cash:solo_ventas')}</option>
              <option value="INCOME">{t('cash:solo_ingresos_manuales')}</option>
              <option value="EXPENSE">{t('cash:solo_egresos')}</option>
            </select>
          </div>

          {/* Método de pago */}
          <div className="space-y-1">
            <label className="text-xs font-black uppercase tracking-wider text-slate-500">
              {t('cash:metodo_de_pago')}
            </label>
            <select
              value={filterPaymentMethod}
              onChange={(e) => setFilterPaymentMethod(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none transition-all"
            >
              <option value="all">{t('cash:todos_los_metodos')}</option>
              <option value="CASH">{t('cash:efectivo')}</option>
              <option value="CARD">{t('cash:tarjeta')}</option>
              <option value="TRANSFER">{t('cash:transferencia')}</option>
              <option value="MIXED">{t('cash:mixto')}</option>
            </select>
          </div>

          {/* Arqueo */}
          <div className="space-y-1">
            <label className="text-xs font-black uppercase tracking-wider text-slate-500">
              {t('cash:arqueo_sesion')}
            </label>
            <select
              value={filterSessionId}
              onChange={(e) => setFilterSessionId(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none transition-all"
            >
              <option value="all">{t('cash:todos_los_arqueos_length', { length: monthSessions.length })}</option>
              {monthSessions.map((s: any) => (
                <option key={s.id} value={s.id}>
                  {s.sessionNumber || t('cash:sesion')} ({new Date(s.openedAt).toLocaleDateString(getLocale())})
                </option>
              ))}
            </select>
          </div>

          {/* Buscador */}
          <div className="space-y-1">
            <label className="text-xs font-black uppercase tracking-wider text-slate-500">
              {t('cash:buscar_concepto_nota')}
            </label>
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder={t('cash:venta_concepto')}
                className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none transition-all"
              />
            </div>
          </div>
        </div>

        {/* Checkbox Anulados */}
        <div className="flex items-center gap-2 pt-2">
          <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-slate-700 select-none">
            <input
              type="checkbox"
              checked={includeCancelled}
              onChange={(e) => setIncludeCancelled(e.target.checked)}
              className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-slate-300"
            />
            <span>{t('cash:incluir_ventas_y_movimientos_anulados')}</span>
          </label>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Ventas */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-black uppercase tracking-widest">{t('cash:ventas')}</span>
            <ShoppingBag className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-2xl font-black text-emerald-600 tabular-nums">{formatCurrency(kpis.totalSales)}</p>
          <p className="text-xs text-slate-400 mt-1 font-medium">{t('cash:facturado_en_el_filtro')}</p>
        </div>

        {/* Ingresos Manuales */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-black uppercase tracking-widest">{t('cash:ingresos_caja')}</span>
            <ArrowDownLeft className="w-4 h-4 text-blue-600" />
          </div>
          <p className="text-2xl font-black text-blue-600 tabular-nums">+{formatCurrency(kpis.totalIncomes)}</p>
          <p className="text-xs text-slate-400 mt-1 font-medium">{t('cash:entradas_directas_a_caja')}</p>
        </div>

        {/* Egresos */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-black uppercase tracking-widest">{t('cash:egresos_gastos')}</span>
            <ArrowUpRight className="w-4 h-4 text-rose-600" />
          </div>
          <p className="text-2xl font-black text-rose-600 tabular-nums">-{formatCurrency(kpis.totalExpenses)}</p>
          <p className="text-xs text-slate-400 mt-1 font-medium">{t('cash:salidas_registradas')}</p>
        </div>

        {/* Flujo Neto */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl text-white shadow-xl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-black uppercase tracking-widest text-blue-400">{t('cash:flujo_neto')}</span>
            <DollarSign className="w-4 h-4 text-blue-400" />
          </div>
          <p className={`text-2xl font-black tabular-nums ${kpis.netFlow >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            {formatCurrency(kpis.netFlow)}
          </p>
          <p className="text-xs text-slate-400 mt-1 font-medium">
            {t('cash:entradas_salidas')}
          </p>
        </div>
      </div>

      {/* Tabla Cronológica de Movimientos */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h4 className="font-black text-slate-900">{t('cash:linea_cronologica_de_movimientos')}</h4>
            <p className="text-xs text-slate-500">
              {t('cash:length_operaciones_registradas', { length: filteredMovements.length })}
            </p>
          </div>
        </div>

        {filteredMovements.length === 0 ? (
          <div className="p-12 text-center text-slate-400">
            <Wallet className="w-8 h-8 mx-auto mb-2 opacity-30" />
            <p className="font-bold text-sm">{t('cash:no_se_encontraron_movimientos_con_los_filtros')}</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-xs uppercase font-black tracking-wider text-slate-600">
                <tr>
                  <th className="py-3 px-4">{t('cash:fecha_y_hora')}</th>
                  <th className="py-3 px-4">{t('cash:tipo')}</th>
                  <th className="py-3 px-4">{t('cash:arqueo')}</th>
                  <th className="py-3 px-4">{t('cash:concepto_nota')}</th>
                  <th className="py-3 px-4 text-center">{t('cash:metodo')}</th>
                  <th className="py-3 px-4 text-right">{t('cash:monto')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredMovements.map((m) => (
                  <tr
                    key={m.id}
                    className={`hover:bg-slate-50 transition-colors ${
                      m.isCancelled ? 'opacity-40 bg-slate-50/50' : ''
                    }`}
                  >
                    <td className="py-3 px-4 text-slate-600 font-bold whitespace-nowrap">
                      {m.date.toLocaleDateString(getLocale(), {
                        day: '2-digit',
                        month: 'short',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </td>
                    <td className="py-3 px-4">
                      {m.type === 'SALE' && (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                          <ShoppingBag className="w-3 h-3" />
                          {t('cash:venta')}
                        </span>
                      )}
                      {m.type === 'INCOME' && (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200">
                          <ArrowDownLeft className="w-3 h-3" />
                          {t('cash:ingreso')}
                        </span>
                      )}
                      {m.type === 'EXPENSE' && (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-bold bg-rose-50 text-rose-700 border border-rose-200">
                          <ArrowUpRight className="w-3 h-3" />
                          {t('cash:egreso')}
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-slate-500">
                      #{m.sessionNumber}
                    </td>
                    <td className="py-3 px-4">
                      <p className={`font-bold ${m.isCancelled ? 'line-through text-slate-400' : 'text-slate-800'}`}>
                        {m.motive}
                      </p>
                      {m.description && (
                        <p className="text-xs text-slate-400 truncate max-w-sm">
                          {m.description}
                        </p>
                      )}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span className="text-xs font-extrabold uppercase px-2 py-0.5 rounded-lg bg-slate-100 text-slate-700">
                        {m.paymentMethod}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      <span
                        className={`font-black text-sm tabular-nums ${
                          m.isCancelled
                            ? 'text-slate-300 line-through'
                            : m.isInflow
                            ? 'text-emerald-600'
                            : 'text-rose-600'
                        }`}
                      >
                        {m.isInflow ? '+' : '-'}{formatCurrency(m.amount)}
                      </span>
                      {m.isCancelled && (
                        <span className="block text-xs font-black text-rose-500 uppercase">
                          {t('cash:anulado_2')}
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default CashMovementsTab;
