// ============================================
// VENTAS - Cambiar el cliente de una venta
// ============================================
// Para que lo comprado quede en el historial del cliente cuando no estaba
// registrado al cobrar, o cuando se dejó "Cliente común" por error. Si el
// cliente no existe, se crea aquí mismo (nombre y celular).

import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { Search, UserPlus, User, X, Loader2 } from 'lucide-react';
import { customersAPI, salesAPI } from '../../services/api';
import { errorMessage } from '../../services/apiErrors';
import { toast } from '../../shared/toast';
import { t } from '../../i18n';

interface Props {
  sale: { id: string; saleNumber: string; customerId?: string | null; customer?: { id: string; name: string; isDefault?: boolean } | null };
  onClose: () => void;
  onChanged: () => void;
}

const inputCls = 'w-full min-h-[44px] px-3 rounded-xl border border-slate-200 bg-white text-sm text-slate-900 focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20';

export function ChangeCustomerDialog({ sale, onClose, onChanged }: Props) {
  const [q, setQ] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [searching, setSearching] = useState(false);
  const [saving, setSaving] = useState(false);
  const [creating, setCreating] = useState(false);
  const [draft, setDraft] = useState({ name: '', phone: '' });

  useEffect(() => {
    let cancelled = false;
    const term = q.trim();
    setSearching(true);
    if (term.length < 2) {
      customersAPI.getAll()
        .then((r: any[]) => {
          if (!cancelled) setResults(Array.isArray(r) ? r.filter((c) => !c.isDefault) : []);
        })
        .catch(() => {
          if (!cancelled) setResults([]);
        })
        .finally(() => {
          if (!cancelled) setSearching(false);
        });
      return () => { cancelled = true; };
    }
    const timer = setTimeout(() => {
      customersAPI.search(term)
        .then((r: any[]) => {
          if (!cancelled) setResults(Array.isArray(r) ? r.filter((c) => !c.isDefault) : []);
        })
        .catch(() => {
          if (!cancelled) setResults([]);
        })
        .finally(() => {
          if (!cancelled) setSearching(false);
        });
    }, 200);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [q]);

  const assign = async (customerId: string | null, name: string) => {
    setSaving(true);
    try {
      await salesAPI.changeCustomer(sale.id, customerId);
      toast.success(t('sales:cliente_asignado', { name }));
      onChanged();
    } catch (e) {
      toast.error(errorMessage(e));
      setSaving(false);
    }
  };

  const createAndAssign = async () => {
    if (!draft.name.trim()) return;
    setSaving(true);
    try {
      const created = await customersAPI.create({ name: draft.name.trim(), phone: draft.phone.trim() || undefined });
      await assign(created.id, created.name);
    } catch (e) {
      toast.error(errorMessage(e));
      setSaving(false);
    }
  };

  const current = sale.customer && !sale.customer.isDefault ? sale.customer.name : t('sales:cliente_comun');

  return createPortal(
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/50 p-4" role="dialog" aria-modal="true" aria-labelledby="change-customer-title" onClick={onClose}>
      <div className="w-full max-w-md max-h-[88vh] overflow-y-auto rounded-3xl bg-white shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between border-b border-slate-100 px-6 py-4">
          <div>
            <h3 id="change-customer-title" className="text-lg font-black text-slate-900">{t('sales:cambiar_cliente')}</h3>
            <p className="text-xs text-slate-500">{t('sales:cambiar_cliente_desc', { sale: sale.saleNumber, current })}</p>
          </div>
          <button type="button" onClick={onClose} className="p-2 rounded-xl text-slate-400 hover:bg-slate-100 hover:text-slate-700" aria-label={t('common:cerrar')}>
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          {!creating ? (
            <>
              <label className="block">
                <span className="sr-only">{t('sales:buscar_cliente')}</span>
                <span className="relative block">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" aria-hidden />
                  <input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('sales:buscar_cliente_ph')} className={`${inputCls} pl-9`} />
                </span>
              </label>

              <ul className="space-y-1.5 min-h-[3rem]">
                {searching && <li className="flex justify-center py-3"><Loader2 className="w-5 h-5 animate-spin text-slate-400" aria-hidden /></li>}
                {!searching && q.trim().length >= 2 && results.length === 0 && (
                  <li className="text-sm text-slate-500 px-1">{t('sales:sin_resultados_cliente')}</li>
                )}
                {results.map((c) => (
                  <li key={c.id}>
                    <button
                      type="button"
                      disabled={saving || c.id === sale.customerId}
                      onClick={() => assign(c.id, c.name)}
                      className="w-full flex items-center gap-3 rounded-2xl border border-slate-200 px-3 py-2.5 text-left hover:border-blue-400 hover:bg-blue-50/40 disabled:opacity-50"
                    >
                      <span className="w-9 h-9 shrink-0 rounded-xl bg-slate-100 text-slate-600 flex items-center justify-center"><User className="w-4 h-4" aria-hidden /></span>
                      <span className="min-w-0">
                        <span className="block text-sm font-bold text-slate-900 truncate">{c.name}</span>
                        <span className="block text-xs text-slate-500 truncate">{[c.phone, c.nit].filter(Boolean).join(' · ') || '—'}</span>
                      </span>
                    </button>
                  </li>
                ))}
              </ul>

              <div className="grid grid-cols-1 gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => { setCreating(true); setDraft({ name: /\d{6,}/.test(q) ? '' : q.trim(), phone: /\d{6,}/.test(q) ? q.replace(/\D/g, '') : '' }); }}
                  className="inline-flex items-center justify-center gap-2 min-h-[44px] rounded-xl border border-dashed border-slate-300 text-sm font-bold text-slate-700 hover:border-blue-400 hover:text-blue-700"
                >
                  <UserPlus className="w-4 h-4" aria-hidden /> {t('sales:registrar_cliente_nuevo')}
                </button>
                {sale.customerId && !sale.customer?.isDefault && (
                  <button
                    type="button"
                    disabled={saving}
                    onClick={() => assign(null, t('sales:cliente_comun'))}
                    className="min-h-[40px] rounded-xl text-xs font-bold text-slate-500 hover:bg-slate-50"
                  >
                    {t('sales:dejar_cliente_comun')}
                  </button>
                )}
              </div>
            </>
          ) : (
            <div className="space-y-3">
              <label className="block">
                <span className="text-xs font-bold text-slate-600">{t('sales:nombre_cliente')} *</span>
                <input autoFocus value={draft.name} maxLength={120} onChange={(e) => setDraft({ ...draft, name: e.target.value })} className={`${inputCls} mt-1`} />
              </label>
              <label className="block">
                <span className="text-xs font-bold text-slate-600">{t('sales:celular_cliente')}</span>
                <input value={draft.phone} inputMode="tel" maxLength={20} onChange={(e) => setDraft({ ...draft, phone: e.target.value })} className={`${inputCls} mt-1`} />
              </label>
              <p className="text-xs text-slate-500">{t('sales:registrar_cliente_aviso')}</p>
              <div className="flex gap-2 pt-1">
                <button type="button" onClick={() => setCreating(false)} className="flex-1 min-h-[44px] rounded-xl border border-slate-200 text-sm font-bold text-slate-700 hover:bg-slate-50">
                  {t('sales:volver')}
                </button>
                <button type="button" disabled={saving || !draft.name.trim()} onClick={createAndAssign} className="flex-[2] min-h-[44px] rounded-xl bg-blue-600 text-sm font-bold text-white hover:bg-blue-700 disabled:opacity-50">
                  {saving ? t('sales:guardando') : t('sales:crear_y_asignar')}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>,
    document.body,
  );
}
