// ============================================
// COMPONENTS - Table Grid (Cuadrícula interactiva de mesas con resumen operativo)
// ============================================

import React, { useState, useMemo, useEffect } from 'react';
import { usePosStore } from '../../store/usePosStore';
import type { Table, TableStatus } from '../../types';
import { Coffee, Utensils, Users, Clock, Search, Check, X, Filter } from 'lucide-react';
import { formatCurrency } from '../../shared/formatUtils';
import { useTableSelection, useTableSummaries, TABLE_STATUS_META, getTableCounts, formatTableElapsed } from './tableSelection';

interface TableGridProps {
  onTableSelect?: (table: Table) => void;
}

type StatusFilter = 'ALL' | TableStatus;

export const TableGrid: React.FC<TableGridProps> = ({ onTableSelect }) => {
  const { 
    tables, 
    selectedTable, 
    isLoadingTables 
  } = usePosStore();

  const select = useTableSelection();
  const summaryOf = useTableSummaries();
  const [filter, setFilter] = useState<StatusFilter>('ALL');
  const [search, setSearch] = useState('');
  const [selectedZone, setSelectedZone] = useState<string>('ALL');
  const [_tick, setTick] = useState(0);

  // Actualizar el tiempo transcurrido cada minuto
  useEffect(() => {
    const timer = setInterval(() => setTick(t => t + 1), 60000);
    return () => clearInterval(timer);
  }, []);

  // Extraer zonas únicas disponibles
  const zones = useMemo(() => {
    const zSet = new Set<string>();
    tables.forEach(t => {
      if (t.zone) zSet.add(t.zone);
    });
    return Array.from(zSet);
  }, [tables]);

  const counts = useMemo(() => getTableCounts(tables), [tables]);

  const filterPills: { id: StatusFilter; label: string; count: number; dot: string; color: string }[] = [
    { id: 'ALL', label: 'Todas las Mesas', count: counts.total, dot: 'bg-slate-400', color: 'text-slate-700' },
    { id: 'AVAILABLE', label: 'Libres', count: counts.available, dot: 'bg-emerald-500', color: 'text-emerald-700' },
    { id: 'ORDERED', label: 'En Consumo', count: counts.ordered, dot: 'bg-amber-500', color: 'text-amber-700' },
    { id: 'PENDING', label: 'Por Cobrar', count: counts.pending, dot: 'bg-violet-500', color: 'text-violet-700' },
  ];

  const filteredTables = useMemo(() => {
    return tables.filter(t => {
      if (filter !== 'ALL' && t.status !== filter) return false;
      if (selectedZone !== 'ALL' && t.zone !== selectedZone) return false;
      if (search.trim()) {
        const q = search.trim().toLowerCase();
        const matchesNum = String(t.number).toLowerCase().includes(q);
        const matchesZone = t.zone ? t.zone.toLowerCase().includes(q) : false;
        return matchesNum || matchesZone;
      }
      return true;
    });
  }, [tables, filter, selectedZone, search]);

  const handleTableClick = async (table: Table) => {
    await select(table);
    if (onTableSelect) {
      onTableSelect(table);
    }
  };

  if (isLoadingTables) {
    return (
      <div className="flex flex-col items-center justify-center h-80 gap-4">
        <div className="relative w-12 h-12">
          <div className="absolute inset-0 border-3 border-slate-200 rounded-full"></div>
          <div className="absolute inset-0 border-3 border-t-blue-600 rounded-full animate-spin"></div>
        </div>
        <p className="text-slate-600 font-bold text-xs uppercase tracking-wider">Cargando Mesas...</p>
      </div>
    );
  }

  return (
    <div className="space-y-4 p-2 select-none">
      {/* 1. Barra de Resumen Operativo (KPIs interactivos) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        {filterPills.map(p => {
          const isActive = filter === p.id;
          return (
            <button
              key={p.id}
              type="button"
              onClick={() => setFilter(p.id)}
              className={`p-3 rounded-2xl border transition-all text-left flex items-center justify-between ${
                isActive
                  ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                  : 'bg-white text-slate-700 border-slate-200/90 hover:border-slate-300 hover:bg-slate-50'
              }`}
            >
              <div className="flex items-center gap-2">
                <span className={`w-2.5 h-2.5 rounded-full ${isActive ? 'bg-white' : p.dot}`} />
                <span className="text-xs font-bold font-heading">{p.label}</span>
              </div>
              <span className={`text-xs font-black px-2 py-0.5 rounded-lg tabular-nums ${
                isActive ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-800'
              }`}>
                {p.count}
              </span>
            </button>
          );
        })}
      </div>

      {/* 2. Barra de Búsqueda y Filtros de Zona */}
      <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar por número o zona..."
            className="w-full pl-9 pr-8 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:border-blue-600 focus:outline-none focus:ring-1 focus:ring-blue-500/20"
          />
          {search && (
            <button onClick={() => setSearch('')} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5">
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Zonas */}
        {zones.length > 0 && (
          <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0 scrollbar-hide">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1 mr-1">
              <Filter className="w-3 h-3" /> Zona:
            </span>
            <button
              onClick={() => setSelectedZone('ALL')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all ${
                selectedZone === 'ALL'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              Todas
            </button>
            {zones.map(z => (
              <button
                key={z}
                onClick={() => setSelectedZone(z)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all ${
                  selectedZone === z
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {z}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* 3. Cuadrícula de Mesas */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3.5">
        {filteredTables.map((table) => {
          const meta = TABLE_STATUS_META[table.status] || TABLE_STATUS_META.AVAILABLE;
          const isSelected = selectedTable?.id === table.id;
          const summary = summaryOf(table.id);
          const totalAmount = summary.total || table.currentSale?.total || 0;
          const timeElapsed = formatTableElapsed(table.currentSale?.createdAt);

          return (
            <button
              key={table.id}
              onClick={() => handleTableClick(table)}
              className={`
                relative flex flex-col justify-between p-4 rounded-2xl border-2 transition-all duration-150 text-left min-h-[140px]
                ${meta.card}
                ${isSelected ? '!border-blue-600 ring-2 ring-blue-600/30 bg-blue-50/60 shadow-md' : 'shadow-xs'}
              `}
            >
              {isSelected && (
                <div className="absolute top-2 right-2 bg-blue-600 text-white p-1 rounded-full shadow-xs">
                  <Check className="w-3 h-3" />
                </div>
              )}

              {/* Encabezado: Número y Zona */}
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Mesa</span>
                  <span className="text-2xl font-black text-slate-900 font-heading leading-tight">
                    {table.number}
                  </span>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <span className={`px-2 py-0.5 rounded-full text-xs font-black uppercase tracking-wider ${meta.badge}`}>
                    {meta.label}
                  </span>
                  {table.zone && (
                    <span className="text-xs font-bold text-slate-400 bg-white/80 px-1.5 py-0.2 rounded border border-slate-200">
                      {table.zone}
                    </span>
                  )}
                </div>
              </div>

              {/* Centro: Total Acumulado */}
              <div className="py-2">
                {totalAmount > 0 ? (
                  <div>
                    <span className="text-xs uppercase font-bold text-slate-400 tracking-wider block">Consumo</span>
                    <span className="text-base font-black text-slate-900 font-heading tabular-nums">
                      {formatCurrency(totalAmount)}
                    </span>
                  </div>
                ) : (
                  <div className="flex items-center gap-1.5 text-slate-400 text-xs">
                    <Coffee className="w-4 h-4 opacity-50" />
                    <span className="text-xs font-medium">Disponible</span>
                  </div>
                )}
              </div>

              {/* Pie: Capacidad y Tiempo */}
              <div className="pt-2 border-t border-slate-200/60 flex items-center justify-between text-xs text-slate-500 font-medium">
                <span className="flex items-center gap-1">
                  <Users className="w-3 h-3 text-slate-400" />
                  <span>{table.capacity} p.</span>
                </span>
                {timeElapsed && (
                  <span className="flex items-center gap-1 text-amber-700 font-bold">
                    <Clock className="w-3 h-3" />
                    <span>{timeElapsed}</span>
                  </span>
                )}
              </div>
            </button>
          );
        })}

        {/* Sin resultados */}
        {filteredTables.length === 0 && (
          <div className="col-span-full flex flex-col items-center justify-center py-16 text-slate-400 border-2 border-dashed border-slate-200 bg-white/60 rounded-3xl space-y-2">
            <Utensils className="w-12 h-12 text-slate-300 stroke-[1.5]" />
            <p className="text-sm font-bold text-slate-700">No hay mesas con los filtros seleccionados</p>
            <p className="text-xs text-slate-400">Prueba cambiando la zona o el estado seleccionado</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default TableGrid;