// ============================================
// COMPONENTS - Selector lateral de mesas (Vista operativa)
// ============================================

import { useFloor } from '../../shared/features';
import React, { useState, useMemo } from 'react';
import { Users, Clock, ShoppingBag, Search, X, List, Map as MapIcon } from 'lucide-react';
import { Segmented } from '../ui';
import { switchTableView } from '../../shared/posSettings';
import { usePosStore } from '../../store/usePosStore';
import { formatCurrency } from '../../shared/formatUtils';
import { useTableSelection, useTableSummaries, useMinuteTick, useTableLook, getTableCounts, formatTableElapsed } from './tableSelection';

import { t as tr } from '../../i18n';
type Filter = 'ALL' | 'AVAILABLE' | 'ORDERED' | 'PENDING';

export const TableSidebar: React.FC = () => {
  const { tables, selectedTable } = usePosStore();
  const select = useTableSelection();
  const summaryOf = useTableSummaries();
  const lookOf = useTableLook();
  useFloor();
  const [filter, setFilter] = useState<Filter>('ALL');
  useMinuteTick();
  const [search, setSearch] = useState('');

  const counts = useMemo(() => getTableCounts(tables), [tables]);

  const filters: { id: Filter; label: string; count: number; color?: string }[] = [
    { id: 'ALL', label: tr('pos:todas'), count: counts.total },
    { id: 'AVAILABLE', label: tr('pos:libres'), count: counts.available, color: 'text-emerald-700' },
    { id: 'ORDERED', label: tr('pos:en_consumo'), count: counts.ordered, color: 'text-amber-700' },
    { id: 'PENDING', label: tr('pos:por_cobrar'), count: counts.pending, color: 'text-violet-700' },
  ];

  const visible = useMemo(() => {
    return tables.filter(t => {
      const matchesFilter = filter === 'ALL' || t.status === filter;
      if (!matchesFilter) return false;
      if (!search.trim()) return true;
      const query = search.trim().toLowerCase();
      const numMatch = String(t.number).toLowerCase().includes(query);
      const zoneMatch = t.zone ? t.zone.toLowerCase().includes(query) : false;
      return numMatch || zoneMatch;
    });
  }, [tables, filter, search]);

  return (
    <div data-guide="table-sidebar" className="flex h-full select-none flex-col overflow-hidden rounded-[22px] bg-slate-50 shadow-card">
      {/* Header con resumen operativo y búsqueda */}
      <div className="space-y-2.5 border-b border-slate-200/70 bg-white p-3">
        <div className="flex items-center justify-between gap-2 px-1">
          <div className="min-w-0">
            <h2 className="text-[0.95rem] font-semibold text-slate-900">{tr('pos:mesas')}</h2>
            <p className="text-xs text-slate-500 num">{tr('pos:value_activas_de_total', { value: counts.ordered + counts.pending, total: counts.total })}</p>
          </div>
          <Segmented
            size="sm"
            value="operational"
            onChange={(v) => switchTableView(v as 'operational' | 'floorplan')}
            ariaLabel={tr('pos:vista_mesas')}
            options={[
              { id: 'operational', label: <List className="h-3.5 w-3.5" aria-hidden />, ariaLabel: tr('pos:vista_lista') },
              { id: 'floorplan', label: <MapIcon className="h-3.5 w-3.5" aria-hidden />, ariaLabel: tr('pos:vista_mapa') },
            ]}
          />
        </div>

        {/* Buscador de mesa / zona */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={tr('pos:buscar_mesa_o_zona')}
            className="w-full pl-8 pr-7 py-1.5 bg-white border border-slate-200 rounded-xl text-xs font-medium focus:border-blue-600 focus:ring-1 focus:ring-blue-500/20 focus:outline-none"
          />
          {search && (
            <button
              onClick={() => setSearch('')}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5"
            >
              <X className="w-3 h-3" />
            </button>
          )}
        </div>

        {/* Chips de Resumen Operativo / Filtros */}
        <div className="grid grid-cols-2 gap-1.5">
          {filters.map(f => {
            const isActive = filter === f.id;
            return (
              <button
                key={f.id}
                type="button"
                onClick={() => setFilter(f.id)}
                className={`flex items-center justify-between px-2.5 py-1.5 rounded-xl text-xs font-bold transition-all border ${
                  isActive
                    ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100/80'
                }`}
              >
                <span>{f.label}</span>
                <span className={`text-xs font-black px-1.5 py-0.2 rounded-md ${
                  isActive ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-700'
                }`}>
                  {f.count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Lista de mesas */}
      <div className="flex-1 space-y-2 overflow-y-auto p-2.5">
        {/* Mostrador: otro flujo de venta, separado de las mesas */}
        <button
          type="button"
          onClick={() => select(null)}
          aria-pressed={!selectedTable}
          className={`relative flex min-h-[56px] w-full items-center gap-3 rounded-[12px] px-3 py-2.5 text-left transition-[box-shadow,background-color] duration-fast ${
            !selectedTable ? 'bg-slate-950 text-white shadow-raised' : 'bg-white text-slate-900 shadow-card hover:shadow-raised'
          }`}
        >
          <span className={`grid h-9 w-9 shrink-0 place-items-center rounded-[10px] ${!selectedTable ? 'bg-white/10' : 'bg-slate-100 text-slate-600'}`}>
            <ShoppingBag className="h-4 w-4" aria-hidden />
          </span>
          <span className="min-w-0">
            <span className="block text-[0.95rem] font-semibold">{tr('pos:mostrador')}</span>
            <span className={`block text-xs ${!selectedTable ? 'text-white/60' : 'text-slate-500'}`}>{tr('pos:venta_rapida_sin_mesa')}</span>
          </span>
        </button>

        {visible.map(table => {
          const meta = lookOf(table);
          const isSelected = selectedTable?.id === table.id;
          const summary = summaryOf(table.id);
          const total = summary.total || table.currentSale?.total || 0;
          const time = table.status === 'AVAILABLE' ? '' : formatTableElapsed(summary.openedAt || table.currentSale?.createdAt);

          const busy = table.status !== 'AVAILABLE';
          const who = meta.waiterName && busy ? meta.waiterName : null;

          return (
            <button
              key={table.id}
              type="button"
              onClick={() => select(table)}
              aria-pressed={isSelected}
              className={`relative w-full rounded-[12px] border px-3 py-2.5 text-left transition-[box-shadow,border-color,background-color] duration-fast ${meta.card} ${
                isSelected ? 'ring-2 ring-blue-600 ring-offset-1' : ''
              }`}
            >
              {/* Fila 1: número y estado, siempre en el mismo lugar */}
              <span className="flex items-center justify-between gap-2">
                <span className="flex min-w-0 items-baseline gap-1.5">
                  <span className="text-xs font-medium text-slate-500">{tr('pos:mesa')}</span>
                  <span className="text-lg font-semibold leading-none text-slate-950 num">{table.number}</span>
                  {table.zone && <span className="truncate text-xs text-slate-500">· {table.zone}</span>}
                </span>
                <span className={`inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full px-2 py-0.5 text-[0.72rem] font-medium ${meta.badge}`}>
                  <span className={`h-1.5 w-1.5 rounded-full ${meta.dot}`} aria-hidden />
                  {meta.label}
                </span>
              </span>

              {/* Fila 2: solo lo que aporta (tiempo y total si está ocupada; puestos si está libre) */}
              <span className="mt-1.5 flex items-center justify-between gap-2 text-xs text-slate-600">
                {busy ? (
                  <span className="flex items-center gap-1 font-medium text-amber-800" title={tr('pos:tiempo_desde_el_primer_envio_a_cocina')}>
                    {time && <><Clock className="h-3 w-3" aria-hidden />{time}</>}
                  </span>
                ) : (
                  <span className="flex items-center gap-1 text-slate-500"><Users className="h-3 w-3" aria-hidden />{table.capacity} {tr('pos:p')}</span>
                )}
                {total > 0 && <span className="text-sm font-semibold text-slate-950 num">{formatCurrency(total)}</span>}
              </span>
              {who && <span className="mt-0.5 block truncate text-xs text-slate-500" title={who}>{who}</span>}
            </button>
          );
        })}

        {visible.length === 0 && (
          <div className="text-center py-8 px-2 space-y-1">
            <p className="text-xs font-bold text-slate-600">{tr('pos:no_se_encontraron_mesas')}</p>
            <p className="text-xs text-slate-400">{tr('pos:intenta_con_otro_filtro_o_termino_de')}</p>
          </div>
        )}
      </div>
    </div>
  );
};
