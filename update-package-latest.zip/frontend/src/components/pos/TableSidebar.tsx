// ============================================
// COMPONENTS - Selector lateral de mesas (Vista operativa)
// ============================================

import React, { useState, useMemo } from 'react';
import { Users, Clock, ShoppingBag, Search, Check, X } from 'lucide-react';
import { usePosStore } from '../../store/usePosStore';
import { formatCurrency } from '../../shared/formatUtils';
import { useTableSelection, useTableSummaries, useMinuteTick, TABLE_STATUS_META, getTableCounts, formatTableElapsed } from './tableSelection';

import { t as tr } from '../../i18n';
type Filter = 'ALL' | 'AVAILABLE' | 'ORDERED' | 'PENDING';

export const TableSidebar: React.FC = () => {
  const { tables, selectedTable } = usePosStore();
  const select = useTableSelection();
  const summaryOf = useTableSummaries();
  const [filter, setFilter] = useState<Filter>('ALL');
  useMinuteTick();
  const [search, setSearch] = useState('');

  const counts = useMemo(() => getTableCounts(tables), [tables]);

  const filters: { id: Filter; label: string; count: number; color?: string }[] = [
    { id: 'ALL', label: tr('pos:todas'), count: counts.total },
    { id: 'AVAILABLE', label: tr('pos:libres'), count: counts.available, color: 'text-emerald-700' },
    { id: 'ORDERED', label: tr('pos:en_consumo'), count: counts.ordered, color: 'text-amber-700' },
    { id: 'PENDING', label: tr('pos:por_cobrar'), count: counts.pending, color: 'text-violet-700' },
  ];

  const visible = useMemo(() => {
    return tables.filter(t => {
      const matchesFilter = filter === 'ALL' || t.status === filter;
      if (!matchesFilter) return false;
      if (!search.trim()) return true;
      const query = search.trim().toLowerCase();
      const numMatch = String(t.number).toLowerCase().includes(query);
      const zoneMatch = t.zone ? t.zone.toLowerCase().includes(query) : false;
      return numMatch || zoneMatch;
    });
  }, [tables, filter, search]);

  return (
    <div data-guide="table-sidebar" className="h-full flex flex-col bg-white rounded-3xl border border-slate-200/90 shadow-sm overflow-hidden select-none">
      {/* Header con resumen operativo y búsqueda */}
      <div className="p-3 border-b border-slate-100 space-y-2.5 bg-slate-50/50">
        <div className="flex items-center justify-between px-1">
          <h2 className="text-sm font-black text-slate-900 font-heading">{tr('pos:mesas')}</h2>
          <span className="text-xs font-bold text-slate-500 bg-white px-2 py-0.5 rounded-full border border-slate-200">
            {tr('pos:value_activas_de_total', { value: counts.ordered + counts.pending, total: counts.total })}
          </span>
        </div>

        {/* Buscador de mesa / zona */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={tr('pos:buscar_mesa_o_zona')}
            className="w-full pl-8 pr-7 py-1.5 bg-white border border-slate-200 rounded-xl text-xs font-medium focus:border-blue-600 focus:ring-1 focus:ring-blue-500/20 focus:outline-none"
          />
          {search && (
            <button
              onClick={() => setSearch('')}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5"
            >
              <X className="w-3 h-3" />
            </button>
          )}
        </div>

        {/* Chips de Resumen Operativo / Filtros */}
        <div className="grid grid-cols-2 gap-1.5">
          {filters.map(f => {
            const isActive = filter === f.id;
            return (
              <button
                key={f.id}
                type="button"
                onClick={() => setFilter(f.id)}
                className={`flex items-center justify-between px-2.5 py-1.5 rounded-xl text-xs font-bold transition-all border ${
                  isActive
                    ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100/80'
                }`}
              >
                <span>{f.label}</span>
                <span className={`text-xs font-black px-1.5 py-0.2 rounded-md ${
                  isActive ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-700'
                }`}>
                  {f.count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Lista de mesas */}
      <div className="flex-1 overflow-y-auto p-2.5 space-y-2">
        {/* Opción Mostrador */}
        <button
          type="button"
          onClick={() => select(null)}
          className={`w-full flex items-center justify-between p-3 rounded-2xl border-2 text-left transition-all relative overflow-hidden ${
            !selectedTable
              ? 'border-blue-600 bg-blue-50/70 ring-2 ring-blue-600/20'
              : 'border-slate-200 bg-white hover:border-slate-300'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <div className={`p-2 rounded-xl ${!selectedTable ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600'}`}>
              <ShoppingBag className="w-4 h-4" />
            </div>
            <div>
              <span className="font-black text-sm text-slate-900 block font-heading">{tr('pos:mostrador')}</span>
              <span className="text-xs font-semibold text-slate-400">{tr('pos:venta_rapida_sin_mesa')}</span>
            </div>
          </div>
          {!selectedTable && (
            <span className="bg-blue-600 text-white p-1 rounded-full">
              <Check className="w-3.5 h-3.5" />
            </span>
          )}
        </button>

        {visible.map(table => {
          const meta = TABLE_STATUS_META[table.status] || TABLE_STATUS_META.AVAILABLE;
          const isSelected = selectedTable?.id === table.id;
          const summary = summaryOf(table.id);
          const total = summary.total || table.currentSale?.total || 0;
          const time = table.status === 'AVAILABLE' ? '' : formatTableElapsed(summary.openedAt || table.currentSale?.createdAt);

          return (
            <button
              key={table.id}
              type="button"
              onClick={() => select(table)}
              className={`w-full p-3 rounded-2xl border-2 text-left transition-all relative overflow-hidden ${meta.card} ${
                isSelected
                  ? '!border-blue-600 ring-2 ring-blue-600/25 bg-blue-50/50'
                  : ''
              }`}
            >
              {isSelected && (
                <div className="absolute left-0 top-2 bottom-2 w-1.5 bg-blue-600 rounded-r-md" />
              )}

              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className={`w-2.5 h-2.5 rounded-full ${meta.dot} shrink-0`} />
                  <span className="font-black text-base text-slate-900 font-heading">
                    {tr('pos:mesa_number', { number: table.number })}
                  </span>
                  {table.zone && (
                    <span className="text-xs font-bold text-slate-400 bg-white/70 px-1.5 py-0.5 rounded border border-slate-200/60">
                      {table.zone}
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-1.5">
                  <span className={`px-2 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider ${meta.badge}`}>
                    {meta.label}
                  </span>
                  {isSelected && (
                    <span className="bg-blue-600 text-white p-0.5 rounded-full">
                      <Check className="w-3 h-3" />
                    </span>
                  )}
                </div>
              </div>

              <div className="mt-2 flex items-center justify-between text-xs text-slate-500 font-medium pt-1 border-t border-slate-200/50">
                <span className="flex items-center gap-1">
                  <Users className="w-3 h-3 text-slate-400" />
                  <span>{table.capacity}{' '}{tr('pos:p')}</span>
                  {time && (
                    <span className="flex items-center gap-1 ml-2 text-amber-700 font-bold" title={tr('pos:tiempo_desde_el_primer_envio_a_cocina')}>
                      <Clock className="w-3 h-3" aria-hidden />
                      {time}
                    </span>
                  )}
                </span>
                {total > 0 ? (
                  <span className="font-black text-slate-900 tabular-nums text-xs">
                    {formatCurrency(total)}
                  </span>
                ) : (
                  <span className="text-xs text-slate-400 font-medium">{tr('pos:vacia')}</span>
                )}
              </div>
            </button>
          );
        })}

        {visible.length === 0 && (
          <div className="text-center py-8 px-2 space-y-1">
            <p className="text-xs font-bold text-slate-600">{tr('pos:no_se_encontraron_mesas')}</p>
            <p className="text-xs text-slate-400">{tr('pos:intenta_con_otro_filtro_o_termino_de')}</p>
          </div>
        )}
      </div>
    </div>
  );
};
