// ============================================
// Ventas · estadísticas rápidas del período filtrado (kit del tablero)
// ============================================
// 60·30·10: tarjetas blancas sobre el lienzo, la de ingresos en negro y el azul
// solo en el medio de pago principal. Un cero (anuladas, arqueos) se muestra
// neutro: el rojo queda para cuando sí hay algo que revisar.

import type { ReactNode } from 'react';
import { t } from '../../i18n';
import { formatCurrency } from '../../shared/formatUtils';
import { Card, Skeleton } from '../ui';
import { AnimatedNumber } from '../charts/AnimatedNumber';
import { StackBar, SLICE_TONES } from '../charts/charts';
import { paymentLabel } from '../analytics/types';

export interface SalesQuickStatsProps {
  loading: boolean;
  periodLabel: string;
  revenue: number;
  completed: number;
  items: number;
  avgTicket: number;
  tips: number;
  cancelled: number;
  cashSessions: number;
  payments: Record<string, number>;
}

const int = (v: number) => Math.round(v).toLocaleString('es-CO');

export function SalesQuickStats(p: SalesQuickStatsProps) {
  const pays = Object.entries(p.payments)
    .filter(([, v]) => v > 0)
    .sort((a, b) => b[1] - a[1])
    .map(([method, value]) => ({ key: method, label: paymentLabel(method), value }));
  const payTotal = pays.reduce((a, x) => a + x.value, 0);

  return (
    <div data-guide="sales-stats" className="lt-stagger grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-12">
      {/* Ingresos del período */}
      <Card tone="inverse" large className="flex min-h-[168px] flex-col justify-between xl:col-span-4">
        <p className="text-sm font-medium text-white/80">{t('sales:ingresos_activemonthlabel', { activeMonthLabel: p.periodLabel })}</p>
        {p.loading ? <Skeleton className="h-9 w-48 !bg-white/10" /> : (
          <AnimatedNumber value={p.revenue} format={formatCurrency} className="text-[2.1rem] font-semibold tracking-tight" />
        )}
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-white/60">
          <span className="num">{t('stats:n_ventas', { n: int(p.completed) })}</span>
          <span className="num">{t('stats:n_unidades', { n: int(p.items) })}</span>
          {p.tips > 0 && <span className="num" title={t('sales:propina_no_suma')}>{t('sales:propinas_aparte', { amount: formatCurrency(p.tips) })}</span>}
        </div>
      </Card>

      {/* Medios de pago */}
      <Card large className="flex flex-col justify-between md:col-span-1 xl:col-span-4">
        <p className="text-sm font-medium text-slate-600">{t('stats:medios_de_pago')}</p>
        {p.loading ? <Skeleton className="h-16 w-full" /> : payTotal <= 0 ? (
          <p className="text-sm text-slate-400">{t('stats:sin_pagos')}</p>
        ) : (
          <div className="space-y-3">
            <StackBar slices={pays} />
            <ul className="grid grid-cols-2 gap-x-4 gap-y-1.5">
              {pays.slice(0, 4).map((x, i) => (
                <li key={x.key} className="flex items-center justify-between gap-2 text-sm">
                  <span className="flex min-w-0 items-center gap-2">
                    <span className={`h-2.5 w-2.5 shrink-0 rounded-sm ${SLICE_TONES[Math.min(i, SLICE_TONES.length - 1)]}`} aria-hidden />
                    <span className="truncate text-slate-600">{x.label}</span>
                  </span>
                  <span className="shrink-0 whitespace-nowrap font-medium text-slate-900 num">{formatCurrency(x.value)}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </Card>

      {/* Ticket, arqueos y anuladas */}
      <div className="grid grid-cols-3 gap-4 md:col-span-1 xl:col-span-4 xl:grid-cols-1 xl:gap-3">
        <MiniFigure label={t('stats:ticket_promedio')} loading={p.loading}>
          <AnimatedNumber value={p.avgTicket} format={formatCurrency} className="text-xl font-semibold tracking-tight" />
        </MiniFigure>
        <MiniFigure label={t('sales:arqueos_del_mes')} loading={p.loading} note={p.cashSessions === 0 ? t('stats:sin_arqueos') : undefined}>
          <span className={`text-xl font-semibold num ${p.cashSessions === 0 ? 'text-slate-400' : 'text-slate-900'}`}>{int(p.cashSessions)}</span>
        </MiniFigure>
        <MiniFigure label={t('stats:anuladas')} loading={p.loading} note={p.cancelled === 0 ? t('stats:sin_anulaciones') : undefined}>
          <span className={`text-xl font-semibold num ${p.cancelled === 0 ? 'text-slate-400' : 'text-rose-700'}`}>{int(p.cancelled)}</span>
        </MiniFigure>
      </div>
    </div>
  );
}

function MiniFigure({ label, loading, note, children }: { label: string; loading: boolean; note?: string; children: ReactNode }) {
  return (
    <div className="flex flex-col justify-between rounded-[14px] bg-white px-4 py-3 shadow-card xl:flex-row xl:items-center">
      <div className="min-w-0">
        <p className="text-xs font-medium text-slate-500">{label}</p>
        {note && <p className="hidden text-[0.72rem] text-slate-400 xl:block">{note}</p>}
      </div>
      <div className="mt-1 xl:mt-0">{loading ? <Skeleton className="h-6 w-20" /> : children}</div>
    </div>
  );
}

export default SalesQuickStats;
