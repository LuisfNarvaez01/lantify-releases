// ============================================
// POS - Puente con la pantalla del cliente (Fase 4 · 10)
// ============================================
// Mientras la caja arma o cobra un pedido, manda su carrito a la pantalla del
// cliente de este equipo (300 ms después del último cambio). Nunca detiene una
// venta: si falla, la pantalla simplemente no se actualiza.

import { useEffect, useRef, useState } from 'react';
import { usePosStore } from '../../store/usePosStore';
import { useFeatureFlag } from '../../shared/features';
import { customerDisplayAPI, type CustomerCartPayload } from '../../services/v3Api';
import { CUSTOMER_DISPLAY_CHANGED, getCustomerDisplayId } from '../../shared/customerDisplay';
import { t } from '../../i18n';

const DEBOUNCE_MS = 300;

const userRole = () => {
  try { return JSON.parse(localStorage.getItem('user') || '{}')?.role || ''; } catch { return ''; }
};

export function CustomerDisplayBridge() {
  const on = useFeatureFlag('customer_display');
  const [displayId, setDisplayId] = useState<string | null>(null);
  const cartsByTable = usePosStore((s) => s.cartsByTable);
  const selectedTable = usePosStore((s) => s.selectedTable);
  const totalPaid = usePosStore((s) => s.totalPaid);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const last = useRef('');

  // ¿A qué pantalla manda esta caja? La elegida aquí, o la única que haya
  useEffect(() => {
    if (!on || !['ADMIN', 'CASHIER'].includes(userRole())) { setDisplayId(null); return; }
    let alive = true;
    const pick = async () => {
      const chosen = getCustomerDisplayId();
      try {
        const list = await customerDisplayAPI.list();
        if (!alive) return;
        if (chosen && list.some((d) => d.id === chosen)) setDisplayId(chosen);
        else setDisplayId(list.length === 1 ? list[0].id : null);
      } catch {
        if (alive) setDisplayId(chosen);
      }
    };
    pick();
    window.addEventListener(CUSTOMER_DISPLAY_CHANGED, pick);
    return () => { alive = false; window.removeEventListener(CUSTOMER_DISPLAY_CHANGED, pick); };
  }, [on]);

  useEffect(() => {
    if (!displayId) return;
    const items = cartsByTable[selectedTable?.id || 'counter'] || [];
    const cart: CustomerCartPayload | null = items.length
      ? {
          label: selectedTable ? t('v3:mesa_n', { n: selectedTable.number }) : null,
          paid: selectedTable ? totalPaid : 0,
          lines: items.map((i) => ({
            name: [i.productName, i.variantName && i.variantName !== 'Única' ? i.variantName : ''].filter(Boolean).join(' · '),
            qty: i.quantity,
            unitPrice: i.unitPrice,
            note: [...(i.removed || []).map((r) => t('v3:sin_x', { x: r })), i.notes || ''].filter(Boolean).join(' · ') || null,
            badge: i.priceRuleName || null,
          })),
        }
      : null;
    const key = JSON.stringify(cart);
    if (key === last.current) return;
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => {
      last.current = key;
      customerDisplayAPI.publish(displayId, cart).catch(() => { last.current = ''; });
    }, DEBOUNCE_MS);
  }, [displayId, cartsByTable, selectedTable, totalPaid]);

  useEffect(() => () => { if (timer.current) clearTimeout(timer.current); }, []);
  return null;
}
