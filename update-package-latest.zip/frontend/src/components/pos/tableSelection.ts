import { useEffect, useState } from 'react';
import { usePosStore } from '../../store/usePosStore';
import type { Table, CartItem } from '../../types';

import { t as tr } from '../../i18n';
/** Pedido en curso de una mesa: el servidor o el store local */
export function summarizeTable(
  tableId: string,
  cartsByTable: Record<string, CartItem[]>,
  pendingOrdersByTable: Record<string, CartItem[]>
) {
  const cart = cartsByTable[tableId];
  const items = cart && cart.length > 0 ? cart : pendingOrdersByTable[tableId] || [];
  const total = items.reduce((sum, i) => sum + (i.total ?? i.quantity * i.unitPrice), 0);
  // Apertura de la mesa = primer envío a cocina
  const openedAt = items
    .map(i => i.orderedAt)
    .filter((v): v is string => !!v)
    .sort()[0];
  return { items, total, count: items.reduce((n, i) => n + i.quantity, 0), openedAt };
}

/** Fuerza un re-render cada minuto (para los tiempos de mesa) */
export function useMinuteTick() {
  const [, setTick] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setTick(t => t + 1), 60000);
    return () => clearInterval(id);
  }, []);
}

export function useTableSummaries() {
  const { cartsByTable, pendingOrdersByTable } = usePosStore();
  return (tableId: string) => summarizeTable(tableId, cartsByTable, pendingOrdersByTable);
}

/**
 * Resumen operativo de mesas (conteo por estado para los indicadores y filtros).
 */
export function getTableCounts(tables: Table[]) {
  const total = tables.length;
  let available = 0;
  let ordered = 0;
  let pending = 0;

  for (const t of tables) {
    if (t.status === 'ORDERED') ordered++;
    else if (t.status === 'PENDING') pending++;
    else available++;
  }

  return { total, available, ordered, pending };
}

/**
 * Formatea el tiempo transcurrido desde la apertura de la mesa.
 */
export function formatTableElapsed(iso?: string): string {
  if (!iso) return '';
  const mins = Math.floor((Date.now() - new Date(iso).getTime()) / 60000);
  if (mins < 1) return tr('pos:1_min');
  if (mins < 60) return `${mins} min`;
  return `${Math.floor(mins / 60)} h ${mins % 60} m`;
}

/**
 * Selección de mesa compartida por todas las vistas (lista lateral, plano, cuadrícula).
 * Garantiza el mismo comportamiento sin importar la vista activa.
 */
export function useTableSelection() {
  const { selectTable, loadTableSale, loadPendingOrderToCart, getPendingOrder } = usePosStore();

  return async (table: Table | null) => {
    selectTable(table);
    if (!table) return;

    if (table.status === 'ORDERED' || table.status === 'PENDING') {
      await loadTableSale(table.id);
      if (getPendingOrder(table.id).length > 0) {
        loadPendingOrderToCart(table.id);
      }
    }
  };
}

export const TABLE_STATUS_META: Record<string, { label: string; dot: string; border: string; card: string; badge: string }> = {
  AVAILABLE: {
    get label() { return tr('pos:libre'); },
    dot: 'bg-emerald-500',
    border: 'border-emerald-300',
    card: 'border-emerald-200/90 bg-emerald-50/40 hover:border-emerald-400 hover:bg-emerald-50/70 text-emerald-950',
    badge: 'bg-emerald-100 text-emerald-800 border border-emerald-200/60',
  },
  ORDERED: {
    get label() { return tr('pos:en_consumo'); },
    dot: 'bg-amber-500',
    border: 'border-amber-400',
    card: 'border-amber-300/90 bg-amber-50/50 hover:border-amber-500 hover:bg-amber-50/80 text-amber-950',
    badge: 'bg-amber-100 text-amber-800 border border-amber-200/60',
  },
  PENDING: {
    get label() { return tr('pos:por_cobrar'); },
    dot: 'bg-violet-500',
    border: 'border-violet-400',
    card: 'border-violet-300/90 bg-violet-50/50 hover:border-violet-500 hover:bg-violet-50/80 text-violet-950',
    badge: 'bg-violet-100 text-violet-800 border border-violet-200/60',
  },
  RESERVED: {
    get label() { return tr('pos:reservada'); },
    dot: 'bg-slate-400',
    border: 'border-slate-300',
    card: 'border-slate-200 bg-slate-50/50 hover:border-slate-400 text-slate-800',
    badge: 'bg-slate-100 text-slate-700 border border-slate-200',
  },
};
