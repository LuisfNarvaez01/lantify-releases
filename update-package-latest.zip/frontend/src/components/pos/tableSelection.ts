import { useFeatures } from '../../shared/features';
import { useOpenTableDialog } from './OpenTableDialog';
import { useEffect, useState } from 'react';
import { usePosStore } from '../../store/usePosStore';
import type { Table, CartItem } from '../../types';

import { t as tr } from '../../i18n';
import { floorAPI } from '../../services/v3Api';
import { ordersAPI } from '../../services/api';
import { useFloorStore } from '../../shared/features';
import { toast } from '../../shared/toast';
import type { TableAlert } from '../../../../src/domain/v3/tableAlerts';
/** Pedido en curso de una mesa: el servidor o el store local */
export function summarizeTable(
  tableId: string,
  cartsByTable: Record<string, CartItem[]>,
  pendingOrdersByTable: Record<string, CartItem[]>
) {
  const cart = cartsByTable[tableId];
  const items = cart && cart.length > 0 ? cart : pendingOrdersByTable[tableId] || [];
  const total = items.reduce((sum, i) => sum + (i.total ?? i.quantity * i.unitPrice), 0);
  // Apertura de la mesa = primer envío a cocina
  const openedAt = items
    .map(i => i.orderedAt)
    .filter((v): v is string => !!v)
    .sort()[0];
  return { items, total, count: items.reduce((n, i) => n + i.quantity, 0), openedAt };
}

/** Fuerza un re-render cada minuto (para los tiempos de mesa) */
export function useMinuteTick() {
  const [, setTick] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setTick(t => t + 1), 60000);
    return () => clearInterval(id);
  }, []);
}

export function useTableSummaries() {
  const { cartsByTable, pendingOrdersByTable } = usePosStore();
  return (tableId: string) => summarizeTable(tableId, cartsByTable, pendingOrdersByTable);
}

/**
 * Resumen operativo de mesas (conteo por estado para los indicadores y filtros).
 */
export function getTableCounts(tables: Table[]) {
  const total = tables.length;
  let available = 0;
  let ordered = 0;
  let pending = 0;

  for (const t of tables) {
    if (t.status === 'ORDERED') ordered++;
    else if (t.status === 'PENDING') pending++;
    else available++;
  }

  return { total, available, ordered, pending };
}

/**
 * Formatea el tiempo transcurrido desde la apertura de la mesa.
 */
export function formatTableElapsed(iso?: string): string {
  if (!iso) return '';
  const mins = Math.floor((Date.now() - new Date(iso).getTime()) / 60000);
  if (mins < 1) return tr('pos:1_min');
  if (mins < 60) return `${mins} min`;
  return `${Math.floor(mins / 60)} h ${mins % 60} m`;
}

/**
 * Selección de mesa compartida por todas las vistas (lista lateral, plano, cuadrícula).
 * Garantiza el mismo comportamiento sin importar la vista activa.
 */
export function useTableSelection() {
  const { selectTable, loadTableSale, loadPendingOrderToCart, getPendingOrder } = usePosStore();

  /** false = no se abrió (canceló la ventana o era una mesa por limpiar) */
  return async (table: Table | null): Promise<boolean> => {
    // Mesa por limpiar: un toque la deja libre (no se abre pedido sobre una mesa sucia)
    if (table && table.status === 'DIRTY') {
      try {
        await floorAPI.clean(table.id);
        await usePosStore.getState().fetchTables();
        useFloorStore.getState().refresh();
        toast.success(tr('v3:mesa_limpia', { number: table.number }));
      } catch (err: any) {
        toast.error(err?.message || tr('v3:no_se_guardo'));
      }
      return false;
    }
    // Abrir mesa con personas, descripción y cliente (si la función está encendida)
    let details: { guests: number | null; label: string | null } = { guests: null, label: null };
    if (table && table.status === 'AVAILABLE' && useFeatures.getState().settings.flags.table_details) {
      const r = await useOpenTableDialog.getState().ask(table.number, { guests: null, label: null, customer: null });
      if (r === null) return false;
      if (r !== 'skip') {
        details = { guests: r.guests, label: r.label };
        usePosStore.getState().setTableDetails(table.id, details);
        if (r.customer) usePosStore.getState().selectCustomerForTable(table.id, r.customer);
      }
    }
    selectTable(table);
    if (!table) return true;

    // La mesa queda ocupada desde que se abre (con quién la abrió), aunque aún no
    // tenga nada pedido. Sin conexión se sigue igual: se guarda al enviar el pedido.
    if (table.status === 'AVAILABLE') {
      try {
        const saved = await ordersAPI.save({ tableId: table.id, items: [], ...details });
        if (saved?.id) usePosStore.setState((st) => ({ serverOrderIdByTable: { ...st.serverOrderIdByTable, [table.id]: saved.id } }));
        await usePosStore.getState().fetchTables();
        useFloorStore.getState().refresh();
      } catch { /* sin conexión: la mesa se ocupa al enviar el primer pedido */ }
      return true;
    }

    if (table.status === 'ORDERED' || table.status === 'PENDING') {
      await loadTableSale(table.id);
      if (getPendingOrder(table.id).length > 0) {
        loadPendingOrderToCart(table.id);
      }
    }
    return true;
  };
}

export const TABLE_STATUS_META: Record<string, { label: string; dot: string; border: string; card: string; badge: string }> = {
  AVAILABLE: {
    get label() { return tr('pos:libre'); },
    dot: 'bg-emerald-500',
    border: 'border-emerald-300',
    card: 'border-emerald-200/90 bg-emerald-50/40 hover:border-emerald-400 hover:bg-emerald-50/70 text-emerald-950',
    badge: 'bg-emerald-100 text-emerald-800 border border-emerald-200/60',
  },
  ORDERED: {
    get label() { return tr('pos:en_consumo'); },
    dot: 'bg-amber-500',
    border: 'border-amber-400',
    card: 'border-amber-300/90 bg-amber-50/50 hover:border-amber-500 hover:bg-amber-50/80 text-amber-950',
    badge: 'bg-amber-100 text-amber-800 border border-amber-200/60',
  },
  PENDING: {
    get label() { return tr('pos:por_cobrar'); },
    dot: 'bg-violet-500',
    border: 'border-violet-400',
    card: 'border-violet-300/90 bg-violet-50/50 hover:border-violet-500 hover:bg-violet-50/80 text-violet-950',
    badge: 'bg-violet-100 text-violet-800 border border-violet-200/60',
  },
  DIRTY: {
    get label() { return tr('v3:por_limpiar'); },
    dot: 'bg-slate-500',
    border: 'border-slate-400',
    card: 'border-dashed border-slate-400 bg-slate-100/70 hover:border-slate-600 text-slate-700',
    badge: 'bg-slate-200 text-slate-800 border border-slate-300',
  },
  RESERVED: {
    get label() { return tr('pos:reservada'); },
    dot: 'bg-slate-400',
    border: 'border-slate-300',
    card: 'border-slate-200 bg-slate-50/50 hover:border-slate-400 text-slate-800',
    badge: 'bg-slate-100 text-slate-700 border border-slate-200',
  },
};

/** Texto corto de una alerta de mesa */
export const alertText = (a: Pick<TableAlert, 'kind' | 'minutes'>) =>
  a.kind === 'bill' ? tr('v3:alerta_txt_bill', { min: a.minutes })
    : a.kind === 'ready' ? tr('v3:alerta_txt_ready', { min: a.minutes })
      : tr('v3:alerta_txt_idle', { min: a.minutes });

/**
 * Tonos por alerta, de la más urgente a la más suave. El texto siempre acompaña al
 * color. "hot" = lleva el doble del tiempo configurado: el tono se oscurece.
 */
const ALERT_LOOK: Record<string, { badge: string; card: string }> = {
  pickup: { badge: 'bg-teal-600 text-white border border-teal-700', card: 'table-alert table-alert-pickup' },
  bill: { badge: 'bg-rose-100 text-rose-800 border border-rose-300', card: 'table-alert table-alert-bill' },
  'bill-hot': { badge: 'bg-rose-600 text-white border border-rose-700', card: 'table-alert table-alert-bill-hot' },
  idle: { badge: 'bg-amber-100 text-amber-900 border border-amber-300', card: 'table-alert table-alert-idle' },
  'idle-hot': { badge: 'bg-orange-500 text-white border border-orange-600', card: 'table-alert table-alert-idle-hot' },
  ready: { badge: 'bg-sky-100 text-sky-900 border border-sky-300', card: 'table-alert table-alert-ready' },
};

/** Mesa abierta sin nada enviado todavía */
const OPEN_LOOK = { badge: 'bg-blue-100 text-blue-800 border border-blue-200', card: 'border-blue-300 bg-blue-50/50 hover:border-blue-500 text-blue-950' };

/**
 * Aspecto de una mesa: su estado y, si la hay, la alerta del salón (pulso suave,
 * borde y texto; nunca solo color). Prioridad: platos listos en cocina > cuenta >
 * servida hace rato > sin pedir. También dice quién la abrió. `plain` lo
 * desactiva (editor del plano).
 */
export function useTableLook() {
  const floor = useFloorStore((s) => s.floor);
  const cfg = useFeatures((s) => s.settings.alerts);
  return (table: Table, plain = false) => {
    const meta = TABLE_STATUS_META[table.status] || TABLE_STATUS_META.AVAILABLE;
    const info = floor.tables.find((t) => t.tableId === table.id);
    const waiterName = info?.waiterName || null;
    const base = { ...meta, alert: undefined as TableAlert | undefined, waiterName, pickup: 0 };
    if (plain) return base;
    const pickup = (floor.pickups || []).find((p) => p.tableId === table.id);
    if (pickup) {
      return { ...base, badge: ALERT_LOOK.pickup.badge, card: `${meta.card} ${ALERT_LOOK.pickup.card}`, label: tr('v3:listo_en_cocina', { count: pickup.count }), pickup: pickup.count };
    }
    const alert = floor.alerts.find((a) => a.tableId === table.id);
    if (alert) {
      const limit = alert.kind === 'bill' ? cfg?.billMin : alert.kind === 'idle' ? cfg?.idleMin : undefined;
      const hot = !!limit && alert.minutes >= limit * 2;
      const look = ALERT_LOOK[hot ? `${alert.kind}-hot` : alert.kind] || ALERT_LOOK.idle;
      return { ...base, label: alertText(alert), badge: look.badge, card: `${meta.card} ${look.card}`, alert };
    }
    // Abierta pero sin nada enviado: se ve distinta de "en consumo"
    if (table.status === 'ORDERED' && info && !info.lastRoundAt) {
      return { ...base, label: tr('v3:mesa_abierta'), badge: OPEN_LOOK.badge, card: OPEN_LOOK.card, dot: 'bg-blue-500' };
    }
    return base;
  };
}
