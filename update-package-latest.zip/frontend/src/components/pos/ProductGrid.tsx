import { SuggestionsBar } from '../v3/SuggestionsBar';
import { isProductPaused } from '../../shared/productState';
// ============================================
// COMPONENTS - Product Grid with Variant Selection & Barcode Scanner (Lantify POS)
// ============================================

import React, { useState, useMemo, useRef, useEffect } from 'react';
import { usePosStore } from '../../store/usePosStore';
import type { Product } from '../../types';
import { Tag, Search, X, LayoutGrid, List, Barcode, Check } from 'lucide-react';
import { formatCurrency } from '../../shared/formatUtils';

import { t } from '../../i18n';
import { mediaSrc } from '../../shared/media';
const normalizeText = (text: string): string => {
  return (text || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim();
};

interface ProductCardProps {
  product: Product;
  onSelect: (product: Product) => void;
  cartCount: number;
  viewMode: 'grid' | 'compact';
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onSelect, cartCount, viewMode }) => {
  const hasVariants = product.variants && product.variants.length > 1;
  const lowestPrice = product.variants?.length
    ? Math.min(...product.variants.map(v => v.price))
    : 0;

  // Solo las variantes con control de inventario pueden estar agotadas
  const trackedVariants = product.variants?.filter(v => v.trackInventory) ?? [];
  const tracksStock = trackedVariants.length > 0;
  const allVariantsTracked = tracksStock && trackedVariants.length === product.variants.length;
  const isOutOfStock = allVariantsTracked && trackedVariants.every(v => (v.stock ?? 0) <= 0);
  const totalStock = tracksStock ? trackedVariants.reduce((sum, v) => sum + (v.stock || 0), 0) : null;
  const isLowStock = tracksStock && !isOutOfStock && totalStock !== null && totalStock <= 5;
  // Pausado (Autopilot o a mano por falta de existencias): no se puede pedir
  const isPaused = isProductPaused(product);
  const isInactive = product.isActive === false || isPaused;
  const isDisabled = isOutOfStock || isInactive;
  const inCart = cartCount > 0;

  // Estado del producto en texto (nunca solo color)
  const status = isInactive
    ? <span className="text-slate-500">{isPaused ? t('pos:pausado') : t('pos:no_disponible')}</span>
    : isOutOfStock
      ? <span className="font-medium text-rose-700">{t('pos:agotado')}</span>
      : isLowStock
        ? <span className="font-medium text-amber-700">{t('pos:quedan_totalstock', { totalStock })}</span>
        : null;

  const price = hasVariants ? (
    <span className="text-slate-600"><span className="text-xs text-slate-500">{t('pos:desde_corto')} </span><span className="font-semibold text-slate-900">{formatCurrency(lowestPrice)}</span></span>
  ) : product.variants?.[0] ? (
    <span className="font-semibold text-slate-900">{formatCurrency(product.variants[0].price)}</span>
  ) : (
    <span className="text-xs text-slate-400">{t('pos:sin_precio')}</span>
  );

  // Contador "en el pedido": esquina superior derecha, sin tapar el nombre
  const counter = inCart && (
    <span className="lt-pop absolute -right-1.5 -top-1.5 z-10 inline-flex h-6 min-w-[1.5rem] items-center justify-center rounded-full bg-blue-600 px-1.5 text-xs font-semibold text-white shadow-card num" aria-label={t('pos:en_pedido_n', { n: cartCount })}>
      {cartCount}
    </span>
  );

  const base = [
    'relative w-full text-left select-none bg-white transition-[box-shadow,transform,background-color] duration-fast ease-out',
    isDisabled
      ? 'cursor-not-allowed bg-slate-50 opacity-60'
      : 'shadow-card hover:shadow-raised active:scale-[0.98]',
    // Selección (está en el pedido) = anillo azul; no se mezcla con el estado del producto
    inCart && !isDisabled ? 'ring-2 ring-blue-600' : '',
  ].join(' ');

  if (viewMode === 'compact') {
    return (
      <button type="button" onClick={() => onSelect(product)} disabled={isDisabled} className={`${base} flex min-h-[52px] items-center justify-between gap-3 rounded-[12px] px-3.5 py-2.5`}>
        {counter}
        <span className="flex min-w-0 items-center gap-3">
          {product.imageUrl && (
            <img src={mediaSrc(product.imageUrl)} alt="" className="h-9 w-9 shrink-0 rounded-lg object-cover" loading="lazy" />
          )}
          <span className="min-w-0">
            <span className="block truncate text-[0.95rem] font-medium leading-snug text-slate-900">{product.name}</span>
            <span className="flex items-center gap-2 text-xs text-slate-500">
              {status ?? (hasVariants ? t('pos:n_opciones', { n: product.variants.length }) : null)}
            </span>
          </span>
        </span>
        <span className="shrink-0 text-sm num">{price}</span>
      </button>
    );
  }

  // Tarjeta estándar: nombre primero, foto solo si el producto la tiene
  return (
    <button type="button" onClick={() => onSelect(product)} disabled={isDisabled} className={`${base} flex min-h-[112px] flex-col rounded-[14px] p-3`}>
      {counter}
      {product.imageUrl && (
        <img src={mediaSrc(product.imageUrl)} alt="" className="mb-2.5 h-20 w-full rounded-[10px] object-cover" loading="lazy" />
      )}
      <span className="line-clamp-2 text-[0.95rem] font-medium leading-snug text-slate-900">{product.name}</span>
      <span className="mt-auto flex items-end justify-between gap-2 pt-2.5">
        <span className="text-sm num">{price}</span>
        {hasVariants && !status && (
          <span className="shrink-0 rounded-full bg-slate-100 px-2 py-0.5 text-[0.72rem] font-medium text-slate-600">{t('pos:n_opciones', { n: product.variants.length })}</span>
        )}
      </span>
      {status && <span className="mt-1.5 text-xs">{status}</span>}
    </button>
  );
};

const VIEW_KEY = 'lantify.pos.catalogView';
const readView = (): 'grid' | 'compact' => {
  try { return localStorage.getItem(VIEW_KEY) === 'compact' ? 'compact' : 'grid'; } catch { return 'grid'; }
};

export const ProductGrid: React.FC = () => {
  const { 
    products, 
    categories, 
    selectedCategory, 
    setSelectedCategory,
    openVariantModal,
    addToCart,
    getCurrentCart,
    isLoadingProducts 
  } = usePosStore();

  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewModeState] = useState<'grid' | 'compact'>(readView);
  // La vista del catálogo se recuerda en este equipo
  const setViewMode = (v: 'grid' | 'compact') => {
    setViewModeState(v);
    try { localStorage.setItem(VIEW_KEY, v); } catch { /* sin almacenamiento */ }
  };
  const [barcodeFeedback, setBarcodeFeedback] = useState<string | null>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Atajo "/" para ir al buscador desde cualquier parte de la pantalla de pedidos
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== '/' || e.ctrlKey || e.metaKey || e.altKey) return;
      const target = e.target as HTMLElement;
      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT' || target.isContentEditable) return;
      e.preventDefault();
      searchInputRef.current?.focus();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  // Mapear cantidades en el carrito actual para mostrar "×N en pedido"
  const cart = getCurrentCart();
  const cartCountsByProduct = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const item of cart) {
      counts[item.productId] = (counts[item.productId] || 0) + item.quantity;
    }
    return counts;
  }, [cart]);

  // Conteos de productos por categoría para los chips
  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const p of products) {
      if (p.categoryId) {
        counts[p.categoryId] = (counts[p.categoryId] || 0) + 1;
      }
    }
    return counts;
  }, [products]);

  // Atajo de teclado: Ctrl+K o '/' enfoca el buscador
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey && e.key === 'k') || (e.key === '/' && document.activeElement?.tagName !== 'INPUT' && document.activeElement?.tagName !== 'TEXTAREA')) {
        e.preventDefault();
        searchInputRef.current?.focus();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Filtrado de productos normalizado (sin tildes, mayúsculas ni espacios superfluos)
  const filteredProducts = useMemo(() => {
    let filtered = products;
    
    if (selectedCategory) {
      filtered = filtered.filter(p => p.categoryId === selectedCategory);
    }
    
    if (searchQuery.trim()) {
      const queryNorm = normalizeText(searchQuery);
      filtered = filtered.filter(p => {
        const nameNorm = normalizeText(p.name);
        const skuMatch = p.variants?.some(v => normalizeText(v.sku || '').includes(queryNorm) || normalizeText(v.barcode || '').includes(queryNorm));
        const variantMatch = p.variants?.some(v => normalizeText(v.name).includes(queryNorm));
        return nameNorm.includes(queryNorm) || skuMatch || variantMatch;
      });
    }
    
    return filtered;
  }, [products, selectedCategory, searchQuery]);

  const handleProductSelect = (product: Product) => {
    if (product.variants && product.variants.length > 1) {
      openVariantModal(product);
    } else if (product.variants && product.variants.length === 1) {
      addToCart(product, product.variants[0]);
    } else {
      console.warn('Product has no variants:', product.name);
    }
  };

  // Manejador para lector de código de barras (Enter automático al escanear o presionar Enter)
  const handleSearchKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && searchQuery.trim()) {
      e.preventDefault();
      const rawQuery = searchQuery.trim();
      const queryNorm = normalizeText(rawQuery);

      // 1. Buscar coincidencia exacta por código de barras o SKU
      let matchedProduct: Product | undefined;
      let matchedVariant: any = null;

      for (const p of products) {
        for (const v of p.variants || []) {
          const vBarcode = v.barcode ? normalizeText(v.barcode) : '';
          const vSku = v.sku ? normalizeText(v.sku) : '';
          if ((vBarcode && vBarcode === queryNorm) || (vSku && vSku === queryNorm)) {
            matchedProduct = p;
            matchedVariant = v;
            break;
          }
        }
        if (matchedProduct) break;
      }

      // 2. Si no hay SKU exacto pero el filtro devuelve exactamente 1 producto
      if (!matchedProduct && filteredProducts.length === 1) {
        matchedProduct = filteredProducts[0];
        if (matchedProduct.variants && matchedProduct.variants.length === 1) {
          matchedVariant = matchedProduct.variants[0];
        }
      }

      if (matchedProduct) {
        if (matchedVariant) {
          addToCart(matchedProduct, matchedVariant);
          setBarcodeFeedback(t('pos:agregado_name_name2', { name: matchedProduct.name, name2: matchedVariant.name }));
        } else {
          openVariantModal(matchedProduct);
          setBarcodeFeedback(t('pos:selecciona_variante_de_name', { name: matchedProduct.name }));
        }
        setSearchQuery('');
        setTimeout(() => setBarcodeFeedback(null), 3000);
      }
    }
  };

  const handleClearSearch = () => {
    setSearchQuery('');
    searchInputRef.current?.focus();
  };

  if (isLoadingProducts) {
    return (
      <div className="flex flex-col items-center justify-center h-64 gap-3">
        <div className="animate-spin rounded-full h-8 w-8 border-3 border-slate-200 border-t-blue-600"></div>
        <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">{t('pos:cargando_catalogo')}</p>
      </div>
    );
  }

  return (
    <div className="space-y-3.5 select-none">
      <SuggestionsBar />
      {/* 1. Barra de Búsqueda Normalizada + Lector de Código de Barras + Switcher de Vista */}
      <div className="flex items-center gap-2.5">
        <div className="relative flex-1" data-guide="product-search">
          <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400">
            <Search className="w-4 h-4" />
          </div>
          <input
            ref={searchInputRef}
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={handleSearchKeyDown}
            placeholder={t('pos:buscar_producto_codigo_de_barras_o_sku')}
            aria-label={t('pos:buscar_producto_por_nombre_codigo_de_barras')}
            className="w-full pl-10 pr-20 py-2.5 bg-white border border-slate-200 rounded-xl focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 focus:outline-none text-slate-900 placeholder-slate-400 text-xs sm:text-sm font-medium shadow-xs"
          />
          <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1.5">
            {searchQuery ? (
              <button
                onClick={handleClearSearch}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-md"
                title={t('pos:limpiar_busqueda')}
              >
                <X className="w-4 h-4" />
              </button>
            ) : (
              <span className="hidden sm:inline-flex items-center gap-1 px-1.5 py-0.5 text-xs font-mono font-bold text-slate-400 bg-slate-100 rounded border border-slate-200">
                <Barcode className="w-3 h-3 text-slate-400" />
                {t('pos:lector_activo')}
              </span>
            )}
          </div>
        </div>

        {/* Conmutador de Vista (Cuadrícula / Lista compacta) */}
        <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 shrink-0">
          <button
            type="button"
            onClick={() => setViewMode('grid')}
            title={t('pos:vista_cuadricula')}
            className={`p-1.5 rounded-lg transition-all ${
              viewMode === 'grid' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <LayoutGrid className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => setViewMode('compact')}
            title={t('pos:vista_lista_compacta')}
            className={`p-1.5 rounded-lg transition-all ${
              viewMode === 'compact' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <List className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Notificación de Producto Escaneado */}
      {barcodeFeedback && (
        <div className="px-3 py-1.5 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-xl text-xs font-bold flex items-center gap-2 animate-in fade-in duration-150">
          <Check className="w-4 h-4 text-emerald-600" />
          {barcodeFeedback}
        </div>
      )}

      {/* 2. Chips de Categorías con Contadores (Sin dropdown redundante) */}
      <div data-guide="product-categories" className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-hide">
        <button
          onClick={() => setSelectedCategory(null)}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all shrink-0 flex items-center gap-1.5 border ${
            selectedCategory === null
              ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
              : 'bg-white text-slate-700 hover:bg-slate-50 border-slate-200'
          }`}
        >
          <span>{t('pos:todas')}</span>
          <span className={`text-xs font-black px-1.5 py-0.2 rounded-md ${
            selectedCategory === null ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'
          }`}>
            {products.length}
          </span>
        </button>

        {categories.map((cat) => {
          const isSelected = selectedCategory === cat.id;
          const count = categoryCounts[cat.id] || 0;
          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all shrink-0 flex items-center gap-1.5 border ${
                isSelected
                  ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                  : 'bg-white text-slate-700 hover:bg-slate-50 border-slate-200'
              }`}
            >
              <span>{cat.name}</span>
              <span className={`text-xs font-black px-1.5 py-0.2 rounded-md ${
                isSelected ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'
              }`}>
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Indicador de Filtros Activos */}
      {(searchQuery || selectedCategory) && (
        <div className="flex items-center gap-2 flex-wrap text-xs">
          {searchQuery && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-blue-50 text-blue-700 border border-blue-200 rounded-lg font-semibold">
              {t('pos:busqueda_searchquery', { searchQuery })}
              <button onClick={handleClearSearch} className="hover:text-blue-900 p-0.5">
                <X className="w-3 h-3" />
              </button>
            </span>
          )}
          {selectedCategory && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-100 text-slate-700 border border-slate-200 rounded-lg font-semibold">
              {t('pos:categoria_value', { value: categories.find(c => c.id === selectedCategory)?.name || t('pos:seleccionada') })}
              <button onClick={() => setSelectedCategory(null)} className="hover:text-slate-900 p-0.5">
                <X className="w-3 h-3" />
              </button>
            </span>
          )}
          <span className="text-slate-400 font-medium ml-auto text-xs">
            {t('pos:productos_count', { count: filteredProducts.length })}
          </span>
        </div>
      )}

      {/* 3. Cuadrícula / Lista de Productos */}
      {viewMode === 'grid' ? (
        <div data-guide="product-grid" className="grid gap-3 pr-1.5 pt-1.5 [grid-template-columns:repeat(auto-fill,minmax(9.5rem,1fr))]">
          {filteredProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onSelect={handleProductSelect}
              cartCount={cartCountsByProduct[product.id] || 0}
              viewMode="grid"
            />
          ))}
        </div>
      ) : (
        <div className="grid gap-2 pr-1.5 pt-1.5 [grid-template-columns:repeat(auto-fill,minmax(17rem,1fr))]">
          {filteredProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onSelect={handleProductSelect}
              cartCount={cartCountsByProduct[product.id] || 0}
              viewMode="compact"
            />
          ))}
        </div>
      )}

      {/* Estado Vacío */}
      {filteredProducts.length === 0 && (
        <div className="text-center py-16 text-slate-400 bg-white rounded-2xl border border-slate-200 space-y-1">
          <Tag className="w-10 h-10 mx-auto opacity-40 text-slate-400" />
          <p className="font-bold text-slate-700 text-sm">{t('pos:no_se_encontraron_productos')}</p>
          <p className="text-xs text-slate-400">{t('pos:intenta_con_otros_terminos_o_cambia_de')}</p>
        </div>
      )}
    </div>
  );
};

export default ProductGrid;
