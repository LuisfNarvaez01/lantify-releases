import { SuggestionsBar } from '../v3/SuggestionsBar';
import { isProductPaused } from '../../shared/productState';
// ============================================
// COMPONENTS - Product Grid with Variant Selection & Barcode Scanner (Lantify POS)
// ============================================

import React, { useState, useMemo, useRef, useEffect } from 'react';
import { usePosStore } from '../../store/usePosStore';
import type { Product } from '../../types';
import { Tag, Search, X, LayoutGrid, List, Barcode, Check } from 'lucide-react';
import { formatCurrency } from '../../shared/formatUtils';

import { t } from '../../i18n';
import { mediaSrc } from '../../shared/media';
const normalizeText = (text: string): string => {
  return (text || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim();
};

interface ProductCardProps {
  product: Product;
  onSelect: (product: Product) => void;
  cartCount: number;
  viewMode: 'grid' | 'compact';
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onSelect, cartCount, viewMode }) => {
  const hasVariants = product.variants && product.variants.length > 1;
  const lowestPrice = product.variants?.length 
    ? Math.min(...product.variants.map(v => v.price))
    : 0;

  // Solo las variantes con control de inventario pueden estar agotadas
  const trackedVariants = product.variants?.filter(v => v.trackInventory) ?? [];
  const tracksStock = trackedVariants.length > 0;
  const allVariantsTracked = tracksStock && trackedVariants.length === product.variants.length;
  const isOutOfStock = allVariantsTracked && trackedVariants.every(v => (v.stock ?? 0) <= 0);
  const totalStock = tracksStock ? trackedVariants.reduce((sum, v) => sum + (v.stock || 0), 0) : null;
  const isLowStock = tracksStock && !isOutOfStock && totalStock !== null && totalStock <= 5;
  // Pausado (Autopilot o a mano por falta de existencias): no se puede pedir
  const isPaused = isProductPaused(product);
  const isInactive = product.isActive === false || isPaused;

  const isDisabled = isOutOfStock || isInactive;

  if (viewMode === 'compact') {
    return (
      <button
        onClick={() => onSelect(product)}
        disabled={isDisabled}
        className={`w-full flex items-center justify-between p-3 bg-white rounded-xl border transition-all text-left group select-none shadow-xs ${
          isDisabled
            ? 'opacity-60 bg-slate-50/80 border-slate-200 cursor-not-allowed'
            : 'border-slate-200/90 hover:border-blue-500 hover:bg-blue-50/20 active:bg-blue-50'
        }`}
      >
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 rounded-lg bg-slate-100 flex items-center justify-center shrink-0 overflow-hidden">
            {product.imageUrl ? (
              <img src={mediaSrc(product.imageUrl)} alt={product.name} className="w-full h-full object-cover" loading="lazy" />
            ) : (
              <Tag className="w-4 h-4 text-slate-400 group-hover:text-blue-500" />
            )}
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <h4 className="font-bold text-xs text-slate-900 truncate font-heading group-hover:text-blue-600">
                {product.name}
              </h4>
              {cartCount > 0 && (
                <span className="px-1.5 py-0.2 bg-blue-600 text-white text-xs font-black rounded-md shrink-0">
                  ×{cartCount}
                </span>
              )}
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
              {isInactive ? (
                <span className="text-slate-500 font-bold bg-slate-100 px-1.5 rounded">{isPaused ? t('pos:pausado') : t('pos:no_disponible')}</span>
              ) : isOutOfStock ? (
                <span className="text-rose-600 font-bold bg-rose-50 px-1.5 rounded">{t('pos:agotado')}</span>
              ) : hasVariants ? (
                <span>{product.variants.length}{' '}{t('pos:variantes')}</span>
              ) : (
                <span>{t('pos:sku')}{' '}{product.variants?.[0]?.sku || t('pos:s_n')}</span>
              )}
            </div>
          </div>
        </div>

        <div className="text-right shrink-0 ml-2">
          {hasVariants ? (
            <span className="text-xs font-bold text-blue-600 tabular-nums">
              {t('pos:desde_amount', { amount: formatCurrency(lowestPrice) })}
            </span>
          ) : product.variants?.[0] ? (
            <span className="text-xs font-black text-slate-900 tabular-nums">
              {formatCurrency(product.variants[0].price)}
            </span>
          ) : (
            <span className="text-xs text-slate-400">{t('pos:sin_precio')}</span>
          )}
        </div>
      </button>
    );
  }

  // Vista cuadrícula normal
  return (
    <button
      onClick={() => onSelect(product)}
      disabled={isDisabled}
      className={`relative flex flex-col items-center justify-between p-3.5 bg-white rounded-2xl border transition-all text-left group min-h-[148px] shadow-xs select-none ${
        isDisabled 
          ? 'opacity-60 bg-slate-50/80 border-slate-200 cursor-not-allowed'
          : 'border-slate-200/90 hover:border-blue-500 hover:shadow-md hover:-translate-y-0.5 active:translate-y-0 active:scale-[0.98]'
      }`}
    >
      {/* Insignia "×N en pedido" */}
      {cartCount > 0 && (
        <span className="absolute top-2 left-2 z-10 px-2 py-0.5 text-xs font-black bg-blue-600 text-white rounded-lg shadow-sm flex items-center gap-1">
          <Check className="w-3 h-3" /> ×{cartCount}
        </span>
      )}

      {/* Imagen / Ícono */}
      <div className="w-full flex justify-center mb-2 relative">
        {product.imageUrl ? (
          <img 
            src={mediaSrc(product.imageUrl)} 
            alt={product.name}
            className="w-16 h-16 object-cover rounded-xl shadow-xs"
            loading="lazy"
          />
        ) : (
          <div className="w-16 h-16 bg-slate-100 group-hover:bg-blue-50 rounded-xl flex items-center justify-center transition-colors">
            <Tag className="w-6 h-6 text-slate-400 group-hover:text-blue-500 transition-colors" />
          </div>
        )}

        {/* Estado: No disponible / Agotado / Poco stock */}
        {isInactive ? (
          <span className="absolute -bottom-1 px-2 py-0.5 text-xs font-black uppercase tracking-wider bg-slate-700 text-white rounded-md shadow-xs">
            {isPaused ? t('pos:pausado') : t('pos:no_disponible')}
          </span>
        ) : isOutOfStock ? (
          <span className="absolute -bottom-1 px-2 py-0.5 text-xs font-black uppercase tracking-wider bg-rose-600 text-white rounded-md shadow-xs">
            {t('pos:agotado')}
          </span>
        ) : isLowStock ? (
          <span className="absolute -bottom-1 px-1.5 py-0.5 text-xs font-bold bg-amber-500 text-white rounded-md shadow-xs">
            {t('pos:quedan_totalstock', { totalStock })}
          </span>
        ) : null}
      </div>

      {/* Nombre del producto */}
      <div className="w-full text-center flex-1 flex flex-col justify-center px-0.5">
        <h3 className="font-bold text-slate-800 line-clamp-2 text-xs leading-snug group-hover:text-blue-600 transition-colors font-heading">
          {product.name}
        </h3>
      </div>

      {/* Precio */}
      <div className="w-full pt-2 mt-1 border-t border-slate-100 flex items-center justify-center">
        {hasVariants ? (
          <div className="text-xs text-blue-600 font-bold tabular-nums">
            {t('pos:desde_amount', { amount: formatCurrency(lowestPrice) })}
          </div>
        ) : product.variants?.[0] ? (
          <div className="text-sm font-black text-slate-900 tabular-nums">
            {formatCurrency(product.variants[0].price)}
          </div>
        ) : (
          <div className="text-xs text-slate-400 font-medium">{t('pos:sin_precio')}</div>
        )}
      </div>

      {/* Variantes */}
      {hasVariants && (
        <span className="absolute top-2 right-2 px-1.5 py-0.5 text-xs font-black bg-blue-600 text-white rounded-md shadow-xs">
          {t('pos:length_var', { length: product.variants.length })}
        </span>
      )}
    </button>
  );
};

export const ProductGrid: React.FC = () => {
  const { 
    products, 
    categories, 
    selectedCategory, 
    setSelectedCategory,
    openVariantModal,
    addToCart,
    getCurrentCart,
    isLoadingProducts 
  } = usePosStore();

  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'compact'>('grid');
  const [barcodeFeedback, setBarcodeFeedback] = useState<string | null>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Atajo "/" para ir al buscador desde cualquier parte de la pantalla de pedidos
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== '/' || e.ctrlKey || e.metaKey || e.altKey) return;
      const target = e.target as HTMLElement;
      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT' || target.isContentEditable) return;
      e.preventDefault();
      searchInputRef.current?.focus();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  // Mapear cantidades en el carrito actual para mostrar "×N en pedido"
  const cart = getCurrentCart();
  const cartCountsByProduct = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const item of cart) {
      counts[item.productId] = (counts[item.productId] || 0) + item.quantity;
    }
    return counts;
  }, [cart]);

  // Conteos de productos por categoría para los chips
  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const p of products) {
      if (p.categoryId) {
        counts[p.categoryId] = (counts[p.categoryId] || 0) + 1;
      }
    }
    return counts;
  }, [products]);

  // Atajo de teclado: Ctrl+K o '/' enfoca el buscador
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey && e.key === 'k') || (e.key === '/' && document.activeElement?.tagName !== 'INPUT' && document.activeElement?.tagName !== 'TEXTAREA')) {
        e.preventDefault();
        searchInputRef.current?.focus();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Filtrado de productos normalizado (sin tildes, mayúsculas ni espacios superfluos)
  const filteredProducts = useMemo(() => {
    let filtered = products;
    
    if (selectedCategory) {
      filtered = filtered.filter(p => p.categoryId === selectedCategory);
    }
    
    if (searchQuery.trim()) {
      const queryNorm = normalizeText(searchQuery);
      filtered = filtered.filter(p => {
        const nameNorm = normalizeText(p.name);
        const skuMatch = p.variants?.some(v => normalizeText(v.sku || '').includes(queryNorm) || normalizeText(v.barcode || '').includes(queryNorm));
        const variantMatch = p.variants?.some(v => normalizeText(v.name).includes(queryNorm));
        return nameNorm.includes(queryNorm) || skuMatch || variantMatch;
      });
    }
    
    return filtered;
  }, [products, selectedCategory, searchQuery]);

  const handleProductSelect = (product: Product) => {
    if (product.variants && product.variants.length > 1) {
      openVariantModal(product);
    } else if (product.variants && product.variants.length === 1) {
      addToCart(product, product.variants[0]);
    } else {
      console.warn('Product has no variants:', product.name);
    }
  };

  // Manejador para lector de código de barras (Enter automático al escanear o presionar Enter)
  const handleSearchKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && searchQuery.trim()) {
      e.preventDefault();
      const rawQuery = searchQuery.trim();
      const queryNorm = normalizeText(rawQuery);

      // 1. Buscar coincidencia exacta por código de barras o SKU
      let matchedProduct: Product | undefined;
      let matchedVariant: any = null;

      for (const p of products) {
        for (const v of p.variants || []) {
          const vBarcode = v.barcode ? normalizeText(v.barcode) : '';
          const vSku = v.sku ? normalizeText(v.sku) : '';
          if ((vBarcode && vBarcode === queryNorm) || (vSku && vSku === queryNorm)) {
            matchedProduct = p;
            matchedVariant = v;
            break;
          }
        }
        if (matchedProduct) break;
      }

      // 2. Si no hay SKU exacto pero el filtro devuelve exactamente 1 producto
      if (!matchedProduct && filteredProducts.length === 1) {
        matchedProduct = filteredProducts[0];
        if (matchedProduct.variants && matchedProduct.variants.length === 1) {
          matchedVariant = matchedProduct.variants[0];
        }
      }

      if (matchedProduct) {
        if (matchedVariant) {
          addToCart(matchedProduct, matchedVariant);
          setBarcodeFeedback(t('pos:agregado_name_name2', { name: matchedProduct.name, name2: matchedVariant.name }));
        } else {
          openVariantModal(matchedProduct);
          setBarcodeFeedback(t('pos:selecciona_variante_de_name', { name: matchedProduct.name }));
        }
        setSearchQuery('');
        setTimeout(() => setBarcodeFeedback(null), 3000);
      }
    }
  };

  const handleClearSearch = () => {
    setSearchQuery('');
    searchInputRef.current?.focus();
  };

  if (isLoadingProducts) {
    return (
      <div className="flex flex-col items-center justify-center h-64 gap-3">
        <div className="animate-spin rounded-full h-8 w-8 border-3 border-slate-200 border-t-blue-600"></div>
        <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">{t('pos:cargando_catalogo')}</p>
      </div>
    );
  }

  return (
    <div className="space-y-3.5 select-none">
      <SuggestionsBar />
      {/* 1. Barra de Búsqueda Normalizada + Lector de Código de Barras + Switcher de Vista */}
      <div className="flex items-center gap-2.5">
        <div className="relative flex-1" data-guide="product-search">
          <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400">
            <Search className="w-4 h-4" />
          </div>
          <input
            ref={searchInputRef}
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={handleSearchKeyDown}
            placeholder={t('pos:buscar_producto_codigo_de_barras_o_sku')}
            aria-label={t('pos:buscar_producto_por_nombre_codigo_de_barras')}
            className="w-full pl-10 pr-20 py-2.5 bg-white border border-slate-200 rounded-xl focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 focus:outline-none text-slate-900 placeholder-slate-400 text-xs sm:text-sm font-medium shadow-xs"
          />
          <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1.5">
            {searchQuery ? (
              <button
                onClick={handleClearSearch}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-md"
                title={t('pos:limpiar_busqueda')}
              >
                <X className="w-4 h-4" />
              </button>
            ) : (
              <span className="hidden sm:inline-flex items-center gap-1 px-1.5 py-0.5 text-xs font-mono font-bold text-slate-400 bg-slate-100 rounded border border-slate-200">
                <Barcode className="w-3 h-3 text-slate-400" />
                {t('pos:lector_activo')}
              </span>
            )}
          </div>
        </div>

        {/* Conmutador de Vista (Cuadrícula / Lista compacta) */}
        <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 shrink-0">
          <button
            type="button"
            onClick={() => setViewMode('grid')}
            title={t('pos:vista_cuadricula')}
            className={`p-1.5 rounded-lg transition-all ${
              viewMode === 'grid' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <LayoutGrid className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => setViewMode('compact')}
            title={t('pos:vista_lista_compacta')}
            className={`p-1.5 rounded-lg transition-all ${
              viewMode === 'compact' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <List className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Notificación de Producto Escaneado */}
      {barcodeFeedback && (
        <div className="px-3 py-1.5 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-xl text-xs font-bold flex items-center gap-2 animate-in fade-in duration-150">
          <Check className="w-4 h-4 text-emerald-600" />
          {barcodeFeedback}
        </div>
      )}

      {/* 2. Chips de Categorías con Contadores (Sin dropdown redundante) */}
      <div data-guide="product-categories" className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-hide">
        <button
          onClick={() => setSelectedCategory(null)}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all shrink-0 flex items-center gap-1.5 border ${
            selectedCategory === null
              ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
              : 'bg-white text-slate-700 hover:bg-slate-50 border-slate-200'
          }`}
        >
          <span>{t('pos:todas')}</span>
          <span className={`text-xs font-black px-1.5 py-0.2 rounded-md ${
            selectedCategory === null ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'
          }`}>
            {products.length}
          </span>
        </button>

        {categories.map((cat) => {
          const isSelected = selectedCategory === cat.id;
          const count = categoryCounts[cat.id] || 0;
          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all shrink-0 flex items-center gap-1.5 border ${
                isSelected
                  ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                  : 'bg-white text-slate-700 hover:bg-slate-50 border-slate-200'
              }`}
            >
              <span>{cat.name}</span>
              <span className={`text-xs font-black px-1.5 py-0.2 rounded-md ${
                isSelected ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'
              }`}>
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Indicador de Filtros Activos */}
      {(searchQuery || selectedCategory) && (
        <div className="flex items-center gap-2 flex-wrap text-xs">
          {searchQuery && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-blue-50 text-blue-700 border border-blue-200 rounded-lg font-semibold">
              {t('pos:busqueda_searchquery', { searchQuery })}
              <button onClick={handleClearSearch} className="hover:text-blue-900 p-0.5">
                <X className="w-3 h-3" />
              </button>
            </span>
          )}
          {selectedCategory && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-100 text-slate-700 border border-slate-200 rounded-lg font-semibold">
              {t('pos:categoria_value', { value: categories.find(c => c.id === selectedCategory)?.name || t('pos:seleccionada') })}
              <button onClick={() => setSelectedCategory(null)} className="hover:text-slate-900 p-0.5">
                <X className="w-3 h-3" />
              </button>
            </span>
          )}
          <span className="text-slate-400 font-medium ml-auto text-xs">
            {t('pos:productos_count', { count: filteredProducts.length })}
          </span>
        </div>
      )}

      {/* 3. Cuadrícula / Lista de Productos */}
      {viewMode === 'grid' ? (
        <div data-guide="product-grid" className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-3">
          {filteredProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onSelect={handleProductSelect}
              cartCount={cartCountsByProduct[product.id] || 0}
              viewMode="grid"
            />
          ))}
        </div>
      ) : (
        <div className="space-y-1.5">
          {filteredProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onSelect={handleProductSelect}
              cartCount={cartCountsByProduct[product.id] || 0}
              viewMode="compact"
            />
          ))}
        </div>
      )}

      {/* Estado Vacío */}
      {filteredProducts.length === 0 && (
        <div className="text-center py-16 text-slate-400 bg-white rounded-2xl border border-slate-200 space-y-1">
          <Tag className="w-10 h-10 mx-auto opacity-40 text-slate-400" />
          <p className="font-bold text-slate-700 text-sm">{t('pos:no_se_encontraron_productos')}</p>
          <p className="text-xs text-slate-400">{t('pos:intenta_con_otros_terminos_o_cambia_de')}</p>
        </div>
      )}
    </div>
  );
};

export default ProductGrid;
