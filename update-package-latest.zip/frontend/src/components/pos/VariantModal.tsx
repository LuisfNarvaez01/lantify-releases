// ============================================
// COMPONENTS - Variant Selection Modal
// ============================================

import React, { useState, useEffect } from 'react';
import { usePosStore } from '../../store/usePosStore';
import type { ProductVariant } from '../../types';
import { X, Plus, Minus, ShoppingCart } from 'lucide-react';
import { formatCurrency } from '../../shared/formatUtils';

import { t } from '../../i18n';
export const VariantModal: React.FC = () => {
  const { 
    isVariantModalOpen, 
    selectedProductForVariant, 
    closeVariantModal,
    addToCart 
  } = usePosStore();
  
  const [quantity, setQuantity] = useState(1);
  const [selectedVariant, setSelectedVariant] = useState<ProductVariant | null>(null);

  // Esc cierra el modal
  useEffect(() => {
    if (!isVariantModalOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setQuantity(1);
        setSelectedVariant(null);
        closeVariantModal();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [isVariantModalOpen, closeVariantModal]);

  if (!isVariantModalOpen || !selectedProductForVariant) return null;

  const variants = selectedProductForVariant.variants || [];

  const handleAddToCart = () => {
    if (selectedVariant) {
      addToCart(selectedProductForVariant, selectedVariant, quantity);
      closeModal();
    }
  };

  const closeModal = () => {
    setQuantity(1);
    setSelectedVariant(null);
    closeVariantModal();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center" role="dialog" aria-modal="true" aria-label={t('pos:elegir_variante_de_name', { name: selectedProductForVariant.name })}>
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={closeModal}
      />
      
      {/* Modal Content */}
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-blue-700 p-6 text-white">
          <div className="flex items-start justify-between">
            <div>
              <h2 className="text-xl font-bold">{selectedProductForVariant.name}</h2>
              {selectedProductForVariant.description && (
                <p className="text-blue-100 text-sm mt-1">{selectedProductForVariant.description}</p>
              )}
            </div>
            <button
              onClick={closeModal}
              className="p-2 hover:bg-white/20 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Variant Selection */}
        <div className="p-6">
          <h3 className="text-sm font-semibold text-gray-600 mb-3">
            {t('pos:selecciona_el_tamano')}
          </h3>
          <div className="space-y-2">
            {variants.map((variant) => (
              <button
                key={variant.id}
                onClick={() => setSelectedVariant(variant)}
                className={`
                  w-full flex items-center justify-between p-4 rounded-xl border-2 transition-all
                  ${selectedVariant?.id === variant.id 
                    ? 'border-blue-500 bg-blue-50' 
                    : 'border-gray-200 hover:border-gray-300'}
                `}
              >
                <div className="flex items-center gap-3">
                  <div className={`
                    w-5 h-5 rounded-full border-2 flex items-center justify-center
                    ${selectedVariant?.id === variant.id ? 'border-blue-500' : 'border-gray-300'}
                  `}>
                    {selectedVariant?.id === variant.id && (
                      <div className="w-2.5 h-2.5 bg-blue-500 rounded-full" />
                    )}
                  </div>
                  <div className="text-left">
                    <div className="font-semibold text-gray-800">{variant.name}</div>
                    <div className="text-xs text-gray-500">{t('pos:sku')}{' '}{variant.sku}</div>
                  </div>
                </div>
                <div className="text-lg font-bold text-green-600">
                  {formatCurrency(variant.price)}
                </div>
              </button>
            ))}
          </div>

          {/* Quantity Selector */}
          {selectedVariant && (
            <div className="mt-6">
              <h3 className="text-sm font-semibold text-gray-600 mb-3">
                {t('pos:cantidad')}
              </h3>
              <div className="flex items-center justify-center gap-4">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-12 h-12 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition-colors"
                >
                  <Minus className="w-5 h-5" />
                </button>
                <span className="text-3xl font-bold w-16 text-center">{quantity}</span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-12 h-12 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition-colors"
                >
                  <Plus className="w-5 h-5" />
                </button>
              </div>
            </div>
          )}

          {/* Total */}
          {selectedVariant && (
            <div className="mt-6 p-4 bg-gray-50 rounded-xl">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">{t('pos:total')}</span>
                <span className="text-2xl font-bold text-green-600">
                  {formatCurrency(selectedVariant.price * quantity)}
                </span>
              </div>
            </div>
          )}

          {/* Add to Cart Button */}
          <button
            onClick={handleAddToCart}
            disabled={!selectedVariant}
            className={`
              w-full mt-6 py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-2 transition-all
              ${selectedVariant 
                ? 'bg-blue-600 text-white hover:bg-blue-700 shadow-lg shadow-blue-500/30' 
                : 'bg-gray-200 text-gray-400 cursor-not-allowed'}
            `}
          >
            <ShoppingCart className="w-5 h-5" />
            {t('pos:agregar_al_carrito')}
          </button>
        </div>
      </div>
    </div>
  );
};

export default VariantModal;