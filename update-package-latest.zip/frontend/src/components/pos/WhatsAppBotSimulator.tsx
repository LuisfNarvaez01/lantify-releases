// ============================================
// COMPONENTS - WhatsApp Bot Simulator & Live Order Stream
// Authentic smartphone mockup for testing WhatsApp chatbot orders & automated payments
// ============================================

import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, 
  MessageCircle, 
  Phone, 
  Video, 
  MoreVertical, 
  CheckCheck, 
  Paperclip, 
  Smile, 
  RefreshCw,
  Sparkles,
  CheckCircle2
} from 'lucide-react';
import { formatCurrency } from '../../shared/formatUtils';
import { demoOrder, DemoOrder } from '../delivery/demoOrder';
import type { Product } from '../../types';
import { toast } from '../../shared/toast';

import { t } from '../../i18n';
interface WhatsAppBotSimulatorProps {
  products: Product[];
  /** Pedido de ejemplo (solo en pantalla: no crea ventas ni toca la caja) */
  onOrderCreated?: (order: DemoOrder) => void;
}

interface ChatMessage {
  id: string;
  sender: 'bot' | 'user';
  text: string;
  time: string;
  options?: Array<{ label: string; action: () => void }>;
  isReceipt?: boolean;
}

export const WhatsAppBotSimulator: React.FC<WhatsAppBotSimulatorProps> = ({
  products,
  onOrderCreated
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [selectedItems, setSelectedItems] = useState<any[]>([]);
  const [_step, setStep] = useState<'GREETING' | 'MENU' | 'DETAILS' | 'PAYMENT' | 'COMPLETED'>('GREETING');
  const [customerName, setCustomerName] = useState(t('delivery:mateo_buendia'));
  const [customerPhone, setCustomerPhone] = useState('312 456 7890');
  const [customerAddress, setCustomerAddress] = useState(t('delivery:carrera_7_85_12_apto_301'));
  const [deliveryNotes, setDeliveryNotes] = useState(t('delivery:edificio_parque_85_timbrar_en_el_301'));
  const chatEndRef = useRef<HTMLDivElement>(null);

  const getCurrentTime = () => {
    return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  // Initialize bot greeting
  const resetChat = () => {
    setSelectedItems([]);
    setStep('GREETING');
    setMessages([
      {
        id: '1',
        sender: 'bot',
        text: '👋 ¡Hola! Bienvenido al canal oficial de pedidos de *Lantify Café & Bistró* 🌿☕.\n\nSoy tu asistente virtual inteligente conectado en tiempo real con nuestra cocina. ¿Qué se te antoja hoy?',
        time: getCurrentTime(),
        options: [
          { label: t('delivery:ver_menu_y_especialidades'), action: () => showMenuOptions() },
          { label: t('delivery:pedir_hamburguesa_lantify_28_000'), action: () => quickAddFeatured(t('delivery:hamburguesa')) },
          { label: t('delivery:pedir_cafe_geisha_huila_9_500'), action: () => quickAddFeatured(t('delivery:cafe_geisha')) }
        ]
      }
    ]);
  };

  useEffect(() => {
    resetChat();
  }, []);

  const addBotMessage = (text: string, options?: any[], isReceipt?: boolean) => {
    setIsTyping(true);
    setTimeout(() => {
      setIsTyping(false);
      setMessages(prev => [
        ...prev,
        {
          id: String(Date.now()),
          sender: 'bot',
          text,
          time: getCurrentTime(),
          options,
          isReceipt
        }
      ]);
    }, 700);
  };

  const addUserMessage = (text: string) => {
    setMessages(prev => [
      ...prev,
      {
        id: String(Date.now()),
        sender: 'user',
        text,
        time: getCurrentTime()
      }
    ]);
  };

  const showMenuOptions = () => {
    addUserMessage(t('delivery:por_favor_muestrame_el_menu'));
    setStep('MENU');

    const availableVariants: any[] = [];
    products.forEach(p => {
      p.variants.forEach(v => {
        availableVariants.push({
          productName: p.name,
          variantName: v.name,
          variantId: v.id,
          price: v.price
        });
      });
    });

    const menuText = t('delivery:nuestra_carta_de_hoy') + 
      products.slice(0, 4).map((p, i) => {
        const v = p.variants[0];
        return `${i + 1}. *${p.name}* - ${formatCurrency(v?.price || 0)}\n_${p.description || ''}_`;
      }).join('\n\n') + `\n\n_Toca una opción para añadirla a tu pedido:_`;

    const options = products.slice(0, 3).map(p => {
      const v = p.variants[0];
      return {
        label: `➕ ${p.name} (${formatCurrency(v?.price || 0)})`,
        action: () => addItemToCart(p.name, v.name, v.id, v.price)
      };
    });

    addBotMessage(menuText, options);
  };

  const quickAddFeatured = (keyword: string) => {
    const product = products.find(p => p.name.toLowerCase().includes(keyword.toLowerCase())) || products[0];
    if (product && product.variants[0]) {
      const v = product.variants[0];
      addUserMessage(t('delivery:quiero_ordenar_name', { name: product.name }));
      addItemToCart(product.name, v.name, v.id, v.price);
    } else {
      showMenuOptions();
    }
  };

  const addItemToCart = (productName: string, variantName: string, variantId: string, price: number) => {
    const newItems = [...selectedItems, { productName, variantName, variantId, price, quantity: 1 }];
    setSelectedItems(newItems);
    setStep('DETAILS');

    const subtotal = newItems.reduce((acc, it) => acc + it.price * it.quantity, 0);
    const tax = Math.round(subtotal * 0.08);
    const total = subtotal + tax;

    const summaryText = t('delivery:tu_pedido_actual') + 
      newItems.map(it => `• 1x *${it.productName}* (${it.variantName}) - ${formatCurrency(it.price)}`).join('\n') +
      t('delivery:subtotal_amount_impoconsumo_8_amount2_total_amount', { amount: formatCurrency(subtotal), amount2: formatCurrency(tax), amount3: formatCurrency(total), customerAddress });

    addBotMessage(summaryText, [
      { label: t('delivery:confirmar_pedido_y_pagar_con_nequi'), action: () => proceedToPayment('NEQUI') },
      { label: t('delivery:pagar_con_daviplata'), action: () => proceedToPayment('DAVIPLATA') },
      { label: t('delivery:pagar_en_efectivo_contraentrega'), action: () => proceedToPayment('CASH') }
    ]);
  };

  const proceedToPayment = async (method: 'NEQUI' | 'DAVIPLATA' | 'CASH') => {
    addUserMessage(t('delivery:confirmo_mi_pedido_deseo_pagar_con_method', { method }));
    setStep('PAYMENT');

    if (method === 'NEQUI' || method === 'DAVIPLATA') {
      const paymentMsg = `📲 *DATOS PARA TRANSFERENCIA (${method}):*\n\n` +
        t('delivery:llave_de_pago_312_456_7890') +
        t('delivery:titular_lantify_pos_s_a_s') +
        t('delivery:monto_exacto_amount', { amount: formatCurrency(selectedItems.reduce((acc, it) => acc + it.price * it.quantity, 0) * 1.08) }) +
        `_Simula el envío del comprobante de transferencia con el siguiente botón:_`;

      addBotMessage(paymentMsg, [
        { label: t('delivery:simular_envio_de_comprobante_method', { method }), action: () => completeOrderWithPayment(method) }
      ]);
    } else {
      completeOrderWithPayment('CASH');
    }
  };

  const completeOrderWithPayment = async (paymentMethod: string) => {
    addUserMessage(t('delivery:comprobante_transferencia_paymentmethod_png_adjunt', { paymentMethod }));
    setIsTyping(true);

    try {
      await new Promise((resolve) => setTimeout(resolve, 900));
      const order = demoOrder('WHATSAPP', [], {
        customerName,
        customerPhone,
        customerAddress,
        deliveryNotes,
        paymentMethod,
        items: selectedItems.map((it) => ({ productName: `${it.productName}${it.variantName ? ` (${it.variantName})` : ''}`, price: it.price, quantity: it.quantity })),
      });
      const res = { order };

      setIsTyping(false);
      setStep('COMPLETED');

      if (res && res.order) {
        onOrderCreated?.(res.order);

        const confirmationMsg = t('delivery:pago_verificado_y_orden_confirmada') +
          t('delivery:pedido_salenumber', { saleNumber: res.order.saleNumber }) +
          t('delivery:estado_recibido_en_cocina_kds') +
          t('delivery:direccion_customeraddress', { customerAddress }) +
          t('delivery:tiempo_estimado_25_a_35_min') +
          t('delivery:demo_confirmacion');

        addBotMessage(confirmationMsg, [
          { label: t('delivery:iniciar_nueva_conversacion'), action: resetChat }
        ]);
        toast.success(t('delivery:pedido_procesado_e_ingresado_al_sistema'));
      }
    } catch (err: any) {
      setIsTyping(false);
      toast.error(err.message || 'Error al procesar pedido por WhatsApp');
    }
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const userText = inputText.trim();
    setInputText('');
    addUserMessage(userText);

    // Simple keyword processing for demo
    const lower = userText.toLowerCase();
    if (lower.includes('hola') || lower.includes('buenas') || lower.includes('menu') || lower.includes('carta')) {
      showMenuOptions();
    } else if (lower.includes('hamburguesa')) {
      quickAddFeatured(t('delivery:hamburguesa'));
    } else if (lower.includes('cafe') || lower.includes('café')) {
      quickAddFeatured(t('delivery:cafe'));
    } else {
      addBotMessage(
        t('delivery:he_recibido_tu_mensaje_usertext_puedes_elegir', { userText }),
        [
          { label: t('delivery:ver_menu_completo'), action: showMenuOptions }
        ]
      );
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Left Column: WhatsApp Smartphone Mockup */}
      <div className="lg:col-span-7 flex justify-center">
        <div className="w-full max-w-[400px] h-[680px] bg-black rounded-[45px] p-3 shadow-2xl ring-1 ring-black/20 flex flex-col relative overflow-hidden">
          {/* Phone Speaker & Camera Notch */}
          <div className="absolute top-4 left-1/2 -translate-x-1/2 w-28 h-4 bg-black rounded-full z-30 flex items-center justify-center">
            <div className="w-3 h-3 bg-gray-900 rounded-full"></div>
          </div>

          {/* Screen Container */}
          <div className="flex-1 bg-[#efeae2] rounded-[36px] overflow-hidden flex flex-col relative">
            {/* WhatsApp Header */}
            <div className="bg-[#075e54] text-white pt-6 pb-3 px-4 flex items-center justify-between shadow-md z-20">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <div className="w-10 h-10 rounded-full bg-slate-900 border-2 border-white/40 flex items-center justify-center overflow-hidden p-1.5">
                    <img src="/logo-lantify-white.svg" alt={t('delivery:lantify_bot')} className="w-full h-full object-contain" />
                  </div>
                  <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-400 border-2 border-[#075e54] rounded-full"></span>
                </div>
                <div>
                  <h4 className="font-bold text-sm leading-tight flex items-center gap-1">
                    {t('delivery:lantify_bot_asistente')}
                    <Sparkles className="w-3 h-3 text-amber-300" />
                  </h4>
                  <span className="text-xs text-emerald-200">{t('delivery:en_linea_ia_conectada_al_pos')}</span>
                </div>
              </div>

              <div className="flex items-center gap-3 text-white/90">
                <Phone className="w-4 h-4 cursor-pointer hover:text-white" />
                <Video className="w-4 h-4 cursor-pointer hover:text-white" />
                <MoreVertical className="w-4 h-4 cursor-pointer hover:text-white" />
              </div>
            </div>

            {/* Chat Body (Messages) */}
            <div 
              className="flex-1 p-3 overflow-y-auto space-y-3 text-xs"
              style={{
                backgroundImage: `radial-gradient(#075e54 0.5px, transparent 0.5px)`,
                backgroundSize: '16px 16px',
                backgroundColor: '#efeae2'
              }}
            >
              {/* Date stamp */}
              <div className="flex justify-center">
                <span className="bg-white/80 text-gray-500 text-xs font-semibold px-2.5 py-1 rounded-lg shadow-sm">
                  HOY
                </span>
              </div>

              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'} space-y-1.5`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl p-3 shadow-sm text-xs leading-relaxed ${
                      msg.sender === 'user'
                        ? 'bg-[#d9fdd3] text-gray-900 rounded-tr-none'
                        : 'bg-white text-gray-900 rounded-tl-none'
                    }`}
                  >
                    <p className="whitespace-pre-line">{msg.text}</p>
                    <div className="flex items-center justify-end gap-1 mt-1 text-xs text-gray-400">
                      <span>{msg.time}</span>
                      {msg.sender === 'user' && <CheckCheck className="w-3.5 h-3.5 text-blue-500" />}
                    </div>
                  </div>

                  {/* Interactive Options / Buttons */}
                  {msg.options && msg.options.length > 0 && (
                    <div className="flex flex-col gap-1.5 w-[85%]">
                      {msg.options.map((opt, idx) => (
                        <button
                          key={idx}
                          onClick={opt.action}
                          className="w-full text-left py-2 px-3 bg-white hover:bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-xl font-bold text-xs shadow-sm active:scale-95 transition-all flex items-center justify-between"
                        >
                          <span>{opt.label}</span>
                          <span className="text-xs text-emerald-600">➔</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ))}

              {isTyping && (
                <div className="flex items-center gap-1.5 bg-white py-2 px-3 rounded-2xl rounded-tl-none w-20 shadow-sm">
                  <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse"></div>
                  <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse [animation-delay:0.2s]"></div>
                  <div className="w-2 h-2 bg-slate-400 rounded-full animate-pulse [animation-delay:0.4s]"></div>
                </div>
              )}

              <div ref={chatEndRef} />
            </div>

            {/* Input Bar */}
            <form onSubmit={handleSendMessage} className="bg-[#f0f2f5] p-2 flex items-center gap-2 border-t border-gray-200">
              <Smile className="w-5 h-5 text-gray-500 cursor-pointer" />
              <Paperclip className="w-5 h-5 text-gray-500 cursor-pointer" />
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder={t('delivery:escribe_un_mensaje')}
                className="flex-1 bg-white text-xs py-2 px-3 rounded-full border-none focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
              <button
                type="submit"
                className="w-8 h-8 rounded-full bg-[#00a884] text-white flex items-center justify-center hover:bg-[#069475] transition-colors"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* Right Column: Customer Details Configuration & System Flow Explain */}
      <div className="lg:col-span-5 space-y-6">
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-emerald-100 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-emerald-700">
              <MessageCircle className="w-6 h-6" />
              <h3 className="font-black text-lg text-gray-900">{t('delivery:configuracion_del_cliente_simulado')}</h3>
            </div>
            <button
              onClick={resetChat}
              className="p-2 hover:bg-gray-100 text-gray-500 rounded-xl transition-colors"
              title={t('delivery:reiniciar_chat')}
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>

          <p className="text-xs text-gray-500">
            {t('delivery:estos_datos_son_los_que_el_bot')}
          </p>

          <div className="space-y-3 text-xs">
            <div>
              <label className="font-bold text-gray-700 block mb-1">{t('delivery:nombre_completo')}</label>
              <input
                type="text"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="w-full px-3 py-2 border border-gray-200 rounded-xl font-medium focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label className="font-bold text-gray-700 block mb-1">{t('delivery:telefono_whatsapp')}</label>
              <input
                type="text"
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
                className="w-full px-3 py-2 border border-gray-200 rounded-xl font-medium focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label className="font-bold text-gray-700 block mb-1">{t('delivery:direccion_de_entrega')}</label>
              <input
                type="text"
                value={customerAddress}
                onChange={(e) => setCustomerAddress(e.target.value)}
                className="w-full px-3 py-2 border border-gray-200 rounded-xl font-medium focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label className="font-bold text-gray-700 block mb-1">{t('delivery:notas_de_entrega_timbre')}</label>
              <input
                type="text"
                value={deliveryNotes}
                onChange={(e) => setDeliveryNotes(e.target.value)}
                className="w-full px-3 py-2 border border-gray-200 rounded-xl font-medium focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>
        </div>

        {/* How it works info card */}
        <div className="bg-gradient-to-br from-emerald-50 to-teal-50 rounded-3xl p-6 border border-emerald-100 space-y-3">
          <h4 className="font-black text-sm text-emerald-900 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            {t('delivery:flujo_automatico_whatsapp_pos')}
          </h4>
          <ol className="text-xs text-emerald-950 space-y-2 list-decimal list-inside font-medium leading-relaxed">
            <li>{t('delivery:el_cliente_escribe_a_la_linea_de')}</li>
            <li>{t('delivery:el_bot_inteligente_despliega_la_carta_precios')}</li>
            <li>{t('delivery:el_cliente_selecciona_productos_y_confirma_direcci')}</li>
            <li>{t('delivery:se_recibe_el_pago_digital_por')}{' '}<b>{t('delivery:nequi_o_daviplata')}</b>{' '}{t('delivery:y_se_valida_el_comprobante')}</li>
            <li>{t('delivery:el_pedido_se_crea_en_el_pos')}{' '}<b>{t('delivery:whatsapp')}</b>{t('delivery:disparando_la_notificacion_flotante_con_la_tarjeta')}</li>
          </ol>
        </div>
      </div>
    </div>
  );
};
