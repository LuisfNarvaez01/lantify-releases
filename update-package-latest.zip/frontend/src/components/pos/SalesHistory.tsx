// ============================================
// COMPONENTS - Sales History Panel
// ============================================

import { PaymentFixModal } from '../v3/OpsModals';
import { useCan as useCanV3 } from '../../shared/permissions';
import { Repeat } from 'lucide-react';
import { TipsCenter } from './TipsCenter';
import { useState, useEffect, useMemo } from 'react';
import { confirmDialog, promptDialog, reasonDialog } from '../../shared/dialog';
import {
  History, Calendar, Clock, AlertCircle,
  ChevronDown, ShoppingBag, Banknote, CreditCard, Smartphone,
  RefreshCw, Filter, CheckCircle2, XCircle, Hourglass, RotateCcw,
  Receipt, Tag, Trash2, Printer, CalendarDays,
  User, MapPin, Phone, MessageCircle, Zap, FileText, HeartHandshake, Pencil
} from 'lucide-react';
import { formatCurrency } from '../../shared/formatUtils';
import { salesAPI } from '../../services/api';
import { printService } from '../../services/printService';
import { sendTicketByWhatsApp } from '../../services/whatsappTicket';
import { buildSalesReport, fetchAllSales } from '../../services/salesReport';
import { ReportButton } from '../common/ReportButton';
import { SalesQuickStats } from './SalesQuickStats';
import { ElectronicInvoiceModal } from './ElectronicInvoiceModal';
import { ChangeCustomerDialog } from './ChangeCustomerDialog';
import { useFeature, showPlanLock } from '../../shared/plan';
import { toast } from '../../shared/toast';
import { groupSaleTaxes } from '../../shared/business';

import { API_URL } from '../../config';

import { t, getLocale } from '../../i18n';
const getToken = () => localStorage.getItem('token');
const isAdminUser = () => {
  try {
    return JSON.parse(localStorage.getItem('user') || '{}')?.role === 'ADMIN';
  } catch {
    return false;
  }
};

/* ── helpers ───────────────────────────────────────────── */

const STATUS_CONFIG: Record<string, { label: string; color: string; bg: string; icon: React.ReactNode }> = {


  COMPLETED: {
    get label() { return t('sales:completada'); },
    color: 'text-emerald-700',
    bg: 'bg-emerald-50 border-emerald-200',
    icon: <CheckCircle2 className="w-3.5 h-3.5" />,
  },
  PENDING: {
    get label() { return t('sales:pendiente'); },
    color: 'text-amber-700',
    bg: 'bg-amber-50 border-amber-200',
    icon: <Hourglass className="w-3.5 h-3.5" />,
  },
  CANCELLED: {
    get label() { return t('sales:cancelada'); },
    color: 'text-red-700',
    bg: 'bg-red-50 border-red-200',
    icon: <XCircle className="w-3.5 h-3.5" />,
  },
  REFUNDED: {
    get label() { return t('sales:reembolsada'); },
    color: 'text-purple-700',
    bg: 'bg-purple-50 border-purple-200',
    icon: <RotateCcw className="w-3.5 h-3.5" />,
  },
};

const PAYMENT_CONFIG: Record<string, { label: string; color: string; bg: string; icon: React.ReactNode }> = {
  CASH: {
    get label() { return t('sales:efectivo'); },
    color: 'text-emerald-700',
    bg: 'bg-emerald-50',
    icon: <Banknote className="w-4 h-4" />,
  },
  CARD: {
    get label() { return t('sales:tarjeta'); },
    color: 'text-blue-700',
    bg: 'bg-blue-50',
    icon: <CreditCard className="w-4 h-4" />,
  },
  TRANSFER: {
    get label() { return t('sales:transferencia'); },
    color: 'text-violet-700',
    bg: 'bg-violet-50',
    icon: <Smartphone className="w-4 h-4" />,
  },
  RAPPI_PAY: {
    get label() { return t('sales:rappipay'); },
    color: 'text-orange-700',
    bg: 'bg-orange-50',
    icon: <Zap className="w-4 h-4 text-orange-600" />,
  },
  NEQUI: {
    label: 'Nequi',
    color: 'text-fuchsia-700',
    bg: 'bg-fuchsia-50',
    icon: <Smartphone className="w-4 h-4 text-fuchsia-600" />,
  },
  DAVIPLATA: {
    label: 'Daviplata',
    color: 'text-rose-700',
    bg: 'bg-rose-50',
    icon: <Smartphone className="w-4 h-4 text-rose-600" />,
  },
};

const CHANNEL_CONFIG: Record<string, { label: string; color: string; bg: string; icon: React.ReactNode }> = {
  RAPPI: {
    label: 'Rappi',
    color: 'text-orange-800',
    bg: 'bg-orange-100 border-orange-200',
    icon: <Zap className="w-3.5 h-3.5 text-orange-600" />,
  },
  WHATSAPP: {
    get label() { return t('sales:whatsapp_bot_2'); },
    color: 'text-emerald-800',
    bg: 'bg-emerald-100 border-emerald-200',
    icon: <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />,
  },
  WEB: {
    get label() { return t('sales:tienda_web_2'); },
    color: 'text-sky-800',
    bg: 'bg-sky-100 border-sky-200',
    icon: <ShoppingBag className="w-3.5 h-3.5 text-sky-600" />,
  },
  KIOSK: {
    get label() { return t('sales:kiosco'); },
    color: 'text-slate-900',
    bg: 'bg-slate-100 border-slate-200',
    icon: <ShoppingBag className="w-3.5 h-3.5 text-slate-600" />,
  },
  COUNTER: {
    get label() { return t('sales:mostrador'); },
    color: 'text-indigo-900',
    bg: 'bg-indigo-100 border-indigo-200',
    icon: <ShoppingBag className="w-3.5 h-3.5 text-indigo-600" />,
  },
  POS: {
    get label() { return t('sales:salon_mesas_2'); },
    color: 'text-amber-900',
    bg: 'bg-amber-100/70 border-amber-200',
    icon: <Tag className="w-3.5 h-3.5 text-amber-700" />,
  },
};

const ChannelBadge = ({ channel }: { channel?: string }) => {
  const cfg = CHANNEL_CONFIG[channel || 'POS'] ?? CHANNEL_CONFIG.POS;
  return (
    <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full border text-xs font-black uppercase tracking-wider ${cfg.color} ${cfg.bg}`}>
      {cfg.icon}
      {cfg.label}
    </span>
  );
};

/* ── sub-components ────────────────────────────────────── */

const StatusBadge = ({ status }: { status: string }) => {
  const cfg = STATUS_CONFIG[status] ?? {
    label: status,
    color: 'text-gray-700',
    bg: 'bg-gray-50 border-gray-200',
    icon: null,
  };
  return (
    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full border text-xs font-semibold ${cfg.color} ${cfg.bg}`}>
      {cfg.icon}
      {cfg.label}
    </span>
  );
};

const PaymentBadge = ({ method }: { method: string }) => {
  const cfg = PAYMENT_CONFIG[method] ?? { label: method, color: 'text-gray-600', bg: 'bg-gray-50', icon: null };
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold ${cfg.color} ${cfg.bg}`}>
      {cfg.icon}
      {cfg.label}
    </span>
  );
};

/* ── SaleCard ───────────────────────────────────────────── */

const SaleCard = ({ sale, onUpdate, config }: { sale: any; onUpdate: () => void; config: any }) => {
  const [expanded, setExpanded] = useState(false);
  const [isCancelling, setIsCancelling] = useState(false);
  const [showInvoiceModal, setShowInvoiceModal] = useState(false);
  const [showCustomer, setShowCustomer] = useState(false);
  const hasCustomers = useFeature('customers');
  
  const items: any[] = sale.items ?? [];
  const itemCount = items.reduce((n: number, i: any) => n + (i.quantity ?? 1), 0);

  const productSummary = items
    .slice(0, 3)
    .map((i: any) => i.productVariant?.product?.name || i.productName || t('sales:producto'))
    .join(', ') + (items.length > 3 ? '...' : '');

  // Copia fiel del recibo: número, fecha, pagos, descuento e impuestos de la venta
  const receiptCopy = () => ({
    kind: 'receipt' as const,
    copy: true,
    saleNumber: sale.receiptCode || sale.saleNumber,
    date: sale.createdAt,
    cashierName: sale.cashierName || null,
    tableNumber: sale.table?.number || null,
    items: items.filter((i) => !i.isCancelled).map((i) => ({
      ...i,
      productName: i.productVariant?.product?.name || i.productName || t('sales:producto'),
      variantName: i.productVariant?.name || i.variantName || '',
    })),
    subtotal: sale.subtotal ?? sale.total,
    total: sale.total,
    discountPct: sale.discountPct || 0,
    discountAmount: sale.discount || 0,
    taxLines: groupSaleTaxes(items),
    customer: sale.customer && !sale.customer.isDefault ? sale.customer : null,
    payments: (sale.payments || []).map((p: any) => ({ method: p.paymentMethod, amount: p.amount })),
    paymentMethod: sale.paymentMethod,
  });

  const canFixPayment = useCanV3()('payment_fix');
  const [showPaymentFix, setShowPaymentFix] = useState(false);

  const handleReprint = (e: React.MouseEvent) => {
    e.stopPropagation();
    printService.printReceipt(receiptCopy()).catch(() => toast.error(t('printing:no_se_pudo_recibo')));
  };

  /** El recibo como imagen al WhatsApp del cliente */
  const handleShareWhatsApp = async (e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await sendTicketByWhatsApp({
        data: receiptCopy(),
        phone: sale.customerPhone || sale.customer?.phone,
        message: t('pos:wa_mensaje_recibo', { business: config?.businessName || 'Lantify POS', saleNumber: sale.receiptCode || sale.saleNumber, total: formatCurrency(sale.total) }),
        fileName: `recibo-${sale.receiptCode || sale.saleNumber}.png`,
      });
    } catch {
      toast.error(t('pos:wa_error'));
    }
  };

  // Propina: aparte del valor de la venta; el ADMIN la puede corregir (queda quién y por qué)
  const tip = Number(sale.tip) || 0;
  const canEditTip = isAdminUser() && sale.status === 'COMPLETED';
  const handleEditTip = async (e: React.MouseEvent) => {
    e.stopPropagation();
    const value = await promptDialog({
      title: t('sales:corregir_propina'),
      message: t('sales:corregir_propina_desc', { total: formatCurrency(sale.total) }),
      label: t('sales:nueva_propina'),
      defaultValue: String(tip),
      inputMode: 'numeric',
      confirmLabel: t('sales:continuar'),
    });
    if (value === null) return;
    const amount = Math.round(Number(value.replace(/[^\d]/g, '')) || 0);
    if (amount === tip) return;
    const reason = await reasonDialog({
      title: t('sales:motivo_correccion_propina', { from: formatCurrency(tip), to: formatCurrency(amount) }),
      placeholder: t('sales:motivo_propina_ej'),
      confirmLabel: t('sales:guardar_propina'),
    });
    if (!reason) return;
    try {
      await salesAPI.adjustTip(sale.id, amount, reason);
      toast.success(t('sales:propina_corregida', { amount: formatCurrency(amount) }));
      onUpdate();
    } catch (err: any) {
      toast.error(err.message || t('sales:error_propina'));
    }
  };

  const handleCancelSale = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!(await confirmDialog({ title: t('sales:anular_esta_venta'), message: t('sales:la_venta_quedara_cancelada_y_el_inventario'), confirmLabel: t('sales:anular_venta'), tone: 'danger' }))) return;

    setIsCancelling(true);
    try {
      await salesAPI.cancel(sale.id);
      toast.success(t('sales:venta_anulada_correctamente'));
      onUpdate();
    } catch (err: any) {
      toast.error('Error al anular venta: ' + (err.message || 'Error desconocido'));
    } finally {
      setIsCancelling(false);
    }
  };

  return (
    <div
      className={`bg-white rounded-3xl border-2 transition-all duration-300 overflow-hidden ${
        expanded ? 'border-blue-500 shadow-lg shadow-blue-500/5' : 'border-slate-200 shadow-sm hover:border-slate-300 hover:shadow-md'
      }`}
    >
      {/* ── Card Header ── */}
      <div
        onClick={() => setExpanded(!expanded)}
        className="w-full text-left p-4 sm:p-5 flex items-start gap-4 cursor-pointer relative"
      >
        {/* Number icon */}
        <div
          className={`w-14 h-14 rounded-2xl flex flex-col items-center justify-center flex-shrink-0 transition-all ${
            expanded ? 'bg-slate-900 text-blue-400 shadow-md shadow-slate-900/10' : 'bg-slate-100 text-slate-700'
          }`}
        >
          <Receipt className={`w-7 h-7 ${expanded ? 'text-blue-400' : 'text-slate-400'}`} />
        </div>

        {/* Info */}
        <div className="flex-1 min-w-0 pr-8 sm:pr-0">
          <div className="flex flex-wrap items-center gap-2 mb-2">
            <span className="font-black text-lg text-gray-800 tracking-tight">{t('sales:venta')}{sale.receiptCode || sale.saleNumber}</span>
            <ChannelBadge channel={sale.channel} />
            <StatusBadge status={sale.status} />
            {sale.tableId ? (
              <span className="bg-blue-100 text-blue-700 text-xs px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">
                {t('sales:mesa_value', { value: sale.table?.number || '' })}
              </span>
            ) : (
              <span className="bg-indigo-100 text-indigo-700 text-xs px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">
                {t('sales:mostrador')}
              </span>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-4 text-xs font-medium text-gray-500 mb-2">
            <span className="flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-blue-600" />
              {new Date(sale.createdAt).toLocaleDateString(getLocale(), { day: '2-digit', month: 'short', year: 'numeric' })}
            </span>
            <span className="flex items-center gap-1.5 border-l border-gray-200 pl-4">
              <Clock className="w-3.5 h-3.5 text-blue-600" />
              {new Date(sale.createdAt).toLocaleTimeString(getLocale(), { hour: '2-digit', minute: '2-digit' })}
            </span>
            <div className="hidden sm:block border-l border-gray-200 pl-4">
              <PaymentBadge method={sale.paymentMethod} />
            </div>
          </div>

          {/* Product Summary */}
          {!expanded && (
            <div className="flex items-center gap-2 text-xs bg-slate-50 rounded-xl px-3 py-1.5 w-fit border border-slate-200">
              <ShoppingBag className="w-3.5 h-3.5 text-blue-600" />
              <span className="text-slate-600 truncate max-w-[200px] sm:max-w-md">
                <span className="font-bold text-slate-900">{itemCount} items:</span> {productSummary}
              </span>
            </div>
          )}
        </div>

        {/* Total & chevron */}
        <div className="flex flex-col items-end gap-2 flex-shrink-0 pt-1">
          <div className="text-right">
            <p className="text-xs font-bold text-slate-500 uppercase tracking-widest leading-none mb-1">{t('sales:total')}</p>
            <p className="text-2xl font-black text-emerald-600 tracking-tighter tabular-nums">{formatCurrency(sale.total)}</p>
            {tip > 0 && (
              <p className="mt-1 inline-flex items-center gap-1 text-xs font-bold text-teal-700 tabular-nums" title={t('sales:propina_no_suma')}>
                <HeartHandshake className="w-3.5 h-3.5" aria-hidden />
                {t('sales:mas_propina', { amount: formatCurrency(tip) })}
              </p>
            )}
          </div>
          <span className={`p-2 rounded-xl transition-all duration-200 ${expanded ? 'rotate-180 bg-blue-50 text-blue-600' : 'bg-slate-100 text-slate-500 hover:text-slate-800'}`}>
            <ChevronDown className="w-4 h-4" />
          </span>
        </div>
      </div>

      {/* ── Expandable Detail ── */}
      {expanded && (
        <div className="border-t border-slate-100 bg-slate-50/50 px-5 pb-6 pt-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-blue-50 rounded-lg">
                <Receipt className="w-4 h-4 text-blue-600" />
              </div>
              <span className="text-sm font-black text-slate-800 uppercase tracking-wide">{t('sales:detalle_de_la_orden')}</span>
            </div>
            
            {sale.status !== 'CANCELLED' && (
              <div className="flex flex-wrap items-center gap-2">
                {canFixPayment && sale.status === 'COMPLETED' && (
                  <button onClick={(e) => { e.stopPropagation(); setShowPaymentFix(true); }} className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 text-slate-700 hover:bg-slate-800 hover:text-white rounded-xl text-xs font-bold transition-all border border-slate-200">
                    <Repeat className="w-3.5 h-3.5" />
                    {t('v3:corregir_pago')}
                  </button>
                )}
                {showPaymentFix && <PaymentFixModal sale={sale} onClose={() => setShowPaymentFix(false)} onSaved={onUpdate} />}
                <button
                  onClick={handleReprint}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 text-slate-700 hover:bg-slate-800 hover:text-white rounded-xl text-xs font-bold transition-all border border-slate-200 hover:shadow-sm"
                >
                  <Printer className="w-3.5 h-3.5" />
                  {t('sales:re_imprimir')}
                </button>
                <button
                  onClick={handleShareWhatsApp}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 text-emerald-700 hover:bg-emerald-600 hover:text-white rounded-xl text-xs font-bold transition-all border border-emerald-200 hover:shadow-sm"
                  title={t('sales:enviar_comprobante_detallado_por_whatsapp')}
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  WhatsApp
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowInvoiceModal(true);
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 text-blue-700 hover:bg-blue-600 hover:text-white rounded-xl text-xs font-bold transition-all border border-blue-200 hover:shadow-lg hover:shadow-blue-200 shadow-sm"
                  title={t('sales:emitir_o_consultar_factura_electronica_dian')}
                >
                  <FileText className="w-3.5 h-3.5 text-blue-600 group-hover:text-white" />
                  <span>{t('sales:factura_electronica')}</span>
                </button>
                <button
                  onClick={handleCancelSale}
                  disabled={isCancelling}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-red-50 text-red-600 hover:bg-red-600 hover:text-white rounded-xl text-xs font-bold transition-all border border-red-100 hover:shadow-lg hover:shadow-red-200 disabled:opacity-50"
                >
                  {isCancelling ? (
                    <RefreshCw className="w-3 h-3 animate-spin" />
                  ) : (
                    <Trash2 className="w-3 h-3" />
                  )}
                  {t('sales:anular_venta_2')}
                </button>
              </div>
            )}
          </div>

          {/* ── Tarjeta de Contacto del Cliente (para delivery/canales) ── */}
          {(sale.customerName || sale.customerPhone || sale.customerAddress) && (
            <div className="mb-4 bg-slate-50 border border-slate-200 rounded-2xl p-4 text-xs space-y-2.5">
              <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                <span className="font-black text-slate-900 uppercase tracking-wider text-xs flex items-center gap-1.5">
                  <User className="w-4 h-4 text-blue-600" />
                  {t('sales:tarjeta_de_contacto_del_cliente_value', { value: sale.channel || t('sales:delivery') })}
                </span>
                <span className="font-bold text-slate-700 bg-white px-2.5 py-0.5 rounded-lg border border-slate-200 text-xs">
                  {t('sales:pago_paymentmethod', { paymentMethod: sale.paymentMethod })}
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <span className="text-slate-500 font-bold block text-xs uppercase">{t('sales:nombre')}</span>
                  <span className="font-extrabold text-slate-900">{sale.customerName || t('sales:no_registrado')}</span>
                </div>
                {sale.customerPhone && (
                  <div>
                    <span className="text-slate-500 font-bold block text-xs uppercase">{t('sales:telefono_whatsapp')}</span>
                    <a 
                      href={`https://wa.me/57${sale.customerPhone.replace(/\D/g, '')}`} 
                      target="_blank" 
                      rel="noreferrer" 
                      className="font-extrabold text-emerald-700 hover:underline flex items-center gap-1 mt-0.5"
                    >
                      <Phone className="w-3.5 h-3.5 text-emerald-600" />
                      {sale.customerPhone}
                    </a>
                  </div>
                )}
                {sale.customerAddress && (
                  <div className="sm:col-span-3">
                    <span className="text-slate-500 font-bold block text-xs uppercase">{t('sales:direccion_de_entrega')}</span>
                    <span className="font-bold text-slate-900 flex items-center gap-1.5 mt-0.5">
                      <MapPin className="w-3.5 h-3.5 text-rose-500 flex-shrink-0" />
                      {sale.customerAddress}
                    </span>
                  </div>
                )}
                {sale.deliveryNotes && (
                  <div className="sm:col-span-3 text-xs text-slate-700 italic bg-white p-2.5 rounded-xl border border-slate-200">
                    "{sale.deliveryNotes}"
                  </div>
                )}
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-2">
              {items.map((item: any, idx: number) => {
                const name = item.productVariant?.product?.name || item.productName || t('sales:producto');
                const variant = item.productVariant?.name || item.variantName || '';
                const isCancelled = item.status === 'CANCELLED';

                return (
                  <div
                    key={idx}
                    className={`group flex items-center gap-3 rounded-[1.25rem] px-4 py-3 border transition-all ${
                      isCancelled
                        ? 'bg-red-50/50 border-red-100 opacity-60'
                        : 'bg-white border-slate-200 hover:border-blue-300 hover:shadow-sm'
                    }`}
                  >
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm flex-shrink-0 transition-colors ${
                        isCancelled ? 'bg-red-100 text-red-600' : 'bg-blue-50 text-blue-700'
                      }`}
                    >
                      {item.quantity}×
                    </div>

                    <div className="flex-1 min-w-0">
                      <p className={`font-bold text-sm truncate ${isCancelled ? 'line-through text-slate-400' : 'text-slate-800'}`}>
                        {name}
                      </p>
                      {variant && (
                        <p className="text-xs text-slate-500 font-medium flex items-center gap-1 mt-0.5">
                          <Tag className="w-3 h-3 opacity-60" />
                          {variant}
                        </p>
                      )}
                    </div>

                    <div className="text-right flex-shrink-0">
                      <p className={`font-black text-sm tabular-nums ${isCancelled ? 'text-slate-400 line-through' : 'text-slate-900'}`}>
                        {formatCurrency(item.total)}
                      </p>
                      {item.quantity > 1 && (
                        <p className="text-xs font-bold text-slate-400 tabular-nums">{formatCurrency(item.unitPrice)} c/u</p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="space-y-4">
              <div className="rounded-3xl bg-slate-900 border border-slate-800 px-5 py-5 text-slate-100 shadow-xl">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">{t('sales:resumen_de_pago')}</p>
                <div className="space-y-3">
                  <div className="flex justify-between items-center text-lg font-black text-white">
                    <span className="text-slate-400 uppercase text-xs tracking-widest">{t('sales:valor_venta')}</span>
                    <span className="text-emerald-400 tabular-nums">{formatCurrency(sale.total)}</span>
                  </div>
                  {(tip > 0 || canEditTip) && (
                    <div className="rounded-2xl bg-slate-800/70 border border-slate-700 px-3 py-2.5 space-y-1.5">
                      <div className="flex justify-between items-center text-sm">
                        <span className="flex items-center gap-1.5 font-bold text-teal-300">
                          <HeartHandshake className="w-4 h-4" aria-hidden />
                          {t('sales:propina')}
                        </span>
                        <span className="font-black text-teal-300 tabular-nums">{formatCurrency(tip)}</span>
                      </div>
                      <p className="text-[0.7857rem] text-slate-400">{t('sales:propina_no_suma')}{sale.waiterName ? ` · ${t('sales:para_mesero', { name: sale.waiterName })}` : ''}</p>
                      {sale.tipEditedAt && (
                        <p className="text-[0.7857rem] text-amber-300/90">
                          {t('sales:propina_editada', { by: sale.tipEditedBy || '—', from: formatCurrency(sale.tipOriginal ?? 0), reason: sale.tipEditReason || '' })}
                        </p>
                      )}
                      {canEditTip && (
                        <button
                          type="button"
                          onClick={handleEditTip}
                          className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-200 hover:text-white underline underline-offset-2"
                        >
                          <Pencil className="w-3 h-3" aria-hidden />
                          {t('sales:corregir_propina')}
                        </button>
                      )}
                    </div>
                  )}
                  {tip > 0 && (
                    <div className="border-t border-slate-800 pt-3 flex justify-between items-center text-sm font-bold text-slate-300">
                      <span className="uppercase text-xs tracking-widest text-slate-400">{t('sales:cobrado_al_cliente')}</span>
                      <span className="tabular-nums">{formatCurrency(sale.total + tip)}</span>
                    </div>
                  )}
                  <div className="pt-1">
                    <PaymentBadge method={sale.paymentMethod} />
                  </div>
                </div>
              </div>
              
              {/* Cliente de la venta: se puede asignar después (no estaba registrado o quedó Cliente común) */}
              <div className="bg-white rounded-3xl p-4 border border-slate-200 flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">{t('sales:cliente')}</p>
                  <p className="mt-0.5 text-sm font-black text-slate-900 truncate">
                    {sale.customer && !sale.customer.isDefault ? sale.customer.name : t('sales:cliente_comun')}
                  </p>
                </div>
                {sale.status !== 'CANCELLED' && (
                  <button
                    type="button"
                    onClick={(e) => { e.stopPropagation(); if (!hasCustomers) return showPlanLock('customers'); setShowCustomer(true); }}
                    className="shrink-0 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 hover:border-blue-400 hover:text-blue-700"
                  >
                    <User className="w-3.5 h-3.5" aria-hidden />
                    {sale.customer && !sale.customer.isDefault ? t('sales:cambiar') : t('sales:asignar_cliente')}
                  </button>
                )}
              </div>

              <div className="bg-stone-100 rounded-3xl p-4 border border-stone-200">
                <p className="text-xs font-bold text-stone-400 uppercase tracking-widest mb-2 px-1">{t('sales:notas_de_auditoria')}</p>
                <p className="text-xs text-stone-600 font-medium italic px-1">
                  {t('sales:id_transaccion')}{' '}<span className="font-mono text-xs opacity-70">{sale.id}</span>
                </p>
                {sale.status === 'CANCELLED' && (
                  <div className="mt-2 p-2 bg-red-100/50 rounded-xl text-red-700 text-xs font-bold border border-red-200">
                    {t('sales:esta_venta_fue_anulada')}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {showCustomer && (
        <ChangeCustomerDialog
          sale={sale}
          onClose={() => setShowCustomer(false)}
          onChanged={() => { setShowCustomer(false); onUpdate(); }}
        />
      )}

      {/* Electronic Invoice Modal */}
      <ElectronicInvoiceModal
        isOpen={showInvoiceModal}
        onClose={() => setShowInvoiceModal(false)}
        sale={sale}
      />
    </div>
  );
};

/* ── Main Component ─────────────────────────────────────── */

const SalesHistoryList: React.FC = () => {
  // ── Estado de datos ──
  const [sales, setSales]                 = useState<any[]>([]);
  const [cashSessions, setCashSessions]   = useState<any[]>([]);
  const [availableMonths, setAvailableMonths] = useState<any[]>([]);
  const [config, setConfig]               = useState<any>({});

  // ── Estado de estadísticas globales/mensuales ──
  const [monthStats, setMonthStats] = useState<{
    totalRevenue: number;
    completedCount: number;
    cancelledCount: number;
    totalItems: number;
    avgTicket: number;
    totalTips?: number;
    paymentBreakdown: { CASH: number; CARD: number; TRANSFER: number; MIXED: number };
  }>({
    totalRevenue: 0,
    completedCount: 0,
    cancelledCount: 0,
    totalItems: 0,
    avgTicket: 0,
    paymentBreakdown: { CASH: 0, CARD: 0, TRANSFER: 0, MIXED: 0 }
  });

  // ── Estado de paginación y filtros ──
  const today = new Date();
  const [selectedYear,  setSelectedYear]  = useState<number>(today.getFullYear());
  const [selectedMonth, setSelectedMonth] = useState<number>(today.getMonth() + 1);
  const [currentPage,   setCurrentPage]   = useState<number>(1);
  const [totalPages,    setTotalPages]    = useState<number>(1);
  const [totalSales,    setTotalSales]    = useState<number>(0);
  const LIMIT = 50;

  // ── Filtros secundarios ──
  const [filterSession, setFilterSession] = useState<string>('all');
  const [filterStatus,  setFilterStatus]  = useState<string>('all');
  const [filterChannel, setFilterChannel] = useState<string>('all');

  // ── Estados de carga ──
  const [loading,       setLoading]       = useState(true);
  const [loadingMonths, setLoadingMonths] = useState(true);

  // ── Carga inicial: meses disponibles y sesiones ──
  useEffect(() => {
    const savedConfig = localStorage.getItem('posConfig');
    if (savedConfig) setConfig(JSON.parse(savedConfig));
    loadMonthsAndSessions();
  }, []);

  // ── Recargar ventas cuando cambia mes, página o filtros ──
  useEffect(() => {
    loadSalesByMonth();
  }, [selectedYear, selectedMonth, currentPage, filterSession, filterStatus]);

  const loadMonthsAndSessions = async () => {
    setLoadingMonths(true);
    try {
      const token = getToken();
      const [monthsRes, sessionsRes] = await Promise.all([
        fetch(`${API_URL}/sales/available-months`, { headers: { Authorization: `Bearer ${token}` } }),
        fetch(`${API_URL}/cash-sessions`,          { headers: { Authorization: `Bearer ${token}` } }),
      ]);
      if (monthsRes.ok) {
        const data = await monthsRes.json();
        setAvailableMonths(data);
      }
      if (sessionsRes.ok) {
        const data = await sessionsRes.json();
        setCashSessions(data.sort((a: any, b: any) =>
          new Date(b.openedAt).getTime() - new Date(a.openedAt).getTime()
        ));
      }
    } catch (err) {
      console.error('Error loading months/sessions:', err);
    }
    setLoadingMonths(false);
  };

  const loadSalesByMonth = async () => {
    setLoading(true);
    try {
      const token = getToken();
      const params = new URLSearchParams({
        year:  String(selectedYear),
        month: String(selectedMonth),
        page:  String(currentPage),
        limit: String(LIMIT),
      });
      if (filterSession !== 'all') params.set('cashSessionId', filterSession);
      if (filterStatus  !== 'all') params.set('status', filterStatus);

      const res = await fetch(`${API_URL}/sales/by-month?${params}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const result = await res.json();
        setSales(result.data ?? []);
        setTotalPages(result.totalPages ?? 1);
        setTotalSales(result.total ?? 0);
        if (result.stats) {
          setMonthStats(result.stats);
        }
      }
    } catch (err) {
      console.error('Error loading sales by month:', err);
    }
    setLoading(false);
  };

  // ── Filtrar las sesiones de caja (arqueos) por el mes seleccionado ──
  const filteredCashSessions = useMemo(() => {
    if (selectedYear === 0 || selectedMonth === 0) {
      return cashSessions;
    }
    return cashSessions.filter(session => {
      const d = new Date(session.openedAt);
      return d.getFullYear() === selectedYear && (d.getMonth() + 1) === selectedMonth;
    });
  }, [cashSessions, selectedYear, selectedMonth]);

  // Si cambia el mes y la sesión seleccionada no pertenece a ese mes, reset a 'all'
  useEffect(() => {
    if (filterSession !== 'all' && !filteredCashSessions.some(s => s.id === filterSession)) {
      setFilterSession('all');
    }
  }, [filteredCashSessions, filterSession]);

  // ── Al cambiar mes ──
  const handleMonthChange = (key: string) => {
    if (!key) return;
    if (key === 'all') {
      setSelectedYear(0);
      setSelectedMonth(0);
    } else {
      const [y, m] = key.split('-').map(Number);
      setSelectedYear(y);
      setSelectedMonth(m);
    }
    setCurrentPage(1);
    setFilterSession('all');
  };

  const handleSessionChange = (v: string) => { setFilterSession(v); setCurrentPage(1); };
  const handleStatusChange  = (v: string) => { setFilterStatus(v);  setCurrentPage(1); };

  const clearFilters = () => {
    setFilterSession('all');
    setFilterStatus('all');
    setCurrentPage(1);
  };

  // ── Helpers computados ──
  const activeMonthKey   = selectedYear === 0 ? 'all' : `${selectedYear}-${String(selectedMonth).padStart(2, '0')}`;
  const activeMonthLabel = activeMonthKey === 'all'
    ? t('sales:historico_total')
    : (availableMonths.find(m => `${m.year}-${String(m.month).padStart(2, '0')}` === activeMonthKey)?.label
      ?? `${[t('sales:enero'),t('sales:febrero'),t('sales:marzo'),t('sales:abril'),t('sales:mayo'),t('sales:junio'),t('sales:julio'),t('sales:agosto'),t('sales:septiembre'),t('sales:octubre'),t('sales:noviembre'),t('sales:diciembre')][selectedMonth - 1]} ${selectedYear}`);

  const displayedSales = useMemo(() => {
    if (filterChannel === 'all') return sales;
    return sales.filter(s => (s.channel || 'POS') === filterChannel);
  }, [sales, filterChannel]);

  const totalRevenue     = monthStats.totalRevenue;
  const completedCount   = monthStats.completedCount;
  const cancelledCount   = monthStats.cancelledCount;
  const totalItems       = monthStats.totalItems;
  const avgTicket        = monthStats.avgTicket;
  const paymentBreakdown = monthStats.paymentBreakdown;

  // ── Exportar el periodo completo con los filtros activos (no solo la página visible) ──
  const reportQuery = () => ({
    year: selectedYear,
    month: selectedMonth,
    cashSessionId: filterSession !== 'all' ? filterSession : undefined,
    status: filterStatus !== 'all' ? filterStatus : undefined,
  });
  const reportScope = () => {
    const parts: string[] = [];
    const session = cashSessions.find((x) => x.id === filterSession);
    if (session) parts.push(t('reports:filtro_arqueo', { n: session.sessionNumber }));
    if (filterStatus !== 'all') parts.push(t('reports:filtro_estado', { status: STATUS_CONFIG[filterStatus]?.label ?? filterStatus }));
    return parts.join(' · ') || undefined;
  };
  const buildReport = async () =>
    buildSalesReport(await fetchAllSales(reportQuery()), selectedYear === 0 ? t('sales:historico') : activeMonthLabel, reportScope());


  /* ── Loading estado inicial de meses ── */
  if (loadingMonths) {
    return (
      <div className="flex flex-col items-center justify-center h-[50vh] gap-4">
        <div className="w-12 h-12 border-4 border-slate-200 border-t-blue-600 rounded-full animate-spin" />
        <p className="text-sm font-bold text-slate-700 animate-pulse">{t('sales:iniciando_historial')}</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-10">

      {/* ── Estadísticas rápidas del período ── */}
      <SalesQuickStats
        loading={loading}
        periodLabel={activeMonthLabel}
        revenue={totalRevenue}
        completed={completedCount}
        items={totalItems}
        avgTicket={avgTicket}
        tips={monthStats.totalTips ?? 0}
        cancelled={cancelledCount}
        cashSessions={filteredCashSessions.length}
        payments={paymentBreakdown}
      />

      {/* ── Filters & Export ── */}
      <div data-guide="sales-filters" className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm">
        {/* Header row */}
        <div className="flex items-center gap-3 mb-5">
          <div className="flex items-center gap-2 bg-slate-900 text-white px-4 py-2.5 rounded-2xl shadow-sm">
            <Filter className="w-4 h-4 text-blue-400" />
            <span className="text-xs font-black uppercase tracking-wider">{t('sales:filtrar_reporte')}</span>
          </div>
          {(filterSession !== 'all' || filterStatus !== 'all' || filterChannel !== 'all' || selectedYear === 0) && (
            <button
              onClick={clearFilters}
              className="text-xs font-bold text-slate-500 hover:text-rose-600 underline underline-offset-2 transition-colors"
            >
              {t('sales:limpiar_filtros')}
            </button>
          )}
        </div>

        {/* Filter chips row */}
        <div className="flex flex-wrap gap-3 mb-4">
          {/* ── Month Selector ── */}
          <div className="flex flex-col gap-1 min-w-[240px]">
            <label className="text-xs font-black uppercase tracking-widest text-slate-500 flex items-center gap-1 px-1">
              <CalendarDays className="w-3 h-3 text-blue-600" />{' '}{t('sales:mes')}
            </label>
            <select
              value={activeMonthKey}
              onChange={e => handleMonthChange(e.target.value)}
              className="text-sm font-bold px-4 py-3 border border-slate-200 rounded-xl bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 focus:outline-none transition-all cursor-pointer text-slate-800"
            >
              <option value="all">{t('sales:todos_los_meses_historico_total')}</option>
              {availableMonths.map(m => {
                const key = `${m.year}-${String(m.month).padStart(2, '0')}`;
                return (
                  <option key={key} value={key}>
                    {t('sales:label_count_ventas_amount', { label: m.label, count: m.count, amount: formatCurrency(m.totalRevenue) })}
                  </option>
                );
              })}
            </select>
          </div>

          {/* ── Session Filter (Filtrado por mes seleccionado) ── */}
          <div className="flex flex-col gap-1 min-w-[240px]">
            <label className="text-xs font-black uppercase tracking-widest text-slate-500 flex items-center gap-1 px-1">
              <History className="w-3 h-3 text-blue-600" />{' '}{t('sales:arqueo_sesion')}
            </label>
            <select
              value={filterSession}
              onChange={e => handleSessionChange(e.target.value)}
              className="text-sm font-bold px-4 py-3 border border-slate-200 rounded-xl bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 focus:outline-none transition-all cursor-pointer text-slate-800"
            >
              <option value="all">
                {selectedYear === 0 ? t('sales:todos_los_arqueos') : t('sales:arqueos_de_activemonthlabel_length', { activeMonthLabel, length: filteredCashSessions.length })}
              </option>
              {filteredCashSessions.map(session => (
                <option key={session.id} value={session.id}>
                  {t('sales:arqueo_sessionnumber_value_value2', { sessionNumber: session.sessionNumber, value: new Date(session.openedAt).toLocaleDateString(getLocale()), value2: session.status === 'OPEN' ? t('sales:vigente') : '' })}
                </option>
              ))}
            </select>
          </div>

          {/* ── Status Filter ── */}
          <div className="flex flex-col gap-1 min-w-[160px]">
            <label className="text-xs font-black uppercase tracking-widest text-slate-500 flex items-center gap-1 px-1">
              <CheckCircle2 className="w-3 h-3 text-blue-600" />{' '}{t('sales:estado')}
            </label>
            <select
              value={filterStatus}
              onChange={e => handleStatusChange(e.target.value)}
              className="text-sm font-bold px-4 py-3 border border-slate-200 rounded-xl bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 focus:outline-none transition-all cursor-pointer text-slate-800"
            >
              <option value="all">{t('sales:cualquier_estado')}</option>
              <option value="COMPLETED">{t('sales:completadas')}</option>
              <option value="PENDING">{t('sales:pendientes')}</option>
              <option value="CANCELLED">{t('sales:anuladas')}</option>
            </select>
          </div>

          {/* ── Channel Filter (Rappi, WhatsApp, Web, Salón) ── */}
          <div className="flex flex-col gap-1 min-w-[200px]">
            <label className="text-xs font-black uppercase tracking-widest text-slate-500 flex items-center gap-1 px-1">
              <Zap className="w-3 h-3 text-orange-500" />{' '}{t('sales:canal_de_venta')}
            </label>
            <select
              value={filterChannel}
              onChange={e => setFilterChannel(e.target.value)}
              className="text-sm font-bold px-4 py-3 border border-slate-200 rounded-xl bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 focus:outline-none transition-all cursor-pointer text-slate-800"
            >
              <option value="all">{t('sales:todos_los_canales')}</option>
              <option value="COUNTER">{t('sales:mostrador_2')}</option>
              <option value="POS">{t('sales:salon_mesas')}</option>
              <option value="RAPPI">{t('sales:rappi')}</option>
              <option value="WHATSAPP">{t('sales:whatsapp_bot')}</option>
              <option value="WEB">{t('sales:tienda_web')}</option>
            </select>
          </div>
        </div>

        {/* Active filter indicator + export */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-slate-100">
          <div className="flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 text-white rounded-full text-xs font-bold">
              <CalendarDays className="w-3.5 h-3.5 text-blue-400" />
              {activeMonthLabel}
            </span>
            {filterSession !== 'all' && (
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 text-white rounded-full text-xs font-bold">
                <History className="w-3.5 h-3.5 text-blue-400" />
                {cashSessions.find(s => s.id === filterSession)
                  ? t('sales:arqueo_sessionnumber', { sessionNumber: cashSessions.find(s => s.id === filterSession)?.sessionNumber })
                  : t('sales:sesion')}
                <button onClick={() => handleSessionChange('all')} className="ml-1 hover:text-slate-300 transition-colors">×</button>
              </span>
            )}
            {filterStatus !== 'all' && (
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 text-white rounded-full text-xs font-bold">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                {STATUS_CONFIG[filterStatus]?.label ?? filterStatus}
                <button onClick={() => handleStatusChange('all')} className="ml-1 hover:text-slate-300 transition-colors">×</button>
              </span>
            )}
            <span className="text-xs text-slate-500 font-bold tabular-nums">
              {totalSales} {totalSales === 1 ? t('sales:venta_2') : t('sales:ventas')} ({formatCurrency(totalRevenue)})
            </span>
          </div>

          <div className="flex gap-2">
            <ReportButton build={buildReport} fileName={`ventas-${activeMonthLabel}`} disabled={totalSales === 0} />
            <button
              onClick={loadSalesByMonth}
              disabled={loading}
              className="flex items-center gap-2 bg-white text-slate-700 px-4 py-3 rounded-xl font-bold hover:bg-slate-50 border border-slate-200 transition-all disabled:opacity-50"
              title={t('sales:recargar_datos')}
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>
      </div>


      {/* ── Sales list ── */}
      <div className="space-y-4">
        <div className="flex items-center justify-between px-2">
          <div className="flex items-center gap-3">
            <h2 className="text-xl font-black text-slate-800 tracking-tight">{t('sales:registro_de_operaciones')}</h2>
            <div className="px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-xs font-black uppercase border border-blue-200 tabular-nums">
              {loading ? '...' : `${sales.length} de ${totalSales}`}
            </div>
          </div>

          {/* ── Paginación ── */}
          {totalPages > 1 && (
            <div className="flex items-center gap-2">
              <button
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1 || loading}
                className="px-3 py-2 bg-white border border-slate-200 text-slate-700 rounded-xl font-bold text-sm hover:bg-slate-50 disabled:opacity-40 transition-all"
              >
                {t('sales:anterior')}
              </button>
              <span className="px-3 py-2 text-sm font-black text-slate-800 tabular-nums">
                {currentPage} / {totalPages}
              </span>
              <button
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages || loading}
                className="px-3 py-2 bg-white border border-slate-200 text-slate-700 rounded-xl font-bold text-sm hover:bg-slate-50 disabled:opacity-40 transition-all"
              >
                {t('sales:siguiente')}
              </button>
            </div>
          )}
        </div>

        {loading ? (
          <div className="space-y-3">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="bg-white rounded-[2rem] p-6 h-24 animate-pulse border border-slate-200 shadow-sm" />
            ))}
          </div>
        ) : displayedSales.length === 0 ? (
          <div className="bg-white rounded-3xl border-2 border-dashed border-slate-200 text-center py-20 shadow-sm">
            <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <AlertCircle className="w-8 h-8 text-slate-400" />
            </div>
            <p className="font-black text-slate-800 text-lg">{t('sales:no_hay_ventas_registradas_con_los_filtros')}</p>
            <p className="text-xs text-slate-400 mt-1 font-medium">{t('sales:prueba_seleccionando_otro_canal_o_limpiando_los')}</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4">
            {displayedSales.map(sale => (
              <SaleCard key={sale.id} sale={sale} onUpdate={loadSalesByMonth} config={config} />
            ))}
          </div>
        )}

        {/* Paginación inferior */}
        {totalPages > 1 && !loading && (
          <div className="flex items-center justify-center gap-3 pt-4">
            <button
              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="px-5 py-2.5 bg-white border border-slate-200 text-slate-700 rounded-xl font-bold text-sm hover:bg-slate-50 disabled:opacity-40 transition-all shadow-sm"
            >
              {t('sales:anterior')}
            </button>
            <div className="flex items-center gap-1.5">
              {[...Array(Math.min(totalPages, 7))].map((_, i) => {
                const page = totalPages <= 7 ? i + 1
                  : currentPage <= 4 ? i + 1
                  : currentPage >= totalPages - 3 ? totalPages - 6 + i
                  : currentPage - 3 + i;
                return (
                  <button
                    key={page}
                    onClick={() => setCurrentPage(page)}
                    className={`w-9 h-9 rounded-xl font-black text-sm transition-all tabular-nums ${
                      page === currentPage
                        ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/20'
                        : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    {page}
                  </button>
                );
              })}
            </div>
            <button
              onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="px-5 py-2.5 bg-white border border-slate-200 text-slate-700 rounded-xl font-bold text-sm hover:bg-slate-50 disabled:opacity-40 transition-all shadow-sm"
            >
              {t('sales:siguiente')}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

/**
 * Ventas con su subpestaña Propinas (Fase 4 · mejoras): todo lo de propinas
 * (encender, estadísticas, reglas y reparto) vive aquí y solo lo ve el ADMIN.
 */
export const SalesHistory: React.FC = () => {
  const isAdmin = (() => { try { return JSON.parse(localStorage.getItem('user') || '{}')?.role === 'ADMIN'; } catch { return false; } })();
  const [sub, setSub] = useState<'sales' | 'tips'>(() => { try { return sessionStorage.getItem('lantify.sales.sub') === 'tips' ? 'tips' : 'sales'; } catch { return 'sales'; } });
  const pick = (v: 'sales' | 'tips') => { setSub(v); try { sessionStorage.setItem('lantify.sales.sub', v); } catch { /* sin almacenamiento */ } };
  if (!isAdmin) return <SalesHistoryList />;
  return (
    <div className="space-y-4">
      <div className="inline-flex gap-1 rounded-2xl bg-slate-100 p-1" role="tablist" aria-label={t('tips:ventas_subtabs')}>
        {(['sales', 'tips'] as const).map((id) => (
          <button key={id} type="button" role="tab" aria-selected={sub === id} onClick={() => pick(id)} className={`inline-flex min-h-[40px] items-center gap-2 rounded-xl px-4 text-sm font-bold transition ${sub === id ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}>
            {id === 'sales' ? <Receipt className="h-4 w-4" aria-hidden /> : <HeartHandshake className="h-4 w-4" aria-hidden />}{t(`tips:subtab_${id}`)}
          </button>
        ))}
      </div>
      {sub === 'sales' ? <SalesHistoryList /> : <TipsCenter />}
    </div>
  );
};

export default SalesHistory;
