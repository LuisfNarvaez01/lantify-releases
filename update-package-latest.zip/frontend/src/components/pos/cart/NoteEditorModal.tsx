// ============================================
// CART - Nota para cocina de un producto
// ============================================

import { useEffect, useState } from 'react';
import { FileText, X } from 'lucide-react';
import { t } from '../../../i18n';

interface NoteEditorModalProps {
  productName: string;
  initialNote: string;
  onSave: (note: string) => void;
  onClose: () => void;
}

const quickNotes = () => [
  t('pos:para_llevar'), t('pos:sin_cebolla'), t('pos:sin_picante'), t('pos:termino_medio'), t('pos:bien_cocido'),
  t('pos:caliente'), t('pos:frio'), t('pos:poco_hielo'), t('pos:sin_azucar'), t('pos:separado'),
];

export function NoteEditorModal({ productName, initialNote, onSave, onClose }: NoteEditorModalProps) {
  const [text, setText] = useState(initialNote);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" role="presentation">
      <div role="dialog" aria-modal="true" aria-labelledby="note-title" className="bg-white rounded-3xl w-full max-w-md shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between p-4 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-600" aria-hidden />
            <div>
              <h3 id="note-title" className="font-bold text-base text-slate-900 font-heading">{t('pos:nota_para_cocina')}</h3>
              <p className="text-xs text-slate-500">{productName}</p>
            </div>
          </div>
          <button type="button" onClick={onClose} aria-label={t('pos:cerrar')} className="w-10 h-10 hover:bg-slate-100 text-slate-500 rounded-xl flex items-center justify-center">
            <X className="w-5 h-5" aria-hidden />
          </button>
        </div>

        <div className="p-4 space-y-4">
          <div>
            <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{t('pos:especificaciones_comunes')}</p>
            <div className="flex flex-wrap gap-1.5">
              {quickNotes().map((tag) => (
                <button
                  key={tag}
                  type="button"
                  onClick={() => setText(text ? `${text}, ${tag}` : tag)}
                  className="px-2.5 min-h-[36px] bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-slate-700 text-xs font-semibold rounded-xl border border-slate-200"
                >
                  + {tag}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label htmlFor="note-text" className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">{t('pos:detalle_de_la_nota')}</label>
            <textarea
              id="note-text"
              rows={3}
              autoFocus
              value={text}
              maxLength={200}
              onChange={(e) => setText(e.target.value)}
              placeholder={t('pos:ej_salsa_aparte_bien_cocido_sin_hielo')}
              className="w-full p-3 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20"
            />
          </div>
          <div className="flex gap-2 pt-2 border-t border-slate-100">
            {initialNote && (
              <button type="button" onClick={() => onSave('')} className="px-4 min-h-[44px] bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-sm font-bold">
                {t('pos:quitar_nota')}
              </button>
            )}
            <button type="button" onClick={() => onSave(text.trim())} className="flex-1 min-h-[44px] bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-bold">
              {t('pos:guardar_nota')}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
