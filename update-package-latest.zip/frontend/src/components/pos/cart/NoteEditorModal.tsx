// ============================================
// CART - Comentarios de un producto para cocina
// ============================================
// Tres niveles, del más rápido al más libre: quitar un ingrediente con un toque
// (si el producto los tiene definidos), frases rápidas del negocio y texto libre,
// que siempre está. En el celular se abre como hoja inferior.

import { useEffect, useMemo, useState } from 'react';
import { X } from 'lucide-react';
import { t } from '../../../i18n';
import { useFeatures } from '../../../shared/features';
import { removedText } from '../../../shared/itemNotes';

interface NoteEditorModalProps {
  productName: string;
  initialNote: string;
  /** Ingredientes del producto que se pueden quitar */
  ingredients?: string[];
  initialRemoved?: string[];
  onSave: (note: string, removed: string[]) => void;
  onClose: () => void;
}

export function NoteEditorModal({ productName, initialNote, ingredients = [], initialRemoved = [], onSave, onClose }: NoteEditorModalProps) {
  const [text, setText] = useState(initialNote);
  const [removed, setRemoved] = useState<string[]>(initialRemoved);
  const quickNotes = useFeatures((s) => s.settings.quickNotes);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  // Un ingrediente quitado que ya no está en la ficha del producto se sigue mostrando
  const options = useMemo(() => [...new Set([...ingredients, ...initialRemoved])], [ingredients, initialRemoved]);
  const toggle = (name: string) => setRemoved((r) => (r.includes(name) ? r.filter((x) => x !== name) : [...r, name]));
  const addPhrase = (phrase: string) => setText((cur) => (cur.toLowerCase().includes(phrase.toLowerCase()) ? cur : cur ? `${cur}, ${phrase}` : phrase));
  const summary = [removedText(removed), text.trim()].filter(Boolean).join(' · ');
  const hadSomething = !!initialNote || initialRemoved.length > 0;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-end sm:items-center justify-center z-50 sm:p-4" role="presentation" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div role="dialog" aria-modal="true" aria-labelledby="note-title" className="bg-white rounded-t-3xl sm:rounded-3xl w-full sm:max-w-md shadow-2xl overflow-hidden max-h-[92dvh] flex flex-col">
        <div className="flex items-center justify-between p-4 border-b border-slate-100 shrink-0">
          <div className="min-w-0">
            <h3 id="note-title" className="font-bold text-lg text-slate-900 font-heading truncate">{productName}</h3>
            <p className="text-xs text-slate-500">{t('v3:comentarios_para_cocina')}</p>
          </div>
          <button type="button" onClick={onClose} aria-label={t('pos:cerrar')} className="w-11 h-11 hover:bg-slate-100 text-slate-500 rounded-xl flex items-center justify-center shrink-0">
            <X className="w-5 h-5" aria-hidden />
          </button>
        </div>

        <div className="p-4 space-y-5 overflow-y-auto">
          {options.length > 0 && (
            <fieldset>
              <legend className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{t('v3:toca_para_quitar')}</legend>
              <div className="flex flex-wrap gap-2">
                {options.map((name) => {
                  const off = removed.includes(name);
                  return (
                    <button
                      key={name}
                      type="button"
                      aria-pressed={off}
                      onClick={() => toggle(name)}
                      className={`px-3.5 min-h-[48px] rounded-xl border-2 text-sm font-semibold transition-colors ${
                        off ? 'bg-rose-50 border-rose-500 text-rose-800' : 'bg-white border-slate-200 text-slate-800 hover:border-slate-400'
                      }`}
                    >
                      {off ? <span><span className="font-black">{t('v3:sin')} </span><span className="line-through">{name}</span></span> : name}
                    </button>
                  );
                })}
              </div>
            </fieldset>
          )}

          {quickNotes.length > 0 && (
            <div>
              <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{t('v3:frases_rapidas')}</p>
              <div className="flex flex-wrap gap-2">
                {quickNotes.map((tag) => (
                  <button key={tag} type="button" onClick={() => addPhrase(tag)} className="px-3.5 min-h-[48px] bg-slate-100 hover:bg-blue-50 hover:text-blue-800 text-slate-800 text-sm font-semibold rounded-xl border border-slate-200">
                    {tag}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div>
            <label htmlFor="note-text" className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">{t('v3:comentario_libre')}</label>
            <textarea
              id="note-text"
              rows={2}
              value={text}
              maxLength={200}
              onChange={(e) => setText(e.target.value)}
              placeholder={t('pos:ej_salsa_aparte_bien_cocido_sin_hielo')}
              className="w-full p-3 border-2 border-slate-200 rounded-xl text-base text-slate-900 focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20"
            />
          </div>
        </div>

        <div className="p-4 border-t border-slate-100 flex gap-2 shrink-0">
          {hadSomething && (
            <button type="button" onClick={() => onSave('', [])} className="px-4 min-h-[52px] bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-sm font-bold">
              {t('v3:borrar_todo')}
            </button>
          )}
          <button type="button" onClick={() => onSave(text.trim(), removed)} className="flex-1 min-h-[52px] px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-base font-bold truncate">
            {summary ? `${t('v3:listo')} · ${summary}` : t('v3:listo')}
          </button>
        </div>
      </div>
    </div>
  );
}
