// ============================================
// CART - Descuento (caja pequeña con valores rápidos y valor libre)
// ============================================

import { useState } from 'react';
import { Percent, ChevronDown } from 'lucide-react';
import { Popover } from '../../common/Popover';
import { t } from '../../../i18n';

const PRESETS = [5, 10, 15, 20, 25, 50];
const MAX_DISCOUNT = 100;

interface DiscountControlProps {
  value: number;
  onChange: (pct: number) => void;
  disabled?: boolean;
}

export function DiscountControl({ value, onChange, disabled }: DiscountControlProps) {
  const active = value > 0;
  return (
    <Popover
      align="right"
      disabled={disabled}
      triggerLabel={t('pos:descuento_value', { value })}
      triggerClassName={`h-11 inline-flex items-center gap-1.5 px-3 rounded-xl border text-sm font-semibold whitespace-nowrap transition-colors ${
        active ? 'border-emerald-300 bg-emerald-50 text-emerald-800' : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
      } disabled:opacity-50`}
      panelClassName="w-64"
      trigger={
        <>
          <Percent className="w-4 h-4" aria-hidden />
          <span>{active ? `-${value}%` : t('pos:descuento_corto')}</span>
          <ChevronDown className="w-4 h-4 opacity-60" aria-hidden />
        </>
      }
    >
      {(close) => <DiscountPanel value={value} onApply={(v) => { onChange(v); close(); }} />}
    </Popover>
  );
}

function DiscountPanel({ value, onApply }: { value: number; onApply: (v: number) => void }) {
  const [custom, setCustom] = useState(value > 0 ? String(value) : '');
  const parsed = Number(custom.replace(',', '.'));
  const valid = custom !== '' && Number.isFinite(parsed) && parsed > 0 && parsed <= MAX_DISCOUNT;

  return (
    <div className="p-3 space-y-3">
      <p className="text-xs font-bold uppercase tracking-wider text-slate-500">{t('pos:descuento_sobre_la_cuenta')}</p>
      <div className="grid grid-cols-3 gap-1.5">
        {PRESETS.map((pct) => (
          <button
            key={pct}
            type="button"
            onClick={() => onApply(pct)}
            aria-pressed={value === pct}
            className={`min-h-[40px] rounded-xl text-sm font-black border ${
              value === pct ? 'bg-blue-600 border-blue-600 text-white' : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
            }`}
          >
            {pct}%
          </button>
        ))}
      </div>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          if (valid) onApply(Math.round(parsed * 100) / 100);
        }}
        className="flex items-center gap-2"
      >
        <label htmlFor="discount-custom" className="sr-only">{t('pos:otro_porcentaje')}</label>
        <div className="relative flex-1">
          <input
            id="discount-custom"
            inputMode="decimal"
            value={custom}
            onChange={(e) => setCustom(e.target.value.replace(/[^0-9.,]/g, ''))}
            placeholder={t('pos:otro_porcentaje')}
            className="w-full pl-3 pr-7 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20"
          />
          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm font-bold text-slate-400">%</span>
        </div>
        <button type="submit" disabled={!valid} className="px-3 min-h-[40px] rounded-xl bg-blue-600 text-white text-sm font-bold disabled:opacity-40">
          {t('pos:aplicar')}
        </button>
      </form>
      {value > 0 && (
        <button type="button" onClick={() => onApply(0)} className="w-full min-h-[36px] rounded-xl text-xs font-bold text-rose-700 hover:bg-rose-50">
          {t('pos:quitar_descuento')}
        </button>
      )}
    </div>
  );
}
