// ============================================
// CART - Cobrar → Transferencia: "Esperando confirmación…" (Fase 4 · D · 3)
// ============================================
// Con la función encendida, la caja espera una transferencia de este valor exacto. Cuando
// el celular del negocio lee el aviso del banco, llega por SSE y el recuadro se pone verde.
// Es solo una ayuda: el botón de confirmar el pago funciona siempre, llegue o no el aviso.

import { useEffect, useRef, useState, type MutableRefObject } from 'react';
import { BadgeCheck, Hourglass } from 'lucide-react';
import { t } from '../../../i18n';
import { formatCurrency } from '../../../shared/formatUtils';
import { transfersAPI, type ExpectedTransfer } from '../../../services/v3Api';
import { LIVE_PAYMENTS_EVENT } from '../../../shared/live';

const POLL_MS = 8000;
const APP_LABEL: Record<string, string> = { NEQUI: 'Nequi', DAVIPLATA: 'Daviplata', BANCOLOMBIA: 'Bancolombia', BREB: 'Bre-B' };

interface Props {
  amount: number;
  /** true al confirmar el pago: la transferencia emparejada queda usada */
  keepRef: MutableRefObject<boolean>;
}

export function TransferWait({ amount: rawAmount, keepRef }: Props) {
  const [state, setState] = useState<ExpectedTransfer | null>(null);
  const idRef = useRef<string | null>(null);
  // Mientras escriben la propina el valor cambia: se espera a que se quede quieto
  const [amount, setAmount] = useState(rawAmount);
  useEffect(() => {
    const h = setTimeout(() => setAmount(rawAmount), 600);
    return () => clearTimeout(h);
  }, [rawAmount]);

  useEffect(() => {
    if (!(amount > 0)) return;
    let alive = true;
    let id: string | null = null;
    const refresh = async () => {
      if (!id) return;
      try {
        const next = await transfersAPI.status(id);
        if (alive) setState(next);
      } catch { /* sin conexión: el cajero confirma a mano */ }
    };
    transfersAPI.expect(amount).then((s) => {
      if (!alive) { void transfersAPI.close(s.id, false).catch(() => undefined); return; }
      id = s.id;
      idRef.current = s.id;
      setState(s);
    }).catch(() => { if (alive) setState(null); });
    const onLive = () => { void refresh(); };
    window.addEventListener(LIVE_PAYMENTS_EVENT, onLive);
    const timer = setInterval(() => void refresh(), POLL_MS);
    return () => {
      alive = false;
      window.removeEventListener(LIVE_PAYMENTS_EVENT, onLive);
      clearInterval(timer);
      if (id) void transfersAPI.close(id, keepRef.current).catch(() => undefined);
      idRef.current = null;
    };
  }, [amount, keepRef]);

  if (!state) return null;
  const transfer = state.transfer;

  if (state.status === 'CONFIRMED' && transfer) {
    const time = new Date(transfer.postedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    return (
      <div role="status" className="mt-3 flex items-start gap-3 rounded-2xl border border-emerald-300 bg-emerald-50 p-3 text-emerald-900">
        <BadgeCheck className="mt-0.5 h-5 w-5 shrink-0 text-emerald-700" aria-hidden />
        <div className="min-w-0">
          <p className="text-sm font-bold">{t('v3:transfer_recibida')}</p>
          <p className="text-xs">
            {t('v3:transfer_detalle', { monto: formatCurrency(transfer.amount), remitente: transfer.sender || t('v3:transfer_sin_nombre'), app: APP_LABEL[transfer.app] || transfer.app, hora: time })}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div role="status" aria-live="polite" className="mt-3 flex items-start gap-3 rounded-2xl border border-slate-200 bg-slate-50 p-3 text-slate-700">
      <Hourglass className={`mt-0.5 h-5 w-5 shrink-0 text-slate-400 ${state.status === 'WAITING' ? 'motion-safe:animate-pulse' : ''}`} aria-hidden />
      <div className="min-w-0">
        <p className="text-sm font-bold">{state.status === 'EXPIRED' ? t('v3:transfer_vencio') : t('v3:transfer_esperando')}</p>
        <p className="text-xs text-slate-500">{t('v3:transfer_esperando_desc')}</p>
      </div>
    </div>
  );
}
