// ============================================
// CART - Enviar a cocina lo nuevo del pedido
// ============================================
// La misma secuencia que el botón "Cocina" del carrito (Cart.tsx › handleMakeOrder),
// para usarla desde la vista de celular sin montar el carrito completo.

import { useRef, useState } from 'react';
import { usePosStore } from '../../../store/usePosStore';
import { printService } from '../../../services/printService';
import { usePrintSettings } from '../../../shared/printSettings';
import { useFloorStore } from '../../../shared/features';
import { toast } from '../../../shared/toast';
import { t } from '../../../i18n';

const currentUserName = (): string | null => {
  try {
    const u = JSON.parse(localStorage.getItem('user') || '{}');
    return u?.name || u?.username || null;
  } catch {
    return null;
  }
};

export function useSendToKitchen() {
  const [sending, setSending] = useState(false);
  const lock = useRef(false);

  const send = async (): Promise<boolean> => {
    const store = usePosStore.getState();
    const { selectedTable, cashSession, products, categories } = store;
    const cart = store.getCurrentCart();
    const newItems = cart.filter((i) => !i.isOrdered);
    if (lock.current || newItems.length === 0) return false;
    if (!cashSession) {
      toast.warning(t('pos:debe_abrir_un_arqueo_de_caja_antes_2'), t('pos:caja_requerida'));
      return false;
    }
    lock.current = true;
    setSending(true);
    try {
      const rounds = cart.filter((i) => i.isOrdered && i.roundNumber).map((i) => i.roundNumber as number);
      const nextRound = (rounds.length ? Math.max(...rounds) : 0) + 1;
      const tableId = selectedTable?.id || 'counter';
      if (selectedTable) await store.orderTable(selectedTable.id);
      store.setCartAsOrdered(tableId);
      const synced = await store.savePendingOrder(tableId, usePosStore.getState().getCurrentCart());
      if (!synced) toast.warning(t('v3:pedido_no_sincronizado'), t('pos:no_se_pudo_enviar_a_cocina'));

      if (usePrintSettings.getState().settings.autoPrintKitchen) {
        const lookup = (productId: string) => {
          const product = products.find((p) => p.id === productId);
          const category = product?.categoryId ? categories.find((c) => c.id === product.categoryId) || product.category : undefined;
          return { product: product?.printStation, category: category?.printStation };
        };
        printService.printKitchenTicket({
          items: newItems,
          tableNumber: selectedTable?.number || t('pos:mostrador'),
          roundNumber: nextRound,
          waiterName: currentUserName(),
        }, lookup).catch(() => toast.warning(t('printing:no_se_pudo_comanda')));
      }

      toast.success(
        selectedTable
          ? t('pos:pedido_ronda_nextround_enviado_a_cocina_para', { nextRound, number: selectedTable.number })
          : t('pos:comanda_de_mostrador_ronda_nextround_enviada_a', { nextRound }),
        t('pos:cocina_notificada'),
      );
      setTimeout(() => useFloorStore.getState().refresh(), 800);
      return true;
    } catch (error: any) {
      toast.error(error?.message || t('pos:no_se_pudo_enviar_a_cocina'), t('pos:no_se_pudo_enviar_a_cocina'));
      return false;
    } finally {
      lock.current = false;
      setSending(false);
    }
  };

  return { send, sending };
}
