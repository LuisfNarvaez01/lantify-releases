// ============================================
// CART - Selector de cliente (menú desplegable)
// ============================================

import { useEffect, useRef, useState } from 'react';
import { User, ChevronDown, Search, UserPlus, RotateCcw, Loader2, Cake } from 'lucide-react';
import { Popover } from '../../common/Popover';
import { customersAPI } from '../../../services/api';
import { errorMessage } from '../../../services/apiErrors';
import { toast } from '../../../shared/toast';
import { t } from '../../../i18n';

interface CustomerPickerProps {
  customer: any | null;
  onSelect: (customer: any) => void;
  isBirthday?: boolean;
}

const inputClass =
  'w-full px-3 py-2 text-sm border border-slate-200 rounded-xl bg-white focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20';

export function CustomerPicker({ customer, onSelect, isBirthday }: CustomerPickerProps) {
  const isDefault = !customer || customer.isDefault;
  const name = isDefault ? t('pos:cliente_comun') : customer.name;

  return (
    <Popover
      triggerLabel={t('pos:cliente_name', { name })}
      triggerClassName="w-full h-11 inline-flex items-center gap-2 pl-2.5 pr-2 rounded-xl border border-slate-200 bg-white hover:border-slate-300 text-left transition-colors"
      panelClassName="w-[min(22rem,calc(100vw-2rem))]"
      trigger={
        <>
          <span className={`w-6 h-6 rounded-lg flex items-center justify-center shrink-0 ${isDefault ? 'bg-slate-100 text-slate-500' : 'bg-blue-50 text-blue-700'}`}>
            {isBirthday ? <Cake className="w-3.5 h-3.5 text-amber-600" aria-hidden /> : <User className="w-3.5 h-3.5" aria-hidden />}
          </span>
          <span className="flex-1 min-w-0 text-sm font-bold text-slate-800 truncate">{name}</span>
          <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" aria-hidden />
        </>
      }
    >
      {(close) => <CustomerPanel customer={customer} onSelect={(c) => { onSelect(c); close(); }} />}
    </Popover>
  );
}

function CustomerPanel({ customer, onSelect }: { customer: any | null; onSelect: (c: any) => void }) {
  const [mode, setMode] = useState<'search' | 'create'>('search');
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [searching, setSearching] = useState(false);
  const [form, setForm] = useState({ name: '', nit: '', phone: '', birthDate: '' });
  const [saving, setSaving] = useState(false);
  const searchRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    searchRef.current?.focus();
  }, [mode]);

  // Búsqueda y carga inmediata de clientes registrados
  useEffect(() => {
    let cancelled = false;
    const q = query.trim();
    setSearching(true);
    if (q.length < 2) {
      customersAPI.getAll()
        .then((all: any[]) => {
          if (!cancelled) {
            setResults(Array.isArray(all) ? all.filter((c) => !c.isDefault) : []);
          }
        })
        .catch((e) => {
          console.error('Error fetching initial customers:', e);
          if (!cancelled) setResults([]);
        })
        .finally(() => {
          if (!cancelled) setSearching(false);
        });
      return () => { cancelled = true; };
    }
    const timer = setTimeout(async () => {
      try {
        const found = await customersAPI.search(q);
        if (!cancelled) setResults(Array.isArray(found) ? found.filter((c) => !c.isDefault) : []);
      } catch (e) {
        if (!cancelled) toast.error(errorMessage(e));
      } finally {
        if (!cancelled) setSearching(false);
      }
    }, 200);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [query]);

  const register = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim()) {
      toast.warning(t('pos:el_nombre_es_obligatorio'));
      return;
    }
    setSaving(true);
    try {
      const created = await customersAPI.create({
        name: form.name.trim(),
        nit: form.nit.trim() || undefined,
        phone: form.phone.trim() || undefined,
        birthDate: form.birthDate || undefined,
      });
      toast.success(t('pos:cliente_registrado_y_seleccionado'));
      onSelect(created);
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const resetToDefault = async () => {
    try {
      onSelect(await customersAPI.getDefault());
    } catch (e) {
      toast.error(errorMessage(e));
    }
  };

  if (mode === 'create') {
    return (
      <form onSubmit={register} className="p-4 space-y-3">
        <p className="text-sm font-bold text-slate-900">{t('pos:registrar_cliente')}</p>
        <div>
          <label htmlFor="cp-name" className="block text-xs font-bold text-slate-600 mb-1">{t('pos:nombre')}</label>
          <input id="cp-name" ref={searchRef} className={inputClass} value={form.name} maxLength={120} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder={t('pos:ej_juan_perez')} />
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div>
            <label htmlFor="cp-nit" className="block text-xs font-bold text-slate-600 mb-1">{t('pos:nit_cc')}</label>
            <input id="cp-nit" className={inputClass} value={form.nit} maxLength={20} onChange={(e) => setForm({ ...form, nit: e.target.value })} />
          </div>
          <div>
            <label htmlFor="cp-phone" className="block text-xs font-bold text-slate-600 mb-1">{t('pos:telefono')}</label>
            <input id="cp-phone" className={inputClass} value={form.phone} maxLength={30} inputMode="tel" onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          </div>
        </div>
        <div>
          <label htmlFor="cp-bday" className="block text-xs font-bold text-slate-600 mb-1">{t('pos:fecha_cumpleanos')}</label>
          <input id="cp-bday" type="date" className={inputClass} value={form.birthDate} onChange={(e) => setForm({ ...form, birthDate: e.target.value })} />
        </div>
        <div className="flex gap-2 pt-1">
          <button type="button" onClick={() => setMode('search')} className="px-3 min-h-[40px] rounded-xl text-sm font-bold text-slate-600 hover:bg-slate-100">
            {t('pos:volver_a_buscar')}
          </button>
          <button type="submit" disabled={saving} className="flex-1 min-h-[40px] rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold disabled:opacity-60 inline-flex items-center justify-center gap-2">
            {saving && <Loader2 className="w-4 h-4 animate-spin" aria-hidden />}
            {t('pos:registrar_seleccionar')}
          </button>
        </div>
      </form>
    );
  }

  return (
    <div className="p-3 space-y-2">
      {customer && !customer.isDefault && (
        <div className="px-2 py-1.5 rounded-xl bg-slate-50 text-xs text-slate-600">
          <p className="font-bold text-slate-900 text-sm">{customer.name}</p>
          <p>{t('pos:nit_value', { value: customer.nit || t('pos:sin_nit') })}{customer.phone ? ` · ${customer.phone}` : ''}</p>
        </div>
      )}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" aria-hidden />
        <input
          ref={searchRef}
          className={`${inputClass} pl-9`}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={t('pos:buscar_por_nombre_nit_telefono')}
          aria-label={t('pos:buscar_cliente')}
        />
        {searching && <Loader2 className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 animate-spin" aria-hidden />}
      </div>

      {results.length > 0 && (
        <ul className="max-h-56 overflow-y-auto divide-y divide-slate-100 rounded-xl border border-slate-200">
          {results.map((c) => (
            <li key={c.id}>
              <button type="button" onClick={() => onSelect(c)} className="w-full text-left px-3 py-2 hover:bg-blue-50 flex items-center justify-between gap-2">
                <span className="min-w-0">
                  <span className="block text-sm font-bold text-slate-800 truncate">{c.name}</span>
                  <span className="block text-xs text-slate-500">{t('pos:nit_value', { value: c.nit || t('pos:sin_nit') })}</span>
                </span>
                {c.phone && <span className="text-xs text-slate-400 shrink-0">{c.phone}</span>}
              </button>
            </li>
          ))}
        </ul>
      )}
      {query.trim().length >= 2 && !searching && results.length === 0 && (
        <p className="text-center text-xs text-slate-500 py-2">{t('pos:no_se_encontraron_clientes')}</p>
      )}

      <div className="flex items-center justify-between gap-2 pt-1 border-t border-slate-100">
        <button type="button" onClick={() => setMode('create')} className="inline-flex items-center gap-1.5 px-2 min-h-[40px] rounded-lg text-sm font-bold text-blue-700 hover:bg-blue-50">
          <UserPlus className="w-4 h-4" aria-hidden />
          {t('pos:registrar_cliente')}
        </button>
        {customer && !customer.isDefault && (
          <button type="button" onClick={resetToDefault} className="inline-flex items-center gap-1.5 px-2 min-h-[40px] rounded-lg text-xs font-bold text-slate-500 hover:text-slate-800 hover:bg-slate-100">
            <RotateCcw className="w-3.5 h-3.5" aria-hidden />
            {t('pos:cliente_comun')}
          </button>
        )}
      </div>
    </div>
  );
}
