// ============================================
// CART - Ventana de cobro
// ============================================
// Resumen (impuestos incluidos y descuento) → propina voluntaria → medio de pago.
// Solo arma el pago; el registro de la venta lo hace el carrito.

import { useEffect, useMemo, useRef, useState } from 'react';
import { X, Banknote, CreditCard, Smartphone, Coins, Check, FileText, HeartHandshake, ChevronDown, Square, CheckSquare, Plus, Trash2 } from 'lucide-react';
import type { CartItem, Product } from '../../../types';
import type { BusinessSettings } from '../../../services/api';
import { computeCartTotals, suggestedTipFor, taxLineLabel, CartTotals } from '../../../shared/cartMath';
import { formatCurrency } from '../../../shared/formatUtils';
import { t } from '../../../i18n';
import { useFeature } from '../../../shared/plan';
import { couponsAPI } from '../../../services/api';
import { errorMessage } from '../../../services/apiErrors';
import { Ticket } from 'lucide-react';

export type PaymentMethod = 'CASH' | 'CARD' | 'TRANSFER' | 'MIXED';

export interface PaymentPayload {
  items: CartItem[];
  isPartial: boolean;
  totals: CartTotals;
  tip: number;
  paymentMethod: PaymentMethod;
  payments?: { method: 'CASH' | 'CARD' | 'TRANSFER'; amount: number }[];
  change: number;
  emitElectronicInvoice: boolean;
  /** Cupón aplicado: el servidor recalcula el descuento al cobrar */
  couponCode?: string;
}

interface PaymentModalProps {
  items: CartItem[];
  discountPct: number;
  products: Product[];
  business: BusinessSettings | null;
  placeLabel: string;
  isProcessing: boolean;
  /** El administrador ve dónde activar la propina si el negocio no la maneja */
  isAdmin?: boolean;
  onClose: () => void;
  onConfirm: (payload: PaymentPayload) => void;
}

type TipChoice = 'none' | 'suggested' | 'custom';

const METHODS: { id: PaymentMethod; icon: typeof Banknote; key: string }[] = [
  { id: 'CASH', icon: Banknote, key: 'pos:efectivo' },
  { id: 'CARD', icon: CreditCard, key: 'pos:tarjeta' },
  { id: 'TRANSFER', icon: Smartphone, key: 'pos:transfer' },
  { id: 'MIXED', icon: Coins, key: 'pos:combinado' },
];

type PartMethod = 'CASH' | 'CARD' | 'TRANSFER';
type PayLine = { id: number; method: PartMethod; amount: string };
const PART_KEYS: Record<PartMethod, string> = { CASH: 'pos:efectivo', CARD: 'pos:tarjeta', TRANSFER: 'pos:transfer' };

/** Lo que queda en caja de cada pago: el cambio se descuenta una sola vez, del último efectivo hacia atrás */
export function netPayments(payments: { method: PartMethod; amount: number }[] | undefined, change: number) {
  if (!payments) return undefined;
  let left = Math.max(0, change);
  const out = payments.map((p) => ({ ...p }));
  for (let i = out.length - 1; i >= 0 && left > 0; i--) {
    if (out[i].method !== 'CASH') continue;
    const take = Math.min(out[i].amount, left);
    out[i].amount -= take;
    left -= take;
  }
  return out.filter((p) => p.amount > 0);
}

const num = (v: string) => Math.max(0, Number(v.replace(/[^0-9]/g, '')) || 0);
const moneyInput =
  'w-full pl-7 pr-3 py-2.5 text-base font-bold tabular-nums border border-slate-300 rounded-xl bg-white focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20';

export function PaymentModal({ items, discountPct, products, business, placeLabel, isProcessing, isAdmin, onClose, onConfirm }: PaymentModalProps) {
  const [method, setMethod] = useState<PaymentMethod>('CASH');
  const [cash, setCash] = useState('');
  // Varios pagos: cada línea es un pago (pueden ser varias transferencias) y se van sumando
  const [lines, setLines] = useState<PayLine[]>([{ id: 1, method: 'TRANSFER', amount: '' }]);
  const [isPartial, setIsPartial] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(() => new Set(items.map((i) => i.id)));
  const [tipChoice, setTipChoice] = useState<TipChoice>('none');
  const [customTip, setCustomTip] = useState('');
  const [emitInvoice, setEmitInvoice] = useState(false);
  const cashRef = useRef<HTMLInputElement>(null);

  const tipEnabled = !!business?.tipEnabled;
  const tipPercent = business?.tipPercent ?? 10;
  // Factura electrónica: el negocio la usa y su plan la incluye
  const hasDian = useFeature('dian');
  const offersInvoice = hasDian && (business ? business.wantsElectronicInvoice : true);

  const payItems = isPartial ? items.filter((i) => selected.has(i.id)) : items;

  // ── Cupón (reemplaza el descuento manual; lo valida el servidor) ──
  const hasCoupons = useFeature('coupons');
  const [couponOpen, setCouponOpen] = useState(false);
  const [couponInput, setCouponInput] = useState('');
  const [coupon, setCoupon] = useState<{ code: string; type: string; value: number; discount: number } | null>(null);
  const [couponError, setCouponError] = useState('');
  const [couponBusy, setCouponBusy] = useState(false);
  const gross = useMemo(() => computeCartTotals(payItems, 0, products, business).subtotal, [payItems, products, business]);
  const applyCoupon = async (code: string) => {
    if (!code.trim()) return;
    setCouponBusy(true);
    setCouponError('');
    try {
      setCoupon(await couponsAPI.validate(code.trim(), gross));
    } catch (e) {
      setCoupon(null);
      setCouponError(errorMessage(e));
    } finally {
      setCouponBusy(false);
    }
  };
  // Si cambian los productos a pagar, el cupón se vuelve a validar con el nuevo subtotal
  useEffect(() => {
    if (coupon) applyCoupon(coupon.code);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gross]);
  const effectivePct = coupon ? (coupon.type === 'PERCENT' ? coupon.value : gross > 0 ? (coupon.discount / gross) * 100 : 0) : discountPct;
  const totals = useMemo(() => computeCartTotals(payItems, effectivePct, products, business), [payItems, effectivePct, products, business]);
  const suggestedTip = suggestedTipFor(totals.total, tipPercent);
  const tip = !tipEnabled ? 0 : tipChoice === 'suggested' ? suggestedTip : tipChoice === 'custom' ? num(customTip) : 0;
  const tipTooHigh = tip > totals.total;
  const chargeTotal = totals.total + tip;

  const mixedPaid = lines.reduce((sum, l) => sum + num(l.amount), 0);
  const mixedCash = lines.reduce((sum, l) => sum + (l.method === 'CASH' ? num(l.amount) : 0), 0);
  // El cambio solo sale del efectivo: lo que sobra de tarjeta o transferencia no se devuelve
  const change = method === 'CASH'
    ? Math.max(0, num(cash) - chargeTotal)
    : method === 'MIXED'
      ? Math.min(mixedCash, Math.max(0, mixedPaid - chargeTotal))
      : 0;
  const overpaidNoCash = method === 'MIXED' && mixedPaid - chargeTotal > change + 0.5;
  const addLine = () => {
    const last = lines[lines.length - 1];
    const rest = Math.max(0, chargeTotal - mixedPaid);
    setLines([...lines, { id: Date.now(), method: last?.method ?? 'TRANSFER', amount: rest > 0 ? String(Math.round(rest)) : '' }]);
  };
  const setLine = (id: number, patch: Partial<PayLine>) => setLines(lines.map((l) => (l.id === id ? { ...l, ...patch } : l)));
  const removeLine = (id: number) => setLines(lines.length > 1 ? lines.filter((l) => l.id !== id) : lines);
  const missing = method === 'CASH' ? Math.max(0, chargeTotal - num(cash)) : method === 'MIXED' ? Math.max(0, chargeTotal - mixedPaid) : 0;
  const canConfirm = payItems.length > 0 && !tipTooHigh && missing === 0 && !overpaidNoCash && !isProcessing;

  useEffect(() => {
    if (method === 'CASH') cashRef.current?.focus();
  }, [method]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !isProcessing) onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [isProcessing, onClose]);

  const confirm = () => {
    if (!canConfirm) return;
    onConfirm({
      items: payItems,
      isPartial: isPartial && payItems.length < items.length,
      totals,
      tip,
      paymentMethod: method,
      payments: method === 'MIXED'
        ? lines.map((l) => ({ method: l.method, amount: num(l.amount) })).filter((p) => p.amount > 0)
        : undefined,
      change,
      emitElectronicInvoice: offersInvoice && emitInvoice,
      couponCode: coupon?.code,
    });
  };

  // Billetes más útiles según el total
  const quickCash = useMemo(() => {
    const options = new Set<number>([chargeTotal]);
    for (const step of [10000, 20000, 50000, 100000]) options.add(Math.ceil(chargeTotal / step) * step);
    return Array.from(options).filter((v) => v > 0).sort((a, b) => a - b).slice(0, 4);
  }, [chargeTotal]);

  const toggleItem = (id: string) => {
    const next = new Set(selected);
    next.has(id) ? next.delete(id) : next.add(id);
    setSelected(next);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-3 sm:p-4" role="presentation">
      <div role="dialog" aria-modal="true" aria-labelledby="payment-title" className="bg-white rounded-3xl w-full max-w-lg max-h-[94vh] flex flex-col shadow-2xl overflow-hidden">
        <header className="flex items-center justify-between px-5 py-4 border-b border-slate-200">
          <div>
            <h3 id="payment-title" className="text-lg font-bold text-slate-900 font-heading">{t('pos:cobrar')}</h3>
            <p className="text-xs text-slate-500">{placeLabel}</p>
          </div>
          <button type="button" onClick={onClose} disabled={isProcessing} aria-label={t('pos:cerrar')} className="w-10 h-10 rounded-xl hover:bg-slate-100 flex items-center justify-center text-slate-500">
            <X className="w-5 h-5" aria-hidden />
          </button>
        </header>

        <div className="flex-1 min-h-0 overflow-y-auto px-5 py-4 space-y-5">
          {/* Resumen de la cuenta */}
          <section className="rounded-2xl bg-slate-50 border border-slate-200 p-4 space-y-1.5 text-sm">
            <div className="flex justify-between text-slate-600">
              <span>{t('pos:subtotal_n_productos', { count: totals.units })}</span>
              <span className="tabular-nums">{formatCurrency(totals.subtotal)}</span>
            </div>
            {totals.discount > 0 && (
              <div className="flex justify-between text-emerald-700 font-semibold">
                <span>{coupon ? t('pos:cupon_aplicado', { code: coupon.code }) : t('pos:descuento_value', { value: discountPct })}</span>
                <span className="tabular-nums">-{formatCurrency(totals.discount)}</span>
              </div>
            )}
            <div className="flex justify-between font-bold text-slate-900 pt-1.5 border-t border-slate-200">
              <span>{t('pos:total_venta')}</span>
              <span className="tabular-nums">{formatCurrency(totals.total)}</span>
            </div>
            {totals.taxLines.map((l) => (
              <div key={`${l.taxType}${l.taxRate}`} className="flex justify-between text-xs text-slate-500">
                <span>{t('pos:incluye_tax', { tax: taxLineLabel(l, { iva: t('pos:iva'), inc: t('pos:impoconsumo') }) })}</span>
                <span className="tabular-nums">{formatCurrency(l.amount)}</span>
              </div>
            ))}
          </section>

          {/* Cupón */}
          {hasCoupons && (
            <section>
              {coupon ? (
                <div className="flex items-center justify-between gap-3 rounded-xl border border-emerald-200 bg-emerald-50 px-3 py-2.5 text-sm">
                  <span className="flex items-center gap-2 font-bold text-emerald-800">
                    <Ticket className="w-4 h-4" aria-hidden /> {coupon.code} · -{formatCurrency(coupon.discount)}
                  </span>
                  <button type="button" onClick={() => { setCoupon(null); setCouponInput(''); }} className="text-xs font-bold text-emerald-800 underline">
                    {t('pos:quitar_cupon')}
                  </button>
                </div>
              ) : couponOpen ? (
                <div className="space-y-1.5">
                  <div className="flex gap-2">
                    <input
                      value={couponInput}
                      onChange={(e) => setCouponInput(e.target.value.toUpperCase())}
                      onKeyDown={(e) => e.key === 'Enter' && applyCoupon(couponInput)}
                      placeholder={t('pos:codigo_del_cupon')}
                      aria-label={t('pos:codigo_del_cupon')}
                      autoFocus
                      className="flex-1 min-h-[44px] px-3 rounded-xl border border-slate-300 font-bold tracking-wide uppercase focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20"
                    />
                    <button type="button" onClick={() => applyCoupon(couponInput)} disabled={couponBusy || !couponInput.trim()} className="min-h-[44px] px-4 rounded-xl bg-slate-900 text-white text-sm font-bold disabled:opacity-50">
                      {t('pos:aplicar')}
                    </button>
                  </div>
                  {couponError && <p role="alert" className="text-xs font-semibold text-rose-700">{couponError}</p>}
                  {discountPct > 0 && <p className="text-xs text-slate-500">{t('pos:cupon_reemplaza_descuento')}</p>}
                </div>
              ) : (
                <button type="button" onClick={() => setCouponOpen(true)} className="inline-flex items-center gap-1.5 min-h-[36px] text-sm font-bold text-blue-700 hover:underline">
                  <Ticket className="w-4 h-4" aria-hidden /> {t('pos:tienes_cupon')}
                </button>
              )}
            </section>
          )}

          {/* Pagar solo algunos productos */}
          {items.length > 1 && (
            <section>
              <button
                type="button"
                onClick={() => { setIsPartial(!isPartial); setSelected(new Set(items.map((i) => i.id))); }}
                aria-expanded={isPartial}
                className="w-full flex items-center justify-between text-sm font-bold text-slate-700 min-h-[40px]"
              >
                <span>{t('pos:pagar_solo_algunos_productos')}</span>
                <ChevronDown className={`w-4 h-4 transition-transform ${isPartial ? 'rotate-180' : ''}`} aria-hidden />
              </button>
              {isPartial && (
                <ul className="mt-1 space-y-1 max-h-44 overflow-y-auto">
                  {items.map((item) => {
                    const on = selected.has(item.id);
                    return (
                      <li key={item.id}>
                        <button
                          type="button"
                          role="checkbox"
                          aria-checked={on}
                          onClick={() => toggleItem(item.id)}
                          className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl border text-left ${on ? 'border-blue-500 bg-blue-50' : 'border-slate-200'}`}
                        >
                          {on ? <CheckSquare className="w-4 h-4 text-blue-600 shrink-0" aria-hidden /> : <Square className="w-4 h-4 text-slate-300 shrink-0" aria-hidden />}
                          <span className="flex-1 min-w-0 text-sm font-semibold text-slate-800 truncate">{item.quantity}× {item.productName}</span>
                          <span className="text-sm font-bold tabular-nums">{formatCurrency(item.total)}</span>
                        </button>
                      </li>
                    );
                  })}
                </ul>
              )}
            </section>
          )}

          {/* Propina voluntaria */}
          {tipEnabled && (
            <section aria-labelledby="tip-title">
              <div className="flex items-baseline justify-between gap-2 mb-2">
                <h4 id="tip-title" className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                  <HeartHandshake className="w-4 h-4 text-amber-600" aria-hidden />
                  {t('pos:desea_agregar_propina')}
                </h4>
                <span className="text-xs text-slate-500">{t('pos:es_voluntaria')}</span>
              </div>
              <div role="radiogroup" aria-labelledby="tip-title" className="grid grid-cols-3 gap-2">
                {([
                  { id: 'none', label: t('pos:sin_propina'), amount: 0 },
                  { id: 'suggested', label: t('pos:sugerida_pct', { pct: tipPercent }), amount: suggestedTip },
                  { id: 'custom', label: t('pos:otro_valor'), amount: null },
                ] as { id: TipChoice; label: string; amount: number | null }[]).map((o) => (
                  <button
                    key={o.id}
                    type="button"
                    role="radio"
                    aria-checked={tipChoice === o.id}
                    onClick={() => setTipChoice(o.id)}
                    className={`min-h-[56px] px-2 rounded-xl border-2 text-center transition-colors ${
                      tipChoice === o.id ? 'border-amber-500 bg-amber-50 text-amber-900' : 'border-slate-200 text-slate-600 hover:border-slate-300'
                    }`}
                  >
                    <span className="block text-xs font-bold">{o.label}</span>
                    {o.amount !== null && <span className="block text-sm font-black tabular-nums">{formatCurrency(o.amount)}</span>}
                  </button>
                ))}
              </div>
              {tipChoice === 'custom' && (
                <div className="mt-2">
                  <label htmlFor="tip-custom" className="sr-only">{t('pos:valor_de_la_propina')}</label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-bold">$</span>
                    <input
                      id="tip-custom"
                      inputMode="numeric"
                      autoFocus
                      value={customTip}
                      onChange={(e) => setCustomTip(e.target.value.replace(/[^0-9]/g, ''))}
                      placeholder={t('pos:valor_de_la_propina')}
                      className={moneyInput}
                    />
                  </div>
                  {tipTooHigh && <p className="mt-1 text-xs font-semibold text-rose-700">{t('pos:la_propina_no_puede_superar_el_total')}</p>}
                </div>
              )}
            </section>
          )}

          {!tipEnabled && isAdmin && (
            <p className="text-xs text-slate-500 leading-relaxed">{t('pos:propina_desactivada_hint')}</p>
          )}

          {/* Medio de pago */}
          <section>
            <h4 className="text-sm font-bold text-slate-900 mb-2">{t('pos:metodo_de_pago')}</h4>
            <div role="radiogroup" aria-label={t('pos:metodo_de_pago')} className="grid grid-cols-4 gap-2">
              {METHODS.map(({ id, icon: Icon, key }) => (
                <button
                  key={id}
                  type="button"
                  role="radio"
                  aria-checked={method === id}
                  onClick={() => setMethod(id)}
                  className={`min-h-[60px] rounded-xl border-2 flex flex-col items-center justify-center gap-1 text-xs font-bold transition-colors ${
                    method === id ? 'border-blue-600 bg-blue-50 text-blue-800' : 'border-slate-200 text-slate-600 hover:border-slate-300'
                  }`}
                >
                  <Icon className="w-5 h-5" aria-hidden />
                  {t(key)}
                </button>
              ))}
            </div>

            {method === 'CASH' && (
              <div className="mt-3 space-y-2">
                <label htmlFor="cash-received" className="block text-xs font-bold text-slate-600">{t('pos:efectivo_recibido')}</label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-bold">$</span>
                  <input
                    id="cash-received"
                    ref={cashRef}
                    inputMode="numeric"
                    value={cash}
                    onChange={(e) => setCash(e.target.value.replace(/[^0-9]/g, ''))}
                    onKeyDown={(e) => { if (e.key === 'Enter') confirm(); }}
                    placeholder="0"
                    className={moneyInput}
                  />
                </div>
                <div className="grid grid-cols-4 gap-2">
                  {quickCash.map((amount, idx) => (
                    <button
                      key={amount}
                      type="button"
                      onClick={() => setCash(String(amount))}
                      className="min-h-[40px] rounded-xl bg-slate-100 hover:bg-slate-200 text-xs font-bold text-slate-700 tabular-nums"
                    >
                      {idx === 0 && amount === chargeTotal ? t('pos:exacto') : formatCurrency(amount)}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {method === 'MIXED' && (
              <div className="mt-3 space-y-2">
                {lines.map((line, idx) => (
                  <div key={line.id} className="flex items-center gap-2">
                    <span className="w-5 shrink-0 text-xs font-bold text-slate-400 tabular-nums">{idx + 1}.</span>
                    <div role="radiogroup" aria-label={t('pos:pago_n', { n: idx + 1 })} className="flex shrink-0 rounded-xl border border-slate-200 p-0.5">
                      {(['CASH', 'CARD', 'TRANSFER'] as const).map((m) => {
                        const Icon = m === 'CASH' ? Banknote : m === 'CARD' ? CreditCard : Smartphone;
                        return (
                          <button
                            key={m}
                            type="button"
                            role="radio"
                            aria-checked={line.method === m}
                            title={t(PART_KEYS[m])}
                            aria-label={t(PART_KEYS[m])}
                            onClick={() => setLine(line.id, { method: m })}
                            className={`h-9 w-10 rounded-lg flex items-center justify-center ${line.method === m ? 'bg-blue-600 text-white' : 'text-slate-500 hover:bg-slate-100'}`}
                          >
                            <Icon className="w-4 h-4" aria-hidden />
                          </button>
                        );
                      })}
                    </div>
                    <div className="relative flex-1 min-w-0">
                      <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 text-sm font-bold">$</span>
                      <input
                        aria-label={t('pos:monto_del_pago_n', { n: idx + 1 })}
                        inputMode="numeric"
                        value={line.amount}
                        autoFocus={idx > 0 && idx === lines.length - 1}
                        onChange={(e) => setLine(line.id, { amount: e.target.value.replace(/[^0-9]/g, '') })}
                        onKeyDown={(e) => { if (e.key === 'Enter') { if (missing > 0) addLine(); else confirm(); } }}
                        placeholder="0"
                        className="w-full pl-6 pr-2 py-2 text-sm font-bold tabular-nums border border-slate-300 rounded-xl focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => removeLine(line.id)}
                      disabled={lines.length === 1}
                      aria-label={t('pos:quitar_pago_n', { n: idx + 1 })}
                      className="h-9 w-9 shrink-0 rounded-lg flex items-center justify-center text-slate-400 hover:text-rose-600 hover:bg-rose-50 disabled:opacity-30 disabled:hover:bg-transparent disabled:hover:text-slate-400"
                    >
                      <Trash2 className="w-4 h-4" aria-hidden />
                    </button>
                  </div>
                ))}
                <div className="flex items-center justify-between gap-2 pt-1">
                  <button
                    type="button"
                    onClick={addLine}
                    className="min-h-[40px] px-3 rounded-xl border-2 border-dashed border-slate-300 text-sm font-bold text-slate-600 hover:border-blue-400 hover:text-blue-700 flex items-center gap-1.5"
                  >
                    <Plus className="w-4 h-4" aria-hidden /> {t('pos:agregar_pago')}
                  </button>
                  <span className="text-xs font-bold text-slate-500 tabular-nums">
                    {t('pos:pagado_de', { paid: formatCurrency(mixedPaid), total: formatCurrency(chargeTotal) })}
                  </span>
                </div>
                {overpaidNoCash && (
                  <p className="px-3 py-2 rounded-xl text-sm font-bold bg-amber-50 text-amber-800">{t('pos:pagos_superan_total')}</p>
                )}
              </div>
            )}

            {(method === 'CASH' || method === 'MIXED') && (missing > 0 || change > 0) && (
              <p className={`mt-2 px-3 py-2 rounded-xl text-sm font-bold flex justify-between ${missing > 0 ? 'bg-rose-50 text-rose-700' : 'bg-emerald-50 text-emerald-800'}`}>
                <span>{missing > 0 ? t('pos:falta_por_pagar') : t('pos:cambio')}</span>
                <span className="tabular-nums">{formatCurrency(missing > 0 ? missing : change)}</span>
              </p>
            )}
          </section>

          {offersInvoice && (
            <label htmlFor="emit-invoice" className="flex items-start gap-3 p-3 rounded-2xl border border-slate-200 cursor-pointer hover:border-slate-300">
              <input id="emit-invoice" type="checkbox" checked={emitInvoice} onChange={(e) => setEmitInvoice(e.target.checked)} className="mt-0.5 w-5 h-5 accent-blue-600" />
              <span>
                <span className="flex items-center gap-1.5 text-sm font-bold text-slate-900">
                  <FileText className="w-4 h-4 text-blue-600" aria-hidden />
                  {t('pos:factura_electronica_dian')}
                </span>
                <span className="block text-xs text-slate-500 mt-0.5">{t('pos:se_imprime_la_factura_electronica')}</span>
              </span>
            </label>
          )}
        </div>

        <footer className="border-t border-slate-200 px-5 py-4 bg-white">
          {tip > 0 && (
            <div className="flex justify-between text-xs text-slate-500 mb-2">
              <span>{t('pos:venta_mas_propina', { sale: formatCurrency(totals.total), tip: formatCurrency(tip) })}</span>
            </div>
          )}
          <button
            type="button"
            onClick={confirm}
            disabled={!canConfirm}
            className="w-full min-h-[52px] rounded-2xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-base shadow-sm disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {isProcessing ? (
              <span className="w-5 h-5 border-2 border-white/40 border-t-white rounded-full animate-spin" aria-hidden />
            ) : (
              <Check className="w-5 h-5" aria-hidden />
            )}
            <span>{t('pos:confirmar_pago')}</span>
            <span className="tabular-nums">{formatCurrency(chargeTotal)}</span>
          </button>
        </footer>
      </div>
    </div>
  );
}
