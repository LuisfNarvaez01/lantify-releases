// ============================================
// COMPONENTS - Registro de propinas (ADMIN)
// ============================================
// La propina es del equipo: aquí se ve cuánto entró por turno de caja, por mes,
// por mesero y en total, y se puede descargar el detalle.

import { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, Download, HeartHandshake, RefreshCw } from 'lucide-react';
import { tipsAPI, TipsReportData } from '../../services/api';
import { errorMessage } from '../../services/apiErrors';
import { formatCurrency } from '../../shared/formatUtils';
import { t, getLocale } from '../../i18n';

type Period = 'month' | 'prev' | 'd90' | 'all';
type View = 'session' | 'month' | 'waiter' | 'log';

const rangeFor = (period: Period): { from?: string; to?: string } => {
  const now = new Date();
  if (period === 'month') return { from: new Date(now.getFullYear(), now.getMonth(), 1).toISOString() };
  if (period === 'prev') {
    return {
      from: new Date(now.getFullYear(), now.getMonth() - 1, 1).toISOString(),
      to: new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59).toISOString(),
    };
  }
  if (period === 'd90') return { from: new Date(Date.now() - 90 * 86400000).toISOString() };
  return {};
};

const monthLabel = (key: string) => {
  const [y, m] = key.split('-').map(Number);
  const label = new Date(y, m - 1, 1).toLocaleDateString(getLocale(), { month: 'long', year: 'numeric' });
  return label.charAt(0).toUpperCase() + label.slice(1);
};

const dateTime = (iso: string | null) =>
  iso ? new Date(iso).toLocaleString(getLocale(), { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : '—';

/** CSV con punto y coma y BOM: Excel en español lo abre bien */
const downloadCsv = (rows: TipsReportData['recent']) => {
  const cell = (v: unknown) => {
    const s = v === null || v === undefined ? '' : String(v);
    return /[";\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const header = ['fecha', 'venta', 'mesa', 'atendio', 'cobro', 'total_cuenta', 'propina', 'efectivo'];
  const lines = rows.map((r) => [r.createdAt, r.saleNumber, r.table ?? '', r.waiterName ?? '', r.cashierName ?? '', r.total, r.tip, r.cash ? 'si' : 'no']);
  const csv = '﻿' + [header, ...lines].map((l) => l.map(cell).join(';')).join('\r\n');
  const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
  const a = document.createElement('a');
  a.href = url;
  a.download = `lantify-propinas-${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
};

function Stat({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4">
      <p className="text-xs font-semibold text-slate-500">{label}</p>
      <p className="mt-1 text-2xl font-black tabular-nums text-slate-900">{value}</p>
      {hint && <p className="mt-0.5 text-xs text-slate-500">{hint}</p>}
    </div>
  );
}

export function TipsReport({ onClose }: { onClose: () => void }) {
  const [period, setPeriod] = useState<Period>('month');
  const [view, setView] = useState<View>('session');
  const [data, setData] = useState<TipsReportData | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  const load = async (p = period) => {
    setLoading(true);
    setError('');
    try {
      const r = rangeFor(p);
      setData(await tipsAPI.report(r.from, r.to));
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load(period);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [period]);

  const maxWaiter = useMemo(() => Math.max(1, ...(data?.byWaiter.map((w) => w.total) || [1])), [data]);

  const periods: { id: Period; label: string }[] = [
    { id: 'month', label: t('tips:este_mes') },
    { id: 'prev', label: t('tips:mes_anterior') },
    { id: 'd90', label: t('tips:ultimos_90') },
    { id: 'all', label: t('tips:todo') },
  ];
  const views: { id: View; label: string }[] = [
    { id: 'session', label: t('tips:por_turno') },
    { id: 'month', label: t('tips:por_mes') },
    { id: 'waiter', label: t('tips:por_mesero') },
    { id: 'log', label: t('tips:registro') },
  ];

  const s = data?.summary;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <button type="button" onClick={onClose} className="p-2 rounded-xl hover:bg-slate-200/70 text-slate-600" aria-label={t('tips:volver')}>
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="flex items-center gap-2 text-xl font-black text-slate-900">
              <HeartHandshake className="w-5 h-5 text-emerald-600" aria-hidden /> {t('tips:titulo')}
            </h2>
            <p className="text-xs text-slate-500">{t('tips:bajada')}</p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex rounded-xl border border-slate-200 bg-white p-1" role="group" aria-label={t('tips:periodo')}>
            {periods.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => setPeriod(p.id)}
                aria-pressed={period === p.id}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold ${period === p.id ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'}`}
              >
                {p.label}
              </button>
            ))}
          </div>
          <button type="button" onClick={() => load()} className="p-2.5 rounded-xl border border-slate-200 bg-white text-slate-600 hover:bg-slate-50" aria-label={t('tips:actualizar')}>
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {data && !data.enabled && (
        <p className="rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">{t('tips:desactivadas')}</p>
      )}
      {error && <p role="alert" className="rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-800">{error}</p>}

      {s && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <Stat label={t('tips:total_periodo')} value={formatCurrency(s.total)} hint={t('tips:n_propinas', { count: s.count })} />
          <Stat label={t('tips:en_efectivo')} value={formatCurrency(s.cash)} hint={t('tips:en_efectivo_desc')} />
          <Stat label={t('tips:promedio')} value={`${s.avgPercent.toLocaleString(getLocale())} %`} hint={t('tips:ventas_con_propina', { pct: s.tipRate.toLocaleString(getLocale()) })} />
          <Stat label={t('tips:historico')} value={formatCurrency(data!.allTime.total)} hint={t('tips:n_propinas', { count: data!.allTime.count })} />
        </div>
      )}

      <div className="flex gap-1 border-b border-slate-200" role="tablist">
        {views.map((v) => (
          <button
            key={v.id}
            type="button"
            role="tab"
            aria-selected={view === v.id}
            onClick={() => setView(v.id)}
            className={`px-4 py-2.5 text-sm font-bold border-b-2 -mb-px ${view === v.id ? 'border-blue-600 text-blue-700' : 'border-transparent text-slate-500 hover:text-slate-800'}`}
          >
            {v.label}
          </button>
        ))}
        {view === 'log' && data && data.recent.length > 0 && (
          <button type="button" onClick={() => downloadCsv(data.recent)} className="ml-auto mb-1 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold text-slate-700 border border-slate-200 hover:bg-slate-50">
            <Download className="w-3.5 h-3.5" aria-hidden /> {t('tips:exportar')}
          </button>
        )}
      </div>

      {data && data.summary.count === 0 && <p className="py-10 text-center text-sm text-slate-500">{t('tips:sin_propinas')}</p>}

      {data && data.summary.count > 0 && view === 'session' && (
        <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white">
          <table className="w-full min-w-[34rem] text-sm">
            <thead className="bg-slate-50 text-xs text-slate-500">
              <tr>
                <th className="px-4 py-3 text-left font-semibold">{t('tips:turno')}</th>
                <th className="px-4 py-3 text-left font-semibold">{t('tips:horario')}</th>
                <th className="px-4 py-3 text-left font-semibold">{t('tips:quien')}</th>
                <th className="px-4 py-3 text-right font-semibold">{t('tips:en_efectivo')}</th>
                <th className="px-4 py-3 text-right font-semibold">{t('tips:propinas')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {data.bySession.filter((x) => x.count > 0).map((x) => (
                <tr key={x.id}>
                  <td className="px-4 py-3 font-semibold text-slate-800">{x.sessionNumber}</td>
                  <td className="px-4 py-3 text-slate-600">{dateTime(x.openedAt)} → {x.closedAt ? dateTime(x.closedAt) : t('tips:en_curso')}</td>
                  <td className="px-4 py-3 text-slate-600">{x.byWaiter.map((w) => `${w.name} ${formatCurrency(w.total)}`).join(' · ')}</td>
                  <td className="px-4 py-3 text-right tabular-nums text-slate-700">{formatCurrency(x.cash)}</td>
                  <td className="px-4 py-3 text-right tabular-nums font-bold text-slate-900">{formatCurrency(x.total)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {data && data.summary.count > 0 && view === 'month' && (
        <ul className="divide-y divide-slate-100 rounded-2xl border border-slate-200 bg-white">
          {data.byMonth.filter((m) => m.count > 0).map((m) => (
            <li key={m.month} className="flex flex-wrap items-baseline justify-between gap-3 px-4 py-3.5">
              <span className="font-semibold text-slate-800">{monthLabel(m.month)}</span>
              <span className="text-xs text-slate-500">
                {t('tips:n_propinas', { count: m.count })} · {t('tips:sobre_la_cuenta', { pct: m.avgPercent.toLocaleString(getLocale()) })}
              </span>
              <span className="tabular-nums font-bold text-slate-900">{formatCurrency(m.total)}</span>
            </li>
          ))}
        </ul>
      )}

      {data && data.summary.count > 0 && view === 'waiter' && (
        <ul className="space-y-3 rounded-2xl border border-slate-200 bg-white p-4">
          {data.byWaiter.map((w) => (
            <li key={w.name}>
              <div className="flex items-baseline justify-between gap-3 text-sm">
                <span className="font-semibold text-slate-800">{w.name}</span>
                <span className="tabular-nums font-bold text-slate-900">{formatCurrency(w.total)} <span className="font-normal text-slate-500">· {t('tips:n_propinas', { count: w.count })}</span></span>
              </div>
              <div className="mt-1.5 h-2 rounded-full bg-slate-100">
                <div className="h-2 rounded-full bg-emerald-500" style={{ width: `${(w.total / maxWaiter) * 100}%` }} />
              </div>
            </li>
          ))}
        </ul>
      )}

      {data && data.summary.count > 0 && view === 'log' && (
        <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white">
          <table className="w-full min-w-[40rem] text-sm">
            <thead className="bg-slate-50 text-xs text-slate-500">
              <tr>
                <th className="px-4 py-3 text-left font-semibold">{t('tips:fecha')}</th>
                <th className="px-4 py-3 text-left font-semibold">{t('tips:mesa')}</th>
                <th className="px-4 py-3 text-left font-semibold">{t('tips:atendio')}</th>
                <th className="px-4 py-3 text-right font-semibold">{t('tips:cuenta')}</th>
                <th className="px-4 py-3 text-right font-semibold">{t('tips:propina')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {data.recent.map((r) => (
                <tr key={r.id}>
                  <td className="px-4 py-2.5 text-slate-600">{dateTime(r.createdAt)}</td>
                  <td className="px-4 py-2.5 text-slate-600">{r.table ? `${t('tips:mesa')} ${r.table}` : t('tips:mostrador')}</td>
                  <td className="px-4 py-2.5 text-slate-700">{r.waiterName || t('tips:sin_asignar')}</td>
                  <td className="px-4 py-2.5 text-right tabular-nums text-slate-600">{formatCurrency(r.total)}</td>
                  <td className="px-4 py-2.5 text-right tabular-nums font-bold text-slate-900">
                    {formatCurrency(r.tip)}
                    {r.cash && <span className="ml-1.5 rounded bg-emerald-50 px-1.5 py-0.5 text-[0.7rem] font-semibold text-emerald-700">{t('tips:efectivo')}</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

/** Tarjeta del turno en la caja: cuánto apartar del cajón para el equipo */
export function SessionTipsCard({ sessionId, refreshKey }: { sessionId: string; refreshKey: number }) {
  const [data, setData] = useState<Awaited<ReturnType<typeof tipsAPI.session>> | null>(null);
  useEffect(() => {
    tipsAPI.session(sessionId).then(setData).catch(() => setData(null));
  }, [sessionId, refreshKey]);
  if (!data) return null;
  return (
    <div className="rounded-2xl border border-emerald-200 bg-emerald-50/60 p-4">
      <div className="flex items-baseline justify-between gap-3">
        <p className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-emerald-800">
          <HeartHandshake className="w-4 h-4" aria-hidden /> {t('tips:propinas_del_turno')}
        </p>
        <p className="text-xl font-black tabular-nums text-emerald-800">{formatCurrency(data.total)}</p>
      </div>
      {data.cash > 0 && <p className="mt-1 text-sm font-semibold text-emerald-900">{t('tips:apartar', { amount: formatCurrency(data.cash) })}</p>}
      {data.byWaiter.length > 0 && (
        <p className="mt-1 text-xs text-emerald-800/80">{data.byWaiter.map((w) => `${w.name} ${formatCurrency(w.total)}`).join(' · ')}</p>
      )}
    </div>
  );
}
