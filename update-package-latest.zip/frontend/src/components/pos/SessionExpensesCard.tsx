// ============================================
// CAJA - Gastos del turno
// ============================================
// Los gastos se registran arqueo a arqueo: con la foto de la factura (la IA la
// lee) o a mano. Todos quedan en este arqueo; solo los pagados con dinero del
// cajón descuentan del saldo esperado.

import { Camera, Plus, Receipt, Sparkles } from 'lucide-react';
import { useExpenseCapture } from '../expenses/ExpenseCapture';
import { LockBadge } from '../common/PlanLocked';
import { formatCurrency } from '../../shared/formatUtils';
import { t } from '../../i18n';

interface Props {
  /** Total de gastos del turno pagados por fuera del cajón (banco, tarjeta, Nequi) */
  outsideTotal: number;
  isAdmin: boolean;
  onSaved: () => void;
}

export function SessionExpensesCard({ outsideTotal, isAdmin, onSaved }: Props) {
  const { openCamera, openManual, elements, hasOcr, ai } = useExpenseCapture({ onSaved, canConsent: isAdmin });

  return (
    <div data-guide="cash-expenses" className="bg-white rounded-3xl p-5 border border-slate-200 space-y-4 shadow-sm">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="text-xs font-black text-slate-800 uppercase tracking-wider flex items-center gap-2">
            <Receipt className="w-4 h-4 text-rose-600" aria-hidden />
            <span>{t('expenses:gastos_del_turno')}</span>
          </h3>
          <p className="mt-1 text-xs text-slate-500">{t('expenses:gastos_del_turno_desc')}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <button
          type="button"
          onClick={openCamera}
          className="inline-flex items-center justify-center gap-2 min-h-[46px] px-3 rounded-2xl bg-violet-600 text-xs font-black text-white shadow-sm hover:bg-violet-700"
        >
          <Camera className="w-4 h-4" aria-hidden /> {t('expenses:foto_de_factura')}
          {!hasOcr && <LockBadge />}
        </button>
        <button
          type="button"
          onClick={openManual}
          className="inline-flex items-center justify-center gap-2 min-h-[46px] px-3 rounded-2xl border border-slate-200 bg-white text-xs font-black text-slate-700 hover:bg-slate-50"
        >
          <Plus className="w-4 h-4" aria-hidden /> {t('expenses:registrar_gasto')}
        </button>
      </div>

      {hasOcr && ai && (
        <p className="flex items-center gap-2 text-xs text-slate-500">
          <Sparkles className="w-3.5 h-3.5 text-violet-500 shrink-0" aria-hidden />
          {!ai.consent ? (isAdmin ? t('expenses:ia_sin_permiso') : t('expenses:ia_sin_permiso_caja')) : ai.expenseAutoRegister ? t('expenses:ia_automatico') : t('expenses:ia_revision')}
        </p>
      )}

      {outsideTotal > 0 && (
        <p className="rounded-xl bg-slate-50 border border-slate-200 px-3 py-2 text-xs text-slate-600">
          {t('expenses:fuera_del_cajon_turno', { amount: formatCurrency(outsideTotal) })}
        </p>
      )}

      {elements}
    </div>
  );
}
