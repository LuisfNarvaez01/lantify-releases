// ============================================
// POS - Abrir mesa: personas, descripción y cliente (Lantify 3.0)
// ============================================
// Ventana rápida al tocar una mesa libre (si la función está encendida). Un toque
// en el número de personas y "Abrir"; "Omitir" abre sin datos. También sirve para
// editar los detalles de una mesa ya abierta.

import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { Users, X } from 'lucide-react';
import { create } from 'zustand';
import { CustomerPicker } from './cart/CustomerPicker';
import { t } from '../../i18n';

export interface TableDetails { guests: number | null; label: string | null; customer: any | null }

interface DialogState {
  request: { tableNumber: string; initial: TableDetails; editing: boolean; resolve: (r: TableDetails | 'skip' | null) => void } | null;
  ask: (tableNumber: string, initial: TableDetails, editing?: boolean) => Promise<TableDetails | 'skip' | null>;
  close: (r: TableDetails | 'skip' | null) => void;
}

export const useOpenTableDialog = create<DialogState>((set, get) => ({
  request: null,
  ask: (tableNumber, initial, editing = false) => new Promise((resolve) => set({ request: { tableNumber, initial, editing, resolve } })),
  close: (r) => { get().request?.resolve(r); set({ request: null }); },
}));

const QUICK = [1, 2, 3, 4, 5, 6, 7, 8];

export function OpenTableDialog() {
  const { request, close } = useOpenTableDialog();
  const [guests, setGuests] = useState<number | null>(null);
  const [other, setOther] = useState('');
  const [label, setLabel] = useState('');
  const [customer, setCustomer] = useState<any | null>(null);

  useEffect(() => {
    if (!request) return;
    const g = request.initial.guests;
    setGuests(g && g <= 8 ? g : null);
    setOther(g && g > 8 ? String(g) : '');
    setLabel(request.initial.label || '');
    setCustomer(request.initial.customer || null);
  }, [request]);

  if (!request) return null;
  const finalGuests = other ? Math.min(99, Math.max(1, Number(other) || 0)) || null : guests;
  const submit = () => close({ guests: finalGuests, label: label.trim() || null, customer });

  return createPortal(
    <div className="fixed inset-0 z-[95] flex items-end justify-center bg-slate-950/50 p-0 sm:items-center sm:p-4" role="presentation" onClick={(e) => { if (e.target === e.currentTarget) close(null); }}>
      <form
        role="dialog"
        aria-modal="true"
        aria-labelledby="open-table-title"
        onSubmit={(e) => { e.preventDefault(); submit(); }}
        className="w-full max-w-md rounded-t-3xl bg-white p-5 shadow-2xl sm:rounded-3xl"
      >
        <div className="flex items-start justify-between gap-3">
          <h2 id="open-table-title" className="text-lg font-black text-slate-900">{request.editing ? t('v3:mesa_detalles_titulo', { number: request.tableNumber }) : t('v3:abrir_mesa_titulo', { number: request.tableNumber })}</h2>
          <button type="button" onClick={() => close(null)} className="rounded-xl p-2 text-slate-400 hover:bg-slate-100" aria-label={t('pos:cerrar')}><X className="h-5 w-5" /></button>
        </div>

        <fieldset className="mt-4">
          <legend className="flex items-center gap-1.5 text-xs font-bold text-slate-700"><Users className="h-4 w-4" aria-hidden />{t('v3:personas')}</legend>
          <div className="mt-2 grid grid-cols-4 gap-2 sm:grid-cols-8">
            {QUICK.map((n) => (
              <button key={n} type="button" aria-pressed={guests === n && !other} onClick={() => { setGuests(guests === n && !other ? null : n); setOther(''); }} className={`min-h-[48px] rounded-xl border-2 text-lg font-black tabular-nums ${guests === n && !other ? 'border-blue-600 bg-blue-600 text-white' : 'border-slate-200 bg-white text-slate-800 hover:border-slate-400'}`}>
                {n}
              </button>
            ))}
          </div>
          <label className="mt-2 flex items-center gap-2 text-xs text-slate-600">
            {t('v3:personas_otro')}
            <input type="number" inputMode="numeric" min={1} max={99} value={other} onChange={(e) => setOther(e.target.value)} className="w-20 rounded-lg border border-slate-300 px-2 py-1.5 text-sm tabular-nums" />
          </label>
        </fieldset>

        <label className="mt-4 block space-y-1 text-xs font-bold text-slate-700">
          {t('v3:descripcion_mesa')}
          <input value={label} maxLength={80} onChange={(e) => setLabel(e.target.value)} placeholder={t('v3:descripcion_mesa_ej')} className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm font-normal" />
        </label>

        <div className="mt-4 space-y-1">
          <p className="text-xs font-bold text-slate-700">{t('v3:cliente')}</p>
          <CustomerPicker customer={customer} onSelect={setCustomer} />
        </div>

        <div className="mt-5 flex gap-2">
          {!request.editing && <button type="button" onClick={() => close('skip')} className="min-h-[52px] rounded-2xl px-5 text-sm font-bold text-slate-600 hover:bg-slate-100">{t('v3:omitir')}</button>}
          <button type="submit" className="min-h-[52px] flex-1 rounded-2xl bg-blue-700 text-base font-black text-white hover:bg-blue-800">{request.editing ? t('v3:guardar') : t('v3:abrir_mesa')}</button>
        </div>
      </form>
    </div>,
    document.body,
  );
}
