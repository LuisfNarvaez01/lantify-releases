// ============================================
// VENTAS → Propinas (Fase 4 · mejoras)
// ============================================
// Antes las propinas estaban en tres lugares: Datos del negocio (encender y el %
// sugerido), Usuarios → Funciones (reglas del reparto) y Personal → Propinas
// (repartir y pagar), además del registro en la Caja. Ahora todo vive aquí:
//   · Interruptor general y % sugerido.
//   · Estadísticas: por turno, por mes, por mesero y el registro.
//   · Reparto (se activa aparte): reglas por grupo, el reparto del periodo y pagos.

import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { BarChart3, Check, Coins, HeartHandshake, Settings2 } from 'lucide-react';
import { t, getLocale } from '../../i18n';
import { toast } from '../../shared/toast';
import { errorMessage } from '../../services/apiErrors';
import { businessAPI } from '../../services/api';
import { featuresAPI, staffAPI, type TipPreview, type TipSplit } from '../../services/v3Api';
import { useBusiness, useBusinessStore } from '../../shared/business';
import { STAFF_GROUPS, useFeatures } from '../../shared/features';
import { formatCurrency } from '../../shared/formatUtils';
import { Toggle } from '../common/Choice';
import { Button } from '../common/Button';
import { TipsReport } from './TipsReport';
import type { StaffGroup, TipRules } from '../../../../src/domain/v3/features';

type Sub = 'stats' | 'split' | 'rules';
const field = 'rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 min-h-[44px] focus:outline-none focus:ring-2 focus:ring-blue-500/40';
const card = 'bg-white rounded-3xl shadow-sm border border-slate-200/80';
const dayStr = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
const weekStart = () => { const d = new Date(); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return dayStr(d); };
const fromIso = (d: string) => new Date(`${d}T00:00:00`).toISOString();
const toIso = (d: string) => new Date(`${d}T23:59:59.999`).toISOString();

/** Reglas del reparto: % por grupo, cómo se reparte entre meseros y cada cuánto */
function RulesPanel() {
  const current = useFeatures((s) => s.settings.tips);
  const [tips, setTips] = useState<TipRules>(current);
  const [busy, setBusy] = useState(false);
  useEffect(() => setTips(current), [current]);
  const sum = STAFF_GROUPS.reduce((a, g) => a + (Number(tips.groups[g]) || 0), 0);
  const save = async () => {
    setBusy(true);
    try { await featuresAPI.save({ tips }); await useFeatures.getState().load(); toast.success(t('v3:guardado')); } catch (err) { toast.error(errorMessage(err)); } finally { setBusy(false); }
  };
  return (
    <section className={`${card} space-y-4 p-5`} aria-labelledby="tips-reglas">
      <div>
        <h3 id="tips-reglas" className="text-base font-bold text-slate-900">{t('tips:reglas_titulo')}</h3>
        <p className="text-sm text-slate-500">{t('tips:reglas_desc')}</p>
      </div>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-5">
        {STAFF_GROUPS.map((g: StaffGroup) => (
          <label key={g} className="block space-y-1 text-xs font-bold text-slate-700">
            {t(`v3:puesto_${g}`)}
            <span className="flex items-center gap-1">
              <input type="number" min={0} max={100} className={`${field} w-full`} value={tips.groups[g]} onChange={(e) => setTips({ ...tips, groups: { ...tips.groups, [g]: Math.max(0, Math.min(100, Number(e.target.value) || 0)) } })} />
              <span className="text-slate-500">%</span>
            </span>
          </label>
        ))}
      </div>
      {/* Barra que muestra cómo queda repartido el 100 % */}
      <div className="flex h-3 overflow-hidden rounded-full bg-slate-100" aria-hidden>
        {STAFF_GROUPS.filter((g) => tips.groups[g] > 0).map((g, i) => (
          <span key={g} className={['bg-blue-600', 'bg-emerald-500', 'bg-amber-400', 'bg-violet-500', 'bg-slate-400'][i % 5]} style={{ width: `${Math.min(100, tips.groups[g])}%`, transition: 'width .3s ease' }} />
        ))}
      </div>
      <p className={`text-xs font-semibold ${sum === 100 ? 'text-emerald-700' : 'text-rose-700'}`} role="status">{t('v3:suma_porcentajes', { suma: sum })}</p>
      <div className="grid gap-3 sm:grid-cols-2">
        <label className="block space-y-1 text-xs font-bold text-slate-700">
          {t('v3:entre_meseros')}
          <select className={`${field} w-full`} value={tips.waiterMode} onChange={(e) => setTips({ ...tips, waiterMode: e.target.value as TipRules['waiterMode'] })}>
            <option value="EQUAL">{t('v3:partes_iguales')}</option>
            <option value="CONTRIBUTION">{t('v3:segun_aporte')}</option>
          </select>
        </label>
        <label className="block space-y-1 text-xs font-bold text-slate-700">
          {t('v3:periodo_reparto')}
          <select className={`${field} w-full`} value={tips.period} onChange={(e) => setTips({ ...tips, period: e.target.value as TipRules['period'] })}>
            <option value="WEEK">{t('v3:periodo_WEEK')}</option>
            <option value="SESSION">{t('v3:periodo_SESSION')}</option>
            <option value="MONTH">{t('v3:periodo_MONTH')}</option>
          </select>
        </label>
      </div>
      <p className="rounded-2xl bg-slate-50 p-3 text-xs text-slate-600">{t('tips:reglas_ejemplo')}</p>
      <Button size="sm" disabled={sum !== 100} isLoading={busy} onClick={save}>{t('v3:guardar_reglas')}</Button>
    </section>
  );
}

/** Reparto del periodo: quién recibe cuánto, confirmar y marcar pagado */
function SplitPanel() {
  const periodType = useFeatures((s) => s.settings.tips.period);
  const [from, setFrom] = useState(weekStart());
  const [to, setTo] = useState(dayStr(new Date()));
  const [preview, setPreview] = useState<TipPreview | null>(null);
  const [amounts, setAmounts] = useState<Record<string, number>>({});
  const [splits, setSplits] = useState<TipSplit[]>([]);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const [p, s] = await Promise.all([staffAPI.tipPreview(fromIso(from), toIso(to)), staffAPI.tipSplits()]);
      setPreview(p); setSplits(s);
      setAmounts(Object.fromEntries(p.shares.map((x) => [x.employeeId, x.amount])));
    } catch (err) { toast.error(errorMessage(err)); }
  }, [from, to]);
  useEffect(() => { load(); }, [load]);

  const assigned = useMemo(() => Object.values(amounts).reduce((a, n) => a + (Number(n) || 0), 0), [amounts]);
  const left = (preview?.total || 0) - assigned;
  const confirm = async () => {
    if (!preview) return;
    setBusy(true);
    try {
      await staffAPI.confirmTips({ from: fromIso(from), to: toIso(to), periodType, shares: Object.entries(amounts).map(([employeeId, amount]) => ({ employeeId, amount: Number(amount) || 0 })) });
      toast.success(t('v3:reparto_confirmado'));
      await load();
    } catch (err) { toast.error(errorMessage(err)); } finally { setBusy(false); }
  };
  const act = async (fn: () => Promise<unknown>) => { try { await fn(); await load(); } catch (err) { toast.error(errorMessage(err)); } };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div className="flex flex-wrap items-end gap-3">
          <label className="block space-y-1 text-xs font-bold text-slate-700">{t('v3:desde_fecha')}<input type="date" className={`${field} block`} value={from} max={to} onChange={(e) => setFrom(e.target.value)} /></label>
          <label className="block space-y-1 text-xs font-bold text-slate-700">{t('v3:hasta_fecha')}<input type="date" className={`${field} block`} value={to} min={from} onChange={(e) => setTo(e.target.value)} /></label>
        </div>
        {preview && <p className="text-sm text-slate-700">{t('v3:propinas_del_periodo')} <strong className="text-lg tabular-nums text-slate-900">{formatCurrency(preview.total)}</strong></p>}
      </div>
      {preview?.alreadyConfirmed && <p className="rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-sm font-semibold text-emerald-900">{t('v3:periodo_ya_repartido')}</p>}
      {preview && !preview.alreadyConfirmed && preview.total <= 0 && <p className="rounded-2xl border border-slate-200 bg-slate-50 p-4 text-sm text-slate-700">{t('v3:sin_propinas')}</p>}
      {preview && !preview.alreadyConfirmed && preview.total > 0 && (
        <section className={`${card} space-y-4 p-5`}>
          <p className="text-sm text-slate-600">{t('v3:reparto_desc')}</p>
          <ul className="divide-y divide-slate-100">
            {preview.employees.map((e) => {
              const v = Number(amounts[e.id] ?? 0);
              return (
                <li key={e.id} className="flex items-center gap-3 py-2">
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-bold text-slate-900">{e.name}</span>
                    <span className="block text-xs text-slate-600">{t(`v3:puesto_${e.group}`)}</span>
                    <span className="mt-1 block h-1.5 overflow-hidden rounded-full bg-slate-100"><span className="block h-full rounded-full bg-emerald-500" style={{ width: `${preview.total ? Math.min(100, (v / preview.total) * 100) : 0}%`, transition: 'width .3s ease' }} /></span>
                  </span>
                  <input type="number" min={0} step={100} aria-label={t('v3:propina_de', { name: e.name })} className={`${field} w-36 text-right tabular-nums`} value={amounts[e.id] ?? 0} onChange={(ev) => setAmounts({ ...amounts, [e.id]: Math.max(0, Math.round(Number(ev.target.value) || 0)) })} />
                </li>
              );
            })}
          </ul>
          <p role="status" className={`text-sm font-bold ${left === 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
            {left === 0 ? t('v3:reparto_completo') : left > 0 ? t('v3:falta_asignar', { valor: formatCurrency(left) }) : t('v3:sobra_asignar', { valor: formatCurrency(-left) })}
          </p>
          {preview.unassigned.length > 0 && <p className="text-xs font-semibold text-amber-800">{t('v3:grupos_sin_personas', { grupos: preview.unassigned.map((u) => t(`v3:puesto_${u.group}`)).join(', ') })}</p>}
          <Button disabled={left !== 0} isLoading={busy} onClick={confirm}>{t('v3:confirmar_reparto')}</Button>
        </section>
      )}
      {splits.length > 0 && (
        <div>
          <h3 className="mb-3 text-base font-bold text-slate-900">{t('v3:repartos_confirmados')}</h3>
          <ul className="space-y-3">
            {splits.map((s) => (
              <li key={s.id} className={`${card} p-4`}>
                <div className="flex flex-wrap items-center gap-3">
                  <span className="text-sm font-bold text-slate-900">{new Date(s.periodFrom).toLocaleDateString(getLocale())} – {new Date(s.periodTo).toLocaleDateString(getLocale())}</span>
                  <span className="font-black tabular-nums text-slate-900">{formatCurrency(s.total)}</span>
                  <span className="ml-auto flex gap-2">
                    {s.status === 'PAID'
                      ? <span className="inline-flex items-center gap-1 rounded-full bg-emerald-100 px-2.5 py-1 text-xs font-bold text-emerald-800"><Check className="h-3.5 w-3.5" aria-hidden />{t('v3:pagada')}</span>
                      : <><Button size="sm" variant="success" onClick={() => act(() => staffAPI.payTips(s.id))}>{t('v3:marcar_pagada')}</Button>
                        <Button size="sm" variant="ghost" onClick={() => act(() => staffAPI.deleteTipSplit(s.id))}>{t('v3:deshacer')}</Button></>}
                  </span>
                </div>
                <p className="mt-2 text-sm text-slate-700">{s.shares.map((x) => `${x.employee.name} ${formatCurrency(x.amount)}`).join(' · ')}</p>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

export const TipsCenter: React.FC = () => {
  const { settings, tipEnabled, tipPercent } = useBusiness();
  const flags = useFeatures((s) => s.settings.flags);
  const [sub, setSub] = useState<Sub>('stats');
  const [pct, setPct] = useState(tipPercent);
  const [busy, setBusy] = useState<string | null>(null);
  useEffect(() => setPct(tipPercent), [tipPercent]);

  const saveBusiness = async (patch: { tipEnabled?: boolean; tipPercent?: number }) => {
    setBusy('business');
    try {
      const saved = await businessAPI.update(patch);
      useBusinessStore.getState().setSettings(saved);
      toast.success(t('v3:guardado'));
    } catch (err) { toast.error(errorMessage(err)); } finally { setBusy(null); }
  };
  const setSplit = async (on: boolean) => {
    setBusy('split');
    try {
      await featuresAPI.save({ flags: on ? { staff: true, tip_split: true } : { tip_split: false } });
      await useFeatures.getState().load();
      if (on) setSub('split');
    } catch (err) { toast.error(errorMessage(err)); } finally { setBusy(null); }
  };

  const subs: { id: Sub; icon: typeof BarChart3; show: boolean }[] = [
    { id: 'stats', icon: BarChart3, show: true },
    { id: 'split', icon: Coins, show: flags.tip_split },
    { id: 'rules', icon: Settings2, show: flags.tip_split },
  ];

  return (
    <div className="space-y-5">
      <section className={`${card} p-5`} aria-labelledby="tips-general">
        <div className="flex flex-wrap items-start gap-4">
          <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-emerald-50 text-emerald-700"><HeartHandshake className="h-5 w-5" aria-hidden /></span>
          <div className="min-w-0 flex-1">
            <h2 id="tips-general" className="text-lg font-black text-slate-900">{t('tips:centro_titulo')}</h2>
            <p className="max-w-2xl text-sm text-slate-500">{t('tips:centro_desc')}</p>
          </div>
        </div>
        <div className="mt-4 grid gap-3 lg:grid-cols-2">
          <Toggle id="tips-on" checked={tipEnabled} disabled={!settings || busy === 'business'} onChange={(v) => saveBusiness({ tipEnabled: v })} label={t('onboarding:manejas_propina')} description={t('onboarding:manejas_propina_desc')} />
          <Toggle id="tips-split" checked={flags.tip_split} disabled={!tipEnabled || busy === 'split'} onChange={setSplit} label={t('tips:reparto_activar')} description={t('tips:reparto_activar_desc')} />
        </div>
        {tipEnabled && (
          <div className="mt-3 flex flex-wrap items-end gap-3">
            <label htmlFor="tips-pct" className="block space-y-1 text-xs font-bold text-slate-700">{t('onboarding:porcentaje_sugerido')}
              <span className="flex items-center gap-1"><input id="tips-pct" type="number" min={0} max={30} className={`${field} w-24`} value={pct} onChange={(e) => setPct(Math.min(30, Math.max(0, Number(e.target.value) || 0)))} /><span className="text-slate-500">%</span></span>
            </label>
            {pct !== tipPercent && <Button size="sm" isLoading={busy === 'business'} onClick={() => saveBusiness({ tipPercent: pct })}>{t('v3:guardar')}</Button>}
          </div>
        )}
      </section>

      {tipEnabled && (
        <>
          <div className="inline-flex flex-wrap gap-1 rounded-2xl bg-slate-100 p-1" role="tablist" aria-label={t('tips:centro_titulo')}>
            {subs.filter((s) => s.show).map(({ id, icon: Icon }) => (
              <button key={id} type="button" role="tab" aria-selected={sub === id} onClick={() => setSub(id)} className={`inline-flex min-h-[40px] items-center gap-2 rounded-xl px-4 text-sm font-bold transition ${sub === id ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}>
                <Icon className="h-4 w-4" aria-hidden />{t(`tips:sub_${id}`)}
              </button>
            ))}
          </div>
          <div key={sub} className="kiosk-fade">
            {sub === 'stats' && <TipsReport embedded />}
            {sub === 'split' && flags.tip_split && <SplitPanel />}
            {sub === 'rules' && flags.tip_split && <RulesPanel />}
          </div>
        </>
      )}
    </div>
  );
};
