// ============================================
// COMPONENTS - Cash Session Panel
// ============================================

import { CloseReportCard } from '../v3/OpsModals';
import React, { useState } from 'react';
import { reasonDialog } from '../../shared/dialog';
import { usePosStore } from '../../store/usePosStore';
import { expensesAPI } from '../../services/api';
import { errorMessage } from '../../services/apiErrors';
import { SessionExpensesCard } from './SessionExpensesCard';
import { Image as ImageIcon, Sparkles } from 'lucide-react';
import { createPortal } from 'react-dom';
import {
  Wallet, 
  Plus, 
  Lock, 
  Unlock, 
  DollarSign,
  TrendingUp,
  TrendingDown,
  BarChart2,
  X,
  Calculator,
  Coins
} from 'lucide-react';
import { formatCurrency } from '../../shared/formatUtils';
import { MonthlyArqueoReport } from './MonthlyArqueoReport';
import { TipsReport, SessionTipsCard } from './TipsReport';
import { useBusiness } from '../../shared/business';
import { tipsAPI } from '../../services/api';
import { HeartHandshake } from 'lucide-react';
import { toast } from '../../shared/toast';

import { t, getLocale } from '../../i18n';
import { ReportButton } from '../common/ReportButton';
import { loadSessionReport } from '../../services/cashReport';
const DENOMINATIONS = [
  { value: 100000, label: '$100.000', type: 'bill' },
  { value: 50000, label: '$50.000', type: 'bill' },
  { value: 20000, label: '$20.000', type: 'bill' },
  { value: 10000, label: '$10.000', type: 'bill' },
  { value: 5000, label: '$5.000', type: 'bill' },
  { value: 2000, label: '$2.000', type: 'bill' },
  { value: 1000, label: '$1.000', type: 'coin' },
  { value: 500, label: '$500', type: 'coin' },
  { value: 200, label: '$200', type: 'coin' },
  { value: 100, label: '$100', type: 'coin' },
  { value: 50, label: '$50', type: 'coin' },
];

export const CashSessionPanel: React.FC = () => {
  const { 
    cashSession, 
    openCashSession, 
    closeCashSession,
    addIncome,
    fetchOpenSession
  } = usePosStore();

  const [showOpenForm, setShowOpenForm] = useState(false);
  const [showCloseForm, setShowCloseForm] = useState(false);
  const [initialBalance, setInitialBalance] = useState('');
  const [countedBalance, setCountedBalance] = useState('');
  const [showDenominations, setShowDenominations] = useState(false);
  const [denomCounts, setDenomCounts] = useState<Record<number, number>>({});
  const [transactionAmount, setTransactionAmount] = useState('');
  const [motive, setMotive] = useState('');
  const [description, setDescription] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showMonthlyReport, setShowMonthlyReport] = useState(false);
  const [showTipsReport, setShowTipsReport] = useState(false);
  // Propinas: solo si el negocio las maneja (Configuración → Negocio)
  const { tipEnabled } = useBusiness();
  const isAdmin = (() => {
    try {
      return JSON.parse(localStorage.getItem('user') || '{}')?.role === 'ADMIN';
    } catch {
      return false;
    }
  })();
  const [closingTipsCash, setClosingTipsCash] = useState(0);
  const [viewer, setViewer] = useState<string | null>(null);
  const [lastClosed, setLastClosed] = useState<{ id: string; number: string } | null>(null);

  // Update counted balance from denomination counts
  const updateDenomCount = (value: number, countStr: string) => {
    const count = parseInt(countStr) || 0;
    const updated = { ...denomCounts, [value]: count };
    setDenomCounts(updated);

    const total = Object.entries(updated).reduce((sum, [val, qty]) => {
      return sum + (Number(val) * (Number(qty) || 0));
    }, 0);
    setCountedBalance(total > 0 ? String(total) : '');
  };

  const handleOpenSession = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!initialBalance) return;
    
    setIsLoading(true);
    try {
      await openCashSession(parseFloat(initialBalance));
      setShowOpenForm(false);
      setInitialBalance('');
      toast.success(t('cash:sesion_de_caja_abierta_correctamente'));
    } catch (error: any) {
      toast.error(error.message || 'Error al abrir sesión');
    }
    setIsLoading(false);
  };

  const handleCloseSession = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!countedBalance || !cashSession) return;
    
    setIsLoading(true);
    try {
      const closing = { id: cashSession.id, number: cashSession.sessionNumber };
      await closeCashSession(parseFloat(countedBalance));
      setLastClosed(closing);
      setShowCloseForm(false);
      setCountedBalance('');
      setDenomCounts({});
      toast.success(t('cash:sesion_de_caja_cerrada_y_arqueo_completado'));
    } catch (error: any) {
      toast.error(error.message || 'Error al cerrar sesión');
    }
    setIsLoading(false);
  };

  const handleAddTransaction = async () => {
    if (!transactionAmount || !cashSession) return;
    
    if (!motive) {
      toast.warning(t('cash:por_favor_ingrese_el_motivo_del_movimiento'));
      return;
    }
    
    setIsLoading(true);
    try {
      await addIncome(parseFloat(transactionAmount), motive, description);
      toast.success(t('cash:ingreso_registrado_con_exito'));
      setTransactionAmount('');
      setMotive('');
      setDescription('');
    } catch (error: any) {
      toast.error(error.message || 'Error al agregar transacción');
    }
    setIsLoading(false);
  };

  // Calculate expected balance
  const expectedBalance = cashSession 
    ? cashSession.initialBalance + cashSession.income - cashSession.expenses
    : 0;

  // Combine movements for history
  const allMovements = [
    ...(cashSession?.incomesDetails || []).map(m => ({ ...m, type: 'INCOME' as const })),
    ...(cashSession?.expensesDetails || []).map(m => ({ ...m, type: 'EXPENSE' as const }))
  ].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  // Gastos del turno pagados por fuera del cajón: quedan en el arqueo sin mover el efectivo
  const outsideExpenses = (cashSession?.expensesDetails || [])
    .filter((e) => !e.isCancelled && e.paymentSource && e.paymentSource !== 'CASH_DRAWER')
    .reduce((n, e) => n + e.amount, 0);

  const showExpenseImage = async (id: string) => {
    try {
      setViewer(await expensesAPI.imageUrl(id));
    } catch (err) {
      toast.error(errorMessage(err));
    }
  };

  // ── Registro de propinas ────────────────────────────────
  if (showTipsReport) {
    return (
      <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 overflow-y-auto max-h-[85vh]">
        <TipsReport onClose={() => setShowTipsReport(false)} />
      </div>
    );
  }

  // ── Monthly report view ─────────────────────────────────
  if (showMonthlyReport) {
    return (
      <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 overflow-y-auto max-h-[85vh]">
        <MonthlyArqueoReport onClose={() => setShowMonthlyReport(false)} />
      </div>
    );
  }

  // ── No session open ─────────────────────────────────────
  if (!cashSession && !showOpenForm) {
    return (
      <div className="bg-white rounded-2xl shadow-lg p-8 space-y-6 max-w-lg mx-auto border border-slate-200">
        <div className="flex flex-col items-center text-center gap-3">
          <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center">
            <Wallet className="w-8 h-8 text-blue-600" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-800">{t('cash:caja')}</h2>
            <p className="text-sm text-slate-500">{t('cash:sesion_cerrada')}</p>
          </div>
        </div>
        <div className="space-y-3">
          {lastClosed && <CloseReportCard sessionId={lastClosed.id} />}
          {lastClosed && (
            <div className="flex items-center justify-between gap-3 p-3 rounded-xl bg-slate-50 border border-slate-200">
              <p className="text-xs text-slate-600">{t('reports:arqueo_cerrado', { n: lastClosed.number })}</p>
              <ReportButton compact label={t('reports:informe')} build={() => loadSessionReport(lastClosed.id)} fileName={`arqueo-${lastClosed.number}`} />
            </div>
          )}
          <button
            data-guide="cash-open"
            onClick={() => setShowOpenForm(true)}
            className="w-full py-3 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-colors flex items-center justify-center gap-2 shadow-sm shadow-blue-500/20 active:scale-[0.98]"
          >
            <Unlock className="w-5 h-5" />
            {t('cash:abrir_caja')}
          </button>

          {/* Monthly report button */}
          <button
            onClick={() => setShowMonthlyReport(true)}
            className="w-full py-3 rounded-xl font-bold flex items-center justify-center gap-2 border border-slate-200 text-slate-700 hover:bg-slate-50 transition-colors shadow-sm"
          >
            <BarChart2 className="w-5 h-5 text-blue-600" />
            {t('cash:ver_reporte_mensual')}
          </button>
          {isAdmin && tipEnabled && (
            <button
              onClick={() => setShowTipsReport(true)}
              className="w-full py-3 rounded-xl font-bold flex items-center justify-center gap-2 border border-slate-200 text-slate-700 hover:bg-slate-50 transition-colors shadow-sm"
            >
              <HeartHandshake className="w-5 h-5 text-emerald-600" />
              {t('tips:ver_registro')}
            </button>
          )}
        </div>
      </div>
    );
  }

  // ── Open session form ───────────────────────────────────
  if (showOpenForm) {
    return (
      <div className="bg-white rounded-3xl shadow-xl p-6 max-w-md mx-auto border border-slate-200">
        <h2 className="text-lg font-bold text-slate-800 mb-4">{t('cash:abrir_caja')}</h2>
        <form onSubmit={handleOpenSession} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">
              {t('cash:saldo_inicial')}
            </label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input
                type="number"
                step="0.01"
                value={initialBalance}
                onChange={(e) => setInitialBalance(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none transition-all"
                placeholder="0.00"
                required
              />
            </div>
          </div>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setShowOpenForm(false)}
              className="flex-1 py-3 border border-slate-200 rounded-xl font-bold text-slate-700 hover:bg-slate-50 transition-colors"
            >
              {t('cash:cancelar')}
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="flex-1 py-3 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 disabled:opacity-50 transition-colors shadow-sm shadow-blue-500/20"
            >
              {isLoading ? t('cash:abriendo') : t('cash:abrir')}
            </button>
          </div>
        </form>
      </div>
    );
  }

  // ── Session is open ─────────────────────────────────────
  return (
    <div className="bg-white rounded-3xl shadow-xl p-6 lg:p-8 space-y-6 max-h-[88vh] overflow-y-auto border border-slate-200">
      {/* Top Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-emerald-100 rounded-2xl flex items-center justify-center text-emerald-700 shadow-sm shrink-0">
            <Wallet className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-black text-slate-800">{t('cash:caja_activa')}</h2>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-black uppercase tracking-wider bg-emerald-100 text-emerald-800">
                {t('cash:turno_abierto')}
              </span>
            </div>
            <p className="text-xs text-slate-400 font-mono mt-0.5">
              {t('cash:arqueo_sessionnumber_abierto_value', { sessionNumber: cashSession?.sessionNumber, value: cashSession?.openedAt ? new Date(cashSession.openedAt).toLocaleDateString(getLocale(), { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : '' })}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {cashSession && (
            <ReportButton compact label={t('reports:informe_arqueo')} build={() => loadSessionReport(cashSession.id)} fileName={`arqueo-${cashSession.sessionNumber}`} />
          )}
          <button
            onClick={() => setShowMonthlyReport(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs border border-slate-200 text-slate-700 hover:bg-slate-50 transition-all shadow-sm"
          >
            <BarChart2 className="w-4 h-4 text-blue-600" />
            <span>{t('cash:ver_reporte_mensual')}</span>
          </button>
          {isAdmin && tipEnabled && (
            <button
              onClick={() => setShowTipsReport(true)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs border border-slate-200 text-slate-700 hover:bg-slate-50 transition-all shadow-sm"
            >
              <HeartHandshake className="w-4 h-4 text-emerald-600" />
              <span>{t('tips:propinas')}</span>
            </button>
          )}
          <button
            data-guide="cash-close"
            onClick={() => {
              setShowCloseForm(true);
              // Las propinas en efectivo están dentro del saldo esperado: se avisa para apartarlas
              if (tipEnabled && cashSession) tipsAPI.session(cashSession.id).then((r) => setClosingTipsCash(r.cash)).catch(() => setClosingTipsCash(0));
            }}
            className="flex items-center gap-2 px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-bold text-xs shadow-md transition-all active:scale-[0.98]"
          >
            <Lock className="w-4 h-4" />
            <span>{t('cash:cerrar_caja')}</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Left side KPIs + Quick Transaction, Right side Movement History */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column (5 cols): Financial Cards + Transaction Form */}
        <div className="lg:col-span-5 space-y-6">
          {/* Session Info 2x2 Grid */}
          <div data-guide="cash-summary" className="grid grid-cols-2 gap-3">
            <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200">
              <p className="text-xs font-black uppercase tracking-wider text-stone-400">{t('cash:saldo_inicial')}</p>
              <p className="text-xl font-black text-stone-800 mt-1">{formatCurrency(cashSession?.initialBalance || 0)}</p>
            </div>
            <div className="p-4 bg-blue-50/50 rounded-2xl border border-blue-200">
              <p className="text-xs font-black uppercase tracking-wider text-blue-700">{t('cash:saldo_esperado')}</p>
              <p className="text-xl font-black text-blue-900 mt-1 tabular-nums">{formatCurrency(expectedBalance)}</p>
            </div>
            <div className="p-4 bg-emerald-50/50 rounded-2xl border border-emerald-200">
              <div className="flex items-center gap-1.5 text-emerald-700">
                <TrendingUp className="w-4 h-4" />
                <p className="text-xs font-black uppercase tracking-wider">{t('cash:ingresos')}</p>
              </div>
              <p className="text-xl font-black text-emerald-700 mt-1 tabular-nums">+{formatCurrency(cashSession?.income || 0)}</p>
            </div>
            <div className="p-4 bg-rose-50/50 rounded-2xl border border-rose-200">
              <div className="flex items-center gap-1.5 text-rose-700">
                <TrendingDown className="w-4 h-4" />
                <p className="text-xs font-black uppercase tracking-wider">{t('cash:egresos')}</p>
              </div>
              <p className="text-xl font-black text-rose-700 mt-1 tabular-nums">-{formatCurrency(cashSession?.expenses || 0)}</p>
              <p className="text-[0.7857rem] font-semibold text-rose-700/70 mt-0.5">{t('expenses:del_cajon')}</p>
            </div>
          </div>

          {tipEnabled && cashSession && <SessionTipsCard sessionId={cashSession.id} refreshKey={cashSession.income} />}

          <SessionExpensesCard outsideTotal={outsideExpenses} isAdmin={isAdmin} onSaved={fetchOpenSession} />

          {/* Ingreso extra al cajón (los gastos van en la tarjeta de arriba) */}
          <div data-guide="cash-movement" className="bg-slate-50/80 rounded-3xl p-5 border border-slate-200 space-y-4 shadow-sm">
            <h3 className="text-xs font-black text-slate-800 uppercase tracking-wider flex items-center gap-2">
              <Plus className="w-4 h-4 text-emerald-600" />
              <span>{t('cash:ingreso_extra')}</span>
            </h3>

            <div className="space-y-3">
              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-slate-500">{t('cash:monto')}</label>
                <div className="relative mt-1">
                  <DollarSign className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="number"
                    step="0.01"
                    value={transactionAmount}
                    onChange={(e) => setTransactionAmount(e.target.value)}
                    className="w-full pl-9 pr-3 py-2.5 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-800 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none transition-all"
                    placeholder="0.00"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-slate-500">{t('cash:motivo')}</label>
                <input
                  type="text"
                  value={motive}
                  onChange={(e) => setMotive(e.target.value)}
                  className="w-full mt-1 px-3 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none transition-all"
                  placeholder={t('cash:ej_ingreso_extra')}
                />
              </div>

              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-slate-500">{t('cash:descripcion_opcional')}</label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full mt-1 px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none transition-all"
                  placeholder={t('cash:detalles_adicionales')}
                  rows={2}
                />
              </div>

              <button
                onClick={handleAddTransaction}
                disabled={!transactionAmount || isLoading || !motive}
                className="w-full py-3 text-white rounded-2xl text-xs font-black shadow-md hover:scale-[1.01] active:scale-[0.99] transition-all disabled:opacity-50 flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700"
              >
                <Plus className="w-4 h-4" />
                {t('cash:registrar_value', { value: t('cash:ingreso') })}
              </button>
            </div>
          </div>
        </div>

        {/* Right Column (7 cols): Movements History in active session */}
        <div data-guide="cash-history" className="lg:col-span-7 flex flex-col space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-black text-stone-800 uppercase tracking-wider flex items-center gap-2">
              <span>{t('cash:historial_del_arqueo_activo_length', { length: allMovements.length })}</span>
            </h3>
            <span className="text-xs text-stone-400 font-medium">{t('cash:movimientos_manuales_de_este_turno')}</span>
          </div>

          <div className="bg-stone-50/60 rounded-3xl p-4 border border-stone-200 flex-1 overflow-y-auto max-h-[560px] space-y-2.5 custom-scrollbar">
            {allMovements.length === 0 ? (
              <div className="py-24 text-center text-stone-400">
                <Wallet className="w-10 h-10 mx-auto mb-2 opacity-30" />
                <p className="font-bold text-xs">{t('cash:sin_movimientos_manuales_en_este_arqueo')}</p>
                <p className="text-xs text-stone-400 mt-1">{t('cash:usa_el_formulario_lateral_para_registrar_ingresos')}</p>
              </div>
            ) : (
              allMovements.map((m: any) => (
                <div
                  key={m.id}
                  className={`p-3.5 border rounded-2xl text-xs transition-all ${
                    m.isCancelled
                      ? 'bg-stone-100/60 border-stone-200 opacity-60'
                      : m.type === 'INCOME'
                      ? 'bg-white border-emerald-100 hover:border-emerald-300 shadow-sm'
                      : 'bg-white border-rose-100 hover:border-rose-300 shadow-sm'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className={`w-2 h-2 rounded-full ${m.type === 'INCOME' ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                        <span className={`font-black text-sm ${m.isCancelled ? 'text-stone-400 line-through' : 'text-stone-800'}`}>
                          {m.motive}
                        </span>
                        {m.type === 'EXPENSE' && m.category && (
                          <span
                            className="text-xs font-black uppercase px-2 py-0.5 rounded-lg text-white"
                            style={{ backgroundColor: m.category.color || '#2563eb' }}
                          >
                            {m.category.name}
                          </span>
                        )}
                        {m.type === 'EXPENSE' && m.captureMode && m.captureMode !== 'MANUAL' && (
                          <Sparkles className="w-3.5 h-3.5 text-violet-500" aria-label={t('expenses:leido_por_ia')} />
                        )}
                      </div>
                      {m.type === 'EXPENSE' && m.paymentSource && m.paymentSource !== 'CASH_DRAWER' && (
                        <p className="text-xs font-semibold text-slate-500 pl-4">
                          {t(`expenses:fuente_${m.paymentSource}`)} · {t('expenses:no_sale_del_cajon')}
                        </p>
                      )}
                      {m.description && !m.isCancelled && (
                        <p className="text-xs text-stone-500 pl-4">{m.description}</p>
                      )}
                      <p className="text-xs text-stone-400 pl-4">
                        {new Date(m.createdAt).toLocaleTimeString(getLocale(), { hour: '2-digit', minute: '2-digit' })}
                        {m.isCancelled && <span className="ml-2 text-rose-500 font-bold">{t('cash:anulado_2')}</span>}
                      </p>
                    </div>

                    <div className="flex flex-col items-end gap-1 shrink-0">
                      <span className={`font-black text-sm ${m.isCancelled ? 'text-stone-300 line-through' : m.type === 'INCOME' ? 'text-emerald-700' : m.paymentSource && m.paymentSource !== 'CASH_DRAWER' ? 'text-slate-500' : 'text-rose-700'}`}>
                        {m.type === 'INCOME' ? '+' : '-'}{formatCurrency(m.amount)}
                      </span>
                      {m.type === 'EXPENSE' && m.imageFile && (
                        <button
                          onClick={() => showExpenseImage(m.id)}
                          className="inline-flex items-center gap-1 text-xs text-stone-500 hover:text-blue-700 font-bold"
                        >
                          <ImageIcon className="w-3.5 h-3.5" aria-hidden />
                          {t('expenses:ver_foto')}
                        </button>
                      )}
                      {!m.isCancelled && (
                        <button
                          onClick={async () => {
                            const reason = await reasonDialog({
                              title: m.type === 'INCOME' ? t('cash:anular_ingreso') : t('cash:anular_egreso'),
                              message: t('cash:amount_el_motivo_queda_registrado_en_el', { amount: formatCurrency(m.amount) }),
                              confirmLabel: t('cash:anular_movimiento'),
                            });
                            if (!reason) return;
                            try {
                              if (m.type === 'INCOME') {
                                await usePosStore.getState().cancelIncome(m.id, reason);
                              } else {
                                // Mismo camino que el registro: solo lo del cajón vuelve al saldo esperado
                                await expensesAPI.cancel(m.id, reason);
                                await fetchOpenSession();
                              }
                              toast.success(t('cash:movimiento_anulado_correctamente'));
                            } catch (error: any) {
                              toast.error(error.message || 'Error al anular movimiento');
                            }
                          }}
                          className="text-xs text-stone-400 hover:text-rose-600 font-bold underline transition-colors"
                        >
                          {t('cash:anular')}
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {viewer &&
        createPortal(
          <div className="fixed inset-0 z-[90] flex items-center justify-center bg-black/80 p-4" onClick={() => { URL.revokeObjectURL(viewer); setViewer(null); }} role="dialog" aria-modal="true">
            <img src={viewer} alt={t('expenses:foto_factura')} className="max-h-[90vh] max-w-full rounded-2xl bg-white object-contain" />
          </div>,
          document.body,
        )}

      {/* Close Session Modal */}
      {showCloseForm && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-stone-200 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100">
              <div className="flex items-center gap-2 text-rose-700">
                <Lock className="w-5 h-5" />
                <h3 className="text-base font-black text-stone-800">{t('cash:cerrar_sesion_de_caja')}</h3>
              </div>
              <button
                onClick={() => setShowCloseForm(false)}
                className="p-1.5 text-stone-400 hover:text-stone-600 rounded-xl"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-amber-50 p-3 rounded-2xl text-xs text-amber-900 border border-amber-200">
              <p className="font-bold">{t('cash:saldo_esperado_en_el_sistema')}{' '}{formatCurrency(expectedBalance)}</p>
              <p className="text-xs text-amber-700 mt-0.5">{t('cash:cuenta_el_dinero_fisico_en_efectivo_en')}</p>
              {closingTipsCash > 0 && (
                <p className="text-xs font-semibold text-emerald-800 mt-1.5">{t('tips:aviso_cierre', { amount: formatCurrency(closingTipsCash) })}</p>
              )}
            </div>

            <form onSubmit={handleCloseSession} className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-black uppercase tracking-wider text-stone-600">
                    {t('cash:efectivo_contado_arqueo_fisico')}
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowDenominations(!showDenominations)}
                    className="inline-flex items-center gap-1 text-xs text-blue-600 hover:text-blue-800 font-semibold"
                  >
                    <Calculator className="w-3.5 h-3.5" />
                    {showDenominations ? t('cash:ocultar_desglose') : t('cash:contar_por_billetes_monedas')}
                  </button>
                </div>
                
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="number"
                    step="0.01"
                    value={countedBalance}
                    onChange={(e) => setCountedBalance(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-2xl text-lg font-black text-stone-800 focus:ring-2 focus:ring-emerald-500 outline-none"
                    placeholder="0.00"
                    required
                    autoFocus
                  />
                </div>
              </div>

              {/* Denomination Breakout Calculator */}
              {showDenominations && (
                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3 space-y-2">
                  <div className="flex items-center justify-between text-xs font-bold text-slate-700 pb-1 border-b border-slate-200">
                    <span className="flex items-center gap-1">
                      <Coins className="w-4 h-4 text-amber-600" />
                      {t('cash:desglose_de_billetes_y_monedas')}
                    </span>
                    <span className="text-xs text-slate-500">{t('cash:ingresa_la_cantidad_fisica')}</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs">
                    {DENOMINATIONS.map((d) => (
                      <div key={d.value} className="flex items-center justify-between bg-white px-2 py-1.5 rounded-lg border border-slate-200">
                        <span className="font-semibold text-slate-700 w-16">{d.label}</span>
                        <div className="flex items-center gap-1.5">
                          <span className="text-slate-400 text-xs">×</span>
                          <input
                            type="number"
                            min="0"
                            placeholder="0"
                            value={denomCounts[d.value] || ''}
                            onChange={(e) => updateDenomCount(d.value, e.target.value)}
                            className="w-12 px-1.5 py-1 text-center font-bold text-slate-800 border border-slate-300 rounded text-xs focus:ring-1 focus:ring-blue-500 outline-none"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {countedBalance && (
                <div className="p-3 rounded-xl bg-stone-50 border text-xs font-bold flex justify-between">
                  <span className="text-stone-500">{t('cash:diferencia')}</span>
                  <span className={parseFloat(countedBalance) - expectedBalance >= 0 ? 'text-emerald-700 font-black' : 'text-rose-700 font-black'}>
                    {formatCurrency(parseFloat(countedBalance) - expectedBalance)}
                  </span>
                </div>
              )}

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCloseForm(false)}
                  className="flex-1 py-3 border border-gray-300 rounded-2xl font-bold text-xs text-gray-700 hover:bg-gray-50"
                >
                  {t('cash:cancelar')}
                </button>
                <button
                  type="submit"
                  disabled={isLoading}
                  className="flex-1 py-3 bg-rose-600 hover:bg-rose-700 text-white rounded-2xl font-black text-xs shadow-md disabled:opacity-50"
                >
                  {isLoading ? t('cash:cerrando') : t('cash:confirmar_cierre')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default CashSessionPanel;