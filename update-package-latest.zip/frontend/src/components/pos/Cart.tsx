// ============================================
// COMPONENTS - Pedido actual (carrito)
// ============================================
// Estructura: encabezado (lugar, pre-cuenta, más acciones) → cliente y descuento →
// productos (rondas enviadas y nuevos) → resumen con impuestos → acción principal.
// Cajero/admin: "Cobrar" es la acción principal; mesero: "Enviar a cocina".

import React, { useState, useMemo, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { usePosStore } from '../../store/usePosStore';
import { salesAPI, ordersAPI, authAPI, customersAPI } from '../../services/api';
import QRCode from 'qrcode';
import { printService } from '../../services/printService';
import { usePrintSettings } from '../../shared/printSettings';
import { errorMessage } from '../../services/apiErrors';
import {
  Trash2, Minus, Plus, ShoppingCart, CreditCard, Check, Ban, Cake, FileText,
  Utensils, AlertTriangle, Users, Clock, ChefHat, History, Receipt, Eraser, X,
} from 'lucide-react';
import { OverflowMenu } from '../common/OverflowMenu';
import { reasonDialog, promptDialog, confirmDialog } from '../../shared/dialog';
import { ElectronicInvoiceModal } from './ElectronicInvoiceModal';
import { CancelItemModal } from './CancelItemModal';
import { CustomerPicker } from './cart/CustomerPicker';
import { DiscountControl } from './cart/DiscountControl';
import { PaymentModal, PaymentPayload } from './cart/PaymentModal';
import { SaleSuccessModal } from './cart/SaleSuccessModal';
import { NoteEditorModal } from './cart/NoteEditorModal';
import type { CartItem } from '../../types';
import { formatCurrency } from '../../shared/formatUtils';
import { toast } from '../../shared/toast';
import { useBusiness, groupSaleTaxes } from '../../shared/business';
import { useFeature } from '../../shared/plan';
import { computeCartTotals, suggestedTipFor } from '../../shared/cartMath';
import { t as tr, getLocale } from '../../i18n';
import { useCan } from '../../shared/permissions';

interface CartProps {
  onOrderComplete?: () => void;
}


export const Cart: React.FC<CartProps> = ({ onOrderComplete }) => {
  const {
    getCurrentCart,
    updateCartItemQuantity,
    updateCartItemNotes,
    removeFromCart,
    clearCart,
    resetCart,
    selectedTable,
    closeTable,
    releaseTable,
    cashSession,
    orderTable,
    fetchTables,
    loadTableSale,
    cancelSaleItem,
    cancelSale,
    fetchOpenSession,
    currentSale,
    savePendingOrder,
    getPendingOrder,
    clearPendingOrder,
    setCartAsOrdered,
    cancelCartItemPartial,
    customersByTable,
    selectCustomerForTable,
    products,
  } = usePosStore();

  const { settings: business } = useBusiness();
  const cart = getCurrentCart();
  const orderedItems = cart.filter(item => item.isOrdered);
  const newItems = cart.filter(item => !item.isOrdered);
  const newItemsCount = newItems.reduce((n, i) => n + i.quantity, 0);

  const tableId = selectedTable?.id || 'counter';
  const placeLabel = selectedTable ? tr('pos:mesa_number', { number: selectedTable.number }) : tr('pos:mostrador');
  const currentCustomer = customersByTable[tableId] || null;

  const user = useMemo(() => {
    try {
      return JSON.parse(localStorage.getItem('user') || '{}');
    } catch {
      return null;
    }
  }, []);
  // Sin la función de cobro (por defecto, el mesero) se toma el pedido y se envía a cocina
  const canCharge = useCan(user?.role)('charge');

  // Minutos de espera de cada ronda: se refresca cada 30 s
  const [, setWaitTimerTick] = useState(0);
  useEffect(() => {
    const timer = setInterval(() => setWaitTimerTick(n => n + 1), 30000);
    return () => clearInterval(timer);
  }, []);

  const orderedRounds = useMemo(() => {
    const map = new Map<number, { roundNumber: number; orderedAt?: string; items: CartItem[] }>();
    orderedItems.forEach((item) => {
      const round = item.roundNumber || 1;
      if (!map.has(round)) map.set(round, { roundNumber: round, orderedAt: item.orderedAt, items: [] });
      const group = map.get(round)!;
      if (item.orderedAt && (!group.orderedAt || new Date(item.orderedAt) < new Date(group.orderedAt))) {
        group.orderedAt = item.orderedAt;
      }
      group.items.push(item);
    });
    return Array.from(map.values()).sort((a, b) => a.roundNumber - b.roundNumber);
  }, [orderedItems]);

  const formatWaitTime = (orderedAt?: string) => {
    if (!orderedAt) return null;
    const minutes = Math.max(0, Math.floor((Date.now() - new Date(orderedAt).getTime()) / 60000));
    const timeStr = new Date(orderedAt).toLocaleTimeString(getLocale(), { hour: '2-digit', minute: '2-digit' });
    let badgeClass = 'bg-emerald-50 text-emerald-700 border-emerald-200';
    let statusText = tr('pos:minutes_min_a_tiempo', { minutes });
    if (minutes >= 30) {
      badgeClass = 'bg-rose-50 text-rose-700 border-rose-200';
      statusText = tr('pos:minutes_min_demorado', { minutes });
    } else if (minutes >= 15) {
      badgeClass = 'bg-amber-50 text-amber-800 border-amber-200';
      statusText = tr('pos:minutes_min_en_espera', { minutes });
    }
    return { minutes, timeStr, badgeClass, statusText };
  };

  // ── Cliente, cumpleaños y descuento ─────────────────────────
  const hasCustomers = useFeature('customers');
  const [isBirthdayActive, setIsBirthdayActive] = useState(false);
  const [recommendedProduct, setRecommendedProduct] = useState<string | null>(null);
  const [discountPct, setDiscountPct] = useState(0);

  // Cada mesa o mostrador tiene siempre un cliente (por defecto, "Cliente común")
  useEffect(() => {
    if (customersByTable[tableId]) return;
    customersAPI.getDefault()
      .then((def) => def && selectCustomerForTable(tableId, def))
      .catch((err) => console.error('Error loading default customer:', err));
  }, [tableId, customersByTable]);

  useEffect(() => {
    let cancelled = false;
    const check = async () => {
      if (!currentCustomer || currentCustomer.isDefault) {
        setIsBirthdayActive(false);
        setRecommendedProduct(null);
        setDiscountPct(0);
        return;
      }
      try {
        const bdays = await customersAPI.getBirthdays();
        const isBday = bdays.some((c: any) => c.id === currentCustomer.id);
        if (cancelled) return;
        setIsBirthdayActive(isBday);
        // Al cambiar de cliente se reinicia el descuento; en su cumpleaños se sugiere 10 %
        setDiscountPct(isBday ? 10 : 0);
        const recs = await customersAPI.getRecommended(currentCustomer.id);
        if (!cancelled) setRecommendedProduct(recs?.[0]?.name || null);
      } catch (err) {
        console.error('Error checking birthday/recs:', err);
      }
    };
    check();
    return () => { cancelled = true; };
  }, [currentCustomer]);

  const totals = useMemo(
    () => computeCartTotals(cart, discountPct, products, business),
    [cart, discountPct, products, business],
  );

  // ── Estados de modales y procesos ───────────────────────────
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [successSale, setSuccessSale] = useState<{ sale: any; change: number; payload: PaymentPayload } | null>(null);
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  const [isSendingOrder, setIsSendingOrder] = useState(false);
  // Candados síncronos: el estado de React tarda un render, un doble clic rápido lo atraviesa
  const paymentLock = useRef(false);
  const orderLock = useRef(false);
  const [cancelModalItem, setCancelModalItem] = useState<CartItem | null>(null);
  const [showPaymentHistory, setShowPaymentHistory] = useState(false);
  const [paymentHistory, setPaymentHistory] = useState<any[]>([]);
  const [completedElectronicSale, setCompletedElectronicSale] = useState<any>(null);
  const [editingNoteItem, setEditingNoteItem] = useState<CartItem | null>(null);

  // ── Impresión ──────────────────────────────────────────────
  const printKitchenTicket = (itemsToPrint: CartItem[], roundNumber?: number) => {
    if (itemsToPrint.length === 0 || !usePrintSettings.getState().settings.autoPrintKitchen) return;
    printService.printKitchenTicket({
      items: itemsToPrint,
      tableNumber: selectedTable?.number || tr('pos:mostrador'),
      roundNumber: roundNumber || itemsToPrint[0]?.roundNumber,
      waiterName: user?.name || null,
    }).catch((e) => {
      console.error('Error printing kitchen ticket:', e);
      toast.warning(tr('printing:no_se_pudo_comanda'));
    });
  };

  /** Pre-cuenta: total sin propina, propina sugerida y total con propina. No es factura. */
  const printPreBill = () => {
    if (cart.length === 0) return;
    const tipPercent = business?.tipEnabled ? business.tipPercent : 0;
    try {
      printService.printReceipt({
        kind: 'prebill',
        items: cart,
        subtotal: totals.subtotal,
        total: totals.total,
        taxLines: totals.taxLines,
        discountPct,
        discountAmount: totals.discount,
        suggestedTip: suggestedTipFor(totals.total, tipPercent),
        tipPercent,
        tableNumber: selectedTable?.number || tr('pos:mostrador'),
        customer: currentCustomer && !currentCustomer.isDefault ? currentCustomer : null,
        cashierName: user?.name || null,
      }).catch((e) => {
        console.error('Error printing pre-bill:', e);
        toast.error(tr('pos:no_se_pudo_imprimir_la_precuenta'));
      });
    } catch (e) {
      console.error('Error printing pre-bill:', e);
      toast.error(tr('pos:no_se_pudo_imprimir_la_precuenta'));
    }
  };

  /** Recibo del cobro. La propina no hace parte de la factura. El QR de sellos se dibuja aquí (sin servicios externos). */
  const printReceipt = async (sale: any, payload: PaymentPayload) => {
    const loyalty = sale.loyaltyInfo;
    const claimQr = loyalty?.token?.claimUrl
      ? await QRCode.toDataURL(loyalty.token.claimUrl, { width: 280, margin: 1, errorCorrectionLevel: 'M' }).catch(() => '')
      : '';
    await printService.printReceipt({
      loyaltyInfo: loyalty,
      claimQrDataUrl: claimQr,
      kind: 'receipt',
      saleNumber: sale.saleNumber,
      date: sale.createdAt,
      cashierName: user?.name || null,
      items: payload.items,
      subtotal: payload.totals.subtotal,
      total: payload.totals.total,
      taxLines: groupSaleTaxes(sale.items),
      discountPct,
      discountAmount: payload.totals.discount,
      tableNumber: selectedTable?.number || tr('pos:mostrador'),
      customer: currentCustomer,
      payments: payload.payments,
      paymentMethod: payload.paymentMethod,
      change: payload.change,
    });
  };

  // ── Enviar a cocina ────────────────────────────────────────
  const handleMakeOrder = async () => {
    if (orderLock.current) return;
    if (!cashSession) {
      toast.warning(tr('pos:debe_abrir_un_arqueo_de_caja_antes_2'), tr('pos:caja_requerida'));
      return;
    }
    if (newItems.length === 0) return;

    orderLock.current = true;
    setIsSendingOrder(true);
    try {
      const currentRounds = orderedItems.filter(i => i.roundNumber).map(i => i.roundNumber!);
      const nextRound = (currentRounds.length > 0 ? Math.max(...currentRounds) : 0) + 1;
      const itemsToSend = newItems;

      if (selectedTable) await orderTable(selectedTable.id);
      setCartAsOrdered(tableId);
      savePendingOrder(tableId, getCurrentCart());
      printKitchenTicket(itemsToSend, nextRound);

      toast.success(
        selectedTable
          ? tr('pos:pedido_ronda_nextround_enviado_a_cocina_para', { nextRound, number: selectedTable.number })
          : tr('pos:comanda_de_mostrador_ronda_nextround_enviada_a', { nextRound }),
        tr('pos:cocina_notificada'),
      );
    } catch (error) {
      console.error('Error creating order:', error);
      toast.error(errorMessage(error), tr('pos:no_se_pudo_enviar_a_cocina'));
    } finally {
      orderLock.current = false;
      setIsSendingOrder(false);
    }
  };

  // ── Cobro ──────────────────────────────────────────────────
  const openPaymentModal = () => {
    if (!canCharge) return;
    if (!cashSession) {
      toast.warning(tr('pos:debe_abrir_un_arqueo_de_caja_antes_2'), tr('pos:caja_requerida'));
      return;
    }
    if (cart.length > 0) setShowPaymentModal(true);
  };

  const processPayment = async (payload: PaymentPayload) => {
    if (paymentLock.current || !cashSession) return;
    paymentLock.current = true;
    setIsProcessingPayment(true);

    try {
      let discountReason: string | undefined;
      let authorizedBy: string | undefined;
      if (discountPct > 0) {
        discountReason = isBirthdayActive ? tr('pos:cumpleanos_de_cliente_10_cortesia') : tr('pos:descuento_comercial_discountpct', { discountPct });
        authorizedBy = user?.name || user?.username || tr('pos:cajero');
      }

      // En pago combinado, el efectivo registrado es lo que queda en caja (sin el cambio devuelto)
      const payments = payload.payments?.map(p =>
        p.method === 'CASH' ? { ...p, amount: Math.max(0, p.amount - payload.change) } : p,
      ).filter(p => p.amount > 0);

      const sale = await salesAPI.create({
        tableId: selectedTable?.id,
        cashSessionId: cashSession.id,
        customerId: currentCustomer?.id || null,
        channel: selectedTable ? 'POS' : 'COUNTER',
        customerName: selectedTable ? undefined : (currentCustomer?.name || tr('pos:cliente_mostrador')),
        discountPct: discountPct || 0,
        discountReason,
        authorizedBy,
        idempotencyKey: `pay_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
        items: payload.items.map(item => ({
          productVariantId: item.variantId,
          quantity: item.quantity,
          unitPrice: item.unitPrice,
          notes: item.notes,
        })),
        paymentMethod: payload.paymentMethod,
        payments,
        tip: payload.tip,
        couponCode: payload.couponCode,
      });

      // Con factura electrónica se imprime la factura DIAN (al emitirla); si no, el recibo.
      // Un fallo de impresión nunca anula un cobro ya registrado.
      if (!payload.emitElectronicInvoice && usePrintSettings.getState().settings.autoPrintReceipt) {
        printReceipt(sale, payload).catch((printError) => {
          console.error('Error printing receipt:', printError);
          toast.warning(tr('pos:no_se_pudo_imprimir_el_recibo'));
        });
      }
      // Los sellos del cliente se avisan siempre, también con factura electrónica
      const credited = sale?.loyaltyInfo?.eligible ? sale.loyaltyInfo.customer : null;
      if (credited) {
        const first = String(credited.name || '').split(' ')[0];
        toast.success(
          tr('loyalty:lleva', { count: credited.stampsCount, total: sale.loyaltyInfo.stampsRequired || 10 }),
          sale.loyaltyInfo.stamps === 1 ? tr('loyalty:sumado_a', { name: first }) : tr('loyalty:sumados_a', { count: sale.loyaltyInfo.stamps, name: first }),
        );
      }

      try {
        if (selectedTable?.status === 'AVAILABLE') await orderTable(selectedTable.id);

        if (payload.isPartial) {
          // Pago parcial: se quitan del pedido solo los productos pagados
          payload.items.forEach(item => removeFromCart(item.id));
          savePendingOrder(tableId, getCurrentCart());
          if (selectedTable) await loadTableSale(selectedTable.id);
          toast.info(tr('pos:pago_parcial_procesado', { amount: formatCurrency(payload.totals.total) }));
        } else {
          // Pago total: se cierra la comanda y el pedido queda vacío (también en mostrador)
          // closeTable ya cierra la comanda de la mesa; el mostrador la cierra por su id
          if (selectedTable) await closeTable(selectedTable.id);
          else await clearPendingOrder('counter');
          resetCart(tableId);
          selectCustomerForTable(tableId, null);
          setDiscountPct(0);
          onOrderComplete?.();
        }
      } catch (tableError) {
        // Si no se pudo actualizar la mesa, la venta se anula para no dejar la cuenta descuadrada
        await cancelSale(sale.id);
        throw new Error(tr('pos:la_venta_fue_anulada_porque_no_se', { value: errorMessage(tableError) }));
      }

      fetchTables();
      fetchOpenSession();
      setShowPaymentModal(false);

      if (payload.emitElectronicInvoice) {
        setCompletedElectronicSale({
          ...sale,
          items: payload.items.map(item => {
            const saved = (sale.items || []).find((si: any) => si.productVariantId === item.variantId);
            return { ...item, taxType: saved?.taxType, taxRate: saved?.taxRate };
          }),
          taxItems: sale.items,
          customer: currentCustomer,
          customerName: currentCustomer?.name,
          paymentMethod: payload.paymentMethod,
        });
      } else {
        setSuccessSale({ sale, change: payload.change, payload });
      }
    } catch (error) {
      console.error('Error processing payment:', error);
      toast.error(errorMessage(error), tr('pos:no_se_pudo_cobrar'));
    } finally {
      paymentLock.current = false;
      setIsProcessingPayment(false);
    }
  };

  // ── Mesa: cerrar, cancelar pedido, abonos ──────────────────
  const handleCloseTable = async () => {
    if (!selectedTable || !canCharge) return;
    if (cart.length > 0) {
      toast.warning(tr('pos:no_puede_cerrar_la_mesa_con_productos'), tr('pos:cuenta_pendiente'));
      return;
    }
    try {
      await closeTable(selectedTable.id);
      toast.success(tr('pos:mesa_number_cerrada_y_liberada_correctamente', { number: selectedTable.number }), tr('pos:mesa_cerrada'));
      fetchTables();
    } catch (error) {
      toast.error(errorMessage(error), tr('pos:no_se_pudo_cerrar_la_mesa'));
    }
  };

  // Motivo obligatorio y, si no es admin, clave de administrador (el servidor exige ambos)
  const handleCancelOrder = async () => {
    if (!selectedTable) return;
    const reason = await reasonDialog({
      title: tr('pos:cancelar_el_pedido_de_la_mesa_number', { number: selectedTable.number }),
      message: tr('pos:los_productos_enviados_a_cocina_se_anulan'),
      confirmLabel: tr('pos:continuar'),
    });
    if (!reason) return;

    let adminAuthToken: string | undefined;
    if (user?.role !== 'ADMIN') {
      const password = await promptDialog({
        title: tr('pos:autorizacion_de_administrador'),
        message: tr('pos:un_administrador_debe_escribir_su_clave_para'),
        label: tr('pos:clave_de_administrador_2'),
        inputType: 'password',
        confirmLabel: tr('pos:autorizar'),
        tone: 'danger',
      });
      if (!password) return;
      try {
        adminAuthToken = (await authAPI.verifyAdminPassword(password)).overrideToken;
      } catch (e) {
        toast.error(errorMessage(e), tr('pos:no_autorizado'));
        return;
      }
    }

    try {
      // releaseTable cierra la comanda en el servidor y vacía el pedido de la mesa
      await releaseTable(selectedTable.id, { reason, adminAuthToken });
      toast.success(tr('pos:pedido_de_la_mesa_number_cancelado', { number: selectedTable.number }));
      onOrderComplete?.();
    } catch (e) {
      toast.error(errorMessage(e), tr('pos:no_se_pudo_cancelar_el_pedido'));
    }
  };

  const handleClearNewItems = async () => {
    const ok = await confirmDialog({
      title: tr('pos:quitar_productos_nuevos'),
      message: tr('pos:quitar_productos_nuevos_desc', { count: newItemsCount }),
      confirmLabel: tr('pos:quitar'),
      tone: 'danger',
    });
    if (ok) clearCart();
  };

  const handleViewPaymentHistory = async () => {
    if (!currentSale) return;
    try {
      setPaymentHistory(await salesAPI.getPayments(currentSale.id));
      setShowPaymentHistory(true);
    } catch (error) {
      toast.error(errorMessage(error));
    }
  };

  // ── Anulación de productos ya enviados (con clave de administrador) ─
  const handleConfirmCancelItem = async (data: {
    quantityToCancel: number;
    reason: string;
    comments?: string;
    wasteDestination: 'waste' | 'restock';
    adminName: string;
    adminAuthToken: string;
  }) => {
    if (!cancelModalItem) return;
    cancelCartItemPartial(tableId, cancelModalItem.id, data.quantityToCancel, data.reason, data.comments, data.adminName, data.wasteDestination);

    try {
      await ordersAPI.cancelItemPartial(cancelModalItem.id, {
        quantity: data.quantityToCancel,
        reason: data.reason,
        comments: data.comments,
        wasteDestination: data.wasteDestination,
        adminAuthToken: data.adminAuthToken,
      });
    } catch {
      if (currentSale) {
        try {
          await cancelSaleItem(cancelModalItem.id, `${data.reason} (${data.adminName})`);
        } catch { /* la anulación local ya quedó registrada */ }
      }
    }

    savePendingOrder(tableId, getCurrentCart());
    if (selectedTable) {
      try { await loadTableSale(selectedTable.id); } catch { /* sin conexión: se usa lo local */ }
    }
    toast.success(
      tr('pos:anulacion_registrada_quantitytocancel_x_productnam', { quantityToCancel: data.quantityToCancel, productName: cancelModalItem.productName, adminName: data.adminName }),
      tr('pos:anulacion_exitosa'),
    );
    setCancelModalItem(null);
  };

  // ── Atajos: F2 cobrar · F4 enviar a cocina (se ignoran con un modal abierto) ─
  const shortcuts = useRef({ pay: () => {}, send: () => {} });
  shortcuts.current = {
    pay: () => { if (canCharge && cart.length > 0 && !showPaymentModal) openPaymentModal(); },
    send: () => { if (newItemsCount > 0 && !isSendingOrder) handleMakeOrder(); },
  };
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== 'F2' && e.key !== 'F4') return;
      if (document.querySelector('[aria-modal="true"], .fixed.inset-0')) return;
      e.preventDefault();
      if (e.key === 'F2') shortcuts.current.pay();
      else shortcuts.current.send();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  // Las ventanas se montan en <body>: dentro del panel del carrito quedarían bajo el encabezado de la app
  const modals = createPortal(
    <>
      {showPaymentModal && (
        <PaymentModal
          items={cart}
          discountPct={discountPct}
          products={products}
          business={business}
          placeLabel={placeLabel}
          isProcessing={isProcessingPayment}
          isAdmin={user?.role === 'ADMIN'}
          onClose={() => setShowPaymentModal(false)}
          onConfirm={processPayment}
        />
      )}
      <CancelItemModal
        isOpen={!!cancelModalItem}
        onClose={() => setCancelModalItem(null)}
        item={cancelModalItem}
        onConfirm={handleConfirmCancelItem}
      />
      {editingNoteItem && (
        <NoteEditorModal
          productName={editingNoteItem.productName}
          initialNote={editingNoteItem.notes || ''}
          onClose={() => setEditingNoteItem(null)}
          onSave={(note) => {
            updateCartItemNotes(editingNoteItem.id, note);
            setEditingNoteItem(null);
          }}
        />
      )}
      {showPaymentHistory && (
        <PaymentHistoryModal payments={paymentHistory} onClose={() => setShowPaymentHistory(false)} />
      )}
      {completedElectronicSale && (
        <ElectronicInvoiceModal
          isOpen
          autoPrint
          onClose={() => setCompletedElectronicSale(null)}
          sale={completedElectronicSale}
        />
      )}
      {successSale && (
        <SaleSuccessModal
          isOpen={!!successSale}
          onClose={() => setSuccessSale(null)}
          sale={successSale.sale}
          change={successSale.change}
          onPrint={() => {
            printReceipt(successSale.sale, successSale.payload).catch((e) => console.error(e));
          }}
        />
      )}
    </>,
    document.body,
  );

  // ── Mesa en consumo sin productos nuevos en este equipo ────
  if (cart.length === 0 && selectedTable && (selectedTable.status === 'ORDERED' || selectedTable.status === 'PENDING')) {
    const tableItems = getPendingOrder(selectedTable.id);
    const tableTotal = tableItems.reduce((sum, i) => sum + (i.total ?? i.quantity * i.unitPrice), 0);
    const isOrdered = selectedTable.status === 'ORDERED';

    return (
      <div className="flex flex-col h-full bg-white p-5 overflow-hidden">
        <div className="pb-4 border-b border-slate-100 flex items-center justify-between">
          <div className="space-y-1">
            <h2 className="text-xl font-bold text-slate-900 font-heading">{placeLabel}</h2>
            <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
              <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${isOrdered ? 'bg-amber-100 text-amber-800' : 'bg-purple-100 text-purple-800'}`}>
                {isOrdered ? tr('pos:en_consumo_2') : tr('pos:pendiente_de_pago')}
              </span>
              <span className="flex items-center gap-1">
                <Users className="w-3.5 h-3.5 text-slate-400" aria-hidden />
                {tr('pos:capacity_comensales', { capacity: selectedTable.capacity })}
              </span>
            </div>
          </div>
          {tableTotal > 0 && (
            <div className="text-right">
              <span className="text-xs font-bold text-slate-500">{tr('pos:total_acumulado')}</span>
              <p className="text-lg font-black text-slate-900 tabular-nums">{formatCurrency(tableTotal)}</p>
            </div>
          )}
        </div>

        <div className="flex-1 overflow-y-auto py-6 flex flex-col justify-center items-center text-center px-2">
          {tableItems.length > 0 ? (
            <div className="w-full space-y-3 my-auto">
              <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 text-left">
                <p className="text-xs font-bold text-slate-700 mb-2.5 flex items-center gap-1.5">
                  <Utensils className="w-3.5 h-3.5 text-blue-600" aria-hidden />
                  {tr('pos:consumo_registrado')}
                </p>
                <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                  {tableItems.map((item, idx) => (
                    <div key={item.id || idx} className="flex justify-between items-center text-xs text-slate-700 py-1.5 border-b border-slate-200/50 last:border-0">
                      <span><strong className="text-slate-900">{item.quantity}x</strong> {item.productName}</span>
                      <span className="font-bold tabular-nums text-slate-900">{formatCurrency(item.total)}</span>
                    </div>
                  ))}
                </div>
              </div>
              <p className="text-xs text-slate-500">{tr('pos:selecciona_productos_del_catalogo_para_anadir_un')}</p>
            </div>
          ) : (
            <div className="flex flex-col items-center max-w-sm space-y-3">
              <div className="w-16 h-16 rounded-3xl bg-blue-50 text-blue-600 flex items-center justify-center">
                <Utensils className="w-8 h-8" aria-hidden />
              </div>
              <h3 className="text-base font-bold text-slate-800">{tr('pos:mesa_en_operacion')}</h3>
              <p className="text-xs text-slate-500 leading-relaxed">{tr('pos:no_hay_productos_en_el_borrador_de')}</p>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-slate-100 rounded-full text-xs font-semibold text-slate-600">
                <Clock className="w-3.5 h-3.5 text-slate-400" aria-hidden />
                {tr('pos:catalogo_listo_para_capturar_pedido')}
              </div>
            </div>
          )}
        </div>

        <div className="pt-4 border-t border-slate-100 space-y-2">
          {selectedTable.status === 'PENDING' && canCharge && (
            <button onClick={handleCloseTable} className="w-full min-h-[48px] bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-sm flex items-center justify-center gap-2">
              <Check className="w-4 h-4" aria-hidden />
              {tr('pos:cerrar_y_liberar_mesa')}
            </button>
          )}
          {isOrdered && (
            <button onClick={handleCancelOrder} className="w-full min-h-[44px] text-rose-700 hover:bg-rose-50 rounded-xl font-semibold text-sm flex items-center justify-center gap-2">
              <AlertTriangle className="w-4 h-4" aria-hidden />
              {tr('pos:cancelar_pedido_de_la_mesa')}
            </button>
          )}
        </div>
        {modals}
      </div>
    );
  }

  if (cart.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-6 text-center bg-white">
        <div className="w-16 h-16 rounded-3xl bg-slate-100 flex items-center justify-center mb-4 text-slate-400">
          <ShoppingCart className="w-8 h-8" aria-hidden />
        </div>
        <p className="text-base font-bold text-slate-700">{tr('pos:carrito_vacio')}</p>
        <p className="text-xs text-slate-500 max-w-xs mt-1">{tr('pos:selecciona_productos_del_catalogo_central_o_abre')}</p>
        {modals}
      </div>
    );
  }

  const showSendButton = newItemsCount > 0 || !canCharge;
  const iconButton = 'w-11 h-11 shrink-0 rounded-xl inline-flex items-center justify-center text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition-colors';

  return (
    <div className="flex flex-col h-full bg-white overflow-hidden">
      {/* ── Encabezado: lugar y acciones del pedido ── */}
      <header className="px-4 pt-4 pb-3 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <div className="min-w-0">
            <h2 className="text-lg font-bold text-slate-900 font-heading leading-tight truncate">{placeLabel}</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              {tr('pos:n_productos', { count: totals.units })}
              {orderedRounds.length > 0 && ` · ${tr('pos:n_rondas_en_cocina', { count: orderedRounds.length })}`}
            </p>
          </div>
          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={printPreBill}
              data-guide="cart-prebill"
              title={tr('pos:imprimir_precuenta')}
              className="h-11 inline-flex items-center gap-1.5 px-3 rounded-xl text-sm font-semibold text-slate-700 hover:bg-slate-100 transition-colors"
            >
              <Receipt className="w-4 h-4 text-slate-500" aria-hidden />
              {tr('pos:precuenta')}
            </button>
            <OverflowMenu
              placement="bottom"
              label={tr('pos:mas_acciones_del_pedido')}
              actions={[
                {
                  label: tr('pos:ver_abonos'),
                  icon: <History className="w-4 h-4" aria-hidden />,
                  hidden: !(selectedTable?.status === 'PENDING' && currentSale),
                  onSelect: handleViewPaymentHistory,
                },
                {
                  label: tr('pos:quitar_productos_nuevos'),
                  icon: <Eraser className="w-4 h-4" aria-hidden />,
                  hidden: newItems.length === 0,
                  onSelect: handleClearNewItems,
                },
                {
                  label: tr('pos:cancelar_pedido_de_la_mesa'),
                  icon: <AlertTriangle className="w-4 h-4" aria-hidden />,
                  tone: 'danger',
                  hidden: selectedTable?.status !== 'ORDERED',
                  onSelect: handleCancelOrder,
                },
              ]}
            />
          </div>
        </div>

        <div className="flex items-center gap-2" data-guide="cart-customer">
          <div className="flex-1 min-w-0">
            {/* Sin el módulo de clientes la venta queda a nombre del cliente común */}
            {hasCustomers && (
              <CustomerPicker
                customer={currentCustomer}
                isBirthday={isBirthdayActive}
                onSelect={(c) => selectCustomerForTable(tableId, c)}
              />
            )}
          </div>
          {canCharge && <DiscountControl value={discountPct} onChange={setDiscountPct} />}
        </div>

        {isBirthdayActive && (
          <p className="flex items-start gap-2 text-xs text-amber-900 leading-relaxed">
            <Cake className="w-4 h-4 text-amber-600 shrink-0" aria-hidden />
            <span>
              <strong>{tr('pos:hoy_cumple_anos_recomiendale')}</strong>{' '}
              {tr('pos:regalo_sugerido')} <strong>{recommendedProduct || tr('pos:un_postre_o_bebida_premium')}</strong>
            </span>
          </p>
        )}
      </header>

      {/* ── Productos: lista continua; las rondas son encabezados de sección ── */}
      <div data-guide="cart-items" className="flex-1 min-h-0 overflow-y-auto border-t border-slate-200">
        {orderedRounds.map((roundGroup) => {
          const waitInfo = formatWaitTime(roundGroup.orderedAt);
          return (
            <section key={roundGroup.roundNumber} aria-label={tr('pos:ronda_roundnumber', { roundNumber: roundGroup.roundNumber })}>
              <div className="sticky top-0 z-[1] px-4 py-2 bg-slate-50 border-b border-slate-200 flex items-center justify-between gap-2 text-xs">
                <span className="flex items-center gap-2 font-semibold text-slate-700">
                  <ChefHat className="w-3.5 h-3.5 text-slate-500" aria-hidden />
                  {tr('pos:ronda_roundnumber', { roundNumber: roundGroup.roundNumber })}
                  {waitInfo && <span className="font-normal text-slate-500 tabular-nums">· {waitInfo.timeStr}</span>}
                </span>
                {waitInfo && (
                  <span className={`px-2 py-0.5 rounded-full border font-semibold ${waitInfo.badgeClass}`}>{waitInfo.statusText}</span>
                )}
              </div>
              <ul className="divide-y divide-slate-100">
                {roundGroup.items.map((item) => (
                  <li key={item.id} className="px-4 py-3 flex items-start gap-3">
                    <span className="w-7 shrink-0 text-sm font-bold text-slate-500 tabular-nums">{item.quantity}×</span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-slate-900 leading-snug">{item.productName}</p>
                      {item.variantName && <p className="text-xs text-slate-500">{item.variantName}</p>}
                      {item.notes && <p className="text-xs text-slate-600 italic mt-0.5">“{item.notes}”</p>}
                      {item.cancellations?.map((canc) => (
                        <p key={canc.id} className="text-xs font-semibold text-rose-700 mt-0.5">
                          {tr('pos:quantity_x_cancelado_reason_value', { quantity: canc.quantity, reason: canc.reason, value: canc.comments ? ` (${canc.comments})` : '' })}
                        </p>
                      ))}
                    </div>
                    <div className="flex flex-col items-end gap-1 shrink-0">
                      <span className="text-sm font-semibold text-slate-900 tabular-nums">{formatCurrency(item.total)}</span>
                      <button
                        type="button"
                        onClick={() => setCancelModalItem(item)}
                        title={tr('pos:anular_producto_o_cancelar_unidades_con_clave')}
                        className="-mr-2 h-8 inline-flex items-center gap-1 px-2 rounded-lg text-xs font-semibold text-rose-700 hover:bg-rose-50"
                      >
                        <Ban className="w-3.5 h-3.5" aria-hidden />
                        {tr('pos:anular')}
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            </section>
          );
        })}

        {newItems.length > 0 && (
          <section aria-label={tr('pos:nuevos_para_ordenar')}>
            {orderedRounds.length > 0 && (
              <div className="sticky top-0 z-[1] px-4 py-2 bg-blue-50 border-b border-blue-100 text-xs font-semibold text-blue-800">
                {tr('pos:nuevos_para_ordenar')}
              </div>
            )}
            <ul className="divide-y divide-slate-100">
              {newItems.map((item) => (
                <li key={item.id} className="px-4 py-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-slate-900 leading-snug">{item.productName}</p>
                      <p className="text-xs text-slate-500 tabular-nums">
                        {item.variantName}
                        {item.quantity > 1 && ` · ${formatCurrency(item.unitPrice)} c/u`}
                      </p>
                    </div>
                    <span className="text-sm font-semibold text-slate-900 tabular-nums shrink-0">{formatCurrency(item.total)}</span>
                  </div>

                  <div className="mt-2 flex items-center gap-1">
                    <div className="flex items-center rounded-xl border border-slate-200">
                      <button
                        type="button"
                        onClick={() => updateCartItemQuantity(item.id, item.quantity - 1)}
                        aria-label={tr('pos:disminuir_cantidad')}
                        className="w-11 h-10 inline-flex items-center justify-center text-slate-600 hover:bg-slate-50 rounded-l-xl"
                      >
                        <Minus className="w-4 h-4" aria-hidden />
                      </button>
                      <span className="w-8 text-center text-sm font-bold text-slate-900 tabular-nums" aria-live="polite">{item.quantity}</span>
                      <button
                        type="button"
                        onClick={() => updateCartItemQuantity(item.id, item.quantity + 1)}
                        aria-label={tr('pos:aumentar_cantidad')}
                        className="w-11 h-10 inline-flex items-center justify-center text-slate-600 hover:bg-slate-50 rounded-r-xl"
                      >
                        <Plus className="w-4 h-4" aria-hidden />
                      </button>
                    </div>

                    <button
                      type="button"
                      onClick={() => setEditingNoteItem(item)}
                      className={`flex-1 min-w-0 h-10 px-2.5 rounded-xl text-xs font-medium text-left inline-flex items-center gap-1.5 transition-colors ${
                        item.notes ? 'text-amber-900 bg-amber-50 hover:bg-amber-100' : 'text-slate-500 hover:text-slate-900 hover:bg-slate-100'
                      }`}
                    >
                      <FileText className="w-3.5 h-3.5 shrink-0" aria-hidden />
                      <span className="truncate">{item.notes || tr('pos:agregar_nota')}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => removeFromCart(item.id)}
                      aria-label={tr('pos:eliminar_productname_del_pedido', { productName: item.productName })}
                      className={`${iconButton} hover:!text-rose-700 hover:!bg-rose-50`}
                    >
                      <Trash2 className="w-4 h-4" aria-hidden />
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          </section>
        )}
      </div>

      {/* ── Resumen y acciones: el total manda; el botón acompaña ── */}
      <footer className="border-t border-slate-200 px-4 pt-3 pb-4 space-y-3">
        {(totals.discount > 0 || totals.taxTotal > 0) && (
          <dl className="space-y-1 text-sm">
            {totals.discount > 0 && (
            <>
            <div className="flex justify-between text-slate-500">
              <dt>{tr('pos:subtotal')}</dt>
              <dd className="tabular-nums">{formatCurrency(totals.subtotal)}</dd>
            </div>
            <div className="flex justify-between text-emerald-700">
              <dt className="flex items-center gap-1">
                {tr('pos:descuento_value', { value: discountPct })}
                <button type="button" onClick={() => setDiscountPct(0)} aria-label={tr('pos:quitar_descuento')} className="w-6 h-6 inline-flex items-center justify-center rounded-md hover:bg-emerald-50">
                  <X className="w-3.5 h-3.5" aria-hidden />
                </button>
              </dt>
              <dd className="tabular-nums">-{formatCurrency(totals.discount)}</dd>
            </div>
            </>
            )}
            {totals.taxTotal > 0 && (
              <div className="flex justify-between text-xs text-slate-500">
                <dt>{tr('pos:impuestos_incluidos')}</dt>
                <dd className="tabular-nums">{formatCurrency(totals.taxTotal)}</dd>
              </div>
            )}
          </dl>
        )}

        <div className="flex items-end justify-between gap-3">
          <div className="min-w-0" data-guide="cart-total">
            <p className="text-xs font-semibold text-slate-500">{tr('pos:total_label')}</p>
            <p className="text-[1.75rem] leading-none font-bold text-slate-900 tabular-nums tracking-tight">{formatCurrency(totals.total)}</p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {showSendButton && canCharge && (
              <button
                onClick={handleMakeOrder}
                disabled={isSendingOrder || isProcessingPayment || newItemsCount === 0}
                title={tr('pos:enviar_los_productos_nuevos_a_cocina_f4')}
                data-guide="cart-send-kitchen"
                className="h-12 px-3.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-50 inline-flex items-center gap-2 text-sm font-semibold transition-colors disabled:opacity-50"
              >
                <ChefHat className="w-4 h-4 text-slate-500" aria-hidden />
                {isSendingOrder ? tr('pos:enviando') : tr('pos:cocina')}
                <span className="min-w-[20px] h-5 px-1 rounded-full bg-blue-600 text-white text-[11px] font-bold leading-5 text-center tabular-nums">
                  {newItemsCount}
                </span>
              </button>
            )}
            {!canCharge ? (
              <button
                onClick={handleMakeOrder}
                disabled={isSendingOrder || newItemsCount === 0}
                title={newItemsCount === 0 ? tr('pos:no_hay_productos_nuevos_para_enviar') : tr('pos:enviar_los_productos_nuevos_a_cocina_f4')}
                data-guide="cart-send-kitchen"
                className="h-12 px-5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold inline-flex items-center gap-2 shadow-sm disabled:opacity-50"
              >
                <ChefHat className="w-5 h-5" aria-hidden />
                {isSendingOrder ? tr('pos:enviando') : tr('pos:enviar_a_cocina')}
                {newItemsCount > 0 && <span className="text-xs font-bold px-1.5 py-0.5 rounded-md bg-white/20 tabular-nums">{newItemsCount}</span>}
              </button>
            ) : (
              <button
                onClick={openPaymentModal}
                disabled={isProcessingPayment}
                title={tr('pos:cobrar_la_cuenta_f2')}
                data-guide="cart-pay"
                className="h-12 px-6 rounded-xl bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white font-semibold inline-flex items-center gap-2 shadow-sm transition-colors disabled:opacity-50"
              >
                <CreditCard className="w-5 h-5" aria-hidden />
                {tr('pos:cobrar')}
                <kbd className="hidden xl:inline text-[11px] font-semibold px-1.5 py-0.5 rounded-md bg-white/15">F2</kbd>
              </button>
            )}
          </div>
        </div>
      </footer>

      {modals}
    </div>
  );
};

function PaymentHistoryModal({ payments, onClose }: { payments: any[]; onClose: () => void }) {
  const methodLabel = (m: string) => (m === 'CASH' ? tr('pos:efectivo') : m === 'CARD' ? tr('pos:tarjeta') : tr('pos:transferencia'));
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" role="presentation">
      <div role="dialog" aria-modal="true" aria-labelledby="history-title" className="bg-white rounded-3xl w-full max-w-md max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-4 border-b border-slate-100">
          <h3 id="history-title" className="text-lg font-bold">{tr('pos:historial_de_abonos')}</h3>
          <button onClick={onClose} aria-label={tr('pos:cerrar')} className="w-10 h-10 hover:bg-slate-100 rounded-xl flex items-center justify-center">
            <X className="w-5 h-5" aria-hidden />
          </button>
        </div>
        <div className="p-4 space-y-2">
          {payments.length === 0 ? (
            <p className="text-center text-slate-500 py-4">{tr('pos:no_hay_pagos_registrados')}</p>
          ) : (
            payments.map((payment: any) => (
              <div key={payment.id} className="p-3 bg-emerald-50 rounded-xl border border-emerald-200">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-emerald-800 tabular-nums">{formatCurrency(payment.amount)}</span>
                  <span className="text-xs text-slate-500">{new Date(payment.createdAt).toLocaleString(getLocale())}</span>
                </div>
                <p className="text-sm text-slate-600">{tr('pos:metodo_value', { value: methodLabel(payment.paymentMethod) })}</p>
                {payment.notes && <p className="text-sm text-slate-500 mt-1">{tr('pos:nota')} {payment.notes}</p>}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

export default Cart;
