// ============================================
// COMPONENTS - Cancel Item Modal (Admin Auth & Partial Cancellation)
// ============================================

import React, { useState } from 'react';
import type { CartItem } from '../../types';
import { authAPI } from '../../services/api';
import { 
  X, 
  Minus, 
  Plus, 
  ShieldAlert, 
  CheckCircle2, 
  AlertCircle, 
  Trash2, 
  KeyRound, 
  RotateCcw, 
  PackageX 
} from 'lucide-react';
import { formatCurrency } from '../../shared/formatUtils';
import { toast } from '../../shared/toast';

import { t } from '../../i18n';
interface CancelItemModalProps {
  isOpen: boolean;
  onClose: () => void;
  item: CartItem | null;
  onConfirm: (data: {
    quantityToCancel: number;
    reason: string;
    comments?: string;
    wasteDestination: 'waste' | 'restock';
    adminName: string;
    adminAuthToken: string;
  }) => Promise<void> | void;
}

// Función (no constante) para que los motivos sigan el idioma activo
const presetReasons = () => [
  t('pos:el_cliente_lo_cancela'),
  t('pos:error_de_digitacion_pedido_duplicado'),
  t('pos:demora_excesiva_en_preparacion'),
  t('pos:cambio_por_otro_producto'),
  t('pos:producto_no_disponible_en_cocina_bar'),
  t('pos:producto_devuelto_no_conforme'),
  t('pos:otro_motivo')
];

export const CancelItemModal: React.FC<CancelItemModalProps> = ({
  isOpen,
  onClose,
  item,
  onConfirm
}) => {
  if (!isOpen || !item) return null;

  const maxQty = item.quantity;
  const [quantityToCancel, setQuantityToCancel] = useState<number>(1);
  const [reason, setReason] = useState<string>(presetReasons()[0]);
  const [comments, setComments] = useState<string>('');
  const [wasteDestination, setWasteDestination] = useState<'waste' | 'restock'>('waste');
  
  // Admin Authorization State
  const [adminPassword, setAdminPassword] = useState<string>('');
  const [isVerifying, setIsVerifying] = useState<boolean>(false);
  const [authorizedAdmin, setAuthorizedAdmin] = useState<string | null>(null);
  const [adminAuthToken, setAdminAuthToken] = useState<string>('');
  const [authError, setAuthError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const handleVerifyAdmin = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!adminPassword.trim()) {
      setAuthError(t('pos:ingresa_la_contrasena_de_administrador'));
      return;
    }

    setIsVerifying(true);
    setAuthError(null);
    try {
      const res = await authAPI.verifyAdminPassword(adminPassword);
      if (res.valid) {
        setAuthorizedAdmin(res.adminName);
        setAdminAuthToken(res.overrideToken);
        toast.success(t('pos:autorizado_por_administrador_adminname', { adminName: res.adminName }));
      } else {
        setAuthError(t('pos:contrasena_de_administrador_incorrecta'));
      }
    } catch (err: any) {
      setAuthError(err.message || t('pos:contrasena_incorrecta_o_usuario_sin_permisos'));
    } finally {
      setIsVerifying(false);
    }
  };

  const handleSubmit = async () => {
    if (!authorizedAdmin) {
      setAuthError(t('pos:debes_validar_la_clave_de_administrador_antes'));
      return;
    }

    if (quantityToCancel <= 0 || quantityToCancel > maxQty) {
      toast.warning(t('pos:cantidad_invalida_a_anular'));
      return;
    }

    setIsSubmitting(true);
    try {
      await onConfirm({
        quantityToCancel,
        reason,
        comments: comments.trim() ? comments.trim() : undefined,
        wasteDestination,
        adminName: authorizedAdmin,
        adminAuthToken
      });
      handleClose();
    } catch (err: any) {
      toast.error(err.message || 'Error al anular producto');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClose = () => {
    setQuantityToCancel(1);
    setReason(presetReasons()[0]);
    setComments('');
    setWasteDestination('waste');
    setAdminPassword('');
    setAuthorizedAdmin(null);
    setAuthError(null);
    setIsSubmitting(false);
    onClose();
  };

  const deductionTotal = quantityToCancel * item.unitPrice;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity"
        onClick={handleClose}
      />

      {/* Modal Container */}
      <div className="relative bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden border border-slate-100 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-rose-600 via-rose-700 to-amber-700 p-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-white/15 backdrop-blur-md rounded-2xl">
              <ShieldAlert className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-black tracking-tight">{t('pos:anulacion_de_comanda')}</h2>
              <p className="text-rose-100 text-xs">{t('pos:requiere_autorizacion_administrativa_y_motivo')}</p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="p-2 hover:bg-white/20 rounded-xl text-rose-100 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto space-y-4">
          {/* Item Card */}
          <div className="bg-rose-50/70 border border-rose-200/80 rounded-2xl p-3.5 flex items-center justify-between">
            <div className="min-w-0 pr-2">
              <div className="font-bold text-slate-900 text-base truncate">{item.productName}</div>
              {item.variantName && (
                <div className="text-xs font-semibold text-rose-700">{item.variantName}</div>
              )}
              <div className="text-xs text-slate-500 mt-0.5">
                {t('pos:comandado')}{' '}<span className="font-mono font-bold text-slate-800">{maxQty}{' '}{t('pos:unidades')}</span>{' '}{t('pos:amount_c_u', { amount: formatCurrency(item.unitPrice) })}
              </div>
            </div>
            <div className="text-right shrink-0">
              <div className="text-xs text-slate-500">{t('pos:total_en_cuenta')}</div>
              <div className="text-base font-black text-slate-900 font-mono">{formatCurrency(item.total)}</div>
            </div>
          </div>

          {/* Stepper Cantidad a Cancelar */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-600">
                {t('pos:cantidad_a_cancelar')}
              </label>
              <span className="text-xs font-bold text-rose-600">
                {t('pos:resta_amount', { amount: formatCurrency(deductionTotal) })}
              </span>
            </div>

            <div className="flex items-center gap-3">
              <div className="flex items-center bg-slate-100 rounded-2xl p-1 shadow-inner">
                <button
                  type="button"
                  onClick={() => setQuantityToCancel(q => Math.max(1, q - 1))}
                  disabled={quantityToCancel <= 1}
                  className="w-11 h-11 rounded-xl bg-white text-slate-700 shadow-xs hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center font-bold active:scale-95 transition-all"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="w-14 text-center font-black text-lg text-slate-900 font-mono">
                  {quantityToCancel}
                </span>
                <button
                  type="button"
                  onClick={() => setQuantityToCancel(q => Math.min(maxQty, q + 1))}
                  disabled={quantityToCancel >= maxQty}
                  className="w-11 h-11 rounded-xl bg-white text-slate-700 shadow-xs hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center font-bold active:scale-95 transition-all"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>

              {maxQty > 1 && (
                <div className="flex gap-2 flex-1">
                  <button
                    type="button"
                    onClick={() => setQuantityToCancel(1)}
                    className={`flex-1 py-2.5 px-2 text-xs font-bold rounded-xl border transition-all ${
                      quantityToCancel === 1
                        ? 'border-rose-400 bg-rose-50 text-rose-800'
                        : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {t('pos:solo_1_unidad')}
                  </button>
                  <button
                    type="button"
                    onClick={() => setQuantityToCancel(maxQty)}
                    className={`flex-1 py-2.5 px-2 text-xs font-bold rounded-xl border transition-all ${
                      quantityToCancel === maxQty
                        ? 'border-rose-400 bg-rose-50 text-rose-800'
                        : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {t('pos:todo_maxqty', { maxQty })}
                  </button>
                </div>
              )}
            </div>
            {quantityToCancel < maxQty && (
              <p className="text-xs text-slate-500 mt-1.5">
                {t('pos:se_mantendran')}{' '}<strong className="text-slate-800">{maxQty - quantityToCancel}{' '}{t('pos:unidades')}</strong>{' '}{t('pos:activas_en_la_comanda')}
              </p>
            )}
          </div>

          {/* Motivo de Cancelación */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
              {t('pos:motivo_de_anulacion')}
            </label>
            <select
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 transition-all"
            >
              {presetReasons().map((r) => (
                <option key={r} value={r}>
                  {r}
                </option>
              ))}
            </select>
          </div>

          {/* Comentarios Opcionales */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
              {t('pos:comentarios_u_observaciones_opcional')}
            </label>
            <input
              type="text"
              value={comments}
              onChange={(e) => setComments(e.target.value)}
              placeholder={t('pos:ej_mesa_pidio_cambiar_por_jugo_de')}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 transition-all placeholder:text-slate-400"
            />
          </div>

          {/* Destino de la Anulación (Merma vs Restock) */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
              {t('pos:destino_en_inventario')}
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setWasteDestination('waste')}
                className={`flex items-center gap-2.5 p-3 rounded-2xl border text-left transition-all ${
                  wasteDestination === 'waste'
                    ? 'border-amber-400 bg-amber-50 text-amber-900 ring-2 ring-amber-400/20'
                    : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                }`}
              >
                <PackageX className="w-5 h-5 shrink-0 text-amber-600" />
                <div>
                  <div className="text-xs font-bold">{t('pos:desechar_merma')}</div>
                  <div className="text-xs text-slate-500">{t('pos:ya_se_cocino_o_se_abrio')}</div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setWasteDestination('restock')}
                className={`flex items-center gap-2.5 p-3 rounded-2xl border text-left transition-all ${
                  wasteDestination === 'restock'
                    ? 'border-emerald-400 bg-emerald-50 text-emerald-900 ring-2 ring-emerald-400/20'
                    : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                }`}
              >
                <RotateCcw className="w-5 h-5 shrink-0 text-emerald-600" />
                <div>
                  <div className="text-xs font-bold">{t('pos:reintegrar_a_stock')}</div>
                  <div className="text-xs text-slate-500">{t('pos:no_se_elaboro_botella_intacta')}</div>
                </div>
              </button>
            </div>
          </div>

          {/* Autorización de Administrador */}
          <div className="pt-2 border-t border-slate-100">
            <label className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
              <KeyRound className="w-4 h-4 text-rose-600" />
              {t('pos:clave_de_administrador')}
            </label>

            {authorizedAdmin ? (
              <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-3 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                  <div>
                    <div className="text-xs font-bold text-emerald-900">{t('pos:autorizacion_confirmada')}</div>
                    <div className="text-xs text-emerald-700">{t('pos:administrador_2')}{' '}<strong className="font-semibold">{authorizedAdmin}</strong></div>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setAuthorizedAdmin(null);
                    setAdminPassword('');
                  }}
                  className="text-xs text-emerald-700 hover:text-emerald-900 underline font-semibold px-2 py-1"
                >
                  {t('pos:cambiar')}
                </button>
              </div>
            ) : (
              <div>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <input
                      type="password"
                      value={adminPassword}
                      onChange={(e) => {
                        setAdminPassword(e.target.value);
                        setAuthError(null);
                      }}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleVerifyAdmin();
                        }
                      }}
                      placeholder={t('pos:ingresa_pin_o_contrasena_de_admin')}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 transition-all font-mono"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => handleVerifyAdmin()}
                    disabled={isVerifying || !adminPassword.trim()}
                    className="px-4 py-2.5 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center gap-1.5 shrink-0"
                  >
                    {isVerifying ? t('pos:verificando') : t('pos:validar')}
                  </button>
                </div>
                {authError && (
                  <div className="flex items-center gap-1 text-rose-600 text-xs font-semibold mt-1.5">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{authError}</span>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={handleClose}
            className="px-4 py-3 rounded-xl border border-slate-200 text-slate-600 text-sm font-bold hover:bg-slate-100 transition-colors"
          >
            {t('pos:cancelar')}
          </button>

          <button
            type="button"
            onClick={handleSubmit}
            disabled={!authorizedAdmin || isSubmitting}
            className="flex-1 bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-700 hover:to-rose-800 text-white py-3 px-4 rounded-xl font-bold text-sm shadow-lg shadow-rose-200 transition-all flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed disabled:shadow-none"
          >
            <Trash2 className="w-4 h-4" />
            {isSubmitting ? t('pos:procesando') : t('pos:confirmar_anulacion_amount', { amount: formatCurrency(deductionTotal) })}
          </button>
        </div>
      </div>
    </div>
  );
};
