// ============================================
// COMPONENTS - Commercial Analytics & Comparison (Lantify POS)
// ============================================

import React, { useState, useEffect } from 'react';
import {
  BarChart3,
  TrendingUp,
  Calendar,
  Award,
  DollarSign,
  ShoppingBag,
  ArrowUpRight,
  ArrowDownRight,
  RefreshCw,
  CreditCard,
  Banknote,
  Smartphone,
  Zap
} from 'lucide-react';
import { formatCurrency } from '../../shared/formatUtils';
import { salesAPI, analyticsAPI } from '../../services/api';

import { t } from '../../i18n';
export const AnalyticsModule: React.FC = () => {
  const [activeSubTab, setActiveSubTab] = useState<'comparison' | 'products' | 'channels'>('comparison');

  // Meses disponibles para comparar
  const [availableMonths, setAvailableMonths] = useState<any[]>([]);
  const [loadingMonths, setLoadingMonths] = useState(true);

  // Claves de meses seleccionados para la comparativa (ej: ['2026-08', '2026-09'])
  const [selectedMonthKeys, setSelectedMonthKeys] = useState<string[]>([]);
  const [comparisonData, setComparisonData] = useState<any[]>([]);
  const [loadingCompare, setLoadingCompare] = useState(false);

  // Estado del reporte de productos estrella
  const [selectedProdYear, setSelectedProdYear] = useState<number>(0);
  const [selectedProdMonth, setSelectedProdMonth] = useState<number>(0);
  const [topProductsData, setTopProductsData] = useState<{
    items: any[];
    totalRevenue: number;
    totalUnits: number;
    periodLabel: string;
  }>({ items: [], totalRevenue: 0, totalUnits: 0, periodLabel: t('analytics:historico_total') });
  const [loadingProducts, setLoadingProducts] = useState(false);
  const [sortBy, setSortBy] = useState<'units' | 'revenue'>('units');

  // Estado del reporte por canales
  const [channelStats, setChannelStats] = useState<any>(null);
  const [loadingChannels, setLoadingChannels] = useState(false);

  // 1. Cargar lista de meses con ventas registradas
  const loadAvailableMonths = async () => {
    setLoadingMonths(true);
    try {
      const data = await salesAPI.getAvailableMonths();
      if (Array.isArray(data)) {
        setAvailableMonths(data);
        if (data.length >= 2) {
          const key1 = `${data[0].year}-${String(data[0].month).padStart(2, '0')}`;
          const key2 = `${data[1].year}-${String(data[1].month).padStart(2, '0')}`;
          setSelectedMonthKeys([key2, key1]);
        } else if (data.length === 1) {
          setSelectedMonthKeys([`${data[0].year}-${String(data[0].month).padStart(2, '0')}`]);
        }
      }
    } catch (err) {
      console.error('Error cargando meses disponibles:', err);
    } finally {
      setLoadingMonths(false);
    }
  };

  // 2. Cargar comparativa multi-mes
  const loadComparison = async (keys: string[]) => {
    if (keys.length === 0) {
      setComparisonData([]);
      return;
    }
    setLoadingCompare(true);
    try {
      const data = await analyticsAPI.compareMonths(keys);
      if (Array.isArray(data)) {
        setComparisonData(data);
      }
    } catch (err) {
      console.error('Error cargando comparativa:', err);
    } finally {
      setLoadingCompare(false);
    }
  };

  // 3. Cargar reporte de productos más vendidos
  const loadTopProducts = async (year?: number, month?: number) => {
    setLoadingProducts(true);
    try {
      const data = await analyticsAPI.getTopProducts(year, month);
      if (data && data.items) {
        setTopProductsData(data);
      }
    } catch (err) {
      console.error('Error cargando top productos:', err);
    } finally {
      setLoadingProducts(false);
    }
  };

  // 4. Cargar analítica por canales
  const loadChannelStats = async () => {
    setLoadingChannels(true);
    try {
      const data = await analyticsAPI.getChannelStats();
      if (data) {
        setChannelStats(data);
      }
    } catch (err) {
      console.error('Error loading channel stats:', err);
    } finally {
      setLoadingChannels(false);
    }
  };

  useEffect(() => {
    loadAvailableMonths();
    loadTopProducts();
    loadChannelStats();
  }, []);

  useEffect(() => {
    if (selectedMonthKeys.length > 0) {
      loadComparison(selectedMonthKeys);
    }
  }, [selectedMonthKeys]);

  const toggleMonthSelection = (key: string) => {
    setSelectedMonthKeys(prev => {
      if (prev.includes(key)) {
        return prev.filter(k => k !== key);
      } else {
        return [...prev, key].sort();
      }
    });
  };

  const handleProductMonthChange = (val: string) => {
    if (val === 'all') {
      setSelectedProdYear(0);
      setSelectedProdMonth(0);
      loadTopProducts();
    } else {
      const [y, m] = val.split('-').map(Number);
      setSelectedProdYear(y);
      setSelectedProdMonth(m);
      loadTopProducts(y, m);
    }
  };

  const sortedProducts = [...(topProductsData.items || [])].sort((a, b) => {
    return sortBy === 'units' ? b.unitsSold - a.unitsSold : b.totalRevenue - a.totalRevenue;
  });

  const maxRevenueCompare = Math.max(...comparisonData.map(m => m.totalRevenue), 1);

  if (loadingMonths) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] gap-4">
        <div className="w-12 h-12 border-4 border-slate-200 border-t-blue-600 rounded-full animate-spin" />
        <p className="text-sm font-bold text-slate-700 animate-pulse">{t('analytics:cargando_modulo_de_estadisticas_lantify')}</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-12 font-sans">
      {/* ── Encabezado y Navegación de Sub-Pestañas ── */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-slate-900 mb-1">
            <div className="p-2 bg-blue-50 text-blue-600 rounded-xl">
              <TrendingUp className="w-5 h-5" />
            </div>
            <h1 className="text-2xl font-extrabold tracking-tight font-heading">{t('analytics:analisis_comercial_y_metricas')}</h1>
          </div>
          <p className="text-xs text-slate-500 font-medium">
            {t('analytics:estadisticas_comparativas_de_ventas_demanda_de_cat')}
          </p>
        </div>

        {/* Botones de navegación de sub-pestaña */}
        <div className="flex items-center gap-1.5 bg-slate-100 p-1.5 rounded-2xl border border-slate-200 w-full md:w-auto">
          <button
            onClick={() => setActiveSubTab('comparison')}
            className={`flex-1 md:flex-none flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeSubTab === 'comparison'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            <span>{t('analytics:comparativa_multi_mes')}</span>
          </button>
          <button
            onClick={() => setActiveSubTab('products')}
            className={`flex-1 md:flex-none flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeSubTab === 'products'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
            }`}
          >
            <Award className="w-4 h-4" />
            <span>{t('analytics:productos_estrella')}</span>
          </button>
          <button
            onClick={() => setActiveSubTab('channels')}
            className={`flex-1 md:flex-none flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeSubTab === 'channels'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
            }`}
          >
            <Zap className="w-4 h-4" />
            <span>{t('analytics:canales_omnicanal')}</span>
          </button>
        </div>
      </div>

      {/* ════════════════════════════════════════════════════════════════════ */}
      {/* VISTA 1: COMPARATIVA MULTI-MES                                      */}
      {/* ════════════════════════════════════════════════════════════════════ */}
      {activeSubTab === 'comparison' && (
        <div className="space-y-6">
          {/* Selector de Meses para Comparar */}
          <div className="bg-slate-50 rounded-3xl border border-slate-200 p-6 shadow-sm">
            <div className="flex items-center gap-2 mb-3">
              <Calendar className="w-4 h-4 text-blue-600" />
              <span className="text-xs font-bold uppercase tracking-wider text-slate-700">
                {t('analytics:selecciona_los_meses_a_contrastar_puedes_elegir')}
              </span>
            </div>

            <div className="flex flex-wrap gap-2.5">
              {availableMonths.map((m: any) => {
                const key = `${m.year}-${String(m.month).padStart(2, '0')}`;
                const isSelected = selectedMonthKeys.includes(key);
                return (
                  <button
                    key={key}
                    onClick={() => toggleMonthSelection(key)}
                    className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all border ${
                      isSelected
                        ? 'bg-slate-900 text-white border-slate-900 shadow-sm'
                        : 'bg-white text-slate-700 border-slate-200 hover:border-blue-400'
                    }`}
                  >
                    <div className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${isSelected ? 'bg-blue-500 border-blue-600' : 'border-slate-300'}`}>
                      {isSelected && <div className="w-1.5 h-1.5 bg-white rounded-full" />}
                    </div>
                    <span>{m.label}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-bold tabular-nums ${isSelected ? 'bg-slate-800 text-slate-200' : 'bg-slate-100 text-slate-600'}`}>
                      {formatCurrency(m.totalRevenue)}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Gráfico Comparativo Visual de Ingresos */}
          {loadingCompare ? (
            <div className="bg-white rounded-3xl p-12 border border-slate-200 flex flex-col items-center justify-center gap-3">
              <RefreshCw className="w-8 h-8 text-blue-600 animate-spin" />
              <p className="text-xs font-bold text-slate-500">{t('analytics:calculando_analitica_comparativa')}</p>
            </div>
          ) : comparisonData.length === 0 ? (
            <div className="bg-white rounded-3xl p-12 text-center text-slate-400 border border-slate-200 font-medium text-sm">
              {t('analytics:selecciona_al_menos_un_mes_arriba_para')}
            </div>
          ) : (
            <>
              {/* Gráfico de Barras de Ingresos por Mes */}
              <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h3 className="text-base font-bold text-slate-900 tracking-tight font-heading">{t('analytics:comparativa_de_ingresos_totales')}</h3>
                    <p className="text-xs text-slate-500">{t('analytics:contraste_de_recaudacion_entre_los_meses_seleccion')}</p>
                  </div>
                  <span className="text-xs font-bold bg-blue-50 text-blue-700 px-3 py-1.5 rounded-xl border border-blue-200">
                    {t('analytics:length_meses_contrastados', { length: comparisonData.length })}
                  </span>
                </div>

                {/* Barras con gradiente moderno */}
                <div className="space-y-4 pt-2">
                  {comparisonData.map((item) => {
                    const pct = Math.round((item.totalRevenue / maxRevenueCompare) * 100);
                    return (
                      <div key={item.monthKey} className="space-y-1.5">
                        <div className="flex items-center justify-between text-xs font-bold">
                          <span className="text-slate-800 font-bold w-36">{item.label}</span>
                          <span className="text-emerald-600 font-black text-sm tabular-nums">{formatCurrency(item.totalRevenue)}</span>
                        </div>
                        <div className="w-full bg-slate-100 h-7 rounded-xl overflow-hidden p-1 border border-slate-200 flex items-center relative">
                          <div
                            className="h-full rounded-lg transition-all duration-700 flex items-center justify-end pr-2 bg-gradient-to-r from-blue-600 to-indigo-600 shadow-sm"
                            style={{ width: `${Math.max(pct, 4)}%` }}
                          >
                            {pct > 15 && <span className="text-xs font-bold text-white tabular-nums">{pct}%</span>}
                          </div>
                          {pct <= 15 && <span className="text-xs font-bold text-slate-600 ml-2 tabular-nums">{pct}%</span>}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Tarjetas de Métricas Comparativas Lado a Lado */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {comparisonData.map((item, idx) => {
                  const prevItem = idx > 0 ? comparisonData[idx - 1] : null;
                  let diffPct = 0;
                  if (prevItem && prevItem.totalRevenue > 0) {
                    diffPct = Math.round(((item.totalRevenue - prevItem.totalRevenue) / prevItem.totalRevenue) * 100);
                  }

                  return (
                    <div key={item.monthKey} className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm hover:border-blue-300 transition-all">
                      <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-3">
                        <span className="font-extrabold text-lg text-slate-900 font-heading">{item.label}</span>
                        {prevItem && (
                          <span className={`inline-flex items-center gap-1 text-xs font-bold px-2.5 py-1 rounded-full ${
                            diffPct >= 0 ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-red-50 text-red-700 border border-red-200'
                          }`}>
                            {diffPct >= 0 ? <ArrowUpRight className="w-3.5 h-3.5" /> : <ArrowDownRight className="w-3.5 h-3.5" />}
                            {t('analytics:value_vs_anterior', { value: diffPct >= 0 ? `+${diffPct}%` : `${diffPct}%` })}
                          </span>
                        )}
                      </div>

                      <div className="space-y-4">
                        {/* Ingresos */}
                        <div>
                          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">{t('analytics:ingresos_totales')}</p>
                          <p className="text-2xl font-black text-slate-900 tabular-nums font-heading">{formatCurrency(item.totalRevenue)}</p>
                        </div>

                        <div className="grid grid-cols-2 gap-3 text-xs">
                          <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200/60">
                            <p className="text-xs font-bold text-slate-400 uppercase">{t('analytics:ventas')}</p>
                            <p className="text-base font-bold text-slate-800 tabular-nums">{item.completedCount}</p>
                          </div>
                          <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200/60">
                            <p className="text-xs font-bold text-slate-400 uppercase">{t('analytics:ticket_prom')}</p>
                            <p className="text-base font-bold text-slate-800 tabular-nums">{formatCurrency(item.avgTicket)}</p>
                          </div>
                        </div>

                        {/* Desglose Métodos de Pago */}
                        <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200/60 space-y-2 text-xs">
                          <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">{t('analytics:metodos_de_pago')}</p>
                          <div className="flex justify-between items-center">
                            <span className="flex items-center gap-1 font-semibold text-slate-600"><Banknote className="w-3.5 h-3.5 text-emerald-600" />{' '}{t('analytics:efectivo')}</span>
                            <span className="font-bold text-slate-900 tabular-nums">{formatCurrency(item.paymentBreakdown.CASH)}</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="flex items-center gap-1 font-semibold text-slate-600"><CreditCard className="w-3.5 h-3.5 text-blue-600" />{' '}{t('analytics:tarjeta')}</span>
                            <span className="font-bold text-slate-900 tabular-nums">{formatCurrency(item.paymentBreakdown.CARD)}</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="flex items-center gap-1 font-semibold text-slate-600"><Smartphone className="w-3.5 h-3.5 text-indigo-600" />{' '}{t('analytics:transferencia')}</span>
                            <span className="font-bold text-slate-900 tabular-nums">{formatCurrency(item.paymentBreakdown.TRANSFER)}</span>
                          </div>
                        </div>

                        {/* Top 3 Productos de este mes */}
                        <div>
                          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2 flex items-center gap-1">
                            <Award className="w-3.5 h-3.5 text-blue-600" />{' '}{t('analytics:top_3_productos_del_mes')}
                          </p>
                          <div className="space-y-1.5">
                            {item.topProducts.map((p: any, pIdx: number) => (
                              <div key={pIdx} className="flex items-center justify-between text-xs bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200/60">
                                <span className="truncate max-w-[150px] font-semibold text-slate-700">
                                  #{pIdx + 1} {p.name} {p.variantName ? `(${p.variantName})` : ''}
                                </span>
                                <span className="font-bold text-slate-900 tabular-nums">{p.units}{' '}{t('analytics:un')}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </div>
      )}

      {/* ════════════════════════════════════════════════════════════════════ */}
      {/* VISTA 2: REPORTE DETALLADO DE PRODUCTOS ESTRELLA Y DEMANDA          */}
      {/* ════════════════════════════════════════════════════════════════════ */}
      {activeSubTab === 'products' && (
        <div className="space-y-6">
          {/* Filtros del reporte de productos */}
          <div className="bg-slate-50 rounded-3xl border border-slate-200 p-6 shadow-sm flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
            {/* Selector de Mes o Histórico Total */}
            <div className="flex flex-col gap-1 min-w-[260px]">
              <label className="text-xs font-bold uppercase tracking-widest text-slate-600 flex items-center gap-1 px-1">
                <Calendar className="w-3.5 h-3.5 text-blue-600" />{' '}{t('analytics:periodo_del_reporte')}
              </label>
              <select
                value={selectedProdYear === 0 ? 'all' : `${selectedProdYear}-${String(selectedProdMonth).padStart(2, '0')}`}
                onChange={e => handleProductMonthChange(e.target.value)}
                className="text-xs font-bold px-4 py-2.5 border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 focus:outline-none transition-all cursor-pointer text-slate-800 shadow-xs"
              >
                <option value="all">{t('analytics:historico_total_todas_las_ventas')}</option>
                {availableMonths.map((m: any) => {
                  const key = `${m.year}-${String(m.month).padStart(2, '0')}`;
                  return (
                    <option key={key} value={key}>
                      {t('analytics:label_count_ventas_amount', { label: m.label, count: m.count, amount: formatCurrency(m.totalRevenue) })}
                    </option>
                  );
                })}
              </select>
            </div>

            {/* Selector de Criterio de Ordenamiento */}
            <div className="flex items-center gap-1.5 bg-slate-200/70 p-1.5 rounded-2xl border border-slate-300/60">
              <button
                onClick={() => setSortBy('units')}
                className={`flex-1 md:flex-none flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all ${
                  sortBy === 'units'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <ShoppingBag className="w-4 h-4 text-blue-600" />
                <span>{t('analytics:mas_vendidos_unidades')}</span>
              </button>
              <button
                onClick={() => setSortBy('revenue')}
                className={`flex-1 md:flex-none flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all ${
                  sortBy === 'revenue'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <DollarSign className="w-4 h-4 text-emerald-600" />
                <span>{t('analytics:mayor_recaudacion')}</span>
              </button>
            </div>
          </div>

          {/* Tarjetas KPI de Productos */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-slate-900 text-white rounded-3xl p-6 shadow-md border border-slate-800">
              <p className="text-blue-400 text-xs uppercase font-bold tracking-widest mb-1">
                {t('analytics:recaudacion_de_catalogo')}
              </p>
              <h3 className="text-3xl font-black tabular-nums font-heading">{formatCurrency(topProductsData.totalRevenue)}</h3>
              <p className="text-xs text-slate-400 font-medium mt-2">{topProductsData.periodLabel}</p>
            </div>

            <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200">
              <p className="text-slate-400 text-xs uppercase font-bold tracking-widest mb-1">
                {t('analytics:total_unidades_comercializadas')}
              </p>
              <h3 className="text-3xl font-black text-slate-900 tabular-nums font-heading">{topProductsData.totalUnits}{' '}{t('analytics:un')}</h3>
              <p className="text-xs text-slate-500 font-medium mt-2">{t('analytics:productos_despachados')}</p>
            </div>

            <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200">
              <p className="text-slate-400 text-xs uppercase font-bold tracking-widest mb-1">
                {t('analytics:variedad_con_salida')}
              </p>
              <h3 className="text-3xl font-black text-slate-900 tabular-nums font-heading">{sortedProducts.length}{' '}{t('analytics:items')}</h3>
              <p className="text-xs text-slate-500 font-medium mt-2">{t('analytics:variantes_vendidas_en_el_periodo')}</p>
            </div>
          </div>

          {/* Tabla de Ranking de Productos */}
          {loadingProducts ? (
            <div className="bg-white rounded-3xl p-12 border border-slate-200 flex flex-col items-center justify-center gap-3">
              <RefreshCw className="w-8 h-8 text-blue-600 animate-spin" />
              <p className="text-xs font-bold text-slate-500">{t('analytics:analizando_demanda_de_productos')}</p>
            </div>
          ) : sortedProducts.length === 0 ? (
            <div className="bg-white rounded-3xl p-12 text-center text-slate-400 border border-slate-200 font-medium">
              {t('analytics:no_se_encontraron_ventas_de_productos_para')}
            </div>
          ) : (
            <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm">
              <div className="p-6 border-b border-slate-100 flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-slate-900 tracking-tight font-heading">
                    {t('analytics:ranking_de_demanda_periodlabel', { periodLabel: topProductsData.periodLabel })}
                  </h3>
                  <p className="text-xs text-slate-500 font-medium">
                    {t('analytics:ordenado_por_value', { value: sortBy === 'units' ? t('analytics:unidades_vendidas') : t('analytics:ingresos_generados') })}
                  </p>
                </div>
                <span className="text-xs font-bold bg-slate-100 text-slate-700 px-3 py-1.5 rounded-xl border border-slate-200">
                  {t('analytics:length_productos_registrados', { length: sortedProducts.length })}
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-xs tracking-wider border-b border-slate-100">
                    <tr>
                      <th className="py-4 px-6">{t('analytics:posicion')}</th>
                      <th className="py-4 px-6">{t('analytics:producto_variante')}</th>
                      <th className="py-4 px-6">{t('analytics:categoria')}</th>
                      <th className="py-4 px-6 text-right">{t('analytics:unidades')}</th>
                      <th className="py-4 px-6 text-right">{t('analytics:precio_promedio')}</th>
                      <th className="py-4 px-6 text-right">{t('analytics:recaudado')}</th>
                      <th className="py-4 px-6 w-44">{t('analytics:participacion')}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium text-slate-800">
                    {sortedProducts.map((prod, idx) => {
                      const sharePct = sortBy === 'units' ? prod.volumeSharePct : prod.revenueSharePct;
                      const isTop3 = idx < 3;
                      const medal = idx === 0 ? '🥇' : idx === 1 ? '🥈' : idx === 2 ? '🥉' : `#${idx + 1}`;

                      return (
                        <tr key={prod.variantId} className={`hover:bg-slate-50/80 transition-colors ${isTop3 ? 'bg-blue-50/20 font-semibold' : ''}`}>
                          <td className="py-4 px-6 text-sm font-bold">
                            <span className={`inline-flex items-center justify-center w-8 h-8 rounded-xl ${
                              idx === 0 ? 'bg-amber-100 text-amber-800 border border-amber-200' :
                              idx === 1 ? 'bg-slate-100 text-slate-700 border border-slate-200' :
                              idx === 2 ? 'bg-orange-50 text-orange-800 border border-orange-200' : 'text-slate-400'
                            }`}>
                              {medal}
                            </span>
                          </td>
                          <td className="py-4 px-6">
                            <div className="font-bold text-slate-900 text-sm">{prod.productName}</div>
                            {prod.variantName && (
                              <div className="text-xs text-slate-500">{prod.variantName}</div>
                            )}
                          </td>
                          <td className="py-4 px-6">
                            <span className="bg-slate-100 text-slate-600 px-2.5 py-1 rounded-lg text-xs font-bold">
                              {prod.categoryName}
                            </span>
                          </td>
                          <td className="py-4 px-6 text-right text-sm font-extrabold text-slate-900 tabular-nums">
                            {t('analytics:unitssold_un', { unitsSold: prod.unitsSold })}
                          </td>
                          <td className="py-4 px-6 text-right font-medium text-slate-600 tabular-nums">
                            {formatCurrency(prod.unitPrice)}
                          </td>
                          <td className="py-4 px-6 text-right text-sm font-black text-emerald-600 tabular-nums">
                            {formatCurrency(prod.totalRevenue)}
                          </td>
                          <td className="py-4 px-6">
                            <div className="flex items-center gap-2">
                              <div className="flex-1 bg-slate-100 h-2.5 rounded-full overflow-hidden p-0.5 border border-slate-200">
                                <div
                                  className="h-full bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full transition-all duration-500"
                                  style={{ width: `${Math.max(sharePct, 2)}%` }}
                                />
                              </div>
                              <span className="text-xs font-bold text-slate-600 w-10 text-right tabular-nums">
                                {sharePct.toFixed(1)}%
                              </span>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ════════════════════════════════════════════════════════════════════ */}
      {/* VISTA 3: VENTAS POR CANAL (RAPPI, WHATSAPP, WEB, SALÓN)             */}
      {/* ════════════════════════════════════════════════════════════════════ */}
      {activeSubTab === 'channels' && (
        <div className="space-y-6">
          {/* Top summary card */}
          <div className="bg-slate-900 text-white p-6 rounded-3xl shadow-md border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="p-2 bg-blue-600/20 text-blue-400 rounded-xl">
                  <Zap className="w-5 h-5" />
                </span>
                <h2 className="text-xl font-bold tracking-tight font-heading">{t('analytics:rendimiento_multicanal')}</h2>
              </div>
              <p className="text-xs text-slate-400 max-w-xl">
                {t('analytics:monitorea_en_tiempo_real_que_porcentaje_de')}
              </p>
            </div>

            <button
              onClick={loadChannelStats}
              disabled={loadingChannels}
              className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-xs shadow-md transition-all flex items-center gap-2 disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 ${loadingChannels ? 'animate-spin' : ''}`} />
              {t('analytics:actualizar_canales')}
            </button>
          </div>

          {loadingChannels || !channelStats ? (
            <div className="flex flex-col items-center justify-center h-48 gap-3">
              <div className="w-10 h-10 border-4 border-slate-200 border-t-blue-600 rounded-full animate-spin" />
              <p className="text-xs font-bold text-slate-500">{t('analytics:calculando_ventas_por_canal')}</p>
            </div>
          ) : (
            <>
              {/* 4 Channel KPI Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {/* 1. Salón / Mesas */}
                {(() => {
                  const posData = channelStats.channels?.POS || { count: 0, total: 0 };
                  const share = channelStats.grandTotal > 0 ? (posData.total / channelStats.grandTotal) * 100 : 0;
                  return (
                    <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                          <span className="w-2.5 h-2.5 rounded-full bg-blue-600"></span>{' '}{t('analytics:salon_mesas')}
                        </span>
                        <span className="text-xs font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded-lg tabular-nums">
                          {share.toFixed(1)}%
                        </span>
                      </div>
                      <div>
                        <span className="text-2xl font-black text-slate-900 tabular-nums font-heading">{formatCurrency(posData.total)}</span>
                        <span className="text-xs text-slate-400 font-semibold block mt-0.5">{posData.count}{' '}{t('analytics:pedidos')}</span>
                      </div>
                      <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                        <div className="h-full bg-blue-600 rounded-full" style={{ width: `${Math.max(share, 3)}%` }} />
                      </div>
                    </div>
                  );
                })()}

                {/* 2. Rappi Delivery */}
                {(() => {
                  const rappiData = channelStats.channels?.RAPPI || { count: 0, total: 0 };
                  const share = channelStats.grandTotal > 0 ? (rappiData.total / channelStats.grandTotal) * 100 : 0;
                  return (
                    <div className="bg-white rounded-3xl p-5 border border-orange-200 shadow-sm space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-orange-800 uppercase tracking-wider flex items-center gap-1.5">
                          <span className="w-2.5 h-2.5 rounded-full bg-orange-500"></span>{' '}{t('analytics:rappi_delivery')}
                        </span>
                        <span className="text-xs font-bold text-orange-800 bg-orange-100 px-2 py-0.5 rounded-lg tabular-nums">
                          {share.toFixed(1)}%
                        </span>
                      </div>
                      <div>
                        <span className="text-2xl font-black text-orange-600 tabular-nums font-heading">{formatCurrency(rappiData.total)}</span>
                        <span className="text-xs text-slate-400 font-semibold block mt-0.5">{rappiData.count}{' '}{t('analytics:pedidos')}</span>
                      </div>
                      <div className="w-full bg-orange-100 h-2 rounded-full overflow-hidden">
                        <div className="h-full bg-orange-500 rounded-full" style={{ width: `${Math.max(share, 3)}%` }} />
                      </div>
                    </div>
                  );
                })()}

                {/* 3. WhatsApp Bot */}
                {(() => {
                  const waData = channelStats.channels?.WHATSAPP || { count: 0, total: 0 };
                  const share = channelStats.grandTotal > 0 ? (waData.total / channelStats.grandTotal) * 100 : 0;
                  return (
                    <div className="bg-white rounded-3xl p-5 border border-emerald-200 shadow-sm space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-emerald-800 uppercase tracking-wider flex items-center gap-1.5">
                          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>{' '}{t('analytics:whatsapp_bot')}
                        </span>
                        <span className="text-xs font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-lg tabular-nums">
                          {share.toFixed(1)}%
                        </span>
                      </div>
                      <div>
                        <span className="text-2xl font-black text-emerald-700 tabular-nums font-heading">{formatCurrency(waData.total)}</span>
                        <span className="text-xs text-slate-400 font-semibold block mt-0.5">{waData.count}{' '}{t('analytics:pedidos')}</span>
                      </div>
                      <div className="w-full bg-emerald-100 h-2 rounded-full overflow-hidden">
                        <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${Math.max(share, 3)}%` }} />
                      </div>
                    </div>
                  );
                })()}

                {/* 4. Tienda Web */}
                {(() => {
                  const webData = channelStats.channels?.WEB || { count: 0, total: 0 };
                  const share = channelStats.grandTotal > 0 ? (webData.total / channelStats.grandTotal) * 100 : 0;
                  return (
                    <div className="bg-white rounded-3xl p-5 border border-sky-200 shadow-sm space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-sky-800 uppercase tracking-wider flex items-center gap-1.5">
                          <span className="w-2.5 h-2.5 rounded-full bg-sky-500"></span>{' '}{t('analytics:tienda_web')}
                        </span>
                        <span className="text-xs font-bold text-sky-800 bg-sky-100 px-2 py-0.5 rounded-lg tabular-nums">
                          {share.toFixed(1)}%
                        </span>
                      </div>
                      <div>
                        <span className="text-2xl font-black text-sky-700 tabular-nums font-heading">{formatCurrency(webData.total)}</span>
                        <span className="text-xs text-slate-400 font-semibold block mt-0.5">{webData.count}{' '}{t('analytics:pedidos')}</span>
                      </div>
                      <div className="w-full bg-sky-100 h-2 rounded-full overflow-hidden">
                        <div className="h-full bg-sky-500 rounded-full" style={{ width: `${Math.max(share, 3)}%` }} />
                      </div>
                    </div>
                  );
                })()}
              </div>

              {/* Comparative Multi-Channel Bar */}
              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-base font-bold text-slate-900 font-heading">{t('analytics:distribucion_de_ingresos_por_canal')}</h3>
                    <p className="text-xs text-slate-400">{t('analytics:total_global_acumulado')}{' '}{formatCurrency(channelStats.grandTotal)}</p>
                  </div>
                  <span className="text-xs font-bold text-slate-700 bg-slate-100 px-3 py-1 rounded-xl">
                    {t('analytics:totalsales_pedidos_totales', { totalSales: channelStats.totalSales })}
                  </span>
                </div>

                {/* Stacked Percentage Bar */}
                <div className="w-full h-8 bg-slate-100 rounded-xl overflow-hidden flex p-1 gap-1 border border-slate-200 shadow-inner">
                  {Object.entries(channelStats.channels as Record<string, { count: number; total: number }>).map(([ch, data]) => {
                    const pct = channelStats.grandTotal > 0 ? (data.total / channelStats.grandTotal) * 100 : 0;
                    if (pct <= 0) return null;
                    const colors: Record<string, string> = {
                      POS: 'bg-blue-600',
                      RAPPI: 'bg-orange-500',
                      WHATSAPP: 'bg-emerald-500',
                      WEB: 'bg-sky-500'
                    };
                    return (
                      <div
                        key={ch}
                        className={`${colors[ch] || 'bg-slate-400'} h-full rounded-lg transition-all duration-700 flex items-center justify-center text-xs font-bold text-white px-2`}
                        style={{ width: `${pct}%` }}
                        title={`${ch}: ${pct.toFixed(1)}% (${formatCurrency(data.total)})`}
                      >
                        {pct > 8 && `${pct.toFixed(0)}%`}
                      </div>
                    );
                  })}
                </div>

                {/* Legend */}
                <div className="flex flex-wrap items-center justify-center gap-6 pt-2 text-xs font-bold text-slate-600">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-blue-600"></span>
                    <span>{t('analytics:salon_mesas')}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-orange-500"></span>
                    <span>Rappi</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                    <span>{t('analytics:whatsapp_bot')}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-sky-500"></span>
                    <span>{t('analytics:tienda_web')}</span>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
};

export default AnalyticsModule;
