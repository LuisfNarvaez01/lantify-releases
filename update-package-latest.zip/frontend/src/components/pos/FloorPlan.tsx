import { CANVAS } from '../../../../src/domain/floorLayout';
import { API_URL } from '../../config';
// ============================================
// COMPONENTS - Plano del establecimiento
// ============================================
// Un solo componente con dos usos:
//  - Operación (editor=false): solo lectura; tocar una mesa abre el pedido.
//  - Editor (editor=true): Administración → Salón y mesas. Crear, numerar, mover,
//    redimensionar, asignar zona y eliminar mesas en el mismo plano.
// Comparte datos y estados con la vista operativa (mismo usePosStore).

import { useFloor } from '../../shared/features';
import { TableRequests } from '../floor/TableRequests';
import React, { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { Users, Clock, Maximize2, Plus, Trash2, CopyPlus, Minus, List, Map as MapIcon } from 'lucide-react';
import { Segmented } from '../ui';
import { switchTableView } from '../../shared/posSettings';
import { usePosStore } from '../../store/usePosStore';
import { tablesAPI } from '../../services/api';
import { formatCurrency } from '../../shared/formatUtils';
import { useTableSelection, useTableSummaries, useTableLook, TABLE_STATUS_META } from './tableSelection';
import type { Table } from '../../types';
import { toast } from '../../shared/toast';
import { errorMessage } from '../../services/apiErrors';
import { confirmDialog, promptDialog } from '../../shared/dialog';

import { t as tr } from '../../i18n';
const DEFAULT_W = 132;
const DEFAULT_H = 104;
const MIN_SIZE = 88;
const MAX_SIZE = 320;
const GAP = 20;
// El mismo lienzo del editor del plano
const CANVAS_W = CANVAS.width;
const CANVAS_H = CANVAS.height;
const NO_ZONE = '__none__';

interface FloorPlanProps {
  onTableSelect?: (table: Table) => void;
  editor?: boolean;
}

const sizeOf = (t: Table) => ({ w: t.width || DEFAULT_W, h: t.height || DEFAULT_H });

const autoPosition = (index: number) => {
  const perRow = Math.floor((CANVAS_W - GAP) / (DEFAULT_W + GAP));
  return {
    x: GAP + (index % perRow) * (DEFAULT_W + GAP),
    y: GAP + Math.floor(index / perRow) * (DEFAULT_H + GAP),
  };
};

const elapsed = (iso?: string) => {
  if (!iso) return '';
  const mins = Math.floor((Date.now() - new Date(iso).getTime()) / 60000);
  return mins < 60 ? `${Math.max(mins, 0)} min` : `${Math.floor(mins / 60)} h`;
};

const ELEMENT_LOOK: Record<string, string> = {
  wall: 'bg-slate-700', door: 'bg-amber-300', window: 'bg-sky-200', bar: 'bg-amber-800/80 text-white', kitchen: 'bg-orange-100 border-2 border-dashed border-orange-300 text-orange-900',
  bathroom: 'bg-sky-50 border-2 border-dashed border-sky-300 text-sky-900', plant: 'bg-emerald-400 rounded-full', text: 'text-slate-600 font-black', zone: 'bg-indigo-50/40 border-2 border-dashed border-indigo-200 text-indigo-700',
};

export const FloorPlan: React.FC<FloorPlanProps> = ({ onTableSelect, editor = false }) => {
  const { tables, selectedTable, fetchTables } = usePosStore();
  const select = useTableSelection();
  const summaryOf = useTableSummaries();
  const lookOf = useTableLook();
  useFloor();
  useEffect(() => {
    if (editor) fetchTables();
  }, [editor]);
  const [zoneFilter, setZoneFilter] = useState<string>('ALL');
  // Operación: el plano se ajusta al espacio visible; zoom manual opcional. En el editor va a 100 %.
  const [zoom, setZoom] = useState<number | 'fit'>('fit');
  const [statusFilter, setStatusFilter] = useState<string | null>(null);
  const viewportRef = useRef<HTMLDivElement>(null);
  const [viewport, setViewport] = useState({ w: 0, h: 0 });
  useLayoutEffect(() => {
    const el = viewportRef.current;
    if (!el || editor) return;
    const read = () => setViewport({ w: el.clientWidth, h: el.clientHeight });
    read();
    const ro = new ResizeObserver(read);
    ro.observe(el);
    return () => ro.disconnect();
  }, [editor]);
  // Paredes, barra, cocina… dibujadas en el editor del plano
  const [elements, setElements] = useState<{ id: string; kind: string; zone: string | null; x: number; y: number; w: number; h: number; rotation: number; label: string | null }[]>([]);
  useEffect(() => {
    if (editor) return;
    fetch(`${API_URL}/floor/layout`, { headers: { Authorization: `Bearer ${localStorage.getItem('token') || ''}` } })
      .then((r) => (r.ok ? r.json() : null)).then((d) => setElements(d?.elements || [])).catch(() => setElements([]));
  }, [editor]);
  const zoneFilterOk = (z: string | null) => zoneFilter === 'ALL' || (zoneFilter === NO_ZONE ? !z : z === zoneFilter);
  const [drag, setDrag] = useState<{ id: string; x: number; y: number } | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const canvasRef = useRef<HTMLDivElement>(null);
  const offset = useRef({ dx: 0, dy: 0 });
  const moved = useRef(false);

  const zones = useMemo(
    () => Array.from(new Set(tables.map(t => t.zone).filter((z): z is string => !!z))).sort(),
    [tables]
  );
  const hasUnzoned = tables.some(t => !t.zone);

  const visible = tables.filter(t => {
    if (zoneFilter === 'ALL') return true;
    if (zoneFilter === NO_ZONE) return !t.zone;
    return t.zone === zoneFilter;
  });

  const posOf = (t: Table) => {
    if (drag?.id === t.id) return { x: drag.x, y: drag.y };
    if (t.positionX != null && t.positionY != null && (t.positionX > 0 || t.positionY > 0)) {
      return { x: t.positionX, y: t.positionY };
    }
    return autoPosition(tables.findIndex(x => x.id === t.id));
  };

  const clamp = (v: number, max: number) => Math.min(Math.max(v, 0), Math.max(max, 0));

  /** Guarda un cambio de la mesa; devuelve false si el servidor lo rechazó */
  const save = async (id: string, data: Record<string, unknown>) => {
    setSaving(true);
    try {
      await tablesAPI.update(id, data);
      await fetchTables();
      return true;
    } catch (err) {
      toast.error(errorMessage(err), tr('pos:no_se_pudo_guardar_la_mesa'));
      return false;
    } finally {
      setSaving(false);
    }
  };

  // ── Crear y eliminar (solo editor) ─────────────────────────
  /** Siguiente número libre: el mayor número entero + 1 */
  const nextNumber = (taken: string[]) => {
    const nums = taken.map((n) => parseInt(n, 10)).filter((n) => Number.isFinite(n));
    return String((nums.length ? Math.max(...nums) : 0) + 1);
  };

  /** Primer hueco de la cuadrícula que no pisa otra mesa */
  const freeSpot = (occupied: { x: number; y: number; w: number; h: number }[]) => {
    for (let i = 0; i < 200; i++) {
      const p = autoPosition(i);
      if (p.y + DEFAULT_H > CANVAS_H) break;
      const clash = occupied.some((o) => p.x < o.x + o.w && p.x + DEFAULT_W > o.x && p.y < o.y + o.h && p.y + DEFAULT_H > o.y);
      if (!clash) return p;
    }
    return { x: GAP, y: GAP };
  };

  const addTables = async (count: number) => {
    setSaving(true);
    const numbers = tables.map((t) => t.number);
    const occupied = tables.map((t) => ({ ...posOf(t), ...{ w: sizeOf(t).w, h: sizeOf(t).h } }));
    const zone = zoneFilter !== 'ALL' && zoneFilter !== NO_ZONE ? zoneFilter : null;
    let lastId: string | null = null;
    try {
      for (let i = 0; i < count; i++) {
        const number = nextNumber(numbers);
        const spot = freeSpot(occupied);
        const created = await tablesAPI.create({ number, capacity: 4, positionX: spot.x, positionY: spot.y, zone });
        numbers.push(number);
        occupied.push({ ...spot, w: DEFAULT_W, h: DEFAULT_H });
        lastId = created?.id || lastId;
      }
      await fetchTables();
      if (lastId) setEditingId(lastId);
    } catch (err) {
      toast.error(errorMessage(err), tr('pos:no_se_pudo_crear_la_mesa'));
      await fetchTables();
    } finally {
      setSaving(false);
    }
  };

  const addSeveral = async () => {
    const answer = await promptDialog({
      title: tr('pos:agregar_varias_mesas'),
      label: tr('pos:cuantas_mesas'),
      defaultValue: '4',
      inputMode: 'numeric',
      confirmLabel: tr('pos:agregar'),
    });
    const n = Math.round(Number(answer));
    if (!answer || !Number.isFinite(n) || n < 1) return;
    await addTables(Math.min(n, 40));
  };

  const removeTable = async (t: Table) => {
    const ok = await confirmDialog({
      title: tr('pos:eliminar_mesa_n', { n: t.number }),
      message: tr('pos:eliminar_mesa_desc'),
      confirmLabel: tr('pos:eliminar'),
      tone: 'danger',
    });
    if (!ok) return;
    try {
      await tablesAPI.delete(t.id);
      setEditingId(null);
      await fetchTables();
    } catch (err) {
      toast.error(errorMessage(err), tr('pos:no_se_pudo_eliminar_la_mesa'));
    }
  };

  const onPointerDown = (e: React.PointerEvent, t: Table) => {
    if (!editor) return;
    e.preventDefault();
    const rect = canvasRef.current!.getBoundingClientRect();
    const p = posOf(t);
    offset.current = { dx: e.clientX - rect.left - p.x, dy: e.clientY - rect.top - p.y };
    moved.current = false;
    setDrag({ id: t.id, ...p });
    (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId);
  };

  const onPointerMove = (e: React.PointerEvent) => {
    if (!drag) return;
    const t = tables.find(x => x.id === drag.id)!;
    const { w, h } = sizeOf(t);
    const rect = canvasRef.current!.getBoundingClientRect();
    moved.current = true;
    setDrag({
      id: drag.id,
      x: clamp(e.clientX - rect.left - offset.current.dx, CANVAS_W - w),
      y: clamp(e.clientY - rect.top - offset.current.dy, CANVAS_H - h),
    });
  };

  const onPointerUp = async () => {
    if (!drag) return;
    const { id, x, y } = drag;
    setDrag(null);
    if (moved.current) await save(id, { positionX: Math.round(x), positionY: Math.round(y) });
  };

  const handleClick = async (t: Table) => {
    if (editor) {
      setEditingId(t.id);
      return;
    }
    await select(t);
    onTableSelect?.(t);
  };

  const editing = tables.find(t => t.id === editingId) || null;

  // ── Encuadre del plano (solo operación) ──
  // Límites de lo que se ve (mesas + mobiliario) con un margen; las coordenadas no cambian.
  const PAD = 32;
  const bounds = (() => {
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    const take = (x: number, y: number, w: number, h: number) => { x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x + w); y1 = Math.max(y1, y + h); };
    visible.forEach((t) => { const p = posOf(t); const { w, h } = sizeOf(t); take(p.x, p.y, w, h); });
    elements.filter((el) => zoneFilterOk(el.zone)).forEach((el) => take(el.x, el.y, el.w, el.h));
    if (!Number.isFinite(x0)) return { x: 0, y: 0, w: CANVAS_W, h: CANVAS_H };
    const x = Math.max(0, x0 - PAD), y = Math.max(0, y0 - PAD);
    return { x, y, w: Math.min(CANVAS_W, x1 + PAD) - x, h: Math.min(CANVAS_H, y1 + PAD) - y };
  })();
  const fitScale = viewport.w && viewport.h ? Math.min(viewport.w / bounds.w, viewport.h / bounds.h) : 1;
  const scale = editor ? 1 : Math.min(2, Math.max(0.4, zoom === 'fit' ? fitScale : zoom));
  const setZoomStep = (dir: 1 | -1) => setZoom(Math.min(2, Math.max(0.4, Math.round((scale + dir * 0.15) * 100) / 100)));
  // Información progresiva: con mesas pequeñas en pantalla, solo número y estado
  const detailOk = (w: number, h: number) => w * scale >= 104 && h * scale >= 92;

  return (
    <div className="space-y-3">
      {/* Pedidos desde el QR de la mesa esperando al mesero (Fase 4) */}
      {!editor && <TableRequests />}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-[14px] bg-white p-3 shadow-card">
        {/* Zonas */}
        <div className="flex flex-wrap gap-1.5">
          <ZoneChip active={zoneFilter === 'ALL'} onClick={() => setZoneFilter('ALL')}>{tr('pos:todas')}</ZoneChip>
          {zones.map(z => (
            <ZoneChip key={z} active={zoneFilter === z} onClick={() => setZoneFilter(z)}>{z}</ZoneChip>
          ))}
          {zones.length > 0 && hasUnzoned && (
            <ZoneChip active={zoneFilter === NO_ZONE} onClick={() => setZoneFilter(NO_ZONE)}>{tr('pos:sin_zona')}</ZoneChip>
          )}
        </div>
        {!editor && (
          <div className="flex flex-wrap items-center gap-2">
            {/* Leyenda compacta: tocar un estado resalta solo esas mesas */}
            <div className="flex flex-wrap items-center gap-1" role="group" aria-label={tr('pos:filtrar_por_estado')}>
              {Object.entries(TABLE_STATUS_META).map(([key, m]) => {
                const on = statusFilter === key;
                return (
                  <button
                    key={key}
                    type="button"
                    aria-pressed={on}
                    onClick={() => setStatusFilter(on ? null : key)}
                    className={`inline-flex h-8 items-center gap-1.5 rounded-full px-2.5 text-xs font-medium transition-colors duration-fast ${on ? 'bg-slate-950 text-white' : 'text-slate-600 hover:bg-slate-100'}`}
                  >
                    <span className={`h-2 w-2 rounded-full ${m.dot}`} aria-hidden />
                    {m.label}
                  </button>
                );
              })}
            </div>
            {/* Zoom del plano */}
            <div className="inline-flex items-center gap-0.5 rounded-full bg-slate-100 p-1">
              <button type="button" onClick={() => setZoomStep(-1)} className="grid h-7 w-7 place-items-center rounded-full text-slate-700 hover:bg-white" aria-label={tr('pos:alejar')}><Minus className="h-3.5 w-3.5" aria-hidden /></button>
              <button type="button" onClick={() => setZoom('fit')} className={`inline-flex h-7 items-center gap-1 rounded-full px-2.5 text-xs font-medium ${zoom === 'fit' ? 'bg-white text-slate-950 shadow-card' : 'text-slate-700 hover:bg-white'}`} title={tr('pos:ajustar_plano')} aria-label={tr('pos:ajustar_plano')}>
                <Maximize2 className="h-3 w-3" aria-hidden /> <span className="num">{Math.round(scale * 100)}%</span>
              </button>
              <button type="button" onClick={() => setZoomStep(1)} className="grid h-7 w-7 place-items-center rounded-full text-slate-700 hover:bg-white" aria-label={tr('pos:acercar')}><Plus className="h-3.5 w-3.5" aria-hidden /></button>
            </div>
            <Segmented
              size="sm"
              value="floorplan"
              onChange={(v) => switchTableView(v as 'operational' | 'floorplan')}
              ariaLabel={tr('pos:vista_mesas')}
              options={[
                { id: 'operational', label: <List className="h-3.5 w-3.5" aria-hidden />, ariaLabel: tr('pos:vista_lista') },
                { id: 'floorplan', label: <MapIcon className="h-3.5 w-3.5" aria-hidden />, ariaLabel: tr('pos:vista_mapa') },
              ]}
            />
          </div>
        )}
      </div>

      {editor && (
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => addTables(1)}
            disabled={saving}
            className="inline-flex items-center gap-2 min-h-[42px] px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold shadow-sm disabled:opacity-50"
          >
            <Plus className="w-4 h-4" aria-hidden /> {tr('pos:agregar_mesa')}
          </button>
          <button
            type="button"
            onClick={addSeveral}
            disabled={saving}
            className="inline-flex items-center gap-2 min-h-[42px] px-4 rounded-xl border border-slate-200 bg-white text-slate-700 text-sm font-bold hover:bg-slate-50 disabled:opacity-50"
          >
            <CopyPlus className="w-4 h-4" aria-hidden /> {tr('pos:agregar_varias')}
          </button>
          <p className="flex-1 min-w-[16rem] text-xs text-blue-700 bg-blue-50 border border-blue-200 rounded-xl px-3 py-2 font-medium">
            {tr('pos:arrastra_las_mesas_para_ubicarlas_como_en', { value: saving ? ` ${tr('pos:guardando')}` : '' })}
          </p>
        </div>
      )}

      <div className={`grid gap-3 ${editor ? 'xl:grid-cols-[1fr_280px]' : ''}`}>
        <div
          ref={viewportRef}
          className={`overflow-auto rounded-[22px] bg-white shadow-card ${editor ? '' : 'h-[calc(var(--app-h,100dvh)-15rem)] min-h-[360px]'}`}
        >
          <div style={editor ? undefined : { width: bounds.w * scale, height: bounds.h * scale, margin: zoom === 'fit' ? '0 auto' : undefined, overflow: 'hidden' }}>
          <div
            ref={canvasRef}
            className="relative"
            style={{
              width: CANVAS_W,
              height: CANVAS_H,
              transform: editor ? undefined : `translate(${-bounds.x * scale}px, ${-bounds.y * scale}px) scale(${scale})`,
              transformOrigin: '0 0',
              transition: editor ? undefined : 'transform 220ms cubic-bezier(0.2, 0.8, 0.2, 1)',
              backgroundImage: editor ? 'radial-gradient(circle, #cbd5e1 1px, transparent 1px)' : undefined,
              backgroundSize: '24px 24px',
            }}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
          >
            {!editor && elements.filter((el) => zoneFilterOk(el.zone)).map((el) => (
              <div key={el.id} aria-hidden className={`pointer-events-none absolute flex items-center justify-center rounded-md text-xs opacity-60 ${ELEMENT_LOOK[el.kind] || 'bg-slate-200'}`}
                style={{ left: el.x, top: el.y, width: el.w, height: el.h, transform: el.rotation ? `rotate(${el.rotation}deg)` : undefined }}>
                {el.label && <span className="truncate px-1">{el.label}</span>}
              </div>
            ))}
            {visible.map(t => {
              const p = posOf(t);
              const { w, h } = sizeOf(t);
              const meta = lookOf(t, editor);
              const total = summaryOf(t.id).total || t.currentSale?.total || 0;
              const time = elapsed(t.currentSale?.createdAt);
              const isSelected = editor ? editingId === t.id : selectedTable?.id === t.id;
              const round = (t as any).shape === 'round';
              // Mesas pequeñas: menos relleno y sin la línea de quién abrió (queda en el título)
              const compact = h < 120 || w < 112;
              const detail = editor || detailOk(w, h);
              const showWaiter = detail && !editor && !!meta.waiterName && t.status !== 'AVAILABLE' && h >= 100 && !(round && h < 140);
              const dimmed = !editor && statusFilter !== null && t.status !== statusFilter;
              return (
                <button
                  key={t.id}
                  type="button"
                  onPointerDown={e => onPointerDown(e, t)}
                  onClick={() => handleClick(t)}
                  style={{ left: p.x, top: p.y, width: w, height: h, touchAction: 'none', transform: (t as any).rotation ? `rotate(${(t as any).rotation}deg)` : undefined }}
                  title={!editor && meta.waiterName && t.status !== 'AVAILABLE' ? tr('v3:abrio', { name: meta.waiterName }) : undefined}
                  className={`absolute overflow-hidden border-2 text-left flex flex-col justify-between ${compact ? 'p-2 gap-0.5' : 'p-2.5 gap-1'} ${round ? 'rounded-full items-center justify-center text-center' : 'rounded-2xl'} ${meta.card} ${
                    isSelected ? 'ring-4 ring-blue-600 ring-offset-2' : ''
                  } ${editor ? 'cursor-move shadow-lg' : 'transition-[box-shadow,opacity] duration-fast hover:shadow-raised'} ${dimmed ? 'opacity-25' : ''} ${
                    drag?.id === t.id ? 'z-20' : ''
                  }`}
                >
                  <div className={`flex items-center gap-1 min-w-0 w-full ${round ? 'justify-center' : 'justify-between'}`}>
                    <span className={`font-black font-heading text-slate-900 leading-none truncate ${compact ? 'text-base' : 'text-lg'}`}>{t.number}</span>
                    <span className="flex shrink-0 items-center gap-0.5 text-[11px] leading-none font-bold text-slate-500">
                      <Users className="w-3 h-3" />
                      {t.capacity}
                    </span>
                  </div>
                  <div className={`min-w-0 w-full flex flex-col ${round ? 'items-center' : ''} ${compact ? 'gap-0' : 'gap-0.5'}`}>
                    {showWaiter && (
                      <p className="text-[11px] leading-4 font-semibold text-slate-600 truncate">{meta.waiterName}</p>
                    )}
                    {total > 0 && !editor && detail && (
                      <p className={`font-black text-slate-900 tabular-nums leading-5 truncate ${compact ? 'text-xs' : 'text-sm'}`}>{formatCurrency(total)}</p>
                    )}
                    <div className={`flex items-center gap-1 min-w-0 ${round ? 'justify-center' : 'justify-between'}`}>
                      <span className={`min-w-0 truncate px-1.5 py-0.5 rounded-full text-[10px] leading-3 font-bold uppercase tracking-wide ${meta.badge}`}>
                        {editor ? t.zone || tr('pos:sin_zona') : meta.label}
                      </span>
                      {time && !editor && !round && detail && (
                        <span className="flex shrink-0 items-center gap-0.5 text-[10px] leading-3 text-slate-500 font-semibold">
                          <Clock className="w-3 h-3" />
                          {time}
                        </span>
                      )}
                    </div>
                  </div>
                </button>
              );
            })}
            {visible.length === 0 && (
              <p className="absolute inset-0 flex items-center justify-center text-sm text-slate-400">
                {tr('pos:no_hay_mesas_en_esta_zona')}
              </p>
            )}
          </div>
          </div>
        </div>

        {editor && (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-4 space-y-4 h-fit">
            {editing ? (
              <>
                <h4 className="font-bold text-slate-900">{tr('pos:mesa')}{' '}{editing.number}</h4>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold uppercase tracking-wider text-slate-500" htmlFor="table-number">
                      {tr('pos:numero')}
                    </label>
                    <input
                      id="table-number"
                      key={`${editing.id}-number-${editing.number}`}
                      defaultValue={editing.number}
                      maxLength={20}
                      onBlur={async (e) => {
                        const input = e.target;
                        const v = input.value.trim();
                        // Si el número no se puede usar (p. ej. repetido), vuelve el que tenía
                        if (!v || v === editing.number || !(await save(editing.id, { number: v }))) input.value = editing.number;
                      }}
                      className="w-full px-3 py-2.5 text-sm border border-slate-200 rounded-xl bg-slate-50"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold uppercase tracking-wider text-slate-500" htmlFor="table-capacity">
                      {tr('pos:personas')}
                    </label>
                    <input
                      id="table-capacity"
                      key={`${editing.id}-cap-${editing.capacity}`}
                      type="number"
                      inputMode="numeric"
                      min={1}
                      max={50}
                      defaultValue={editing.capacity}
                      onBlur={async (e) => {
                        const input = e.target;
                        const v = Math.round(Number(input.value));
                        if (!v || v === editing.capacity || !(await save(editing.id, { capacity: v }))) input.value = String(editing.capacity);
                      }}
                      className="w-full px-3 py-2.5 text-sm border border-slate-200 rounded-xl bg-slate-50 tabular-nums"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold uppercase tracking-wider text-slate-500" htmlFor="zone-input">
                    {tr('pos:zona')}
                  </label>
                  <input
                    id="zone-input"
                    key={editing.id}
                    list="zone-options"
                    defaultValue={editing.zone || ''}
                    placeholder={tr('pos:ej_salon_terraza_barra')}
                    onBlur={e => {
                      const v = e.target.value.trim();
                      if (v !== (editing.zone || '')) save(editing.id, { zone: v || null });
                    }}
                    className="w-full px-3 py-2.5 text-sm border border-slate-200 rounded-xl bg-slate-50"
                  />
                  <datalist id="zone-options">
                    {zones.map(z => (
                      <option key={z} value={z} />
                    ))}
                  </datalist>
                </div>

                {(['width', 'height'] as const).map(dim => {
                  const value = dim === 'width' ? sizeOf(editing).w : sizeOf(editing).h;
                  return (
                    <div key={dim} className="space-y-1.5">
                      <label className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-slate-500">
                        <span className="flex items-center gap-1">
                          <Maximize2 className="w-3 h-3" />
                          {dim === 'width' ? tr('pos:ancho') : tr('pos:alto')}
                        </span>
                        <span className="font-mono">{value}px</span>
                      </label>
                      <input
                        type="range"
                        min={MIN_SIZE}
                        max={MAX_SIZE}
                        step={4}
                        defaultValue={value}
                        key={`${editing.id}-${dim}`}
                        onPointerUp={e => save(editing.id, { [dim]: Number((e.target as HTMLInputElement).value) })}
                        onKeyUp={e => save(editing.id, { [dim]: Number((e.target as HTMLInputElement).value) })}
                        className="w-full accent-blue-600"
                      />
                    </div>
                  );
                })}

                <button
                  type="button"
                  onClick={() => save(editing.id, { width: null, height: null })}
                  className="w-full min-h-[40px] text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl"
                >
                  {tr('pos:restablecer_tamano')}
                </button>

                <button
                  type="button"
                  onClick={() => removeTable(editing)}
                  className="w-full min-h-[40px] inline-flex items-center justify-center gap-2 text-xs font-bold text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-xl"
                >
                  <Trash2 className="w-4 h-4" aria-hidden /> {tr('pos:eliminar_mesa')}
                </button>
              </>
            ) : (
              <p className="text-xs text-slate-500">
                {tables.length === 0 ? tr('pos:aun_no_hay_mesas') : tr('pos:selecciona_una_mesa_del_plano_para_editar')}
              </p>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

const ZoneChip: React.FC<{ active: boolean; onClick: () => void; children: React.ReactNode }> = ({
  active,
  onClick,
  children,
}) => (
  <button
    type="button"
    onClick={onClick}
    className={`px-3 min-h-[36px] rounded-lg text-xs font-bold transition-all ${
      active ? 'bg-blue-600 text-white shadow-sm' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
    }`}
  >
    {children}
  </button>
);
