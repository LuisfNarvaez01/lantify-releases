// ============================================
// COMPONENTS - Plano del establecimiento
// ============================================
// Un solo componente con dos usos:
//  - Operación (editor=false): solo lectura; tocar una mesa abre el pedido.
//  - Editor (editor=true): Administración → Salón y mesas. Crear, numerar, mover,
//    redimensionar, asignar zona y eliminar mesas en el mismo plano.
// Comparte datos y estados con la vista operativa (mismo usePosStore).

import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Users, Clock, Maximize2, Plus, Trash2, CopyPlus } from 'lucide-react';
import { usePosStore } from '../../store/usePosStore';
import { tablesAPI } from '../../services/api';
import { formatCurrency } from '../../shared/formatUtils';
import { useTableSelection, useTableSummaries, TABLE_STATUS_META } from './tableSelection';
import type { Table } from '../../types';
import { toast } from '../../shared/toast';
import { errorMessage } from '../../services/apiErrors';
import { confirmDialog, promptDialog } from '../../shared/dialog';

import { t as tr } from '../../i18n';
const DEFAULT_W = 132;
const DEFAULT_H = 104;
const MIN_SIZE = 88;
const MAX_SIZE = 320;
const GAP = 20;
const CANVAS_W = 1100;
const CANVAS_H = 620;
const NO_ZONE = '__none__';

interface FloorPlanProps {
  onTableSelect?: (table: Table) => void;
  editor?: boolean;
}

const sizeOf = (t: Table) => ({ w: t.width || DEFAULT_W, h: t.height || DEFAULT_H });

const autoPosition = (index: number) => {
  const perRow = Math.floor((CANVAS_W - GAP) / (DEFAULT_W + GAP));
  return {
    x: GAP + (index % perRow) * (DEFAULT_W + GAP),
    y: GAP + Math.floor(index / perRow) * (DEFAULT_H + GAP),
  };
};

const elapsed = (iso?: string) => {
  if (!iso) return '';
  const mins = Math.floor((Date.now() - new Date(iso).getTime()) / 60000);
  return mins < 60 ? `${Math.max(mins, 0)} min` : `${Math.floor(mins / 60)} h`;
};

export const FloorPlan: React.FC<FloorPlanProps> = ({ onTableSelect, editor = false }) => {
  const { tables, selectedTable, fetchTables } = usePosStore();
  const select = useTableSelection();
  const summaryOf = useTableSummaries();
  useEffect(() => {
    if (editor) fetchTables();
  }, [editor]);
  const [zoneFilter, setZoneFilter] = useState<string>('ALL');
  const [drag, setDrag] = useState<{ id: string; x: number; y: number } | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const canvasRef = useRef<HTMLDivElement>(null);
  const offset = useRef({ dx: 0, dy: 0 });
  const moved = useRef(false);

  const zones = useMemo(
    () => Array.from(new Set(tables.map(t => t.zone).filter((z): z is string => !!z))).sort(),
    [tables]
  );
  const hasUnzoned = tables.some(t => !t.zone);

  const visible = tables.filter(t => {
    if (zoneFilter === 'ALL') return true;
    if (zoneFilter === NO_ZONE) return !t.zone;
    return t.zone === zoneFilter;
  });

  const posOf = (t: Table) => {
    if (drag?.id === t.id) return { x: drag.x, y: drag.y };
    if (t.positionX != null && t.positionY != null && (t.positionX > 0 || t.positionY > 0)) {
      return { x: t.positionX, y: t.positionY };
    }
    return autoPosition(tables.findIndex(x => x.id === t.id));
  };

  const clamp = (v: number, max: number) => Math.min(Math.max(v, 0), Math.max(max, 0));

  /** Guarda un cambio de la mesa; devuelve false si el servidor lo rechazó */
  const save = async (id: string, data: Record<string, unknown>) => {
    setSaving(true);
    try {
      await tablesAPI.update(id, data);
      await fetchTables();
      return true;
    } catch (err) {
      toast.error(errorMessage(err), tr('pos:no_se_pudo_guardar_la_mesa'));
      return false;
    } finally {
      setSaving(false);
    }
  };

  // ── Crear y eliminar (solo editor) ─────────────────────────
  /** Siguiente número libre: el mayor número entero + 1 */
  const nextNumber = (taken: string[]) => {
    const nums = taken.map((n) => parseInt(n, 10)).filter((n) => Number.isFinite(n));
    return String((nums.length ? Math.max(...nums) : 0) + 1);
  };

  /** Primer hueco de la cuadrícula que no pisa otra mesa */
  const freeSpot = (occupied: { x: number; y: number; w: number; h: number }[]) => {
    for (let i = 0; i < 200; i++) {
      const p = autoPosition(i);
      if (p.y + DEFAULT_H > CANVAS_H) break;
      const clash = occupied.some((o) => p.x < o.x + o.w && p.x + DEFAULT_W > o.x && p.y < o.y + o.h && p.y + DEFAULT_H > o.y);
      if (!clash) return p;
    }
    return { x: GAP, y: GAP };
  };

  const addTables = async (count: number) => {
    setSaving(true);
    const numbers = tables.map((t) => t.number);
    const occupied = tables.map((t) => ({ ...posOf(t), ...{ w: sizeOf(t).w, h: sizeOf(t).h } }));
    const zone = zoneFilter !== 'ALL' && zoneFilter !== NO_ZONE ? zoneFilter : null;
    let lastId: string | null = null;
    try {
      for (let i = 0; i < count; i++) {
        const number = nextNumber(numbers);
        const spot = freeSpot(occupied);
        const created = await tablesAPI.create({ number, capacity: 4, positionX: spot.x, positionY: spot.y, zone });
        numbers.push(number);
        occupied.push({ ...spot, w: DEFAULT_W, h: DEFAULT_H });
        lastId = created?.id || lastId;
      }
      await fetchTables();
      if (lastId) setEditingId(lastId);
    } catch (err) {
      toast.error(errorMessage(err), tr('pos:no_se_pudo_crear_la_mesa'));
      await fetchTables();
    } finally {
      setSaving(false);
    }
  };

  const addSeveral = async () => {
    const answer = await promptDialog({
      title: tr('pos:agregar_varias_mesas'),
      label: tr('pos:cuantas_mesas'),
      defaultValue: '4',
      inputMode: 'numeric',
      confirmLabel: tr('pos:agregar'),
    });
    const n = Math.round(Number(answer));
    if (!answer || !Number.isFinite(n) || n < 1) return;
    await addTables(Math.min(n, 40));
  };

  const removeTable = async (t: Table) => {
    const ok = await confirmDialog({
      title: tr('pos:eliminar_mesa_n', { n: t.number }),
      message: tr('pos:eliminar_mesa_desc'),
      confirmLabel: tr('pos:eliminar'),
      tone: 'danger',
    });
    if (!ok) return;
    try {
      await tablesAPI.delete(t.id);
      setEditingId(null);
      await fetchTables();
    } catch (err) {
      toast.error(errorMessage(err), tr('pos:no_se_pudo_eliminar_la_mesa'));
    }
  };

  const onPointerDown = (e: React.PointerEvent, t: Table) => {
    if (!editor) return;
    e.preventDefault();
    const rect = canvasRef.current!.getBoundingClientRect();
    const p = posOf(t);
    offset.current = { dx: e.clientX - rect.left - p.x, dy: e.clientY - rect.top - p.y };
    moved.current = false;
    setDrag({ id: t.id, ...p });
    (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId);
  };

  const onPointerMove = (e: React.PointerEvent) => {
    if (!drag) return;
    const t = tables.find(x => x.id === drag.id)!;
    const { w, h } = sizeOf(t);
    const rect = canvasRef.current!.getBoundingClientRect();
    moved.current = true;
    setDrag({
      id: drag.id,
      x: clamp(e.clientX - rect.left - offset.current.dx, CANVAS_W - w),
      y: clamp(e.clientY - rect.top - offset.current.dy, CANVAS_H - h),
    });
  };

  const onPointerUp = async () => {
    if (!drag) return;
    const { id, x, y } = drag;
    setDrag(null);
    if (moved.current) await save(id, { positionX: Math.round(x), positionY: Math.round(y) });
  };

  const handleClick = async (t: Table) => {
    if (editor) {
      setEditingId(t.id);
      return;
    }
    await select(t);
    onTableSelect?.(t);
  };

  const editing = tables.find(t => t.id === editingId) || null;

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-3.5 rounded-2xl border border-slate-200 shadow-sm">
        {/* Zonas */}
        <div className="flex flex-wrap gap-1.5">
          <ZoneChip active={zoneFilter === 'ALL'} onClick={() => setZoneFilter('ALL')}>{tr('pos:todas')}</ZoneChip>
          {zones.map(z => (
            <ZoneChip key={z} active={zoneFilter === z} onClick={() => setZoneFilter(z)}>{z}</ZoneChip>
          ))}
          {zones.length > 0 && hasUnzoned && (
            <ZoneChip active={zoneFilter === NO_ZONE} onClick={() => setZoneFilter(NO_ZONE)}>{tr('pos:sin_zona')}</ZoneChip>
          )}
        </div>
        {/* Leyenda (icono + texto, no solo color) */}
        <div className="flex flex-wrap gap-4">
          {Object.entries(TABLE_STATUS_META).map(([key, m]) => (
            <span key={key} className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-600">
              <span className={`w-3 h-3 rounded-full ${m.dot}`} />
              {m.label}
            </span>
          ))}
        </div>
      </div>

      {editor && (
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => addTables(1)}
            disabled={saving}
            className="inline-flex items-center gap-2 min-h-[42px] px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold shadow-sm disabled:opacity-50"
          >
            <Plus className="w-4 h-4" aria-hidden /> {tr('pos:agregar_mesa')}
          </button>
          <button
            type="button"
            onClick={addSeveral}
            disabled={saving}
            className="inline-flex items-center gap-2 min-h-[42px] px-4 rounded-xl border border-slate-200 bg-white text-slate-700 text-sm font-bold hover:bg-slate-50 disabled:opacity-50"
          >
            <CopyPlus className="w-4 h-4" aria-hidden /> {tr('pos:agregar_varias')}
          </button>
          <p className="flex-1 min-w-[16rem] text-xs text-blue-700 bg-blue-50 border border-blue-200 rounded-xl px-3 py-2 font-medium">
            {tr('pos:arrastra_las_mesas_para_ubicarlas_como_en', { value: saving ? ` ${tr('pos:guardando')}` : '' })}
          </p>
        </div>
      )}

      <div className={`grid gap-3 ${editor ? 'xl:grid-cols-[1fr_280px]' : ''}`}>
        <div className="overflow-auto rounded-3xl border border-slate-200 bg-white shadow-sm">
          <div
            ref={canvasRef}
            className="relative"
            style={{
              width: CANVAS_W,
              height: CANVAS_H,
              backgroundImage: editor ? 'radial-gradient(circle, #cbd5e1 1px, transparent 1px)' : undefined,
              backgroundSize: '24px 24px',
            }}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
          >
            {visible.map(t => {
              const p = posOf(t);
              const { w, h } = sizeOf(t);
              const meta = TABLE_STATUS_META[t.status] || TABLE_STATUS_META.AVAILABLE;
              const total = summaryOf(t.id).total || t.currentSale?.total || 0;
              const time = elapsed(t.currentSale?.createdAt);
              const isSelected = editor ? editingId === t.id : selectedTable?.id === t.id;
              return (
                <button
                  key={t.id}
                  type="button"
                  onPointerDown={e => onPointerDown(e, t)}
                  onClick={() => handleClick(t)}
                  style={{ left: p.x, top: p.y, width: w, height: h, touchAction: 'none' }}
                  className={`absolute p-3 rounded-2xl border-2 text-left flex flex-col justify-between ${meta.card} ${
                    isSelected ? 'ring-4 ring-blue-600/30 !border-blue-600' : ''
                  } ${editor ? 'cursor-move shadow-lg' : 'transition-shadow hover:shadow-md'} ${
                    drag?.id === t.id ? 'z-20' : ''
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-black text-lg font-heading text-slate-900">{t.number}</span>
                    <span className="flex items-center gap-1 text-xs font-bold text-slate-500">
                      <Users className="w-3 h-3" />
                      {t.capacity}
                    </span>
                  </div>
                  <div>
                    {total > 0 && !editor && (
                      <p className="text-sm font-black text-slate-900 tabular-nums">{formatCurrency(total)}</p>
                    )}
                    <div className="flex items-center justify-between gap-1">
                      <span className={`px-2 py-0.5 rounded-full text-xs font-bold uppercase tracking-wide ${meta.badge}`}>
                        {editor ? t.zone || tr('pos:sin_zona') : meta.label}
                      </span>
                      {time && !editor && (
                        <span className="flex items-center gap-0.5 text-xs text-slate-500 font-semibold">
                          <Clock className="w-3 h-3" />
                          {time}
                        </span>
                      )}
                    </div>
                  </div>
                </button>
              );
            })}
            {visible.length === 0 && (
              <p className="absolute inset-0 flex items-center justify-center text-sm text-slate-400">
                {tr('pos:no_hay_mesas_en_esta_zona')}
              </p>
            )}
          </div>
        </div>

        {editor && (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-4 space-y-4 h-fit">
            {editing ? (
              <>
                <h4 className="font-bold text-slate-900">{tr('pos:mesa')}{' '}{editing.number}</h4>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold uppercase tracking-wider text-slate-500" htmlFor="table-number">
                      {tr('pos:numero')}
                    </label>
                    <input
                      id="table-number"
                      key={`${editing.id}-number-${editing.number}`}
                      defaultValue={editing.number}
                      maxLength={20}
                      onBlur={async (e) => {
                        const input = e.target;
                        const v = input.value.trim();
                        // Si el número no se puede usar (p. ej. repetido), vuelve el que tenía
                        if (!v || v === editing.number || !(await save(editing.id, { number: v }))) input.value = editing.number;
                      }}
                      className="w-full px-3 py-2.5 text-sm border border-slate-200 rounded-xl bg-slate-50"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold uppercase tracking-wider text-slate-500" htmlFor="table-capacity">
                      {tr('pos:personas')}
                    </label>
                    <input
                      id="table-capacity"
                      key={`${editing.id}-cap-${editing.capacity}`}
                      type="number"
                      inputMode="numeric"
                      min={1}
                      max={50}
                      defaultValue={editing.capacity}
                      onBlur={async (e) => {
                        const input = e.target;
                        const v = Math.round(Number(input.value));
                        if (!v || v === editing.capacity || !(await save(editing.id, { capacity: v }))) input.value = String(editing.capacity);
                      }}
                      className="w-full px-3 py-2.5 text-sm border border-slate-200 rounded-xl bg-slate-50 tabular-nums"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold uppercase tracking-wider text-slate-500" htmlFor="zone-input">
                    {tr('pos:zona')}
                  </label>
                  <input
                    id="zone-input"
                    key={editing.id}
                    list="zone-options"
                    defaultValue={editing.zone || ''}
                    placeholder={tr('pos:ej_salon_terraza_barra')}
                    onBlur={e => {
                      const v = e.target.value.trim();
                      if (v !== (editing.zone || '')) save(editing.id, { zone: v || null });
                    }}
                    className="w-full px-3 py-2.5 text-sm border border-slate-200 rounded-xl bg-slate-50"
                  />
                  <datalist id="zone-options">
                    {zones.map(z => (
                      <option key={z} value={z} />
                    ))}
                  </datalist>
                </div>

                {(['width', 'height'] as const).map(dim => {
                  const value = dim === 'width' ? sizeOf(editing).w : sizeOf(editing).h;
                  return (
                    <div key={dim} className="space-y-1.5">
                      <label className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-slate-500">
                        <span className="flex items-center gap-1">
                          <Maximize2 className="w-3 h-3" />
                          {dim === 'width' ? tr('pos:ancho') : tr('pos:alto')}
                        </span>
                        <span className="font-mono">{value}px</span>
                      </label>
                      <input
                        type="range"
                        min={MIN_SIZE}
                        max={MAX_SIZE}
                        step={4}
                        defaultValue={value}
                        key={`${editing.id}-${dim}`}
                        onPointerUp={e => save(editing.id, { [dim]: Number((e.target as HTMLInputElement).value) })}
                        onKeyUp={e => save(editing.id, { [dim]: Number((e.target as HTMLInputElement).value) })}
                        className="w-full accent-blue-600"
                      />
                    </div>
                  );
                })}

                <button
                  type="button"
                  onClick={() => save(editing.id, { width: null, height: null })}
                  className="w-full min-h-[40px] text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl"
                >
                  {tr('pos:restablecer_tamano')}
                </button>

                <button
                  type="button"
                  onClick={() => removeTable(editing)}
                  className="w-full min-h-[40px] inline-flex items-center justify-center gap-2 text-xs font-bold text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-xl"
                >
                  <Trash2 className="w-4 h-4" aria-hidden /> {tr('pos:eliminar_mesa')}
                </button>
              </>
            ) : (
              <p className="text-xs text-slate-500">
                {tables.length === 0 ? tr('pos:aun_no_hay_mesas') : tr('pos:selecciona_una_mesa_del_plano_para_editar')}
              </p>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

const ZoneChip: React.FC<{ active: boolean; onClick: () => void; children: React.ReactNode }> = ({
  active,
  onClick,
  children,
}) => (
  <button
    type="button"
    onClick={onClick}
    className={`px-3 min-h-[36px] rounded-lg text-xs font-bold transition-all ${
      active ? 'bg-blue-600 text-white shadow-sm' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
    }`}
  >
    {children}
  </button>
);
