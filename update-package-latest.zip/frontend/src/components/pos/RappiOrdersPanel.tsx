// ============================================
// DELIVERY - Rappi Partners (demostración)
// ============================================
// La conexión con Rappi aún no está lista: esta pantalla muestra cómo llegarán los
// pedidos. Los pedidos de ejemplo viven solo aquí (no crean ventas ni tocan la caja).

import React, { useState } from 'react';
import { 
  Zap, 
  Clock, 
  MapPin, 
  Phone, 
  CheckCircle2, 
  RefreshCw, 
  Truck
} from 'lucide-react';
import { formatCurrency } from '../../shared/formatUtils';
import type { Product } from '../../types';
import { toast } from '../../shared/toast';
import { demoOrder, DemoOrder } from '../delivery/demoOrder';

import { t } from '../../i18n';
interface RappiOrdersPanelProps {
  products: Product[];
}

export const RappiOrdersPanel: React.FC<RappiOrdersPanelProps> = ({ products }) => {
  const [isSimulating, setIsSimulating] = useState(false);
  const [filterStatus, setFilterStatus] = useState<'ALL' | 'PREPARING' | 'DISPATCHED'>('ALL');
  const [rappiSales, setRappiSales] = useState<DemoOrder[]>([]);

  const handleSimulateOrder = () => {
    setIsSimulating(true);
    window.setTimeout(() => {
      const order = demoOrder('RAPPI', products);
      setRappiSales((prev) => [order, ...prev]);
      toast.success(t('delivery:orden_salenumber_de_rappi_generada', { saleNumber: order.saleNumber }));
      setIsSimulating(false);
    }, 700);
  };

  const totalRappiRevenue = rappiSales.reduce((acc, s) => acc + s.total, 0);

  return (
    <div className="space-y-6">
      {/* Top Banner with Rappi Branding & Simulator Controls */}
      <div className="bg-gradient-to-r from-orange-600 via-amber-600 to-orange-500 rounded-3xl p-6 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 bg-white/15 backdrop-blur-md rounded-2xl flex items-center justify-center shadow-inner">
            <Zap className="w-10 h-10 text-white fill-white animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-2xl font-black tracking-tight">{t('delivery:conector_rappi_partners')}</h2>
              <span className="px-2.5 py-0.5 bg-white/20 text-white text-xs font-black rounded-full uppercase tracking-wider shadow-sm">
                {t('delivery:demostracion')}
              </span>
            </div>
            <p className="text-orange-100 text-sm font-medium mt-0.5">
              {t('delivery:recepcion_automatica_de_comandas_y_sincronizacion')}
            </p>
          </div>
        </div>

        <button
          onClick={handleSimulateOrder}
          disabled={isSimulating}
          className="w-full md:w-auto px-6 py-3.5 bg-white text-orange-600 rounded-2xl font-black text-sm tracking-wide shadow-lg hover:bg-orange-50 active:scale-95 transition-all flex items-center justify-center gap-2.5 disabled:opacity-60 flex-shrink-0"
        >
          {isSimulating ? (
            <>
              <RefreshCw className="w-5 h-5 animate-spin" />
              {t('delivery:generando_pedido_rappi')}
            </>
          ) : (
            <>
              <Zap className="w-5 h-5 fill-orange-600" />
              {t('delivery:simular_pedido_entrante_de_rappi')}
            </>
          )}
        </button>
      </div>

      {/* KPI Cards for Rappi */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-orange-100">
          <span className="text-xs font-black uppercase tracking-wider text-gray-500">{t('delivery:pedidos_rappi')}</span>
          <p className="text-2xl font-black text-gray-900 mt-1">{rappiSales.length}</p>
          <span className="text-xs text-orange-600 font-semibold mt-0.5 block">{t('delivery:sincronizados_en_tiempo_real')}</span>
        </div>

        <div className="bg-white rounded-2xl p-4 shadow-sm border border-orange-100">
          <span className="text-xs font-black uppercase tracking-wider text-gray-500">{t('delivery:total_facturado')}</span>
          <p className="text-2xl font-black text-emerald-700 mt-1">{formatCurrency(totalRappiRevenue)}</p>
          <span className="text-xs text-gray-500 font-medium mt-0.5 block">{t('delivery:pagos_digitales_rappipay')}</span>
        </div>

        <div className="bg-white rounded-2xl p-4 shadow-sm border border-orange-100">
          <span className="text-xs font-black uppercase tracking-wider text-gray-500">{t('delivery:auto_comanda')}</span>
          <p className="text-2xl font-black text-orange-600 mt-1">{t('delivery:activa_kds')}</p>
          <span className="text-xs text-gray-500 font-medium mt-0.5 block">{t('delivery:envio_automatico_a_cocina')}</span>
        </div>
      </div>

      {/* Orders List */}
      <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-6 space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-gray-100 pb-4">
          <div>
            <h3 className="text-lg font-black text-gray-900">{t('delivery:historial_de_pedidos_de_rappi')}</h3>
            <p className="text-xs text-gray-500">{t('delivery:monitor_de_cocina_y_seguimiento_de_repartidores')}</p>
          </div>

          <div className="flex items-center gap-2 bg-gray-100 p-1 rounded-xl text-xs font-bold">
            <button
              onClick={() => setFilterStatus('ALL')}
              className={`px-3 py-1.5 rounded-lg transition-colors ${filterStatus === 'ALL' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500'}`}
            >
              {t('delivery:todos_length', { length: rappiSales.length })}
            </button>
            <button
              onClick={() => setFilterStatus('PREPARING')}
              className={`px-3 py-1.5 rounded-lg transition-colors ${filterStatus === 'PREPARING' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500'}`}
            >
              {t('delivery:en_cocina')}
            </button>
            <button
              onClick={() => setFilterStatus('DISPATCHED')}
              className={`px-3 py-1.5 rounded-lg transition-colors ${filterStatus === 'DISPATCHED' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500'}`}
            >
              {t('delivery:con_repartidor')}
            </button>
          </div>
        </div>

        {rappiSales.length === 0 ? (
          <div className="text-center py-12 space-y-3">
            <div className="w-14 h-14 bg-orange-50 text-orange-600 rounded-2xl flex items-center justify-center mx-auto">
              <Zap className="w-7 h-7" />
            </div>
            <p className="font-bold text-gray-700">{t('delivery:no_hay_pedidos_de_rappi_registrados')}</p>
            <p className="text-xs text-gray-500 max-w-sm mx-auto">
              {t('delivery:haz_clic_en_el_boton_superior_simular')}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {rappiSales.map((sale) => (
              <div 
                key={sale.id}
                className="bg-orange-50/30 hover:bg-orange-50/60 rounded-2xl p-4 border border-orange-100 transition-all space-y-3"
              >
                {/* Header */}
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-black text-sm text-gray-900">#{sale.saleNumber}</span>
                      <span className="px-2 py-0.5 bg-orange-500 text-white font-black text-xs rounded-md uppercase">
                        Rappi
                      </span>
                    </div>
                    <span className="text-xs text-gray-500 flex items-center gap-1 mt-0.5">
                      <Clock className="w-3 h-3" />
                      {new Date(sale.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>

                  <span className="text-base font-black text-gray-900">
                    {formatCurrency(sale.total)}
                  </span>
                </div>

                {/* Tarjeta de Contacto del Cliente */}
                <div className="bg-white rounded-xl p-3 border border-orange-100 text-xs space-y-1">
                  <div className="font-bold text-gray-800 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                    {sale.customerName || t('delivery:cliente_rappi')}
                  </div>
                  {sale.customerPhone && (
                    <div className="text-gray-600 flex items-center gap-1 text-xs">
                      <Phone className="w-3 h-3 text-gray-400" />
                      {sale.customerPhone}
                    </div>
                  )}
                  {sale.customerAddress && (
                    <div className="text-gray-600 flex items-start gap-1 text-xs">
                      <MapPin className="w-3 h-3 text-rose-500 mt-0.5 flex-shrink-0" />
                      <span className="truncate">{sale.customerAddress}</span>
                    </div>
                  )}
                  {sale.deliveryNotes && (
                    <div className="text-xs text-amber-900 italic bg-amber-50 p-1.5 rounded-lg mt-1">
                      "{sale.deliveryNotes}"
                    </div>
                  )}
                </div>

                {/* Items */}
                <div className="text-xs space-y-1 pt-1">
                  {sale.items.map((it, idx) => {
                    const name = (it as any).productVariant?.product?.name 
                      ? `${(it as any).productVariant.product.name} (${(it as any).productVariant.name})`
                      : (it as any).productName || t('delivery:producto');
                    return (
                      <div key={idx} className="flex items-center justify-between text-gray-700">
                        <span>{it.quantity}x {name}</span>
                        <span className="font-medium text-gray-900">{formatCurrency(it.total)}</span>
                      </div>
                    );
                  })}
                </div>

                {/* Status Bar */}
                <div className="flex items-center justify-between pt-2 border-t border-orange-100 text-xs">
                  <span className="flex items-center gap-1 text-emerald-700 font-bold">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    {t('delivery:comandado_a_cocina')}
                  </span>
                  <span className="text-xs text-orange-700 font-semibold flex items-center gap-1">
                    <Truck className="w-3.5 h-3.5" />
                    {t('delivery:repartidor_asignado')}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
