// ============================================
// CAJA › Informe mensual › Exportación contable (Fase 4 · beta)
// ============================================
// Del mes elegido: libro de ventas (CSV), comprobante para Siigo Nube y para Alegra
// (Excel) e informe para el contador (PDF/Excel con reportDocument). Las cuentas PUC
// se configuran aquí. Solo lee las ventas: nunca las modifica.

import { useEffect, useMemo, useState } from 'react';
import * as XLSX from 'xlsx';
import { AlertTriangle, CheckCircle2, Download, FileSpreadsheet, Save } from 'lucide-react';
import { t } from '../../i18n';
import { toast } from '../../shared/toast';
import { useFeatures } from '../../shared/features';
import { gestionAPI, type AccountingMonth } from '../../services/v3Api';
import { ReportButton } from '../common/ReportButton';
import { int, money, type ReportDoc } from '../../services/reportDocument';
import { formatCurrency } from '../../shared/formatUtils';
import {
  AccountingAccounts, SALES_BOOK_HEADERS, SIIGO_MAX_ROWS, Sheet, alegraSheet, billable, salesBookRows, siigoSheet, taxesOf, toCsv, voucherTotals,
} from '../../../../src/domain/accountingExport';

const field = 'w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 min-h-[44px] focus:outline-none focus:ring-2 focus:ring-blue-500/40';

const ACCOUNT_FIELDS: (keyof AccountingAccounts)[] = ['caja', 'bancos', 'tarjetas', 'otros', 'ingresos', 'iva', 'impoconsumo', 'propinas'];
const OTHER_FIELDS: (keyof AccountingAccounts)[] = ['siigoVoucherType', 'siigoStart', 'alegraVoucherType', 'alegraNumbering', 'thirdPartyId', 'costCenter'];

const save = (blob: Blob, name: string) => {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
};

/** Un libro de Excel con una hoja (Siigo: partes de máximo 500 registros) */
const writeSheet = (sheet: Sheet, name: string) => {
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([sheet.headers, ...sheet.rows]), sheet.name);
  XLSX.writeFile(wb, name, { compression: true });
};

export function AccountingExportTab({ month, monthLabel }: { month: string; monthLabel: string }) {
  const { settings, save: saveFeatures } = useFeatures();
  const [data, setData] = useState<AccountingMonth | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [accounts, setAccounts] = useState<AccountingAccounts>(settings.accounting);
  const [busy, setBusy] = useState(false);

  const load = () => {
    setError(null);
    setData(null);
    gestionAPI.accountingMonth(month).then(setData).catch((e) => setError(e?.message || t('v3:cont_error')));
  };
  useEffect(load, [month]);
  useEffect(() => { setAccounts(settings.accounting); }, [settings.accounting]);

  const sales = useMemo(() => (data ? billable(data.sales) : []), [data]);
  const totals = useMemo(() => {
    let iva = 0, inc = 0, tips = 0, total = 0;
    for (const s of sales) { const x = taxesOf(s); iva += x.iva; inc += x.inc; tips += s.tip; total += s.total; }
    return { iva: iva / 100, inc: inc / 100, tips, total };
  }, [sales]);

  const saveAccounts = async () => {
    setBusy(true);
    try {
      await saveFeatures({ accounting: accounts });
      toast.success(t('v3:guardado'));
      load();
    } catch (e: any) {
      toast.error(e?.message || t('v3:no_se_guardo'));
    } finally {
      setBusy(false);
    }
  };

  const salesCsv = () => data && save(new Blob([toCsv(SALES_BOOK_HEADERS, salesBookRows(data.sales))], { type: 'text/csv;charset=utf-8' }), `lantify-libro-ventas-${month}.csv`);

  const siigo = () => {
    if (!data) return;
    const sheet = siigoSheet(data.vouchers, data.accounts);
    // Siigo admite 500 registros por archivo: un comprobante nunca queda partido entre dos archivos
    const parts: Sheet[] = [];
    let current: Sheet = { ...sheet, rows: [] };
    for (const v of data.vouchers) {
      const rows = sheet.rows.filter((r) => r[1] === v.number);
      if (current.rows.length + rows.length > SIIGO_MAX_ROWS && current.rows.length) { parts.push(current); current = { ...sheet, rows: [] }; }
      current.rows.push(...rows);
    }
    if (current.rows.length) parts.push(current);
    parts.forEach((p, i) => writeSheet(p, `lantify-siigo-comprobantes-${month}${parts.length > 1 ? `-parte-${i + 1}` : ''}.xlsx`));
  };

  const alegra = () => data && writeSheet(alegraSheet(data.vouchers, data.accounts), `lantify-alegra-comprobantes-${month}.xlsx`);

  /** Informe mensual para el contador: cierres, gastos, facturas y comprobantes */
  const accountantReport = (): ReportDoc => {
    if (!data) throw new Error(t('v3:cont_error'));
    const expenses = data.expenses.reduce((n, e) => n + e.amount, 0);
    return {
      title: t('v3:cont_informe_titulo'),
      period: monthLabel,
      kpis: [
        { label: t('v3:cont_ventas'), value: money(totals.total) },
        { label: t('v3:cont_iva'), value: money(totals.iva) },
        { label: t('v3:cont_inc'), value: money(totals.inc) },
        { label: t('v3:cont_propinas'), value: money(totals.tips) },
        { label: t('v3:cont_gastos'), value: money(expenses) },
        { label: t('v3:cont_num_ventas'), value: int(sales.length) },
      ],
      tables: [
        {
          title: t('v3:cont_comprobantes'), sheet: 'Comprobantes',
          columns: [{ label: t('v3:cont_numero') }, { label: t('v3:cont_fecha') }, { label: t('v3:cont_cuenta') }, { label: t('v3:cont_descripcion'), width: 3 }, { label: t('v3:cont_debito'), align: 'right' }, { label: t('v3:cont_credito'), align: 'right' }],
          rows: data.vouchers.flatMap((v) => v.lines.map((l) => [v.number, v.date, l.account, l.description, money(l.debit), money(l.credit)])),
          totals: ['', '', '', t('v3:cont_total'), money(data.vouchers.reduce((n, v) => n + voucherTotals(v).debit, 0)), money(data.vouchers.reduce((n, v) => n + voucherTotals(v).credit, 0))],
        },
        {
          title: t('v3:cont_cierres'), sheet: 'Cierres',
          columns: [{ label: t('v3:cont_arqueo') }, { label: t('v3:cont_fecha') }, { label: t('v3:cont_cerro') }, { label: t('v3:cont_entradas'), align: 'right' }, { label: t('v3:cont_salidas'), align: 'right' }, { label: t('v3:cont_diferencia'), align: 'right' }],
          rows: data.sessions.map((s) => [s.sessionNumber, (s.closedAt || s.openedAt).slice(0, 10), s.closedByName || '', money(s.income), money(s.expenses), money(s.difference ?? 0)]),
        },
        {
          title: t('v3:cont_gastos_titulo'), sheet: 'Gastos',
          columns: [{ label: t('v3:cont_fecha') }, { label: t('v3:cont_concepto'), width: 2 }, { label: t('v3:cont_proveedor'), width: 2 }, { label: t('v3:cont_factura') }, { label: t('v3:cont_iva'), align: 'right' }, { label: t('v3:cont_total'), align: 'right' }],
          rows: data.expenses.map((e) => [e.createdAt.slice(0, 10), [e.category, e.motive].filter(Boolean).join(' · '), [e.supplierName, e.supplierNit].filter(Boolean).join(' · '), e.invoiceNumber || '', money(e.taxAmount ?? 0), money(e.amount)]),
          totals: ['', '', '', '', '', money(expenses)],
        },
        {
          title: t('v3:cont_facturas'), sheet: 'Facturas',
          columns: [{ label: t('v3:cont_factura') }, { label: t('v3:cont_fecha') }, { label: t('v3:cont_cliente'), width: 2 }, { label: t('v3:cont_base'), align: 'right' }, { label: t('v3:cont_impuesto'), align: 'right' }, { label: t('v3:cont_total'), align: 'right' }, { label: t('v3:cont_estado') }],
          rows: data.invoices.map((i) => [i.invoiceNumber, i.issueDate.slice(0, 10), `${i.customerName} · ${i.customerNit}`, money(i.subtotal), money(i.tax), money(i.total), i.status]),
        },
      ],
      notes: [t('v3:cont_beta_nota')],
    };
  };

  return (
    <div className="space-y-6">
      <div role="note" className="flex items-start gap-3 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
        <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0" aria-hidden />
        <p><span className="mr-2 rounded-full bg-amber-200 px-2 py-0.5 text-[0.7143rem] font-bold uppercase tracking-wide">beta</span>{t('v3:cont_beta')}</p>
      </div>

      {error && <p role="alert" className="rounded-2xl bg-rose-50 p-4 text-sm font-semibold text-rose-800">{error}</p>}
      {!data && !error && <p role="status" className="text-sm text-slate-500">{t('v3:cont_cargando')}</p>}

      {data && (
        <section className="bg-white rounded-3xl border border-slate-200/80 p-6 space-y-4">
          <div className="flex flex-wrap items-baseline justify-between gap-3">
            <h3 className="text-base font-semibold text-slate-900">{t('v3:cont_titulo', { mes: monthLabel })}</h3>
            <p className={`flex items-center gap-1.5 text-sm font-semibold ${data.balanced ? 'text-emerald-700' : 'text-rose-700'}`} role="status">
              {data.balanced ? <CheckCircle2 className="h-4 w-4" aria-hidden /> : <AlertTriangle className="h-4 w-4" aria-hidden />}
              {data.balanced ? t('v3:cont_cuadra', { n: data.vouchers.length }) : t('v3:cont_no_cuadra')}
            </p>
          </div>
          <dl className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm">
            {[[t('v3:cont_num_ventas'), String(sales.length)], [t('v3:cont_ventas'), formatCurrency(totals.total)], [t('v3:cont_iva_inc'), formatCurrency(totals.iva + totals.inc)], [t('v3:cont_propinas'), formatCurrency(totals.tips)]].map(([k, v]) => (
              <div key={k} className="rounded-2xl bg-slate-50 p-3"><dt className="text-xs text-slate-500">{k}</dt><dd className="mt-1 font-semibold tabular-nums text-slate-900">{v}</dd></div>
            ))}
          </dl>
          <div className="flex flex-wrap gap-2">
            <button type="button" onClick={salesCsv} disabled={!sales.length} className="inline-flex min-h-[44px] items-center gap-2 rounded-xl border border-slate-300 px-4 text-sm font-bold text-slate-800 hover:bg-slate-50 disabled:opacity-50">
              <Download className="h-4 w-4" aria-hidden />{t('v3:cont_libro_csv')}
            </button>
            <button type="button" onClick={siigo} disabled={!data.vouchers.length} className="inline-flex min-h-[44px] items-center gap-2 rounded-xl border border-slate-300 px-4 text-sm font-bold text-slate-800 hover:bg-slate-50 disabled:opacity-50">
              <FileSpreadsheet className="h-4 w-4" aria-hidden />{t('v3:cont_siigo')}
            </button>
            <button type="button" onClick={alegra} disabled={!data.vouchers.length} className="inline-flex min-h-[44px] items-center gap-2 rounded-xl border border-slate-300 px-4 text-sm font-bold text-slate-800 hover:bg-slate-50 disabled:opacity-50">
              <FileSpreadsheet className="h-4 w-4" aria-hidden />{t('v3:cont_alegra')}
            </button>
            <ReportButton label={t('v3:cont_informe')} build={accountantReport} fileName={`contador-${month}`} align="left" />
          </div>
          <p className="text-xs text-slate-500">{t('v3:cont_como')}</p>
        </section>
      )}

      <section className="bg-white rounded-3xl border border-slate-200/80 p-6 space-y-4" aria-labelledby="cont-cuentas">
        <div>
          <h3 id="cont-cuentas" className="text-base font-semibold text-slate-900">{t('v3:cont_cuentas')}</h3>
          <p className="text-xs text-slate-500">{t('v3:cont_cuentas_desc')}</p>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {ACCOUNT_FIELDS.map((k) => (
            <label key={k} className="text-xs font-bold text-slate-700 space-y-1 block">
              {t(`v3:cont_c_${k}`)}
              <input inputMode="numeric" className={field} value={String(accounts[k])} onChange={(e) => setAccounts({ ...accounts, [k]: e.target.value.replace(/[^\d]/g, '') })} />
            </label>
          ))}
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {OTHER_FIELDS.map((k) => (
            <label key={k} className="text-xs font-bold text-slate-700 space-y-1 block">
              {t(`v3:cont_c_${k}`)}
              <input inputMode={k === 'siigoStart' || k === 'thirdPartyId' || k === 'siigoVoucherType' ? 'numeric' : 'text'} className={field} value={String(accounts[k])}
                onChange={(e) => setAccounts({ ...accounts, [k]: k === 'siigoStart' ? Number(e.target.value.replace(/[^\d]/g, '')) || 1 : e.target.value })} />
            </label>
          ))}
        </div>
        <button type="button" onClick={saveAccounts} disabled={busy} className="inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-slate-900 px-4 text-sm font-bold text-white hover:bg-slate-800 disabled:opacity-50">
          <Save className="h-4 w-4" aria-hidden />{t('v3:guardar')}
        </button>
      </section>
    </div>
  );
}
