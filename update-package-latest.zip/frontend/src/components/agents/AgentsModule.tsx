// ============================================
// COMPONENTS - Agentes de IA (Premium)
// ============================================
// Backoffice, Compras y Marketing. Cada respuesta puede traer un gráfico y
// acciones propuestas; ninguna acción se ejecuta sin que el administrador la
// confirme. "Qué datos se envían" muestra el resumen exacto que sale del equipo.

import { FormEvent, ReactNode, Suspense, lazy, useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import {
  AlertTriangle, BarChart3, CalendarClock, CalendarRange, Check, ClipboardList, Clock3, Eye, Loader2, Megaphone, MessageCircle, MessageSquareText,
  PackageX, Percent, Rocket, RotateCcw, Scale, Send, ShoppingCart, Sparkles, Store, Ticket, TrendingUp, UserRoundCheck, Wallet, Wand2, X,
} from 'lucide-react';
import { agentsAPI, aiSettingsAPI, AgentAction, AgentChart, AgentId, AgentMessage, AiSettings } from '../../services/api';
import { ApiError, errorMessage } from '../../services/apiErrors';
import { formatCurrency } from '../../shared/formatUtils';
import { toast } from '../../shared/toast';
import { useFeature } from '../../shared/plan';
import { PlanLocked } from '../common/PlanLocked';
import { whatsappNumber } from '../admin/SuppliersPanel';
import { t, getLanguage, getLocale } from '../../i18n';
import { copyText } from '../../shared/browser';
import { AGENT_TASKS, profileReady, visiblePart, type AgentKpi, type AgentTask, type AiProfile, type FlyerCopy } from '../../../../src/domain/v3/agents';

const FlyerStudio = lazy(() => import('./FlyerStudio').then((m) => ({ default: m.FlyerStudio })));
const FlyerGallery = lazy(() => import('./FlyerStudio').then((m) => ({ default: m.FlyerGallery })));

type OpenFlyer = { copy: FlyerCopy; template?: 'claro' | 'oscuro' | 'foto'; photo?: string | null };

const AGENTS: { id: AgentId; icon: typeof BarChart3; tone: string }[] = [
  { id: 'backoffice', icon: BarChart3, tone: 'text-blue-700 bg-blue-50' },
  { id: 'purchasing', icon: ShoppingCart, tone: 'text-emerald-700 bg-emerald-50' },
  { id: 'marketing', icon: Megaphone, tone: 'text-violet-700 bg-violet-50' },
];

// ── Texto con **negrita** y viñetas (sin HTML) ─────────────
const inline = (text: string): ReactNode[] =>
  text.split(/(\*\*[^*]+\*\*)/g).map((p, i) => (p.startsWith('**') && p.endsWith('**') ? <strong key={i}>{p.slice(2, -2)}</strong> : p));

function RichText({ text }: { text: string }) {
  const lines = text.split('\n').map((l) => l.trim()).filter(Boolean);
  const out: ReactNode[] = [];
  let bullets: string[] = [];
  const flush = () => {
    if (bullets.length) out.push(<ul key={`u${out.length}`} className="my-1.5 list-disc space-y-1 pl-5">{bullets.map((b, i) => <li key={i}>{inline(b)}</li>)}</ul>);
    bullets = [];
  };
  for (const l of lines) {
    if (/^([-•*]|\d+[.)])\s+/.test(l)) bullets.push(l.replace(/^([-•*]|\d+[.)])\s+/, ''));
    else {
      flush();
      out.push(<p key={`p${out.length}`} className="my-1.5">{inline(l)}</p>);
    }
  }
  flush();
  return <div className="leading-relaxed">{out}</div>;
}

// ── Gráfico simple en SVG (barras o línea) ─────────────────
const fmt = (v: number, unit: AgentChart['unit']) =>
  unit === 'COP' ? formatCurrency(v) : unit === '%' ? `${v.toLocaleString(getLocale())} %` : v.toLocaleString(getLocale());

function Chart({ chart }: { chart: AgentChart }) {
  const values = chart.series[0]?.values || [];
  const max = Math.max(1, ...values);
  const W = 560;
  const H = 180;
  const n = chart.labels.length;
  const bw = W / Math.max(1, n);
  const step = Math.ceil(n / 10);
  const points = values.map((v, i) => `${i * bw + bw / 2},${H - (v / max) * (H - 12)}`).join(' ');
  const peak = values.indexOf(max);
  return (
    <figure className="mt-3 rounded-2xl border border-slate-200 bg-white p-4">
      <figcaption className="flex items-baseline justify-between gap-3 text-xs">
        <span className="font-bold text-slate-700">{chart.title}</span>
        <span className="text-slate-500">{t('agents:maximo', { value: fmt(max, chart.unit), label: chart.labels[peak] })}</span>
      </figcaption>
      <svg viewBox={`0 0 ${W} ${H + 22}`} className="mt-2 w-full" role="img" aria-label={chart.title}>
        {chart.type === 'line' ? (
          <polyline points={points} fill="none" stroke="#2563eb" strokeWidth="2.5" strokeLinejoin="round" />
        ) : (
          values.map((v, i) => (
            <rect key={i} x={i * bw + bw * 0.15} width={bw * 0.7} y={H - (v / max) * (H - 12)} height={(v / max) * (H - 12)} rx={Math.min(4, bw * 0.2)} fill={i === peak ? '#1d4ed8' : '#93b4f5'}>
              <title>{`${chart.labels[i]}: ${fmt(v, chart.unit)}`}</title>
            </rect>
          ))
        )}
        {chart.labels.map((l, i) => (i % step === 0 ? (
          <text key={i} x={i * bw + bw / 2} y={H + 16} textAnchor="middle" fontSize="11" fill="#64748b">{l}</text>
        ) : null))}
      </svg>
    </figure>
  );
}

// ── Acciones propuestas ────────────────────────────────────
function PurchaseOrderCard({ action }: { action: Extract<AgentAction, { type: 'purchase_order' }> }) {
  const total = action.items.reduce((n, i) => n + (i.price ? i.price * i.quantity : 0), 0);
  const message = [
    t('agents:pedido_saludo', { supplier: action.supplierName }),
    ...action.items.map((i) => `• ${i.quantity} ${i.unit || ''} ${i.itemName}`.replace(/\s+/g, ' ').trim()),
    action.note ? `\n${action.note}` : '',
    t('agents:pedido_gracias'),
  ].filter(Boolean).join('\n');
  const wa = whatsappNumber(action.phone);
  return (
    <div className="mt-3 rounded-2xl border border-emerald-200 bg-emerald-50/50 p-4">
      <p className="flex items-center gap-2 text-sm font-bold text-emerald-900"><ShoppingCart className="w-4 h-4" aria-hidden /> {t('agents:pedido_para', { supplier: action.supplierName })}</p>
      <ul className="mt-2 divide-y divide-emerald-100 text-sm">
        {action.items.map((i, k) => (
          <li key={k} className="flex justify-between gap-3 py-1.5">
            <span>{i.quantity} {i.unit} · {i.itemName}</span>
            <span className="tabular-nums text-slate-700">{i.price ? formatCurrency(i.price * i.quantity) : '—'}</span>
          </li>
        ))}
      </ul>
      {total > 0 && <p className="mt-1 text-right text-sm font-black tabular-nums text-emerald-900">{t('agents:total_estimado', { total: formatCurrency(total) })}</p>}
      <div className="mt-3 flex flex-wrap gap-2">
        {wa ? (
          <a href={`https://wa.me/${wa}?text=${encodeURIComponent(message)}`} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 min-h-[40px] px-4 rounded-xl bg-emerald-600 text-sm font-bold text-white hover:bg-emerald-700">
            <MessageCircle className="w-4 h-4" aria-hidden /> {t('agents:enviar_whatsapp')}
          </a>
        ) : (
          <span className="text-xs text-emerald-800">{t('agents:sin_whatsapp')}</span>
        )}
        <button type="button" onClick={() => copyText(message).then(() => toast.success(t('agents:copiado')))} className="min-h-[40px] px-4 rounded-xl border border-emerald-200 bg-white text-sm font-bold text-emerald-800">
          {t('agents:copiar_pedido')}
        </button>
      </div>
    </div>
  );
}

function CouponCard({ action }: { action: Extract<AgentAction, { type: 'create_coupon' }> }) {
  const [done, setDone] = useState(false);
  const [busy, setBusy] = useState(false);
  const value = action.discountType === 'PERCENT' ? `${action.value} %` : formatCurrency(action.value);
  return (
    <div className="mt-3 rounded-2xl border border-violet-200 bg-violet-50/50 p-4">
      <p className="flex items-center gap-2 text-sm font-bold text-violet-900"><Ticket className="w-4 h-4" aria-hidden /> {t('agents:cupon_propuesto')}</p>
      <p className="mt-1 text-lg font-black tracking-wide text-slate-900">{action.code} <span className="text-violet-700">-{value}</span></p>
      <p className="text-xs text-slate-600">
        {action.description ? `${action.description} · ` : ''}
        {action.minPurchase ? `${t('coupons:desde', { amount: formatCurrency(action.minPurchase) })} · ` : ''}
        {t('agents:vigencia', { count: action.days })}
      </p>
      <button
        type="button"
        disabled={done || busy}
        onClick={async () => {
          setBusy(true);
          try {
            await agentsAPI.createCoupon(action);
            setDone(true);
            toast.success(t('coupons:creado', { code: action.code }));
          } catch (e) {
            toast.error(errorMessage(e));
          } finally {
            setBusy(false);
          }
        }}
        className="mt-3 min-h-[40px] px-4 rounded-xl bg-violet-600 text-sm font-bold text-white hover:bg-violet-700 disabled:opacity-60"
      >
        {done ? t('agents:cupon_creado') : t('agents:crear_cupon')}
      </button>
    </div>
  );
}

// ── Perfil del negocio ─────────────────────────────────────

const TONES: AiProfile['tone'][] = ['cercano', 'profesional', 'divertido', 'elegante'];
const pfield = 'w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-violet-500/40';

function ProfileModal({ initial, onClose, onSaved }: { initial: AiProfile; onClose: () => void; onSaved: (p: AiProfile) => void }) {
  const [p, setP] = useState<AiProfile>(initial);
  const [busy, setBusy] = useState(false);
  const set = <K extends keyof AiProfile>(k: K, v: AiProfile[K]) => setP((x) => ({ ...x, [k]: v }));
  const save = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      const r = await agentsAPI.saveProfile(p);
      onSaved(r.profile);
      toast.success(t('agents:perfil_guardado'));
      onClose();
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };
  return createPortal(
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/50 p-4" role="dialog" aria-modal="true" aria-labelledby="ai-profile-title">
      <form onSubmit={save} className="flex max-h-[90vh] w-full max-w-xl flex-col rounded-3xl bg-white shadow-2xl">
        <div className="flex items-start justify-between gap-3 border-b border-slate-100 px-6 py-4">
          <div>
            <h3 id="ai-profile-title" className="font-black text-slate-900">{t('agents:perfil_titulo')}</h3>
            <p className="text-xs text-slate-500">{t('agents:perfil_desc')}</p>
          </div>
          <button type="button" onClick={onClose} className="rounded-xl p-2 text-slate-400 hover:bg-slate-100" aria-label={t('expenses:cerrar')}><X className="h-5 w-5" /></button>
        </div>
        <div className="flex-1 space-y-3 overflow-y-auto px-6 py-4">
          <label className="block space-y-1 text-xs font-bold text-slate-700">{t('agents:perfil_oferta')}
            <textarea rows={3} maxLength={400} required minLength={10} className={pfield} value={p.offer} onChange={(e) => set('offer', e.target.value)} placeholder={t('agents:perfil_oferta_ej')} />
          </label>
          <label className="block space-y-1 text-xs font-bold text-slate-700">{t('agents:perfil_clientes')}
            <input maxLength={200} className={pfield} value={p.audience} onChange={(e) => set('audience', e.target.value)} placeholder={t('agents:perfil_clientes_ej')} />
          </label>
          <label className="block space-y-1 text-xs font-bold text-slate-700">{t('agents:perfil_distinto')}
            <input maxLength={200} className={pfield} value={p.difference} onChange={(e) => set('difference', e.target.value)} placeholder={t('agents:perfil_distinto_ej')} />
          </label>
          <div className="grid gap-3 sm:grid-cols-2">
            <label className="block space-y-1 text-xs font-bold text-slate-700">{t('agents:perfil_tono')}
              <select className={pfield} value={p.tone} onChange={(e) => set('tone', e.target.value as AiProfile['tone'])}>
                {TONES.map((x) => <option key={x} value={x}>{t(`agents:tono_${x}`)}</option>)}
              </select>
            </label>
            <fieldset className="space-y-1">
              <legend className="text-xs font-bold text-slate-700">{t('agents:perfil_colores')}</legend>
              <div className="flex gap-2">
                {[0, 1].map((i) => (
                  <input key={i} type="color" aria-label={t(i ? 'agents:color_acento' : 'agents:color_principal')} value={p.colors[i]} onChange={(e) => set('colors', (i ? [p.colors[0], e.target.value] : [e.target.value, p.colors[1]]) as AiProfile['colors'])} className="h-[42px] w-full cursor-pointer rounded-xl border border-slate-300 bg-white p-1" />
                ))}
              </div>
            </fieldset>
            <label className="block space-y-1 text-xs font-bold text-slate-700">WhatsApp
              <input inputMode="tel" maxLength={20} className={pfield} value={p.whatsapp} onChange={(e) => set('whatsapp', e.target.value)} placeholder="3001234567" />
            </label>
            <label className="block space-y-1 text-xs font-bold text-slate-700">Instagram
              <input maxLength={40} className={pfield} value={p.instagram} onChange={(e) => set('instagram', e.target.value)} placeholder="@minegocio" />
            </label>
          </div>
        </div>
        <div className="flex justify-end gap-2 border-t border-slate-100 px-6 py-3">
          <button type="button" onClick={onClose} className="min-h-[44px] rounded-xl px-4 text-sm font-bold text-slate-600 hover:bg-slate-100">{t('agents:cancelar')}</button>
          <button type="submit" disabled={busy} className="min-h-[44px] rounded-xl bg-slate-900 px-5 text-sm font-bold text-white disabled:opacity-60">{t('agents:guardar')}</button>
        </div>
      </form>
    </div>,
    document.body,
  );
}

// ── Respuesta del agente ───────────────────────────────────

function Kpis({ kpis }: { kpis: AgentKpi[] }) {
  if (!kpis.length) return null;
  return (
    <dl className="mt-3 grid gap-2" style={{ gridTemplateColumns: `repeat(${Math.min(kpis.length, 4)}, minmax(0, 1fr))` }}>
      {kpis.map((k, i) => {
        const down = k.delta?.trim().startsWith('-');
        return (
          <div key={i} className="rounded-2xl border border-slate-200 bg-slate-50/70 px-3 py-2.5">
            <dt className="truncate text-[11px] font-bold uppercase tracking-wide text-slate-500">{k.label}</dt>
            <dd className="mt-0.5 text-lg font-black tabular-nums text-slate-900">{k.value}</dd>
            {k.delta && <dd className={`text-xs font-bold tabular-nums ${down ? 'text-rose-700' : 'text-emerald-700'}`}>{k.delta}</dd>}
          </div>
        );
      })}
    </dl>
  );
}

function FlyerCard({ flyer, onOpen }: { flyer: FlyerCopy; onOpen: () => void }) {
  return (
    <div className="mt-3 flex items-center gap-4 rounded-2xl border border-violet-200 bg-gradient-to-br from-violet-50 to-white p-4">
      <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-violet-600 text-white"><Wand2 className="h-6 w-6" aria-hidden /></span>
      <div className="min-w-0 flex-1">
        <p className="text-xs font-bold uppercase tracking-wide text-violet-700">{t('agents:flyer_listo')}</p>
        <p className="truncate font-black text-slate-900">{flyer.headline} <span className="text-violet-700">{flyer.accent}</span></p>
      </div>
      <button type="button" onClick={onOpen} className="min-h-[44px] shrink-0 rounded-xl bg-violet-600 px-4 text-sm font-bold text-white hover:bg-violet-700">{t('agents:flyer_abrir')}</button>
    </div>
  );
}

function AssistantMessage({ m, onFlyer }: { m: AgentMessage; onFlyer: (f: OpenFlyer) => void }) {
  return (
    <div className="max-w-[48rem] rounded-3xl border border-slate-200 bg-white px-5 py-4 text-sm text-slate-800 shadow-sm">
      {m.headline && <p className="text-base font-black leading-snug text-slate-900">{m.headline}</p>}
      <Kpis kpis={m.kpis || []} />
      <div className={m.headline || m.kpis?.length ? 'mt-2' : ''}><RichText text={m.content} /></div>
      {m.chart && <Chart chart={m.chart} />}
      {m.flyers && m.flyers.length > 0 ? (
        <Suspense fallback={null}>
          <FlyerGallery flyers={m.flyers} fresh={Date.now() - new Date(m.createdAt).getTime() < 5 * 60_000} onOpen={(copy, template, photo) => onFlyer({ copy, template, photo })} />
        </Suspense>
      ) : m.flyer ? <FlyerCard flyer={m.flyer} onOpen={() => onFlyer({ copy: m.flyer! })} /> : null}
      {m.actions.map((a, i) => (a.type === 'purchase_order' ? <PurchaseOrderCard key={i} action={a} /> : <CouponCard key={i} action={a} />))}
    </div>
  );
}

const TASK_ICONS: Record<string, typeof BarChart3> = {
  semana: CalendarRange, margen: Percent, horas: Clock3, proyeccion: TrendingUp, gastos: Wallet,
  lista: ClipboardList, agota: AlertTriangle, precios: Scale, quieto: PackageX,
  flyer: Wand2, dia_flojo: CalendarClock, textos: MessageSquareText, regreso: UserRoundCheck, empujar: Rocket,
};

const STEPS: Record<AgentId, string[]> = {
  backoffice: ['agents:paso_ventas', 'agents:paso_comparar', 'agents:paso_escribir'],
  purchasing: ['agents:paso_inventario', 'agents:paso_proveedores', 'agents:paso_escribir'],
  marketing: ['agents:paso_tendencias', 'agents:paso_idea', 'agents:paso_escribir'],
};

// ── Módulo ──────────────────────────────────────────────────

export function AgentsModule() {
  const allowed = useFeature('ai_agents');
  const [agent, setAgent] = useState<AgentId>('backoffice');
  const [messages, setMessages] = useState<AgentMessage[]>([]);
  const [question, setQuestion] = useState('');
  const [busy, setBusy] = useState(false);
  const [live, setLive] = useState('');
  const [step, setStep] = useState(0);
  const [ai, setAi] = useState<AiSettings | null>(null);
  const [preview, setPreview] = useState<unknown>(null);
  const [profile, setProfile] = useState<AiProfile | null>(null);
  const [editProfile, setEditProfile] = useState(false);
  const [flyer, setFlyer] = useState<OpenFlyer | null>(null);
  const [flyerAsk, setFlyerAsk] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  const abort = useRef<AbortController | null>(null);

  useEffect(() => {
    aiSettingsAPI.get().then(setAi).catch(() => setAi(null));
    agentsAPI.profile().then((r) => setProfile(r.profile)).catch(() => setProfile(null));
    return () => abort.current?.abort();
  }, []);
  useEffect(() => {
    if (!allowed) return;
    setFlyerAsk(false);
    agentsAPI.messages(agent).then(setMessages).catch(() => setMessages([]));
  }, [agent, allowed]);
  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [messages, busy, live]);
  // Pasos visibles mientras el agente arranca
  useEffect(() => {
    if (!busy || live) return;
    const id = setInterval(() => setStep((n) => Math.min(n + 1, 2)), 1600);
    return () => clearInterval(id);
  }, [busy, live]);

  if (!allowed) return <PlanLocked feature="ai_agents" />;

  const tasks = AGENT_TASKS.filter((x) => x.agent === agent);

  const run = async (input: { question?: string; task?: AgentTask }) => {
    const q = (input.question || '').trim();
    if ((!q && !input.task) || busy) return;
    const shown = q || t(`agents:tarea_${input.task!.id}`);
    setQuestion('');
    setFlyerAsk(false);
    setBusy(true);
    setLive('');
    setStep(0);
    const pending: AgentMessage = { id: `tmp-${Date.now()}`, role: 'user', content: shown, chart: null, actions: [], userName: null, createdAt: new Date().toISOString() };
    setMessages((m) => [...m, pending]);
    abort.current = new AbortController();
    try {
      const reply = await agentsAPI.stream(
        agent,
        { question: q, task: input.task?.id ?? null, taskLabel: shown, lang: getLanguage() },
        (d) => setLive((x) => x + d),
        abort.current.signal,
      );
      setMessages((m) => [...m, reply]);

    } catch (e: any) {
      if (e?.name === 'AbortError') return;
      setMessages((m) => m.filter((x) => x.id !== pending.id));
      if (q) setQuestion(q);
      const code = e instanceof ApiError ? e.code : '';
      toast.error(errorMessage(e), code === 'AI_CONSENT_REQUIRED' ? t('agents:falta_permiso') : undefined);
    } finally {
      setBusy(false);
      setLive('');
    }
  };

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (flyerAsk) run({ question, task: AGENT_TASKS.find((x) => x.id === 'flyer') });
    else run({ question });
  };

  const pickTask = (task: AgentTask) => {
    if (task.flyer) {
      setFlyerAsk(true);
      document.getElementById('agent-question')?.focus();
      return;
    }
    run({ task });
  };

  const current = AGENTS.find((a) => a.id === agent)!;
  const needsProfile = profile !== null && !profileReady(profile);

  return (
    <div className="grid h-[calc(100vh-7rem)] min-h-[32rem] gap-4 lg:grid-cols-[18rem_minmax(0,1fr)]">
      <aside className="space-y-2 overflow-y-auto">
        <div className="px-1 pb-2">
          <h2 className="flex items-center gap-2 text-xl font-black text-slate-900"><Sparkles className="h-5 w-5 text-violet-600" aria-hidden /> {t('agents:titulo')}</h2>
          <p className="mt-1 text-xs text-slate-500">{t('agents:bajada')}</p>
        </div>
        {AGENTS.map(({ id, icon: Icon, tone }) => (
          <button
            key={id}
            type="button"
            onClick={() => setAgent(id)}
            aria-pressed={agent === id}
            className={`w-full rounded-2xl border p-4 text-left transition-colors ${agent === id ? 'border-slate-900 bg-white shadow-sm' : 'border-slate-200 bg-white/60 hover:bg-white'}`}
          >
            <span className={`inline-grid h-9 w-9 place-items-center rounded-xl ${tone}`}><Icon className="h-5 w-5" aria-hidden /></span>
            <span className="mt-2 block font-bold text-slate-900">{t(`agents:${id}`)}</span>
            <span className="block text-xs leading-relaxed text-slate-500">{t(`agents:${id}_desc`)}</span>
          </button>
        ))}
        <button type="button" onClick={() => setEditProfile(true)} className={`w-full rounded-2xl border p-4 text-left ${needsProfile ? 'border-amber-300 bg-amber-50' : 'border-slate-200 bg-white/60 hover:bg-white'}`}>
          <span className="flex items-center gap-2 text-sm font-bold text-slate-900"><Store className="h-4 w-4" aria-hidden /> {t('agents:perfil_titulo')}</span>
          <span className="mt-0.5 block text-xs leading-relaxed text-slate-600">{needsProfile ? t('agents:perfil_falta') : profile?.offer || t('agents:perfil_desc')}</span>
        </button>
      </aside>

      <section className="flex min-h-0 flex-col rounded-3xl border border-slate-200 bg-slate-50/60">
        <header className="flex items-center justify-between gap-3 rounded-t-3xl border-b border-slate-200 bg-white px-5 py-3">
          <p className="flex items-center gap-2 font-bold text-slate-900"><span className={`inline-grid h-8 w-8 place-items-center rounded-lg ${current.tone}`}><current.icon className="h-4 w-4" aria-hidden /></span>{t(`agents:${agent}`)}</p>
          <div className="flex gap-1">
            <button type="button" onClick={async () => setPreview(await agentsAPI.context(agent))} className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg px-3 text-xs font-bold text-slate-600 hover:bg-slate-100">
              <Eye className="h-4 w-4" aria-hidden /> {t('agents:que_se_envia')}
            </button>
            {messages.length > 0 && (
              <button type="button" onClick={async () => { await agentsAPI.clear(agent); setMessages([]); }} className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg px-3 text-xs font-bold text-slate-600 hover:bg-slate-100">
                <RotateCcw className="h-4 w-4" aria-hidden /> {t('agents:nueva_conversacion')}
              </button>
            )}
          </div>
        </header>

        <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4" aria-live="polite">
          {ai && !ai.consent && <p className="mb-4 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">{t('agents:sin_permiso')}</p>}
          {needsProfile && (
            <p className="mb-4 flex flex-wrap items-center gap-2 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">
              {t('agents:perfil_aviso')}
              <button type="button" onClick={() => setEditProfile(true)} className="font-bold underline">{t('agents:perfil_completar')}</button>
            </p>
          )}

          {messages.length === 0 && !busy && (
            <div className="mx-auto max-w-3xl py-4">
              <p className="text-lg font-black text-slate-900">{t(`agents:${agent}_bienvenida`)}</p>
              <p className="mt-1 text-sm text-slate-600">{t('agents:elige_tarea')}</p>
              <div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
                {tasks.map((task) => {
                  const Icon = TASK_ICONS[task.id] || Sparkles;
                  return (
                    <button key={task.id} type="button" onClick={() => pickTask(task)} className={`group rounded-2xl border bg-white p-4 text-left transition hover:-translate-y-0.5 hover:shadow-md ${task.flyer ? 'border-violet-300 ring-1 ring-violet-200' : 'border-slate-200 hover:border-slate-300'}`}>
                      <span className={`inline-grid h-10 w-10 place-items-center rounded-xl ${task.flyer ? 'bg-violet-600 text-white' : current.tone}`}><Icon className="h-5 w-5" aria-hidden /></span>
                      <span className="mt-3 block font-bold text-slate-900">{t(`agents:tarea_${task.id}`)}</span>
                      <span className="mt-0.5 block text-xs leading-relaxed text-slate-500">{t(`agents:tarea_${task.id}_d`)}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          <ul className="space-y-4">
            {messages.map((m) => (
              <li key={m.id} className={m.role === 'user' ? 'flex justify-end' : ''}>
                {m.role === 'user'
                  ? <p className="max-w-[80%] rounded-2xl rounded-br-md bg-slate-900 px-4 py-2.5 text-sm text-white">{m.content}</p>
                  : <AssistantMessage m={m} onFlyer={setFlyer} />}
              </li>
            ))}
            {busy && (
              <li>
                {live ? (
                  <div className="max-w-[48rem] rounded-3xl border border-slate-200 bg-white px-5 py-4 text-sm text-slate-800 shadow-sm">
                    <RichText text={visiblePart(live)} />
                    <span className="inline-block h-4 w-1.5 animate-pulse rounded-sm bg-violet-500 align-middle" aria-hidden />
                  </div>
                ) : (
                  <ol className="space-y-1.5 rounded-3xl border border-slate-200 bg-white px-5 py-4 text-sm" aria-label={t('agents:analizando')}>
                    {STEPS[agent].map((key, i) => (
                      <li key={key} className={`flex items-center gap-2 ${i <= step ? 'text-slate-800' : 'text-slate-400'}`}>
                        {i < step ? <Check className="h-4 w-4 text-emerald-600" aria-hidden /> : i === step ? <Loader2 className="h-4 w-4 animate-spin text-violet-600" aria-hidden /> : <span className="h-4 w-4" />}
                        {t(key)}
                      </li>
                    ))}
                  </ol>
                )}
              </li>
            )}
          </ul>
          <div ref={endRef} />
        </div>

        {messages.length > 0 && !busy && (
          <div className="flex gap-2 overflow-x-auto border-t border-slate-200 bg-white px-3 pt-3" role="list" aria-label={t('agents:tareas')}>
            {tasks.map((task) => (
              <button key={task.id} type="button" role="listitem" onClick={() => pickTask(task)} className={`shrink-0 rounded-full border px-3 py-1.5 text-xs font-bold ${task.flyer ? 'border-violet-300 bg-violet-50 text-violet-800' : 'border-slate-200 text-slate-700 hover:bg-slate-50'}`}>
                {t(`agents:tarea_${task.id}`)}
              </button>
            ))}
          </div>
        )}

        <form onSubmit={submit} className="rounded-b-3xl border-t border-slate-200 bg-white p-3">
          {flyerAsk && (
            <p className="mb-2 flex items-center justify-between gap-2 rounded-xl bg-violet-50 px-3 py-2 text-xs font-semibold text-violet-900">
              <span className="flex items-center gap-1.5"><Wand2 className="h-4 w-4" aria-hidden /> {t('agents:flyer_pregunta')}</span>
              <button type="button" onClick={() => setFlyerAsk(false)} className="rounded-lg p-1 hover:bg-violet-100" aria-label={t('agents:cancelar')}><X className="h-4 w-4" /></button>
            </p>
          )}
          <div className="flex gap-2">
            <label htmlFor="agent-question" className="sr-only">{t('agents:pregunta')}</label>
            <input
              id="agent-question"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              maxLength={800}
              placeholder={flyerAsk ? t('agents:flyer_placeholder') : t(`agents:${agent}_placeholder`)}
              className="min-h-[48px] flex-1 rounded-xl border border-slate-200 px-4 text-sm focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            />
            {flyerAsk && !question.trim() ? (
              <button type="submit" disabled={busy} className="inline-flex min-h-[48px] items-center gap-2 rounded-xl bg-violet-600 px-4 text-sm font-bold text-white disabled:opacity-40">{t('agents:flyer_tu_eliges')}</button>
            ) : (
              <button type="submit" disabled={busy || !question.trim()} className="inline-flex min-h-[48px] items-center gap-2 rounded-xl bg-slate-900 px-5 text-sm font-bold text-white disabled:opacity-40" aria-label={t('agents:enviar')}>
                <Send className="h-4 w-4" aria-hidden />
              </button>
            )}
          </div>
        </form>
      </section>

      {editProfile && profile && <ProfileModal initial={profile} onClose={() => setEditProfile(false)} onSaved={setProfile} />}
      {flyer && (
        <Suspense fallback={null}>
          <FlyerStudio key={`${flyer.copy.headline}-${flyer.template}`} initial={flyer.copy} initialTemplate={flyer.template} initialPhoto={flyer.photo} onClose={() => setFlyer(null)} />
        </Suspense>
      )}

      {preview !== null &&
        createPortal(
          <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/50 p-4" role="dialog" aria-modal="true" aria-labelledby="agent-preview-title">
            <div className="flex max-h-[85vh] w-full max-w-2xl flex-col rounded-3xl bg-white shadow-2xl">
              <div className="flex items-center justify-between border-b border-slate-100 px-6 py-4">
                <div>
                  <h3 id="agent-preview-title" className="font-black text-slate-900">{t('agents:que_se_envia')}</h3>
                  <p className="text-xs text-slate-500">{t('agents:que_se_envia_desc')}</p>
                </div>
                <button type="button" onClick={() => setPreview(null)} className="p-2 rounded-xl text-slate-400 hover:bg-slate-100" aria-label={t('expenses:cerrar')}><X className="w-5 h-5" /></button>
              </div>
              <pre className="flex-1 overflow-auto bg-slate-50 px-6 py-4 text-xs leading-relaxed text-slate-700">{JSON.stringify(preview, null, 2)}</pre>
            </div>
          </div>,
          document.body,
        )}
    </div>
  );
}
