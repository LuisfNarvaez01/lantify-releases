// ============================================
// COMPONENTS - Agentes de IA (Premium)
// ============================================
// Backoffice, Compras y Marketing. Cada respuesta puede traer un gráfico y
// acciones propuestas; ninguna acción se ejecuta sin que el administrador la
// confirme. "Qué datos se envían" muestra el resumen exacto que sale del equipo.

import { FormEvent, ReactNode, useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { BarChart3, Eye, Megaphone, MessageCircle, RotateCcw, Send, ShoppingCart, Sparkles, Ticket, X } from 'lucide-react';
import { agentsAPI, aiSettingsAPI, AgentAction, AgentChart, AgentId, AgentMessage, AiSettings } from '../../services/api';
import { ApiError, errorMessage } from '../../services/apiErrors';
import { formatCurrency } from '../../shared/formatUtils';
import { toast } from '../../shared/toast';
import { useFeature } from '../../shared/plan';
import { PlanLocked } from '../common/PlanLocked';
import { whatsappNumber } from '../admin/SuppliersPanel';
import { t, getLanguage, getLocale } from '../../i18n';
import { copyText } from '../../shared/browser';

const AGENTS: { id: AgentId; icon: typeof BarChart3; tone: string }[] = [
  { id: 'backoffice', icon: BarChart3, tone: 'text-blue-700 bg-blue-50' },
  { id: 'purchasing', icon: ShoppingCart, tone: 'text-emerald-700 bg-emerald-50' },
  { id: 'marketing', icon: Megaphone, tone: 'text-violet-700 bg-violet-50' },
];

// ── Texto con **negrita** y viñetas (sin HTML) ─────────────
const inline = (text: string): ReactNode[] =>
  text.split(/(\*\*[^*]+\*\*)/g).map((p, i) => (p.startsWith('**') && p.endsWith('**') ? <strong key={i}>{p.slice(2, -2)}</strong> : p));

function RichText({ text }: { text: string }) {
  const lines = text.split('\n').map((l) => l.trim()).filter(Boolean);
  const out: ReactNode[] = [];
  let bullets: string[] = [];
  const flush = () => {
    if (bullets.length) out.push(<ul key={`u${out.length}`} className="my-1.5 list-disc space-y-1 pl-5">{bullets.map((b, i) => <li key={i}>{inline(b)}</li>)}</ul>);
    bullets = [];
  };
  for (const l of lines) {
    if (/^([-•*]|\d+[.)])\s+/.test(l)) bullets.push(l.replace(/^([-•*]|\d+[.)])\s+/, ''));
    else {
      flush();
      out.push(<p key={`p${out.length}`} className="my-1.5">{inline(l)}</p>);
    }
  }
  flush();
  return <div className="leading-relaxed">{out}</div>;
}

// ── Gráfico simple en SVG (barras o línea) ─────────────────
const fmt = (v: number, unit: AgentChart['unit']) =>
  unit === 'COP' ? formatCurrency(v) : unit === '%' ? `${v.toLocaleString(getLocale())} %` : v.toLocaleString(getLocale());

function Chart({ chart }: { chart: AgentChart }) {
  const values = chart.series[0]?.values || [];
  const max = Math.max(1, ...values);
  const W = 560;
  const H = 180;
  const n = chart.labels.length;
  const bw = W / Math.max(1, n);
  const step = Math.ceil(n / 10);
  const points = values.map((v, i) => `${i * bw + bw / 2},${H - (v / max) * (H - 12)}`).join(' ');
  const peak = values.indexOf(max);
  return (
    <figure className="mt-3 rounded-2xl border border-slate-200 bg-white p-4">
      <figcaption className="flex items-baseline justify-between gap-3 text-xs">
        <span className="font-bold text-slate-700">{chart.title}</span>
        <span className="text-slate-500">{t('agents:maximo', { value: fmt(max, chart.unit), label: chart.labels[peak] })}</span>
      </figcaption>
      <svg viewBox={`0 0 ${W} ${H + 22}`} className="mt-2 w-full" role="img" aria-label={chart.title}>
        {chart.type === 'line' ? (
          <polyline points={points} fill="none" stroke="#2563eb" strokeWidth="2.5" strokeLinejoin="round" />
        ) : (
          values.map((v, i) => (
            <rect key={i} x={i * bw + bw * 0.15} width={bw * 0.7} y={H - (v / max) * (H - 12)} height={(v / max) * (H - 12)} rx={Math.min(4, bw * 0.2)} fill={i === peak ? '#1d4ed8' : '#93b4f5'}>
              <title>{`${chart.labels[i]}: ${fmt(v, chart.unit)}`}</title>
            </rect>
          ))
        )}
        {chart.labels.map((l, i) => (i % step === 0 ? (
          <text key={i} x={i * bw + bw / 2} y={H + 16} textAnchor="middle" fontSize="11" fill="#64748b">{l}</text>
        ) : null))}
      </svg>
    </figure>
  );
}

// ── Acciones propuestas ────────────────────────────────────
function PurchaseOrderCard({ action }: { action: Extract<AgentAction, { type: 'purchase_order' }> }) {
  const total = action.items.reduce((n, i) => n + (i.price ? i.price * i.quantity : 0), 0);
  const message = [
    t('agents:pedido_saludo', { supplier: action.supplierName }),
    ...action.items.map((i) => `• ${i.quantity} ${i.unit || ''} ${i.itemName}`.replace(/\s+/g, ' ').trim()),
    action.note ? `\n${action.note}` : '',
    t('agents:pedido_gracias'),
  ].filter(Boolean).join('\n');
  const wa = whatsappNumber(action.phone);
  return (
    <div className="mt-3 rounded-2xl border border-emerald-200 bg-emerald-50/50 p-4">
      <p className="flex items-center gap-2 text-sm font-bold text-emerald-900"><ShoppingCart className="w-4 h-4" aria-hidden /> {t('agents:pedido_para', { supplier: action.supplierName })}</p>
      <ul className="mt-2 divide-y divide-emerald-100 text-sm">
        {action.items.map((i, k) => (
          <li key={k} className="flex justify-between gap-3 py-1.5">
            <span>{i.quantity} {i.unit} · {i.itemName}</span>
            <span className="tabular-nums text-slate-700">{i.price ? formatCurrency(i.price * i.quantity) : '—'}</span>
          </li>
        ))}
      </ul>
      {total > 0 && <p className="mt-1 text-right text-sm font-black tabular-nums text-emerald-900">{t('agents:total_estimado', { total: formatCurrency(total) })}</p>}
      <div className="mt-3 flex flex-wrap gap-2">
        {wa ? (
          <a href={`https://wa.me/${wa}?text=${encodeURIComponent(message)}`} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 min-h-[40px] px-4 rounded-xl bg-emerald-600 text-sm font-bold text-white hover:bg-emerald-700">
            <MessageCircle className="w-4 h-4" aria-hidden /> {t('agents:enviar_whatsapp')}
          </a>
        ) : (
          <span className="text-xs text-emerald-800">{t('agents:sin_whatsapp')}</span>
        )}
        <button type="button" onClick={() => copyText(message).then(() => toast.success(t('agents:copiado')))} className="min-h-[40px] px-4 rounded-xl border border-emerald-200 bg-white text-sm font-bold text-emerald-800">
          {t('agents:copiar_pedido')}
        </button>
      </div>
    </div>
  );
}

function CouponCard({ action }: { action: Extract<AgentAction, { type: 'create_coupon' }> }) {
  const [done, setDone] = useState(false);
  const [busy, setBusy] = useState(false);
  const value = action.discountType === 'PERCENT' ? `${action.value} %` : formatCurrency(action.value);
  return (
    <div className="mt-3 rounded-2xl border border-violet-200 bg-violet-50/50 p-4">
      <p className="flex items-center gap-2 text-sm font-bold text-violet-900"><Ticket className="w-4 h-4" aria-hidden /> {t('agents:cupon_propuesto')}</p>
      <p className="mt-1 text-lg font-black tracking-wide text-slate-900">{action.code} <span className="text-violet-700">-{value}</span></p>
      <p className="text-xs text-slate-600">
        {action.description ? `${action.description} · ` : ''}
        {action.minPurchase ? `${t('coupons:desde', { amount: formatCurrency(action.minPurchase) })} · ` : ''}
        {t('agents:vigencia', { count: action.days })}
      </p>
      <button
        type="button"
        disabled={done || busy}
        onClick={async () => {
          setBusy(true);
          try {
            await agentsAPI.createCoupon(action);
            setDone(true);
            toast.success(t('coupons:creado', { code: action.code }));
          } catch (e) {
            toast.error(errorMessage(e));
          } finally {
            setBusy(false);
          }
        }}
        className="mt-3 min-h-[40px] px-4 rounded-xl bg-violet-600 text-sm font-bold text-white hover:bg-violet-700 disabled:opacity-60"
      >
        {done ? t('agents:cupon_creado') : t('agents:crear_cupon')}
      </button>
    </div>
  );
}

// ── Módulo ──────────────────────────────────────────────────

export function AgentsModule() {
  const allowed = useFeature('ai_agents');
  const [agent, setAgent] = useState<AgentId>('backoffice');
  const [messages, setMessages] = useState<AgentMessage[]>([]);
  const [question, setQuestion] = useState('');
  const [busy, setBusy] = useState(false);
  const [ai, setAi] = useState<AiSettings | null>(null);
  const [preview, setPreview] = useState<unknown>(null);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    aiSettingsAPI.get().then(setAi).catch(() => setAi(null));
  }, []);
  useEffect(() => {
    if (!allowed) return;
    agentsAPI.messages(agent).then(setMessages).catch(() => setMessages([]));
  }, [agent, allowed]);
  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [messages, busy]);

  if (!allowed) return <PlanLocked feature="ai_agents" />;

  const ask = async (text: string) => {
    const q = text.trim();
    if (!q || busy) return;
    setQuestion('');
    setBusy(true);
    const pending: AgentMessage = { id: `tmp-${Date.now()}`, role: 'user', content: q, chart: null, actions: [], userName: null, createdAt: new Date().toISOString() };
    setMessages((m) => [...m, pending]);
    try {
      const reply = await agentsAPI.ask(agent, q, getLanguage());
      setMessages((m) => [...m, reply]);
    } catch (e) {
      setMessages((m) => m.filter((x) => x.id !== pending.id));
      setQuestion(q);
      const code = e instanceof ApiError ? e.code : '';
      toast.error(errorMessage(e), code === 'AI_CONSENT_REQUIRED' ? t('agents:falta_permiso') : undefined);
    } finally {
      setBusy(false);
    }
  };

  const submit = (e: FormEvent) => {
    e.preventDefault();
    ask(question);
  };

  const current = AGENTS.find((a) => a.id === agent)!;
  const suggestions = [1, 2, 3].map((i) => t(`agents:${agent}_sugerencia_${i}`));

  return (
    <div className="grid h-[calc(100vh-7rem)] min-h-[32rem] gap-4 lg:grid-cols-[18rem_minmax(0,1fr)]">
      <aside className="space-y-2 overflow-y-auto">
        <div className="px-1 pb-2">
          <h2 className="flex items-center gap-2 text-xl font-black text-slate-900"><Sparkles className="w-5 h-5 text-violet-600" aria-hidden /> {t('agents:titulo')}</h2>
          <p className="mt-1 text-xs text-slate-500">{t('agents:bajada')}</p>
        </div>
        {AGENTS.map(({ id, icon: Icon, tone }) => (
          <button
            key={id}
            type="button"
            onClick={() => setAgent(id)}
            aria-pressed={agent === id}
            className={`w-full rounded-2xl border p-4 text-left transition-colors ${agent === id ? 'border-slate-900 bg-white shadow-sm' : 'border-slate-200 bg-white/60 hover:bg-white'}`}
          >
            <span className={`inline-grid h-9 w-9 place-items-center rounded-xl ${tone}`}><Icon className="w-5 h-5" aria-hidden /></span>
            <span className="mt-2 block font-bold text-slate-900">{t(`agents:${id}`)}</span>
            <span className="block text-xs leading-relaxed text-slate-500">{t(`agents:${id}_desc`)}</span>
          </button>
        ))}
      </aside>

      <section className="flex min-h-0 flex-col rounded-3xl border border-slate-200 bg-white">
        <header className="flex items-center justify-between gap-3 border-b border-slate-100 px-5 py-3">
          <p className="font-bold text-slate-900">{t(`agents:${agent}`)}</p>
          <div className="flex gap-1">
            <button type="button" onClick={async () => setPreview(await agentsAPI.context(agent))} className="inline-flex items-center gap-1.5 min-h-[36px] px-3 rounded-lg text-xs font-bold text-slate-600 hover:bg-slate-100">
              <Eye className="w-4 h-4" aria-hidden /> {t('agents:que_se_envia')}
            </button>
            {messages.length > 0 && (
              <button type="button" onClick={async () => { await agentsAPI.clear(agent); setMessages([]); }} className="inline-flex items-center gap-1.5 min-h-[36px] px-3 rounded-lg text-xs font-bold text-slate-600 hover:bg-slate-100">
                <RotateCcw className="w-4 h-4" aria-hidden /> {t('agents:nueva_conversacion')}
              </button>
            )}
          </div>
        </header>

        <div className="flex-1 min-h-0 overflow-y-auto px-5 py-4" aria-live="polite">
          {ai && !ai.consent && (
            <p className="mb-4 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">{t('agents:sin_permiso')}</p>
          )}
          {messages.length === 0 && (
            <div className="mx-auto max-w-md py-10 text-center">
              <span className={`inline-grid h-14 w-14 place-items-center rounded-2xl ${current.tone}`}><current.icon className="w-7 h-7" aria-hidden /></span>
              <p className="mt-3 font-bold text-slate-800">{t(`agents:${agent}_bienvenida`)}</p>
              <div className="mt-5 flex flex-col gap-2">
                {suggestions.map((s) => (
                  <button key={s} type="button" onClick={() => ask(s)} className="rounded-xl border border-slate-200 px-4 py-2.5 text-left text-sm text-slate-700 hover:border-slate-400 hover:bg-slate-50">
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}
          <ul className="space-y-4">
            {messages.map((m) => (
              <li key={m.id} className={m.role === 'user' ? 'flex justify-end' : ''}>
                {m.role === 'user' ? (
                  <p className="max-w-[80%] rounded-2xl rounded-br-md bg-slate-900 px-4 py-2.5 text-sm text-white">{m.content}</p>
                ) : (
                  <div className="max-w-[46rem] text-sm text-slate-800">
                    <RichText text={m.content} />
                    {m.chart && <Chart chart={m.chart} />}
                    {m.actions.map((a, i) =>
                      a.type === 'purchase_order' ? <PurchaseOrderCard key={i} action={a} /> : <CouponCard key={i} action={a} />,
                    )}
                  </div>
                )}
              </li>
            ))}
            {busy && (
              <li className="flex items-center gap-2 text-sm text-slate-500">
                <Sparkles className="w-4 h-4 animate-pulse text-violet-500" aria-hidden /> {t('agents:analizando')}
              </li>
            )}
          </ul>
          <div ref={endRef} />
        </div>

        <form onSubmit={submit} className="flex gap-2 border-t border-slate-100 p-3">
          <label htmlFor="agent-question" className="sr-only">{t('agents:pregunta')}</label>
          <input
            id="agent-question"
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            maxLength={800}
            placeholder={t(`agents:${agent}_placeholder`)}
            className="flex-1 min-h-[48px] rounded-xl border border-slate-200 px-4 text-sm focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20"
          />
          <button type="submit" disabled={busy || !question.trim()} className="inline-flex items-center gap-2 min-h-[48px] px-5 rounded-xl bg-slate-900 text-sm font-bold text-white disabled:opacity-40" aria-label={t('agents:enviar')}>
            <Send className="w-4 h-4" aria-hidden />
          </button>
        </form>
      </section>

      {preview !== null &&
        createPortal(
          <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/50 p-4" role="dialog" aria-modal="true" aria-labelledby="agent-preview-title">
            <div className="flex max-h-[85vh] w-full max-w-2xl flex-col rounded-3xl bg-white shadow-2xl">
              <div className="flex items-center justify-between border-b border-slate-100 px-6 py-4">
                <div>
                  <h3 id="agent-preview-title" className="font-black text-slate-900">{t('agents:que_se_envia')}</h3>
                  <p className="text-xs text-slate-500">{t('agents:que_se_envia_desc')}</p>
                </div>
                <button type="button" onClick={() => setPreview(null)} className="p-2 rounded-xl text-slate-400 hover:bg-slate-100" aria-label={t('expenses:cerrar')}><X className="w-5 h-5" /></button>
              </div>
              <pre className="flex-1 overflow-auto bg-slate-50 px-6 py-4 text-xs leading-relaxed text-slate-700">{JSON.stringify(preview, null, 2)}</pre>
            </div>
          </div>,
          document.body,
        )}
    </div>
  );
}
