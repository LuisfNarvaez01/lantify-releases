// ============================================
// COMPONENTS - Estudio de flyers (agente de marketing, Lantify 3.0)
// ============================================
// Misma técnica de los flyers de Lantify: una plantilla HTML a 1080 px con
// Plus Jakarta Sans, titular grande con la segunda línea en el color de acento,
// foto protagonista, beneficios con icono, sello de oferta y franja de contacto.
// La IA solo escribe el texto (nunca dibuja letras en la foto). La imagen final
// se arma en este equipo con html-to-image.

import '@fontsource/plus-jakarta-sans/500.css';
import '@fontsource/plus-jakarta-sans/600.css';
import '@fontsource/plus-jakarta-sans/700.css';
import '@fontsource/plus-jakarta-sans/800.css';
import { CSSProperties, ReactNode, useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { toPng } from 'html-to-image';
import {
  Check, Clock, Download, Gift, Heart, ImagePlus, Leaf, Loader2, MapPin, MessageCircle, Phone, Share2, ShieldCheck,
  Sparkles, Star, Tag, Truck, Upload, Wand2, X,
} from 'lucide-react';
import { agentsAPI } from '../../services/api';
import { errorMessage } from '../../services/apiErrors';
import { usePosStore } from '../../store/usePosStore';
import { toast } from '../../shared/toast';
import { t } from '../../i18n';
import { FLYER_ICONS, kindOf, type AiProfile, type FlyerCopy, type FlyerIcon } from '../../../../src/domain/v3/agents';

const ICONS: Record<FlyerIcon, typeof Star> = {
  star: Star, clock: Clock, truck: Truck, shield: ShieldCheck, sparkles: Sparkles, heart: Heart,
  tag: Tag, check: Check, leaf: Leaf, gift: Gift, phone: Phone, map: MapPin,
};

type Template = 'claro' | 'oscuro' | 'foto';
type Format = 'post' | 'story' | 'square';
const SIZES: Record<Format, number> = { post: 1350, story: 1920, square: 1080 };
const W = 1080;
const FONT = "'Plus Jakarta Sans', 'Outfit', system-ui, sans-serif";

interface Brand { name: string; logo: string | null; profile: AiProfile }

const WaIcon = ({ size = 34 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <path d="M3 21l1.6-4.6A9 9 0 1 1 8 20z" /><path d="M9 9.2c.3 2.8 2.6 5.3 5.6 5.6l1-1.4-1.9-1-.9.7a4 4 0 0 1-2-2l.7-.9-1-1.9z" />
  </svg>
);
const IgIcon = ({ size = 34 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
    <rect x="3" y="3" width="18" height="18" rx="5" /><circle cx="12" cy="12" r="4" /><circle cx="17.5" cy="6.5" r="1" fill="currentColor" />
  </svg>
);

const phoneText = (raw: string) => {
  const d = raw.replace(/\D/g, '').replace(/^57(?=\d{10}$)/, '');
  return d.length === 10 ? `${d.slice(0, 3)} ${d.slice(3, 6)} ${d.slice(6)}` : raw;
};

/** Franja de contacto: WhatsApp e Instagram del perfil */
function Contact({ brand, color }: { brand: Brand; color: string }) {
  const { whatsapp, instagram } = brand.profile;
  if (!whatsapp && !instagram) return <span style={{ fontSize: 34, fontWeight: 800 }}>{brand.name}</span>;
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 44, fontSize: 36, fontWeight: 700, color }}>
      {whatsapp && <span style={{ display: 'inline-flex', alignItems: 'center', gap: 14 }}><WaIcon />{phoneText(whatsapp)}</span>}
      {whatsapp && instagram && <span style={{ width: 2, height: 42, background: color, opacity: 0.35 }} />}
      {instagram && <span style={{ display: 'inline-flex', alignItems: 'center', gap: 14 }}><IgIcon />@{instagram}</span>}
    </div>
  );
}

function BrandRow({ brand, color }: { brand: Brand; color: string }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 18 }}>
      {brand.logo && <img src={brand.logo} alt="" style={{ width: 72, height: 72, objectFit: 'contain', borderRadius: 18 }} />}
      <span style={{ fontSize: 40, fontWeight: 800, letterSpacing: -1, color }}>{brand.name}</span>
    </div>
  );
}

function Photo({ src, style, colors, word }: { src: string | null; style: CSSProperties; colors?: [string, string]; word?: string }) {
  if (src) return <img src={src} alt="" style={{ objectFit: 'cover', display: 'block', ...style }} />;
  // Sin foto: un fondo con los colores de la marca y la palabra principal, nunca un hueco
  const [a, b] = colors || ['#1d4ed8', '#f59e0b'];
  return (
    <div style={{ ...style, background: `radial-gradient(120% 90% at 20% 15%, ${b}cc, transparent 55%), linear-gradient(135deg, ${a}, ${a}dd 60%, #0b1220)`, display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
      {word && <span style={{ fontSize: 150, fontWeight: 800, letterSpacing: -6, color: 'rgba(255,255,255,.16)', whiteSpace: 'nowrap' }}>{word}</span>}
    </div>
  );
}

/** El flyer a tamaño real (1080 px de ancho) */
export function FlyerCanvas({ copy, brand, photo, template, format }: { copy: FlyerCopy; brand: Brand; photo: string | null; template: Template; format: Format }) {
  const H = SIZES[format];
  const [c1, c2] = brand.profile.colors;
  const tall = format === 'story';
  const square = format === 'square';
  const base: CSSProperties = { width: W, height: H, position: 'relative', overflow: 'hidden', display: 'flex', flexDirection: 'column', fontFamily: FONT, WebkitFontSmoothing: 'antialiased' };
  const benefits = copy.benefits.slice(0, square ? 3 : 4);

  if (template === 'foto') {
    return (
      <div style={{ ...base, background: '#0b1220', color: '#fff' }}>
        <Photo src={photo} colors={brand.profile.colors} word={copy.headline} style={{ position: 'absolute', inset: 0, width: W, height: H }} />
        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(5,10,25,.55) 0%, rgba(5,10,25,0) 28%, rgba(5,10,25,.35) 52%, rgba(5,10,25,.92) 100%)' }} />
        <div style={{ position: 'relative', padding: '56px 64px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <BrandRow brand={brand} color="#fff" />
          {copy.offer && (
            <div style={{ width: 230, height: 230, borderRadius: '50%', background: c2, color: '#0b1220', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center', transform: 'rotate(-8deg)', boxShadow: '0 20px 40px -12px rgba(0,0,0,.5)' }}>
              <span style={{ fontSize: copy.offer.length > 8 ? 46 : 60, fontWeight: 800, letterSpacing: -2, lineHeight: 1 }}>{copy.offer}</span>
              {copy.offerNote && <span style={{ fontSize: 20, fontWeight: 700, marginTop: 8, padding: '0 22px', lineHeight: 1.15 }}>{copy.offerNote}</span>}
            </div>
          )}
        </div>
        <div style={{ position: 'relative', marginTop: 'auto', padding: '0 64px 40px' }}>
          {copy.kicker && <span style={{ display: 'inline-block', background: c1, color: '#fff', borderRadius: 999, padding: '12px 26px', fontSize: 26, fontWeight: 800 }}>{copy.kicker}</span>}
          <h1 style={{ margin: '22px 0 0', fontSize: tall ? 112 : 96, lineHeight: 0.98, fontWeight: 800, letterSpacing: -3.5 }}>
            {copy.headline}{copy.accent && <><br /><span style={{ color: c2 }}>{copy.accent}</span></>}
          </h1>
          {copy.subtitle && <p style={{ margin: '22px 0 0', fontSize: 32, lineHeight: 1.3, fontWeight: 500, color: 'rgba(255,255,255,.88)', maxWidth: 900 }}>{copy.subtitle}</p>}
          {benefits.length > 0 && (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 14, marginTop: 30 }}>
              {benefits.map((b, i) => { const I = ICONS[b.icon]; return (
                <span key={i} style={{ display: 'inline-flex', alignItems: 'center', gap: 10, background: 'rgba(255,255,255,.14)', border: '1px solid rgba(255,255,255,.28)', borderRadius: 999, padding: '12px 22px', fontSize: 26, fontWeight: 700 }}>
                  <I size={28} strokeWidth={2.2} color={c2} />{b.text}
                </span>
              ); })}
            </div>
          )}
        </div>
        <div style={{ position: 'relative', height: 120, background: 'rgba(255,255,255,.96)', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 36 }}>
          {copy.cta && <span style={{ background: c1, color: '#fff', borderRadius: 999, padding: '14px 30px', fontSize: 30, fontWeight: 800 }}>{copy.cta}</span>}
          <Contact brand={brand} color="#0b1220" />
        </div>
      </div>
    );
  }

  const dark = template === 'oscuro';
  const ink = dark ? '#ffffff' : '#0b1b3f';
  const soft = dark ? '#cbd5e1' : '#334155';
  const photoH = square ? 420 : tall ? 820 : 560;
  return (
    <div style={{ ...base, background: dark ? `radial-gradient(900px 700px at 85% 10%, ${c1}55, transparent 60%), #070d1f` : `linear-gradient(180deg, #f8fafc 0%, #eef2f7 100%)`, color: ink }}>
      <div style={{ padding: '60px 64px 0', display: 'flex', flexDirection: 'column', alignItems: dark ? 'flex-start' : 'center', textAlign: dark ? 'left' : 'center' }}>
        <BrandRow brand={brand} color={ink} />
        {copy.kicker && (
          <span style={{ marginTop: 30, display: 'inline-block', borderRadius: 999, padding: '10px 24px', fontSize: 26, fontWeight: 800, background: dark ? `${c2}26` : `${c1}1a`, color: dark ? c2 : c1, border: `1px solid ${dark ? c2 : c1}55` }}>{copy.kicker}</span>
        )}
        <h1 style={{ margin: '22px 0 0', fontSize: square ? 84 : 100, lineHeight: 0.98, fontWeight: 800, letterSpacing: -3.5 }}>
          {copy.headline}
          {copy.accent && <><br /><span style={dark ? { background: `linear-gradient(90deg, ${c1}, ${c2})`, WebkitBackgroundClip: 'text', backgroundClip: 'text', color: 'transparent' } : { color: c1 }}>{copy.accent}</span></>}
        </h1>
        {copy.subtitle && !square && <p style={{ margin: '20px 0 0', fontSize: 31, lineHeight: 1.3, fontWeight: 500, color: soft, maxWidth: 900 }}>{copy.subtitle}</p>}
      </div>

      <div style={{ position: 'relative', margin: `${square ? 28 : 40}px 64px 0` }}>
        <Photo src={photo} colors={brand.profile.colors} word={copy.headline} style={{ width: W - 128, height: photoH, borderRadius: 36, boxShadow: '0 30px 60px -22px rgba(15,23,42,.45)' }} />
        {copy.offer && (
          <div style={{ position: 'absolute', right: -14, bottom: -30, background: c1, color: '#fff', borderRadius: 32, padding: '18px 34px', boxShadow: `0 18px 36px -12px ${c1}`, textAlign: 'right' }}>
            <div style={{ fontSize: copy.offer.length > 8 ? 52 : 68, fontWeight: 800, letterSpacing: -2.5, lineHeight: 1 }}>{copy.offer}</div>
            {copy.offerNote && <div style={{ fontSize: 22, fontWeight: 700, marginTop: 6, opacity: 0.92 }}>{copy.offerNote}</div>}
          </div>
        )}
      </div>

      {benefits.length > 0 && (
        <div style={{ display: 'grid', gridTemplateColumns: `repeat(${benefits.length}, 1fr)`, gap: 18, margin: `${copy.offer ? 62 : 40}px 64px 0` }}>
          {benefits.map((b, i) => { const I = ICONS[b.icon]; return (
            <div key={i} style={{ background: dark ? 'rgba(255,255,255,.06)' : '#fff', border: `1px solid ${dark ? 'rgba(255,255,255,.12)' : '#e2e8f0'}`, borderRadius: 26, padding: '24px 18px', textAlign: 'center' }}>
              <I size={44} strokeWidth={2} color={dark ? c2 : c1} />
              <p style={{ margin: '10px 0 0', fontSize: 24, fontWeight: 700, lineHeight: 1.15 }}>{b.text}</p>
            </div>
          ); })}
        </div>
      )}

      <div style={{ marginTop: 'auto' }}>
        {copy.cta && (
          <div style={{ display: 'flex', justifyContent: 'center', padding: '0 0 30px' }}>
            <span style={{ background: dark ? c2 : '#0b1b3f', color: dark ? '#0b1220' : '#fff', borderRadius: 999, padding: '16px 40px', fontSize: 32, fontWeight: 800 }}>{copy.cta}</span>
          </div>
        )}
        <div style={{ height: 120, background: dark ? '#ffffff' : '#0b1b3f', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Contact brand={brand} color={dark ? '#070d1f' : '#ffffff'} />
        </div>
      </div>
    </div>
  );
}

const field = 'w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-violet-500/40';

const Seg = <T extends string>({ value, options, onChange, label }: { value: T; options: { id: T; label: string }[]; onChange: (v: T) => void; label: string }) => (
  <div role="radiogroup" aria-label={label} className="grid gap-1 rounded-xl bg-slate-100 p-1" style={{ gridTemplateColumns: `repeat(${options.length}, 1fr)` }}>
    {options.map((o) => (
      <button key={o.id} type="button" role="radio" aria-checked={value === o.id} onClick={() => onChange(o.id)} className={`min-h-[36px] rounded-lg text-xs font-bold ${value === o.id ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}>
        {o.label}
      </button>
    ))}
  </div>
);

function Labeled({ label, children }: { label: string; children: ReactNode }) {
  return <label className="block space-y-1 text-xs font-bold text-slate-700">{label}{children}</label>;
}

export function FlyerStudio({ initial, onClose, initialTemplate, initialPhoto }: { initial: FlyerCopy; onClose: () => void; initialTemplate?: Template; initialPhoto?: string | null }) {
  const products = usePosStore((s) => s.products);
  const [copy, setCopy] = useState<FlyerCopy>(initial);
  const [brand, setBrand] = useState<Brand | null>(null);
  const [kind, setKind] = useState<'food' | 'retail' | 'services'>('food');
  const [template, setTemplate] = useState<Template>(initialTemplate || initial.template || 'claro');
  const [format, setFormat] = useState<Format>('post');
  const [photo, setPhoto] = useState<string | null>(initialPhoto ?? null);
  const [busy, setBusy] = useState<'image' | 'export' | null>(null);
  const node = useRef<HTMLDivElement>(null);
  const box = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(0.4);

  // Marca: perfil, logo y foto del producto sugerido
  useEffect(() => {
    agentsAPI.profile().then((p) => {
      setBrand({ name: p.businessName || 'Mi negocio', logo: p.logoUrl, profile: p.profile });
      setKind(kindOf(p.businessType));
    }).catch(() => setBrand(null));
  }, []);
  const productPhoto = useMemo(() => {
    const name = initial.product.toLowerCase();
    if (!name) return null;
    const hit = products.find((p) => p.imageUrl && (p.name.toLowerCase() === name || name.includes(p.name.toLowerCase())));
    return hit?.imageUrl || null;
  }, [products, initial.product]);
  useEffect(() => { if (productPhoto && !initialPhoto) setPhoto(productPhoto); }, [productPhoto, initialPhoto]);

  // La vista previa se ajusta al espacio disponible
  useEffect(() => {
    const el = box.current;
    if (!el) return;
    const fit = () => setScale(Math.min((el.clientWidth - 16) / W, (el.clientHeight - 16) / SIZES[format]));
    fit();
    const ro = new ResizeObserver(fit);
    ro.observe(el);
    return () => ro.disconnect();
  }, [format]);

  const set = <K extends keyof FlyerCopy>(k: K, v: FlyerCopy[K]) => setCopy((c) => ({ ...c, [k]: v }));

  const aiPhoto = async () => {
    if (!copy.imagePrompt.trim()) { toast.warning(t('agents:flyer_falta_descripcion')); return; }
    setBusy('image');
    try {
      const r = await agentsAPI.flyerImage(copy.imagePrompt, kind, format === 'story');
      setPhoto(r.image);
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusy(null);
    }
  };

  const upload = (file: File | undefined) => {
    if (!file) return;
    if (file.size > 8 * 1024 * 1024) { toast.warning(t('agents:flyer_foto_grande')); return; }
    const reader = new FileReader();
    reader.onload = () => setPhoto(String(reader.result));
    reader.readAsDataURL(file);
  };

  const render = async () => {
    if (!node.current) return null;
    await document.fonts?.ready;
    return toPng(node.current, { width: W, height: SIZES[format], pixelRatio: 1, cacheBust: true, style: { transform: 'none' } });
  };
  const fileName = `flyer-${(brand?.name || 'negocio').toLowerCase().replace(/[^a-z0-9]+/g, '-')}-${format}.png`;

  const download = async () => {
    setBusy('export');
    try {
      const url = await render();
      if (!url) return;
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      a.click();
      toast.success(t('agents:flyer_descargado'));
    } catch (e) {
      console.error('[flyer]', e);
      toast.error(t('agents:flyer_no_se_pudo'));
    } finally {
      setBusy(null);
    }
  };

  const share = async () => {
    setBusy('export');
    try {
      const url = await render();
      if (!url) return;
      const blob = await (await fetch(url)).blob();
      const file = new File([blob], fileName, { type: 'image/png' });
      if (navigator.canShare?.({ files: [file] })) await navigator.share({ files: [file], text: `${copy.headline} ${copy.accent}`.trim() });
      else {
        const a = document.createElement('a');
        a.href = url;
        a.download = fileName;
        a.click();
        toast.info(t('agents:flyer_compartir_manual'));
      }
    } catch (e: any) {
      if (e?.name !== 'AbortError') toast.error(t('agents:flyer_no_se_pudo'));
    } finally {
      setBusy(null);
    }
  };

  return createPortal(
    <div className="fixed inset-0 z-[90] flex bg-slate-950/70 p-0 sm:p-4" role="dialog" aria-modal="true" aria-labelledby="flyer-title">
      <div className="flex h-full w-full flex-col overflow-hidden bg-white sm:rounded-3xl lg:flex-row">
        {/* Controles */}
        <aside className="flex max-h-[45vh] flex-col border-b border-slate-200 lg:max-h-none lg:w-[24rem] lg:border-b-0 lg:border-r">
          <div className="flex items-center justify-between gap-2 border-b border-slate-100 px-5 py-3">
            <h2 id="flyer-title" className="flex items-center gap-2 font-black text-slate-900"><Wand2 className="h-5 w-5 text-violet-600" aria-hidden /> {t('agents:flyer_titulo')}</h2>
            <button type="button" onClick={onClose} className="rounded-xl p-2 text-slate-500 hover:bg-slate-100" aria-label={t('expenses:cerrar')}><X className="h-5 w-5" /></button>
          </div>
          <div className="flex-1 space-y-4 overflow-y-auto px-5 py-4">
            <Seg label={t('agents:flyer_estilo')} value={template} onChange={setTemplate} options={[{ id: 'claro', label: t('agents:flyer_claro') }, { id: 'oscuro', label: t('agents:flyer_oscuro') }, { id: 'foto', label: t('agents:flyer_foto') }]} />
            <Seg label={t('agents:flyer_formato')} value={format} onChange={setFormat} options={[{ id: 'post', label: t('agents:flyer_post') }, { id: 'story', label: t('agents:flyer_historia') }, { id: 'square', label: t('agents:flyer_cuadrado') }]} />

            <fieldset className="space-y-2 rounded-2xl border border-slate-200 p-3">
              <legend className="px-1 text-xs font-bold text-slate-700">{t('agents:flyer_foto_titulo')}</legend>
              <textarea rows={2} className={field} value={copy.imagePrompt} onChange={(e) => set('imagePrompt', e.target.value)} aria-label={t('agents:flyer_descripcion_foto')} placeholder={t('agents:flyer_descripcion_foto')} />
              <div className="flex flex-wrap gap-2">
                <button type="button" onClick={aiPhoto} disabled={busy !== null} className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl bg-violet-600 px-3 text-xs font-bold text-white hover:bg-violet-700 disabled:opacity-60">
                  {busy === 'image' ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <Sparkles className="h-4 w-4" aria-hidden />} {t('agents:flyer_foto_ia')}
                </button>
                <label className="inline-flex min-h-[40px] cursor-pointer items-center gap-1.5 rounded-xl border border-slate-300 px-3 text-xs font-bold text-slate-700 hover:bg-slate-50">
                  <Upload className="h-4 w-4" aria-hidden /> {t('agents:flyer_subir')}
                  <input type="file" accept="image/*" className="sr-only" onChange={(e) => upload(e.target.files?.[0])} />
                </label>
                {productPhoto && photo !== productPhoto && (
                  <button type="button" onClick={() => setPhoto(productPhoto)} className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-slate-300 px-3 text-xs font-bold text-slate-700 hover:bg-slate-50">
                    <ImagePlus className="h-4 w-4" aria-hidden /> {t('agents:flyer_foto_producto')}
                  </button>
                )}
              </div>
              <p className="text-[11px] text-slate-500">{t('agents:flyer_foto_nota')}</p>
            </fieldset>

            <Labeled label={t('agents:flyer_etiqueta')}><input className={field} maxLength={36} value={copy.kicker} onChange={(e) => set('kicker', e.target.value)} /></Labeled>
            <div className="grid grid-cols-2 gap-2">
              <Labeled label={t('agents:flyer_titular')}><input className={field} maxLength={40} value={copy.headline} onChange={(e) => set('headline', e.target.value)} /></Labeled>
              <Labeled label={t('agents:flyer_acento')}><input className={field} maxLength={32} value={copy.accent} onChange={(e) => set('accent', e.target.value)} /></Labeled>
            </div>
            <Labeled label={t('agents:flyer_subtitulo')}><textarea rows={2} className={field} maxLength={110} value={copy.subtitle} onChange={(e) => set('subtitle', e.target.value)} /></Labeled>
            <div className="grid grid-cols-2 gap-2">
              <Labeled label={t('agents:flyer_oferta')}><input className={field} maxLength={16} value={copy.offer} onChange={(e) => set('offer', e.target.value)} /></Labeled>
              <Labeled label={t('agents:flyer_nota_oferta')}><input className={field} maxLength={40} value={copy.offerNote} onChange={(e) => set('offerNote', e.target.value)} /></Labeled>
            </div>
            <fieldset className="space-y-2">
              <legend className="text-xs font-bold text-slate-700">{t('agents:flyer_beneficios')}</legend>
              {[0, 1, 2, 3].map((i) => {
                const b = copy.benefits[i] || { icon: 'check' as FlyerIcon, text: '' };
                const update = (patch: Partial<typeof b>) => {
                  const list = [...copy.benefits];
                  list[i] = { ...b, ...patch };
                  set('benefits', list.filter((x) => x && x.text.trim()));
                };
                return (
                  <div key={i} className="flex gap-2">
                    <select aria-label={t('agents:flyer_icono')} className={`${field} w-28`} value={b.icon} onChange={(e) => update({ icon: e.target.value as FlyerIcon })}>
                      {FLYER_ICONS.map((ic) => <option key={ic} value={ic}>{t(`agents:icono_${ic}`)}</option>)}
                    </select>
                    <input className={field} maxLength={34} value={b.text} onChange={(e) => update({ text: e.target.value })} aria-label={t('agents:flyer_beneficio_n', { n: i + 1 })} />
                  </div>
                );
              })}
            </fieldset>
            <Labeled label={t('agents:flyer_cta')}><input className={field} maxLength={28} value={copy.cta} onChange={(e) => set('cta', e.target.value)} /></Labeled>
            {brand && !brand.profile.whatsapp && !brand.profile.instagram && <p className="rounded-xl bg-amber-50 p-3 text-xs text-amber-900">{t('agents:flyer_sin_contacto')}</p>}
          </div>
          <div className="flex gap-2 border-t border-slate-100 p-3">
            <button type="button" onClick={download} disabled={busy !== null || !brand} className="inline-flex flex-1 min-h-[48px] items-center justify-center gap-2 rounded-xl bg-slate-900 text-sm font-bold text-white disabled:opacity-60">
              {busy === 'export' ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <Download className="h-4 w-4" aria-hidden />} {t('agents:flyer_descargar')}
            </button>
            <button type="button" onClick={share} disabled={busy !== null || !brand} className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-xl bg-emerald-600 px-4 text-sm font-bold text-white disabled:opacity-60">
              {typeof navigator.share === 'function' ? <Share2 className="h-4 w-4" aria-hidden /> : <MessageCircle className="h-4 w-4" aria-hidden />} {t('agents:flyer_compartir')}
            </button>
          </div>
        </aside>

        {/* Vista previa a escala */}
        <div ref={box} className="relative flex flex-1 items-center justify-center overflow-hidden bg-slate-200/70">
          {brand ? (
            <div style={{ width: W * scale, height: SIZES[format] * scale }} className="shadow-2xl">
              <div ref={node} style={{ width: W, height: SIZES[format], transform: `scale(${scale})`, transformOrigin: 'top left' }}>
                <FlyerCanvas copy={copy} brand={brand} photo={photo} template={template} format={format} />
              </div>
            </div>
          ) : (
            <Loader2 className="h-8 w-8 animate-spin text-slate-500" aria-label={t('agents:analizando')} />
          )}
        </div>
      </div>
    </div>,
    document.body,
  );
}

// ── Galería: las 3 propuestas ya armadas, con su foto ──

/** Fotos con IA ya hechas en esta sesión (por descripción), para no gastar el cupo dos veces */
const aiPhotos = new Map<string, string | 'failed' | 'pending'>();

/** Foto de cada propuesta: la del producto; si no hay, una con IA (solo en respuestas recién llegadas) */
function useFlyerPhotos(flyers: FlyerCopy[], kind: string, allowAi: boolean) {
  const products = usePosStore((st) => st.products);
  const [, bump] = useState(0);
  const photoOf = (f: FlyerCopy) => {
    const name = f.product.toLowerCase();
    const hit = name ? products.find((p) => p.imageUrl && (p.name.toLowerCase() === name || name.includes(p.name.toLowerCase()))) : undefined;
    if (hit?.imageUrl) return hit.imageUrl;
    const ai = aiPhotos.get(f.imagePrompt);
    return ai && ai !== 'failed' && ai !== 'pending' ? ai : null;
  };
  useEffect(() => {
    if (!allowAi) return;
    let alive = true;
    flyers.filter((f) => !photoOf(f) && f.imagePrompt && !aiPhotos.has(f.imagePrompt)).slice(0, 3).forEach((f) => {
      aiPhotos.set(f.imagePrompt, 'pending');
      agentsAPI.flyerImage(f.imagePrompt, kind, false)
        .then((r) => { aiPhotos.set(f.imagePrompt, r.image); if (alive) bump((n) => n + 1); })
        .catch(() => { aiPhotos.set(f.imagePrompt, 'failed'); });
    });
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [flyers, allowAi, kind]);
  return photoOf;
}

export function FlyerGallery({ flyers, fresh, onOpen }: { flyers: FlyerCopy[]; fresh: boolean; onOpen: (copy: FlyerCopy, template: Template, photo: string | null) => void }) {
  const [brand, setBrand] = useState<Brand | null>(null);
  const [kind, setKind] = useState<'food' | 'retail' | 'services'>('food');
  useEffect(() => {
    agentsAPI.profile().then((p) => { setBrand({ name: p.businessName || 'Mi negocio', logo: p.logoUrl, profile: p.profile }); setKind(kindOf(p.businessType)); }).catch(() => setBrand(null));
  }, []);
  const photoOf = useFlyerPhotos(flyers, kind, fresh);
  if (!brand) return null;
  const scale = 0.2;
  return (
    <div className="mt-3">
      <p className="text-[11px] font-bold uppercase tracking-wide text-violet-700">{t('agents:flyer_propuestas')}</p>
      <ul className="mt-2 flex gap-3 overflow-x-auto pb-1">
        {flyers.map((f, i) => {
          const template = (f.template || (['claro', 'oscuro', 'foto'] as Template[])[i % 3]) as Template;
          const photo = photoOf(f);
          return (
            <li key={i} className="shrink-0">
              <button type="button" onClick={() => onOpen(f, template, photo)} className="group block rounded-2xl border border-slate-200 bg-white p-2 text-left shadow-xs hover:border-violet-400 hover:shadow-md" aria-label={t('agents:flyer_abrir_n', { n: i + 1, title: `${f.headline} ${f.accent}` })}>
                <div style={{ width: W * scale, height: SIZES.post * scale }} className="overflow-hidden rounded-lg">
                  <div style={{ width: W, height: SIZES.post, transform: `scale(${scale})`, transformOrigin: 'top left', pointerEvents: 'none' }}>
                    <FlyerCanvas copy={f} brand={brand} photo={photo} template={template} format="post" />
                  </div>
                </div>
                <span className="mt-1.5 block w-[216px] truncate text-xs font-bold text-slate-800">{t(`agents:flyer_${template}`)} · {f.headline}</span>
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
