// ============================================
// EXPENSES - Revisar una factura antes de guardarla (Lantify 3.0)
// ============================================
// Foto a un lado y formulario al otro; todo se puede corregir. Proveedor nuevo con
// sus datos ya llenos, Gasto o Inventario, y la tabla de conciliación: cada línea
// de la factura → ingrediente o producto, conversión a unidad base y el costo
// nuevo frente al anterior. Al confirmar se guarda todo junto (o nada).

import React, { useEffect, useMemo, useState } from 'react';
import { createPortal } from 'react-dom';
import { AlertTriangle, ArrowDown, ArrowUp, Check, Loader2, Receipt, Store, X } from 'lucide-react';
import { API_URL } from '../../config';
import { responseError, errorMessage } from '../../services/apiErrors';
import { ingredientsAPI, type Ingredient } from '../../services/v3Api';
import { usePosStore } from '../../store/usePosStore';
import { formatCurrency } from '../../shared/formatUtils';
import { toast } from '../../shared/toast';
import { t } from '../../i18n';
import type { PreparedImage } from '../../shared/image';
import type { InvoiceReading, PaymentSource } from '../../services/api';

type Kind = 'ingredient' | 'variant';
interface Target { kind: Kind; id: string; name: string; unit: string; lastCost: number | null }
export interface Prepared {
  docType: 'SUPPLY_PURCHASE' | 'OPERATIONAL_EXPENSE';
  supplier: { status: 'FOUND' | 'NEW'; match: { id: string; name: string; nit: string | null } | null; suggested: { name: string; legalName: string | null; nit: string | null; phone: string | null; address: string | null; category: string | null } };
  lines: { text: string; quantity: number; unit: string | null; total: number | null; target: Target | null; via: string; confidence: number; factor: number | null; lastCost: number | null; suggestNew: { name: string; unit: 'g' | 'ml' | 'und' } | null }[];
}
interface Line { text: string; quantity: string; unit: string; factor: string; total: string; target: Target | null; create: { name: string; unit: 'g' | 'ml' | 'und' } | null; skip: boolean; lastCost: number | null; via: string }

const call = async <T,>(method: string, path: string, body?: unknown): Promise<T> => {
  const token = localStorage.getItem('token');
  const res = await fetch(`${API_URL}${path}`, { method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const data = await res.json().catch(() => null);
  if (!res.ok) throw responseError(res.status, data);
  return data as T;
};

const field = 'w-full rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/40';
const SOURCES: PaymentSource[] = ['CASH_DRAWER', 'BANK', 'CARD', 'NEQUI', 'OTHER'];

function SupplierModal({ suggested, onClose, onCreated }: { suggested: Prepared['supplier']['suggested']; onClose: () => void; onCreated: (s: { id: string; name: string }) => void }) {
  const [f, setF] = useState({ name: suggested.name, legalName: suggested.legalName || '', nit: suggested.nit || '', phone: suggested.phone || '', address: suggested.address || '', category: suggested.category || '' });
  const [busy, setBusy] = useState(false);
  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try { onCreated(await call('POST', '/purchases/suppliers', f)); toast.success(t('expenses:pr_proveedor_creado')); } catch (err) { toast.error(errorMessage(err)); } finally { setBusy(false); }
  };
  return createPortal(
    <div className="fixed inset-0 z-[110] flex items-center justify-center bg-black/50 p-4" role="presentation" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <form onSubmit={save} role="dialog" aria-modal="true" aria-label={t('expenses:pr_crear_proveedor')} className="w-full max-w-md space-y-3 rounded-3xl bg-white p-6 shadow-2xl">
        <h3 className="font-black text-slate-900">{t('expenses:pr_crear_proveedor')}</h3>
        <p className="text-xs text-slate-500">{t('expenses:pr_datos_factura')}</p>
        {(['name', 'legalName', 'nit', 'phone', 'address', 'category'] as const).map((k) => (
          <label key={k} className="block space-y-1 text-xs font-bold text-slate-700">{t(`expenses:pr_sup_${k}`)}
            <input required={k === 'name'} className={field} value={f[k]} onChange={(e) => setF({ ...f, [k]: e.target.value })} />
          </label>
        ))}
        <div className="flex justify-end gap-2 pt-1">
          <button type="button" onClick={onClose} className="min-h-[40px] rounded-xl px-4 text-sm font-bold text-slate-600 hover:bg-slate-100">{t('expenses:cancelar')}</button>
          <button type="submit" disabled={busy} className="min-h-[40px] rounded-xl bg-slate-900 px-4 text-sm font-bold text-white disabled:opacity-60">{t('expenses:pr_guardar_proveedor')}</button>
        </div>
      </form>
    </div>,
    document.body,
  );
}

export function PurchaseReview({ photo, reading, prepared, categories, categoryId, paymentSource, onClose, onSaved }: {
  photo: PreparedImage | null; reading: InvoiceReading; prepared: Prepared; categories: { id: string; name: string }[];
  categoryId: string | null; paymentSource: PaymentSource; onClose: () => void; onSaved: () => void;
}) {
  const products = usePosStore((s) => s.products);
  const [ingredients, setIngredients] = useState<Ingredient[]>([]);
  const [docType, setDocType] = useState(prepared.docType);
  const [supplier, setSupplier] = useState<{ id: string; name: string } | null>(prepared.supplier.match);
  const [supplierModal, setSupplierModal] = useState(false);
  const [head, setHead] = useState({ invoiceNumber: reading.invoiceNumber || '', invoiceDate: reading.invoiceDate || '', subtotal: String(reading.subtotal ?? ''), tax: String(reading.tax ?? ''), total: String(reading.total ?? ''), categoryId: categoryId || '', notes: '' });
  const [pay, setPay] = useState<{ mode: 'PAID' | 'CREDIT'; source: PaymentSource; dueDate: string }>({ mode: 'PAID', source: paymentSource, dueDate: '' });
  const [lines, setLines] = useState<Line[]>(() => prepared.lines.map((l) => ({
    text: l.text, quantity: String(l.quantity ?? 1), unit: l.unit || '', factor: String(l.factor ?? (l.target ? 1 : '')), total: String(l.total ?? ''),
    target: l.target, create: l.target ? null : l.suggestNew, skip: false, lastCost: l.lastCost, via: l.via,
  })));
  const [busy, setBusy] = useState(false);

  useEffect(() => { ingredientsAPI.list().then(setIngredients).catch(() => setIngredients([])); }, []);
  const variants = useMemo(() => products.flatMap((p) => (p.variants || []).map((v: any) => ({ id: v.id, name: v.name && v.name !== 'Única' ? `${p.name} ${v.name}` : p.name, cost: v.cost ?? null }))), [products]);

  const setLine = (k: number, patch: Partial<Line>) => setLines((ls) => ls.map((l, i) => (i === k ? { ...l, ...patch } : l)));
  const pickTarget = (k: number, value: string) => {
    if (value === '__new') { setLine(k, { target: null, create: { name: lines[k].text.slice(0, 80), unit: 'g' } }); return; }
    if (value === '__skip') { setLine(k, { skip: true }); return; }
    const [kind, id] = value.split(':') as [Kind, string];
    if (kind === 'ingredient') { const i = ingredients.find((x) => x.id === id)!; setLine(k, { target: { kind, id, name: i.name, unit: i.unit, lastCost: i.lastCost ?? i.avgCost }, create: null, skip: false, factor: lines[k].factor || '1' }); }
    else { const v = variants.find((x) => x.id === id)!; setLine(k, { target: { kind, id, name: v.name, unit: 'und', lastCost: v.cost }, create: null, skip: false, factor: '1' }); }
  };

  const linesTotal = lines.filter((l) => !l.skip).reduce((n, l) => n + (Number(l.total) || 0), 0);
  const ready = !!supplier && Number(head.total) > 0 && (pay.mode === 'PAID' || !!pay.dueDate) && (docType === 'OPERATIONAL_EXPENSE' || lines.some((l) => !l.skip && (l.target || l.create)));

  const confirm = async () => {
    setBusy(true);
    try {
      const r = await call<{ alerts: { name: string; margin: number | null }[] }>('POST', '/purchases', {
        docType, supplierId: supplier?.id, supplierName: supplier?.name, ...head, total: Number(head.total), subtotal: Number(head.subtotal) || null, tax: Number(head.tax) || null,
        categoryId: head.categoryId || null, payment: pay, image: photo?.base64 || null, fromAi: true, aiConfidence: reading.confidence,
        lines: docType === 'SUPPLY_PURCHASE' ? lines.map((l) => ({ text: l.text, quantity: Number(l.quantity) || 0, unit: l.unit || null, factor: Number(l.factor) || 1, total: Number(l.total) || 0, target: l.target ? { kind: l.target.kind, id: l.target.id } : null, create: l.create, skip: l.skip || (!l.target && !l.create) })) : [],
      });
      toast.success(pay.mode === 'CREDIT' ? t('expenses:pr_guardada_credito') : t('expenses:pr_guardada'));
      if (r.alerts?.length) toast.warning(r.alerts.map((a) => `${a.name}: ${a.margin} %`).join(' · '), t('expenses:pr_margen_bajo'));
      onSaved();
    } catch (e) { toast.error(errorMessage(e)); } finally { setBusy(false); }
  };

  return createPortal(
    <div className="fixed inset-0 z-[100] flex bg-slate-950/70 sm:p-4" role="dialog" aria-modal="true" aria-labelledby="pr-title">
      <div className="flex h-full w-full flex-col overflow-hidden bg-white sm:rounded-3xl lg:flex-row">
        {/* La foto */}
        <div className="flex max-h-[30vh] items-center justify-center overflow-auto bg-slate-900 lg:max-h-none lg:w-[38%]">
          {photo ? <img src={photo.previewUrl} alt={t('expenses:pr_foto')} className="max-h-full w-full object-contain" /> : <Receipt className="h-16 w-16 text-slate-600" aria-hidden />}
        </div>
        {/* El formulario */}
        <div className="flex min-h-0 flex-1 flex-col">
          <div className="flex items-center justify-between gap-3 border-b border-slate-100 px-5 py-3">
            <h2 id="pr-title" className="font-black text-slate-900">{t('expenses:pr_titulo')}</h2>
            <button type="button" onClick={onClose} className="rounded-xl p-2 text-slate-400 hover:bg-slate-100" aria-label={t('expenses:cancelar')}><X className="h-5 w-5" /></button>
          </div>
          <div className="min-h-0 flex-1 space-y-4 overflow-y-auto px-5 py-4">
            {/* Proveedor */}
            {!supplier ? (
              <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-amber-300 bg-amber-50 p-3">
                <p className="flex items-center gap-2 text-sm font-bold text-amber-950"><AlertTriangle className="h-4 w-4" aria-hidden />{t('expenses:pr_proveedor_nuevo', { name: prepared.supplier.suggested.name || '—' })}</p>
                <button type="button" onClick={() => setSupplierModal(true)} className="min-h-[40px] rounded-xl bg-amber-600 px-3 text-sm font-bold text-white">{t('expenses:pr_revisar_crear')}</button>
              </div>
            ) : (
              <p className="flex items-center gap-2 rounded-2xl bg-emerald-50 px-3 py-2 text-sm text-emerald-900"><Store className="h-4 w-4" aria-hidden /><span className="font-bold">{supplier.name}</span>{prepared.supplier.status === 'FOUND' && <span className="text-xs">· {t('expenses:pr_proveedor_encontrado')}</span>}</p>
            )}

            {/* Gasto o Inventario */}
            <div className="inline-flex gap-1 rounded-xl bg-slate-100 p-1" role="radiogroup" aria-label={t('expenses:pr_tipo')}>
              {(['SUPPLY_PURCHASE', 'OPERATIONAL_EXPENSE'] as const).map((d) => (
                <button key={d} type="button" role="radio" aria-checked={docType === d} onClick={() => setDocType(d)} className={`min-h-[36px] rounded-lg px-3 text-xs font-bold ${docType === d ? 'bg-white shadow-sm' : 'text-slate-600'}`}>{t(`expenses:pr_${d}`)}</button>
              ))}
            </div>

            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              <label className="space-y-1 text-xs font-bold text-slate-700">{t('expenses:pr_numero')}<input className={field} value={head.invoiceNumber} onChange={(e) => setHead({ ...head, invoiceNumber: e.target.value })} /></label>
              <label className="space-y-1 text-xs font-bold text-slate-700">{t('expenses:pr_fecha')}<input type="date" className={field} value={head.invoiceDate} onChange={(e) => setHead({ ...head, invoiceDate: e.target.value })} /></label>
              <label className="space-y-1 text-xs font-bold text-slate-700">{t('expenses:pr_iva')}<input type="number" step={1} className={field} value={head.tax} onChange={(e) => setHead({ ...head, tax: e.target.value })} /></label>
              <label className="space-y-1 text-xs font-bold text-slate-700">{t('expenses:pr_total')}<input required type="number" step={1} className={`${field} font-bold`} value={head.total} onChange={(e) => setHead({ ...head, total: e.target.value })} /></label>
            </div>

            {/* Tabla de conciliación */}
            {docType === 'SUPPLY_PURCHASE' && (
              <section aria-labelledby="pr-lines" className="space-y-2">
                <h3 id="pr-lines" className="text-sm font-bold text-slate-900">{t('expenses:pr_lineas')}</h3>
                <ul className="space-y-2">
                  {lines.map((l, k) => {
                    const factor = Number(l.factor) || 0;
                    const base = (Number(l.quantity) || 0) * factor;
                    const unit = l.target?.unit || l.create?.unit || '';
                    const perBase = base > 0 && Number(l.total) > 0 ? Number(l.total) / base : null;
                    const change = perBase !== null && l.lastCost ? ((perBase - l.lastCost) / l.lastCost) * 100 : null;
                    return (
                      <li key={k} className={`rounded-2xl border p-3 ${l.skip ? 'border-dashed border-slate-200 opacity-60' : 'border-slate-200'}`}>
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="min-w-0 flex-1 text-sm font-semibold text-slate-900">"{l.text}"</span>
                          {l.via === 'alias' && <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[11px] font-bold text-emerald-800">{t('expenses:pr_aprendido')}</span>}
                          {l.skip && <button type="button" onClick={() => setLine(k, { skip: false })} className="text-xs font-bold text-blue-700">{t('expenses:pr_incluir')}</button>}
                        </div>
                        {!l.skip && (
                          <div className="mt-2 grid gap-2 sm:grid-cols-[1.4fr_1fr_1fr]">
                            <label className="space-y-1 text-xs font-bold text-slate-700">{t('expenses:pr_vinculado')}
                              <select className={field} value={l.target ? `${l.target.kind}:${l.target.id}` : '__new'} onChange={(e) => pickTarget(k, e.target.value)}>
                                <option value="__new">{t('expenses:pr_crear_ingrediente')}</option>
                                <optgroup label={t('expenses:pr_ingredientes')}>{ingredients.map((i) => <option key={i.id} value={`ingredient:${i.id}`}>{i.name} [{i.unit}]</option>)}</optgroup>
                                <optgroup label={t('expenses:pr_productos')}>{variants.map((v) => <option key={v.id} value={`variant:${v.id}`}>{v.name} [und]</option>)}</optgroup>
                                <option value="__skip">{t('expenses:pr_omitir')}</option>
                              </select>
                            </label>
                            <div className="grid grid-cols-[1fr_4.5rem] gap-1">
                              <label className="space-y-1 text-xs font-bold text-slate-700">{t('expenses:pr_cantidad')}<input type="number" step="any" className={field} value={l.quantity} onChange={(e) => setLine(k, { quantity: e.target.value })} /></label>
                              <label className="space-y-1 text-xs font-bold text-slate-700">{t('expenses:pr_unidad')}<input className={field} value={l.unit} onChange={(e) => setLine(k, { unit: e.target.value })} placeholder="kg" /></label>
                            </div>
                            <label className="space-y-1 text-xs font-bold text-slate-700">{t('expenses:pr_total_linea')}<input type="number" step={1} className={field} value={l.total} onChange={(e) => setLine(k, { total: e.target.value })} /></label>
                          </div>
                        )}
                        {!l.skip && l.create && (
                          <div className="mt-2 grid grid-cols-[1fr_8rem] gap-2">
                            <label className="space-y-1 text-xs font-bold text-slate-700">{t('expenses:pr_nombre_nuevo')}<input className={field} value={l.create.name} onChange={(e) => setLine(k, { create: { ...l.create!, name: e.target.value } })} /></label>
                            <label className="space-y-1 text-xs font-bold text-slate-700">{t('expenses:pr_unidad_base')}
                              <select className={field} value={l.create.unit} onChange={(e) => setLine(k, { create: { ...l.create!, unit: e.target.value as any } })}><option value="g">g</option><option value="ml">ml</option><option value="und">und</option></select>
                            </label>
                          </div>
                        )}
                        {!l.skip && (
                          <p className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-600">
                            <label className="inline-flex items-center gap-1">{t('expenses:pr_conversion', { unit: l.unit || '—' })}
                              <span className="font-bold">×</span><input type="number" step="any" min={0} value={l.factor} onChange={(e) => setLine(k, { factor: e.target.value })} className="w-20 rounded-md border border-slate-300 px-1.5 py-0.5 tabular-nums" aria-label={t('expenses:pr_factor')} />
                              = <span className="font-bold text-slate-900 tabular-nums">{base ? base.toLocaleString() : '—'} {unit}</span>
                            </label>
                            {perBase !== null && <span className="font-semibold text-slate-800">{t('expenses:pr_costo_unitario', { cost: unit === 'und' ? formatCurrency(Math.round(perBase)) : `$${perBase.toFixed(2)}`, unit: unit || 'und' })}</span>}
                            {change !== null && Math.abs(change) >= 0.5 && (
                              <span className={`inline-flex items-center gap-0.5 font-bold ${change > 0 ? 'text-rose-700' : 'text-emerald-700'}`}>{change > 0 ? <ArrowUp className="h-3 w-3" aria-hidden /> : <ArrowDown className="h-3 w-3" aria-hidden />}{change > 0 ? '+' : ''}{change.toFixed(0)} %</span>
                            )}
                            {!factor && <span className="font-bold text-amber-700">{t('expenses:pr_falta_factor')}</span>}
                          </p>
                        )}
                      </li>
                    );
                  })}
                </ul>
                {Math.abs(linesTotal - Number(head.total || 0)) > 1 && Number(head.total) > 0 && <p className="text-xs text-slate-500">{t('expenses:pr_suma_lineas', { sum: formatCurrency(linesTotal), total: formatCurrency(Number(head.total)) })}</p>}
              </section>
            )}

            {/* Pago */}
            <div className="grid gap-2 sm:grid-cols-3">
              <label className="space-y-1 text-xs font-bold text-slate-700">{t('expenses:pr_categoria')}
                <select className={field} value={head.categoryId} onChange={(e) => setHead({ ...head, categoryId: e.target.value })}><option value="">—</option>{categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
              </label>
              <label className="space-y-1 text-xs font-bold text-slate-700">{t('expenses:pr_pago')}
                <select className={field} value={pay.mode} onChange={(e) => setPay({ ...pay, mode: e.target.value as any })}><option value="PAID">{t('expenses:pr_pagada')}</option><option value="CREDIT">{t('expenses:pr_credito')}</option></select>
              </label>
              {pay.mode === 'PAID' ? (
                <label className="space-y-1 text-xs font-bold text-slate-700">{t('expenses:pr_de_donde')}
                  <select className={field} value={pay.source} onChange={(e) => setPay({ ...pay, source: e.target.value as PaymentSource })}>{SOURCES.map((s) => <option key={s} value={s}>{t(`expenses:fuente_${s}`)}</option>)}</select>
                </label>
              ) : (
                <label className="space-y-1 text-xs font-bold text-slate-700">{t('expenses:pr_vence')}<input required type="date" className={field} value={pay.dueDate} onChange={(e) => setPay({ ...pay, dueDate: e.target.value })} /></label>
              )}
            </div>
            <label className="block space-y-1 text-xs font-bold text-slate-700">{t('expenses:pr_notas')}<input className={field} value={head.notes} maxLength={300} onChange={(e) => setHead({ ...head, notes: e.target.value })} /></label>
          </div>
          <div className="flex items-center justify-between gap-3 border-t border-slate-100 px-5 py-3">
            <p className="text-xs text-slate-500">{!supplier ? t('expenses:pr_falta_proveedor') : t('expenses:pr_todo_junto')}</p>
            <button type="button" onClick={confirm} disabled={!ready || busy} className="inline-flex min-h-[48px] items-center gap-2 rounded-xl bg-emerald-600 px-5 text-sm font-black text-white disabled:opacity-50">
              {busy ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <Check className="h-4 w-4" aria-hidden />}{t('expenses:pr_confirmar')}
            </button>
          </div>
        </div>
      </div>
      {supplierModal && <SupplierModal suggested={prepared.supplier.suggested} onClose={() => setSupplierModal(false)} onCreated={(s) => { setSupplier(s); setSupplierModal(false); }} />}
    </div>,
    document.body,
  );
}
