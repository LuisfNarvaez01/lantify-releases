// ============================================
// EXPENSES - Cuentas por pagar (compras a crédito) · Lantify 3.0
// ============================================

import React, { useEffect, useState } from 'react';
import { CalendarClock, Check } from 'lucide-react';
import { API_URL } from '../../config';
import { responseError, errorMessage } from '../../services/apiErrors';
import { formatCurrency } from '../../shared/formatUtils';
import { toast } from '../../shared/toast';
import { t, getLocale } from '../../i18n';

interface Payable { id: string; supplierName: string; invoiceNumber: string | null; amount: number; dueDate: string | null; status: 'PENDING' | 'PAID'; overdue: boolean; daysLeft: number | null }

const call = async <T,>(method: string, path: string, body?: unknown): Promise<T> => {
  const token = localStorage.getItem('token');
  const res = await fetch(`${API_URL}${path}`, { method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const data = await res.json().catch(() => null);
  if (!res.ok) throw responseError(res.status, data);
  return data as T;
};

export const PayablesPanel: React.FC = () => {
  const [rows, setRows] = useState<Payable[] | null>(null);
  const load = () => call<Payable[]>('GET', '/payables').then(setRows).catch(() => setRows([]));
  useEffect(() => { load(); }, []);
  if (!rows || rows.length === 0) return null;
  const total = rows.reduce((n, r) => n + r.amount, 0);
  const pay = async (r: Payable, source: string) => {
    try { await call('POST', `/payables/${r.id}/pay`, { source }); toast.success(t('expenses:ap_pagada')); load(); } catch (e) { toast.error(errorMessage(e)); }
  };
  return (
    <section className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm" aria-labelledby="ap-title">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h3 id="ap-title" className="flex items-center gap-2 text-base font-bold text-slate-900"><CalendarClock className="h-5 w-5 text-blue-700" aria-hidden />{t('expenses:ap_titulo')}</h3>
        <span className="text-sm font-black tabular-nums text-slate-900">{formatCurrency(total)}</span>
      </div>
      <ul className="mt-3 divide-y divide-slate-100">
        {rows.map((r) => (
          <li key={r.id} className="flex flex-wrap items-center gap-3 py-2.5">
            <span className="min-w-0 flex-1">
              <span className="block font-semibold text-slate-900">{r.supplierName}{r.invoiceNumber ? ` · ${r.invoiceNumber}` : ''}</span>
              <span className={`block text-xs font-semibold ${r.overdue ? 'text-rose-700' : r.daysLeft !== null && r.daysLeft <= 3 ? 'text-amber-700' : 'text-slate-500'}`}>
                {r.dueDate ? (r.overdue ? t('expenses:ap_vencida', { date: new Date(r.dueDate).toLocaleDateString(getLocale()) }) : t('expenses:ap_vence', { count: r.daysLeft ?? 0, date: new Date(r.dueDate).toLocaleDateString(getLocale()) })) : t('expenses:ap_sin_fecha')}
              </span>
            </span>
            <span className="font-bold tabular-nums">{formatCurrency(r.amount)}</span>
            <select aria-label={t('expenses:ap_pagar_desde')} defaultValue="" onChange={(e) => { if (e.target.value) pay(r, e.target.value); e.target.value = ''; }} className="min-h-[36px] rounded-lg border border-slate-300 px-2 text-xs font-bold">
              <option value="" disabled>{t('expenses:ap_registrar_pago')}</option>
              {['BANK', 'CASH_DRAWER', 'CARD', 'NEQUI', 'OTHER'].map((s) => <option key={s} value={s}>{t(`expenses:fuente_${s}`)}</option>)}
            </select>
          </li>
        ))}
      </ul>
      <p className="mt-2 flex items-center gap-1 text-xs text-slate-500"><Check className="h-3.5 w-3.5" aria-hidden />{t('expenses:ap_nota')}</p>
    </section>
  );
};
