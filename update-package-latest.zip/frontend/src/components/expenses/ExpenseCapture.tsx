import { PurchaseReview, type Prepared } from './PurchaseReview';
// ============================================
// GASTOS - Registro con foto de la factura (se usa desde la caja)
// ============================================
// Los gastos se registran arqueo a arqueo: siempre quedan en el turno abierto.
// Tomas la foto, la IA lee proveedor, valores y categoría y tú revisas antes de
// guardar; con el modo automático, una lectura confiable queda registrada sola.

import { useCallback, useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { ScanLine, Sparkles, X } from 'lucide-react';
import {
  expensesAPI, expenseCategoriesAPI, aiSettingsAPI, InvoiceReading, PaymentSource, AiSettings,
} from '../../services/api';
import { ApiError, errorMessage } from '../../services/apiErrors';
import { prepareInvoicePhoto, PreparedImage } from '../../shared/image';
import { formatCurrency } from '../../shared/formatUtils';
import { toast } from '../../shared/toast';
import { useFeature, showPlanLock } from '../../shared/plan';
import { t, getLanguage } from '../../i18n';

export const SOURCES: PaymentSource[] = ['CASH_DRAWER', 'BANK', 'CARD', 'NEQUI', 'OTHER'];

export interface Category {
  id: string;
  name: string;
  color?: string | null;
  isActive?: boolean;
}

// ── Formulario (manual o revisión de la lectura) ────────────

export interface Draft {
  amount: string;
  supplierName: string;
  supplierNit: string;
  invoiceNumber: string;
  invoiceDate: string;
  subtotal: string;
  taxAmount: string;
  categoryId: string;
  paymentSource: PaymentSource;
  motive: string;
  description: string;
}

export const emptyDraft = (): Draft => ({
  amount: '', supplierName: '', supplierNit: '', invoiceNumber: '', invoiceDate: '',
  subtotal: '', taxAmount: '', categoryId: '', paymentSource: 'CASH_DRAWER', motive: '', description: '',
});

export const draftFromReading = (r: InvoiceReading, categoryId: string | null, source: PaymentSource): Draft => ({
  amount: r.total ? String(r.total) : '',
  supplierName: r.supplierName || '',
  supplierNit: r.supplierNit || '',
  invoiceNumber: r.invoiceNumber || '',
  invoiceDate: r.invoiceDate || '',
  subtotal: r.subtotal ? String(r.subtotal) : '',
  taxAmount: r.tax ? String(r.tax) : '',
  categoryId: categoryId || '',
  paymentSource: source,
  motive: '',
  description: r.items.length ? r.items.map((i) => `${i.quantity ? `${i.quantity} × ` : ''}${i.description}`).join(', ').slice(0, 480) : '',
});

const inputCls = 'w-full min-h-[44px] px-3 rounded-xl border border-slate-200 bg-white text-sm text-slate-900 focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20';

export function ExpenseForm({ categories, initial, photo, reading, onClose, onSaved }: {
  categories: Category[];
  initial: Draft;
  photo: PreparedImage | null;
  reading: InvoiceReading | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [d, setD] = useState<Draft>(initial);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const fromAi = !!reading;
  const set = (k: keyof Draft) => (e: { target: { value: string } }) => setD((x) => ({ ...x, [k]: e.target.value }));
  // Lo que la IA llenó se marca, para que se revise antes de guardar
  const aiFilled = (k: keyof Draft) => fromAi && !!initial[k] && d[k] === initial[k];

  const save = async () => {
    setError('');
    setSaving(true);
    try {
      await expensesAPI.create({
        amount: Number(d.amount),
        motive: d.motive || d.supplierName,
        description: d.description || null,
        supplierName: d.supplierName || null,
        supplierNit: d.supplierNit || null,
        invoiceNumber: d.invoiceNumber || null,
        invoiceDate: d.invoiceDate || null,
        subtotal: d.subtotal ? Number(d.subtotal) : null,
        taxAmount: d.taxAmount ? Number(d.taxAmount) : null,
        categoryId: d.categoryId || null,
        paymentSource: d.paymentSource,
        image: photo?.base64 || null,
        captureMode: fromAi ? 'AI_REVIEWED' : 'MANUAL',
        aiConfidence: reading?.confidence ?? null,
        items: reading?.items ?? undefined,
      });
      toast.success(t('expenses:registrado', { amount: formatCurrency(Number(d.amount)) }));
      onSaved();
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setSaving(false);
    }
  };

  const field = (k: keyof Draft, label: string, props: Record<string, unknown> = {}) => (
    <label className="block">
      <span className="flex items-center gap-1.5 text-xs font-bold text-slate-600">
        {label}
        {aiFilled(k) && <Sparkles className="w-3 h-3 text-violet-500" aria-label={t('expenses:leido_por_ia')} />}
      </span>
      <input value={d[k]} onChange={set(k)} className={`${inputCls} mt-1 ${aiFilled(k) ? 'bg-violet-50/60 border-violet-200' : ''}`} {...props} />
    </label>
  );

  return createPortal(
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/50 p-4" role="dialog" aria-modal="true" aria-labelledby="expense-form-title">
      <div className={`w-full ${photo ? 'max-w-4xl' : 'max-w-xl'} max-h-[92vh] overflow-y-auto rounded-3xl bg-white shadow-2xl`}>
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-slate-100 bg-white px-6 py-4">
          <div>
            <h3 id="expense-form-title" className="text-lg font-black text-slate-900">{fromAi ? t('expenses:revisa_la_lectura') : t('expenses:nuevo_gasto')}</h3>
            {reading && (
              <p className="text-xs text-slate-500">
                {t('expenses:confianza', { pct: Math.round(reading.confidence * 100) })}
                {reading.confidence < 0.7 && <span className="ml-1 font-semibold text-amber-700">· {t('expenses:revisa_con_cuidado')}</span>}
              </p>
            )}
          </div>
          <button type="button" onClick={onClose} className="p-2 rounded-xl text-slate-400 hover:bg-slate-100 hover:text-slate-700" aria-label={t('expenses:cerrar')}>
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className={`grid gap-6 p-6 ${photo ? 'md:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)]' : ''}`}>
          {photo && (
            <div className="space-y-2">
              <img src={photo.previewUrl} alt={t('expenses:foto_factura')} className="w-full max-h-[60vh] object-contain rounded-2xl border border-slate-200 bg-slate-50" />
              {reading && reading.items.length > 0 && (
                <details className="rounded-xl border border-slate-200 p-3 text-xs text-slate-600">
                  <summary className="cursor-pointer font-bold text-slate-700">{t('expenses:productos_leidos', { count: reading.items.length })}</summary>
                  <ul className="mt-2 space-y-1">
                    {reading.items.map((i, n) => (
                      <li key={n} className="flex justify-between gap-3"><span>{i.quantity ? `${i.quantity} × ` : ''}{i.description}</span><span className="tabular-nums">{i.total ? formatCurrency(i.total) : ''}</span></li>
                    ))}
                  </ul>
                </details>
              )}
            </div>
          )}

          <div className="space-y-4">
            <label className="block">
              <span className="flex items-center gap-1.5 text-xs font-bold text-slate-600">
                {t('expenses:total_pagado')} *
                {aiFilled('amount') && <Sparkles className="w-3 h-3 text-violet-500" aria-hidden />}
              </span>
              <input
                value={d.amount}
                onChange={set('amount')}
                inputMode="numeric"
                type="number"
                min={1}
                className={`${inputCls} mt-1 text-xl font-black tabular-nums ${aiFilled('amount') ? 'bg-violet-50/60 border-violet-200' : ''}`}
                autoFocus={!fromAi}
              />
            </label>
            <div className="grid grid-cols-2 gap-3">
              {field('supplierName', t('expenses:proveedor'), { maxLength: 120 })}
              {field('supplierNit', 'NIT', { maxLength: 20 })}
              {field('invoiceNumber', t('expenses:numero_factura'), { maxLength: 40 })}
              {field('invoiceDate', t('expenses:fecha_factura'), { type: 'date' })}
              {field('subtotal', t('expenses:subtotal'), { type: 'number', inputMode: 'numeric' })}
              {field('taxAmount', t('expenses:iva'), { type: 'number', inputMode: 'numeric' })}
            </div>
            <div className="grid grid-cols-2 gap-3">
              <label className="block">
                <span className="flex items-center gap-1.5 text-xs font-bold text-slate-600">
                  {t('expenses:categoria')}
                  {aiFilled('categoryId') && <Sparkles className="w-3 h-3 text-violet-500" aria-hidden />}
                </span>
                <select value={d.categoryId} onChange={set('categoryId')} className={`${inputCls} mt-1 ${aiFilled('categoryId') ? 'bg-violet-50/60 border-violet-200' : ''}`}>
                  <option value="">{t('expenses:sin_categoria')}</option>
                  {categories.filter((c) => c.isActive !== false).map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </label>
              <label className="block">
                <span className="text-xs font-bold text-slate-600">{t('expenses:como_se_pago')}</span>
                <select value={d.paymentSource} onChange={set('paymentSource')} className={`${inputCls} mt-1`}>
                  {SOURCES.map((s) => <option key={s} value={s}>{t(`expenses:fuente_${s}`)}</option>)}
                </select>
              </label>
            </div>
            <p className="text-xs text-slate-500">{d.paymentSource === 'CASH_DRAWER' ? t('expenses:cajon_desc') : t('expenses:fuera_desc')}</p>
            {field('motive', t('expenses:motivo'), { maxLength: 160, placeholder: d.supplierName || t('expenses:motivo_ej') })}
            <label className="block">
              <span className="text-xs font-bold text-slate-600">{t('expenses:notas')}</span>
              <textarea value={d.description} onChange={set('description')} maxLength={500} rows={2} className={`${inputCls} mt-1 py-2`} />
            </label>

            {error && <p role="alert" className="rounded-xl bg-rose-50 px-3 py-2 text-sm font-medium text-rose-700">{error}</p>}

            <div className="flex gap-3 pt-2">
              <button type="button" onClick={onClose} className="flex-1 min-h-[46px] rounded-xl border border-slate-200 font-bold text-slate-700 hover:bg-slate-50">
                {t('expenses:cancelar')}
              </button>
              <button
                type="button"
                onClick={save}
                disabled={saving || !Number(d.amount)}
                className="flex-[2] min-h-[46px] rounded-xl bg-blue-600 font-bold text-white shadow-sm hover:bg-blue-700 disabled:opacity-50"
              >
                {saving ? t('expenses:guardando') : t('expenses:registrar_gasto')}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>,
    document.body,
  );
}

// ── Leyendo la factura (la foto con una línea que la recorre) ──

export function ScanningOverlay({ photo }: { photo: PreparedImage }) {
  return createPortal(
    <div className="fixed inset-0 z-[85] flex items-center justify-center bg-slate-950/80 p-6" role="status" aria-live="polite">
      <div className="w-full max-w-sm text-center">
        <div className="relative mx-auto overflow-hidden rounded-2xl border border-white/20 shadow-2xl">
          <img src={photo.previewUrl} alt="" className="max-h-[60vh] w-full object-contain bg-white" />
          <div className="pointer-events-none absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-transparent via-violet-400/35 to-transparent motion-safe:animate-[scanline_1.8s_ease-in-out_infinite]" />
        </div>
        <p className="mt-5 flex items-center justify-center gap-2 font-bold text-white">
          <ScanLine className="w-5 h-5 text-violet-300" aria-hidden /> {t('expenses:leyendo_factura')}
        </p>
        <p className="mt-1 text-sm text-white/70">{t('expenses:leyendo_desc')}</p>
      </div>
    </div>,
    document.body,
  );
}

// ── Consentimiento (solo la primera vez) ────────────────────

export function ConsentPrompt({ onAccept, onClose }: { onAccept: () => void; onClose: () => void }) {
  const [busy, setBusy] = useState(false);
  return createPortal(
    <div className="fixed inset-0 z-[85] flex items-center justify-center bg-black/50 p-4" role="dialog" aria-modal="true" aria-labelledby="ai-consent-title">
      <div className="w-full max-w-lg rounded-3xl bg-white p-6 shadow-2xl">
        <div className="mb-4 grid h-12 w-12 place-items-center rounded-2xl bg-violet-50 text-violet-600">
          <Sparkles className="w-6 h-6" aria-hidden />
        </div>
        <h3 id="ai-consent-title" className="text-lg font-black text-slate-900">{t('expenses:consent_titulo')}</h3>
        <p className="mt-2 text-sm text-slate-600 leading-relaxed">{t('ai:consent_que_se_envia')}</p>
        <p className="mt-2 text-sm text-slate-600 leading-relaxed">{t('ai:consent_proveedor')}</p>
        <div className="mt-6 space-y-2">
          <button
            type="button"
            disabled={busy}
            onClick={async () => {
              setBusy(true);
              await onAccept();
              setBusy(false);
            }}
            className="w-full min-h-[48px] rounded-xl bg-violet-600 font-bold text-white hover:bg-violet-700 disabled:opacity-50"
          >
            {t('ai:autorizar')}
          </button>
          <button type="button" onClick={onClose} className="w-full min-h-[44px] rounded-xl font-semibold text-slate-600 hover:bg-slate-50">
            {t('expenses:ahora_no')}
          </button>
        </div>
      </div>
    </div>,
    document.body,
  );
}


// ── Captura: botones de foto/manual + las ventanas que abren ──

/**
 * Todo lo necesario para registrar un gasto desde cualquier pantalla: abre la
 * cámara o el formulario, lee la factura con la IA y pide el permiso de IA la
 * primera vez (solo el ADMIN puede darlo; los demás registran a mano).
 */
export function useExpenseCapture({ onSaved, canConsent }: { onSaved: () => void; canConsent: boolean }) {
  const [categories, setCategories] = useState<Category[]>([]);
  const [ai, setAi] = useState<AiSettings | null>(null);
  const [form, setForm] = useState<{ initial: Draft; photo: PreparedImage | null; reading: InvoiceReading | null } | null>(null);
  // Factura leída y emparejada con el inventario: se revisa en la pantalla dividida
  const [purchase, setPurchase] = useState<{ photo: PreparedImage; reading: InvoiceReading; prepared: Prepared; categoryId: string | null; paymentSource: PaymentSource } | null>(null);
  const [scanning, setScanning] = useState<PreparedImage | null>(null);
  const [pendingPhoto, setPendingPhoto] = useState<PreparedImage | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const hasOcr = useFeature('expense_ocr');

  useEffect(() => {
    expenseCategoriesAPI.getAll().then(setCategories).catch(() => setCategories([]));
    aiSettingsAPI.get().then(setAi).catch(() => setAi(null));
  }, []);

  const scan = useCallback(async (photo: PreparedImage) => {
    setScanning(photo);
    try {
      const result = await expensesAPI.scan(photo.base64, photo.mimeType, getLanguage());
      if (result.mode === 'auto') {
        toast.success(t('expenses:auto_registrado', { amount: formatCurrency(result.expense.amount), supplier: result.expense.supplierName || '' }), t('expenses:auto_titulo'));
        onSaved();
      } else if (result.prepared) {
        setPurchase({ photo, reading: result.reading, prepared: result.prepared, categoryId: result.categoryId, paymentSource: result.paymentSource });
      } else {
        setForm({ initial: draftFromReading(result.reading, result.categoryId, result.paymentSource), photo, reading: result.reading });
      }
    } catch (e) {
      const code = e instanceof ApiError ? e.code : '';
      if (code === 'AI_CONSENT_REQUIRED' && canConsent) {
        setPendingPhoto(photo);
      } else if (code === 'PLAN_FEATURE_REQUIRED' || code === 'AI_PLAN_REQUIRED') {
        showPlanLock('expense_ocr');
      } else {
        // Sin lectura no se pierde la foto: se registra a mano con ella adjunta
        toast.warning(code === 'AI_NOT_AN_INVOICE' ? t('expenses:no_es_factura') : errorMessage(e), t('expenses:llena_a_mano'));
        setForm({ initial: emptyDraft(), photo, reading: null });
      }
    } finally {
      setScanning(null);
    }
  }, [onSaved, canConsent]);

  const onFile = async (file: File | undefined) => {
    if (!file) return;
    try {
      await scan(await prepareInvoicePhoto(file));
    } catch {
      toast.error(t('expenses:foto_invalida'));
    }
  };

  const openCamera = () => {
    if (!hasOcr) return showPlanLock('expense_ocr');
    fileRef.current?.click();
  };
  const openManual = () => setForm({ initial: emptyDraft(), photo: null, reading: null });

  const elements = (
    <>
      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        capture="environment"
        className="sr-only"
        tabIndex={-1}
        aria-hidden
        onChange={(e) => {
          onFile(e.target.files?.[0]);
          e.target.value = '';
        }}
      />
      {scanning && <ScanningOverlay photo={scanning} />}
      {purchase && (
        <PurchaseReview
          {...purchase}
          categories={categories}
          onClose={() => setPurchase(null)}
          onSaved={() => { setPurchase(null); onSaved(); }}
        />
      )}
      {form && (
        <ExpenseForm
          categories={categories}
          initial={form.initial}
          photo={form.photo}
          reading={form.reading}
          onClose={() => setForm(null)}
          onSaved={() => {
            setForm(null);
            onSaved();
          }}
        />
      )}
      {pendingPhoto && (
        <ConsentPrompt
          onClose={() => {
            // Sin permiso, la foto igual sirve: se registra a mano
            setForm({ initial: emptyDraft(), photo: pendingPhoto, reading: null });
            setPendingPhoto(null);
          }}
          onAccept={async () => {
            try {
              setAi(await aiSettingsAPI.update({ consent: true }));
              const photo = pendingPhoto;
              setPendingPhoto(null);
              await scan(photo);
            } catch (e) {
              toast.error(errorMessage(e));
            }
          }}
        />
      )}
    </>
  );

  return { openCamera, openManual, elements, hasOcr, ai };
}
