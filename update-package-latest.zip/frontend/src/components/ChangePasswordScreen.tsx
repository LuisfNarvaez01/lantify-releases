import { useState } from 'react';
import { authAPI } from '../services/api';
import { AlertCircle, KeyRound } from 'lucide-react';

import { t } from '../i18n';
interface ChangePasswordScreenProps {
  user: any;
  onChanged: (user: any) => void;
  onLogout: () => void;
}

const inputClass =
  'w-full px-4 py-3 border border-slate-300 rounded-xl bg-slate-50/50 focus:bg-white focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 text-slate-900 text-sm font-medium transition-all';
const labelClass = 'block text-xs font-bold text-slate-700 mb-1.5';

/** Se muestra cuando la cuenta usa una clave de fábrica o un admin la restableció. */
export function ChangePasswordScreen({ user, onChanged, onLogout }: ChangePasswordScreenProps) {
  const [current, setCurrent] = useState('');
  const [next, setNext] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (next.length < 8) return setError(t('auth:la_nueva_contrasena_debe_tener_al_menos'));
    if (next !== confirm) return setError(t('auth:las_contrasenas_no_coinciden'));

    setLoading(true);
    try {
      const result = await authAPI.changePassword(current, next);
      localStorage.setItem('token', result.token);
      localStorage.setItem('user', JSON.stringify(result.user));
      onChanged(result.user);
    } catch (err: any) {
      setError(err.message || t('auth:no_se_pudo_cambiar_la_contrasena'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-slate-950 font-sans">
      <form onSubmit={handleSubmit} className="w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden">
        <div className="px-8 pt-8 pb-5 bg-slate-900 text-center">
          <KeyRound className="w-10 h-10 text-amber-400 mx-auto mb-2" />
          <h1 className="text-lg font-bold text-white">{t('auth:cambia_tu_contrasena')}</h1>
          <p className="text-xs text-slate-400 mt-1">
            {t('auth:hola_value_por_seguridad_debes_elegir_una', { value: user?.name || user?.username })}
          </p>
        </div>

        <div className="px-8 py-6 space-y-4">
          {error && (
            <div role="alert" className="bg-rose-50 border border-rose-200 text-rose-700 px-4 py-3 rounded-xl text-xs font-semibold flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label htmlFor="cp-current" className={labelClass}>{t('auth:contrasena_actual')}</label>
            <input id="cp-current" type="password" value={current} onChange={(e) => setCurrent(e.target.value)} className={inputClass} autoComplete="current-password" autoFocus required />
          </div>
          <div>
            <label htmlFor="cp-new" className={labelClass}>{t('auth:nueva_contrasena')}</label>
            <input id="cp-new" type="password" value={next} onChange={(e) => setNext(e.target.value)} className={inputClass} placeholder={t('auth:minimo_8_caracteres')} autoComplete="new-password" required />
          </div>
          <div>
            <label htmlFor="cp-confirm" className={labelClass}>{t('auth:confirmar_nueva_contrasena')}</label>
            <input id="cp-confirm" type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} className={inputClass} autoComplete="new-password" required />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 rounded-xl font-bold text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-sm"
          >
            {loading ? t('auth:guardando') : t('auth:guardar_y_continuar')}
          </button>
          <button type="button" onClick={onLogout} className="w-full py-2 text-xs font-semibold text-slate-500 hover:text-slate-800">
            {t('auth:cerrar_sesion')}
          </button>
        </div>
      </form>
    </div>
  );
}
