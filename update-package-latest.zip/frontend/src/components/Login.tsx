import { useEffect, useState } from 'react';
import { authAPI } from '../services/api';
import { LanguageSelector } from './common/LanguageSelector';
import { AlertCircle, WifiOff, Eye, EyeOff, ShieldCheck, RefreshCw, Building2, Cloud } from 'lucide-react';
import { toast } from '../shared/toast';
import { ApiError, isConnectionError, errorMessage } from '../services/apiErrors';
import { usePlanStore } from '../shared/plan';
import { ExportDataButtons } from './common/ExportDataButtons';
import { SavedLoginField } from './common/SavedLoginField';
import { canSavePasswords, savedLogins, SavedLogin } from '../shared/savedLogins';

import { t, getLocale } from '../i18n';
import { useTransport, unpair, lanOnlyPaired } from '../services/transport';
import { androidBridge } from '../services/androidBridge';
import { confirmDialog } from '../shared/dialog';
interface LoginProps {
  onLogin: (user: any) => void;
}

const inputClass =
  'w-full px-4 py-3 border border-slate-300 rounded-xl bg-slate-50/50 focus:bg-white focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20 text-slate-900 placeholder-slate-400 text-sm font-medium transition-all';
const labelClass = 'block text-xs font-bold text-slate-700 mb-1.5';

const saveSession = (result: { token: string; user: any }) => {
  localStorage.setItem('token', result.token);
  localStorage.setItem('user', JSON.stringify(result.user));
};

function PasswordInput({ value, onChange, placeholder, autoComplete, id }: {
  value: string; onChange: (v: string) => void; placeholder?: string; autoComplete: string; id: string;
}) {
  const [visible, setVisible] = useState(false);
  return (
    <div className="relative">
      <input
        id={id}
        type={visible ? 'text' : 'password'}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className={`${inputClass} pr-11`}
        placeholder={placeholder}
        autoComplete={autoComplete}
        required
      />
      <button
        type="button"
        onClick={() => setVisible(v => !v)}
        className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-slate-400 hover:text-slate-700 rounded-lg"
        aria-label={visible ? t('auth:ocultar_contrasena') : t('auth:mostrar_contrasena')}
      >
        {visible ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
      </button>
    </div>
  );
}

interface LoginErrorInfo {
  title: string;
  message: string;
  /** Problema de conexión: se ofrece reintentar */
  retry?: boolean;
  /** Cuenta suspendida: el ADMIN puede descargar sus datos igual */
  exportToken?: string;
}

/** En la app del celular: por qué no llega a la caja (en vez del mensaje general) */
const phoneConnectionHint = (): string | null => {
  const st = useTransport.getState();
  if (!st.clientApp || !st.paired) return null;
  if (lanOnlyPaired()) return t('layout:login_solo_red_local');
  if (st.hostOnline === false) return t('layout:login_caja_sin_internet');
  return t('layout:login_sin_internet_ni_wifi');
};

/** Clasifica el error para que el usuario sepa qué falló, sin revelar detalles sensibles. */
const describeLoginError = (e: unknown, fallbackKey: string): LoginErrorInfo => {
  if (isConnectionError(e)) {
    return { title: t('auth:sin_conexion_con_el_servidor'), message: phoneConnectionHint() || errorMessage(e), retry: true };
  }
  const code = e instanceof ApiError ? e.code : '';
  if (code === 'RELAY_HOST_OFFLINE' || code === 'RELAY_UNAVAILABLE') {
    return { title: t('auth:sin_conexion_con_el_servidor'), message: t('layout:login_caja_sin_internet'), retry: true };
  }
  if (['CLOUD_UNREACHABLE', 'CLOUD_CLOCK_TAMPERED', 'CLOUD_OFFLINE_WINDOW_EXPIRED'].includes(code)) {
    return { title: t('auth:se_necesita_conexion'), message: errorMessage(e), retry: code === 'CLOUD_UNREACHABLE' };
  }
  if (code === 'CLOUD_SUBSCRIPTION_SUSPENDED') {
    const exportToken = e instanceof ApiError ? e.details.exportToken : undefined;
    return { title: t('auth:suscripcion_suspendida'), message: errorMessage(e), exportToken };
  }
  if (code === 'CLOUD_DEVICE_LIMIT' || code === 'CLOUD_DEVICE_REVOKED') return { title: t('auth:equipo_no_autorizado'), message: errorMessage(e) };
  if (code === 'CLOUD_LOCKED') return { title: t('auth:demasiados_intentos'), message: errorMessage(e) };
  if (code === 'CLOUD_TENANT_NOT_FOUND') return { title: t('auth:codigo_no_encontrado'), message: errorMessage(e) };
  if (code === 'AUTH_INVALID_CREDENTIALS') {
    return { title: t('auth:error_de_credenciales'), message: errorMessage(e) };
  }
  if (code === 'AUTH_RATE_LIMITED' || code === 'RATE_LIMITED') {
    return { title: t('auth:demasiados_intentos'), message: errorMessage(e) };
  }
  if (code === 'AUTH_WEAK_PASSWORD' || code === 'AUTH_INVALID_USERNAME' || code === 'AUTH_NAME_REQUIRED' || code === 'VALIDATION_ERROR') {
    return { title: t('auth:revisa_los_datos'), message: errorMessage(e) };
  }
  if (code === 'SERVER_ERROR') {
    return { title: t('auth:error_del_servidor'), message: errorMessage(e) };
  }
  return { title: t('auth:no_se_pudo_continuar'), message: errorMessage(e, fallbackKey) };
};

export function Login({ onLogin }: LoginProps) {
  const clientApp = useTransport((s) => s.clientApp);
  const business = useTransport((s) => s.business);
  const [mode, setMode] = useState<'loading' | 'login' | 'setup' | 'activate'>('loading');
  const [tenant, setTenant] = useState<{ code: string; name: string } | null>(null);
  const [activationCode, setActivationCode] = useState('');
  // Instalación que trabajaba en modo local: se conecta a la nube con la clave de su administrador
  const [canLink, setCanLink] = useState(false);
  const [localAdminUser, setLocalAdminUser] = useState('');
  const [localAdminPass, setLocalAdminPass] = useState('');
  const [error, setErrorInfo] = useState<LoginErrorInfo | null>(null);
  // Validaciones locales: solo texto
  const setError = (message: string) => setErrorInfo(message ? { title: t('auth:revisa_los_datos'), message } : null);
  const [loading, setLoading] = useState(false);

  // Login
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  // Ingresos guardados en este equipo (la contraseña solo en Lantify.exe, cifrada por Windows)
  const [saved, setSaved] = useState<SavedLogin[]>([]);
  const [remember, setRemember] = useState(() => savedLogins.remember());
  const [filledFrom, setFilledFrom] = useState<string | null>(null);
  useEffect(() => {
    savedLogins.list().then(setSaved);
  }, []);

  const pickSaved = async (login: SavedLogin) => {
    setUsername(login.username);
    setErrorInfo(null);
    const pass = login.hasPassword ? await savedLogins.password(login.username) : null;
    setPassword(pass || '');
    setFilledFrom(pass ? login.username : null);
    // Con la contraseña puesta basta Enter o "Ingresar"; si no, se escribe
    setTimeout(() => document.getElementById(pass ? 'login-submit' : 'login-password')?.focus(), 0);
  };

  const forgetSaved = async (login: SavedLogin) => {
    await savedLogins.remove(login.username);
    setSaved((list) => list.filter((l) => l.username !== login.username));
    if (filledFrom === login.username) {
      setPassword('');
      setFilledFrom(null);
    }
  };

  // Primer arranque: cuenta administradora
  const [setupName, setSetupName] = useState('');
  const [setupUsername, setSetupUsername] = useState('');
  const [setupPassword, setSetupPassword] = useState('');
  const [setupConfirm, setSetupConfirm] = useState('');

  const checkServer = () => {
    setMode('loading');
    setErrorInfo(null);
    authAPI.getSetupStatus()
      .then((status) => {
        setTenant(status.tenant || null);
        setCanLink(!!status.canLink);
        setMode(status.needsActivation ? 'activate' : status.needsSetup ? 'setup' : 'login');
      })
      .catch((e) => {
        setMode('login');
        setErrorInfo(describeLoginError(e, 'auth:error_al_iniciar_sesion'));
      });
  };

  useEffect(checkServer, []);

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const result = await authAPI.login(username.trim(), password);
      saveSession(result);
      // Recordar (o dejar de recordar) este ingreso en este equipo
      const who = username.trim().toLowerCase();
      savedLogins.setRemember(remember);
      if (remember) await savedLogins.save({ username: who, name: result.user?.name || who, password: canSavePasswords() ? password : undefined });
      else await savedLogins.remove(who);
      usePlanStore.getState().setFromLogin(result.license);
      if (result.license?.subStatus === 'GRACE' && result.license.graceUntil) {
        // Periodo de gracia: se recuerda en cada ingreso
        const date = new Date(result.license.graceUntil).toLocaleDateString(getLocale(), { day: 'numeric', month: 'long' });
        setTimeout(() => toast.show({ type: 'warning', title: t('plan:aviso_gracia_titulo'), message: t('plan:periodo_gracia', { date }), duration: 12000 }), 900);
      }
      if (result.offline && result.offlineUntil) {
        // Se avisa cuando la aplicación ya está montada
        const until = new Date(result.offlineUntil).toLocaleString(getLocale(), { dateStyle: 'medium', timeStyle: 'short' });
        setTimeout(() => toast.show({ type: 'warning', title: t('auth:ingreso_sin_conexion'), message: t('auth:ingreso_sin_conexion_desc', { until }), duration: 10000 }), 800);
      }
      onLogin(result.user);
    } catch (err) {
      // La contraseña guardada ya no sirve (la cambiaron): se olvida, el usuario se conserva
      if (filledFrom && err instanceof ApiError && err.code === 'AUTH_INVALID_CREDENTIALS') {
        const entry = saved.find((l) => l.username === filledFrom);
        await savedLogins.save({ username: filledFrom, name: entry?.name || filledFrom });
        setSaved((list) => list.map((l) => (l.username === filledFrom ? { ...l, hasPassword: false } : l)));
        setPassword('');
        setFilledFrom(null);
      }
      setErrorInfo(describeLoginError(err, 'auth:error_al_iniciar_sesion'));
    } finally {
      setLoading(false);
    }
  };

  const handleActivateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const linked = await authAPI.activateCloud(
        activationCode.trim().toUpperCase(),
        canLink ? { username: localAdminUser.trim().toLowerCase(), password: localAdminPass } : undefined,
      );
      setTenant(linked);
      setCanLink(false);
      setLocalAdminPass('');
      // Desde aquí se entra con el usuario y la clave de Lantify Cloud
      setUsername('');
      setPassword('');
      setMode('login');
      toast.show({ type: 'success', title: t('auth:equipo_vinculado'), message: t('auth:equipo_vinculado_desc', { name: linked.name }) });
    } catch (err) {
      setErrorInfo(describeLoginError(err, 'auth:no_se_pudo_vincular'));
    } finally {
      setLoading(false);
    }
  };

  const handleSetupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (setupPassword.length < 8) {
      setError(t('auth:la_contrasena_debe_tener_al_menos_8'));
      return;
    }
    if (setupPassword !== setupConfirm) {
      setError(t('auth:las_contrasenas_no_coinciden'));
      return;
    }
    setLoading(true);
    try {
      const result = await authAPI.setupFirstAdmin({
        name: setupName.trim(),
        username: setupUsername.trim().toLowerCase(),
        password: setupPassword,
      });
      saveSession(result);
      onLogin(result.user);
    } catch (err) {
      setErrorInfo(describeLoginError(err, 'auth:no_se_pudo_crear_la_cuenta_administradora'));
    } finally {
      setLoading(false);
    }
  };

  const submitLabel = (busy: string, idle: string) =>
    loading ? (
      <>
        <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
        <span>{busy}</span>
      </>
    ) : idle;

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-slate-950 relative overflow-hidden font-sans">
      {/* Subtle ambient background glow */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-[radial-gradient(#3e3e3b_1px,transparent_1px)] [background-size:24px_24px] opacity-20" />
      </div>

      <div className="relative w-full max-w-md">
        <div className="bg-white rounded-3xl shadow-2xl border border-slate-200/80 overflow-hidden">

          {/* Branding */}
          <div className="relative px-8 pt-8 pb-5 text-center bg-slate-900 border-b border-slate-800">
            <div className="absolute top-3 right-3">
              <LanguageSelector variant="pill" />
            </div>
            <img
              src="/logo-lantify-white.svg"
              alt="Lantify POS"
              className="h-12 sm:h-14 w-auto object-contain mx-auto mb-2 drop-shadow-md"
            />
            {tenant ? (
              <div className="flex items-center justify-center gap-1.5 text-slate-300 text-xs font-semibold">
                <Building2 className="w-3.5 h-3.5 text-emerald-400" aria-hidden />
                <span>{tenant.name}</span>
              </div>
            ) : (
              <div className="flex items-center justify-center gap-1.5 text-slate-400 text-xs font-semibold tracking-wide">
                <WifiOff className="w-3.5 h-3.5 text-emerald-400" />
                <span>{t('auth:operacion_100_local_y_autonoma')}</span>
              </div>
            )}
          </div>

          {error && (
            <div className="px-8 pt-5" role="alert">
              <div className={`border px-4 py-3 rounded-xl text-xs flex items-start gap-2.5 ${
                error.retry ? 'bg-amber-50 border-amber-200 text-amber-900' : 'bg-rose-50 border-rose-200 text-rose-700'
              }`}>
                {error.retry
                  ? <WifiOff className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" aria-hidden />
                  : <AlertCircle className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" aria-hidden />}
                <div className="flex-1 min-w-0">
                  <p className="font-bold">{error.title}</p>
                  <p className="font-medium mt-0.5 leading-relaxed">{error.message}</p>
                  {error.exportToken && (
                    <div className="mt-3">
                      <p className="font-medium text-rose-800">{t('plan:descarga_tus_datos')}</p>
                      <ExportDataButtons className="mt-2" getToken={async () => error.exportToken!} />
                    </div>
                  )}
                  {error.retry && (
                    <button
                      type="button"
                      onClick={checkServer}
                      className="mt-2 inline-flex items-center gap-1.5 font-bold text-amber-800 hover:text-amber-950 underline"
                    >
                      <RefreshCw className="w-3.5 h-3.5" aria-hidden />
                      {t('auth:reintentar')}
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          {mode === 'loading' && (
            <div className="px-8 py-12 flex justify-center">
              <span className="w-6 h-6 border-2 border-slate-200 border-t-blue-600 rounded-full animate-spin" />
            </div>
          )}

          {mode === 'activate' && (
            <form onSubmit={handleActivateSubmit} className="px-8 py-6 space-y-4">
              <div className="flex items-start gap-3 bg-blue-50 border border-blue-100 rounded-xl p-3">
                <Cloud className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" aria-hidden />
                <div className="text-xs text-blue-900 leading-relaxed">
                  <p className="font-bold">{t('auth:vincula_este_equipo')}</p>
                  <p className="mt-0.5">{t('auth:vincula_este_equipo_desc')}</p>
                </div>
              </div>
              <div>
                <label htmlFor="activation-code" className={labelClass}>{t('auth:codigo_del_negocio')}</label>
                <input
                  id="activation-code"
                  type="text"
                  value={activationCode}
                  onChange={(e) => setActivationCode(e.target.value.toUpperCase().replace(/[^A-Z0-9-]/g, ''))}
                  className={`${inputClass} font-mono tracking-wider uppercase`}
                  placeholder={t('auth:codigo_ejemplo')}
                  autoComplete="off"
                  autoFocus
                  required
                  maxLength={40}
                />
              </div>
              {canLink && (
                <>
                  <p className="text-xs text-slate-600 leading-relaxed">{t('auth:confirma_admin_local')}</p>
                  <div>
                    <label htmlFor="link-admin-user" className={labelClass}>{t('auth:usuario_admin_local')}</label>
                    <input id="link-admin-user" type="text" value={localAdminUser} onChange={(e) => setLocalAdminUser(e.target.value)}
                      className={inputClass} autoComplete="username" required />
                  </div>
                  <div>
                    <label htmlFor="link-admin-pass" className={labelClass}>{t('auth:contrasena')}</label>
                    <PasswordInput id="link-admin-pass" value={localAdminPass} onChange={setLocalAdminPass} autoComplete="current-password" />
                  </div>
                </>
              )}
              <button
                type="submit"
                disabled={loading || activationCode.length < 3 || (canLink && (!localAdminUser || !localAdminPass))}
                className="w-full py-3.5 rounded-xl font-bold text-white bg-blue-600 hover:bg-blue-700 transition-all disabled:opacity-60 flex items-center justify-center gap-2 text-sm"
              >
                {submitLabel(t('auth:vinculando'), t('auth:vincular'))}
              </button>
              {canLink && (
                <button type="button" onClick={() => { setErrorInfo(null); setMode('login'); }}
                  className="w-full text-sm font-semibold text-slate-500 hover:text-slate-800">
                  {t('auth:volver_al_ingreso')}
                </button>
              )}
            </form>
          )}

          {mode === 'login' && (
            <form onSubmit={handleLoginSubmit} className="px-8 py-6 space-y-4">
              <div>
                <label htmlFor="login-username" className={labelClass}>{t('auth:usuario')}</label>
                <SavedLoginField
                  id="login-username"
                  value={username}
                  onChange={(v) => {
                    setUsername(v);
                    if (filledFrom && v.trim().toLowerCase() !== filledFrom) {
                      setPassword('');
                      setFilledFrom(null);
                    }
                  }}
                  saved={saved}
                  onPick={pickSaved}
                  onForget={forgetSaved}
                  className={inputClass}
                  autoFocus
                />
              </div>

              <div>
                <label htmlFor="login-password" className={labelClass}>{t('auth:contrasena')}</label>
                <PasswordInput id="login-password" value={password} onChange={(v) => { setPassword(v); setFilledFrom(null); }} autoComplete="current-password" />
              </div>

              <label className="flex items-start gap-2.5 cursor-pointer select-none">
                <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} className="mt-0.5 w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500/30" />
                <span className="text-xs text-slate-600 leading-snug">
                  {canSavePasswords() ? (androidBridge()?.loginsList ? t('auth:recordar_celular') : t('auth:recordar_equipo')) : t('auth:recordar_tablet')}
                </span>
              </label>

              <button
                id="login-submit"
                type="submit"
                disabled={loading}
                className="w-full py-3.5 rounded-xl font-bold text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 transition-all duration-200 disabled:opacity-60 shadow-lg shadow-blue-500/25 flex items-center justify-center gap-2 text-sm"
              >
                {submitLabel(t('auth:ingresando'), t('auth:ingresar'))}
              </button>

              <p className="text-xs text-slate-500 text-center">
                {t('auth:olvidaste_tu_contrasena_pide_al_administrador_que')}
              </p>
              {canLink && (
                <button type="button" onClick={() => { setErrorInfo(null); setMode('activate'); }}
                  className="w-full flex items-center justify-center gap-2 rounded-xl border border-slate-200 py-3 text-sm font-semibold text-blue-700 hover:bg-blue-50 transition-colors">
                  <Cloud className="w-4 h-4" aria-hidden /> {t('auth:conectar_con_cloud')}
                </button>
              )}
            </form>
          )}

          {mode === 'setup' && (
            <form onSubmit={handleSetupSubmit} className="px-8 py-6 space-y-3.5">
              <div className="flex items-start gap-3 bg-blue-50 border border-blue-100 rounded-xl p-3">
                <ShieldCheck className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-bold text-slate-900">{t('auth:configuracion_inicial')}</p>
                  <p className="text-xs text-slate-600">{t('auth:crea_la_cuenta_del_administrador_del_negocio')}</p>
                </div>
              </div>

              <div>
                <label htmlFor="setup-name" className={labelClass}>{t('auth:nombre_completo')}</label>
                <input id="setup-name" type="text" value={setupName} onChange={(e) => setSetupName(e.target.value)} className={inputClass} autoComplete="name" autoFocus required />
              </div>

              <div>
                <label htmlFor="setup-username" className={labelClass}>{t('auth:usuario')}</label>
                <input
                  id="setup-username"
                  type="text"
                  value={setupUsername}
                  onChange={(e) => setSetupUsername(e.target.value.toLowerCase().replace(/\s+/g, ''))}
                  className={inputClass}
                  autoComplete="username"
                  minLength={3}
                  required
                />
              </div>

              <div>
                <label htmlFor="setup-password" className={labelClass}>{t('auth:contrasena')}</label>
                <PasswordInput id="setup-password" value={setupPassword} onChange={setSetupPassword} placeholder={t('auth:minimo_8_caracteres')} autoComplete="new-password" />
              </div>

              <div>
                <label htmlFor="setup-confirm" className={labelClass}>{t('auth:confirmar_contrasena')}</label>
                <PasswordInput id="setup-confirm" value={setupConfirm} onChange={setSetupConfirm} autoComplete="new-password" />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 rounded-xl font-bold text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 transition-all duration-200 disabled:opacity-60 shadow-lg shadow-blue-500/25 flex items-center justify-center gap-2 text-sm"
              >
                {submitLabel(t('auth:creando_cuenta'), t('auth:crear_cuenta_y_entrar'))}
              </button>
            </form>
          )}

          <div className="px-8 pb-5 text-center border-t border-slate-100 pt-3 bg-slate-50/50">
            <p className="text-xs text-slate-400 font-medium">{t('auth:value_lantify_pos_sistema_de_punto_de', { value: new Date().getFullYear() })}</p>
            {clientApp && (
              <button
                type="button"
                onClick={async () => {
                  if (await confirmDialog({ title: t('layout:cambiar_local'), message: t('layout:cambiar_local_confirmar', { name: business || 'Lantify' }) })) unpair();
                }}
                className="mt-2 text-xs font-medium text-slate-500 underline underline-offset-2 hover:text-slate-700"
              >
                {business ? `${business} · ` : ''}{t('layout:cambiar_local')}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
