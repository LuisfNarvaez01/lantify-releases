// ============================================
// HELP - Markdown mínimo para los artículos de ayuda
// ============================================
// Soporta: ## subtítulos, listas (- y 1.), **negrita**, *cursiva*, `teclas` y
// [[tour:id|texto]] (botón que lanza el recorrido). Construye elementos de React,
// nunca HTML crudo.

import { Fragment, ReactNode } from 'react';
import { PlayCircle } from 'lucide-react';

interface MarkdownViewProps {
  source: string;
  onTour?: (tourId: string) => void;
}

const inline = (text: string, keyBase: string): ReactNode[] => {
  const out: ReactNode[] = [];
  const re = /(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`)/g;
  let last = 0;
  let m: RegExpExecArray | null;
  let i = 0;
  while ((m = re.exec(text))) {
    if (m.index > last) out.push(text.slice(last, m.index));
    const token = m[0];
    const key = `${keyBase}-${i++}`;
    if (token.startsWith('**')) out.push(<strong key={key} className="font-semibold text-slate-900">{token.slice(2, -2)}</strong>);
    else if (token.startsWith('`')) out.push(<kbd key={key} className="px-1.5 py-0.5 rounded-md bg-slate-100 border border-slate-200 text-[0.85em] font-mono text-slate-800">{token.slice(1, -1)}</kbd>);
    else out.push(<em key={key}>{token.slice(1, -1)}</em>);
    last = m.index + token.length;
  }
  if (last < text.length) out.push(text.slice(last));
  return out;
};

export function MarkdownView({ source, onTour }: MarkdownViewProps) {
  const blocks: ReactNode[] = [];
  const lines = source.split('\n');
  let list: { ordered: boolean; items: string[] } | null = null;
  let para: string[] = [];

  const flushPara = () => {
    if (para.length) {
      const k = `p${blocks.length}`;
      blocks.push(<p key={k} className="text-sm leading-relaxed text-slate-700">{inline(para.join(' '), k)}</p>);
      para = [];
    }
  };
  const flushList = () => {
    if (list) {
      const k = `l${blocks.length}`;
      const Tag = list.ordered ? 'ol' : 'ul';
      blocks.push(
        <Tag key={k} className={`space-y-1.5 pl-5 text-sm leading-relaxed text-slate-700 ${list.ordered ? 'list-decimal' : 'list-disc'} marker:text-slate-400`}>
          {list.items.map((item, idx) => <li key={idx}>{inline(item, `${k}-${idx}`)}</li>)}
        </Tag>,
      );
      list = null;
    }
  };

  for (const raw of lines) {
    const line = raw.trim();
    const tour = line.match(/^\[\[tour:([a-z-]+)\|([^\]]+)\]\]$/);
    if (!line) {
      flushPara();
      flushList();
    } else if (line.startsWith('## ')) {
      flushPara();
      flushList();
      blocks.push(<h3 key={`h${blocks.length}`} className="text-sm font-bold text-slate-900 pt-2">{line.slice(3)}</h3>);
    } else if (tour) {
      flushPara();
      flushList();
      blocks.push(
        <button
          key={`t${blocks.length}`}
          type="button"
          onClick={() => onTour?.(tour[1])}
          className="inline-flex items-center gap-2 h-10 px-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold"
        >
          <PlayCircle className="w-4 h-4" aria-hidden />
          {tour[2]}
        </button>,
      );
    } else if (/^(-|\d+\.)\s/.test(line)) {
      flushPara();
      const ordered = /^\d+\./.test(line);
      if (!list || list.ordered !== ordered) {
        flushList();
        list = { ordered, items: [] };
      }
      list.items.push(line.replace(/^(-|\d+\.)\s+/, ''));
    } else {
      flushList();
      para.push(line);
    }
  }
  flushPara();
  flushList();

  return <div className="space-y-3">{blocks.map((b, i) => <Fragment key={i}>{b}</Fragment>)}</div>;
}
