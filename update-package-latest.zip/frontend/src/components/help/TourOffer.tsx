// ============================================
// HELP - Ofrecimiento del recorrido la primera vez que se entra a una pantalla
// ============================================
// No interrumpe: es una tarjeta pequeña. "Ahora no" no vuelve a ofrecer ese
// recorrido; "No volver a mostrar" apaga los ofrecimientos para este usuario.

import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { Compass, X } from 'lucide-react';
import { t } from '../../i18n';
import { useGuideStore } from '../../guide/guideStore';
import { markTourSeen, muteTours, pendingTourFor, requestTour } from '../../guide/tourRunner';
import { tourTitle, TourDef } from '../../guide/tours';

export function TourOffer({ role }: { role: string }) {
  const module = useGuideStore((s) => s.module);
  const helpOpen = useGuideStore((s) => s.helpOpen);
  const [offer, setOffer] = useState<TourDef | null>(null);

  useEffect(() => {
    setOffer(null);
    // Un momento después de entrar, para no competir con la carga de la pantalla
    const timer = setTimeout(() => {
      if (document.querySelector('[aria-modal="true"], .driver-popover')) return;
      setOffer(pendingTourFor(module, role));
    }, 1200);
    return () => clearTimeout(timer);
  }, [module, role]);

  if (!offer || helpOpen) return null;

  const dismiss = () => {
    markTourSeen(offer.id);
    setOffer(null);
  };

  return createPortal(
    <div role="dialog" aria-labelledby="tour-offer-title" className="fixed bottom-4 left-4 z-50 w-[min(22rem,calc(100vw-2rem))] bg-white border border-slate-200 rounded-2xl shadow-xl p-4">
      <button type="button" onClick={dismiss} aria-label={t('guide:ahora_no')} className="absolute top-2 right-2 w-9 h-9 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 flex items-center justify-center">
        <X className="w-4 h-4" aria-hidden />
      </button>
      <div className="flex items-start gap-3 pr-6">
        <span className="w-9 h-9 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center shrink-0">
          <Compass className="w-5 h-5" aria-hidden />
        </span>
        <div className="min-w-0">
          <p id="tour-offer-title" className="text-sm font-bold text-slate-900">{tourTitle(offer.id)}</p>
          <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">{t('guide:oferta_desc')}</p>
        </div>
      </div>
      <div className="mt-3 flex items-center gap-2">
        <button
          type="button"
          onClick={() => { markTourSeen(offer.id); setOffer(null); requestTour(offer.id); }}
          className="h-10 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold"
        >
          {t('guide:ver_recorrido')}
        </button>
        <button type="button" onClick={dismiss} className="h-10 px-3 rounded-xl text-sm font-semibold text-slate-600 hover:bg-slate-100">
          {t('guide:ahora_no')}
        </button>
      </div>
      <button
        type="button"
        onClick={() => { muteTours(); setOffer(null); }}
        className="mt-1 text-xs text-slate-500 hover:text-slate-800 underline underline-offset-2"
      >
        {t('guide:no_volver_a_mostrar')}
      </button>
    </div>,
    document.body,
  );
}
