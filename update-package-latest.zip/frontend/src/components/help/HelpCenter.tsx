// ============================================
// HELP - Centro de ayuda (panel lateral): artículos, recorridos y asistente
// ============================================

import { useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { X, Search, ArrowLeft, PlayCircle, BookOpen, Sparkles, Send, WifiOff, ChevronRight, ShieldCheck, Loader2, Compass } from 'lucide-react';
import { useSetupGuide, useGuideProgress } from '../../shared/setupGuide';
import { t, useLanguage } from '../../i18n';
import { useGuideStore } from '../../guide/guideStore';
import { requestTour } from '../../guide/tourRunner';
import { toursForRole, tourTitle } from '../../guide/tours';
import { articlesFor, getArticle, searchArticles, HelpArticle } from '../../help';
import { askCopilot, isCopilotConfigured, ChatTurn, CopilotError } from '../../guide/copilot';
import { useBusiness } from '../../shared/business';
import { MarkdownView } from './MarkdownView';

interface HelpCenterProps {
  role: string;
}

export function HelpCenter({ role }: HelpCenterProps) {
  const { helpOpen, helpTab, closeHelp, setTab } = useGuideStore();
  const panelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!helpOpen) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') closeHelp(); };
    window.addEventListener('keydown', onKey);
    panelRef.current?.focus();
    return () => window.removeEventListener('keydown', onKey);
  }, [helpOpen, closeHelp]);

  if (!helpOpen) return null;

  return createPortal(
    <div className="fixed inset-0 z-[60] flex justify-end" role="presentation">
      <div className="absolute inset-0 bg-slate-900/30" onClick={closeHelp} aria-hidden />
      <aside
        ref={panelRef}
        tabIndex={-1}
        role="dialog"
        aria-modal="true"
        aria-labelledby="help-title"
        className="relative h-full w-full sm:w-[26rem] bg-white shadow-2xl flex flex-col outline-none"
      >
        <header className="px-4 pt-4 pb-3 border-b border-slate-200 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <h2 id="help-title" className="text-lg font-bold text-slate-900 font-heading">{t('guide:centro_de_ayuda')}</h2>
            <button type="button" onClick={closeHelp} aria-label={t('guide:cerrar')} className="w-10 h-10 rounded-xl hover:bg-slate-100 text-slate-500 flex items-center justify-center">
              <X className="w-5 h-5" aria-hidden />
            </button>
          </div>
          <div role="tablist" aria-label={t('guide:centro_de_ayuda')} className="grid grid-cols-2 gap-1 p-1 rounded-xl bg-slate-100">
            {(['help', 'assistant'] as const).map((tab) => (
              <button
                key={tab}
                type="button"
                role="tab"
                aria-selected={helpTab === tab}
                onClick={() => setTab(tab)}
                className={`h-9 rounded-lg text-sm font-semibold inline-flex items-center justify-center gap-1.5 transition-colors ${
                  helpTab === tab ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {tab === 'help' ? <BookOpen className="w-4 h-4" aria-hidden /> : <Sparkles className="w-4 h-4" aria-hidden />}
                {tab === 'help' ? t('guide:ayuda') : t('guide:asistente')}
              </button>
            ))}
          </div>
        </header>
        {helpTab === 'help' ? <HelpTab role={role} /> : <AssistantTab role={role} />}
      </aside>
    </div>,
    document.body,
  );
}

const startTourFromHelp = (tourId: string) => {
  useGuideStore.getState().closeHelp();
  // Se espera a que el panel desaparezca para resaltar el elemento correcto
  setTimeout(() => requestTour(tourId), 150);
};

function HelpTab({ role }: { role: string }) {
  const { language } = useLanguage();
  const { module, articleId, setArticle } = useGuideStore();
  const [query, setQuery] = useState('');
  const list = useMemo(() => articlesFor(language, role), [language, role]);
  const results = useMemo(() => searchArticles(query, list), [query, list]);
  const article = articleId ? getArticle(articleId, language) : null;

  if (article) {
    return (
      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-4 space-y-4">
        <button type="button" onClick={() => setArticle(null)} className="inline-flex items-center gap-1.5 h-9 -ml-1 px-1 rounded-lg text-sm font-semibold text-slate-600 hover:text-slate-900">
          <ArrowLeft className="w-4 h-4" aria-hidden />
          {t('guide:volver')}
        </button>
        <h3 className="text-xl font-bold text-slate-900 font-heading leading-snug">{article.title}</h3>
        <MarkdownView source={article.body} onTour={startTourFromHelp} />
      </div>
    );
  }

  const here = list.filter((a) => a.module === module);
  const tours = toursForRole(role);

  return (
    <div className="flex-1 min-h-0 overflow-y-auto px-4 py-4 space-y-6">
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" aria-hidden />
        <input
          autoFocus
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={t('guide:buscar_en_la_ayuda')}
          aria-label={t('guide:buscar_en_la_ayuda')}
          className="w-full h-11 pl-9 pr-3 text-sm border border-slate-200 rounded-xl bg-white focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20"
        />
      </div>

      {query.trim() ? (
        results.length > 0 ? (
          <ArticleList articles={results} onOpen={setArticle} />
        ) : (
          <p className="text-sm text-slate-500">{t('guide:sin_resultados')}</p>
        )
      ) : (
        <>
          {role === 'ADMIN' && <SetupGuideCard />}
          {here.length > 0 && (
            <section className="space-y-2">
              <h3 className="text-xs font-semibold text-slate-500">{t('guide:para_esta_pantalla')}</h3>
              <ArticleList articles={here} onOpen={setArticle} />
            </section>
          )}
          <section className="space-y-2">
            <h3 className="text-xs font-semibold text-slate-500">{t('guide:recorridos_guiados')}</h3>
            <ul className="space-y-1">
              {tours.map((tour) => (
                <li key={tour.id}>
                  <button
                    type="button"
                    onClick={() => startTourFromHelp(tour.id)}
                    className="w-full min-h-[44px] px-3 rounded-xl hover:bg-slate-50 text-left inline-flex items-center gap-3 text-sm font-semibold text-slate-800"
                  >
                    <PlayCircle className="w-4 h-4 text-blue-600 shrink-0" aria-hidden />
                    {tourTitle(tour.id)}
                  </button>
                </li>
              ))}
            </ul>
          </section>
          <section className="space-y-2">
            <h3 className="text-xs font-semibold text-slate-500">{t('guide:todos_los_temas')}</h3>
            <ArticleList articles={list.filter((a) => a.module !== module)} onOpen={setArticle} />
          </section>
        </>
      )}
    </div>
  );
}

/** Guía de configuración: avance y acceso directo (solo el administrador) */
function SetupGuideCard() {
  const { loaded, progress } = useGuideProgress();
  if (!loaded) return null;
  const open = () => {
    useGuideStore.getState().closeHelp();
    useSetupGuide.getState().requestOpen();
  };
  return (
    <section className="rounded-2xl border border-blue-100 bg-blue-50/60 p-4">
      <div className="flex items-start gap-3">
        <Compass className="w-5 h-5 text-blue-700 shrink-0 mt-0.5" aria-hidden />
        <div className="min-w-0 flex-1">
          <h3 className="text-sm font-bold text-slate-900">{t('setup:titulo')}</h3>
          <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
            {progress.complete ? t('setup:todo_listo') : t('setup:ayuda_desc', { done: progress.done, total: progress.total })}
          </p>
          <button type="button" onClick={open} className="mt-2 h-9 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold">
            {progress.complete ? t('setup:revisar') : t('setup:continuar')}
          </button>
        </div>
      </div>
    </section>
  );
}

function ArticleList({ articles, onOpen }: { articles: HelpArticle[]; onOpen: (id: string) => void }) {
  return (
    <ul className="divide-y divide-slate-100 rounded-xl border border-slate-200">
      {articles.map((a) => (
        <li key={a.id}>
          <button type="button" onClick={() => onOpen(a.id)} className="w-full min-h-[48px] px-3 py-2 text-left flex items-center gap-3 hover:bg-slate-50">
            <span className="flex-1 min-w-0 text-sm font-semibold text-slate-800">{a.title}</span>
            <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" aria-hidden />
          </button>
        </li>
      ))}
    </ul>
  );
}

interface Message extends ChatTurn {
  tourId?: string | null;
  articles?: HelpArticle[];
  error?: string;
}

function AssistantTab({ role }: { role: string }) {
  const { language } = useLanguage();
  const { module, setTab, setArticle } = useGuideStore();
  const { settings } = useBusiness();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  const [configured, setConfigured] = useState(true);
  useEffect(() => {
    isCopilotConfigured().then(setConfigured);
  }, []);

  useEffect(() => {
    endRef.current?.scrollIntoView({ block: 'end' });
  }, [messages, busy]);

  const errorText = (code: string) => t(`guide:${code}`);

  const ask = async (question: string) => {
    const q = question.trim();
    if (!q || busy) return;
    const history: ChatTurn[] = messages.filter((m) => !m.error).map(({ role: r, content }) => ({ role: r, content }));
    setMessages((prev) => [...prev, { role: 'user', content: q }]);
    setInput('');
    setBusy(true);
    try {
      const reply = await askCopilot({ question: q, lang: language, module, role, businessType: settings?.businessType, history });
      setMessages((prev) => [...prev, { role: 'assistant', content: reply.answer, tourId: reply.tourId }]);
    } catch (e) {
      // Sin IA, se responde con la ayuda local
      const code = e instanceof CopilotError ? e.code : 'AI_UNAVAILABLE';
      const local = searchArticles(q, articlesFor(language, role), 3);
      setMessages((prev) => [...prev, { role: 'assistant', content: '', error: errorText(code), articles: local }]);
    } finally {
      setBusy(false);
    }
  };

  const suggestions = [t('guide:sugerencia_1'), t('guide:sugerencia_2'), t('guide:sugerencia_3')];

  return (
    <div className="flex-1 min-h-0 flex flex-col">
      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-4 space-y-4" aria-live="polite">
        {!configured && (
          <div className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600 leading-relaxed">
            <WifiOff className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" aria-hidden />
            <span>{t('guide:asistente_no_configurado')}</span>
          </div>
        )}

        {messages.length === 0 && (
          <div className="space-y-3">
            <p className="text-sm text-slate-700 leading-relaxed">{t('guide:asistente_intro')}</p>
            <div className="flex flex-col items-start gap-2">
              {suggestions.map((s) => (
                <button key={s} type="button" onClick={() => ask(s)} className="min-h-[40px] px-3 py-2 rounded-xl border border-slate-200 hover:border-slate-300 hover:bg-slate-50 text-left text-sm text-slate-700">
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((m, i) =>
          m.role === 'user' ? (
            <div key={i} className="flex justify-end">
              <p className="max-w-[85%] px-3.5 py-2.5 rounded-2xl rounded-br-md bg-blue-600 text-white text-sm leading-relaxed whitespace-pre-wrap">{m.content}</p>
            </div>
          ) : (
            <div key={i} className="space-y-2">
              {m.error ? (
                <div className="space-y-2">
                  <p className="text-sm text-slate-600 leading-relaxed">{m.error}</p>
                  {m.articles && m.articles.length > 0 ? (
                    <ul className="space-y-1">
                      {m.articles.map((a) => (
                        <li key={a.id}>
                          <button
                            type="button"
                            onClick={() => { setTab('help'); setArticle(a.id); }}
                            className="w-full min-h-[44px] px-3 rounded-xl border border-slate-200 hover:bg-slate-50 text-left text-sm font-semibold text-slate-800 inline-flex items-center justify-between gap-2"
                          >
                            {a.title}
                            <ChevronRight className="w-4 h-4 text-slate-400" aria-hidden />
                          </button>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-sm text-slate-500">{t('guide:sin_resultados')}</p>
                  )}
                </div>
              ) : (
                <div className="px-3.5 py-3 rounded-2xl rounded-bl-md bg-slate-100">
                  <MarkdownView source={m.content} onTour={startTourFromHelp} />
                </div>
              )}
              {m.tourId && (
                <button
                  type="button"
                  onClick={() => startTourFromHelp(m.tourId!)}
                  className="inline-flex items-center gap-2 h-10 px-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold"
                >
                  <PlayCircle className="w-4 h-4" aria-hidden />
                  {t('guide:mostrarme')}
                </button>
              )}
            </div>
          ),
        )}
        {busy && (
          <p className="inline-flex items-center gap-2 text-sm text-slate-500">
            <Loader2 className="w-4 h-4 animate-spin" aria-hidden />
            {t('guide:pensando')}
          </p>
        )}
        <div ref={endRef} />
      </div>

      <form
        onSubmit={(e) => { e.preventDefault(); ask(input); }}
        className="border-t border-slate-200 p-3 space-y-2"
      >
        <div className="flex items-end gap-2">
          <label htmlFor="copilot-input" className="sr-only">{t('guide:escribe_tu_pregunta')}</label>
          <textarea
            id="copilot-input"
            rows={1}
            value={input}
            maxLength={500}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); ask(input); } }}
            placeholder={t('guide:escribe_tu_pregunta')}
            className="flex-1 resize-none max-h-32 px-3 py-2.5 text-sm border border-slate-200 rounded-xl focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20"
          />
          <button type="submit" disabled={busy || !input.trim()} aria-label={t('guide:enviar')} className="w-11 h-11 rounded-xl bg-blue-600 hover:bg-blue-700 text-white inline-flex items-center justify-center disabled:opacity-40">
            <Send className="w-4 h-4" aria-hidden />
          </button>
        </div>
        <p className="flex items-center gap-1.5 text-[0.7857rem] text-slate-500">
          <ShieldCheck className="w-3.5 h-3.5" aria-hidden />
          {t('guide:privacidad')}
        </p>
      </form>
    </div>
  );
}
