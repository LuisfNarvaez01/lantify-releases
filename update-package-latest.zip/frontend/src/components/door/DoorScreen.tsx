// ============================================
// PUERTA - Pantalla del portero (Fase 4 · cover, manillas y aforo)
// ============================================
// Para el celular del portero (rol DOOR): ocupación en vivo contra el aforo,
// +1 / −1 con un toque y el código impreso en la manilla. Los covers que cobra
// la caja suman solos. Al 90 % avisa; lleno, avisa más fuerte, pero nunca bloquea.

import React, { FormEvent, useCallback, useEffect, useRef, useState } from 'react';
import { DoorOpen, LogOut, Minus, Plus, Ticket } from 'lucide-react';
import { t } from '../../i18n';
import { toast } from '../../shared/toast';
import { LIVE_DOOR_EVENT, useLiveEvents } from '../../shared/live';
import { doorAPI, type DoorState } from '../../services/v3Api';

const POLL_MS = 15_000;

const LEVEL_LOOK: Record<DoorState['level'], { bar: string; text: string }> = {
  none: { bar: 'bg-blue-600', text: 'text-slate-900' },
  ok: { bar: 'bg-emerald-500', text: 'text-slate-900' },
  warn: { bar: 'bg-amber-500', text: 'text-amber-900' },
  full: { bar: 'bg-rose-600', text: 'text-rose-700' },
};

const buzz = () => {
  try { navigator.vibrate?.(25); } catch { /* sin vibración */ }
};

export const DoorScreen: React.FC<{ user?: any; onLogout: () => void }> = ({ user, onLogout }) => {
  useLiveEvents(true);
  const [state, setState] = useState<DoorState | null>(null);
  const [off, setOff] = useState(false);
  const [busy, setBusy] = useState(false);
  const [band, setBand] = useState('');
  const bandRef = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    try {
      setState(await doorAPI.state());
      setOff(false);
    } catch (err: any) {
      if (err?.code === 'FEATURE_OFF' || err?.status === 403 || err?.status === 402) setOff(true);
    }
  }, []);

  useEffect(() => {
    load();
    const onLive = () => load();
    window.addEventListener(LIVE_DOOR_EVENT, onLive);
    const timer = window.setInterval(() => { if (!document.hidden) load(); }, POLL_MS);
    return () => {
      window.removeEventListener(LIVE_DOOR_EVENT, onLive);
      window.clearInterval(timer);
    };
  }, [load]);

  const mark = async (kind: 'IN' | 'OUT', wristband?: string) => {
    if (busy) return;
    setBusy(true);
    buzz();
    try {
      const res = await doorAPI.mark(kind, wristband);
      setState(res.state);
      if (wristband) {
        toast.success(kind === 'IN' ? t('v3:puerta_manilla_entra', { code: res.event.wristband }) : t('v3:puerta_manilla_sale', { code: res.event.wristband }));
        setBand('');
      }
    } catch (err: any) {
      toast.error(err?.message || t('v3:no_se_guardo'));
    } finally {
      setBusy(false);
      if (wristband) bandRef.current?.focus();
    }
  };

  const submitBand = (kind: 'IN' | 'OUT') => (e?: FormEvent) => {
    e?.preventDefault();
    if (band.trim()) mark(kind, band.trim());
  };

  const look = LEVEL_LOOK[state?.level || 'none'];
  const pct = state?.capacity ? Math.min(100, Math.round((state.occupancy * 100) / state.capacity)) : null;

  return (
    <div className="flex min-h-[100dvh] flex-col bg-slate-50">
      <header className="flex items-center justify-between gap-3 border-b border-slate-200 bg-white px-4 py-3">
        <div className="flex min-w-0 items-center gap-2">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-slate-900 text-white"><DoorOpen className="h-5 w-5" aria-hidden /></span>
          <div className="min-w-0">
            <h1 className="font-heading text-lg font-bold text-slate-900">{t('v3:puerta_titulo')}</h1>
            <p className="truncate text-xs text-slate-500">{user?.name || user?.username}</p>
          </div>
        </div>
        <button type="button" onClick={onLogout} className="inline-flex min-h-[44px] items-center gap-2 rounded-xl px-3 text-sm font-semibold text-slate-700 hover:bg-slate-100">
          <LogOut className="h-4 w-4" aria-hidden /> {t('v3:puerta_salir')}
        </button>
      </header>

      {off ? (
        <main className="flex flex-1 items-center justify-center p-6 text-center">
          <p className="max-w-sm text-base font-semibold text-slate-700">{t('v3:puerta_apagada')}</p>
        </main>
      ) : (
        <main className="mx-auto flex w-full max-w-md flex-1 flex-col gap-4 p-4">
          {/* Ocupación en vivo */}
          <section className="rounded-3xl bg-white p-5 shadow-sm" aria-live="polite">
            <p className="text-xs font-bold uppercase tracking-wide text-slate-500">{t('v3:puerta_adentro')}</p>
            <p className={`font-heading text-6xl font-black tabular-nums ${look.text}`}>
              {state ? state.occupancy : '—'}
              {state?.capacity ? <span className="text-2xl font-bold text-slate-400"> / {state.capacity}</span> : null}
            </p>
            {pct !== null && (
              <div className="mt-3 h-3 overflow-hidden rounded-full bg-slate-100" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100}>
                <div className={`h-full rounded-full transition-all duration-300 ${look.bar}`} style={{ width: `${pct}%` }} />
              </div>
            )}
            {state?.level === 'warn' && <p className="mt-3 rounded-xl bg-amber-100 p-3 text-sm font-bold text-amber-900" role="alert">{t('v3:puerta_aviso_90', { pct })}</p>}
            {state?.level === 'full' && <p className="mt-3 rounded-xl bg-rose-100 p-3 text-sm font-bold text-rose-800" role="alert">{t('v3:puerta_aviso_lleno')}</p>}
            {state && !state.capacity && <p className="mt-2 text-xs text-slate-500">{t('v3:puerta_sin_aforo')}</p>}
          </section>

          {/* +1 / −1 */}
          <div className="grid grid-cols-2 gap-3">
            <button type="button" disabled={busy || !state} onClick={() => mark('OUT')} className="flex min-h-[112px] flex-col items-center justify-center gap-1 rounded-3xl border-2 border-slate-300 bg-white text-slate-800 shadow-sm active:scale-[0.98] disabled:opacity-50" aria-label={t('v3:puerta_sale')}>
              <Minus className="h-10 w-10" aria-hidden />
              <span className="text-base font-bold">{t('v3:puerta_sale')}</span>
            </button>
            <button type="button" disabled={busy || !state} onClick={() => mark('IN')} className="flex min-h-[112px] flex-col items-center justify-center gap-1 rounded-3xl bg-blue-700 text-white shadow-sm active:scale-[0.98] disabled:opacity-50" aria-label={t('v3:puerta_entra')}>
              <Plus className="h-10 w-10" aria-hidden />
              <span className="text-base font-bold">{t('v3:puerta_entra')}</span>
            </button>
          </div>

          {/* Manilla */}
          <form onSubmit={submitBand('IN')} className="space-y-2 rounded-3xl bg-white p-4 shadow-sm">
            <label htmlFor="door-band" className="flex items-center gap-2 text-sm font-bold text-slate-800"><Ticket className="h-4 w-4" aria-hidden /> {t('v3:puerta_manilla')}</label>
            <input
              id="door-band" ref={bandRef} value={band} onChange={(e) => setBand(e.target.value.toUpperCase())} maxLength={30} autoComplete="off" autoCapitalize="characters"
              placeholder={t('v3:puerta_manilla_ej')} className="w-full rounded-xl border border-slate-300 px-4 py-3 font-mono text-lg tracking-wider text-slate-900 outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/30"
            />
            <div className="grid grid-cols-2 gap-2">
              <button type="button" disabled={busy || !band.trim()} onClick={submitBand('OUT')} className="min-h-[48px] rounded-xl border-2 border-slate-300 font-bold text-slate-700 disabled:opacity-50">{t('v3:puerta_manilla_salida')}</button>
              <button type="submit" disabled={busy || !band.trim()} className="min-h-[48px] rounded-xl bg-slate-900 font-bold text-white disabled:opacity-50">{t('v3:puerta_manilla_entrada')}</button>
            </div>
          </form>

          {/* La noche */}
          {state && (
            <dl className="grid grid-cols-4 gap-2 text-center">
              {([['puerta_covers', state.coversSold], ['puerta_entradas', state.entries], ['puerta_salidas', state.exits], ['puerta_pico', state.peak]] as const).map(([k, v]) => (
                <div key={k} className="rounded-2xl bg-white p-2 shadow-sm">
                  <dt className="text-[11px] font-semibold text-slate-500">{t(`v3:${k}`)}</dt>
                  <dd className="font-heading text-xl font-black tabular-nums text-slate-900">{v}</dd>
                </div>
              ))}
            </dl>
          )}
          {!!state?.recent.length && (
            <ul className="divide-y divide-slate-100 rounded-2xl bg-white px-4 text-sm shadow-sm" aria-label={t('v3:puerta_ultimos')}>
              {state.recent.map((e) => (
                <li key={e.id} className="flex items-center justify-between gap-3 py-2">
                  <span className={e.kind === 'IN' ? 'font-semibold text-emerald-700' : 'font-semibold text-slate-600'}>{e.kind === 'IN' ? '+1' : '−1'}{e.wristband ? ` · ${e.wristband}` : ''}</span>
                  <span className="text-xs text-slate-500 tabular-nums">{new Date(e.at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}{e.by ? ` · ${e.by}` : ''}</span>
                </li>
              ))}
            </ul>
          )}
        </main>
      )}
    </div>
  );
};
