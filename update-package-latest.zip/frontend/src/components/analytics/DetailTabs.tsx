// ============================================
// Estadísticas · Productos, Equipo y clientes, Comparar meses
// ============================================
import { useEffect, useMemo, useState } from 'react';
import { t } from '../../i18n';
import { analyticsAPI, salesAPI } from '../../services/api';
import { Card, CardHeader, DeltaBadge, EmptyState, Segmented, Skeleton, StatusBadge } from '../ui';
import { AnimatedNumber } from '../charts/AnimatedNumber';
import { BarChart, Donut, RankList, SLICE_TONES, fmtMoneyShort } from '../charts/charts';
import { Overview, money, int, pct, delta } from './types';

// ── Productos ────────────────────────────────────────────────

export function ProductsTab({ data }: { data: Overview }) {
  const [sort, setSort] = useState<'revenue' | 'units'>('revenue');
  const k = data.kpis;
  const products = useMemo(
    () => [...data.products].sort((a, b) => (sort === 'revenue' ? b.revenue - a.revenue : b.units - a.units)).slice(0, 12),
    [data.products, sort],
  );
  if (!data.products.length) return <Card large><EmptyState title={t('stats:sin_ventas_periodo')} description={t('stats:sin_ventas_desc')} /></Card>;
  const top5 = [...data.products].sort((a, b) => b.revenue - a.revenue).slice(0, 5).reduce((a, p) => a + p.revenue, 0);
  const catTotal = data.categories.reduce((a, c) => a + c.revenue, 0);
  const catSlices = data.categories.slice(0, 6).map((c) => ({ key: c.name, label: c.name, value: c.revenue }));
  const withMargin = data.products.filter((p) => p.margin !== null);
  const bestMargin = [...withMargin].sort((a, b) => (b.margin! - a.margin!))[0];
  const worstMargin = [...withMargin].sort((a, b) => (a.margin! - b.margin!))[0];

  return (
    <div className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Card tone="inverse" large>
          <p className="text-sm font-medium text-white/80">{t('stats:productos_distintos')}</p>
          <AnimatedNumber value={data.productCount} format={int} className="mt-3 text-[2rem] font-semibold" />
          <p className="mt-2 text-xs text-white/55">{t('stats:con_ventas_en_periodo')}</p>
        </Card>
        <Card large>
          <p className="text-sm font-medium text-slate-600">{t('stats:concentracion_top5')}</p>
          <AnimatedNumber value={k.revenue ? (top5 / k.revenue) * 100 : 0} format={(v) => `${Math.round(v)}%`} className="mt-3 text-[2rem] font-semibold" />
          <p className="mt-2 text-xs text-slate-500">{t('stats:concentracion_hint')}</p>
        </Card>
        <Card large>
          <p className="text-sm font-medium text-slate-600">{t('stats:mejor_margen')}</p>
          <p className="mt-3 truncate text-xl font-semibold">{bestMargin ? bestMargin.name : '—'}</p>
          <p className="mt-2 text-xs text-slate-500">{bestMargin ? t('stats:margen_n', { pct: pct(bestMargin.margin!) }) : t('stats:carga_costos')}</p>
        </Card>
        <Card large>
          <p className="text-sm font-medium text-slate-600">{t('stats:menor_margen')}</p>
          <p className="mt-3 truncate text-xl font-semibold">{worstMargin && worstMargin !== bestMargin ? worstMargin.name : '—'}</p>
          <p className="mt-2 text-xs text-slate-500">{worstMargin && worstMargin !== bestMargin ? t('stats:margen_n', { pct: pct(worstMargin.margin!) }) : t('stats:carga_costos')}</p>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-12">
        <Card large className="lg:col-span-8">
          <CardHeader
            title={t('stats:lo_que_mas_vende')}
            hint={t('stats:top_n', { n: products.length })}
            action={<Segmented size="sm" value={sort} onChange={setSort} options={[{ id: 'revenue', label: t('stats:por_ingresos') }, { id: 'units', label: t('stats:por_unidades') }]} ariaLabel={t('stats:ordenar')} />}
          />
          <RankList
            numbered
            items={products.map((p) => ({
              key: p.productId,
              label: p.name,
              sub: p.category || undefined,
              value: sort === 'revenue' ? p.revenue : p.units,
              display: sort === 'revenue' ? money(p.revenue) : t('stats:n_unidades', { n: int(p.units) }),
              aside: (
                <span className="hidden items-center gap-2 text-xs text-slate-500 md:inline-flex">
                  {sort === 'revenue' ? t('stats:n_unidades', { n: int(p.units) }) : money(p.revenue)}
                  {p.margin !== null && <StatusBadge size="sm" dot={false} tone={p.margin >= 0.5 ? 'success' : p.margin >= 0.25 ? 'neutral' : 'warning'}>{pct(p.margin)}</StatusBadge>}
                </span>
              ),
            }))}
          />
          {k.costCoverage < 0.999 && (
            <p className="mt-4 rounded-xl bg-slate-50 px-3 py-2 text-xs text-slate-600">{t('stats:nota_costos', { pct: pct(k.costCoverage) })}</p>
          )}
        </Card>
        <Card large className="lg:col-span-4">
          <CardHeader title={t('stats:categorias')} hint={t('stats:categorias_hint')} />
          {catTotal <= 0 ? <EmptyState compact title={t('stats:sin_ventas_periodo')} /> : (
            <div className="flex flex-col items-center gap-5">
              <Donut
                slices={catSlices}
                size={180}
                center={<><span className="text-2xl font-semibold num">{pct(catSlices[0].value / catTotal)}</span><span className="max-w-[110px] truncate text-xs text-slate-500">{catSlices[0].label}</span></>}
              />
              <ul className="w-full space-y-2">
                {data.categories.slice(0, 8).map((c, i) => (
                  <li key={c.name} className="flex items-center justify-between gap-3 text-sm">
                    <span className="flex min-w-0 items-center gap-2">
                      <span className={`h-2.5 w-2.5 shrink-0 rounded-sm ${SLICE_TONES[Math.min(i, SLICE_TONES.length - 1)]}`} aria-hidden />
                      <span className="truncate text-slate-700">{c.name}</span>
                    </span>
                    <span className="shrink-0 font-medium num">{fmtMoneyShort(c.revenue)}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}

// ── Equipo, clientes y gastos ────────────────────────────────

export function PeopleTab({ data }: { data: Overview }) {
  const k = data.kpis;
  const totalExp = data.expensesByCategory.reduce((a, e) => a + e.amount, 0);
  return (
    <div className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Card tone="inverse" large>
          <p className="text-sm font-medium text-white/80">{t('stats:clientes_identificados')}</p>
          <AnimatedNumber value={k.identifiedShare * 100} format={(v) => `${Math.round(v)}%`} className="mt-3 text-[2rem] font-semibold" />
          <div className="mt-2 flex items-center gap-2 text-xs">
            <DeltaBadge value={delta(k.identifiedShare, data.prev.identifiedShare)} />
            <span className="text-white/55">{t('stats:de_las_ventas_con_cliente')}</span>
          </div>
        </Card>
        <Card large>
          <p className="text-sm font-medium text-slate-600">{t('stats:clientes_unicos')}</p>
          <AnimatedNumber value={k.uniqueCustomers} format={int} className="mt-3 text-[2rem] font-semibold" />
          <div className="mt-2 flex items-center gap-2 text-xs"><DeltaBadge value={delta(k.uniqueCustomers, data.prev.uniqueCustomers)} /><span className="text-slate-500">{t('stats:vs_periodo_anterior')}</span></div>
        </Card>
        <Card large>
          <p className="text-sm font-medium text-slate-600">{t('stats:clientes_nuevos')}</p>
          <AnimatedNumber value={data.newCustomers} format={int} className="mt-3 text-[2rem] font-semibold" />
          <p className="mt-2 text-xs text-slate-500">{t('stats:registrados_en_periodo')}</p>
        </Card>
        <Card large>
          <p className="text-sm font-medium text-slate-600">{t('stats:propinas')}</p>
          <AnimatedNumber value={k.tips} format={money} className="mt-3 text-[2rem] font-semibold" />
          <p className="mt-2 text-xs text-slate-500">{k.sales ? t('stats:por_venta_money', { amount: money(k.tips / k.sales) }) : t('stats:sin_comparacion')}</p>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-12">
        <Card large className="lg:col-span-7">
          <CardHeader title={t('stats:equipo')} hint={t('stats:equipo_hint')} />
          {!data.staff.length ? <EmptyState compact title={t('stats:sin_equipo')} description={t('stats:sin_equipo_desc')} /> : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-200 text-left text-xs text-slate-500">
                    <th className="pb-2 font-medium">{t('stats:persona')}</th>
                    <th className="pb-2 text-right font-medium">{t('stats:ventas')}</th>
                    <th className="pb-2 text-right font-medium">{t('stats:ingresos')}</th>
                    <th className="hidden pb-2 text-right font-medium sm:table-cell">{t('stats:ticket_promedio')}</th>
                    <th className="pb-2 text-right font-medium">{t('stats:propinas')}</th>
                  </tr>
                </thead>
                <tbody className="lt-stagger">
                  {data.staff.map((s, i) => {
                    const share = k.revenue ? s.revenue / k.revenue : 0;
                    return (
                      <tr key={s.name} className="border-b border-slate-100 last:border-0">
                        <td className="py-3">
                          <div className="flex items-center gap-2.5">
                            <span className={`grid h-8 w-8 shrink-0 place-items-center rounded-full text-xs font-semibold ${i === 0 ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-700'}`}>{initials(s.name)}</span>
                            <div className="min-w-0">
                              <p className="truncate font-medium text-slate-900">{s.name}</p>
                              <div className="mt-1 h-1 w-24 overflow-hidden rounded-full bg-slate-100"><div className={`h-full rounded-full ${i === 0 ? 'bg-blue-600' : 'bg-slate-700'}`} style={{ width: `${share * 100}%` }} /></div>
                            </div>
                          </div>
                        </td>
                        <td className="py-3 text-right num">{int(s.sales)}</td>
                        <td className="py-3 text-right font-medium num">{money(s.revenue)}</td>
                        <td className="hidden py-3 text-right num sm:table-cell">{money(s.avgTicket)}</td>
                        <td className="py-3 text-right num">{money(s.tips)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </Card>
        <Card large className="lg:col-span-5">
          <CardHeader title={t('stats:mejores_clientes')} hint={t('stats:mejores_clientes_hint')} />
          {!data.customers.length ? <EmptyState compact title={t('stats:sin_clientes')} description={t('stats:sin_clientes_desc')} /> : (
            <RankList numbered items={data.customers.map((c, i) => ({ key: `${c.name}-${i}`, label: c.name, value: c.revenue, display: money(c.revenue), aside: <span className="text-xs text-slate-500 num">{t('stats:n_visitas', { n: int(c.sales) })}</span> }))} />
          )}
        </Card>
      </div>

      <Card large>
        <CardHeader
          title={t('stats:gastos_por_categoria')}
          hint={totalExp > 0 && k.revenue > 0 ? t('stats:gastos_equivalen', { pct: pct(totalExp / k.revenue), amount: money(totalExp) }) : t('stats:gastos_hint')}
        />
        {!data.expensesByCategory.length ? <EmptyState compact title={t('stats:sin_gastos')} /> : (
          <RankList items={data.expensesByCategory.map((e) => ({ key: e.name, label: e.name, value: e.amount, display: money(e.amount), aside: <span className="text-xs text-slate-500 num">{pct(e.amount / totalExp)}</span> }))} />
        )}
      </Card>
    </div>
  );
}

const initials = (name: string) => name.split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0]?.toUpperCase()).join('') || '?';

// ── Comparar meses ───────────────────────────────────────────

interface MonthOpt { year: number; month: number; label: string; count: number; totalRevenue: number }
interface MonthCmp { monthKey: string; label: string; totalRevenue: number; completedCount: number; cancelledCount: number; avgTicket: number; totalItemsSold: number }

export function CompareTab() {
  const [months, setMonths] = useState<MonthOpt[] | null>(null);
  const [selected, setSelected] = useState<string[]>([]);
  const [rows, setRows] = useState<MonthCmp[] | null>(null);
  const keyOf = (m: MonthOpt) => `${m.year}-${String(m.month).padStart(2, '0')}`;

  useEffect(() => {
    salesAPI.getAvailableMonths().then((list: MonthOpt[]) => {
      const arr = Array.isArray(list) ? list : [];
      setMonths(arr);
      setSelected(arr.slice(0, 3).map(keyOf).reverse());
    }).catch(() => setMonths([]));
  }, []);

  useEffect(() => {
    if (!selected.length) { setRows([]); return; }
    let alive = true;
    setRows(null);
    analyticsAPI.compareMonths([...selected].sort()).then((r: MonthCmp[]) => { if (alive) setRows(Array.isArray(r) ? r : []); }).catch(() => { if (alive) setRows([]); });
    return () => { alive = false; };
  }, [selected]);

  const toggle = (key: string) => setSelected((s) => (s.includes(key) ? s.filter((k) => k !== key) : s.length >= 6 ? s : [...s, key]));

  if (!months) return <Skeleton className="h-[320px] rounded-[22px]" />;
  if (!months.length) return <Card large><EmptyState title={t('stats:sin_meses')} /></Card>;

  const metrics: { id: string; label: string; get: (m: MonthCmp) => number; fmt: (v: number) => string; invert?: boolean }[] = [
    { id: 'rev', label: t('stats:ingresos'), get: (m) => m.totalRevenue, fmt: money },
    { id: 'sales', label: t('stats:ventas'), get: (m) => m.completedCount, fmt: int },
    { id: 'ticket', label: t('stats:ticket_promedio'), get: (m) => m.avgTicket, fmt: money },
    { id: 'items', label: t('stats:productos_vendidos'), get: (m) => m.totalItemsSold, fmt: int },
    { id: 'void', label: t('stats:anuladas'), get: (m) => m.cancelledCount, fmt: int, invert: true },
  ];
  const best = rows && rows.length ? Math.max(...rows.map((r) => r.totalRevenue)) : 0;

  return (
    <div className="space-y-4">
      <Card large>
        <CardHeader title={t('stats:elige_meses')} hint={t('stats:elige_meses_hint')} />
        <div className="flex flex-wrap gap-2">
          {months.slice(0, 18).map((m) => {
            const key = keyOf(m);
            const on = selected.includes(key);
            return (
              <button
                key={key} type="button" onClick={() => toggle(key)} aria-pressed={on}
                className={`min-h-[40px] rounded-full px-4 text-sm font-medium transition-colors duration-fast ${on ? 'bg-slate-950 text-white' : 'bg-white text-slate-700 shadow-card hover:bg-slate-50'}`}
              >
                {m.label}
              </button>
            );
          })}
        </div>
      </Card>
      {!rows ? <Skeleton className="h-[320px] rounded-[22px]" /> : !rows.length ? null : (
        <div className="grid gap-4 lg:grid-cols-12">
          <Card large className="lg:col-span-7">
            <CardHeader title={t('stats:ingresos_por_mes')} />
            <BarChart
              height={260}
              averageLabel={t('stats:prom')}
              data={rows.map((r) => ({
                key: r.monthKey, label: r.label.split(' ')[0].slice(0, 3), value: r.totalRevenue, highlight: r.totalRevenue === best && best > 0,
                tooltip: { title: r.label, rows: [{ label: t('stats:ingresos'), value: money(r.totalRevenue), accent: true }, { label: t('stats:ventas'), value: int(r.completedCount) }] },
              }))}
            />
          </Card>
          <Card large className="lg:col-span-5">
            <CardHeader title={t('stats:mes_a_mes')} hint={t('stats:mes_a_mes_hint')} />
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-200 text-left text-xs text-slate-500">
                    <th className="pb-2 font-medium" />
                    {rows.map((r) => <th key={r.monthKey} className="pb-2 text-right font-medium">{r.label.split(' ')[0].slice(0, 3)}</th>)}
                  </tr>
                </thead>
                <tbody>
                  {metrics.map((m) => (
                    <tr key={m.id} className="border-b border-slate-100 last:border-0">
                      <td className="py-2.5 pr-2 text-slate-600">{m.label}</td>
                      {rows.map((r, i) => (
                        <td key={r.monthKey} className="py-2.5 text-right align-top">
                          <span className="font-medium num">{m.fmt(m.get(r))}</span>
                          {i > 0 && <div className="mt-1 flex justify-end"><DeltaBadge value={delta(m.get(r), m.get(rows[i - 1]))} invert={m.invert} /></div>}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}

