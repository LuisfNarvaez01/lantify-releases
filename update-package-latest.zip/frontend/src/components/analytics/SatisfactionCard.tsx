// ============================================
// Estadísticas · Satisfacción (Fase 4 · 12)
// ============================================
// Encuesta de 1 a 5 que responden los clientes al reclamar sellos en la página.
// Promedio de 7 días, promedio por semana (8 semanas) y comentarios recientes.

import { useEffect, useState } from 'react';
import { Star } from 'lucide-react';
import { t, getLocale } from '../../i18n';
import { surveysAPI } from '../../services/v3Api';
import { useFeatureFlag } from '../../shared/features';
import { Card, CardHeader, EmptyState } from '../ui';
import type { SurveySummary } from '../../../../src/domain/survey';

const tone = (avg: number | null) => (avg === null ? 'text-slate-400' : avg >= 4 ? 'text-emerald-600' : avg >= 3.5 ? 'text-amber-600' : 'text-rose-600');

export function SatisfactionCard() {
  const on = useFeatureFlag('survey');
  const [data, setData] = useState<SurveySummary | null>(null);

  useEffect(() => {
    if (!on) return;
    surveysAPI.summary().then(setData).catch(() => setData(null));
  }, [on]);

  if (!on) return null;
  const fmt = (n: number | null) => (n === null ? '—' : n.toLocaleString(getLocale(), { minimumFractionDigits: 1, maximumFractionDigits: 1 }));
  const weeks = data?.weeks ?? [];

  return (
    <Card large>
      <CardHeader title={t('stats:sat_titulo')} hint={t('stats:sat_sub')} />
      {!data || (!data.count7 && !weeks.some((w) => w.count)) ? (
        <EmptyState compact title={t('stats:sat_sin_respuestas')} description={t('stats:sat_sin_respuestas_desc')} />
      ) : (
        <div className="grid gap-6 lg:grid-cols-12">
          <div className="lg:col-span-3">
            <p className="text-sm font-medium text-slate-600">{t('stats:sat_promedio_7d')}</p>
            <p className={`mt-2 flex items-center gap-2 text-[2rem] font-semibold tabular-nums ${tone(data.avg7)}`}>
              {fmt(data.avg7)} <Star className="h-6 w-6 fill-current" aria-hidden />
            </p>
            <p className="mt-1 text-xs text-slate-500">{t('stats:sat_respuestas_n', { n: data.count7 })}</p>
          </div>
          <div className="lg:col-span-4">
            <p className="text-sm font-medium text-slate-600">{t('stats:sat_semanas')}</p>
            <ol className="mt-3 flex h-28 items-end gap-1.5" aria-label={t('stats:sat_semanas')}>
              {weeks.map((w) => (
                <li key={w.weekStart} className="flex flex-1 flex-col items-center gap-1" title={`${new Date(w.weekStart).toLocaleDateString(getLocale(), { day: 'numeric', month: 'short' })}: ${fmt(w.avg)} (${w.count})`}>
                  <span className="text-[0.6875rem] tabular-nums text-slate-500">{w.avg === null ? '' : fmt(w.avg)}</span>
                  <span className={`w-full rounded-t-md ${w.avg === null ? 'bg-slate-100' : w.avg >= 3.5 ? 'bg-blue-500' : 'bg-rose-400'}`} style={{ height: `${w.avg === null ? 4 : Math.max(8, (w.avg / 5) * 80)}px` }} />
                </li>
              ))}
            </ol>
          </div>
          <div className="lg:col-span-5">
            <p className="text-sm font-medium text-slate-600">{t('stats:sat_comentarios')}</p>
            <ul className="mt-2 max-h-56 space-y-2 overflow-y-auto">
              {data.recent.map((c) => (
                <li key={c.id} className="rounded-xl bg-slate-50 px-3 py-2">
                  <p className="text-xs text-slate-500"><b className={tone(c.score)}>{c.score}/5</b> · {c.customerName || t('stats:sat_anonimo')} · {new Date(c.at).toLocaleDateString(getLocale(), { day: 'numeric', month: 'short' })}</p>
                  <p className="text-sm text-slate-800">{c.comment}</p>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </Card>
  );
}
