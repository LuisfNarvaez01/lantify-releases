// ============================================
// Estadísticas · Resumen: cómo le fue al negocio en el período
// ============================================
import React, { useEffect, useMemo, useState } from 'react';
import { Info } from 'lucide-react';
import { t } from '../../i18n';
import { analyticsAPI } from '../../services/api';
import { Card, CardHeader, DeltaBadge, EmptyState, Segmented, Skeleton } from '../ui';
import { AnimatedNumber } from '../charts/AnimatedNumber';
import { BarChart, Donut, Gauge, Heatmap, LineChart, Sparkline, StackBar, SLICE_TONES, fmtMoneyShort } from '../charts/charts';
import {
  Overview, MonthlyRevenue, Kpis, money, int, pct, delta, fmtDay, weekdayShort, weekdayLong,
  monthShort, hourLabel, paymentLabel, channelLabel,
} from './types';

// ── Tarjeta de indicador (la primera de la fila va en negro) ──

export function KpiCard({ label, value, format, now, before, inverse = false, spark, foot, invertDelta = false }: {
  label: string;
  value: number;
  format: (v: number) => string;
  now: number;
  before: number;
  inverse?: boolean;
  spark?: number[];
  foot?: React.ReactNode;
  invertDelta?: boolean;
}) {
  return (
    <Card tone={inverse ? 'inverse' : 'default'} large className="flex min-h-[148px] flex-col justify-between">
      <div className="flex items-start justify-between gap-2">
        <p className={`text-sm font-medium ${inverse ? 'text-white/80' : 'text-slate-600'}`}>{label}</p>
        {spark && <Sparkline values={spark} tone={inverse ? 'light' : 'dark'} width={84} height={30} />}
      </div>
      <div>
        <AnimatedNumber value={value} format={format} className="text-[2rem] font-semibold tracking-tight" />
        <div className="mt-2 flex items-center gap-2 text-xs">
          <DeltaBadge value={delta(now, before)} invert={invertDelta} />
          <span className={inverse ? 'text-white/55' : 'text-slate-500'}>{foot ?? t('stats:vs_periodo_anterior')}</span>
        </div>
      </div>
    </Card>
  );
}

/** Cifra secundaria: etiqueta, valor y nota corta */
function MiniStat({ label, value, note, tone = 'default' }: { label: string; value: React.ReactNode; note?: React.ReactNode; tone?: 'default' | 'muted' }) {
  return (
    <div className="rounded-[14px] bg-white p-4 shadow-card">
      <p className="text-xs font-medium text-slate-500">{label}</p>
      <p className={`mt-1.5 text-xl font-semibold tracking-tight num ${tone === 'muted' ? 'text-slate-400' : 'text-slate-900'}`}>{value}</p>
      {note && <p className="mt-1 text-xs text-slate-500">{note}</p>}
    </div>
  );
}

// ── Frases que leen los datos (sin inventar: solo lo que muestran las cifras) ──

function insights(o: Overview): string[] {
  const out: string[] = [];
  const k = o.kpis;
  if (k.sales === 0) return out;
  if (o.range.days >= 7) {
    const best = [...o.weekday].sort((a, b) => b.avgRevenue - a.avgRevenue)[0];
    if (best && best.avgRevenue > 0) out.push(t('stats:ins_mejor_dia', { day: weekdayLong(best.day), amount: money(best.avgRevenue) }));
  }
  const peak = [...o.hourly].sort((a, b) => b.sales - a.sales)[0];
  if (peak && peak.sales > 0) out.push(t('stats:ins_hora_pico', { from: hourLabel(peak.hour), to: hourLabel((peak.hour + 1) % 24), n: int(peak.sales) }));
  const top = o.products[0];
  if (top && k.revenue > 0) out.push(t('stats:ins_top_producto', { name: top.name, share: pct(top.revenue / k.revenue) }));
  const ch = o.channels[0];
  if (ch && o.channels.length > 1 && k.revenue > 0) out.push(t('stats:ins_canal', { channel: channelLabel(ch.key), share: pct(ch.revenue / k.revenue) }));
  return out.slice(0, 3);
}

// ── Pestaña ──────────────────────────────────────────────────

export function OverviewTab({ data, loading }: { data: Overview | null; loading: boolean }) {
  const thisYear = new Date().getFullYear();
  const [year, setYear] = useState(thisYear);
  const [monthly, setMonthly] = useState<MonthlyRevenue | null>(null);

  useEffect(() => {
    let alive = true;
    setMonthly(null);
    analyticsAPI.getMonthlyRevenue(year).then((m) => { if (alive) setMonthly(m); }).catch(() => { if (alive) setMonthly({ year, months: [] }); });
    return () => { alive = false; };
  }, [year]);

  if (loading && !data) return <OverviewSkeleton />;
  if (!data) return null;

  const k = data.kpis;
  const p = data.prev;
  const single = data.range.days === 1;
  const spark = data.daily.map((d) => d.revenue);
  const hasSales = k.sales > 0;

  return (
    <div className={`space-y-4 transition-opacity duration-base ${loading ? 'opacity-60' : ''}`}>
      {/* Fila 1 · indicadores */}
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard inverse label={t('stats:ingresos')} value={k.revenue} format={money} now={k.revenue} before={p.revenue} spark={single ? undefined : spark} />
        <KpiCard label={t('stats:ventas')} value={k.sales} format={int} now={k.sales} before={p.sales} spark={single ? undefined : data.daily.map((d) => d.sales)} />
        <KpiCard label={t('stats:ticket_promedio')} value={k.avgTicket} format={money} now={k.avgTicket} before={p.avgTicket} />
        <KpiCard
          label={t('stats:productos_vendidos')} value={k.items} format={int} now={k.items} before={p.items}
          foot={hasSales ? t('stats:por_venta', { n: k.itemsPerSale.toLocaleString('es-CO', { maximumFractionDigits: 1 }) }) : undefined}
        />
      </div>

      {/* Fila 2 · ritmo + tendencia */}
      <div className="grid gap-4 lg:grid-cols-12">
        <PaceCard data={data} />
        <Card large className="lg:col-span-8">
          <CardHeader
            title={single ? t('stats:ventas_por_hora') : t('stats:dia_a_dia')}
            hint={single ? fmtDay(data.range.from, { weekday: 'long', day: 'numeric', month: 'long' }) : t('stats:linea_punteada_anterior')}
          />
          {!hasSales ? <EmptyState compact title={t('stats:sin_ventas_periodo')} description={t('stats:sin_ventas_desc')} /> : single ? (
            <BarChart
              height={240}
              showAverage={false}
              data={hoursWithSales(data).map((h) => ({
                key: String(h.hour), label: String(h.hour), value: h.revenue, highlight: h.hour === peakHour(data),
                tooltip: { title: `${hourLabel(h.hour)} – ${hourLabel((h.hour + 1) % 24)}`, rows: [{ label: t('stats:ingresos'), value: money(h.revenue), accent: true }, { label: t('stats:ventas'), value: int(h.sales) }] },
              }))}
            />
          ) : (
            <LineChart
              height={240}
              valueLabel={t('stats:este_periodo')}
              compareLabel={t('stats:periodo_anterior')}
              points={data.daily.map((d) => ({ label: fmtDay(d.date, { day: 'numeric' }), title: fmtDay(d.date, { weekday: 'short', day: 'numeric', month: 'short' }), value: d.revenue, compare: d.prevRevenue }))}
            />
          )}
        </Card>
      </div>

      {/* Fila 3 · 12 meses + medios de pago */}
      <div className="grid gap-4 lg:grid-cols-12">
        <Card large className="lg:col-span-8">
          <CardHeader
            title={t('stats:ingresos_por_mes')}
            hint={monthly ? t('stats:en_el_ano', { amount: money(monthly.months.reduce((a, m) => a + m.revenue, 0)), year: monthly.year }) : ' '}
            action={<Segmented size="sm" value={String(year)} onChange={(v) => setYear(Number(v))} options={[{ id: String(thisYear - 1), label: String(thisYear - 1) }, { id: String(thisYear), label: String(thisYear) }]} ariaLabel={t('stats:ano')} />}
          />
          {!monthly ? <Skeleton className="h-[240px] w-full" /> : (
            <BarChart
              height={240}
              averageLabel={t('stats:prom')}
              data={Array.from({ length: 12 }, (_, i) => {
                const m = monthly.months[i] || { month: i + 1, revenue: 0, sales: 0, prevRevenue: 0 };
                const d = delta(m.revenue, m.prevRevenue);
                return {
                  key: String(i), label: monthShort(i + 1), value: m.revenue, compare: m.prevRevenue,
                  highlight: year === thisYear && i === new Date().getMonth(),
                  tooltip: {
                    title: `${monthShort(i + 1)} ${monthly.year}`,
                    rows: [
                      { label: t('stats:ingresos'), value: money(m.revenue), accent: true },
                      { label: t('stats:ventas'), value: int(m.sales) },
                      ...(d !== null ? [{ label: t('stats:vs_ano_anterior'), value: `${d > 0 ? '+' : ''}${d.toFixed(1)}%` }] : []),
                    ],
                  },
                };
              })}
            />
          )}
          <p className="mt-3 flex items-center gap-1.5 text-xs text-slate-500"><span className="inline-block h-0.5 w-3 rounded-full bg-slate-400" aria-hidden /> {t('stats:marca_ano_anterior')}</p>
        </Card>
        <PaymentsCard data={data} />
      </div>

      {/* Fila 4 · mapa de calor + canales y días */}
      <div className="grid gap-4 lg:grid-cols-12">
        <Card large className="lg:col-span-8">
          <CardHeader title={t('stats:cuando_vendes')} hint={t('stats:cuando_vendes_hint')} />
          <HeatCard data={data} />
        </Card>
        <div className="space-y-4 lg:col-span-4">
          <ChannelsCard data={data} />
          {data.range.days >= 7 && hasSales && (
            <Card large>
              <CardHeader title={t('stats:promedio_por_dia')} hint={t('stats:promedio_por_dia_hint')} />
              <BarChart
                height={150}
                showAverage={false}
                data={data.weekday.map((w) => {
                  const best = Math.max(...data.weekday.map((x) => x.avgRevenue));
                  return {
                    key: String(w.day), label: weekdayShort(w.day).slice(0, 2), value: w.avgRevenue, highlight: w.avgRevenue === best && best > 0,
                    tooltip: { title: weekdayLong(w.day), rows: [{ label: t('stats:promedio'), value: money(w.avgRevenue), accent: true }, { label: t('stats:ventas'), value: int(w.sales) }] },
                  };
                })}
              />
            </Card>
          )}
        </div>
      </div>

      {/* Fila 5 · el resto del dinero */}
      <SecondaryStats k={k} p={p} />
    </div>
  );
}

const hoursWithSales = (o: Overview) => {
  const used = o.hourly.filter((h) => h.sales > 0).map((h) => h.hour);
  if (!used.length) return [];
  const from = Math.min(...used), to = Math.max(...used);
  return o.hourly.slice(from, to + 1);
};
const peakHour = (o: Overview) => [...o.hourly].sort((a, b) => b.revenue - a.revenue)[0]?.hour;

// ── Ritmo: el período contra el anterior, en el medidor negro ──

function PaceCard({ data }: { data: Overview }) {
  const now = data.kpis.revenue;
  const before = data.prev.revenue;
  const ratio = before > 0 ? now / before : null;
  const lines = insights(data);
  const status = ratio === null ? t('stats:ritmo_sin_base') : ratio >= 1.05 ? t('stats:ritmo_arriba') : ratio > 0.95 ? t('stats:ritmo_igual') : t('stats:ritmo_abajo');
  return (
    <Card tone="inverse" large className="flex flex-col lg:col-span-4">
      <CardHeader title={t('stats:ritmo')} hint={t('stats:ritmo_hint')} />
      <div className="flex flex-1 flex-col items-center justify-center py-2">
        {/* 100 % queda en dos tercios del arco: hay espacio para ver cuando se supera */}
        <Gauge
          ratio={ratio === null ? 0 : Math.min(ratio / 1.5, 1)}
          size={232}
          center={
            ratio === null ? <span className="pb-2 text-3xl font-semibold text-white/40">—</span> : (
              <div className="flex items-end gap-1.5 pb-1">
                <AnimatedNumber value={Math.round(ratio * 100)} format={(v) => `${Math.round(v)}`} className="text-5xl font-semibold tracking-tight" />
                <span className="mb-1 text-lg font-medium text-white/70">%</span>
              </div>
            )
          }
        />
        <p className="mt-1 text-xs text-white/55">{t('stats:del_periodo_anterior')}</p>
      </div>
      <div className="mt-3 border-t border-white/10 pt-3">
        <p className="text-sm font-semibold">{status}</p>
        {lines.length > 0 ? (
          <ul className="mt-1.5 space-y-1 text-xs leading-relaxed text-white/65">
            {lines.map((l) => <li key={l}>{l}</li>)}
          </ul>
        ) : <p className="mt-1.5 text-xs text-white/55">{t('stats:sin_ventas_periodo')}</p>}
      </div>
    </Card>
  );
}

// ── Medios de pago ──

function PaymentsCard({ data }: { data: Overview }) {
  const total = data.payments.reduce((a, p) => a + p.amount, 0);
  const slices = data.payments.slice(0, 6).map((p) => ({ key: p.method, label: paymentLabel(p.method), value: p.amount }));
  const top = data.payments[0];
  return (
    <Card large className="lg:col-span-4">
      <CardHeader title={t('stats:medios_de_pago')} hint={t('stats:medios_de_pago_hint')} />
      {total <= 0 ? <EmptyState compact title={t('stats:sin_pagos')} /> : (
        <div className="flex flex-col items-center gap-5 sm:flex-row lg:flex-col">
          <Donut
            slices={slices}
            center={top && (
              <>
                <span className="text-2xl font-semibold tracking-tight num">{pct(top.amount / total)}</span>
                <span className="text-xs text-slate-500">{paymentLabel(top.method)}</span>
              </>
            )}
          />
          <ul className="w-full space-y-2.5">
            {slices.map((s, i) => (
              <li key={s.key} className="flex items-center justify-between gap-3 text-sm">
                <span className="flex min-w-0 items-center gap-2">
                  <span className={`h-2.5 w-2.5 shrink-0 rounded-sm ${SLICE_TONES[Math.min(i, SLICE_TONES.length - 1)]}`} aria-hidden />
                  <span className="truncate text-slate-700">{s.label}</span>
                </span>
                <span className="shrink-0 whitespace-nowrap font-medium text-slate-900 num">{fmtMoneyShort(s.value)}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </Card>
  );
}

// ── Canales ──

function ChannelsCard({ data }: { data: Overview }) {
  const total = data.channels.reduce((a, c) => a + c.revenue, 0);
  const slices = data.channels.map((c) => ({ key: c.key, label: channelLabel(c.key), value: c.revenue }));
  return (
    <Card large>
      <CardHeader title={t('stats:canales')} hint={t('stats:canales_hint')} />
      {total <= 0 ? <EmptyState compact title={t('stats:sin_ventas_periodo')} /> : (
        <>
          <StackBar slices={slices} />
          <ul className="mt-4 space-y-2">
            {data.channels.map((c, i) => (
              <li key={c.key} className="flex items-center justify-between gap-3 text-sm">
                <span className="flex items-center gap-2">
                  <span className={`h-2.5 w-2.5 rounded-sm ${SLICE_TONES[Math.min(i, SLICE_TONES.length - 1)]}`} aria-hidden />
                  <span className="text-slate-700">{channelLabel(c.key)}</span>
                  <span className="text-xs text-slate-400 num">{int(c.sales)}</span>
                </span>
                <span className="font-medium text-slate-900 num">{pct(c.revenue / total)}</span>
              </li>
            ))}
          </ul>
        </>
      )}
    </Card>
  );
}

// ── Mapa de calor ──

function HeatCard({ data }: { data: Overview }) {
  const values = data.heatmap.sales;
  const used = useMemo(() => {
    const hrs: number[] = [];
    for (let h = 0; h < 24; h++) if (values.some((row) => row[h] > 0)) hrs.push(h);
    return hrs;
  }, [values]);
  if (!used.length) return <EmptyState compact title={t('stats:sin_ventas_periodo')} />;
  // Horas de la primera a la última con ventas (mínimo 8 columnas para que respire)
  let from = Math.min(...used), to = Math.max(...used);
  while (to - from < 7) { if (from > 0) from--; if (to - from < 7 && to < 23) to++; if (from === 0 && to === 23) break; }
  const hours = Array.from({ length: to - from + 1 }, (_, i) => from + i);
  return (
    <Heatmap
      rows={Array.from({ length: 7 }, (_, i) => weekdayShort(i))}
      cols={hours.map((h) => String(h))}
      values={values.map((row) => hours.map((h) => row[h]))}
      format={(v) => t('stats:n_ventas', { n: int(v) })}
      cellTitle={(r, c) => `${weekdayLong(r)} · ${hourLabel(hours[c])} – ${hourLabel((hours[c] + 1) % 24)}`}
    />
  );
}

// ── Cifras secundarias ──

function SecondaryStats({ k, p }: { k: Kpis; p: Kpis }) {
  const profitKnown = k.netEstimate !== null;
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
      <MiniStat label={t('stats:propinas')} value={money(k.tips)} note={<DeltaInline now={k.tips} before={p.tips} />} />
      <MiniStat label={t('stats:descuentos')} value={money(k.discounts)} note={k.revenue > 0 ? t('stats:de_las_ventas', { pct: pct(k.discounts / (k.revenue + k.discounts), 1) }) : undefined} />
      <MiniStat
        label={t('stats:anuladas')}
        value={int(k.cancelledCount)}
        tone={k.cancelledCount === 0 ? 'muted' : 'default'}
        note={k.cancelledCount === 0 ? t('stats:sin_anulaciones') : money(k.cancelledAmount)}
      />
      <MiniStat label={t('stats:gastos')} value={money(k.expenses)} note={k.revenue > 0 && k.expenses > 0 ? t('stats:de_las_ventas', { pct: pct(k.expenses / k.revenue) }) : undefined} />
      <MiniStat
        label={t('stats:utilidad_bruta')}
        value={k.grossProfit === null ? '—' : money(k.grossProfit)}
        tone={k.grossProfit === null ? 'muted' : 'default'}
        note={k.grossProfit === null ? t('stats:falta_costo', { pct: pct(k.costCoverage) }) : t('stats:margen_n', { pct: pct(k.revenue ? k.grossProfit / k.revenue : 0) })}
      />
      <MiniStat
        label={t('stats:resultado_estimado')}
        value={profitKnown ? money(k.netEstimate!) : '—'}
        tone={profitKnown ? 'default' : 'muted'}
        note={profitKnown ? (k.costCoverage < 0.999 ? t('stats:costo_parcial', { pct: pct(k.costCoverage) }) : t('stats:ventas_menos_costo_gastos')) : t('stats:ventas_menos_costo_gastos')}
      />
    </div>
  );
}

function DeltaInline({ now, before }: { now: number; before: number }) {
  const d = delta(now, before);
  if (d === null) return <span>{t('stats:sin_comparacion')}</span>;
  return <span className="inline-flex items-center gap-1.5"><DeltaBadge value={d} /> {t('stats:vs_anterior_corto')}</span>;
}

function OverviewSkeleton() {
  return (
    <div className="space-y-4" aria-busy>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-[148px] rounded-[22px]" />)}</div>
      <div className="grid gap-4 lg:grid-cols-12"><Skeleton className="h-[340px] rounded-[22px] lg:col-span-4" /><Skeleton className="h-[340px] rounded-[22px] lg:col-span-8" /></div>
      <p className="flex items-center gap-1.5 text-xs text-slate-500"><Info className="h-3.5 w-3.5" aria-hidden /> {t('stats:calculando')}</p>
    </div>
  );
}

