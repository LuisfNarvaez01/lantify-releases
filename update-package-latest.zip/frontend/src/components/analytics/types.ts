// Tipos del tablero de Estadísticas (espejo de src/domain/analyticsOverview.ts)
import { t, getLocale } from '../../i18n';
import { formatCurrency } from '../../shared/formatUtils';

export interface Kpis {
  revenue: number; sales: number; avgTicket: number; items: number; itemsPerSale: number;
  tips: number; discounts: number; cancelledCount: number; cancelledAmount: number; expenses: number;
  cogs: number; costCoverage: number; grossProfit: number | null; netEstimate: number | null;
  identifiedShare: number; uniqueCustomers: number;
}

export interface Overview {
  /** partial: el período va en curso y el anterior se comparó hasta la misma hora */
  range: { from: string; to: string; days: number; prevFrom: string; prevTo: string; partial?: boolean };
  kpis: Kpis;
  prev: Kpis;
  daily: { date: string; revenue: number; sales: number; prevRevenue: number }[];
  heatmap: { sales: number[][]; revenue: number[][] };
  hourly: { hour: number; revenue: number; sales: number }[];
  weekday: { day: number; avgRevenue: number; revenue: number; sales: number }[];
  payments: { method: string; amount: number; count: number }[];
  channels: { key: string; revenue: number; sales: number }[];
  /** Productos distintos vendidos (la lista `products` trae solo los 20 primeros) */
  productCount: number;
  products: { productId: string; name: string; category: string | null; units: number; revenue: number; cost: number | null; margin: number | null }[];
  categories: { name: string; revenue: number; units: number }[];
  staff: { name: string; sales: number; revenue: number; tips: number; avgTicket: number }[];
  customers: { name: string; sales: number; revenue: number }[];
  expensesByCategory: { name: string; amount: number }[];
  newCustomers: number;
}

export interface MonthlyRevenue { year: number; months: { month: number; revenue: number; sales: number; prevRevenue: number }[] }

export const money = (v: number) => formatCurrency(v);
export const int = (v: number) => Math.round(v).toLocaleString('es-CO');
export const pct = (v: number, digits = 0) => `${(v * 100).toLocaleString('es-CO', { maximumFractionDigits: digits })}%`;

/** Variación en % contra el período anterior; null si no hay base para comparar */
export const delta = (now: number, before: number) => (before > 0 ? ((now - before) / before) * 100 : null);

export const parseKey = (key: string) => {
  const [y, m, d] = key.split('-').map(Number);
  return new Date(y, m - 1, d);
};

export const fmtDay = (key: string, opts: Intl.DateTimeFormatOptions = { day: 'numeric', month: 'short' }) =>
  parseKey(key).toLocaleDateString(getLocale(), opts).replace('.', '');

export const fmtRange = (from: string, to: string) =>
  from === to ? fmtDay(from, { weekday: 'short', day: 'numeric', month: 'short' }) : `${fmtDay(from)} – ${fmtDay(to)}`;

/** Nombre corto del día de la semana (0 = lunes) */
export const weekdayShort = (i: number) => {
  const base = new Date(2026, 10, 9 + i); // 9 nov 2026 es lunes
  return base.toLocaleDateString(getLocale(), { weekday: 'short' }).replace('.', '');
};
export const weekdayLong = (i: number) => new Date(2026, 10, 9 + i).toLocaleDateString(getLocale(), { weekday: 'long' });

export const monthShort = (m: number) => new Date(2026, m - 1, 1).toLocaleDateString(getLocale(), { month: 'short' }).replace('.', '');

export const hourLabel = (h: number) => `${String(h).padStart(2, '0')}:00`;

const PAY_KEYS: Record<string, string> = {
  CASH: 'stats:pago_efectivo', CARD: 'stats:pago_tarjeta', TRANSFER: 'stats:pago_transferencia',
  NEQUI: 'stats:pago_nequi', DAVIPLATA: 'stats:pago_daviplata', MIXED: 'stats:pago_mixto', RAPPI_PAY: 'stats:pago_rappi',
};
export const paymentLabel = (m: string) => (PAY_KEYS[m] ? t(PAY_KEYS[m]) : m.charAt(0) + m.slice(1).toLowerCase());

const CHANNEL_KEYS: Record<string, string> = {
  TABLE: 'stats:canal_mesas', COUNTER: 'stats:canal_mostrador', WEB: 'stats:canal_web', RAPPI: 'stats:canal_rappi', WHATSAPP: 'stats:canal_whatsapp',
};
export const channelLabel = (k: string) => (CHANNEL_KEYS[k] ? t(CHANNEL_KEYS[k]) : k);
