// ============================================
// Estadísticas: el tablero del negocio
// ============================================
// Un período (Hoy, 7 días, Este mes...) contra el anterior de igual duración.
// Pestañas: Resumen · Productos · Equipo y clientes · Comparar meses.
// Datos: GET /analytics/overview (src/domain/analyticsOverview.ts).

import { useCallback, useEffect, useState } from 'react';
import { RefreshCw } from 'lucide-react';
import { t } from '../../i18n';
import { analyticsAPI } from '../../services/api';
import { Card, EmptyState, Segmented } from '../ui';
import { OverviewTab } from './OverviewTab';
import { SatisfactionCard } from './SatisfactionCard';
import { CompareTab, PeopleTab, ProductsTab } from './DetailTabs';
import { PeriodId, periodRange, dateKey } from './period';
import { Overview, fmtRange } from './types';

type Tab = 'overview' | 'products' | 'people' | 'compare';
const PERIOD_KEY = 'lantify.stats.period';

const readPeriod = (): PeriodId => {
  try {
    const v = localStorage.getItem(PERIOD_KEY) as PeriodId | null;
    return v && v !== 'custom' ? v : '7d';
  } catch { return '7d'; }
};

export function StatsModule() {
  const [tab, setTab] = useState<Tab>('overview');
  const [period, setPeriod] = useState<PeriodId>(readPeriod);
  const [custom, setCustom] = useState(() => periodRange('30d'));
  const [data, setData] = useState<Overview | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const range = period === 'custom' ? custom : periodRange(period);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setData(await analyticsAPI.getOverview(range.from, range.to));
    } catch (e: any) {
      setError(e?.message || t('stats:error_cargar'));
    } finally {
      setLoading(false);
    }
  }, [range.from, range.to]);

  useEffect(() => { load(); }, [load]);

  const pickPeriod = (p: PeriodId) => {
    setPeriod(p);
    if (p !== 'custom') { try { localStorage.setItem(PERIOD_KEY, p); } catch { /* sin almacenamiento */ } }
  };

  const today = dateKey(new Date());

  return (
    <div className="mx-auto max-w-[1440px] space-y-5 pb-12">
      {/* Encabezado */}
      <header className="flex flex-col gap-4 xl:flex-row xl:items-end xl:justify-between">
        <div>
          <h1 className="text-[1.75rem] font-semibold tracking-tight text-slate-950">{t('stats:titulo')}</h1>
          <p className="mt-1 text-sm text-slate-500">
            {data ? t(data.range.partial ? 'stats:rango_vs_hora' : 'stats:rango_vs', { range: fmtRange(data.range.from, data.range.to), prev: fmtRange(data.range.prevFrom, data.range.prevTo) }) : t('stats:subtitulo')}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Segmented
            size="sm"
            value={period}
            onChange={pickPeriod}
            ariaLabel={t('stats:periodo')}
            options={[
              { id: 'today', label: t('stats:p_hoy') },
              { id: 'yesterday', label: t('stats:p_ayer') },
              { id: '7d', label: t('stats:p_7d') },
              { id: '30d', label: t('stats:p_30d') },
              { id: 'month', label: t('stats:p_mes') },
              { id: 'lastMonth', label: t('stats:p_mes_pasado') },
              { id: 'year', label: t('stats:p_ano') },
              { id: 'custom', label: t('stats:p_personalizado') },
            ]}
          />
          <button
            type="button" onClick={load} disabled={loading}
            className="inline-flex h-9 w-9 items-center justify-center rounded-full bg-white text-slate-700 shadow-card hover:bg-slate-50 disabled:opacity-50"
            aria-label={t('stats:actualizar')} title={t('stats:actualizar')}
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} aria-hidden />
          </button>
        </div>
      </header>

      {period === 'custom' && (
        <div className="lt-enter flex flex-wrap items-end gap-3 rounded-[14px] bg-white p-3 shadow-card">
          <label className="text-xs font-medium text-slate-600">
            {t('stats:desde')}
            <input type="date" value={custom.from} max={custom.to} onChange={(e) => e.target.value && setCustom((c) => ({ ...c, from: e.target.value }))}
              className="mt-1 block h-10 rounded-[10px] border border-slate-200 bg-slate-50 px-3 text-sm text-slate-900" />
          </label>
          <label className="text-xs font-medium text-slate-600">
            {t('stats:hasta')}
            <input type="date" value={custom.to} min={custom.from} max={today} onChange={(e) => e.target.value && setCustom((c) => ({ ...c, to: e.target.value }))}
              className="mt-1 block h-10 rounded-[10px] border border-slate-200 bg-slate-50 px-3 text-sm text-slate-900" />
          </label>
          <p className="pb-2.5 text-xs text-slate-500">{t('stats:max_un_ano')}</p>
        </div>
      )}

      {/* Pestañas */}
      <Segmented
        value={tab}
        onChange={setTab}
        ariaLabel={t('stats:secciones')}
        options={[
          { id: 'overview', label: t('stats:tab_resumen') },
          { id: 'products', label: t('stats:tab_productos') },
          { id: 'people', label: t('stats:tab_personas') },
          { id: 'compare', label: t('stats:tab_comparar') },
        ]}
      />

      {error && tab !== 'compare' ? (
        <Card large><EmptyState title={t('stats:error_cargar')} description={error} action={<button type="button" onClick={load} className="h-10 rounded-[10px] bg-slate-950 px-4 text-sm font-medium text-white hover:bg-slate-800">{t('stats:reintentar')}</button>} /></Card>
      ) : (
        <div key={tab} className="lt-fade">
          {tab === 'overview' && <OverviewTab data={data} loading={loading} />}
          {tab === 'products' && data && <ProductsTab data={data} />}
          {tab === 'people' && data && <div className="space-y-4"><SatisfactionCard /><PeopleTab data={data} /></div>}
          {tab === 'compare' && <CompareTab />}
        </div>
      )}
    </div>
  );
}

export default StatsModule;
