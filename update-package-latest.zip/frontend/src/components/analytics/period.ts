// Períodos rápidos del tablero (Hoy, Ayer, 7 días...). Todo en fecha local.
export type PeriodId = 'today' | 'yesterday' | '7d' | '30d' | 'month' | 'lastMonth' | 'year' | 'custom';

export const dateKey = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

const day = (y: number, m: number, d: number) => new Date(y, m, d);

export function periodRange(id: Exclude<PeriodId, 'custom'>, now = new Date()): { from: string; to: string } {
  const y = now.getFullYear(), m = now.getMonth(), d = now.getDate();
  switch (id) {
    case 'today': return { from: dateKey(now), to: dateKey(now) };
    case 'yesterday': { const k = dateKey(day(y, m, d - 1)); return { from: k, to: k }; }
    case '7d': return { from: dateKey(day(y, m, d - 6)), to: dateKey(now) };
    case '30d': return { from: dateKey(day(y, m, d - 29)), to: dateKey(now) };
    case 'month': return { from: dateKey(day(y, m, 1)), to: dateKey(now) };
    case 'lastMonth': return { from: dateKey(day(y, m - 1, 1)), to: dateKey(day(y, m, 0)) };
    case 'year': return { from: dateKey(day(y, 0, 1)), to: dateKey(now) };
  }
}
