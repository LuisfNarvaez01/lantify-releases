import { Languages } from 'lucide-react';
import { LANGUAGES, useLanguage } from '../../i18n';
import { t } from '../../i18n';

interface LanguageSelectorProps {
  /** cards: Configuración · compact: menú de usuario · pill: pantalla de inicio de sesión */
  variant?: 'cards' | 'compact' | 'pill';
}

/** Selector de idioma de la interfaz. La preferencia es por usuario. */
export function LanguageSelector({ variant = 'cards' }: LanguageSelectorProps) {
  const { language, setLanguage } = useLanguage();

  if (variant === 'pill') {
    return (
      <div role="radiogroup" aria-label={t('common:idioma')} className="inline-flex items-center gap-1 p-1 rounded-full bg-white/10 border border-white/10">
        <Languages className="w-3.5 h-3.5 text-slate-400 ml-1.5" aria-hidden />
        {LANGUAGES.map(lang => (
          <button
            key={lang.id}
            type="button"
            role="radio"
            aria-checked={language === lang.id}
            aria-label={lang.label}
            onClick={() => setLanguage(lang.id)}
            className={`px-2.5 py-1 rounded-full text-xs font-bold uppercase transition-colors ${
              language === lang.id ? 'bg-white text-slate-900' : 'text-slate-300 hover:text-white'
            }`}
          >
            {lang.id}
          </button>
        ))}
      </div>
    );
  }

  if (variant === 'compact') {
    return (
      <div role="radiogroup" aria-label={t('common:idioma')} className="grid grid-cols-2 gap-1 p-1 rounded-xl bg-slate-950/60 border border-slate-800/80">
        {LANGUAGES.map(lang => (
          <button
            key={lang.id}
            type="button"
            role="radio"
            aria-checked={language === lang.id}
            onClick={() => setLanguage(lang.id)}
            className={`min-h-[36px] rounded-lg text-xs font-bold transition-colors ${
              language === lang.id ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            {lang.label}
          </button>
        ))}
      </div>
    );
  }

  return (
    <div role="radiogroup" aria-label={t('common:idioma')} className="grid grid-cols-1 sm:grid-cols-2 gap-3">
      {LANGUAGES.map(lang => {
        const active = language === lang.id;
        return (
          <button
            key={lang.id}
            type="button"
            role="radio"
            aria-checked={active}
            onClick={() => setLanguage(lang.id)}
            className={`text-left p-4 rounded-2xl border-2 transition-all flex items-center gap-3 ${
              active ? 'border-blue-600 bg-blue-50' : 'border-slate-200 bg-white hover:border-slate-300'
            }`}
          >
            <span className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 text-xs font-black uppercase ${active ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600'}`}>
              {lang.id}
            </span>
            <span className="text-sm font-bold text-slate-900">{lang.label}</span>
          </button>
        );
      })}
    </div>
  );
}
