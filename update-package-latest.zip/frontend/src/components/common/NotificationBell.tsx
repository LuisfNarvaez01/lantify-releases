// ============================================
// COMPONENTS - Campanita: historial de avisos
// ============================================
// Arriba en la barra. Muestra cuántos avisos no se han visto y, al abrirla, la
// lista de los últimos días (los más nuevos primero).

import React, { useEffect, useRef, useState } from 'react';
import { Award, Bell, CalendarDays, Cake, ChefHat, Gift, Radar, ReceiptText, ShoppingBag, TimerReset, UserPlus } from 'lucide-react';
import { useNotificationLog, useUnreadCount, type LogIcon } from '../../shared/notificationLog';
import { t, getLocale } from '../../i18n';

export const LOG_ICONS: Record<LogIcon, React.ElementType> = {
  order: ShoppingBag,
  reservation: CalendarDays,
  customer: UserPlus,
  prize: Gift,
  card: Award,
  birthday: Cake,
  kitchen: ChefHat,
  bill: ReceiptText,
  alert: TimerReset,
  autopilot: Radar,
};

const whenOf = (at: number) => {
  const d = new Date(at);
  const today = new Date();
  const sameDay = d.toDateString() === today.toDateString();
  return sameDay
    ? d.toLocaleTimeString(getLocale(), { hour: '2-digit', minute: '2-digit' })
    : d.toLocaleString(getLocale(), { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
};

export const NotificationBell: React.FC<{ dark?: boolean }> = ({ dark = false }) => {
  const [open, setOpen] = useState(false);
  const entries = useNotificationLog((s) => s.entries);
  const markAllRead = useNotificationLog((s) => s.markAllRead);
  const clear = useNotificationLog((s) => s.clear);
  const unread = useUnreadCount();
  const box = useRef<HTMLDivElement>(null);

  // Al abrirla, lo que se ve queda como leído
  useEffect(() => {
    if (!open) return;
    const timer = window.setTimeout(markAllRead, 1200);
    const onDown = (e: PointerEvent) => { if (box.current && !box.current.contains(e.target as Node)) setOpen(false); };
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('pointerdown', onDown);
    document.addEventListener('keydown', onKey);
    return () => {
      window.clearTimeout(timer);
      document.removeEventListener('pointerdown', onDown);
      document.removeEventListener('keydown', onKey);
    };
  }, [open, markAllRead]);

  const button = dark
    ? 'w-12 h-12 text-white hover:bg-white/10'
    : 'w-10 h-10 text-slate-600 hover:text-slate-900 hover:bg-slate-100';

  return (
    <div ref={box} className="relative shrink-0">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        aria-label={unread ? t('notifications:campana_sin_leer', { count: unread }) : t('notifications:campana')}
        title={t('notifications:campana')}
        className={`relative rounded-xl inline-flex items-center justify-center transition-colors ${button}`}
      >
        <Bell className="w-5 h-5" aria-hidden />
        {unread > 0 && (
          <span className="absolute top-1 right-1 min-w-[1.125rem] h-[1.125rem] px-1 rounded-full bg-rose-600 text-white text-[0.625rem] font-black leading-[1.125rem] text-center tabular-nums">
            {unread > 99 ? '99+' : unread}
          </span>
        )}
      </button>

      {open && (
        <div
          role="dialog"
          aria-label={t('notifications:campana')}
          className="fixed sm:absolute z-50 inset-x-2 sm:inset-x-auto top-16 sm:top-auto sm:right-0 sm:mt-2 sm:w-[24rem] bg-white text-slate-900 border border-slate-200 rounded-2xl shadow-2xl overflow-hidden"
        >
          <header className="flex items-center justify-between gap-2 px-4 py-3 border-b border-slate-100">
            <h2 className="text-sm font-bold font-heading">{t('notifications:campana')}</h2>
            {entries.length > 0 && (
              <button type="button" onClick={clear} className="text-xs font-semibold text-slate-500 hover:text-slate-900">
                {t('notifications:borrar_historial')}
              </button>
            )}
          </header>
          <ul className="max-h-[min(28rem,70vh)] overflow-y-auto overscroll-contain divide-y divide-slate-100">
            {entries.length === 0 && (
              <li className="px-4 py-10 text-center text-sm text-slate-500">{t('notifications:sin_avisos')}</li>
            )}
            {entries.map((e) => {
              const Icon = LOG_ICONS[e.icon] || Bell;
              return (
                <li key={e.id} className={`flex gap-3 px-4 py-3 ${e.read ? '' : 'bg-blue-50/60'}`}>
                  <span className={`${e.tone} w-9 h-9 shrink-0 rounded-xl flex items-center justify-center text-white`}>
                    <Icon className="w-4 h-4" aria-hidden />
                  </span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-baseline justify-between gap-2">
                      <p className="text-sm font-semibold leading-snug">{e.title}</p>
                      <time className="shrink-0 text-[0.6875rem] text-slate-500 tabular-nums">{whenOf(e.at)}</time>
                    </div>
                    {e.message && <p className="text-xs text-slate-600 mt-0.5 leading-relaxed break-words">{e.message}</p>}
                  </div>
                </li>
              );
            })}
          </ul>
        </div>
      )}
    </div>
  );
};
