// ============================================
// COMPONENTS - Toast Container UI
// ============================================

import React, { useState, useEffect } from 'react';
import { toast, ToastItem } from '../../shared/toast';
import { CheckCircle2, AlertCircle, AlertTriangle, Info, X } from 'lucide-react';

export const ToastContainer: React.FC = () => {
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  useEffect(() => {
    return toast.subscribe((updated) => {
      setToasts(updated);
    });
  }, []);

  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-5 right-5 z-50 flex flex-col gap-2.5 max-w-sm w-full pointer-events-none select-none">
      {toasts.map((t) => {
        const isSuccess = t.type === 'success';
        const isError = t.type === 'error';
        const isWarning = t.type === 'warning';

        return (
          <div
            key={t.id}
            className={`
              pointer-events-auto flex items-start gap-3 p-3.5 rounded-2xl border shadow-xl backdrop-blur-md transition-all duration-200 animate-in slide-in-from-top-4 fade-in-50
              ${isSuccess ? 'bg-emerald-950/95 text-emerald-100 border-emerald-500/40 shadow-emerald-950/30' : ''}
              ${isError ? 'bg-rose-950/95 text-rose-100 border-rose-500/40 shadow-rose-950/30' : ''}
              ${isWarning ? 'bg-amber-950/95 text-amber-100 border-amber-500/40 shadow-amber-950/30' : ''}
              ${t.type === 'info' ? 'bg-slate-900/95 text-slate-100 border-slate-700 shadow-slate-950/30' : ''}
            `}
          >
            <div className="shrink-0 mt-0.5">
              {isSuccess && <CheckCircle2 className="w-5 h-5 text-emerald-400" />}
              {isError && <AlertCircle className="w-5 h-5 text-rose-400" />}
              {isWarning && <AlertTriangle className="w-5 h-5 text-amber-400" />}
              {t.type === 'info' && <Info className="w-5 h-5 text-blue-400" />}
            </div>

            <div className="flex-1 min-w-0 pr-1">
              {t.title && (
                <h5 className="font-bold text-xs leading-snug mb-0.5 font-heading">
                  {t.title}
                </h5>
              )}
              <p className="text-xs font-medium opacity-90 leading-relaxed break-words">
                {t.message}
              </p>
            </div>

            <button
              onClick={() => toast.dismiss(t.id)}
              className="shrink-0 p-1 rounded-lg opacity-70 hover:opacity-100 transition-opacity"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        );
      })}
    </div>
  );
};

export default ToastContainer;
