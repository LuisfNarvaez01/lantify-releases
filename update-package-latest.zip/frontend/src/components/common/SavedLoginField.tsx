// ============================================
// COMMON - Campo de usuario con los ingresos guardados
// ============================================
// Al tocar el campo se despliegan, debajo, los usuarios guardados en este equipo (como
// el autocompletar del navegador). Se filtran mientras se escribe, se eligen con el mouse
// o con las flechas y Enter, y cada uno se puede olvidar con la X.

import { useEffect, useId, useMemo, useRef, useState } from 'react';
import { KeyRound, X } from 'lucide-react';
import type { SavedLogin } from '../../shared/savedLogins';
import { t } from '../../i18n';

const fold = (s: string) => s.normalize('NFD').replace(/\p{M}/gu, '').toLowerCase();

export function SavedLoginField({ id, value, onChange, saved, onPick, onForget, className, autoFocus }: {
  id: string;
  value: string;
  onChange: (v: string) => void;
  saved: SavedLogin[];
  onPick: (login: SavedLogin) => void;
  onForget: (login: SavedLogin) => void;
  className: string;
  autoFocus?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(-1);
  const wrapRef = useRef<HTMLDivElement>(null);
  // El foco automático al abrir la pantalla no despliega la lista (taparía la contraseña)
  const skipAutoFocus = useRef(!!autoFocus);
  const listId = useId();

  const options = useMemo(() => {
    const q = fold(value.trim());
    // Si lo escrito ya es exactamente un usuario guardado, se muestran todos (para cambiar de usuario)
    if (!q || saved.some((l) => l.username === value.trim().toLowerCase())) return saved;
    return saved.filter((l) => fold(l.username).includes(q) || fold(l.name).includes(q));
  }, [saved, value]);

  const visible = open && options.length > 0;

  useEffect(() => {
    setActive(-1);
  }, [value, open]);

  useEffect(() => {
    if (!visible) return;
    const onDown = (e: MouseEvent) => {
      if (!wrapRef.current?.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', onDown);
    return () => document.removeEventListener('mousedown', onDown);
  }, [visible]);

  const pick = (login: SavedLogin) => {
    setOpen(false);
    onPick(login);
  };

  const onKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (!open) setOpen(true);
      setActive((i) => (options.length ? (i + 1) % options.length : -1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setActive((i) => (options.length ? (i <= 0 ? options.length - 1 : i - 1) : -1));
    } else if (e.key === 'Enter' && visible && active >= 0) {
      e.preventDefault();
      pick(options[active]);
    } else if (e.key === 'Escape' && visible) {
      e.preventDefault();
      e.stopPropagation();
      setOpen(false);
    } else if (e.key === 'Tab') {
      setOpen(false);
    }
  };

  return (
    <div ref={wrapRef} className="relative">
      <input
        id={id}
        type="text"
        value={value}
        onChange={(e) => {
          onChange(e.target.value);
          setOpen(true);
        }}
        onFocus={() => {
          if (skipAutoFocus.current) skipAutoFocus.current = false;
          else setOpen(true);
        }}
        onClick={() => setOpen(true)}
        onKeyDown={onKeyDown}
        className={className}
        autoComplete="username"
        autoCapitalize="none"
        spellCheck={false}
        autoFocus={autoFocus}
        required
        role="combobox"
        aria-autocomplete="list"
        aria-expanded={visible}
        aria-controls={listId}
        aria-activedescendant={visible && active >= 0 ? `${listId}-${active}` : undefined}
      />
      {visible && (
        <ul
          id={listId}
          role="listbox"
          aria-label={t('auth:ingresos_guardados')}
          className="absolute left-0 right-0 top-full mt-1.5 z-30 max-h-72 overflow-y-auto rounded-xl border border-slate-200 bg-white py-1 shadow-xl shadow-slate-900/10"
        >
          {options.map((login, i) => (
            <li
              key={login.username}
              id={`${listId}-${i}`}
              role="option"
              aria-selected={i === active}
              // mousedown: elegir antes de que el campo pierda el foco
              onMouseDown={(e) => {
                e.preventDefault();
                pick(login);
              }}
              onMouseEnter={() => setActive(i)}
              className={`group flex items-center gap-3 px-3 py-2 cursor-pointer ${i === active ? 'bg-blue-50' : ''}`}
            >
              <span aria-hidden className="w-8 h-8 shrink-0 rounded-full bg-slate-900 text-white grid place-items-center text-xs font-bold">
                {(login.name || login.username).charAt(0).toUpperCase()}
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-sm font-semibold text-slate-900 truncate">{login.name || login.username}</span>
                <span className="flex items-center gap-1 text-xs text-slate-500 truncate">
                  {login.username}
                  {login.hasPassword && <KeyRound className="w-3 h-3 shrink-0" aria-label={t('auth:con_contrasena')} />}
                </span>
              </span>
              <button
                type="button"
                tabIndex={-1}
                onMouseDown={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  onForget(login);
                }}
                aria-label={t('auth:olvidar_usuario', { name: login.name || login.username })}
                title={t('auth:olvidar')}
                className="shrink-0 p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50"
              >
                <X className="w-4 h-4" aria-hidden />
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
