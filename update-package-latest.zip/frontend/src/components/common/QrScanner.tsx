// ============================================
// Escáner de QR con la cámara del celular
// ============================================
// En la caja: lee el QR de la tarjeta de sellos del cliente (wallet o página). Usa el lector del
// navegador (BarcodeDetector) cuando existe y jsQR en los demás (iPhone, por ejemplo).

import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { X, CameraOff } from 'lucide-react';
import jsQR from 'jsqr';

interface Props {
  title: string;
  hint: string;
  deniedText: string;
  closeLabel: string;
  onResult: (text: string) => void;
  onClose: () => void;
}

export function QrScanner({ title, hint, deniedText, closeLabel, onResult, onClose }: Props) {
  const video = useRef<HTMLVideoElement>(null);
  const [denied, setDenied] = useState(false);
  const done = useRef(false);
  // La cámara se abre una sola vez aunque el padre vuelva a dibujarse
  const report = useRef(onResult);
  report.current = onResult;

  useEffect(() => {
    let stream: MediaStream | null = null;
    let frame = 0;
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    const Detector = (window as any).BarcodeDetector;
    const detector = Detector ? new Detector({ formats: ['qr_code'] }) : null;

    const found = (text: string) => {
      if (done.current || !text) return;
      done.current = true;
      navigator.vibrate?.(60);
      report.current(text);
    };

    const scan = async () => {
      const v = video.current;
      if (!v || done.current) return;
      if (v.readyState >= 2 && v.videoWidth) {
        try {
          if (detector) {
            const codes = await detector.detect(v);
            if (codes[0]?.rawValue) return found(codes[0].rawValue);
          } else if (ctx) {
            // Se lee una versión reducida: suficiente para un QR y liviano en celulares
            const scale = Math.min(1, 640 / v.videoWidth);
            canvas.width = Math.round(v.videoWidth * scale);
            canvas.height = Math.round(v.videoHeight * scale);
            ctx.drawImage(v, 0, 0, canvas.width, canvas.height);
            const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
            const code = jsQR(img.data, img.width, img.height, { inversionAttempts: 'dontInvert' });
            if (code?.data) return found(code.data);
          }
        } catch {
          // un cuadro ilegible: se intenta con el siguiente
        }
      }
      frame = requestAnimationFrame(scan);
    };

    navigator.mediaDevices
      ?.getUserMedia({ video: { facingMode: 'environment' }, audio: false })
      .then((s) => {
        stream = s;
        if (!video.current) return;
        video.current.srcObject = s;
        video.current.play().catch(() => {});
        frame = requestAnimationFrame(scan);
      })
      .catch(() => setDenied(true));
    if (!navigator.mediaDevices?.getUserMedia) setDenied(true);

    return () => {
      cancelAnimationFrame(frame);
      stream?.getTracks().forEach((t) => t.stop());
    };
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [onClose]);

  return createPortal(
    <div role="dialog" aria-modal="true" aria-label={title} className="fixed inset-0 z-[200] flex flex-col bg-black text-white">
      <div className="flex items-center justify-between px-4 py-3">
        <p className="font-bold">{title}</p>
        <button type="button" onClick={onClose} aria-label={closeLabel} className="grid h-11 w-11 place-items-center rounded-full bg-white/10 hover:bg-white/20">
          <X className="h-5 w-5" aria-hidden />
        </button>
      </div>
      <div className="relative flex-1 overflow-hidden">
        {denied ? (
          <div className="grid h-full place-items-center p-8 text-center">
            <div>
              <CameraOff className="mx-auto h-10 w-10 text-white/60" aria-hidden />
              <p className="mt-4 text-sm text-white/80">{deniedText}</p>
            </div>
          </div>
        ) : (
          <>
            <video ref={video} playsInline muted className="h-full w-full object-cover" />
            {/* Marco de enfoque */}
            <div aria-hidden className="pointer-events-none absolute inset-0 grid place-items-center">
              <div className="relative h-64 w-64 rounded-3xl shadow-[0_0_0_100vmax_rgb(0_0_0/0.55)]">
                {['left-0 top-0 border-l-4 border-t-4 rounded-tl-3xl', 'right-0 top-0 border-r-4 border-t-4 rounded-tr-3xl', 'left-0 bottom-0 border-l-4 border-b-4 rounded-bl-3xl', 'right-0 bottom-0 border-r-4 border-b-4 rounded-br-3xl'].map((c) => (
                  <span key={c} className={`absolute h-10 w-10 border-white ${c}`} />
                ))}
                <span className="absolute inset-x-4 top-1/2 h-0.5 bg-white/70 motion-safe:animate-pulse" />
              </div>
            </div>
          </>
        )}
      </div>
      <p className="px-6 py-5 text-center text-sm text-white/80">{hint}</p>
    </div>,
    document.body,
  );
}
