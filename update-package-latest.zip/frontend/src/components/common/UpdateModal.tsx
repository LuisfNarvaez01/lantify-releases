// ============================================
// COMPONENTS - Update Notification Modal (Post-Login) - Lantify POS
// ============================================

import React, { useState } from 'react';
import { API_URL } from '../../config';
import {
  Sparkles, ShieldCheck, CheckCircle2, Wrench,
  ArrowRight, Download, X, AlertCircle, RefreshCw,
  Database
} from 'lucide-react';

import { t } from '../../i18n';
interface UpdateData {
  updateAvailable: boolean;
  currentVersion: string;
  latestVersion: string;
  releaseName?: string;
  changelog?: string;
  features?: string[];
  fixes?: string[];
  buildDate?: string;
}

interface UpdateModalProps {
  updateData: UpdateData;
  onClose: () => void;
}

export const UpdateModal: React.FC<UpdateModalProps> = ({ updateData, onClose }) => {
  const [isApplying, setIsApplying] = useState(false);
  const [applyResult, setApplyResult] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleApplyUpdate = async () => {
    setIsApplying(true);
    setErrorMessage(null);

    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`${API_URL}/version/apply-update`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        }
      });

      const data = await res.json();
      if (res.ok) {
        setApplyResult(data.message || t('layout:el_asistente_de_actualizacion_segura_se_ha'));
      } else {
        setErrorMessage(data.error || t('layout:no_se_pudo_iniciar_el_actualizador'));
      }
    } catch (err: any) {
      setErrorMessage(err.message || t('layout:error_de_conexion_al_solicitar_actualizacion'));
    } finally {
      setIsApplying(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-md flex items-center justify-center z-[150] p-4 animate-in fade-in duration-200 font-sans">
      <div className="bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl border border-slate-200 flex flex-col max-h-[90vh]">
        
        {/* Header con diseño Slate Obsidian */}
        <div className="bg-slate-900 p-6 text-white relative border-b border-slate-800">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-400 shrink-0">
                <Sparkles className="w-6 h-6 animate-pulse" />
              </div>
              <div>
                <span className="text-xs font-bold uppercase tracking-[0.2em] text-blue-400">
                  {t('layout:actualizacion_de_software_disponible')}
                </span>
                <h3 className="font-extrabold text-xl text-white font-heading">
                  {updateData.releaseName || t('layout:nueva_version_de_lantify_pos')}
                </h3>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors"
              title={t('layout:posponer')}
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Versión Badge Comparativo */}
          <div className="mt-4 flex items-center gap-3 bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-xs font-bold w-fit">
            <span className="text-slate-400 font-mono">{t('layout:actual_v')}{updateData.currentVersion}</span>
            <ArrowRight className="w-4 h-4 text-blue-400" />
            <span className="text-emerald-300 font-mono bg-emerald-950/60 px-2.5 py-0.5 rounded-lg border border-emerald-500/30">
              {t('layout:disponible_value', { value: updateData.latestVersion.startsWith('v') ? updateData.latestVersion : `v${updateData.latestVersion}` })}
            </span>
          </div>
        </div>

        {/* Contenido scrolleable */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 custom-scrollbar">
          {/* Alerta de Éxito al lanzar actualizador */}
          {applyResult ? (
            <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-6 text-emerald-900 space-y-3">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-7 h-7 text-emerald-600 shrink-0" />
                <h4 className="font-extrabold text-base">{t('layout:actualizador_iniciado')}</h4>
              </div>
              <p className="text-xs text-emerald-800 leading-relaxed font-medium">
                {applyResult}
              </p>
              <div className="p-3 bg-white/80 rounded-xl text-xs text-emerald-700 font-bold flex items-center gap-2">
                <Database className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{t('layout:la_base_de_datos_local_se_respalda')}</span>
              </div>
            </div>
          ) : (
            <>
              {/* Resumen del changelog */}
              {updateData.changelog && (
                <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200">
                  <p className="text-xs font-medium text-slate-700 leading-relaxed">
                    {updateData.changelog}
                  </p>
                </div>
              )}

              {/* Novedades */}
              {updateData.features && updateData.features.length > 0 && (
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-700">
                    <Sparkles className="w-4 h-4 text-blue-600" />
                    <span>{t('layout:novedades_del_sistema')}</span>
                  </div>
                  <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs space-y-2">
                    {updateData.features.map((feat, idx) => (
                      <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-700 font-medium">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Correcciones de errores */}
              {updateData.fixes && updateData.fixes.length > 0 && (
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-700">
                    <Wrench className="w-4 h-4 text-blue-600" />
                    <span>{t('layout:correcciones_y_estabilidad')}</span>
                  </div>
                  <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs space-y-2">
                    {updateData.fixes.map((fix, idx) => (
                      <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-700 font-medium">
                        <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                        <span>{fix}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Garantía de Seguridad de Datos */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 flex items-start gap-3">
                <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <h5 className="font-bold text-xs text-slate-800">
                    {t('layout:seguridad_y_respaldo_de_base_de_datos')}
                  </h5>
                  <p className="text-xs text-slate-600 leading-relaxed font-medium">
                    {t('layout:tus_ventas_dinero_en_caja_clientes_y')}{' '}<code className="bg-white px-1.5 py-0.5 rounded text-blue-600 border border-slate-200 font-bold">backups/</code>{' '}{t('layout:antes_de_aplicar_cualquier_cambio')}
                  </p>
                </div>
              </div>

              {/* Mensaje de error si falla */}
              {errorMessage && (
                <div className="bg-red-50 border border-red-200 rounded-2xl p-4 flex items-center gap-3 text-xs text-red-700 font-bold">
                  <AlertCircle className="w-5 h-5 shrink-0 text-red-600" />
                  <span>{errorMessage}</span>
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer con acciones */}
        <div className="p-5 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
          <button
            onClick={onClose}
            className="w-full sm:w-auto px-5 py-2.5 rounded-xl text-slate-600 hover:text-slate-900 font-bold text-xs transition-colors"
          >
            {applyResult ? t('layout:cerrar_ventana') : t('layout:recordarmelo_mas_tarde')}
          </button>

          {!applyResult && (
            <button
              onClick={handleApplyUpdate}
              disabled={isApplying}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-bold text-white text-xs bg-blue-600 hover:bg-blue-700 active:bg-blue-800 shadow-md shadow-blue-500/25 transition-all disabled:opacity-50"
            >
              {isApplying ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>{t('layout:iniciando_actualizador')}</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  <span>{t('layout:aplicar_actualizacion_ahora')}</span>
                </>
              )}
            </button>
          )}
        </div>

      </div>
    </div>
  );
};

export default UpdateModal;
