// ============================================
// COMMON - Botón "Generar informe": elegir PDF o Excel
// ============================================
// El informe se arma al elegir el formato (puede traer datos del servidor) y sale
// igual en los dos: PDF para imprimir o compartir, Excel para analizar.

import { useState } from 'react';
import { FileText, FileSpreadsheet, ChevronDown, Loader2, FileBarChart } from 'lucide-react';
import { Popover } from './Popover';
import { exportReport, ReportDoc, ReportFormat } from '../../services/reportDocument';
import { toast } from '../../shared/toast';
import { t } from '../../i18n';

interface Props {
  /** Arma el informe (puede ser asíncrono) */
  build: () => ReportDoc | Promise<ReportDoc>;
  fileName?: string;
  label?: string;
  disabled?: boolean;
  /** Botón más pequeño (filas de una lista) */
  compact?: boolean;
  align?: 'left' | 'right';
}

export function ReportButton({ build, fileName, label, disabled, compact, align = 'right' }: Props) {
  const [busy, setBusy] = useState<ReportFormat | null>(null);

  const run = async (format: ReportFormat, close: () => void) => {
    close();
    setBusy(format);
    try {
      exportReport(await build(), format, fileName);
    } catch (e: any) {
      toast.error(e?.message || t('reports:no_se_genero'));
    } finally {
      setBusy(null);
    }
  };

  const option = (format: ReportFormat, close: () => void) => {
    const Icon = format === 'pdf' ? FileText : FileSpreadsheet;
    return (
      <button
        type="button"
        role="menuitem"
        onClick={() => run(format, close)}
        className="w-full flex items-start gap-3 px-3 py-2.5 rounded-xl text-left hover:bg-slate-50 focus-visible:outline-none focus-visible:bg-slate-100"
      >
        <span className={`mt-0.5 w-8 h-8 rounded-lg grid place-items-center shrink-0 ${format === 'pdf' ? 'bg-rose-50 text-rose-600' : 'bg-emerald-50 text-emerald-700'}`}>
          <Icon className="w-4 h-4" aria-hidden />
        </span>
        <span>
          <span className="block text-sm font-bold text-slate-900">{t(`reports:formato_${format}`)}</span>
          <span className="block text-xs text-slate-500">{t(`reports:formato_${format}_desc`)}</span>
        </span>
      </button>
    );
  };

  return (
    <Popover
      align={align}
      disabled={disabled || !!busy}
      triggerLabel={label || t('reports:generar_informe')}
      triggerClassName={`inline-flex items-center justify-center gap-2 font-bold text-white bg-slate-900 hover:bg-slate-800 shadow-sm transition-all active:scale-[0.98] disabled:opacity-50 ${
        compact ? 'px-3 py-2 rounded-xl text-xs' : 'px-5 py-3 rounded-xl text-sm'
      }`}
      trigger={
        <>
          {busy ? <Loader2 className="w-4 h-4 animate-spin" aria-hidden /> : <FileBarChart className="w-4 h-4" aria-hidden />}
          <span>{busy ? t('reports:generando') : label || t('reports:generar_informe')}</span>
          <ChevronDown className="w-4 h-4 opacity-70" aria-hidden />
        </>
      }
      panelClassName="w-72 p-2"
    >
      {(close) => (
        <div role="menu">
          {option('pdf', close)}
          {option('xlsx', close)}
        </div>
      )}
    </Popover>
  );
}
