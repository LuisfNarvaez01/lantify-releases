import { Sun, Moon, Monitor } from 'lucide-react';
import { ThemeMode, useThemeMode } from '../../shared/theme/themeMode';

import { t } from '../../i18n';
const OPTIONS: { id: ThemeMode; label: string; short: string; description: string; icon: typeof Sun }[] = [
  { id: 'light', get label() { return t('common:claro'); }, get short() { return t('common:claro'); }, get description() { return t('common:ideal_para_locales_con_mucha_luz'); }, icon: Sun },
  { id: 'dark', get label() { return t('common:oscuro'); }, get short() { return t('common:oscuro'); }, get description() { return t('common:descansa_la_vista_en_bares_y_turnos'); }, icon: Moon },
  { id: 'system', get label() { return t('common:automatico'); }, get short() { return t('common:auto'); }, get description() { return t('common:sigue_la_configuracion_de_windows'); }, icon: Monitor },
];

interface ThemeModeSelectorProps {
  /** cards: tarjetas grandes (Configuración) · compact: control segmentado (menú de usuario) */
  variant?: 'cards' | 'compact';
}

/** Selector de tema claro / oscuro / automático. La preferencia es por usuario. */
export function ThemeModeSelector({ variant = 'cards' }: ThemeModeSelectorProps) {
  const { mode, setMode } = useThemeMode();

  if (variant === 'compact') {
    return (
      <div role="radiogroup" aria-label={t('common:tema_de_la_pantalla')} className="grid grid-cols-3 gap-1 p-1 rounded-xl bg-slate-950/60 border border-slate-800/80">
        {OPTIONS.map(({ id, label, short, icon: Icon }) => {
          const active = mode === id;
          return (
            <button
              key={id}
              type="button"
              role="radio"
              aria-checked={active}
              aria-label={label}
              title={label}
              onClick={() => setMode(id)}
              className={`flex flex-col items-center justify-center gap-0.5 min-h-[44px] py-1 rounded-lg text-xs font-bold transition-colors ${
                active ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Icon className="w-4 h-4" aria-hidden />
              {short}
            </button>
          );
        })}
      </div>
    );
  }

  return (
    <div role="radiogroup" aria-label={t('common:tema_de_la_pantalla')} className="grid grid-cols-1 sm:grid-cols-3 gap-3">
      {OPTIONS.map(({ id, label, description, icon: Icon }) => {
        const active = mode === id;
        return (
          <button
            key={id}
            type="button"
            role="radio"
            aria-checked={active}
            onClick={() => setMode(id)}
            className={`text-left p-4 rounded-2xl border-2 transition-all flex items-start gap-3 ${
              active ? 'border-blue-600 bg-blue-50' : 'border-slate-200 bg-white hover:border-slate-300'
            }`}
          >
            <span className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${active ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600'}`}>
              <Icon className="w-5 h-5" aria-hidden />
            </span>
            <span>
              <span className="block text-sm font-bold text-slate-900">{label}</span>
              <span className="block text-xs text-slate-500 mt-0.5">{description}</span>
            </span>
          </button>
        );
      })}
    </div>
  );
}
