// ============================================
// COMMON - Guía de imagen (el "?" junto a cada lugar donde se sube una foto)
// ============================================
// Dice qué formato y tamaño subir según dónde se use: producto, logo o portada.

import { HelpCircle } from 'lucide-react';
import { Popover } from './Popover';
import { IMAGE_SPECS, ImageKind } from '../../shared/media';
import { t } from '../../i18n';

export function ImageGuide({ kind, align = 'left' }: { kind: ImageKind; align?: 'left' | 'right' }) {
  const spec = IMAGE_SPECS[kind];
  const rows: [string, string][] = [
    [t('media:guia_formato'), t(`media:guia_formato_${kind}`)],
    [t('media:guia_tamano'), t('media:guia_tamano_valor', { w: spec.width, h: spec.height, min: spec.minSide })],
    [t('media:guia_forma'), t(`media:guia_forma_${kind}`)],
    [t('media:guia_peso'), t('media:guia_peso_valor')],
  ];
  return (
    <Popover
      align={align}
      triggerLabel={t('media:guia_titulo', { what: t(`media:tipo_${kind}`) })}
      triggerClassName="inline-flex h-7 w-7 items-center justify-center rounded-full text-slate-400 hover:text-blue-600 hover:bg-blue-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500/40"
      trigger={<HelpCircle className="w-4 h-4" aria-hidden />}
      panelClassName="w-80 max-w-[calc(100vw-2rem)] p-4"
    >
      {() => (
        <div className="space-y-3 text-left">
          <p className="text-sm font-bold text-slate-900">{t('media:guia_titulo', { what: t(`media:tipo_${kind}`) })}</p>
          <dl className="space-y-2">
            {rows.map(([k, v]) => (
              <div key={k} className="grid grid-cols-[5.5rem_1fr] gap-2 text-xs">
                <dt className="font-semibold text-slate-500">{k}</dt>
                <dd className="text-slate-800">{v}</dd>
              </div>
            ))}
          </dl>
          <p className="text-xs text-slate-600 leading-relaxed border-t border-slate-100 pt-3">{t(`media:guia_consejo_${kind}`)}</p>
        </div>
      )}
    </Popover>
  );
}
