// ============================================
// COMMON - Ajustar la carátula de una foto
// ============================================
// Se arrastra la foto dentro del marco y se acerca con el control. Lo que queda en
// el marco es exactamente lo que se guarda (y lo que se ve en la caja y la página).

import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { X, ZoomIn, ZoomOut, RotateCcw, Loader2 } from 'lucide-react';
import { CENTERED, Framing, IMAGE_SPECS, ImageKind, sourceRect, toMonoBitmap } from '../../shared/media';
import { t } from '../../i18n';

interface Props {
  img: HTMLImageElement;
  kind: ImageKind;
  title?: string;
  busy?: boolean;
  onCancel: () => void;
  onConfirm: (framing: Framing) => void;
}

const clamp = (v: number, min: number, max: number) => Math.max(min, Math.min(max, v));

export function ImageCropper({ img, kind, title, busy, onCancel, onConfirm }: Props) {
  const spec = IMAGE_SPECS[kind];
  const [f, setF] = useState<Framing>(CENTERED);
  const canvas = useRef<HTMLCanvasElement>(null);
  const drag = useRef<{ x: number; y: number; f: Framing } | null>(null);
  const [ticket, setTicket] = useState<string | null>(null);
  const small = Math.min(img.naturalWidth, img.naturalHeight) < spec.minSide;
  const displayW = spec.aspect >= 1.5 ? 480 : 320;
  const displayH = Math.round(displayW / spec.aspect);

  useEffect(() => {
    const c = canvas.current;
    if (!c) return;
    const dpr = window.devicePixelRatio || 1;
    c.width = displayW * dpr;
    c.height = displayH * dpr;
    const ctx = c.getContext('2d')!;
    const { sx, sy, sw, sh } = sourceRect(img.naturalWidth, img.naturalHeight, spec.aspect, f);
    ctx.clearRect(0, 0, c.width, c.height);
    ctx.drawImage(img, sx, sy, sw, sh, 0, 0, c.width, c.height);
    // El logo también sale en el ticket: se muestra cómo queda en blanco y negro
    if (kind === 'logo') {
      const id = window.setTimeout(() => setTicket(toMonoBitmap(c, 192).src), 120);
      return () => window.clearTimeout(id);
    }
  }, [f, img, kind, spec.aspect, displayW, displayH]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && !busy && onCancel();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [busy, onCancel]);

  const move = (dxPx: number, dyPx: number, from: Framing) => {
    const { sw, sh } = sourceRect(img.naturalWidth, img.naturalHeight, spec.aspect, from);
    const spareX = img.naturalWidth - sw;
    const spareY = img.naturalHeight - sh;
    const perPx = sw / displayW;
    setF({
      ...from,
      x: spareX > 0 ? clamp(from.x - (dxPx * perPx * 2) / spareX, -1, 1) : 0,
      y: spareY > 0 ? clamp(from.y - (dyPx * perPx * 2) / spareY, -1, 1) : 0,
    });
  };

  const onKeyMove = (e: React.KeyboardEvent) => {
    const step = e.shiftKey ? 40 : 10;
    const d: Record<string, [number, number]> = { ArrowLeft: [step, 0], ArrowRight: [-step, 0], ArrowUp: [0, step], ArrowDown: [0, -step] };
    if (d[e.key]) {
      e.preventDefault();
      move(d[e.key][0], d[e.key][1], f);
    } else if (e.key === '+' || e.key === '=') setF({ ...f, zoom: clamp(f.zoom + 0.1, 1, 4) });
    else if (e.key === '-') setF({ ...f, zoom: clamp(f.zoom - 0.1, 1, 4) });
  };

  return createPortal(
    <div className="fixed inset-0 z-[200] flex items-center justify-center bg-slate-950/70 backdrop-blur-sm p-4" role="dialog" aria-modal="true" aria-labelledby="cropper-title">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-xl max-h-[calc(100dvh-2rem)] flex flex-col overflow-hidden border border-slate-200">
        <div className="flex items-center justify-between gap-3 px-6 py-4 border-b border-slate-100">
          <div>
            <h3 id="cropper-title" className="text-base font-bold text-slate-900">{title || t('media:ajustar_titulo')}</h3>
            <p className="text-xs text-slate-500">{t(`media:ajustar_ayuda_${kind}`)}</p>
          </div>
          <button type="button" onClick={onCancel} disabled={busy} aria-label={t('media:cancelar')} className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="overflow-y-auto px-6 py-5 space-y-4">
          <div className="flex flex-col sm:flex-row items-center gap-5 justify-center">
            <canvas
              ref={canvas}
              tabIndex={0}
              aria-label={t('media:marco_aria')}
              onKeyDown={onKeyMove}
              onPointerDown={(e) => {
                (e.target as HTMLElement).setPointerCapture(e.pointerId);
                drag.current = { x: e.clientX, y: e.clientY, f };
              }}
              onPointerMove={(e) => drag.current && move(e.clientX - drag.current.x, e.clientY - drag.current.y, drag.current.f)}
              onPointerUp={() => (drag.current = null)}
              onWheel={(e) => setF((p) => ({ ...p, zoom: clamp(p.zoom - e.deltaY / 600, 1, 4) }))}
              style={{ width: displayW, height: displayH, maxWidth: '100%', aspectRatio: String(spec.aspect) }}
              className={`touch-none cursor-grab active:cursor-grabbing bg-[repeating-conic-gradient(#e2e8f0_0_25%,#fff_0_50%)] [background-size:16px_16px] shadow-inner ring-1 ring-slate-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${kind === 'product' ? 'rounded-2xl' : kind === 'logo' ? 'rounded-xl' : 'rounded-lg'}`}
            />
            {kind === 'logo' && (
              <div className="text-center shrink-0">
                <p className="text-xs font-semibold text-slate-500 mb-2">{t('media:asi_en_ticket')}</p>
                <div className="bg-white border border-dashed border-slate-300 rounded-lg p-3 w-32 h-32 grid place-items-center">
                  {ticket && <img src={ticket} alt="" className="max-w-full max-h-full [image-rendering:pixelated]" />}
                </div>
              </div>
            )}
          </div>

          <div className="flex items-center gap-3">
            <ZoomOut className="w-4 h-4 text-slate-400 shrink-0" aria-hidden />
            <input
              type="range"
              min={1}
              max={4}
              step={0.01}
              value={f.zoom}
              onChange={(e) => setF({ ...f, zoom: Number(e.target.value) })}
              aria-label={t('media:acercar')}
              className="flex-1 accent-blue-600"
            />
            <ZoomIn className="w-4 h-4 text-slate-400 shrink-0" aria-hidden />
            <button type="button" onClick={() => setF(CENTERED)} className="ml-1 inline-flex items-center gap-1 text-xs font-semibold text-slate-600 hover:text-blue-700 px-2 py-1 rounded-lg hover:bg-slate-100">
              <RotateCcw className="w-3.5 h-3.5" aria-hidden /> {t('media:centrar')}
            </button>
          </div>

          {small && (
            <p role="status" className="text-xs font-medium text-amber-800 bg-amber-50 border border-amber-200 rounded-xl px-3 py-2">
              {t('media:aviso_pequena', { w: img.naturalWidth, h: img.naturalHeight, min: spec.minSide })}
            </p>
          )}
        </div>

        <div className="flex gap-3 px-6 py-4 border-t border-slate-100 bg-slate-50/60">
          <button type="button" onClick={onCancel} disabled={busy} className="flex-1 px-4 py-3 rounded-xl border border-slate-300 bg-white text-sm font-bold text-slate-700 hover:bg-slate-50">
            {t('media:cancelar')}
          </button>
          <button type="button" onClick={() => onConfirm(f)} disabled={busy} className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-blue-600 text-sm font-bold text-white hover:bg-blue-700 disabled:opacity-60">
            {busy && <Loader2 className="w-4 h-4 animate-spin" aria-hidden />}
            {busy ? t('media:guardando') : t('media:usar_foto')}
          </button>
        </div>
      </div>
    </div>,
    document.body,
  );
}
