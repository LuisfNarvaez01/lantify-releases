// ============================================
// COMMON - Tamaño de la letra de todo el sistema
// ============================================
// Todo el sistema mide en rem: cambiar el tamaño de la letra raíz agranda (o
// achica) textos, botones y espacios a la vez. La preferencia es de este equipo
// (cada caja o tablet elige la suya) y se guarda al instante.

import { useEffect, useState } from 'react';
import { Minus, Plus, RotateCcw } from 'lucide-react';
import { DEFAULT_THEME, FONT_SIZE_MAX, FONT_SIZE_MIN, getSavedTheme, saveTheme } from '../../shared/themeManager';
import { t } from '../../i18n';

const px = (v: string) => parseFloat(v) || 14;
export const FONT_SIZE_EVENT = 'lantify:font-size';

export function useFontSize() {
  const [size, setSize] = useState(() => px(getSavedTheme().fontScale));
  useEffect(() => {
    const on = () => setSize(px(getSavedTheme().fontScale));
    window.addEventListener(FONT_SIZE_EVENT, on);
    return () => window.removeEventListener(FONT_SIZE_EVENT, on);
  }, []);
  const change = (next: number) => {
    const v = Math.min(FONT_SIZE_MAX, Math.max(FONT_SIZE_MIN, Math.round(next)));
    saveTheme({ fontScale: `${v}px` });
    setSize(v);
    window.dispatchEvent(new Event(FONT_SIZE_EVENT));
  };
  return { size, change };
}

/** A− / tamaño / A+ (menú de usuario) */
export function FontSizeControl({ dark = true }: { dark?: boolean }) {
  const { size, change } = useFontSize();
  const base = px(DEFAULT_THEME.fontScale);
  const pct = Math.round((size / base) * 100);
  const btn = `grid h-11 w-11 place-items-center rounded-lg font-black transition-colors disabled:opacity-30 ${dark ? 'text-slate-300 hover:bg-slate-800 hover:text-white' : 'text-slate-700 hover:bg-slate-100'}`;
  return (
    <div className={`flex items-center gap-1 rounded-xl p-1 ${dark ? 'border border-slate-800/80 bg-slate-950/60' : 'border border-slate-200 bg-white'}`} role="group" aria-label={t('common:tamano_letra')}>
      <button type="button" className={btn} onClick={() => change(size - 1)} disabled={size <= FONT_SIZE_MIN} aria-label={t('common:letra_mas_pequena')} title={t('common:letra_mas_pequena')}>
        <span aria-hidden className="flex items-center text-xs">A<Minus className="h-3 w-3" /></span>
      </button>
      <button type="button" onClick={() => change(base)} title={t('common:letra_normal')} aria-label={t('common:letra_actual', { pct })}
        className={`flex min-h-[44px] flex-1 items-center justify-center gap-1 rounded-lg text-xs font-bold tabular-nums ${dark ? 'text-white hover:bg-slate-800' : 'text-slate-900 hover:bg-slate-100'}`}>
        {pct}%{size !== base && <RotateCcw className="h-3 w-3 opacity-60" aria-hidden />}
      </button>
      <button type="button" className={btn} onClick={() => change(size + 1)} disabled={size >= FONT_SIZE_MAX} aria-label={t('common:letra_mas_grande')} title={t('common:letra_mas_grande')}>
        <span aria-hidden className="flex items-center text-base">A<Plus className="h-3.5 w-3.5" /></span>
      </button>
    </div>
  );
}
