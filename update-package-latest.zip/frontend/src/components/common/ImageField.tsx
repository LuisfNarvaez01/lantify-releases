// ============================================
// COMMON - Campo de imagen: subir, ajustar la carátula, cambiar o quitar
// ============================================
// La foto es opcional. Se puede elegir un archivo o arrastrarlo encima; antes de
// guardar se abre el ajuste del encuadre.

import { useRef, useState } from 'react';
import { ImagePlus, Crop, Trash2, Loader2, ImageOff } from 'lucide-react';
import { ImageCropper } from './ImageCropper';
import { ImageGuide } from './ImageGuide';
import { ACCEPTED_IMAGE_TYPES, Framing, ImageFileError, ImageKind, IMAGE_SPECS, loadImage, mediaSrc, readImageFile, uploadImage } from '../../shared/media';
import { toast } from '../../shared/toast';
import { t } from '../../i18n';

interface Props {
  kind: ImageKind;
  value: string | null | undefined;
  onChange: (url: string | null) => void | Promise<void>;
  label: string;
  hint?: string;
  /** Texto del botón para quitar (p. ej. "Usar el logo del negocio") */
  removeLabel?: string;
  /** Mostrar "Quitar" (p. ej. no, si lo que se ve es el logo del negocio) */
  canRemove?: boolean;
  disabled?: boolean;
  id?: string;
}

export const imageErrorText = (e: unknown) => {
  if (e instanceof ImageFileError) return t(`media:error_${e.code.toLowerCase()}`);
  return (e as Error)?.message || t('media:error_subir');
};

export function ImageField({ kind, value, onChange, label, hint, removeLabel, canRemove = true, disabled, id }: Props) {
  const input = useRef<HTMLInputElement>(null);
  const [editing, setEditing] = useState<{ img: HTMLImageElement; revoke?: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [over, setOver] = useState(false);
  const [broken, setBroken] = useState(false);
  const spec = IMAGE_SPECS[kind];
  const fieldId = id || `image-${kind}`;

  const open = async (file: File | undefined) => {
    if (!file) return;
    try {
      const { img, url } = await readImageFile(file);
      setEditing({ img, revoke: url });
    } catch (e) {
      toast.error(imageErrorText(e));
    }
  };

  const reframe = async () => {
    if (!value) return;
    try {
      setEditing({ img: await loadImage(mediaSrc(value)!) });
    } catch {
      toast.error(t('media:error_read'));
    }
  };

  const close = () => {
    if (editing?.revoke) URL.revokeObjectURL(editing.revoke);
    setEditing(null);
  };

  const save = async (f: Framing) => {
    if (!editing) return;
    setBusy(true);
    try {
      const url = await uploadImage(editing.img, kind, f);
      await onChange(url);
      setBroken(false);
      close();
    } catch (e) {
      toast.error(imageErrorText(e));
    } finally {
      setBusy(false);
    }
  };

  const frame = kind === 'cover' ? 'w-40 aspect-video rounded-lg' : kind === 'logo' ? 'w-20 h-20 rounded-xl' : 'w-24 h-24 rounded-2xl';

  return (
    <div className="space-y-1.5">
      <div className="flex items-center gap-1">
        <label htmlFor={fieldId} className="text-sm font-semibold text-slate-700 ml-1">{label}</label>
        <span className="text-xs text-slate-400">· {t('media:opcional')}</span>
        <ImageGuide kind={kind} />
      </div>
      <div
        onDragOver={(e) => {
          if (disabled) return;
          e.preventDefault();
          setOver(true);
        }}
        onDragLeave={() => setOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setOver(false);
          if (!disabled) open(e.dataTransfer.files?.[0]);
        }}
        className={`flex items-center gap-4 p-3 rounded-2xl border-2 border-dashed transition-colors ${over ? 'border-blue-500 bg-blue-50/60' : 'border-slate-200 bg-slate-50/50'}`}
      >
        <div className={`${frame} shrink-0 overflow-hidden bg-white border border-slate-200 grid place-items-center ${kind === 'logo' ? 'bg-[repeating-conic-gradient(#f1f5f9_0_25%,#fff_0_50%)] [background-size:12px_12px]' : ''}`}>
          {value && !broken ? (
            <img src={mediaSrc(value)} alt="" onError={() => setBroken(true)} className={`w-full h-full ${kind === 'logo' ? 'object-contain' : 'object-cover'}`} />
          ) : value && broken ? (
            <ImageOff className="w-6 h-6 text-slate-300" aria-label={t('media:no_carga')} />
          ) : (
            <ImagePlus className="w-7 h-7 text-slate-300" aria-hidden />
          )}
        </div>
        <div className="min-w-0 flex-1 space-y-2">
          <p className="text-xs text-slate-500 leading-snug">
            {hint || t('media:hint_generico', { w: spec.width, h: spec.height })}
          </p>
          <div className="flex flex-wrap gap-2">
            <input
              ref={input}
              id={fieldId}
              type="file"
              accept={ACCEPTED_IMAGE_TYPES}
              className="sr-only"
              disabled={disabled || busy}
              onChange={(e) => {
                open(e.target.files?.[0]);
                e.target.value = '';
              }}
            />
            <button
              type="button"
              disabled={disabled || busy}
              onClick={() => input.current?.click()}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-blue-600 text-white text-xs font-bold hover:bg-blue-700 disabled:opacity-60"
            >
              {busy ? <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden /> : <ImagePlus className="w-3.5 h-3.5" aria-hidden />}
              {value ? t('media:cambiar') : t('media:subir')}
            </button>
            {value && !broken && value.startsWith('/api/') && (
              <button type="button" disabled={disabled || busy} onClick={reframe} className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-300 bg-white text-slate-700 text-xs font-bold hover:bg-slate-50">
                <Crop className="w-3.5 h-3.5" aria-hidden /> {t('media:ajustar')}
              </button>
            )}
            {value && canRemove && (
              <button type="button" disabled={disabled || busy} onClick={() => onChange(null)} className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-rose-600 text-xs font-bold hover:bg-rose-50">
                <Trash2 className="w-3.5 h-3.5" aria-hidden /> {removeLabel || t('media:quitar')}
              </button>
            )}
          </div>
        </div>
      </div>
      {editing && <ImageCropper img={editing.img} kind={kind} busy={busy} onCancel={close} onConfirm={save} />}
    </div>
  );
}
