// ============================================
// COMPONENTS - Función fuera del plan (candado + plan que la incluye)
// ============================================

import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { Lock, X, Clock, ArrowUpRight, PlayCircle, CheckCircle2 } from 'lucide-react';
import { FEATURE_PLAN, PLAN_PRICE, PLAN_LOCK_EVENT, PlanCode } from '../../shared/plan';
import { formatCurrency } from '../../shared/formatUtils';
import i18next, { t } from '../../i18n';

const isAdmin = () => {
  try {
    return JSON.parse(localStorage.getItem('user') || '{}')?.role === 'ADMIN';
  } catch {
    return false;
  }
};

/** Candado pequeño para pestañas y botones */
export function LockBadge({ className = '' }: { className?: string }) {
  return <Lock className={`w-3.5 h-3.5 shrink-0 opacity-70 ${className}`} aria-label={t('plan:no_incluido')} />;
}

interface PlanLockedProps {
  feature: string;
  /** Dentro de un modal o un panel pequeño */
  compact?: boolean;
  /** La función aún no está terminada: se anuncia como próxima */
  soon?: boolean;
  /** Mostrar u ocultar la demostración de la función (si tiene una) */
  onDemo?: () => void;
  demoOpen?: boolean;
}

const PRICING_URL = 'https://lantifypos.dpdns.org/precios';

/**
 * Promoción de una función fuera del plan: qué hace, qué gana el negocio, en qué
 * plan está y cuánto cuesta. Nunca desaparece sin explicación.
 */
export function PlanLocked({ feature, compact = false, soon = false, onDemo, demoOpen = false }: PlanLockedProps) {
  const plan: PlanCode = FEATURE_PLAN[feature] || 'pro';
  const benefits = [1, 2, 3].map((n) => `plan:f_${feature}_b${n}`).filter((k) => i18next.exists(k));
  const admin = isAdmin();
  return (
    <section
      className={`${compact ? '' : 'max-w-3xl mx-auto my-8 bg-surface border border-line rounded-3xl shadow-sm overflow-hidden'} text-left`}
      aria-labelledby={`plan-lock-${feature}`}
    >
      <div className={`${compact ? 'p-6' : 'p-6 sm:p-8'} grid gap-6 ${benefits.length && !compact ? 'sm:grid-cols-[1.2fr_1fr]' : ''}`}>
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-primary-soft px-3 py-1 text-xs font-bold text-primary-text">
              <Lock className="w-3.5 h-3.5" aria-hidden />
              {t('plan:disponible_en', { plan: t(`plan:plan_${plan}`) })}
            </span>
            {soon && (
              <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-100 px-3 py-1 text-xs font-bold text-amber-800">
                <Clock className="w-3.5 h-3.5" aria-hidden /> {t('plan:proximamente')}
              </span>
            )}
          </div>
          <h2 id={`plan-lock-${feature}`} className="mt-3 text-2xl font-bold text-fg font-heading">
            {t(`plan:f_${feature}`)}
          </h2>
          <p className="mt-2 text-sm text-fg-secondary leading-relaxed">{t(`plan:f_${feature}_desc`)}</p>
          <p className="mt-4 text-lg font-bold text-fg tabular-nums">
            {t('plan:desde_al_mes', { price: formatCurrency(PLAN_PRICE[plan]) })}
          </p>
          <div className="mt-4 flex flex-wrap gap-2">
            {admin && (
              <a
                href={PRICING_URL}
                target="_blank"
                rel="noreferrer"
                className="inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-primary px-5 text-sm font-semibold text-white hover:bg-primary-hover"
              >
                {t('plan:ver_planes')} <ArrowUpRight className="w-4 h-4" aria-hidden />
              </a>
            )}
            {onDemo && (
              <button
                type="button"
                onClick={onDemo}
                aria-expanded={demoOpen}
                className="inline-flex min-h-[44px] items-center gap-2 rounded-xl border border-line px-5 text-sm font-semibold text-fg hover:bg-surface-muted"
              >
                <PlayCircle className="w-4 h-4" aria-hidden /> {demoOpen ? t('plan:ocultar_demo') : t('plan:ver_demo')}
              </button>
            )}
          </div>
          <p className="mt-4 text-xs text-fg-muted leading-relaxed">
            {admin ? t('plan:como_cambiar') : t('plan:pidele_al_admin')}
          </p>
        </div>
        {benefits.length > 0 && !compact && (
          <ul className="self-center space-y-3 rounded-2xl bg-surface-muted p-5">
            {benefits.map((k) => (
              <li key={k} className="flex gap-2.5 text-sm text-fg">
                <CheckCircle2 className="mt-0.5 w-4 h-4 shrink-0 text-primary-text" aria-hidden />
                <span>{t(k)}</span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </section>
  );
}

/** Modal global: cualquier pantalla puede pedirlo con showPlanLock('dian') */
export function PlanLockHost() {
  const [feature, setFeature] = useState<string | null>(null);

  useEffect(() => {
    const open = (e: Event) => setFeature((e as CustomEvent<{ feature: string }>).detail?.feature || null);
    window.addEventListener(PLAN_LOCK_EVENT, open);
    return () => window.removeEventListener(PLAN_LOCK_EVENT, open);
  }, []);

  useEffect(() => {
    if (!feature) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setFeature(null);
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [feature]);

  if (!feature) return null;
  return createPortal(
    <div className="fixed inset-0 z-[90] flex items-center justify-center p-4 bg-black/50" onClick={() => setFeature(null)}>
      <div
        role="dialog"
        aria-modal="true"
        className="relative w-full max-w-md bg-surface border border-line rounded-2xl shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          type="button"
          onClick={() => setFeature(null)}
          className="absolute top-3 right-3 p-2 rounded-lg text-fg-muted hover:text-fg hover:bg-surface-muted"
          aria-label={t('plan:cerrar')}
        >
          <X className="w-4 h-4" />
        </button>
        <PlanLocked feature={feature} compact />
        <div className="px-6 pb-6">
          <button
            type="button"
            onClick={() => setFeature(null)}
            className="w-full min-h-[42px] rounded-lg bg-primary hover:bg-primary-hover text-white text-sm font-semibold"
          >
            {t('plan:entendido')}
          </button>
        </div>
      </div>
    </div>,
    document.body,
  );
}
