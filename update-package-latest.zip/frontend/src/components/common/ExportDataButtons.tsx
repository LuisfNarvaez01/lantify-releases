// ============================================
// COMPONENTS - Descargar ventas y facturas (CSV)
// ============================================
// Los datos fiscales son del negocio: se pueden sacar siempre, incluso con la
// suscripción suspendida (en ese caso el permiso llega con el intento de ingreso).

import { useState } from 'react';
import { Download, Loader2 } from 'lucide-react';
import { exportAPI } from '../../services/api';
import { errorMessage } from '../../services/apiErrors';
import { toast } from '../../shared/toast';
import { t } from '../../i18n';

interface Props {
  /** Devuelve un permiso de exportación vigente */
  getToken: () => Promise<string>;
  className?: string;
}

export function ExportDataButtons({ getToken, className = '' }: Props) {
  const [busy, setBusy] = useState<'sales' | 'invoices' | null>(null);

  const download = async (kind: 'sales' | 'invoices') => {
    setBusy(kind);
    try {
      await exportAPI.download(kind, await getToken());
    } catch (e) {
      toast.error(errorMessage(e), t('plan:no_se_pudo_exportar'));
    } finally {
      setBusy(null);
    }
  };

  const button = (kind: 'sales' | 'invoices', label: string) => (
    <button
      type="button"
      onClick={() => download(kind)}
      disabled={busy !== null}
      className="inline-flex items-center justify-center gap-2 min-h-[40px] px-3.5 rounded-lg border border-line-strong bg-surface text-fg text-xs font-semibold hover:bg-surface-muted disabled:opacity-50"
    >
      {busy === kind ? <Loader2 className="w-4 h-4 animate-spin" aria-hidden /> : <Download className="w-4 h-4" aria-hidden />}
      {label}
    </button>
  );

  return (
    <div className={`flex flex-wrap gap-2 ${className}`}>
      {button('sales', t('plan:exportar_ventas'))}
      {button('invoices', t('plan:exportar_facturas'))}
    </div>
  );
}
