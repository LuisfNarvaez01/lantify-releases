// ============================================
// COMMON - Menú desplegable anclado a un botón
// ============================================
// Se cierra con clic afuera o Escape y devuelve el foco al botón.

import { ReactNode, useEffect, useRef, useState } from 'react';

interface PopoverProps {
  /** Contenido del botón que abre el menú */
  trigger: ReactNode;
  triggerClassName?: string;
  triggerLabel: string;
  /** Contenido; recibe una función para cerrar */
  children: (close: () => void) => ReactNode;
  align?: 'left' | 'right';
  panelClassName?: string;
  disabled?: boolean;
}

export function Popover({ trigger, triggerClassName = '', triggerLabel, children, align = 'left', panelClassName = '', disabled }: PopoverProps) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);

  const close = () => {
    setOpen(false);
    buttonRef.current?.focus();
  };

  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (!ref.current?.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close();
    };
    document.addEventListener('mousedown', onDown);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDown);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  return (
    <div ref={ref} className="relative min-w-0">
      <button
        ref={buttonRef}
        type="button"
        aria-haspopup="dialog"
        aria-expanded={open}
        aria-label={triggerLabel}
        disabled={disabled}
        onClick={() => setOpen((o) => !o)}
        className={triggerClassName}
      >
        {trigger}
      </button>
      {open && (
        <div
          role="dialog"
          aria-label={triggerLabel}
          className={`absolute top-full mt-2 z-40 bg-white border border-slate-200 rounded-2xl shadow-xl ${
            align === 'right' ? 'right-0' : 'left-0'
          } ${panelClassName}`}
        >
          {children(close)}
        </div>
      )}
    </div>
  );
}
