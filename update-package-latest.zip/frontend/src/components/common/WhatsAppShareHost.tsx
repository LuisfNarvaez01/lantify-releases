// ============================================
// COMMON - Enviar una cuenta o recibo por WhatsApp
// ============================================
// Muestra la imagen de la cuenta y deja:
//  - Enviar por WhatsApp: abre el chat con el mensaje y, si el negocio está en Lantify
//    Cloud, un enlace privado a la cuenta. En el computador también deja la imagen
//    copiada para pegarla (Ctrl+V).
//  - Copiar la imagen, descargarla o (celular/tablet) compartirla con el sistema.
// Se monta una vez en App; la abre sendTicketByWhatsApp.

import { useEffect, useMemo, useRef, useState } from 'react';
import { Copy, Download, Link2, Loader2, MessageCircle, Share2, X, Check, CloudOff } from 'lucide-react';
import { useWhatsAppShare, WhatsAppOutcome } from '../../shared/whatsappShare';
import { ticketsAPI } from '../../services/api';
import { openWhatsAppChat } from '../../services/whatsappTicket';
import { toast } from '../../shared/toast';
import { t } from '../../i18n';

type LinkState = { status: 'loading' } | { status: 'ready'; url: string } | { status: 'off' };

const canCopyImage = () => typeof window !== 'undefined' && window.isSecureContext && !!navigator.clipboard?.write && typeof ClipboardItem !== 'undefined';

const toBase64 = (blob: Blob) =>
  new Promise<string>((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result).split(',')[1] || '');
    r.onerror = () => reject(r.error);
    r.readAsDataURL(blob);
  });

/** Copia texto incluso sin conexión segura (tablets por http en la red local) */
const copyText = async (text: string) => {
  if (window.isSecureContext && navigator.clipboard?.writeText) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      // sigue con el método antiguo
    }
  }
  const area = document.createElement('textarea');
  area.value = text;
  area.setAttribute('readonly', '');
  Object.assign(area.style, { position: 'fixed', opacity: '0', left: '-9999px' });
  document.body.appendChild(area);
  area.select();
  const ok = document.execCommand('copy');
  area.remove();
  return ok;
};

const download = (blob: Blob, name: string) => {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
};

export function WhatsAppShareHost() {
  const current = useWhatsAppShare((s) => s.current);
  const close = useWhatsAppShare((s) => s.close);
  const [phone, setPhone] = useState('');
  const [link, setLink] = useState<LinkState>({ status: 'loading' });
  const [busy, setBusy] = useState(false);
  const [copied, setCopied] = useState<'image' | 'link' | null>(null);
  const linkPromise = useRef<Promise<string | null>>(Promise.resolve(null));
  const phoneRef = useRef<HTMLInputElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);

  const imageUrl = useMemo(() => (current ? URL.createObjectURL(current.blob) : ''), [current]);
  useEffect(() => () => {
    if (imageUrl) URL.revokeObjectURL(imageUrl);
  }, [imageUrl]);

  const file = useMemo(() => (current ? new File([current.blob], current.fileName, { type: current.blob.type || 'image/png' }) : null), [current]);
  const canShare = !!file && typeof navigator !== 'undefined' && !!navigator.canShare?.({ files: [file] });
  const copyable = canCopyImage();

  useEffect(() => {
    if (!current) return;
    setPhone(current.phone);
    setCopied(null);
    setBusy(false);
    setLink({ status: 'loading' });
    let alive = true;
    // El enlace se prepara apenas se abre la ventana: al tocar "Enviar" casi siempre ya está
    linkPromise.current = toBase64(current.blob)
      .then((data) => ticketsAPI.share(data))
      .then((r) => {
        if (alive) setLink({ status: 'ready', url: r.url });
        return r.url;
      })
      .catch(() => {
        if (alive) setLink({ status: 'off' });
        return null;
      });
    const prev = document.activeElement as HTMLElement | null;
    setTimeout(() => phoneRef.current?.focus(), 0);
    return () => {
      alive = false;
      prev?.focus?.();
    };
  }, [current]);

  if (!current) return null;

  const finish = (outcome: WhatsAppOutcome) => close(outcome);

  const copyImage = async (silent = false) => {
    if (!copyable) return false;
    try {
      await navigator.clipboard.write([new ClipboardItem({ [current.blob.type || 'image/png']: current.blob })]);
      setCopied('image');
      if (!silent) toast.success(t('pos:wa_copiada_sola'));
      return true;
    } catch {
      if (!silent) toast.error(t('pos:wa_no_copia'));
      return false;
    }
  };

  const copyLink = async () => {
    if (link.status !== 'ready') return;
    if (await copyText(link.url)) {
      setCopied('link');
      toast.success(t('pos:wa_enlace_copiado'));
    }
  };

  const share = async () => {
    if (!file) return;
    try {
      await navigator.share({ files: [file], text: current.message });
      finish('shared');
    } catch (err: any) {
      if (err?.name !== 'AbortError') toast.error(t('pos:wa_no_comparte'));
    }
  };

  const send = async () => {
    setBusy(true);
    try {
      // Si el enlace aún se está preparando, se espera un momento (sin bloquear si no hay internet)
      const url = await Promise.race([linkPromise.current, new Promise<null>((r) => setTimeout(() => r(null), 8000))]);
      const text = url ? `${current.message}\n\n${t('pos:wa_ver_cuenta', { link: url })}` : current.message;
      // En el computador la imagen también queda copiada; sin enlace ni portapapeles, se descarga
      const pasted = await copyImage(true);
      if (!url && !pasted) download(current.blob, current.fileName);
      openWhatsAppChat(phone, text);
      if (url) toast.show({ type: 'success', title: t('pos:wa_listo_titulo'), message: pasted ? t('pos:wa_listo_enlace_pegar') : t('pos:wa_listo_enlace'), duration: 9000 });
      else if (pasted) toast.show({ type: 'success', title: t('pos:wa_copiada_titulo'), message: t('pos:wa_copiada_desc'), duration: 9000 });
      else toast.show({ type: 'info', title: t('pos:wa_descargada_titulo'), message: t('pos:wa_descargada_desc'), duration: 9000 });
      finish('sent');
    } finally {
      setBusy(false);
    }
  };

  const onKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      e.stopPropagation();
      finish('cancelled');
    } else if (e.key === 'Tab') {
      const focusables = panelRef.current?.querySelectorAll<HTMLElement>('button:not([disabled]), input');
      if (!focusables?.length) return;
      const first = focusables[0];
      const last = focusables[focusables.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    }
  };

  const secondary = 'inline-flex items-center justify-center gap-2 min-h-[44px] px-3 rounded-xl border border-slate-300 bg-white text-sm font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-50';

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onMouseDown={() => finish('cancelled')}>
      <div
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="wa-share-title"
        onMouseDown={(e) => e.stopPropagation()}
        onKeyDown={onKeyDown}
        className="w-full max-w-3xl max-h-[92vh] overflow-hidden bg-white rounded-3xl shadow-2xl border border-slate-200 grid md:grid-cols-[minmax(0,17rem)_minmax(0,1fr)]"
      >
        <div className="bg-slate-100 border-b md:border-b-0 md:border-r border-slate-200 p-4 overflow-y-auto max-h-[34vh] md:max-h-[92vh]">
          <img src={imageUrl} alt={t('pos:wa_vista_previa')} className="w-full h-auto bg-white rounded-md shadow-sm" />
        </div>

        <div className="p-6 flex flex-col gap-5 overflow-y-auto">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h2 id="wa-share-title" className="text-lg font-bold text-slate-900">{t('pos:wa_titulo')}</h2>
              <p className="text-sm text-slate-500 mt-0.5">{t('pos:wa_subtitulo')}</p>
            </div>
            <button type="button" onClick={() => finish('cancelled')} aria-label={t('common:cerrar')} className="p-2 -m-2 rounded-xl text-slate-500 hover:bg-slate-100 hover:text-slate-800">
              <X className="w-5 h-5" aria-hidden />
            </button>
          </div>

          <label className="block">
            <span className="block text-sm font-semibold text-slate-700 mb-1.5">{t('pos:wa_numero')}</span>
            <input
              ref={phoneRef}
              type="tel"
              inputMode="tel"
              value={phone}
              placeholder="3001234567"
              onChange={(e) => setPhone(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  if (!busy) send();
                }
              }}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-slate-50 text-base text-slate-900 focus:bg-white focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20"
            />
            <span className="block text-xs text-slate-500 mt-1">{t('pos:wa_numero_ayuda')}</span>
          </label>

          <div className="rounded-2xl border border-slate-200 px-4 py-3 text-sm" aria-live="polite">
            {link.status === 'loading' && (
              <p className="flex items-center gap-2 text-slate-600"><Loader2 className="w-4 h-4 animate-spin shrink-0" aria-hidden /> {t('pos:wa_enlace_preparando')}</p>
            )}
            {link.status === 'ready' && (
              <div className="flex items-center justify-between gap-3">
                <p className="flex items-center gap-2 text-slate-700 min-w-0"><Link2 className="w-4 h-4 text-emerald-600 shrink-0" aria-hidden /> <span className="truncate">{t('pos:wa_enlace_listo')}</span></p>
                <button type="button" onClick={copyLink} className="shrink-0 inline-flex items-center gap-1.5 text-xs font-bold text-blue-700 hover:underline">
                  {copied === 'link' ? <Check className="w-3.5 h-3.5" aria-hidden /> : <Copy className="w-3.5 h-3.5" aria-hidden />} {t('pos:wa_copiar_enlace')}
                </button>
              </div>
            )}
            {link.status === 'off' && (
              <p className="flex items-start gap-2 text-slate-600"><CloudOff className="w-4 h-4 shrink-0 mt-0.5" aria-hidden /> {copyable ? t('pos:wa_sin_enlace_pegar') : t('pos:wa_sin_enlace_adjuntar')}</p>
            )}
          </div>

          <button type="button" onClick={send} disabled={busy} className="inline-flex items-center justify-center gap-2 min-h-[48px] px-5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold shadow-sm disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500/40">
            {busy ? <Loader2 className="w-5 h-5 animate-spin" aria-hidden /> : <MessageCircle className="w-5 h-5" aria-hidden />}
            {t('pos:wa_enviar')}
          </button>

          <div className="grid grid-cols-2 gap-2">
            {copyable && (
              <button type="button" onClick={() => copyImage()} className={secondary}>
                {copied === 'image' ? <Check className="w-4 h-4 text-emerald-600" aria-hidden /> : <Copy className="w-4 h-4" aria-hidden />} {t('pos:wa_copiar_imagen')}
              </button>
            )}
            <button type="button" onClick={() => { download(current.blob, current.fileName); toast.success(t('pos:wa_descargada_sola')); }} className={secondary}>
              <Download className="w-4 h-4" aria-hidden /> {t('pos:wa_descargar')}
            </button>
            {canShare && (
              <button type="button" onClick={share} className={secondary}>
                <Share2 className="w-4 h-4" aria-hidden /> {t('pos:wa_compartir')}
              </button>
            )}
          </div>
          {!copyable && <p className="text-xs text-slate-500 -mt-2">{t('pos:wa_sin_portapapeles')}</p>}
        </div>
      </div>
    </div>
  );
}
