import { useEffect, useRef, useState } from 'react';
import { AlertTriangle, HelpCircle } from 'lucide-react';
import { dialogManager, DialogRequest } from '../../shared/dialog';
import { Button } from './Button';

import { t } from '../../i18n';
/** Muestra los diálogos de confirmDialog / promptDialog. Se monta una vez en App. */
export function DialogHost() {
  const [current, setCurrent] = useState<DialogRequest | null>(null);
  const [value, setValue] = useState('');
  const [touched, setTouched] = useState(false);
  const panelRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement | HTMLTextAreaElement>(null);
  const confirmRef = useRef<HTMLButtonElement>(null);
  const previousFocus = useRef<HTMLElement | null>(null);

  useEffect(() => dialogManager.subscribe(setCurrent), []);

  useEffect(() => {
    if (!current) return;
    previousFocus.current = document.activeElement as HTMLElement;
    setValue(current.defaultValue || '');
    setTouched(false);
    // Foco inicial: el campo de texto, o "Cancelar" si la acción es destructiva
    setTimeout(() => {
      if (current.kind === 'prompt') inputRef.current?.focus();
      else if (current.tone === 'danger') panelRef.current?.querySelector<HTMLButtonElement>('[data-cancel]')?.focus();
      else confirmRef.current?.focus();
    }, 0);
    return () => previousFocus.current?.focus?.();
  }, [current?.id]);

  if (!current) return null;

  const isPrompt = current.kind === 'prompt';
  const invalid = isPrompt && current.required && value.trim() === '';
  const danger = current.tone === 'danger';

  const cancel = () => dialogManager.close(current.id, isPrompt ? null : false);
  const accept = () => {
    if (invalid) {
      setTouched(true);
      inputRef.current?.focus();
      return;
    }
    dialogManager.close(current.id, isPrompt ? value.trim() : true);
  };

  const onKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      e.stopPropagation();
      cancel();
    } else if (e.key === 'Enter' && !(current.multiline && !e.ctrlKey)) {
      e.preventDefault();
      accept();
    } else if (e.key === 'Tab') {
      // Mantener el foco dentro del diálogo
      const focusables = panelRef.current?.querySelectorAll<HTMLElement>('button, input, textarea');
      if (!focusables || focusables.length === 0) return;
      const first = focusables[0];
      const last = focusables[focusables.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    }
  };

  const Icon = danger ? AlertTriangle : HelpCircle;
  const inputClass = `w-full px-3.5 py-2.5 rounded-xl border bg-slate-50 text-sm text-slate-900 focus:bg-white focus:outline-none focus:ring-2 ${
    touched && invalid ? 'border-rose-400 focus:ring-rose-500/30' : 'border-slate-300 focus:border-blue-600 focus:ring-blue-500/20'
  }`;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onMouseDown={cancel}>
      <div
        ref={panelRef}
        role="alertdialog"
        aria-modal="true"
        aria-labelledby={`dialog-title-${current.id}`}
        aria-describedby={current.message ? `dialog-msg-${current.id}` : undefined}
        onKeyDown={onKeyDown}
        onMouseDown={(e) => e.stopPropagation()}
        className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 p-6"
      >
        <div className="flex items-start gap-3">
          <span className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${danger ? 'bg-rose-50 text-rose-600' : 'bg-blue-50 text-blue-600'}`}>
            <Icon className="w-5 h-5" aria-hidden />
          </span>
          <div className="min-w-0 flex-1">
            <h2 id={`dialog-title-${current.id}`} className="text-base font-bold text-slate-900 font-heading">{current.title}</h2>
            {current.message && (
              <p id={`dialog-msg-${current.id}`} className="text-sm text-slate-600 mt-1">{current.message}</p>
            )}
          </div>
        </div>

        {isPrompt && (
          <div className="mt-4">
            <label htmlFor={`dialog-input-${current.id}`} className="block text-xs font-bold text-slate-700 mb-1.5">
              {current.label}{current.required && <span className="text-rose-600"> *</span>}
            </label>
            {current.multiline ? (
              <textarea
                id={`dialog-input-${current.id}`}
                ref={inputRef as React.RefObject<HTMLTextAreaElement>}
                value={value}
                onChange={(e) => setValue(e.target.value)}
                placeholder={current.placeholder}
                rows={3}
                className={inputClass}
              />
            ) : (
              <input
                id={`dialog-input-${current.id}`}
                ref={inputRef as React.RefObject<HTMLInputElement>}
                value={value}
                onChange={(e) => setValue(e.target.value)}
                placeholder={current.placeholder}
                inputMode={current.inputMode}
                type={current.inputType || 'text'}
                autoComplete={current.inputType === 'password' ? 'off' : undefined}
                className={inputClass}
              />
            )}
            {touched && invalid && <p className="text-xs text-rose-600 mt-1">{t('common:este_campo_es_obligatorio')}</p>}
          </div>
        )}

        <div className="flex justify-end gap-2 mt-6">
          <Button variant="outline" onClick={cancel} data-cancel>
            {current.cancelLabel || t('common:cancelar')}
          </Button>
          <Button ref={confirmRef} variant={danger ? 'danger' : 'primary'} onClick={accept}>
            {current.confirmLabel || t('common:aceptar')}
          </Button>
        </div>
      </div>
    </div>
  );
}
