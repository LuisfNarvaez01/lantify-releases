// ============================================
// COMPONENTS - Avisos emergentes (abajo a la derecha)
// ============================================
// Lo que llegó de la página (pedidos, reservas, clientes nuevos, premios, tarjetas
// completas) y lo que pasa en el salón (platos listos en cocina, cuenta pedida,
// mesas que esperan, avisos de Autopilot). El servidor avisa al instante por la
// conexión en vivo; si se cae, se pregunta cada 15 s. Una vez al día avisa quién
// cumple años. Los pedidos se quedan hasta cerrarlos; lo demás se va solo. Todo
// queda en la campanita. Cada equipo ve solo lo que su rol puede atender.

import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Award, CalendarDays, Cake, ChefHat, Gift, Radar, ReceiptText, ShoppingBag, TimerReset, UserPlus, X } from 'lucide-react';
import { notificationsAPI, PosNotification } from '../../services/api';
import { chime } from '../../store/useOnlineOrdersStore';
import { useCan } from '../../shared/permissions';
import { usePlan } from '../../shared/plan';
import { formatCurrency } from '../../shared/formatUtils';
import { t, getLocale } from '../../i18n';
import { useNotificationLog, type LogIcon } from '../../shared/notificationLog';
import { LIVE_NOTIFICATIONS_EVENT } from '../../shared/live';
import { currentUserId, useFloor } from '../../shared/features';
import type { FloorState } from '../../services/v3Api';

export type NotificationTarget = { tab: 'delivery' | 'reservations' } | { admin: 'customers' | 'coupons' };

interface Card {
  key: string;
  icon: React.ElementType;
  tone: string;
  title: string;
  message: string;
  action?: { label: string; target: NotificationTarget };
  /** 0 = se queda hasta cerrarla */
  ttl: number;
  /** Ícono en la campanita */
  log: LogIcon;
}

const POLL_MS = 15000;
const BIRTHDAY_CHECK_MS = 60 * 60 * 1000;
const MAX_VISIBLE = 4;

const today = () => new Date().toLocaleDateString('en-CA');
const BDAY_KEY = 'lantify.birthdaysShown';

const timeOf = (iso: string | number | null | undefined) =>
  iso ? new Date(String(iso)).toLocaleString(getLocale(), { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : '';

export const NotificationCenter: React.FC<{ role?: string; isAdmin: boolean; onOpen: (target: NotificationTarget) => void }> = ({ role, isAdmin, onOpen }) => {
  const [cards, setCards] = useState<Card[]>([]);
  const cursor = useRef<number | null>(null);
  const can = useCan(role);
  const plan = usePlan();
  const seeOrders = plan.has('webstore') && can('online_orders');
  const seeReservations = plan.has('reservations');
  const seeLoyalty = plan.has('loyalty') || plan.has('customers');

  const dismiss = useCallback((key: string) => setCards((cs) => cs.filter((c) => c.key !== key)), []);

  const push = useCallback((card: Card) => {
    setCards((cs) => [card, ...cs.filter((c) => c.key !== card.key)].slice(0, 12));
    useNotificationLog.getState().add({ id: card.key, icon: card.log, tone: card.tone, title: card.title, message: card.message });
    if (card.ttl > 0) window.setTimeout(() => dismiss(card.key), card.ttl);
  }, [dismiss]);

  const cardFor = useCallback((n: PosNotification): Card | null => {
    const d = n.data;
    const name = String(d.name || t('notifications:un_cliente'));
    switch (n.kind) {
      case 'ONLINE_ORDER':
        if (!seeOrders) return null;
        return {
          key: `n${n.id}`, icon: ShoppingBag, log: 'order', tone: 'bg-blue-600', ttl: 0,
          title: t('notifications:pedido_titulo', { code: d.code || '' }),
          message: t('notifications:pedido_desc', { name, total: formatCurrency(Number(d.total) || 0) }),
          action: { label: t('notifications:ver_pedido'), target: { tab: 'delivery' } },
        };
      case 'RESERVATION':
        if (!seeReservations) return null;
        return {
          key: `n${n.id}`, icon: CalendarDays, log: 'reservation', tone: 'bg-violet-600', ttl: 30000,
          title: t('notifications:reserva_titulo'),
          message: t('notifications:reserva_desc', { name, count: Number(d.party) || 1, when: timeOf(d.startsAt) }),
          action: { label: t('notifications:ver_reservas'), target: { tab: 'reservations' } },
        };
      case 'NEW_CUSTOMER':
        if (!seeLoyalty) return null;
        return {
          key: `n${n.id}`, icon: UserPlus, log: 'customer', tone: 'bg-emerald-600', ttl: 15000,
          title: t('notifications:cliente_titulo'),
          message: t('notifications:cliente_desc', { name }),
          action: isAdmin ? { label: t('notifications:ver_clientes'), target: { admin: 'customers' } } : undefined,
        };
      case 'PRIZE':
        if (!seeLoyalty) return null;
        return {
          key: `n${n.id}`, icon: Gift, log: 'prize', tone: 'bg-amber-500', ttl: 20000,
          title: t('notifications:premio_titulo'),
          message: t('notifications:premio_desc', { name, prize: d.label || '', code: d.code || '' }),
          action: isAdmin ? { label: t('notifications:ver_cupones'), target: { admin: 'coupons' } } : undefined,
        };
      case 'CARD_COMPLETE':
        if (!seeLoyalty) return null;
        return {
          key: `n${n.id}`, icon: Award, log: 'card', tone: 'bg-amber-600', ttl: 30000,
          title: t('notifications:tarjeta_titulo'),
          message: t('notifications:tarjeta_desc', { name, prize: d.label || '', code: d.code || '' }),
        };
      default:
        return null;
    }
  }, [seeOrders, seeReservations, seeLoyalty, isAdmin]);

  const birthdaysCard = useCallback((list: { name: string }[]) => {
    let shown = '';
    try { shown = localStorage.getItem(BDAY_KEY) || ''; } catch { /* sin almacenamiento */ }
    if (!list.length || shown === today()) return;
    try { localStorage.setItem(BDAY_KEY, today()); } catch { /* sin almacenamiento */ }
    const names = list.slice(0, 3).map((b) => b.name).join(', ');
    push({
      key: `bday-${today()}`, icon: Cake, log: 'birthday', tone: 'bg-pink-600', ttl: 0,
      title: t('notifications:cumple_titulo', { count: list.length }),
      message: list.length > 3 ? t('notifications:cumple_desc_mas', { names, count: list.length - 3 }) : t('notifications:cumple_desc', { names }),
      action: isAdmin ? { label: t('notifications:ver_clientes'), target: { admin: 'customers' } } : undefined,
    });
  }, [push, isAdmin]);

  useEffect(() => {
    let alive = true;
    let lastBirthdayCheck = 0;
    const tick = async () => {
      if (!alive) return;
      const wantBirthdays = seeLoyalty && Date.now() - lastBirthdayCheck > BIRTHDAY_CHECK_MS;
      try {
        const feed = await notificationsAPI.since(cursor.current, wantBirthdays);
        if (!alive) return;
        if (wantBirthdays) lastBirthdayCheck = Date.now();
        const fresh = feed.items.map(cardFor).filter((c): c is Card => !!c);
        if (fresh.some((c) => c.ttl === 0 || c.icon === CalendarDays)) chime();
        fresh.forEach(push);
        cursor.current = feed.cursor;
        if (feed.birthdays) birthdaysCard(feed.birthdays);
      } catch {
        // sin conexión con el servidor del negocio: se intenta en la próxima vuelta
      }
    };
    tick();
    const timer = window.setInterval(tick, POLL_MS);
    window.addEventListener(LIVE_NOTIFICATIONS_EVENT, tick);
    return () => {
      alive = false;
      window.clearInterval(timer);
      window.removeEventListener(LIVE_NOTIFICATIONS_EVENT, tick);
    };
  }, [cardFor, push, birthdaysCard, seeLoyalty]);

  // ── Salón: lo nuevo desde la última vez (platos listos, cuenta, esperas, Autopilot) ──
  const { floor } = useFloor();
  const seen = useRef<{ ready: boolean; pickups: Map<string, number>; bills: Set<string>; alerts: Set<string>; notices: Set<string> }>({
    ready: false, pickups: new Map(), bills: new Set(), alerts: new Set(), notices: new Set(),
  });
  useEffect(() => {
    if (floor.now === new Date(0).toISOString()) return; // aún no hay datos
    const cards = floorCards(floor, seen.current, role);
    seen.current.ready = true;
    if (cards.some((c) => c.log === 'kitchen' || c.log === 'bill')) chime();
    cards.forEach(push);
  }, [floor, role, push]);

  if (!cards.length) return null;
  const visible = cards.slice(0, MAX_VISIBLE);

  return (
    <section
      aria-label={t('notifications:region')}
      aria-live="polite"
      className="fixed z-40 bottom-4 right-4 left-4 sm:left-auto sm:w-96 flex flex-col-reverse gap-3 pointer-events-none"
    >
      {visible.map((c) => {
        const Icon = c.icon;
        return (
          <article
            key={c.key}
            className="pointer-events-auto bg-white border border-slate-200 rounded-2xl shadow-xl p-4 flex gap-3 animate-in slide-in-from-bottom-4 fade-in-50 duration-200"
          >
            <div className={`${c.tone} w-10 h-10 shrink-0 rounded-xl flex items-center justify-center text-white`}>
              <Icon className="w-5 h-5" aria-hidden />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-sm font-bold text-slate-900 leading-snug">{c.title}</h3>
              <p className="text-xs text-slate-600 mt-0.5 leading-relaxed break-words">{c.message}</p>
              {c.action && (
                <button
                  type="button"
                  onClick={() => {
                    onOpen(c.action!.target);
                    dismiss(c.key);
                  }}
                  className="mt-2 text-xs font-bold text-blue-700 hover:underline"
                >
                  {c.action.label}
                </button>
              )}
            </div>
            <button
              type="button"
              onClick={() => dismiss(c.key)}
              className="shrink-0 -mr-1 -mt-1 w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-slate-700 hover:bg-slate-100"
              aria-label={t('notifications:cerrar')}
            >
              <X className="w-4 h-4" />
            </button>
          </article>
        );
      })}
      {cards.length > MAX_VISIBLE && (
        <button
          type="button"
          onClick={() => setCards([])}
          className="pointer-events-auto self-end text-xs font-bold text-slate-600 bg-white/90 border border-slate-200 rounded-full px-3 py-1 shadow"
        >
          {t('notifications:cerrar_todas', { count: cards.length })}
        </button>
      )}
    </section>
  );
};

type Seen = { ready: boolean; pickups: Map<string, number>; bills: Set<string>; alerts: Set<string>; notices: Set<string> };

/**
 * Tarjetas por lo que cambió en el salón. La primera vez solo memoriza (al abrir el
 * programa no salen avisos viejos). El mesero solo ve lo de sus mesas.
 */
function floorCards(floor: FloorState, seen: Seen, role?: string): Card[] {
  const me = currentUserId();
  const mine = (waiterId: string | null | undefined) => role !== 'WAITER' || !waiterId || waiterId === me;
  const out: Card[] = [];
  const first = !seen.ready;

  const pickups = new Map<string, number>();
  for (const p of floor.pickups || []) {
    pickups.set(p.tableId, p.count);
    const before = seen.pickups.get(p.tableId) || 0;
    if (!first && p.count > before && mine(p.waiterId)) {
      out.push({
        key: `pk-${p.tableId}-${p.readyAt || p.count}`, icon: ChefHat, tone: 'bg-teal-600', ttl: 20000, log: 'kitchen',
        title: t('notifications:listo_titulo', { table: p.tableNumber }),
        message: p.waiterName && role !== 'WAITER' ? t('notifications:listo_desc_mesero', { count: p.count, name: p.waiterName }) : t('notifications:listo_desc', { count: p.count }),
      });
    }
  }
  seen.pickups = pickups;

  const bills = new Set<string>();
  for (const tb of floor.tables) {
    if (!tb.billRequestedAt) continue;
    bills.add(tb.tableId);
    if (!first && !seen.bills.has(tb.tableId) && mine(tb.waiterId)) {
      const number = tb.tableNumber || '';
      out.push({
        key: `bill-${tb.tableId}-${tb.billRequestedAt}`, icon: ReceiptText, tone: 'bg-violet-600', ttl: 15000, log: 'bill',
        title: number ? t('notifications:cuenta_titulo', { table: number }) : t('notifications:cuenta_titulo_sin'),
        message: tb.waiterName ? t('notifications:cuenta_desc', { name: tb.waiterName }) : '',
      });
    }
  }
  seen.bills = bills;

  const alerts = new Set<string>();
  for (const a of floor.alerts) {
    const key = `${a.tableId}:${a.kind}`;
    alerts.add(key);
    if (!first && !seen.alerts.has(key) && mine(a.waiterId)) {
      out.push({
        key: `al-${key}-${Math.floor(Date.now() / 60000)}`, icon: TimerReset, tone: a.kind === 'bill' ? 'bg-rose-600' : 'bg-amber-500', ttl: 12000, log: 'alert',
        title: t(`notifications:alerta_${a.kind}`, { table: a.tableNumber, min: a.minutes }),
        message: t(`v3:alerta_ayuda_${a.kind}`),
      });
    }
  }
  seen.alerts = alerts;

  const notices = new Set<string>();
  for (const n of floor.notices || []) {
    notices.add(n.id);
    if (!first && !seen.notices.has(n.id)) {
      out.push({ key: `ap-${n.id}`, icon: Radar, tone: 'bg-indigo-600', ttl: 20000, log: 'autopilot', title: t('notifications:autopilot_titulo'), message: String(n.message || '') });
    }
  }
  seen.notices = notices;
  return out;
}
