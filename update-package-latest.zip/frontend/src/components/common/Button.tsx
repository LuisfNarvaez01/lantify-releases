import React from 'react';
import { Loader2 } from 'lucide-react';

export type ButtonVariant = 'primary' | 'secondary' | 'outline' | 'danger' | 'ghost' | 'success';
export type ButtonSize = 'sm' | 'md' | 'lg';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  isLoading?: boolean;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  fullWidth?: boolean;
}

const variantStyles: Record<ButtonVariant, string> = {
  primary:
    'bg-blue-600 hover:bg-blue-700 text-white shadow-sm border border-transparent focus-visible:ring-2 focus-visible:ring-blue-500/40',
  secondary:
    'bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 focus-visible:ring-2 focus-visible:ring-slate-400/40',
  outline:
    'bg-transparent hover:bg-slate-50 text-slate-700 border border-slate-300 hover:border-slate-400 focus-visible:ring-2 focus-visible:ring-slate-300/40',
  danger:
    'bg-rose-600 hover:bg-rose-700 text-white shadow-sm border border-transparent focus-visible:ring-2 focus-visible:ring-rose-500/40',
  ghost:
    'bg-transparent hover:bg-slate-100 text-slate-600 hover:text-slate-900 border border-transparent focus-visible:ring-2 focus-visible:ring-slate-300/40',
  success:
    'bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm border border-transparent focus-visible:ring-2 focus-visible:ring-emerald-500/40',
};

const sizeStyles: Record<ButtonSize, string> = {
  sm: 'px-3 py-1.5 text-xs min-h-[36px] gap-1.5 rounded-lg',
  md: 'px-4 py-2 text-sm min-h-[42px] gap-2 rounded-lg font-medium',
  lg: 'px-5 py-2.5 text-base min-h-[48px] gap-2.5 rounded-xl font-semibold',
};

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(({
  children,
  variant = 'primary',
  size = 'md',
  isLoading = false,
  leftIcon,
  rightIcon,
  fullWidth = false,
  disabled,
  className = '',
  ...props
}, ref) => {
  const isDisabled = disabled || isLoading;

  return (
    <button
      ref={ref}
      {...props}
      disabled={isDisabled}
      className={`
        inline-flex items-center justify-center select-none font-medium transition-all duration-150
        outline-none active:scale-[0.98] disabled:opacity-50 disabled:pointer-events-none disabled:active:scale-100
        ${variantStyles[variant]}
        ${sizeStyles[size]}
        ${fullWidth ? 'w-full' : ''}
        ${className}
      `}
    >
      {isLoading ? (
        <Loader2 className="w-4 h-4 animate-spin text-current" />
      ) : (
        leftIcon && <span className="inline-flex shrink-0 items-center">{leftIcon}</span>
      )}
      <span className="truncate">{children}</span>
      {!isLoading && rightIcon && (
        <span className="inline-flex shrink-0 items-center">{rightIcon}</span>
      )}
    </button>
  );
});

Button.displayName = 'Button';

export default Button;
