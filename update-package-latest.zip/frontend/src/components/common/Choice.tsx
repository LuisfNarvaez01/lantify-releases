// ============================================
// COMMON - Interruptor y tarjeta de opción
// ============================================
// Controles grandes (mínimo 44 px) pensados para pantalla táctil.

import { Check } from 'lucide-react';

export function Toggle({ checked, onChange, label, description, id, disabled = false, badge }: {
  checked: boolean; onChange: (v: boolean) => void; label: string; description?: string; id: string;
  /** No se puede cambiar (p. ej. el plan no lo incluye) */
  disabled?: boolean;
  /** Etiqueta junto al nombre (plan, próximamente) */
  badge?: React.ReactNode;
}) {
  return (
    <label htmlFor={id} className={`flex items-start justify-between gap-4 p-4 rounded-2xl border border-slate-200 bg-white ${disabled ? 'cursor-not-allowed opacity-75' : 'cursor-pointer hover:border-slate-300'}`}>
      <span>
        <span className="flex flex-wrap items-center gap-2 text-sm font-bold text-slate-900">{label}{badge}</span>
        {description && <span className="block text-xs text-slate-500 mt-0.5">{description}</span>}
      </span>
      <span className="relative inline-flex shrink-0 mt-0.5">
        <input id={id} type="checkbox" role="switch" className="peer sr-only" checked={checked} disabled={disabled} onChange={(e) => onChange(e.target.checked)} />
        <span className="w-11 h-6 rounded-full bg-slate-300 peer-checked:bg-blue-600 transition-colors peer-focus-visible:ring-2 peer-focus-visible:ring-blue-500/40" />
        <span className="absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform peer-checked:translate-x-5" />
      </span>
    </label>
  );
}

export function ChoiceCard({ active, onClick, title, description, icon }: { active: boolean; onClick: () => void; title: string; description?: string; icon?: React.ReactNode }) {
  return (
    <button
      type="button"
      role="radio"
      aria-checked={active}
      onClick={onClick}
      className={`relative text-left p-4 rounded-2xl border-2 transition-all ${
        active ? 'border-blue-600 bg-blue-50 shadow-sm' : 'border-slate-200 bg-white hover:border-slate-300'
      }`}
    >
      {active && (
        <span className="absolute top-3 right-3 w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center">
          <Check className="w-3.5 h-3.5" aria-hidden />
        </span>
      )}
      {icon}
      <span className="block text-sm font-bold text-slate-900 pr-6">{title}</span>
      {description && <span className="block text-xs text-slate-500 mt-1 leading-relaxed">{description}</span>}
    </button>
  );
}
