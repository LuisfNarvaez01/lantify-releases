// ============================================
// COMMON - Interruptor y tarjeta de opción
// ============================================
// Controles grandes (mínimo 44 px) pensados para pantalla táctil.

import { useEffect, useId, useRef, useState } from 'react';
import { Check, HelpCircle } from 'lucide-react';
import { t } from '../../i18n';

/** Botón "?" con la explicación completa (se abre al tocar; Esc o tocar fuera lo cierra) */
export function InfoTip({ text, label }: { text: string; label: string }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLSpanElement>(null);
  const tipId = useId();
  useEffect(() => {
    if (!open) return;
    const close = (e: MouseEvent | KeyboardEvent) => {
      if (e instanceof KeyboardEvent ? e.key === 'Escape' : !ref.current?.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', close);
    document.addEventListener('keydown', close);
    return () => { document.removeEventListener('mousedown', close); document.removeEventListener('keydown', close); };
  }, [open]);
  return (
    <span ref={ref} className="relative inline-flex shrink-0">
      <button
        type="button"
        onClick={(e) => { e.preventDefault(); e.stopPropagation(); setOpen((o) => !o); }}
        aria-label={label}
        aria-expanded={open}
        aria-describedby={open ? tipId : undefined}
        className="grid h-7 w-7 place-items-center rounded-full text-slate-400 hover:bg-slate-100 hover:text-slate-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500/40"
      >
        <HelpCircle className="h-4 w-4" aria-hidden />
      </button>
      {open && (
        <span id={tipId} role="tooltip" className="absolute right-0 top-8 z-30 w-64 rounded-xl border border-slate-200 bg-white p-3 text-xs leading-relaxed text-slate-700 shadow-lg">
          {text}
        </span>
      )}
    </span>
  );
}

/**
 * Interruptor compacto: nombre, "?" con la explicación y el interruptor en un renglón.
 * Varios seguidos van dentro de <ToggleGrid> para quedar uno al lado del otro.
 */
export function Toggle({ checked, onChange, label, description, id, disabled = false, badge }: {
  checked: boolean; onChange: (v: boolean) => void; label: string; description?: string; id: string;
  /** No se puede cambiar (p. ej. el plan no lo incluye) */
  disabled?: boolean;
  /** Etiqueta junto al nombre (plan, próximamente) */
  badge?: React.ReactNode;
}) {
  return (
    <div className={`flex min-h-[52px] items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2 ${disabled ? 'opacity-75' : 'hover:border-slate-300'}`}>
      <label htmlFor={id} className={`flex min-w-0 flex-1 flex-wrap items-center gap-x-2 gap-y-0.5 text-sm font-semibold leading-snug text-slate-900 ${disabled ? 'cursor-not-allowed' : 'cursor-pointer'}`}>
        {label}{badge}
      </label>
      {description && <InfoTip text={description} label={`${label}: ${t('common:mas_info')}`} />}
      <span className="relative inline-flex shrink-0">
        <input id={id} type="checkbox" role="switch" className="peer sr-only" checked={checked} disabled={disabled} onChange={(e) => onChange(e.target.checked)} />
        <label htmlFor={id} aria-hidden className={`block h-6 w-11 rounded-full bg-slate-300 transition-colors peer-checked:bg-blue-600 peer-focus-visible:ring-2 peer-focus-visible:ring-blue-500/40 ${disabled ? 'cursor-not-allowed' : 'cursor-pointer'}`} />
        <span className="pointer-events-none absolute left-0.5 top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform peer-checked:translate-x-5" />
      </span>
    </div>
  );
}

/** Interruptores uno al lado del otro (1 columna en celular, 2 en tablet, 3 en pantallas anchas) */
export function ToggleGrid({ children, cols = 3 }: { children: React.ReactNode; cols?: 2 | 3 }) {
  return <div className={`grid gap-2.5 sm:grid-cols-2 ${cols === 3 ? 'xl:grid-cols-3' : ''}`}>{children}</div>;
}

export function ChoiceCard({ active, onClick, title, description, icon }: { active: boolean; onClick: () => void; title: string; description?: string; icon?: React.ReactNode }) {
  return (
    <button
      type="button"
      role="radio"
      aria-checked={active}
      onClick={onClick}
      className={`relative text-left p-4 rounded-2xl border-2 transition-all ${
        active ? 'border-blue-600 bg-blue-50 shadow-sm' : 'border-slate-200 bg-white hover:border-slate-300'
      }`}
    >
      {active && (
        <span className="absolute top-3 right-3 w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center">
          <Check className="w-3.5 h-3.5" aria-hidden />
        </span>
      )}
      {icon}
      <span className="block text-sm font-bold text-slate-900 pr-6">{title}</span>
      {description && <span className="block text-xs text-slate-500 mt-1 leading-relaxed">{description}</span>}
    </button>
  );
}
