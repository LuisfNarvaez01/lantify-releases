// ============================================
// PEDIDOS WEB - Lo que piden los clientes desde la página del negocio
// ============================================
// Por aceptar → En preparación → Listo / En camino → Cobrado. Aceptar manda la
// comanda a cocina; cobrar deja la venta en el arqueo abierto con el medio de pago
// que eligió el cliente. Rechazar pide un motivo, que el cliente ve en su enlace.

import { useCallback, useEffect, useState } from 'react';
import { Bike, Store, Phone, MapPin, MessageCircle, Check, X, ChefHat, Wallet, Loader2, Clock, ShoppingBag } from 'lucide-react';
import { onlineOrdersAPI, OnlineOrder, OnlineOrderStatus } from '../../services/api';
import { errorMessage } from '../../services/apiErrors';
import { toast } from '../../shared/toast';
import { reasonDialog, promptDialog } from '../../shared/dialog';
import { useFeature } from '../../shared/plan';
import { PlanLocked } from '../common/PlanLocked';
import { formatCurrency } from '../../shared/formatUtils';
import { whatsappNumber } from '../admin/SuppliersPanel';
import { useOnlineOrdersStore } from '../../store/useOnlineOrdersStore';
import { t, getLocale } from '../../i18n';

const COLUMNS: { key: string; statuses: OnlineOrderStatus[]; tone: string }[] = [
  { key: 'por_aceptar', statuses: ['PENDING'], tone: 'border-amber-300 bg-amber-50' },
  { key: 'en_preparacion', statuses: ['ACCEPTED'], tone: 'border-blue-200 bg-blue-50/50' },
  { key: 'listos', statuses: ['READY'], tone: 'border-emerald-200 bg-emerald-50/50' },
  { key: 'cerrados_hoy', statuses: ['COMPLETED', 'REJECTED', 'CANCELLED'], tone: 'border-slate-200 bg-slate-50' },
];

function OrderCard({ o, businessName, onChanged }: { o: OnlineOrder; businessName: string; onChanged: () => void }) {
  const [busy, setBusy] = useState(false);
  const delivery = o.kind === 'DELIVERY';
  const closed = ['COMPLETED', 'REJECTED', 'CANCELLED'].includes(o.status);
  const minutes = Math.max(0, Math.round((Date.now() - new Date(o.placedAt).getTime()) / 60000));

  const run = async (action: 'accept' | 'reject' | 'ready' | 'complete', body: Record<string, unknown> = {}, ok?: string) => {
    setBusy(true);
    try {
      await onlineOrdersAPI.act(o.id, action, body);
      if (ok) toast.success(ok);
      onChanged();
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusy(false);
    }
  };

  const accept = async () => {
    const eta = await promptDialog({ title: t('orders:aceptar_titulo', { code: o.code }), label: t('orders:tiempo_label'), placeholder: t('orders:tiempo_ej'), confirmLabel: t('orders:aceptar'), required: false });
    if (eta === null) return;
    run('accept', { eta: eta || undefined }, t('orders:aceptado_ok'));
  };
  const reject = async () => {
    const reason = await reasonDialog({ title: t('orders:rechazar_titulo', { code: o.code }), placeholder: t('orders:rechazar_ej'), confirmLabel: t('orders:rechazar') });
    if (reason) run('reject', { reason });
  };

  const waText = t(`orders:wa_${o.status}`, { name: o.customerName.split(' ')[0], business: businessName, code: o.code, defaultValue: '' });

  return (
    <article className={`rounded-2xl border bg-white p-4 space-y-3 shadow-sm ${o.status === 'PENDING' ? 'border-amber-300 ring-2 ring-amber-200' : 'border-slate-200'} ${closed ? 'opacity-75' : ''}`}>
      <header className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="flex items-center gap-2 text-sm font-black text-slate-900">
            <span className={`inline-flex items-center gap-1 rounded-lg px-2 py-0.5 text-[0.7857rem] font-bold ${delivery ? 'bg-violet-100 text-violet-800' : 'bg-sky-100 text-sky-800'}`}>
              {delivery ? <Bike className="w-3.5 h-3.5" aria-hidden /> : <Store className="w-3.5 h-3.5" aria-hidden />}
              {t(delivery ? 'orders:domicilio' : 'orders:recoger')}
            </span>
            <span className="font-mono">{o.code}</span>
          </p>
          <p className="mt-1 text-base font-bold text-slate-900 truncate">{o.customerName}</p>
        </div>
        <span className="shrink-0 inline-flex items-center gap-1 text-xs text-slate-500">
          <Clock className="w-3.5 h-3.5" aria-hidden />
          {minutes < 60 ? t('orders:hace_min', { count: minutes }) : new Date(o.placedAt).toLocaleTimeString(getLocale(), { hour: '2-digit', minute: '2-digit' })}
        </span>
      </header>

      <ul className="text-sm divide-y divide-slate-100">
        {o.items.map((l, i) => (
          <li key={i} className="flex justify-between gap-3 py-1.5">
            <span className="min-w-0"><b className="tabular-nums">{l.qty}×</b> {l.name}{l.note && <span className="block text-xs text-amber-700">{l.note}</span>}</span>
            <span className="shrink-0 tabular-nums text-slate-600">{formatCurrency(l.price * l.qty)}</span>
          </li>
        ))}
      </ul>

      <div className="rounded-xl bg-slate-50 px-3 py-2 text-sm space-y-1">
        {o.deliveryFee > 0 && <p className="flex justify-between text-slate-600"><span>{t('orders:domicilio_valor')}</span><span className="tabular-nums">{formatCurrency(o.deliveryFee)}</span></p>}
        <p className="flex justify-between font-black text-slate-900"><span>{t('orders:total')} · {t(`page:pago_${o.paymentMethod}`)}</span><span className="tabular-nums">{formatCurrency(o.total)}</span></p>
      </div>

      <div className="space-y-1 text-sm text-slate-700">
        {o.address && <p className="flex gap-2"><MapPin className="w-4 h-4 mt-0.5 shrink-0 text-slate-400" aria-hidden />{o.address}</p>}
        {o.notes && <p className="flex gap-2"><MessageCircle className="w-4 h-4 mt-0.5 shrink-0 text-slate-400" aria-hidden />{o.notes}</p>}
        {o.customerPhone && (
          <p className="flex flex-wrap items-center gap-3">
            <a href={`tel:${o.customerPhone}`} className="inline-flex items-center gap-1.5 font-semibold text-blue-700 hover:underline"><Phone className="w-4 h-4" aria-hidden />{o.customerPhone}</a>
            <a href={`https://wa.me/${whatsappNumber(o.customerPhone)}${waText ? `?text=${encodeURIComponent(waText)}` : ''}`} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 font-semibold text-emerald-700 hover:underline">
              <MessageCircle className="w-4 h-4" aria-hidden />WhatsApp
            </a>
          </p>
        )}
        {o.statusNote && <p className="text-xs text-slate-500">{o.status === 'REJECTED' || o.status === 'CANCELLED' ? t('orders:motivo', { note: o.statusNote }) : t('orders:tiempo_dicho', { note: o.statusNote })}</p>}
      </div>

      {!closed && (
        <div className="flex flex-wrap gap-2 pt-1">
          {o.status === 'PENDING' && (
            <button type="button" disabled={busy} onClick={accept} className="flex-1 inline-flex items-center justify-center gap-1.5 min-h-[44px] px-3 rounded-xl bg-blue-600 text-sm font-bold text-white hover:bg-blue-700 disabled:opacity-50">
              {busy ? <Loader2 className="w-4 h-4 animate-spin" aria-hidden /> : <ChefHat className="w-4 h-4" aria-hidden />} {t('orders:aceptar')}
            </button>
          )}
          {o.status === 'ACCEPTED' && (
            <button type="button" disabled={busy} onClick={() => run('ready', {}, t('orders:listo_ok'))} className="flex-1 inline-flex items-center justify-center gap-1.5 min-h-[44px] px-3 rounded-xl bg-emerald-600 text-sm font-bold text-white hover:bg-emerald-700 disabled:opacity-50">
              <Check className="w-4 h-4" aria-hidden /> {t(delivery ? 'orders:en_camino' : 'orders:listo')}
            </button>
          )}
          {(o.status === 'ACCEPTED' || o.status === 'READY') && (
            <button type="button" disabled={busy} onClick={() => run('complete', {}, t('orders:cobrado_ok'))} className={`flex-1 inline-flex items-center justify-center gap-1.5 min-h-[44px] px-3 rounded-xl text-sm font-bold disabled:opacity-50 ${o.status === 'READY' ? 'bg-slate-900 text-white hover:bg-slate-800' : 'border border-slate-200 text-slate-700 hover:bg-slate-50'}`}>
              <Wallet className="w-4 h-4" aria-hidden /> {t('orders:cobrar', { amount: formatCurrency(o.total - o.deliveryFee) })}
            </button>
          )}
          <button type="button" disabled={busy} onClick={reject} className="inline-flex items-center justify-center gap-1.5 min-h-[44px] px-3 rounded-xl border border-rose-200 text-sm font-bold text-rose-700 hover:bg-rose-50 disabled:opacity-50">
            <X className="w-4 h-4" aria-hidden /> {t(o.status === 'PENDING' ? 'orders:rechazar' : 'orders:cancelar')}
          </button>
        </div>
      )}
      {o.status === 'COMPLETED' && <p className="text-xs font-bold text-emerald-700">{t('orders:cobrado')}</p>}
    </article>
  );
}

export function OnlineOrdersModule({ businessName }: { businessName: string }) {
  const hasOrders = useFeature('webstore');
  const version = useOnlineOrdersStore((s) => s.version);
  const refreshBadge = useOnlineOrdersStore((s) => s.refresh);
  const [orders, setOrders] = useState<OnlineOrder[] | null>(null);

  const load = useCallback(async () => {
    try {
      setOrders(await onlineOrdersAPI.list());
    } catch (e) {
      toast.error(errorMessage(e));
      setOrders([]);
    }
    refreshBadge();
  }, [refreshBadge]);

  useEffect(() => {
    if (hasOrders) load();
  }, [hasOrders, load, version]);

  if (!hasOrders) return <PlanLocked feature="webstore" />;
  if (!orders) return <div className="flex justify-center py-20"><Loader2 className="w-6 h-6 animate-spin text-slate-400" aria-hidden /></div>;

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-2xl font-bold text-slate-900 font-heading flex items-center gap-2"><ShoppingBag className="w-6 h-6 text-blue-600" aria-hidden /> {t('orders:titulo')}</h2>
        <p className="mt-1 text-sm text-slate-500 max-w-3xl">{t('orders:bajada')}</p>
      </div>
      {orders.length === 0 ? (
        <div className="rounded-3xl border-2 border-dashed border-slate-200 p-10 text-center text-slate-500">
          <p className="font-bold text-slate-700">{t('orders:vacio')}</p>
          <p className="mt-1 text-sm">{t('orders:vacio_desc')}</p>
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 2xl:grid-cols-4 items-start">
          {COLUMNS.map((col) => {
            const list = orders.filter((o) => col.statuses.includes(o.status));
            return (
              <section key={col.key} className={`rounded-3xl border p-3 space-y-3 ${col.tone}`} aria-label={t(`orders:${col.key}`)}>
                <h3 className="px-1 text-sm font-black text-slate-800 flex items-center justify-between">{t(`orders:${col.key}`)} <span className="tabular-nums text-slate-500">{list.length}</span></h3>
                {list.map((o) => <OrderCard key={o.id} o={o} businessName={businessName} onChanged={load} />)}
              </section>
            );
          })}
        </div>
      )}
    </div>
  );
}
