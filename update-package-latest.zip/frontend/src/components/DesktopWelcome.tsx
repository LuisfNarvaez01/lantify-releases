// Bienvenida de la primera apertura de Lantify.exe en este equipo: qué quedó listo, si se
// trajeron los datos de la instalación anterior, cómo conectar las tablets y cómo se actualiza.
// Después sigue el ingreso normal (vincular el negocio con Lantify Cloud).

import { useEffect, useState } from 'react';
import { ArrowRight, Check, Copy, DatabaseBackup, HardDrive, MonitorSmartphone, PanelBottom, RefreshCw } from 'lucide-react';
import { desktop, DesktopInfo } from '../shared/desktop';
import { LanguageSelector } from './common/LanguageSelector';
import { t } from '../i18n';

interface Row {
  icon: typeof HardDrive;
  title: string;
  body: React.ReactNode;
}

export function DesktopWelcome({ info, onDone }: { info: DesktopInfo; onDone: () => void }) {
  const [copied, setCopied] = useState<string | null>(null);
  const [leaving, setLeaving] = useState(false);

  useEffect(() => {
    if (!copied) return;
    const timer = setTimeout(() => setCopied(null), 1800);
    return () => clearTimeout(timer);
  }, [copied]);

  const copy = (url: string) => {
    void desktop()?.copy(url);
    setCopied(url);
  };

  const finish = async () => {
    setLeaving(true);
    await desktop()?.markWelcomed().catch(() => undefined);
    onDone();
  };

  const folder = info.legacyImport?.from.split(/[\\/]/).filter(Boolean).pop();
  const rows: Row[] = [
    info.legacyImport
      ? {
        icon: DatabaseBackup,
        title: t('desktop:datos_traidos'),
        body: <>{t('desktop:datos_traidos_desc', { folder })}</>,
      }
      : {
        icon: HardDrive,
        title: t('desktop:datos_aqui'),
        body: <>{t('desktop:datos_aqui_desc')} <span className="font-mono text-[0.8571rem] text-slate-500">{info.dataDir}</span></>,
      },
    {
      icon: MonitorSmartphone,
      title: t('desktop:tablets'),
      body: info.lanAccess && info.tabletUrls.length ? (
        <>
          <span>{t('desktop:tablets_desc')}</span>
          <span className="mt-2 flex flex-wrap gap-2">
            {info.tabletUrls.map((url) => (
              <button key={url} type="button" onClick={() => copy(url)}
                className="inline-flex min-h-[36px] items-center gap-2 rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-[0.9286rem] font-semibold text-slate-800 hover:border-blue-300 hover:bg-blue-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600">
                {url}
                {copied === url
                  ? <Check className="h-3.5 w-3.5 text-emerald-600" aria-label={t('desktop:copiado')} />
                  : <Copy className="h-3.5 w-3.5 text-slate-400" aria-hidden />}
              </button>
            ))}
          </span>
        </>
      ) : <>{t('desktop:tablets_sin_red')}</>,
    },
    {
      icon: PanelBottom,
      title: t('desktop:bandeja'),
      body: <>{t('desktop:bandeja_desc')}</>,
    },
    {
      icon: RefreshCw,
      title: t('desktop:actualizaciones'),
      body: <>{t('desktop:actualizaciones_desc')}</>,
    },
  ];

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-slate-950 p-4 font-sans">
      <div className="pointer-events-none absolute inset-0" aria-hidden>
        <div className="absolute -left-40 -top-40 h-[28rem] w-[28rem] rounded-full bg-blue-600/15 blur-3xl" />
        <div className="absolute -bottom-40 -right-32 h-[26rem] w-[26rem] rounded-full bg-cyan-500/10 blur-3xl" />
      </div>

      <main className={`relative w-full max-w-[640px] overflow-hidden rounded-3xl border border-slate-200/80 bg-white shadow-[0_24px_60px_-20px_rgba(2,6,23,0.6)] transition-[opacity,transform] duration-300 ease-out ${leaving ? 'translate-y-1 opacity-0' : ''}`}>
        <header className="relative bg-slate-900 px-8 pb-7 pt-8 text-white sm:px-10">
          <div className="absolute right-4 top-4">
            <LanguageSelector variant="pill" />
          </div>
          <img src="/logo-lantify-white.svg" alt="Lantify" className="h-11 w-auto" />
          <h1 className="mt-6 text-[2rem] font-extrabold leading-tight tracking-[-0.02em] [text-wrap:balance] sm:text-[2.2857rem]">
            {t('desktop:titulo')}
          </h1>
          <p className="mt-2 max-w-[46ch] text-[1.0714rem] leading-relaxed text-slate-300">{t('desktop:subtitulo')}</p>
        </header>

        <ol className="divide-y divide-slate-100 px-8 sm:px-10">
          {rows.map((row, i) => (
            <li key={row.title} className="welcome-row flex gap-4 py-4" style={{ animationDelay: `${120 + i * 90}ms` }}>
              <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-blue-50 text-blue-700">
                <row.icon className="h-[18px] w-[18px]" aria-hidden />
              </span>
              <div className="min-w-0 flex-1">
                <h2 className="text-[1.0714rem] font-bold text-slate-900">{row.title}</h2>
                <p className="mt-0.5 flex flex-col text-sm leading-relaxed text-slate-600">{row.body}</p>
              </div>
            </li>
          ))}
        </ol>

        <footer className="flex flex-col-reverse items-stretch gap-3 border-t border-slate-100 bg-slate-50/70 px-8 py-5 sm:flex-row sm:items-center sm:justify-between sm:px-10">
          <span className="text-center text-xs font-medium tabular-nums text-slate-500 sm:text-left">{t('desktop:version', { value: info.version })}</span>
          <button type="button" onClick={finish} autoFocus
            className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-xl bg-blue-600 px-6 text-sm font-bold text-white shadow-[0_8px_20px_-8px_rgba(37,99,235,0.7)] transition-colors hover:bg-blue-700 active:bg-blue-800 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600">
            {t('desktop:empezar')}
            <ArrowRight className="h-4 w-4" aria-hidden />
          </button>
        </footer>
      </main>
    </div>
  );
}
