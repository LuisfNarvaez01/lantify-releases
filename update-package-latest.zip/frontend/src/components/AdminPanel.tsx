import { PayablesPanel } from './expenses/PayablesPanel';
import { ProductsTabs } from './admin/ProductsTabs';
import { InventoryTabs } from './v3/InventoryTabs';
import { BusinessTabs } from './admin/BusinessTabs';
import { SalonTabs } from './v3/SalonTabs';
import { MenuEnginePanel } from './admin/MenuEnginePanel';
import { Gauge } from 'lucide-react';
import { FeaturesPanel } from './admin/FeaturesPanel';
import { StaffModule } from './admin/StaffModule';
import { useFeatureFlag, useFeatures } from '../shared/features';
import React, { useEffect, useState } from 'react';
import { confirmDialog } from '../shared/dialog';
import { productsAPI } from '../services/api';
import { LayoutDashboard, Package, Grid, Trash2, ArrowLeft, X, Settings, Check, LogOut, Info, Users, Truck, Boxes, Shield, Ticket, Globe, Compass, Building2, Printer, Palette, ShieldCheck, CreditCard, Sparkles, Wrench, Music } from 'lucide-react';
import { SetupGuide } from './admin/SetupGuide';
import { AdminHome } from './admin/AdminHome';
import { useGuideProgress, GuideSection } from '../shared/setupGuide';
import { CustomersAdmin } from './admin/CustomersAdmin';
import { SystemConfigAdmin } from './admin/SystemConfigAdmin';
import { SuppliersModule } from './admin/SuppliersModule';
import { PageModule } from './admin/PageModule';
import { ProyectaPanel } from './admin/ProyectaPanel';
import { CouponsAdmin } from './admin/CouponsAdmin';
import { PlanLocked, LockBadge } from './common/PlanLocked';
import { usePlan } from '../shared/plan';
import { DEFAULT_THEME } from '../shared/themeManager';
import { toast } from '../shared/toast';


import { t } from '../i18n';

interface AdminPanelProps {
  user: any;
  onLogout: () => void;
  onClose?: () => void;
  /** Volver al POS en una pestaña (la guía lleva a la caja) */
  onGoToPos?: (tab: 'cash') => void;
  /** Pestaña con la que abre (p. ej. 'config' para el recorrido de configuración) */
  initialTab?: string;
}

type ConfigSection = 'business' | 'subscription' | 'ai' | 'dian' | 'printers' | 'appearance' | 'maintenance' | 'about';
const CONFIG_SECTIONS: ConfigSection[] = ['subscription', 'ai', 'dian', 'printers', 'appearance', 'maintenance', 'about'];

/** Pestañas de versiones anteriores (y la vieja "Configuración") a la pantalla de hoy */
const tabFromLegacy = (tab?: string) =>
  tab === 'tables' ? 'salon'
    : tab === 'expense-categories' || tab === 'expenses' ? 'suppliers'
      : tab === 'config' ? 'business'
        : tab === 'features' ? 'guide'
        : tab;

interface NavItem { id: string; label: string; icon: React.ElementType; feature?: string }

// Agrupado por lo que el dueño quiere hacer, en el orden en que se configura
const NAV_GROUPS: { id: string; items: NavItem[] }[] = [
  { id: 'empezar', items: [{ id: 'home', label: 'stats:inicio', icon: LayoutDashboard }, { id: 'guide', label: 'admin:guia_configuracion', icon: Compass }] },
  {
    id: 'negocio',
    items: [
      { id: 'business', label: 'admin:datos_del_negocio', icon: Building2 },
      { id: 'salon', label: 'admin:salon_y_mesas', icon: Grid },
      { id: 'users', label: 'admin:usuarios_y_roles', icon: Shield },
      { id: 'printers', label: 'admin:impresion', icon: Printer },
      { id: 'appearance', label: 'admin:apariencia', icon: Palette },
    ],
  },
  {
    id: 'carta',
    items: [
      { id: 'products', label: 'admin:productos', icon: Package },
      { id: 'inventory', label: 'admin:inventario', icon: Boxes },
      { id: 'menu-engine', label: 'v3:me_titulo', icon: Gauge, feature: 'autopilot' },
      { id: 'suppliers', label: 'admin:proveedores_y_gastos', icon: Truck },
    ],
  },
  {
    id: 'clientes',
    items: [
      { id: 'customers', label: 'admin:clientes', icon: Users, feature: 'customers' },
      { id: 'coupons', label: 'admin:cupones', icon: Ticket, feature: 'coupons' },
      { id: 'page', label: 'admin:mi_pagina_fidelidad', icon: Globe },
      { id: 'proyecta', label: 'proyecta:menu', icon: Music },
    ],
  },
  {
    id: 'cuenta',
    items: [
      { id: 'dian', label: 'admin:facturacion_dian', icon: ShieldCheck, feature: 'dian' },
      { id: 'subscription', label: 'admin:plan_y_suscripcion', icon: CreditCard },
      { id: 'ai', label: 'admin:asistente_ia', icon: Sparkles },
      { id: 'maintenance', label: 'admin:mantenimiento', icon: Wrench },
      { id: 'about', label: 'admin:acerca_de', icon: Info },
    ],
  },
];

export function AdminPanel({ user, onLogout, onClose, onGoToPos, initialTab }: AdminPanelProps) {
  const plan = usePlan();
  const staffOn = useFeatureFlag('staff');
  useEffect(() => { useFeatures.getState().load(); }, []);
  // 'tables' era la pestaña anterior de mesas: hoy vive en Salón y mesas
  const guide = useGuideProgress();
  const [navQuery, setNavQuery] = useState('');
  const norm = (v: string) => v.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  const navLabel = (item: NavItem) => (item.id === 'users' && staffOn ? t('v3:personal') : t(item.label));
  const navGroups = NAV_GROUPS
    .map((g) => ({ ...g, items: g.items.filter((it) => !navQuery.trim() || norm(navLabel(it)).includes(norm(navQuery.trim()))) }))
    .filter((g) => g.items.length > 0);
  const [activeTab, setActiveTab] = useState<string>(() => tabFromLegacy(initialTab) || 'home');
  // Un paso de la guía lleva a su pantalla (o al POS, para la caja)
  const goTo = (section: GuideSection) => {
    if (section === 'pos-cash') {
      if (onGoToPos) onGoToPos('cash');
      else onClose?.();
      return;
    }
    setActiveTab(section);
  };
  // Estado para limpieza de duplicados
  const [showDuplicatesModal, setShowDuplicatesModal] = useState(false);
  const [duplicateGroups, setDuplicateGroups] = useState<any[]>([]);
  const [isSearchingDuplicates, setIsSearchingDuplicates] = useState(false);
  const [isCleaningDuplicates, setIsCleaningDuplicates] = useState(false);
  const [cleanupResult, setCleanupResult] = useState<any>(null);
  
  // Estado para configuración
  const [config, setConfig] = useState(() => {
    const saved = localStorage.getItem('posConfig');
    return saved ? JSON.parse(saved) : {
      businessName: t('admin:lantify_pos'),
      address: '',
      phone: '',
      taxRate: 19,
      nit: '',
      receiptTemplate: t('admin:businessname_address_phone_mesa_table_fecha_date'),
      kitchenTemplate: t('admin:comanda_mesa_table_hora_time_items'),
      receiptFont: 'sans-serif',
      receiptLogo: '/logo-lantify.svg',
      invoicePrinter: t('admin:impresora_termica'),
      kitchenPrinter: t('admin:impresora_cocina'),
      paperWidth: '80mm',
      receiptMargin: '2mm',
      fontSizeTicket: 'medium',
      ticketFooterText: t('admin:gracias_por_su_visita'),
      theme: DEFAULT_THEME
    };
  });

  
  const handleFindDuplicates = async () => {
    setIsSearchingDuplicates(true);
    setCleanupResult(null);
    try {
      const data = await productsAPI.getDuplicates();
      setDuplicateGroups(data);
      setShowDuplicatesModal(true);
    } catch (err) {
      console.error('Error finding duplicates:', err);
      toast.error('Error al buscar duplicados');
    } finally {
      setIsSearchingDuplicates(false);
    }
  };

  const handleCleanupDuplicates = async () => {
    if (!(await confirmDialog({ title: t('admin:fusionar_value_productos_duplicados', { value: duplicateGroups.reduce((acc, g) => acc + g.count - 1, 0) }), message: t('admin:se_conservara_la_version_mas_completa_de'), confirmLabel: t('admin:fusionar'), tone: 'danger' }))) return;
    
    setIsCleaningDuplicates(true);
    try {
      const keys = duplicateGroups.map(g => g.key);
      const result = await productsAPI.cleanupDuplicates(keys);
      setCleanupResult(result);
      toast.success(t('admin:limpieza_de_duplicados_completada'));
      // Recargar duplicados para mostrar que ya no hay
      const newData = await productsAPI.getDuplicates();
      setDuplicateGroups(newData);
    } catch (err) {
      console.error('Error cleaning up duplicates:', err);
      toast.error('Error al limpiar duplicados');
    } finally {
      setIsCleaningDuplicates(false);
    }
  };

  return (
    <div className="h-screen flex flex-col overflow-hidden bg-slate-100 font-sans" style={{ height: 'var(--app-h, 100dvh)' }}>
      {/* Branded Header (en el celular: solo el botón de volver con flecha y el título corto) */}
      <header className="z-20 shrink-0 border-b border-white/5 bg-slate-950">
        <div className="mx-auto flex h-14 max-w-7xl items-center justify-between gap-2 px-2 sm:px-4">
          <div className="flex min-w-0 items-center gap-2 sm:gap-4">
            {onClose && (
              <button
                onClick={onClose}
                aria-label={t('admin:volver_al_pos')}
                className="inline-flex h-10 shrink-0 items-center gap-2 rounded-full bg-white/[0.06] px-3 text-[0.8125rem] font-medium text-white/80 transition-colors duration-fast hover:bg-white/10 hover:text-white sm:h-9 sm:pl-2.5 sm:pr-3.5"
              >
                <ArrowLeft className="h-4 w-4" aria-hidden />
                <span className="hidden sm:inline">{t('admin:volver_al_pos')}</span>
              </button>
            )}
            <div className="flex min-w-0 items-center gap-3">
              <div className="hidden h-9 w-9 place-items-center rounded-full bg-white/10 text-white sm:grid">
                <Settings className="h-4 w-4" aria-hidden />
              </div>
              <div className="min-w-0">
                <h1 className="truncate text-base font-semibold tracking-tight text-white">{t('admin:administracion_lantify')}</h1>
                <p className="hidden truncate text-xs text-white/50 sm:block">{t('admin:gestion_de_catalogo_mesas_y_parametros')}</p>
              </div>
            </div>
          </div>
          <div className="flex shrink-0 items-center gap-2 sm:gap-4">
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-slate-800 rounded-xl border border-slate-700/60">
              <div className="w-7 h-7 rounded-full bg-blue-600 flex items-center justify-center">
                <span className="text-xs font-semibold text-white">
                  {user.name?.charAt(0)?.toUpperCase()}
                </span>
              </div>
              <span className="max-w-[150px] truncate text-[0.8125rem] font-medium text-slate-200">
                {user.name}
              </span>
            </div>
            <button
              onClick={onLogout}
              className="p-2 text-slate-400 hover:text-rose-300 hover:bg-rose-950/40 rounded-xl transition-colors border border-slate-800"
              title={t('admin:cerrar_sesion')}
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      <div className="flex-1 min-h-0 flex flex-col lg:flex-row">
        {/* Menú agrupado: en pantallas grandes a la izquierda, en tablets arriba */}
        <nav
          data-guide="settings-tabs"
          aria-label={t('admin:menu_administracion')}
          className="relative bg-slate-950 border-b lg:border-b-0 lg:border-r border-slate-800 lg:w-64 shrink-0 overflow-x-auto lg:overflow-y-auto"
        >
          <div className="flex lg:flex-col gap-1 lg:gap-5 p-2 lg:p-4 min-w-max lg:min-w-0">
            <div className="hidden lg:block">
              <label htmlFor="admin-search" className="sr-only">{t('admin:buscar_ajuste')}</label>
              <input
                id="admin-search"
                type="search"
                value={navQuery}
                onChange={(e) => setNavQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && navGroups[0]?.items[0]) { setActiveTab(navGroups[0].items[0].id); setNavQuery(''); }
                  if (e.key === 'Escape') setNavQuery('');
                }}
                placeholder={t('admin:buscar_ajuste')}
                className="h-9 w-full rounded-[10px] bg-white/[0.06] px-3 text-[0.8125rem] text-white placeholder:text-white/40 focus:bg-white/10 focus:outline-none focus:ring-2 focus:ring-blue-500/60"
              />
              {navQuery && navGroups.length === 0 && <p className="px-1 pt-2 text-xs text-white/50">{t('admin:sin_ajustes')}</p>}
            </div>
            {navGroups.map((group) => (
              <div key={group.id} className="flex lg:flex-col gap-1 lg:gap-0.5 items-center lg:items-stretch">
                <p className="hidden px-3 pb-1 text-xs font-medium text-slate-500 lg:block">{t(`admin:grupo_${group.id}`)}</p>
                {group.items.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.id;
                  const isLocked = !!item.feature && !plan.has(item.feature);
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setActiveTab(item.id)}
                      aria-current={isActive ? 'page' : undefined}
                      className={`flex items-center gap-2.5 whitespace-nowrap rounded-[10px] px-3 py-2 text-[0.8125rem] font-medium transition-colors duration-fast ${
                        isActive ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                      }`}
                    >
                      <Icon className="w-4 h-4 shrink-0" aria-hidden />
                      <span className="flex-1 text-left">{navLabel(item)}</span>
                      {item.id === 'guide' && !guide.progress.complete && guide.progress.total > 0 && (
                        <span className={`text-[0.7143rem] tabular-nums px-1.5 py-0.5 rounded-full ${isActive ? 'bg-white/20' : 'bg-slate-800 text-slate-300'}`}>
                          {guide.progress.done}/{guide.progress.total}
                        </span>
                      )}
                      {isLocked && <LockBadge />}
                    </button>
                  );
                })}
              </div>
            ))}
          </div>
        </nav>

        {/* Contenido */}
        <div className="relative flex-1 min-w-0 overflow-y-auto custom-scrollbar">
          <div className="max-w-6xl mx-auto px-4 py-8">
            {activeTab === 'home' && <AdminHome userName={user.name} onOpenGuide={() => setActiveTab('guide')} />}
            {activeTab === 'guide' && <SetupGuide onGo={goTo} />}
            {activeTab === 'products' && <ProductsTabs />}
            {activeTab === 'salon' && <SalonTabs />}
            {CONFIG_SECTIONS.includes(activeTab as ConfigSection) && (
              <SystemConfigAdmin
                key={activeTab}
                section={activeTab as ConfigSection}
                config={config}
                setConfig={setConfig}
                onFindDuplicates={handleFindDuplicates}
                isSearchingDuplicates={isSearchingDuplicates}
              />
            )}
            {activeTab === 'customers' && (plan.has('customers') ? <CustomersAdmin /> : <PlanLocked feature="customers" />)}
            {activeTab === 'suppliers' && <div className="space-y-6"><PayablesPanel /><SuppliersModule /></div>}
            {activeTab === 'coupons' && <CouponsAdmin />}
            {activeTab === 'menu-engine' && <MenuEnginePanel />}
            {activeTab === 'page' && <PageModule />}
            {activeTab === 'proyecta' && <ProyectaPanel />}
            {activeTab === 'inventory' && <div className="space-y-6"><FeaturesPanel place="inventory" /><InventoryTabs /></div>}
            {activeTab === 'users' && <div className="space-y-6"><FeaturesPanel place="users" /><StaffModule currentUser={user} /></div>}
            {activeTab === 'business' && (
              <BusinessTabs
                onGo={setActiveTab}
                onSaved={(b) => setConfig((c: any) => ({
                  ...c,
                  businessName: b.businessName,
                  address: [b.address, b.city].filter(Boolean).join(', '),
                  phone: b.phone || '',
                  nit: b.nit ? (b.dv ? `${b.nit}-${b.dv}` : b.nit) : '',
                }))}
              />
            )}
          </div>
        </div>
      </div>

      {/* Duplicates Modal */}
      {showDuplicatesModal && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center z-[120] p-4">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden border border-slate-200 flex flex-col">
            <div className="bg-slate-900 px-8 py-5 flex justify-between items-center text-white shrink-0">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-rose-600 rounded-xl text-white shadow-sm">
                  <Trash2 className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold font-heading">{t('admin:gestion_de_duplicados_en_inventario')}</h3>
              </div>
              <button
                onClick={() => setShowDuplicatesModal(false)}
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-8 space-y-6">
              {cleanupResult && (
                <div className="p-5 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center gap-4">
                  <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center text-white shrink-0">
                    <Check className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="font-bold text-emerald-900 text-base">{t('admin:limpieza_completada')}</p>
                    <p className="text-emerald-700 text-xs font-medium">{t('admin:se_han_fusionado_eliminado_count_productos_repetid', { count: cleanupResult.count })}</p>
                  </div>
                </div>
              )}

              {duplicateGroups.length === 0 ? (
                <div className="text-center py-20 bg-slate-50 rounded-3xl border-2 border-dashed border-slate-200">
                  <Check className="w-16 h-16 text-emerald-500 mx-auto mb-3 opacity-60" />
                  <p className="text-xl font-bold text-slate-900">{t('admin:no_se_encontraron_duplicados')}</p>
                  <p className="text-slate-500 text-xs font-medium mt-1">{t('admin:el_catalogo_esta_limpio_y_optimizado')}</p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="bg-amber-50 border border-amber-200 p-4 rounded-2xl text-amber-900 font-medium text-xs flex items-start gap-3">
                    <Info className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                    <span>{t('admin:se_han_detectado_length_grupos_de_productos', { length: duplicateGroups.length })}</span>
                  </div>
                  
                  <div className="space-y-3">
                    {duplicateGroups.map((group) => (
                      <div key={group.key} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div>
                          <div className="flex items-center gap-2">
                             <h5 className="font-bold text-base text-slate-900">{group.name}</h5>
                             <span className="bg-slate-100 text-slate-700 text-xs px-2 py-0.5 rounded-lg font-bold uppercase">{group.categoryName}</span>
                          </div>
                          <p className="text-xs text-slate-500 font-medium mt-1">
                            {t('admin:count_versiones_encontradas', { count: group.count })}{' '}{group.items.reduce((acc: number, item: any) => acc + item.variantsCount, 0)}{' '}{t('admin:variantes_totales')}
                          </p>
                          <div className="flex gap-2 mt-3 overflow-x-auto pb-1">
                            {group.items.map((item: any, _idx: number) => (
                              <div key={item.id} className={`text-xs px-2.5 py-1 rounded-lg border shrink-0 font-mono ${item.isActive ? 'bg-emerald-50 border-emerald-200 text-emerald-700' : 'bg-slate-50 border-slate-200 text-slate-400'}`}>
                                {t('admin:id')}{item.id.slice(-6)} {item.isActive ? t('admin:activo') : t('admin:oculto')}
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="p-6 bg-slate-50 border-t border-slate-200 flex justify-between gap-4 shrink-0">
               <button
                onClick={() => setShowDuplicatesModal(false)}
                className="px-6 py-3 bg-white text-slate-700 rounded-xl font-bold hover:bg-slate-100 transition-all border border-slate-300 text-sm"
              >
                {t('admin:cerrar')}
              </button>
              {duplicateGroups.length > 0 && (
                <button
                  onClick={handleCleanupDuplicates}
                  disabled={isCleaningDuplicates}
                  className="flex-1 bg-rose-600 text-white px-6 py-3 rounded-xl font-bold text-sm shadow-sm hover:bg-rose-700 active:scale-95 transition-all disabled:opacity-50"
                >
                  {isCleaningDuplicates ? t('admin:procesando') : t('admin:fusionar_y_limpiar_length_grupos', { length: duplicateGroups.length })}
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
