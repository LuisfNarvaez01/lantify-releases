// ============================================
// RESERVAS - Agenda del día
// ============================================
// Lo que llega por WhatsApp o teléfono se agenda aquí; lo de la página pública
// llega solo. Una mesa nunca queda con dos reservas a la misma hora (lo revisa
// el servidor). Desde cada reserva: confirmar, llegó, no llegó, cancelar,
// reprogramar y avisarle al cliente por WhatsApp.

import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  CalendarDays, ChevronLeft, ChevronRight, Plus, Settings2, Users, MessageCircle, Phone, Store, Globe, Pencil,
  Check, X, UserCheck, UserX, AlertTriangle, RotateCcw, Loader2,
} from 'lucide-react';
import { reservationsAPI, Reservation, BookingConfig, ReservationChannel } from '../../services/api';
import { errorMessage } from '../../services/apiErrors';
import { toast } from '../../shared/toast';
import { reasonDialog } from '../../shared/dialog';
import { useFeature } from '../../shared/plan';
import { PlanLocked } from '../common/PlanLocked';
import { whatsappNumber } from '../admin/SuppliersPanel';
import { useReservationsStore } from '../../store/useReservationsStore';
import { ReservationForm } from './ReservationForm';
import { ReservationSettingsPanel } from './ReservationSettingsPanel';
import { t, getLocale } from '../../i18n';

const todayLocal = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};
const shiftDate = (date: string, days: number) => {
  const d = new Date(`${date}T12:00:00`);
  d.setDate(d.getDate() + days);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

const isAdminUser = () => {
  try {
    return JSON.parse(localStorage.getItem('user') || '{}')?.role === 'ADMIN';
  } catch {
    return false;
  }
};

const CHANNEL_ICON: Record<ReservationChannel, typeof Phone> = {
  POS: Store,
  WALK_IN: Store,
  PHONE: Phone,
  WHATSAPP: MessageCircle,
  ONLINE: Globe,
};

const STATUS_STYLE: Record<string, string> = {
  PENDING: 'bg-amber-100 text-amber-800 border-amber-200',
  CONFIRMED: 'bg-blue-50 text-blue-700 border-blue-200',
  SEATED: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  CANCELLED: 'bg-slate-100 text-slate-500 border-slate-200',
  NO_SHOW: 'bg-rose-50 text-rose-700 border-rose-200',
};

/** Mensaje de WhatsApp para el cliente según el estado de su reserva */
export const reservationMessage = (r: Reservation, businessName: string) => {
  const when = new Date(`${r.date}T12:00:00`).toLocaleDateString(getLocale(), { weekday: 'long', day: 'numeric', month: 'long' });
  if (r.status === 'CANCELLED') return t('reservations:wa_cancelada', { name: r.customerName.split(' ')[0], business: businessName, when, time: r.time });
  return t('reservations:wa_confirmada', {
    name: r.customerName.split(' ')[0],
    business: businessName,
    when,
    time: r.time,
    count: r.partySize,
    table: r.table ? t('reservations:wa_mesa', { table: r.table.number }) : '',
    code: r.code,
  });
};

function ReservationCard({ r, businessName, onChanged, onEdit }: { r: Reservation; businessName: string; onChanged: () => void; onEdit: () => void }) {
  const [busy, setBusy] = useState(false);
  const Icon = CHANNEL_ICON[r.channel] || Store;
  const inactive = r.status === 'CANCELLED' || r.status === 'NO_SHOW';

  const setStatus = async (status: string) => {
    let cancelReason: string | null | undefined;
    if (status === 'CANCELLED') {
      cancelReason = await reasonDialog({ title: t('reservations:cancelar_titulo', { name: r.customerName, time: r.time }), placeholder: t('reservations:cancelar_ej') });
      if (!cancelReason) return;
    }
    setBusy(true);
    try {
      await reservationsAPI.update(r.id, { status, ...(cancelReason ? { cancelReason } : {}) });
      onChanged();
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusy(false);
    }
  };

  const action = (label: string, onClick: () => void, Ico: typeof Check, tone = 'text-slate-700 border-slate-200 hover:bg-slate-50') => (
    <button type="button" disabled={busy} onClick={onClick} className={`inline-flex items-center gap-1.5 min-h-[36px] px-3 rounded-xl border text-xs font-bold disabled:opacity-50 ${tone}`}>
      <Ico className="w-3.5 h-3.5" aria-hidden /> {label}
    </button>
  );

  return (
    <li className={`rounded-2xl border bg-white p-4 flex flex-col sm:flex-row gap-4 ${inactive ? 'opacity-60' : ''} ${r.cloudConflict ? 'border-amber-300' : 'border-slate-200'}`}>
      <div className="sm:w-20 shrink-0 flex sm:flex-col items-baseline sm:items-start gap-2 sm:gap-0">
        <span className="text-2xl font-black text-slate-900 tabular-nums leading-none">{r.time}</span>
        <span className="text-xs font-semibold text-slate-500 tabular-nums">{t('reservations:hasta', { time: r.endTime })}</span>
      </div>

      <div className="flex-1 min-w-0 space-y-1.5">
        <div className="flex flex-wrap items-center gap-2">
          <span className={`text-base font-black text-slate-900 ${inactive ? 'line-through' : ''}`}>{r.customerName}</span>
          <span className={`px-2 py-0.5 rounded-full border text-[11px] font-black uppercase tracking-wide ${STATUS_STYLE[r.status]}`}>{t(`reservations:estado_${r.status}`)}</span>
          {r.customer && <span className="text-[11px] font-bold text-violet-700 bg-violet-50 px-2 py-0.5 rounded-full">{t('reservations:cliente_registrado')}</span>}
        </div>
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs font-semibold text-slate-600">
          <span className="inline-flex items-center gap-1"><Users className="w-3.5 h-3.5" aria-hidden />{t('reservations:personas', { count: r.partySize })}</span>
          <span>{r.table ? t('reservations:mesa_n', { table: r.table.number }) + (r.table.zone ? ` · ${r.table.zone}` : '') : t('reservations:sin_mesa')}</span>
          <span className="inline-flex items-center gap-1"><Icon className="w-3.5 h-3.5" aria-hidden />{t(`reservations:canal_${r.channel}`)}</span>
          {r.customerPhone && <span className="tabular-nums">{r.customerPhone}</span>}
          <span className="font-mono text-slate-400">{r.code}</span>
        </div>
        {r.notes && <p className="text-xs text-slate-600 italic">“{r.notes}”</p>}
        {r.status === 'CANCELLED' && r.cancelReason && <p className="text-xs text-slate-500">{t('reservations:motivo_cancelacion', { reason: r.cancelReason })}</p>}
        {r.cloudConflict && !inactive && (
          <p className="flex items-center gap-1.5 text-xs font-semibold text-amber-800">
            <AlertTriangle className="w-3.5 h-3.5" aria-hidden />{t('reservations:conflicto')}
          </p>
        )}
      </div>

      <div className="flex flex-wrap content-start gap-1.5 shrink-0 sm:max-w-[19rem] sm:justify-end">
        {r.status === 'PENDING' && action(t('reservations:confirmar'), () => setStatus('CONFIRMED'), Check, 'text-white bg-emerald-600 border-emerald-600 hover:bg-emerald-700')}
        {r.status === 'CONFIRMED' && action(t('reservations:llego'), () => setStatus('SEATED'), UserCheck, 'text-white bg-blue-600 border-blue-600 hover:bg-blue-700')}
        {r.status === 'CONFIRMED' && action(t('reservations:no_llego'), () => setStatus('NO_SHOW'), UserX)}
        {(r.status === 'PENDING' || r.status === 'CONFIRMED') && action(t('reservations:editar'), onEdit, Pencil)}
        {(r.status === 'PENDING' || r.status === 'CONFIRMED') && action(t('reservations:cancelar'), () => setStatus('CANCELLED'), X, 'text-rose-700 border-rose-200 hover:bg-rose-50')}
        {inactive && action(t('reservations:reactivar'), () => setStatus('CONFIRMED'), RotateCcw)}
        {r.customerPhone && (r.status === 'CONFIRMED' || r.status === 'CANCELLED') && (
          <a
            href={`https://wa.me/${whatsappNumber(r.customerPhone)}?text=${encodeURIComponent(reservationMessage(r, businessName))}`}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1.5 min-h-[36px] px-3 rounded-xl border border-emerald-200 text-xs font-bold text-emerald-700 hover:bg-emerald-50"
          >
            <MessageCircle className="w-3.5 h-3.5" aria-hidden /> {t('reservations:avisar_whatsapp')}
          </a>
        )}
      </div>
    </li>
  );
}

export function ReservationsModule({ businessName }: { businessName: string }) {
  const hasFeature = useFeature('reservations');
  const isAdmin = isAdminUser();
  const [date, setDate] = useState(todayLocal);
  const [list, setList] = useState<Reservation[] | null>(null);
  const [config, setConfig] = useState<BookingConfig | null>(null);
  const [form, setForm] = useState<{ edit?: Reservation } | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const version = useReservationsStore((s) => s.version);
  const refreshBadge = useReservationsStore((s) => s.refresh);

  const load = useCallback(async () => {
    try {
      const [rows, cfg] = await Promise.all([reservationsAPI.list(date), reservationsAPI.settings()]);
      setList(rows);
      setConfig(cfg);
    } catch (e) {
      toast.error(errorMessage(e));
      setList([]);
    }
  }, [date]);

  useEffect(() => {
    if (hasFeature) load();
  }, [load, hasFeature, version]);

  const changed = () => {
    load();
    refreshBadge();
  };

  const stats = useMemo(() => {
    const active = (list || []).filter((r) => r.status !== 'CANCELLED' && r.status !== 'NO_SHOW');
    return {
      count: active.length,
      people: active.reduce((n, r) => n + r.partySize, 0),
      pending: active.filter((r) => r.status === 'PENDING').length,
      seated: active.filter((r) => r.status === 'SEATED').length,
    };
  }, [list]);

  if (!hasFeature) return <PlanLocked feature="reservations" />;

  const dayLabel = new Date(`${date}T12:00:00`).toLocaleDateString(getLocale(), { weekday: 'long', day: 'numeric', month: 'long' });
  const enabled = !!config?.settings.enabled;

  return (
    <div className="max-w-5xl mx-auto space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-900 font-heading flex items-center gap-2">
            <CalendarDays className="w-6 h-6 text-blue-600" aria-hidden /> {t('reservations:titulo')}
          </h2>
          <p className="text-sm text-slate-500 mt-1">{t('reservations:bajada')}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {isAdmin && (
            <button type="button" onClick={() => setShowSettings(true)} className="inline-flex items-center gap-2 min-h-[44px] px-4 rounded-xl border border-slate-200 bg-white text-sm font-bold text-slate-700 hover:bg-slate-50">
              <Settings2 className="w-4 h-4" aria-hidden /> {t('reservations:configurar')}
            </button>
          )}
          {enabled && (
            <button type="button" onClick={() => setForm({})} className="inline-flex items-center gap-2 min-h-[44px] px-5 rounded-xl bg-blue-600 text-sm font-bold text-white shadow-sm hover:bg-blue-700">
              <Plus className="w-4 h-4" aria-hidden /> {t('reservations:nueva')}
            </button>
          )}
        </div>
      </div>

      {config && !enabled ? (
        <div className="rounded-3xl border border-dashed border-slate-300 bg-white px-6 py-14 text-center">
          <CalendarDays className="mx-auto w-10 h-10 text-slate-300" aria-hidden />
          <p className="mt-3 font-bold text-slate-800">{t('reservations:inactivo_titulo')}</p>
          <p className="mt-1 text-sm text-slate-500 max-w-md mx-auto">{isAdmin ? t('reservations:inactivo_admin') : t('reservations:inactivo_equipo')}</p>
          {isAdmin && (
            <button type="button" onClick={() => setShowSettings(true)} className="mt-5 inline-flex items-center gap-2 min-h-[44px] px-5 rounded-xl bg-blue-600 text-sm font-bold text-white hover:bg-blue-700">
              <Settings2 className="w-4 h-4" aria-hidden /> {t('reservations:activar')}
            </button>
          )}
        </div>
      ) : (
        <>
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white p-2">
            <div className="flex items-center gap-1">
              <button type="button" onClick={() => setDate(shiftDate(date, -1))} className="p-2.5 rounded-xl text-slate-600 hover:bg-slate-100" aria-label={t('reservations:dia_anterior')}>
                <ChevronLeft className="w-4 h-4" />
              </button>
              <input type="date" value={date} onChange={(e) => e.target.value && setDate(e.target.value)} className="px-3 py-2 rounded-xl border border-slate-200 text-sm font-bold text-slate-800" aria-label={t('reservations:fecha')} />
              <button type="button" onClick={() => setDate(shiftDate(date, 1))} className="p-2.5 rounded-xl text-slate-600 hover:bg-slate-100" aria-label={t('reservations:dia_siguiente')}>
                <ChevronRight className="w-4 h-4" />
              </button>
              {date !== todayLocal() && (
                <button type="button" onClick={() => setDate(todayLocal())} className="ml-1 px-3 py-2 rounded-xl text-xs font-bold text-blue-700 hover:bg-blue-50">
                  {t('reservations:hoy')}
                </button>
              )}
              <span className="ml-2 hidden md:inline text-sm font-semibold text-slate-500 first-letter:uppercase">{dayLabel}</span>
            </div>
            <dl className="flex gap-4 px-2 text-xs">
              <div><dt className="font-semibold text-slate-500">{t('reservations:reservas')}</dt><dd className="text-lg font-black text-slate-900 tabular-nums">{stats.count}</dd></div>
              <div><dt className="font-semibold text-slate-500">{t('reservations:personas_label')}</dt><dd className="text-lg font-black text-slate-900 tabular-nums">{stats.people}</dd></div>
              <div><dt className="font-semibold text-amber-700">{t('reservations:por_confirmar')}</dt><dd className="text-lg font-black text-amber-700 tabular-nums">{stats.pending}</dd></div>
              <div><dt className="font-semibold text-emerald-700">{t('reservations:llegaron')}</dt><dd className="text-lg font-black text-emerald-700 tabular-nums">{stats.seated}</dd></div>
            </dl>
          </div>

          {!list ? (
            <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-slate-400" aria-hidden /></div>
          ) : list.length === 0 ? (
            <div className="rounded-3xl border border-dashed border-slate-300 bg-white px-6 py-14 text-center">
              <p className="font-bold text-slate-700">{t('reservations:dia_vacio')}</p>
              <p className="mt-1 text-sm text-slate-500">{t('reservations:dia_vacio_desc')}</p>
            </div>
          ) : (
            <ul className="space-y-2.5">
              {list.map((r) => (
                <ReservationCard key={r.id} r={r} businessName={businessName} onChanged={changed} onEdit={() => setForm({ edit: r })} />
              ))}
            </ul>
          )}
        </>
      )}

      {form && config && (
        <ReservationForm
          config={config}
          date={date}
          edit={form.edit}
          onClose={() => setForm(null)}
          onSaved={(r) => {
            setForm(null);
            if (r.date !== date) setDate(r.date);
            else changed();
            toast.success(t('reservations:guardada', { name: r.customerName, time: r.time, table: r.table?.number ?? '—' }));
          }}
        />
      )}
      {showSettings && (
        <ReservationSettingsPanel
          onClose={() => setShowSettings(false)}
          onSaved={(cfg) => {
            setConfig(cfg);
            setShowSettings(false);
            changed();
          }}
        />
      )}
    </div>
  );
}
