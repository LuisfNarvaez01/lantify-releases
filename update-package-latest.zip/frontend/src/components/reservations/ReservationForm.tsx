// ============================================
// RESERVAS - Nueva reserva / reprogramar
// ============================================
// Para lo que llega por WhatsApp, teléfono o en persona. Muestra las horas del
// horario con mesa libre para ese grupo; la caja también puede escribir otra
// hora. El servidor vuelve a revisar que la mesa no tenga otra reserva.

import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { X, Minus, Plus, MessageCircle, Phone, Store } from 'lucide-react';
import { reservationsAPI, Reservation, BookingConfig } from '../../services/api';
import { errorMessage } from '../../services/apiErrors';
import { useFeature } from '../../shared/plan';
import { t } from '../../i18n';

const inputCls = 'w-full min-h-[44px] px-3 rounded-xl border border-slate-200 bg-white text-sm text-slate-900 focus:outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20';
const labelCls = 'text-xs font-bold text-slate-600';
const CHANNELS = [
  { id: 'WHATSAPP', icon: MessageCircle },
  { id: 'PHONE', icon: Phone },
  { id: 'WALK_IN', icon: Store },
] as const;

interface Props {
  config: BookingConfig;
  date: string;
  edit?: Reservation;
  onClose: () => void;
  onSaved: (r: Reservation) => void;
}

export function ReservationForm({ config, date: initialDate, edit, onClose, onSaved }: Props) {
  const hasCustomers = useFeature('customers');
  const [name, setName] = useState(edit?.customerName ?? '');
  const [phone, setPhone] = useState(edit?.customerPhone ?? '');
  const [party, setParty] = useState(edit?.partySize ?? 2);
  const [date, setDate] = useState(edit?.date ?? initialDate);
  const [time, setTime] = useState(edit?.time ?? '');
  const [tableId, setTableId] = useState(edit?.tableId ?? '');
  const [channel, setChannel] = useState<string>(edit?.channel && edit.channel !== 'ONLINE' && edit.channel !== 'POS' ? edit.channel : 'WHATSAPP');
  const [notes, setNotes] = useState(edit?.notes ?? '');
  const [saveCustomer, setSaveCustomer] = useState(false);
  const [slots, setSlots] = useState<{ time: string; available: boolean }[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    reservationsAPI.availability(date, party).then(setSlots).catch(() => setSlots([]));
  }, [date, party]);
  useEffect(() => setError(''), [name, phone, party, date, time, tableId]);

  const tables = [...config.tables].sort((a, b) => Number(b.reservable) - Number(a.reservable) || a.number.localeCompare(b.number, 'es', { numeric: true }));

  const save = async () => {
    if (!name.trim()) return setError(t('reservations:error_nombre'));
    if (!/^\d{2}:\d{2}$/.test(time)) return setError(t('reservations:error_hora'));
    setSaving(true);
    try {
      const body: Record<string, unknown> = {
        customerName: name,
        customerPhone: phone || null,
        partySize: party,
        date,
        time,
        notes: notes || null,
      };
      // Al editar, "automática" conserva la mesa salvo que no sirva; se manda solo si cambió
      if (!edit || tableId !== (edit.tableId ?? '')) body.tableId = tableId || null;
      const saved = edit
        ? await reservationsAPI.update(edit.id, body)
        : await reservationsAPI.create({ ...body, channel, saveCustomer: hasCustomers && saveCustomer });
      onSaved(saved);
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setSaving(false);
    }
  };

  return createPortal(
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/50 p-4" role="dialog" aria-modal="true" aria-labelledby="reservation-form-title">
      <div className="w-full max-w-2xl max-h-[92vh] overflow-y-auto rounded-3xl bg-white shadow-2xl">
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-slate-100 bg-white px-6 py-4">
          <div>
            <h3 id="reservation-form-title" className="text-lg font-black text-slate-900">{edit ? t('reservations:editar_titulo', { code: edit.code }) : t('reservations:nueva')}</h3>
            <p className="text-xs text-slate-500">{t('reservations:form_desc')}</p>
          </div>
          <button type="button" onClick={onClose} className="p-2 rounded-xl text-slate-400 hover:bg-slate-100 hover:text-slate-700" aria-label={t('common:cerrar')}>
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5">
          {!edit && (
            <div role="radiogroup" aria-label={t('reservations:como_llego')} className="grid grid-cols-3 gap-2">
              {CHANNELS.map(({ id, icon: Icon }) => (
                <button
                  key={id}
                  type="button"
                  role="radio"
                  aria-checked={channel === id}
                  onClick={() => setChannel(id)}
                  className={`inline-flex items-center justify-center gap-2 min-h-[44px] rounded-xl border text-xs font-bold ${channel === id ? 'border-blue-600 bg-blue-50 text-blue-700' : 'border-slate-200 text-slate-600 hover:bg-slate-50'}`}
                >
                  <Icon className="w-4 h-4" aria-hidden /> {t(`reservations:canal_${id}`)}
                </button>
              ))}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <label className="block">
              <span className={labelCls}>{t('reservations:nombre')} *</span>
              <input autoFocus={!edit} value={name} maxLength={120} onChange={(e) => setName(e.target.value)} className={`${inputCls} mt-1`} />
            </label>
            <label className="block">
              <span className={labelCls}>{t('reservations:celular')}</span>
              <input value={phone} inputMode="tel" maxLength={20} onChange={(e) => setPhone(e.target.value)} className={`${inputCls} mt-1`} />
            </label>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-[auto_1fr] gap-4 items-end">
            <div>
              <span className={labelCls}>{t('reservations:personas_label')}</span>
              <div className="mt-1 flex items-center gap-2">
                <button type="button" onClick={() => setParty(Math.max(1, party - 1))} className="w-11 h-11 rounded-xl border border-slate-200 flex items-center justify-center hover:bg-slate-50" aria-label={t('reservations:menos')}>
                  <Minus className="w-4 h-4" />
                </button>
                <span className="w-10 text-center text-xl font-black tabular-nums" aria-live="polite">{party}</span>
                <button type="button" onClick={() => setParty(Math.min(200, party + 1))} className="w-11 h-11 rounded-xl border border-slate-200 flex items-center justify-center hover:bg-slate-50" aria-label={t('reservations:mas')}>
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>
            <label className="block">
              <span className={labelCls}>{t('reservations:fecha')}</span>
              <input type="date" value={date} onChange={(e) => e.target.value && setDate(e.target.value)} className={`${inputCls} mt-1`} />
            </label>
          </div>

          <div>
            <div className="flex items-center justify-between">
              <span className={labelCls}>{t('reservations:hora')} *</span>
              <span className="text-[11px] text-slate-500">{t('reservations:horas_desc')}</span>
            </div>
            {slots.length > 0 ? (
              <div className="mt-2 flex flex-wrap gap-1.5">
                {slots.map((s) => (
                  <button
                    key={s.time}
                    type="button"
                    disabled={!s.available && time !== s.time}
                    onClick={() => setTime(s.time)}
                    className={`min-w-[4.25rem] min-h-[40px] px-2.5 rounded-xl border text-sm font-bold tabular-nums ${
                      time === s.time ? 'border-blue-600 bg-blue-600 text-white' : s.available ? 'border-slate-200 text-slate-800 hover:border-blue-400' : 'border-slate-100 text-slate-300 line-through'
                    }`}
                  >
                    {s.time}
                  </button>
                ))}
              </div>
            ) : (
              <p className="mt-2 text-xs text-slate-500">{t('reservations:sin_horario_dia')}</p>
            )}
            <label className="mt-3 flex items-center gap-2 text-xs text-slate-600">
              {t('reservations:otra_hora')}
              <input type="time" value={time} onChange={(e) => setTime(e.target.value)} className="px-2 py-1.5 rounded-lg border border-slate-200 text-sm font-bold" />
            </label>
          </div>

          <label className="block">
            <span className={labelCls}>{t('reservations:mesa')}</span>
            <select value={tableId} onChange={(e) => setTableId(e.target.value)} className={`${inputCls} mt-1`}>
              <option value="">{edit?.table ? t('reservations:mesa_actual', { table: edit.table.number }) : t('reservations:mesa_automatica')}</option>
              {tables.map((tb) => (
                <option key={tb.id} value={tb.id} disabled={tb.capacity < party}>
                  {t('reservations:mesa_opcion', { table: tb.number, count: tb.capacity })}{tb.zone ? ` · ${tb.zone}` : ''}{tb.reservable ? '' : ` · ${t('reservations:no_reservable')}`}
                </option>
              ))}
            </select>
          </label>

          <label className="block">
            <span className={labelCls}>{t('reservations:notas')}</span>
            <textarea value={notes} onChange={(e) => setNotes(e.target.value)} maxLength={500} rows={2} placeholder={t('reservations:notas_ej')} className={`${inputCls} mt-1 py-2`} />
          </label>

          {!edit && hasCustomers && (
            <label className="flex items-start gap-3 rounded-2xl border border-slate-200 p-3 cursor-pointer">
              <input type="checkbox" checked={saveCustomer} onChange={(e) => setSaveCustomer(e.target.checked)} className="mt-0.5 w-4 h-4" />
              <span>
                <span className="block text-sm font-bold text-slate-800">{t('reservations:guardar_cliente')}</span>
                <span className="block text-xs text-slate-500">{t('reservations:guardar_cliente_desc')}</span>
              </span>
            </label>
          )}

          {error && <p role="alert" className="rounded-xl bg-rose-50 px-3 py-2 text-sm font-medium text-rose-700">{error}</p>}

          <div className="flex gap-3 pt-1">
            <button type="button" onClick={onClose} className="flex-1 min-h-[48px] rounded-xl border border-slate-200 font-bold text-slate-700 hover:bg-slate-50">
              {t('common:cancelar')}
            </button>
            <button type="button" onClick={save} disabled={saving} className="flex-[2] min-h-[48px] rounded-xl bg-blue-600 font-bold text-white shadow-sm hover:bg-blue-700 disabled:opacity-50">
              {saving ? t('reservations:guardando') : edit ? t('reservations:guardar_cambios') : t('reservations:agendar')}
            </button>
          </div>
        </div>
      </div>
    </div>,
    document.body,
  );
}
