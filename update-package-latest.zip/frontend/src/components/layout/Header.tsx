import { hasDesktopTitleBar } from './DesktopTitleBar';
import { AutopilotButton } from '../v3/AutopilotPanel';
import { NotificationBell } from '../common/NotificationBell';
import { ShiftButton } from '../mobile/ShiftButton';
import { AttendanceButton, AttendanceHost } from '../attendance/AttendanceButton';
import React, { useState, useEffect } from 'react';
import { usePosStore } from '../../store/usePosStore';
import {
  LayoutGrid,
  ShoppingBag,
  History,
  Wallet,
  Menu,
  Settings,
  LogOut,
  BarChart3,
  Sparkles,
  ChevronDown,
  Info
} from 'lucide-react';

import { dianAPI } from '../../services/api';
import { ThemeModeSelector } from '../common/ThemeModeSelector';
import { FontSizeControl } from '../common/FontSizeControl';
import { LanguageSelector } from '../common/LanguageSelector';

import { t as tr } from '../../i18n';
import { HelpCircle, CalendarDays, Bike } from 'lucide-react';
import { motion, useReducedMotion } from 'motion/react';
import { useBusiness } from '../../shared/business';
import { useReservationsStore } from '../../store/useReservationsStore';
import { useOnlineOrdersStore } from '../../store/useOnlineOrdersStore';
import { useGuideStore } from '../../guide/guideStore';
import { usePlan } from '../../shared/plan';
import { LockBadge } from '../common/PlanLocked';
import { tabAllowed, usePermissions } from '../../shared/permissions';
export type TabType = 'tables' | 'products' | 'sales' | 'cash' | 'analytics' | 'reservations' | 'agents' | 'delivery';

interface HeaderProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
  user?: any;
  onLogout?: () => void;
  /** Abre Administración (opcional: en una sección, p. ej. 'about') */
  onOpenAdmin?: (tab?: string) => void;
  tableViewMode?: 'operational' | 'floorplan';
}

export const Header: React.FC<HeaderProps> = ({ 
  activeTab, 
  onTabChange, 
  user, 
  onLogout, 
  onOpenAdmin,
  tableViewMode = 'operational'
}) => {
  const { cashSession, tables } = usePosStore();
  const openHelp = useGuideStore((s) => s.openHelp);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const reduceMotion = useReducedMotion();
  const [dianStats, setDianStats] = useState<any>(null);

  // El estado de la DIAN solo se consulta si el plan incluye la facturación electrónica
  const plan = usePlan();
  // Reservas: aviso de pendientes por confirmar (las de la página llegan solas)
  const hasReservations = plan.has('reservations');
  const reservationsEnabled = useReservationsStore((s) => s.enabled);
  const pendingReservations = useReservationsStore((s) => s.pending);
  const refreshReservations = useReservationsStore((s) => s.refresh);
  useEffect(() => {
    if (!hasReservations) return;
    refreshReservations();
    const timer = setInterval(refreshReservations, 60000);
    return () => clearInterval(timer);
  }, [hasReservations, refreshReservations]);
  // Pedidos web: aviso con sonido cuando llega uno nuevo desde la página
  const hasOrders = plan.has('webstore');
  const pendingOrders = useOnlineOrdersStore((s) => s.pending);
  const refreshOrders = useOnlineOrdersStore((s) => s.refresh);
  const userRoleForOrders = (user?.role || 'WAITER').toUpperCase();
  useEffect(() => {
    if (!hasOrders || userRoleForOrders === 'WAITER') return;
    const tick = async () => {
      // El aviso con sonido lo da NotificationCenter; aquí solo el contador
      await refreshOrders();
    };
    tick();
    const timer = setInterval(tick, 20000);
    return () => clearInterval(timer);
  }, [hasOrders, userRoleForOrders, refreshOrders]);
  const hasDian = plan.has('dian');
  useEffect(() => {
    if (!hasDian) {
      setDianStats(null);
      return;
    }
    const fetchDian = () => {
      dianAPI.getStats().then(setDianStats).catch(() => {});
    };
    fetchDian();
    const interval = setInterval(fetchDian, 30000);
    return () => clearInterval(interval);
  }, [hasDian]);

  const occupiedTables = tables.filter(t => t.status !== 'AVAILABLE').length;

  // Delivery reúne la página web, los pedidos en línea y los canales (WhatsApp, Rappi)
  const business = useBusiness().settings;
  const channelsOn = !!business?.whatsappEnabled || !!business?.rappiEnabled;
  const hasDelivery = hasOrders || plan.has('whatsapp') || plan.has('delivery');

  // Orden por uso: lo del día a día primero y Delivery al final, a la derecha
  const allTabs: { id: TabType; label: string; icon: React.ReactNode; badge?: number; locked?: boolean }[] = [
    { id: 'tables', label: tr('layout:mesas'), icon: <LayoutGrid className="w-4 h-4 sm:w-5 sm:h-5" />, badge: occupiedTables || undefined },
    {
      id: 'products',
      label: tableViewMode === 'operational' ? tr('layout:pedidos') : tr('layout:mostrador'),
      icon: <ShoppingBag className="w-4 h-4 sm:w-5 sm:h-5" />,
      badge: tableViewMode === 'operational' ? occupiedTables || undefined : undefined,
    },
    { id: 'sales', label: tr('layout:ventas'), icon: <History className="w-4 h-4 sm:w-5 sm:h-5" /> },
    { id: 'cash', label: tr('layout:caja'), icon: <Wallet className="w-4 h-4 sm:w-5 sm:h-5" />, badge: cashSession ? 1 : undefined },
    { id: 'analytics', label: tr('layout:estadisticas'), icon: <BarChart3 className="w-4 h-4 sm:w-5 sm:h-5" />, locked: !plan.has('analytics_adv') },
    { id: 'reservations', label: tr('layout:reservas'), icon: <CalendarDays className="w-4 h-4 sm:w-5 sm:h-5" />, badge: pendingReservations || undefined, locked: !hasReservations },
    { id: 'agents', label: tr('layout:agentes'), icon: <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-violet-300" />, locked: !plan.has('ai_agents') },
    { id: 'delivery', label: tr('layout:delivery'), icon: <Bike className="w-4 h-4 sm:w-5 sm:h-5" />, badge: pendingOrders || undefined, locked: !hasDelivery },
  ];

  // Control de acceso y pestañas según Rol
  // Cada pestaña pide una función; el ADMIN decide cuáles tiene cada rol
  // (Configuración › Usuarios y roles). El ADMIN ve todas.
  const userRole = (user?.role || 'WAITER').toUpperCase();
  const rolePerms = usePermissions((s) => s.perms);

  // En vista operativa las mesas viven dentro de 'Pedidos': no existe pestaña de mapa
  const tabs = allTabs
    .filter(t => tabAllowed(rolePerms, userRole, t.id))
    .filter(t => !(tableViewMode === 'operational' && t.id === 'tables'))
    // El equipo ve Reservas solo si el ADMIN las activó (el ADMIN la ve para activarlas)
    .filter(t => t.id !== 'reservations' || userRole === 'ADMIN' || (hasReservations && reservationsEnabled))
    // La caja ve Delivery si hay pedidos web en el plan o un canal encendido (el ADMIN la ve con su candado)
    .filter(t => t.id !== 'delivery' || userRole === 'ADMIN' || hasOrders || channelsOn);

  return (
    <header className="sticky top-0 z-40 select-none border-b border-white/5 bg-slate-950 font-sans text-white header-themed">
      <div className="w-full px-3 sm:px-4 lg:px-6">
        <div className="flex h-14 items-center justify-between gap-2">

          {/* Logo & Brand */}
          <div className="flex items-center gap-3 shrink-0">
            <img
              src="/logo-lantify-white.svg"
              alt={tr('layout:lantify_pos_logo')}
              className="h-9 w-auto object-contain"
            />
          </div>

          {/* Navigation Tabs (Responsive & Clear: Delimitado y modo solo-iconos si hay muchas pestañas) */}
          <nav 
            data-guide="main-nav" 
            className="mx-auto hidden min-w-0 max-w-fit items-center gap-0.5 overflow-hidden rounded-full bg-white/[0.06] p-1 md:flex"
          >
            {tabs.map((tab) => {
              const isActive = activeTab === tab.id;
              // Si hay más de 5 pestañas, colapsamos el texto para dejar solo iconos con tooltip en pantallas medianas
              // La pestaña activa siempre muestra su texto para mantener claridad
              const showTextClass = tabs.length > 5
                ? (isActive ? 'inline' : 'hidden 2xl:inline')
                : (isActive ? 'inline' : 'hidden xl:inline');

              return (
                <button
                  key={tab.id}
                  onClick={() => onTabChange(tab.id)}
                  aria-label={tab.label}
                  aria-current={isActive ? 'page' : undefined}
                  className={`relative flex h-9 shrink-0 items-center gap-2 rounded-full px-3 text-[0.8125rem] font-medium transition-colors duration-fast ${
                    isActive ? 'text-slate-950' : 'text-white/65 hover:text-white'
                  }`}
                  title={tab.label}
                >
                  {isActive && (
                    <motion.span
                      layoutId={reduceMotion ? undefined : 'header-active-tab'}
                      transition={{ type: 'spring', stiffness: 420, damping: 38 }}
                      className="absolute inset-0 rounded-full bg-white"
                      aria-hidden
                    />
                  )}
                  <span className="relative shrink-0 [&>svg]:h-4 [&>svg]:w-4">{tab.icon}</span>
                  <span className={`relative ${showTextClass}`}>{tab.label}</span>
                  {tab.locked && <span className="relative"><LockBadge /></span>}
                  {tab.badge !== undefined && (
                    <span className={`relative grid h-5 min-w-5 shrink-0 place-items-center rounded-full px-1.5 text-[0.72rem] font-semibold num ${
                      isActive ? 'bg-slate-950 text-white' : 'bg-white/15 text-white'
                    }`}>
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right Controls: Operational Badges + Consolidated User Menu (Siempre visible y delimitado) */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0 ml-auto">
            {/* Estado de caja: en el programa de escritorio ya está en la barra de la ventana */}
            {!hasDesktopTitleBar() && <button
              type="button"
              onClick={() => onTabChange('cash')}
              className="hidden h-9 shrink-0 items-center gap-2 rounded-full bg-white/[0.06] px-3 text-[0.8125rem] font-medium text-white/80 transition-colors duration-fast hover:bg-white/10 hover:text-white sm:flex"
              title={cashSession ? tr('layout:sesion_de_caja_abierta_clic_para_ver') : tr('layout:no_hay_sesion_de_caja_abierta_clic')}
            >
              <span className={`h-2 w-2 rounded-full ${cashSession ? 'bg-emerald-400' : 'bg-amber-400'}`} aria-hidden />
              <span className="hidden xl:inline">{cashSession ? tr('layout:caja_abierta') : tr('layout:caja_cerrada')}</span>
            </button>}

            {/* Facturas electrónicas que esperan validación (sin internet o con el proveedor caído) */}
            {dianStats?.queue?.pending > 0 && (
              <button
                type="button"
                onClick={() => onOpenAdmin?.()}
                className="hidden h-9 shrink-0 items-center gap-2 rounded-full bg-white/[0.06] px-3 text-[0.8125rem] font-medium text-white/80 transition-colors duration-fast hover:bg-white/10 hover:text-white md:flex"
                title={tr('layout:pending_facturas_en_cola_para_transmitir_a', { pending: dianStats.queue.pending })}
              >
                <span className="h-2 w-2 rounded-full bg-amber-400" aria-hidden />
                <span className="hidden xl:inline">DIAN ({dianStats.queue.pending})</span>
              </button>
            )}

            {/* Badge de Mesas Activas */}
            {occupiedTables > 0 && (
              <button
                type="button"
                onClick={() => onTabChange(tableViewMode === 'operational' ? 'products' : 'tables')}
                className="hidden h-9 shrink-0 items-center gap-2 rounded-full bg-white/[0.06] px-3 text-[0.8125rem] font-medium text-white/80 transition-colors duration-fast hover:bg-white/10 hover:text-white lg:flex"
                title={tr('layout:occupiedtables_mesas_activas_en_consumo_o_cobro', { occupiedTables })}
              >
                <span className="h-2 w-2 rounded-full bg-amber-400" aria-hidden />
                <span className="hidden xl:inline">{occupiedTables}{' '}{tr('layout:mesas_activas')}</span>
                <span className="num xl:hidden">{occupiedTables}</span>
              </button>
            )}

            <AutopilotButton role={String(user?.role || '')} />
            <AttendanceHost />
            <NotificationBell header />

            {/* Ayuda: artículos, recorridos y asistente (F1) */}
            <button
              type="button"
              data-guide="help-button"
              onClick={() => openHelp()}
              title={tr('guide:ayuda_f1')}
              aria-label={tr('guide:ayuda_f1')}
              className="inline-flex h-9 w-9 items-center justify-center rounded-full text-white/70 transition-colors duration-fast hover:bg-white/10 hover:text-white"
            >
              <HelpCircle className="h-[18px] w-[18px]" aria-hidden />
            </button>

            {/* Menú de Usuario Unificado */}
            {user && (
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setShowUserMenu(!showUserMenu)}
                  aria-expanded={showUserMenu}
                  className={`flex h-10 items-center gap-2 rounded-full py-1 pl-1 pr-2.5 text-left transition-colors duration-fast ${
                    showUserMenu ? 'bg-white/15' : 'bg-white/[0.06] hover:bg-white/10'
                  }`}
                >
                  <div className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-white text-xs font-semibold text-slate-950">
                    {user.name?.charAt(0)?.toUpperCase() || user.username?.charAt(0)?.toUpperCase() || 'U'}
                  </div>
                  <div className="hidden sm:flex flex-col leading-tight">
                    <span className="max-w-[110px] truncate text-[0.8125rem] font-medium text-white">
                      {user.name || user.username}
                    </span>
                    <span className="text-[0.72rem] text-white/50">
                      {user.role === 'ADMIN' ? tr('layout:admin') : user.role === 'WAITER' ? tr('layout:mesero') : tr('layout:cajero')}
                    </span>
                  </div>
                  <ChevronDown className={`h-3.5 w-3.5 text-white/50 transition-transform duration-base ${showUserMenu ? 'rotate-180' : ''}`} />
                </button>

                {/* Dropdown Popover */}
                {showUserMenu && (
                  <div className="lt-pop absolute right-0 z-50 mt-2 w-72 origin-top-right divide-y divide-white/10 rounded-[16px] bg-[#1c1c1b] p-2 text-white shadow-overlay [color-scheme:dark]">
                    <div className="p-2.5 space-y-1">
                      <p className="truncate text-sm font-semibold">{user.name || user.username}</p>
                      <p className="truncate text-xs text-white/50">@{user.username}</p>
                      <span className="mt-1 inline-block rounded-full bg-white/10 px-2 py-0.5 text-xs font-medium text-white/80">
                        {tr('layout:rol_value', { value: user.role === 'ADMIN' ? tr('layout:administrador') : user.role === 'WAITER' ? tr('layout:mesero') : tr('layout:cajero') })}
                      </span>
                    </div>

                    <div className="p-2.5 space-y-1.5">
                      <p className="text-xs font-medium text-white/50">{tr('layout:tema')}</p>
                      <ThemeModeSelector variant="compact" />
                      <p className="pt-1 text-xs font-medium text-white/50">{tr('layout:tamano_letra')}</p>
                      <FontSizeControl />
                      <p className="pt-1 text-xs font-medium text-white/50">{tr('layout:idioma')}</p>
                      <LanguageSelector variant="compact" />
                    </div>

                    {user.role === 'ADMIN' && (
                      <div className="py-2 space-y-1">
                        {onOpenAdmin && (
                          <button
                            type="button"
                            onClick={() => {
                              setShowUserMenu(false);
                              onOpenAdmin();
                            }}
                            className="flex h-10 w-full items-center gap-2.5 rounded-[10px] px-3 text-left text-[0.8125rem] font-medium text-white/80 transition-colors duration-fast hover:bg-white/10 hover:text-white"
                          >
                            <Settings className="h-4 w-4 text-white/60" aria-hidden />
                            <span>{tr('layout:panel_de_configuracion')}</span>
                          </button>
                        )}

                        {onOpenAdmin && (
                          <button
                            type="button"
                            onClick={() => {
                              setShowUserMenu(false);
                              onOpenAdmin('about');
                            }}
                            className="flex h-10 w-full items-center gap-2.5 rounded-[10px] px-3 text-left text-[0.8125rem] font-medium text-white/80 transition-colors duration-fast hover:bg-white/10 hover:text-white"
                          >
                            <Info className="h-4 w-4 text-white/60" aria-hidden />
                            <span>{tr('layout:acerca_de_lantify')}</span>
                          </button>
                        )}
                      </div>
                    )}

                    <ShiftButton />
                    <AttendanceButton role={String(user.role || '')} onOpen={() => setShowUserMenu(false)} />

                    {onLogout && (
                      <div className="pt-2">
                        <button
                          type="button"
                          onClick={() => {
                            setShowUserMenu(false);
                            onLogout();
                          }}
                          className="flex h-10 w-full items-center gap-2.5 rounded-[10px] px-3 text-left text-[0.8125rem] font-medium text-white/80 transition-colors duration-fast hover:bg-rose-500/15 hover:text-rose-200"
                        >
                          <LogOut className="w-4 h-4" />
                          <span>{tr('layout:cerrar_sesion')}</span>
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Mobile Hamburger Toggle */}
            <button 
              onClick={() => setShowMobileMenu(!showMobileMenu)}
              className="ml-1 inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-white/70 transition-colors hover:bg-white/10 hover:text-white md:hidden"
              title={tr('layout:menu_de_navegacion')}
            >
              <Menu className="w-6 h-6" />
            </button>
          </div>

        </div>

        {/* Mobile Dropdown Menu Drawer */}
        {showMobileMenu && (
          <div className="md:hidden py-3 px-2 border-t border-slate-800 bg-slate-900/98 backdrop-blur-md rounded-b-2xl mb-2 space-y-3 animate-in slide-in-from-top-2 duration-200 shadow-2xl">
            {user && (
              <div className="flex items-center justify-between px-3 py-2 bg-slate-800 rounded-xl border border-slate-700">
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-full bg-blue-600 flex items-center justify-center font-black text-white text-xs">
                    {user.name?.charAt(0)?.toUpperCase() || user.username?.charAt(0)?.toUpperCase() || 'U'}
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-200">{user.name || user.username}</p>
                    <p className="text-xs text-blue-400 uppercase tracking-wider font-semibold">{user.role}</p>
                  </div>
                </div>
                {user.role === 'ADMIN' && (
                  <button
                    onClick={() => {
                      setShowMobileMenu(false);
                      onOpenAdmin && onOpenAdmin();
                    }}
                    className="flex items-center gap-1 px-2.5 py-1 bg-blue-500/20 text-blue-300 border border-blue-500/30 rounded-lg text-xs font-bold hover:bg-blue-500/30"
                  >
                    <Settings className="w-3.5 h-3.5" />
                    <span>{tr('layout:admin')}</span>
                  </button>
                )}
              </div>
            )}

            {/* Tema claro / oscuro */}
            <div>
              <p className="text-xs font-bold text-slate-400 mb-1.5 px-1">{tr('layout:tema')}</p>
              <ThemeModeSelector variant="compact" />
              <p className="text-xs font-bold text-slate-400 mb-1.5 mt-3 px-1">{tr('layout:tamano_letra')}</p>
              <FontSizeControl />
              <p className="text-xs font-bold text-slate-400 mb-1.5 mt-3 px-1">{tr('layout:idioma')}</p>
              <LanguageSelector variant="compact" />
            </div>

            {/* Quick Actions (Admin and Logout) */}
            <div className="pt-2 border-t border-slate-800 flex gap-2">
              {user && user.role === 'ADMIN' && (
                <button
                  onClick={() => {
                    setShowMobileMenu(false);
                    onOpenAdmin && onOpenAdmin();
                  }}
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold border border-slate-700 transition-all"
                >
                  <Settings className="w-4 h-4 text-blue-400" />
                  <span>{tr('layout:configuracion')}</span>
                </button>
              )}
              {onLogout && (
                <button
                  onClick={() => {
                    setShowMobileMenu(false);
                    onLogout();
                  }}
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-900/60 rounded-xl text-xs font-bold transition-all"
                >
                  <LogOut className="w-4 h-4" />
                  <span>{tr('layout:cerrar_sesion')}</span>
                </button>
              )}
            </div>
          </div>
        )}

        {/* Mobile Navigation Tabs */}
        <div className="md:hidden flex gap-1 pb-2 overflow-x-auto">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`
                  relative flex-shrink-0 flex items-center gap-1.5 px-3 py-2 rounded-xl font-bold text-xs transition-all
                  ${isActive
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-300 hover:bg-slate-800'}
                `}
              >
                {tab.icon}
                <span>{tab.label}</span>
                {tab.locked && <LockBadge />}
                {tab.badge !== undefined && (
                  <span className={`w-4 h-4 text-xs rounded-full flex items-center justify-center font-bold ${
                    isActive ? 'bg-white text-blue-600' : 'bg-red-500 text-white'
                  }`}>
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

    </header>
  );
};

export default Header;