import React, { useState, useEffect } from 'react';
import { usePosStore } from '../../store/usePosStore';
import {
  LayoutGrid,
  ShoppingBag,
  History,
  Wallet,
  Menu,
  Settings,
  LogOut,
  BarChart3,
  Sparkles,
  X,
  CheckCircle2,
  Calendar,
  ShieldCheck,
  ChevronDown
} from 'lucide-react';

import { dianAPI } from '../../services/api';
import { API_URL } from '../../config';
import { ThemeModeSelector } from '../common/ThemeModeSelector';
import { LanguageSelector } from '../common/LanguageSelector';

import { t as tr } from '../../i18n';
import { HelpCircle, CalendarDays, Bike } from 'lucide-react';
import { useBusiness } from '../../shared/business';
import { useReservationsStore } from '../../store/useReservationsStore';
import { useOnlineOrdersStore } from '../../store/useOnlineOrdersStore';
import { useGuideStore } from '../../guide/guideStore';
import { usePlan } from '../../shared/plan';
import { LockBadge } from '../common/PlanLocked';
import { tabAllowed, usePermissions } from '../../shared/permissions';
export type TabType = 'tables' | 'products' | 'sales' | 'cash' | 'analytics' | 'reservations' | 'agents' | 'delivery';

interface HeaderProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
  user?: any;
  onLogout?: () => void;
  onOpenAdmin?: () => void;
  tableViewMode?: 'operational' | 'floorplan';
}

export const Header: React.FC<HeaderProps> = ({ 
  activeTab, 
  onTabChange, 
  user, 
  onLogout, 
  onOpenAdmin,
  tableViewMode = 'operational'
}) => {
  const { cashSession, tables } = usePosStore();
  const openHelp = useGuideStore((s) => s.openHelp);
  const [versionInfo, setVersionInfo] = useState<any>(null);
  const [showVersionModal, setShowVersionModal] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [dianStats, setDianStats] = useState<any>(null);

  useEffect(() => {
    fetch(`${API_URL}/version`)
      .then(res => res.json())
      .then(data => setVersionInfo(data))
      .catch(() => setVersionInfo({ version: '1.0.0', buildDate: '2026-10-16' }));
  }, []);

  // El estado de la DIAN solo se consulta si el plan incluye la facturación electrónica
  const plan = usePlan();
  // Reservas: aviso de pendientes por confirmar (las de la página llegan solas)
  const hasReservations = plan.has('reservations');
  const reservationsEnabled = useReservationsStore((s) => s.enabled);
  const pendingReservations = useReservationsStore((s) => s.pending);
  const refreshReservations = useReservationsStore((s) => s.refresh);
  useEffect(() => {
    if (!hasReservations) return;
    refreshReservations();
    const timer = setInterval(refreshReservations, 60000);
    return () => clearInterval(timer);
  }, [hasReservations, refreshReservations]);
  // Pedidos web: aviso con sonido cuando llega uno nuevo desde la página
  const hasOrders = plan.has('webstore');
  const pendingOrders = useOnlineOrdersStore((s) => s.pending);
  const refreshOrders = useOnlineOrdersStore((s) => s.refresh);
  const userRoleForOrders = (user?.role || 'WAITER').toUpperCase();
  useEffect(() => {
    if (!hasOrders || userRoleForOrders === 'WAITER') return;
    const tick = async () => {
      // El aviso con sonido lo da NotificationCenter; aquí solo el contador
      await refreshOrders();
    };
    tick();
    const timer = setInterval(tick, 20000);
    return () => clearInterval(timer);
  }, [hasOrders, userRoleForOrders, refreshOrders]);
  const hasDian = plan.has('dian');
  useEffect(() => {
    if (!hasDian) {
      setDianStats(null);
      return;
    }
    const fetchDian = () => {
      dianAPI.getStats().then(setDianStats).catch(() => {});
    };
    fetchDian();
    const interval = setInterval(fetchDian, 30000);
    return () => clearInterval(interval);
  }, [hasDian]);

  const occupiedTables = tables.filter(t => t.status !== 'AVAILABLE').length;

  // Delivery reúne la página web, los pedidos en línea y los canales (WhatsApp, Rappi)
  const business = useBusiness().settings;
  const channelsOn = !!business?.whatsappEnabled || !!business?.rappiEnabled;
  const hasDelivery = hasOrders || plan.has('whatsapp') || plan.has('delivery');

  // Orden por uso: lo del día a día primero y Delivery al final, a la derecha
  const allTabs: { id: TabType; label: string; icon: React.ReactNode; badge?: number; locked?: boolean }[] = [
    { id: 'tables', label: tr('layout:mesas'), icon: <LayoutGrid className="w-4 h-4 sm:w-5 sm:h-5" />, badge: occupiedTables || undefined },
    {
      id: 'products',
      label: tableViewMode === 'operational' ? tr('layout:pedidos') : tr('layout:mostrador'),
      icon: <ShoppingBag className="w-4 h-4 sm:w-5 sm:h-5" />,
      badge: tableViewMode === 'operational' ? occupiedTables || undefined : undefined,
    },
    { id: 'sales', label: tr('layout:ventas'), icon: <History className="w-4 h-4 sm:w-5 sm:h-5" /> },
    { id: 'cash', label: tr('layout:caja'), icon: <Wallet className="w-4 h-4 sm:w-5 sm:h-5" />, badge: cashSession ? 1 : undefined },
    { id: 'analytics', label: tr('layout:estadisticas'), icon: <BarChart3 className="w-4 h-4 sm:w-5 sm:h-5" />, locked: !plan.has('analytics_adv') },
    { id: 'reservations', label: tr('layout:reservas'), icon: <CalendarDays className="w-4 h-4 sm:w-5 sm:h-5" />, badge: pendingReservations || undefined, locked: !hasReservations },
    { id: 'agents', label: tr('layout:agentes'), icon: <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-violet-300" />, locked: !plan.has('ai_agents') },
    { id: 'delivery', label: tr('layout:delivery'), icon: <Bike className="w-4 h-4 sm:w-5 sm:h-5" />, badge: pendingOrders || undefined, locked: !hasDelivery },
  ];

  // Control de acceso y pestañas según Rol
  // Cada pestaña pide una función; el ADMIN decide cuáles tiene cada rol
  // (Configuración › Usuarios y roles). El ADMIN ve todas.
  const userRole = (user?.role || 'WAITER').toUpperCase();
  const rolePerms = usePermissions((s) => s.perms);

  // En vista operativa las mesas viven dentro de 'Pedidos': no existe pestaña de mapa
  const tabs = allTabs
    .filter(t => tabAllowed(rolePerms, userRole, t.id))
    .filter(t => !(tableViewMode === 'operational' && t.id === 'tables'))
    // El equipo ve Reservas solo si el ADMIN las activó (el ADMIN la ve para activarlas)
    .filter(t => t.id !== 'reservations' || userRole === 'ADMIN' || (hasReservations && reservationsEnabled))
    // La caja ve Delivery si hay pedidos web en el plan o un canal encendido (el ADMIN la ve con su candado)
    .filter(t => t.id !== 'delivery' || userRole === 'ADMIN' || hasOrders || channelsOn);

  return (
    <header className="bg-slate-900 border-b border-slate-800 shadow-md sticky top-0 z-40 select-none font-sans header-themed">
      <div className="w-full px-3 sm:px-4 lg:px-6">
        <div className="flex items-center justify-between h-16 gap-2">

          {/* Logo & Brand */}
          <div className="flex items-center gap-3 shrink-0">
            <img
              src="/logo-lantify-white.svg"
              alt={tr('layout:lantify_pos_logo')}
              className="h-10 sm:h-11 w-auto object-contain drop-shadow"
            />
            <div className="hidden sm:flex flex-col">
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setShowVersionModal(true)}
                  className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 hover:border-slate-600 text-blue-400 rounded-full text-xs font-bold transition-all shadow-sm flex items-center gap-1"
                  title={tr('layout:notas_de_version_de_lantify')}
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                  v{versionInfo?.version || '1.0.0'}
                </button>
              </div>
            </div>
          </div>

          {/* Navigation Tabs (Responsive & Clear: Delimitado y modo solo-iconos si hay muchas pestañas) */}
          <nav 
            data-guide="main-nav" 
            className="hidden md:flex items-center gap-0.5 lg:gap-1 min-w-0 max-w-fit mx-auto bg-slate-950/60 p-1 rounded-xl border border-slate-800/80 overflow-hidden"
          >
            {tabs.map((tab) => {
              const isActive = activeTab === tab.id;
              // Si hay más de 5 pestañas, colapsamos el texto para dejar solo iconos con tooltip en pantallas medianas
              // La pestaña activa siempre muestra su texto para mantener claridad
              const showTextClass = tabs.length > 5
                ? (isActive ? 'inline' : 'hidden 2xl:inline')
                : (isActive ? 'inline' : 'hidden xl:inline');

              return (
                <button
                  key={tab.id}
                  onClick={() => onTabChange(tab.id)}
                  aria-label={tab.label}
                  className={`
                    relative flex items-center gap-1.5 sm:gap-2 px-2.5 py-1.5 lg:px-3 lg:py-2 rounded-lg font-semibold text-xs transition-all duration-150 shrink-0
                    ${isActive
                      ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/20'
                      : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'}
                  `}
                  title={tab.label}
                >
                  <span className="shrink-0">{tab.icon}</span>
                  <span className={`font-medium tracking-wide ${showTextClass}`}>{tab.label}</span>
                  {tab.locked && <LockBadge />}
                  {tab.badge !== undefined && (
                    <span className={`w-4 h-4 text-[10px] rounded-full flex items-center justify-center font-bold shadow-sm shrink-0 ${
                      isActive ? 'bg-white text-blue-600' : 'bg-red-500 text-white'
                    }`}>
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right Controls: Operational Badges + Consolidated User Menu (Siempre visible y delimitado) */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0 ml-auto">
            {/* Badge de Estado de Caja */}
            <button
              type="button"
              onClick={() => onTabChange('cash')}
              className={`hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold border transition-colors shrink-0 ${
                cashSession
                  ? 'bg-emerald-950/60 text-emerald-300 border-emerald-800/80 hover:bg-emerald-900/60'
                  : 'bg-amber-950/60 text-amber-300 border-amber-800/80 hover:bg-amber-900/60'
              }`}
              title={cashSession ? tr('layout:sesion_de_caja_abierta_clic_para_ver') : tr('layout:no_hay_sesion_de_caja_abierta_clic')}
            >
              <span className={`w-2 h-2 rounded-full ${cashSession ? 'bg-emerald-400' : 'bg-amber-400'}`} />
              <span className="hidden xl:inline">{cashSession ? tr('layout:caja_abierta') : tr('layout:caja_cerrada')}</span>
            </button>

            {/* Facturas electrónicas que esperan validación (sin internet o con el proveedor caído) */}
            {dianStats?.queue?.pending > 0 && (
              <button
                type="button"
                onClick={onOpenAdmin}
                className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold border transition-colors shrink-0 bg-amber-950/60 text-amber-300 border-amber-800/80 hover:bg-amber-900/60"
                title={tr('layout:pending_facturas_en_cola_para_transmitir_a', { pending: dianStats.queue.pending })}
              >
                <span className="w-2 h-2 rounded-full bg-amber-400" />
                <span className="hidden xl:inline">DIAN ({dianStats.queue.pending})</span>
              </button>
            )}

            {/* Badge de Mesas Activas */}
            {occupiedTables > 0 && (
              <button
                type="button"
                onClick={() => onTabChange(tableViewMode === 'operational' ? 'products' : 'tables')}
                className="hidden lg:flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-800/90 text-amber-400 hover:text-white hover:bg-slate-700 border border-slate-700 rounded-xl text-xs font-bold transition-all shrink-0"
                title={tr('layout:occupiedtables_mesas_activas_en_consumo_o_cobro', { occupiedTables })}
              >
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                <span className="hidden xl:inline">{occupiedTables}{' '}{tr('layout:mesas_activas')}</span>
                <span className="xl:hidden">{occupiedTables}</span>
              </button>
            )}

            {/* Ayuda: artículos, recorridos y asistente (F1) */}
            <button
              type="button"
              data-guide="help-button"
              onClick={() => openHelp()}
              title={tr('guide:ayuda_f1')}
              aria-label={tr('guide:ayuda_f1')}
              className="w-10 h-10 rounded-xl inline-flex items-center justify-center text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <HelpCircle className="w-5 h-5" aria-hidden />
            </button>

            {/* Menú de Usuario Unificado */}
            {user && (
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setShowUserMenu(!showUserMenu)}
                  className={`flex items-center gap-2 p-1.5 sm:px-2.5 sm:py-1.5 rounded-xl border transition-all text-left ${
                    showUserMenu
                      ? 'bg-slate-800 border-blue-500 ring-2 ring-blue-500/30'
                      : 'bg-slate-800/90 border-slate-700/80 hover:bg-slate-800 hover:border-slate-600'
                  }`}
                >
                  <div className="w-7 h-7 rounded-lg bg-blue-600 flex items-center justify-center text-white font-black text-xs shrink-0 shadow-sm">
                    {user.name?.charAt(0)?.toUpperCase() || user.username?.charAt(0)?.toUpperCase() || 'U'}
                  </div>
                  <div className="hidden sm:flex flex-col leading-tight">
                    <span className="text-xs font-bold text-slate-200 max-w-[90px] truncate">
                      {user.name || user.username}
                    </span>
                    <span className={`text-xs font-black uppercase tracking-wider ${
                      user.role === 'ADMIN' ? 'text-amber-400' : user.role === 'WAITER' ? 'text-emerald-400' : 'text-blue-400'
                    }`}>
                      {user.role === 'ADMIN' ? tr('layout:admin') : user.role === 'WAITER' ? tr('layout:mesero') : tr('layout:cajero')}
                    </span>
                  </div>
                  <ChevronDown className={`w-3.5 h-3.5 text-slate-400 transition-transform ${showUserMenu ? 'rotate-180' : ''}`} />
                </button>

                {/* Dropdown Popover */}
                {showUserMenu && (
                  <div className="absolute right-0 mt-2 w-64 bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl z-50 p-2 animate-in fade-in-50 zoom-in-95 duration-150 divide-y divide-slate-800">
                    <div className="p-2.5 space-y-1">
                      <p className="font-bold text-sm text-slate-100 truncate">{user.name || user.username}</p>
                      <p className="text-xs text-slate-400 truncate">@{user.username}</p>
                      <span className={`inline-block px-2 py-0.5 rounded-md text-xs font-black uppercase tracking-wider mt-1 ${
                        user.role === 'ADMIN' ? 'bg-amber-400/10 text-amber-400 border border-amber-400/20' :
                        user.role === 'WAITER' ? 'bg-emerald-400/10 text-emerald-400 border border-emerald-400/20' :
                        'bg-blue-400/10 text-blue-400 border border-blue-400/20'
                      }`}>
                        {tr('layout:rol_value', { value: user.role === 'ADMIN' ? tr('layout:administrador') : user.role === 'WAITER' ? tr('layout:mesero') : tr('layout:cajero') })}
                      </span>
                    </div>

                    <div className="p-2.5 space-y-1.5">
                      <p className="text-xs font-bold text-slate-400">{tr('layout:tema')}</p>
                      <ThemeModeSelector variant="compact" />
                      <p className="text-xs font-bold text-slate-400 pt-1">{tr('layout:idioma')}</p>
                      <LanguageSelector variant="compact" />
                    </div>

                    {user.role === 'ADMIN' && (
                      <div className="py-2 space-y-1">
                        {onOpenAdmin && (
                          <button
                            type="button"
                            onClick={() => {
                              setShowUserMenu(false);
                              onOpenAdmin();
                            }}
                            className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-800 transition-colors text-left"
                          >
                            <Settings className="w-4 h-4 text-blue-400" />
                            <span>{tr('layout:panel_de_configuracion')}</span>
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => {
                            setShowUserMenu(false);
                            setShowVersionModal(true);
                          }}
                          className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-800 transition-colors text-left"
                        >
                          <Sparkles className="w-4 h-4 text-amber-400" />
                          <span>{tr('layout:notas_de_version_v_value', { value: versionInfo?.version || '1.0.0' })}</span>
                        </button>
                      </div>
                    )}

                    {onLogout && (
                      <div className="pt-2">
                        <button
                          type="button"
                          onClick={() => {
                            setShowUserMenu(false);
                            onLogout();
                          }}
                          className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-bold text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 transition-colors text-left"
                        >
                          <LogOut className="w-4 h-4" />
                          <span>{tr('layout:cerrar_sesion')}</span>
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Mobile Hamburger Toggle */}
            <button 
              onClick={() => setShowMobileMenu(!showMobileMenu)}
              className="md:hidden p-2 text-slate-300 hover:bg-slate-800 rounded-xl transition-colors shrink-0 ml-1"
              title={tr('layout:menu_de_navegacion')}
            >
              <Menu className="w-6 h-6" />
            </button>
          </div>

        </div>

        {/* Mobile Dropdown Menu Drawer */}
        {showMobileMenu && (
          <div className="md:hidden py-3 px-2 border-t border-slate-800 bg-slate-900/98 backdrop-blur-md rounded-b-2xl mb-2 space-y-3 animate-in slide-in-from-top-2 duration-200 shadow-2xl">
            {user && (
              <div className="flex items-center justify-between px-3 py-2 bg-slate-800 rounded-xl border border-slate-700">
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-full bg-blue-600 flex items-center justify-center font-black text-white text-xs">
                    {user.name?.charAt(0)?.toUpperCase() || user.username?.charAt(0)?.toUpperCase() || 'U'}
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-200">{user.name || user.username}</p>
                    <p className="text-xs text-blue-400 uppercase tracking-wider font-semibold">{user.role}</p>
                  </div>
                </div>
                {user.role === 'ADMIN' && (
                  <button
                    onClick={() => {
                      setShowMobileMenu(false);
                      onOpenAdmin && onOpenAdmin();
                    }}
                    className="flex items-center gap-1 px-2.5 py-1 bg-blue-500/20 text-blue-300 border border-blue-500/30 rounded-lg text-xs font-bold hover:bg-blue-500/30"
                  >
                    <Settings className="w-3.5 h-3.5" />
                    <span>{tr('layout:admin')}</span>
                  </button>
                )}
              </div>
            )}

            {/* Tema claro / oscuro */}
            <div>
              <p className="text-xs font-bold text-slate-400 mb-1.5 px-1">{tr('layout:tema')}</p>
              <ThemeModeSelector variant="compact" />
              <p className="text-xs font-bold text-slate-400 mb-1.5 mt-3 px-1">{tr('layout:idioma')}</p>
              <LanguageSelector variant="compact" />
            </div>

            {/* Quick Actions (Admin and Logout) */}
            <div className="pt-2 border-t border-slate-800 flex gap-2">
              {user && user.role === 'ADMIN' && (
                <button
                  onClick={() => {
                    setShowMobileMenu(false);
                    onOpenAdmin && onOpenAdmin();
                  }}
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold border border-slate-700 transition-all"
                >
                  <Settings className="w-4 h-4 text-blue-400" />
                  <span>{tr('layout:configuracion')}</span>
                </button>
              )}
              {onLogout && (
                <button
                  onClick={() => {
                    setShowMobileMenu(false);
                    onLogout();
                  }}
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-900/60 rounded-xl text-xs font-bold transition-all"
                >
                  <LogOut className="w-4 h-4" />
                  <span>{tr('layout:cerrar_sesion')}</span>
                </button>
              )}
            </div>
          </div>
        )}

        {/* Mobile Navigation Tabs */}
        <div className="md:hidden flex gap-1 pb-2 overflow-x-auto">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`
                  relative flex-shrink-0 flex items-center gap-1.5 px-3 py-2 rounded-xl font-bold text-xs transition-all
                  ${isActive
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-300 hover:bg-slate-800'}
                `}
              >
                {tab.icon}
                <span>{tab.label}</span>
                {tab.locked && <LockBadge />}
                {tab.badge !== undefined && (
                  <span className={`w-4 h-4 text-xs rounded-full flex items-center justify-center font-bold ${
                    isActive ? 'bg-white text-blue-600' : 'bg-red-500 text-white'
                  }`}>
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Version Modal */}
      {showVersionModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
            <div className="bg-slate-900 p-6 text-white flex items-center justify-between border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-blue-500/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-lg text-white font-heading">Lantify POS</h3>
                  <p className="text-xs text-slate-400">{tr('layout:version_v_value', { value: versionInfo?.version || '1.0.0' })}{' '}{versionInfo?.releaseName || tr('layout:release_oficial')}</p>
                </div>
              </div>
              <button
                onClick={() => setShowVersionModal(false)}
                className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
              <div className="flex items-center gap-4 text-xs font-bold text-slate-600 bg-slate-50 p-3 rounded-2xl border border-slate-200">
                <div className="flex items-center gap-1.5">
                  <Calendar className="w-4 h-4 text-blue-600" />
                  <span>{tr('layout:fecha')}{' '}{versionInfo?.buildDate || '2026-10-16'}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>{tr('layout:estado_produccion_estable')}</span>
                </div>
              </div>

              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                  {tr('layout:resumen_del_software')}
                </h4>
                <p className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-2xl border border-slate-200">
                  {versionInfo?.changelog || tr('layout:lantify_pos_sistema_de_punto_de_venta')}
                </p>
              </div>

              {versionInfo?.features && (
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                    {tr('layout:caracteristicas_destacadas')}
                  </h4>
                  <ul className="space-y-2">
                    {versionInfo.features.map((feat: string, idx: number) => (
                      <li key={idx} className="flex items-start gap-2 text-xs text-slate-700">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end">
              <button
                onClick={() => setShowVersionModal(false)}
                className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow transition-all"
              >
                {tr('layout:cerrar')}
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;