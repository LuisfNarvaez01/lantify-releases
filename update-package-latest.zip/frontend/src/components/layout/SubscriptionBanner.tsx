// ============================================
// COMPONENTS - Aviso del estado de pago (sobre el encabezado)
// ============================================
// Prueba por terminar o pago pendiente: aviso discreto que se puede ocultar.
// Periodo de gracia: aviso fijo con la fecha de suspensión. Nunca bloquea la venta.

import { useState } from 'react';
import { AlertTriangle, Clock, X } from 'lucide-react';
import { usePlan, daysUntil } from '../../shared/plan';
import { getLocale, t } from '../../i18n';

const TRIAL_NOTICE_DAYS = 7;
const DISMISS_KEY = 'lantify.subBanner.dismissed';

const formatDate = (iso: string | null | undefined) =>
  iso ? new Date(iso).toLocaleDateString(getLocale(), { day: 'numeric', month: 'long' }) : '';

export function SubscriptionBanner() {
  const { info, subStatus } = usePlan();
  const [dismissed, setDismissed] = useState(() => {
    try {
      return sessionStorage.getItem(DISMISS_KEY) || '';
    } catch {
      return '';
    }
  });

  if (!info?.linked || !subStatus) return null;

  let tone: 'info' | 'warning' | 'danger';
  let message: string;
  if (subStatus === 'TRIAL') {
    const days = daysUntil(info.periodEnd);
    if (days === null || days > TRIAL_NOTICE_DAYS) return null;
    tone = 'info';
    message = days === 0 ? t('plan:prueba_termina_hoy') : t('plan:prueba_termina', { count: days, date: formatDate(info.periodEnd) });
  } else if (subStatus === 'PAST_DUE') {
    tone = 'warning';
    message = t('plan:pago_pendiente', { date: formatDate(info.periodEnd), until: formatDate(info.graceUntil) });
  } else if (subStatus === 'GRACE') {
    tone = 'danger';
    message = t('plan:periodo_gracia', { date: formatDate(info.graceUntil) });
  } else {
    return null;
  }

  // Ocultar dura hasta que cambie el estado (y nunca aplica al periodo de gracia)
  const key = `${subStatus}:${info.periodEnd}`;
  const canDismiss = tone !== 'danger';
  if (canDismiss && dismissed === key) return null;

  const styles = {
    info: 'bg-info-soft text-info-text border-info-border',
    warning: 'bg-warning-soft text-warning-text border-warning-border',
    danger: 'bg-danger-soft text-danger-text border-danger-border',
  }[tone];
  const Icon = tone === 'info' ? Clock : AlertTriangle;

  return (
    <div role={tone === 'danger' ? 'alert' : 'status'} className={`shrink-0 border-b ${styles}`}>
      <div className="flex items-center gap-3 px-4 py-2 text-sm">
        <Icon className="w-4 h-4 shrink-0" aria-hidden />
        <p className="flex-1 min-w-0 font-medium leading-snug">{message}</p>
        {canDismiss && (
          <button
            type="button"
            onClick={() => {
              setDismissed(key);
              try {
                sessionStorage.setItem(DISMISS_KEY, key);
              } catch {
                // sin almacenamiento: se oculta solo en esta vista
              }
            }}
            className="p-1.5 -mr-1.5 rounded-md hover:bg-black/5 dark:hover:bg-white/10"
            aria-label={t('plan:ocultar_aviso')}
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
}
