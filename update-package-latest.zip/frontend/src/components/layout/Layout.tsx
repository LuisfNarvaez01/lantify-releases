// ============================================
// COMPONENTS - Main Layout
// ============================================

import { useState, useEffect } from 'react';
import { usePosStore } from '../../store/usePosStore';
import { Header } from './Header';
import { FloorPlan } from '../pos/FloorPlan';
import { TableSidebar } from '../pos/TableSidebar';
import { getTableViewMode, TableViewMode } from '../../shared/posSettings';
import { ProductGrid } from '../pos/ProductGrid';
import { Cart } from '../pos/Cart';
import { CashSessionPanel } from '../pos/CashSessionPanel';
import { VariantModal } from '../pos/VariantModal';
import { SalesHistory } from '../pos/SalesHistory';
import { AnalyticsModule } from '../pos/AnalyticsModule';
import { AdminPanel } from '../AdminPanel';
import { ArrowLeft } from 'lucide-react';
import { useBusiness } from '../../shared/business';
import { HelpCenter } from '../help/HelpCenter';
import { SubscriptionBanner } from './SubscriptionBanner';
import { AgentsModule } from '../agents/AgentsModule';
import { ReservationsModule } from '../reservations/ReservationsModule';
import { DeliveryModule } from '../delivery/DeliveryModule';
import { PlanLocked } from '../common/PlanLocked';
import { usePlan } from '../../shared/plan';
import { TourOffer } from '../help/TourOffer';
import { useGuideStore } from '../../guide/guideStore';
import { START_TOUR_EVENT, startTour } from '../../guide/tourRunner';
import { getTour, GuideModule } from '../../guide/tours';

import { t } from '../../i18n';
import { tabAllowed, usePermissions } from '../../shared/permissions';
import { NotificationCenter } from '../common/NotificationCenter';
import { Compass } from 'lucide-react';
import { useSetupGuide, useGuideProgress } from '../../shared/setupGuide';
interface LayoutProps {
  user?: any;
  onLogout?: () => void;
}

type TabType = 'tables' | 'products' | 'sales' | 'cash' | 'analytics' | 'reservations' | 'agents' | 'delivery';

export const Layout: React.FC<LayoutProps> = ({ user, onLogout }) => {
  const [activeTab, setActiveTab] = useState<TabType>('products');
  const [showAdmin, setShowAdmin] = useState(false);
  const [viewMode, setViewMode] = useState<TableViewMode>(() => getTableViewMode());
  // Un negocio sin mesas (comidas rápidas, tienda) trabaja siempre en mostrador
  const business = useBusiness();
  const { usesTables } = business;
  const isOperational = viewMode === 'operational' || !usesTables;

  // En vista operativa no existe la pestaña de mapa: mesas y pedido viven en la misma pantalla
  const rolePerms = usePermissions((s) => s.perms);
  const handleTabChange = (tab: TabType) => {
    if (!tabAllowed(rolePerms, user?.role, tab)) return;
    setActiveTab(isOperational && tab === 'tables' ? 'products' : tab);
  };

  // Redirigir si el rol activo no tiene acceso a la pestaña actual (o el ADMIN se la quitó)
  useEffect(() => {
    if (!tabAllowed(rolePerms, user?.role, activeTab)) setActiveTab('products');
  }, [user, activeTab, rolePerms]);
  useEffect(() => {
    if (isOperational && activeTab === 'tables') setActiveTab('products');
  }, [isOperational, activeTab]);
  const [adminInitialTab, setAdminInitialTab] = useState<string | undefined>(undefined);
  const role = (user?.role || 'WAITER').toUpperCase();

  // Guía de configuración: se abre al pedirla (aviso, ayuda o fin del asistente inicial)
  const guideOpenRequested = useSetupGuide((s) => s.openRequested);
  const guideState = useSetupGuide((s) => s.state);
  const saveGuide = useSetupGuide((s) => s.save);
  const guide = useGuideProgress();
  useEffect(() => {
    if (!guideOpenRequested || user?.role !== 'ADMIN') return;
    setAdminInitialTab('guide');
    setShowAdmin(true);
  }, [guideOpenRequested, user]);
  const showGuideBanner = user?.role === 'ADMIN' && guide.loaded && !guide.progress.complete && !guideState.hiddenAt;
  const plan = usePlan();

  // La ayuda sabe en qué pantalla está el usuario (artículos y recorridos de esa pantalla)
  const setGuideModule = useGuideStore((s) => s.setModule);
  useEffect(() => {
    const byTab: Record<string, GuideModule> = { products: 'pos', tables: 'pos', cash: 'cash', sales: 'sales' };
    setGuideModule(showAdmin ? 'settings' : byTab[activeTab] || 'other');
  }, [showAdmin, activeTab, setGuideModule]);

  // Un recorrido pedido desde la ayuda o el asistente: primero se abre su pantalla
  useEffect(() => {
    const onStart = (e: Event) => {
      const id = (e as CustomEvent<{ id: string }>).detail?.id;
      const tour = id ? getTour(id) : null;
      if (!tour) return;
      if (tour.module === 'settings') {
        setAdminInitialTab('config');
        setShowAdmin(true);
      } else {
        setShowAdmin(false);
        if (tour.module === 'cash') setActiveTab('cash');
        else if (tour.module === 'sales') setActiveTab('sales');
        else if (tour.module === 'pos') setActiveTab('products');
      }
      setTimeout(() => startTour(tour.id, role), 450);
    };
    window.addEventListener(START_TOUR_EVENT, onStart);
    return () => window.removeEventListener(START_TOUR_EVENT, onStart);
  }, [role]);

  // F1 abre la ayuda desde cualquier pantalla
  const openHelp = useGuideStore((s) => s.openHelp);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'F1') {
        e.preventDefault();
        openHelp();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [openHelp]);

  const [tableOrderMode, setTableOrderMode] = useState(false);

  const { 
    products,
    fetchProducts, 
    fetchCategories, 
    fetchTables, 
    fetchOpenSession, 
    selectedTable, 
    clearCart, 
  } = usePosStore();

  useEffect(() => {
    // Initial data fetch
    fetchProducts();
    fetchCategories();
    fetchTables();
    fetchOpenSession();
  }, []);

  const openPageSettings = () => {
    setAdminInitialTab('page');
    setShowAdmin(true);
  };

  const handleTableSelect = () => {
    // Cuando se selecciona una mesa, entrar en modo pedido
    setTableOrderMode(true);
    setActiveTab('products');
  };

  const handleBackToTables = () => {
    setTableOrderMode(false);
    setActiveTab(isOperational ? 'products' : 'tables');
    clearCart();
  };

  // Callback cuando se completa un pedido - volver al inicio
  const handleOrderComplete = () => {
    setTableOrderMode(false);
    setActiveTab(isOperational ? 'products' : 'tables');
    clearCart();
  };

  const renderContent = () => {
    // Modo pedido de mesa
    if (tableOrderMode && selectedTable) {
      return (
        <div className="space-y-4">
          {/* Header del modo pedido */}
          <div className="bg-white rounded-xl shadow p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <button
                onClick={handleBackToTables}
                className="p-2 hover:bg-gray-100 rounded-lg"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div>
                <h2 className="text-xl font-bold">{t('layout:mesa')}{' '}{selectedTable.number}</h2>
                <p className="text-sm text-gray-500">{t('layout:agrega_los_productos_del_pedido')}</p>
              </div>
            </div>
          </div>
          
          {/* Grid de productos */}
          <ProductGrid />
        </div>
      );
    }
    
    switch (activeTab) {
      case 'tables':
        return <FloorPlan onTableSelect={handleTableSelect} />;
      case 'products':
        return <ProductGrid />;
      case 'sales':
        return <SalesHistory />;
      case 'delivery':
        return <DeliveryModule role={role} products={products} onEditPage={role === 'ADMIN' ? openPageSettings : undefined} />;
      case 'cash':
        return <CashSessionPanel />;
      case 'analytics':
        return plan.has('analytics_adv') ? <AnalyticsModule /> : <PlanLocked feature="analytics_adv" />;
      case 'agents':
        return <AgentsModule />;
      case 'reservations':
        return <ReservationsModule businessName={business.settings?.businessName || 'Lantify'} />;
      default:
        return <ProductGrid />;
    }
  };

  const isCartVisible = (tableOrderMode && !!selectedTable) || activeTab === 'products';

  return (
    <div className="h-screen flex flex-col overflow-hidden bg-slate-100 font-sans">
      <SubscriptionBanner />
      {showAdmin ? (
        <AdminPanel
          key={adminInitialTab || 'admin'}
          user={user}
          onLogout={onLogout!}
          initialTab={adminInitialTab}
          onGoToPos={(tab) => {
            setAdminInitialTab(undefined);
            setShowAdmin(false);
            handleTabChange(tab);
          }}
          onClose={() => {
            setAdminInitialTab(undefined);
            const mode = getTableViewMode();
            setViewMode(mode);
            if (mode === 'operational' && activeTab === 'tables') setActiveTab('products');
            setShowAdmin(false);
          }}
        />
      ) : (
        <>
          <Header 
            activeTab={activeTab} 
            onTabChange={handleTabChange} 
            tableViewMode={isOperational ? 'operational' : 'floorplan'}
            user={user}
            onLogout={onLogout}
            onOpenAdmin={() => {
              if (user?.role === 'ADMIN') setShowAdmin(true);
            }}
          />

          {showGuideBanner && (
            <div className="bg-blue-50 border-b border-blue-100 px-4 py-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm">
              <Compass className="w-4 h-4 text-blue-700 shrink-0" aria-hidden />
              <span className="text-blue-900 font-semibold">
                {guide.progress.pendingChoices > 0
                  ? t('setup:aviso_elegir', { count: guide.progress.pendingChoices })
                  : t('setup:aviso_pasos', { count: guide.progress.total - guide.progress.done })}
              </span>
              <button type="button" onClick={() => useSetupGuide.getState().requestOpen()} className="font-bold text-blue-700 hover:underline">
                {t('setup:continuar')}
              </button>
              <button
                type="button"
                onClick={() => saveGuide({ ...guideState, hiddenAt: new Date().toISOString() }).catch(() => undefined)}
                className="ml-auto text-xs text-blue-800/80 hover:text-blue-900"
              >
                {t('setup:ocultar_aviso')}
              </button>
            </div>
          )}

          <main className="flex-1 flex overflow-hidden">
            <div className="flex-1 flex flex-col lg:flex-row gap-0 overflow-hidden p-2 lg:p-4">
              {/* Selector lateral de mesas (vista operativa) */}
              {isOperational && usesTables && activeTab === 'products' && (
                <aside className="w-full lg:w-64 xl:w-72 lg:shrink-0 lg:mr-4 h-48 lg:h-full">
                  <TableSidebar />
                </aside>
              )}
              {/* Main Content Area */}
              <div className={`overflow-auto ${
                isCartVisible 
                  ? 'lg:basis-[60%] lg:max-w-[60%]' 
                  : 'flex-1'
              }`}>
                {activeTab === 'cash' && !tableOrderMode ? (
                  <div className="w-full max-w-7xl mx-auto px-2 lg:px-4 py-2">
                    {renderContent()}
                  </div>
                ) : activeTab === 'delivery' && !tableOrderMode ? (
                  <div className="w-full max-w-7xl mx-auto px-2 lg:px-4 py-2">
                    {renderContent()}
                  </div>
                ) : activeTab === 'analytics' && !tableOrderMode ? (
                  <div className="w-full max-w-7xl mx-auto px-2 lg:px-4 py-2">
                    {renderContent()}
                  </div>
                ) : activeTab === 'sales' && !tableOrderMode ? (
                  <div className="w-full max-w-[1550px] mx-auto px-2 lg:px-4 py-2">
                    {renderContent()}
                  </div>
                ) : activeTab === 'tables' && !tableOrderMode ? (
                  <div className="w-full max-w-7xl mx-auto px-2 lg:px-6 py-2">
                    {renderContent()}
                  </div>
                ) : (
                  renderContent()
                )}
              </div>

              {/* Sidebar - Cart (Visible in table order mode and products counter mode) */}
              {isCartVisible && (
                <aside className="w-full lg:basis-[40%] h-full lg:ml-4 relative z-10 flex flex-col overflow-hidden">
                  <div className="h-full flex flex-col overflow-hidden bg-white rounded-3xl shadow-sm border border-slate-200/90">
                    <Cart onOrderComplete={handleOrderComplete} />
                  </div>
                </aside>
              )}
            </div>
          </main>

          {/* Variant Modal */}
          <VariantModal />

        </>
      )}
      <NotificationCenter
        role={user?.role}
        isAdmin={user?.role === 'ADMIN'}
        onOpen={(target) => {
          if ('tab' in target) {
            setShowAdmin(false);
            handleTabChange(target.tab);
          } else {
            setAdminInitialTab(target.admin);
            setShowAdmin(true);
          }
        }}
      />
      <HelpCenter role={role} />
      <TourOffer role={role} />
    </div>
  );
};

export default Layout;