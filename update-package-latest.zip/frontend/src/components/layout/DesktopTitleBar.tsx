// ============================================
// COMPONENTS - Barra propia de la ventana (Lantify.exe)
// ============================================
// Reemplaza la barra gris de Windows: logo y negocio, estado de la conexión
// (internet, red local y celulares conectados), estado de la caja, búsqueda rápida
// (Ctrl+K) y los botones de la ventana. Solo aparece en el programa de escritorio;
// en el navegador, las tablets y los celulares no existe.

import React, { useEffect, useState } from 'react';
import { Minus, Search, Square, Copy, X, Wifi, WifiOff, Smartphone, Lock, Unlock } from 'lucide-react';
import { desktop } from '../../shared/desktop';
import { useBusinessStore } from '../../shared/business';
import { API_URL } from '../../config';
import { t } from '../../i18n';

export const TITLEBAR_H = 36;

interface StatusBar {
  internet: boolean;
  lanEnabled: boolean;
  devices: number;
  cash: { open: boolean; by?: string | null; since?: string };
}

/** true si este equipo dibuja su propia barra (programa de escritorio con la versión nueva) */
export const hasDesktopTitleBar = () => !!desktop()?.window;

const useStatusBar = () => {
  const [status, setStatus] = useState<StatusBar | null>(null);
  useEffect(() => {
    let alive = true;
    const load = async () => {
      const token = localStorage.getItem('token');
      if (!token) return alive && setStatus(null);
      try {
        const res = await fetch(`${API_URL}/system/status-bar`, { headers: { Authorization: `Bearer ${token}` } });
        if (alive) setStatus(res.ok ? await res.json() : null);
      } catch {
        if (alive) setStatus(null);
      }
    };
    void load();
    const timer = setInterval(load, 15_000);
    const onFocus = () => void load();
    window.addEventListener('focus', onFocus);
    return () => {
      alive = false;
      clearInterval(timer);
      window.removeEventListener('focus', onFocus);
    };
  }, []);
  return status;
};

/** Abre la búsqueda: Layout lleva al catálogo y enfoca el buscador (mismo atajo Ctrl+K) */
const openSearch = () => window.dispatchEvent(new Event('lantify:search'));

const Pill: React.FC<{ tone: 'ok' | 'warn' | 'off'; title: string; children: React.ReactNode }> = ({ tone, title, children }) => (
  <span
    title={title}
    className={`inline-flex items-center gap-1.5 h-6 px-2 rounded-md text-[11px] font-medium no-drag ${
      tone === 'ok' ? 'text-white/80 bg-white/[0.08]' : tone === 'warn' ? 'text-amber-200 bg-amber-400/15' : 'text-white/50 bg-white/[0.06]'
    }`}
  >
    <span className={`w-1.5 h-1.5 rounded-full ${tone === 'ok' ? 'bg-emerald-400' : tone === 'warn' ? 'bg-amber-400' : 'bg-white/40'}`} />
    {children}
  </span>
);

const WinButton: React.FC<{ label: string; onClick: () => void; danger?: boolean; children: React.ReactNode }> = ({ label, onClick, danger, children }) => (
  <button
    type="button"
    aria-label={label}
    title={label}
    onClick={onClick}
    className={`no-drag h-full w-11 inline-flex items-center justify-center text-white/70 transition-colors ${
      danger ? 'hover:bg-red-600 hover:text-white' : 'hover:bg-white/10 hover:text-white'
    }`}
  >
    {children}
  </button>
);

export const DesktopTitleBar: React.FC = () => {
  const bridge = desktop()?.window;
  const [maximized, setMaximized] = useState(true);
  const businessName = useBusinessStore((s) => s.settings?.businessName);
  const status = useStatusBar();

  useEffect(() => {
    if (!bridge) return;
    const root = document.documentElement;
    root.classList.add('has-titlebar');
    root.style.setProperty('--titlebar-h', `${TITLEBAR_H}px`);
    void bridge.isMaximized().then(setMaximized).catch(() => {});
    const off = bridge.onMaximized(setMaximized);
    return () => {
      off();
      root.classList.remove('has-titlebar');
    };
  }, [bridge]);

  if (!bridge) return null;

  const cash = status?.cash;
  return (
    <div
      className="titlebar-drag header-themed fixed inset-x-0 top-0 z-[60] flex items-stretch bg-slate-950 text-white border-b border-white/5 select-none"
      style={{ height: TITLEBAR_H }}
      onDoubleClick={(e) => {
        if ((e.target as HTMLElement).closest('.no-drag')) return;
        void bridge.toggleMaximize();
      }}
    >
      <div className="flex items-center gap-2 pl-3 pr-4 min-w-0">
        <img src="/icon-lantify.svg" alt="" className="w-4 h-4" draggable={false} />
        <span className="text-[12px] font-semibold text-white tracking-tight">Lantify</span>
        {businessName && (
          <>
            <span className="text-white/30">/</span>
            <span className="text-[12px] text-white/70 truncate max-w-[220px]">{businessName}</span>
          </>
        )}
      </div>

      {status && (
        <div className="flex items-center gap-1.5">
          <Pill tone={status.internet ? 'ok' : 'warn'} title={status.internet ? t('layout:tb_internet_ok') : t('layout:tb_internet_off')}>
            {status.internet ? <Wifi className="w-3 h-3" /> : <WifiOff className="w-3 h-3" />}
            {status.internet ? t('layout:tb_en_linea') : t('layout:tb_sin_internet')}
          </Pill>
          {status.lanEnabled && (
            <Pill tone={status.devices > 0 ? 'ok' : 'off'} title={t('layout:tb_celulares_desc')}>
              <Smartphone className="w-3 h-3" />
              {t('layout:tb_celulares', { count: status.devices })}
            </Pill>
          )}
          {cash && (
            <Pill tone={cash.open ? 'ok' : 'off'} title={cash.open && cash.by ? t('layout:tb_caja_abierta_por', { name: cash.by }) : t('layout:tb_caja_cerrada')}>
              {cash.open ? <Unlock className="w-3 h-3" /> : <Lock className="w-3 h-3" />}
              {cash.open ? (cash.by ? t('layout:tb_caja_abierta_por', { name: cash.by }) : t('layout:tb_caja_abierta')) : t('layout:tb_caja_cerrada')}
            </Pill>
          )}
        </div>
      )}

      <div className="flex-1" />

      {status && (
        <button
          type="button"
          onClick={openSearch}
          className="no-drag self-center mr-3 inline-flex items-center gap-2 h-6 pl-2 pr-1.5 rounded-md border border-white/10 bg-white/[0.06] text-[11px] text-white/60 hover:bg-white/10 hover:text-white transition-colors"
        >
          <Search className="w-3 h-3" />
          {t('layout:tb_buscar')}
          <kbd className="ml-2 px-1 rounded bg-white/10 border border-white/10 font-mono text-[10px] text-white/60">Ctrl K</kbd>
        </button>
      )}

      <div className="flex items-stretch">
        <WinButton label={t('layout:tb_minimizar')} onClick={() => void bridge.minimize()}>
          <Minus className="w-3.5 h-3.5" />
        </WinButton>
        <WinButton label={maximized ? t('layout:tb_restaurar') : t('layout:tb_maximizar')} onClick={() => void bridge.toggleMaximize()}>
          {maximized ? <Copy className="w-3 h-3 -scale-x-100" /> : <Square className="w-3 h-3" />}
        </WinButton>
        <WinButton label={t('layout:tb_cerrar')} onClick={() => void bridge.close()} danger>
          <X className="w-4 h-4" />
        </WinButton>
      </div>
    </div>
  );
};
