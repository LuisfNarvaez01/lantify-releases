// ============================================
// LAYOUT - Proyecta en la caja (3.7)
// ============================================
// Avisos de Proyecta en cualquier pantalla (mensaje del DJ; sin DJ: pedido o canción que no
// cargó) y, cuando no hay DJ en cabina y hay pedidos esperando, un botón flotante para
// decidirlos sin entrar a Administración. Con DJ en cabina no aparece nada.

import { useEffect, useRef, useState } from 'react';
import { Music, X } from 'lucide-react';
import { t } from '../../i18n';
import { startProyectaNotifier } from '../../shared/proyectaNotifier';
import type { ProyectaStatus } from '../../services/proyectaApi';
import { ProyectaDeskCard } from '../admin/ProyectaDesk';

export function ProyectaDock({ isAdmin, hidden }: { isAdmin: boolean; hidden: boolean }) {
  const [status, setStatus] = useState<ProyectaStatus | null>(null);
  const [open, setOpen] = useState(false);
  const openRef = useRef(false);
  const hiddenRef = useRef(hidden);
  openRef.current = open;
  hiddenRef.current = hidden;

  useEffect(() => startProyectaNotifier({ isOpen: () => openRef.current || hiddenRef.current, onStatus: setStatus }), []);

  const desk = status?.venue ? status.desk : null;
  const waiting = desk && desk.online && !desk.djPresent ? desk.pending.length : 0;

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open]);

  if (hidden || !desk || (!waiting && !open)) return null;

  return (
    <>
      {!open && (
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="fixed bottom-5 right-5 z-40 inline-flex min-h-[48px] items-center gap-2 rounded-full bg-slate-950 px-4 text-sm font-semibold text-white shadow-xl ring-1 ring-white/10 transition hover:-translate-y-0.5"
        >
          <Music className="h-4 w-4" aria-hidden />
          {t('proyecta:dock_boton', { count: waiting })}
          <span className="grid h-6 min-w-[1.5rem] place-items-center rounded-full bg-amber-400 px-1.5 text-xs font-bold tabular-nums text-slate-950">{waiting}</span>
        </button>
      )}
      {open && (
        <div className="fixed inset-0 z-50 flex items-end justify-end bg-slate-950/30 p-4 sm:items-center sm:justify-center" onClick={(e) => e.target === e.currentTarget && setOpen(false)}>
          <div role="dialog" aria-modal="true" aria-label={t('proyecta:cabina_titulo')} className="relative max-h-[90vh] w-full max-w-xl overflow-y-auto rounded-3xl">
            <button type="button" onClick={() => setOpen(false)} aria-label={t('common:cerrar')} className="absolute right-4 top-4 z-10 grid h-9 w-9 place-items-center rounded-full text-slate-500 hover:bg-slate-100">
              <X className="h-4 w-4" aria-hidden />
            </button>
            <ProyectaDeskCard desk={desk} isAdmin={isAdmin} onChange={(id) => setStatus((s) => (s?.desk && id ? { ...s, desk: { ...s.desk, pending: s.desk.pending.filter((r) => r.id !== id) } } : s))} />
          </div>
        </div>
      )}
    </>
  );
}
