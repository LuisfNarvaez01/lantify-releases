// ============================================
// SALÓN - Pedidos desde la mesa esperando al mesero (Fase 4)
// ============================================
// El cliente pidió desde el QR de su mesa. Aparece en el plano de la caja y en el
// celular del mesero (avisos en vivo); al aceptarlo es una ronda nueva de la mesa
// y sale la comanda, igual que "Enviar a cocina". Rechazarlo le muestra el motivo.

import React, { useState } from 'react';
import { Check, QrCode, X } from 'lucide-react';
import { t } from '../../i18n';
import { toast } from '../../shared/toast';
import { promptDialog } from '../../shared/dialog';
import { formatCurrency } from '../../shared/formatUtils';
import { currentUserId, useFeatureFlag, useFloorStore } from '../../shared/features';
import { tableOrdersAPI, type TableRequest } from '../../services/v3Api';
import { usePosStore } from '../../store/usePosStore';
import { usePrintSettings } from '../../shared/printSettings';
import { printService } from '../../services/printService';

const currentUserName = (): string | null => {
  try {
    const u = JSON.parse(localStorage.getItem('user') || '{}');
    return u?.name || u?.username || null;
  } catch {
    return null;
  }
};

/** Los pedidos de mesa que le tocan a quien mira: el mesero ve los de sus mesas y los de mesas sin mesero */
const storedRole = () => {
  try {
    return String(JSON.parse(localStorage.getItem('user') || '{}')?.role || '');
  } catch {
    return '';
  }
};

export const useTableRequests = (role?: string): TableRequest[] => {
  const on = useFeatureFlag('table_ordering');
  const list = useFloorStore((s) => s.floor.tableRequests) || [];
  const me = currentUserId();
  if (!on) return [];
  return String(role || storedRole()).toUpperCase() === 'WAITER' ? list.filter((r) => !r.waiterId || r.waiterId === me) : list;
};

export const TableRequests: React.FC<{ role?: string; compact?: boolean }> = ({ role, compact = false }) => {
  const requests = useTableRequests(role);
  const [busy, setBusy] = useState<string | null>(null);
  if (!requests.length) return null;

  const refresh = () => {
    useFloorStore.getState().refresh();
    usePosStore.getState().fetchTables().catch(() => undefined);
  };

  const accept = async (r: TableRequest) => {
    setBusy(r.id);
    try {
      const done = await tableOrdersAPI.accept(r.id);
      if (usePrintSettings.getState().settings.autoPrintKitchen) {
        const { products, categories } = usePosStore.getState();
        const lookup = (productId: string) => {
          const product = products.find((p) => p.id === productId);
          const category = product?.categoryId ? categories.find((c) => c.id === product.categoryId) || product.category : undefined;
          return { product: product?.printStation, category: category?.printStation };
        };
        printService.printKitchenTicket({ items: done.items, tableNumber: done.tableNumber, roundNumber: done.roundNumber, waiterName: currentUserName() }, lookup)
          .catch(() => toast.warning(t('printing:no_se_pudo_comanda')));
      }
      toast.success(t('v3:mesa_pedido_aceptado', { number: done.tableNumber, round: done.roundNumber }));
    } catch (err: any) {
      toast.error(err?.message || t('v3:no_se_guardo'));
    } finally {
      setBusy(null);
      refresh();
    }
  };

  const reject = async (r: TableRequest) => {
    const reason = await promptDialog({
      title: t('v3:mesa_pedido_rechazar_titulo', { number: r.tableNumber }),
      label: t('v3:mesa_pedido_motivo'),
      placeholder: t('v3:mesa_pedido_motivo_ej'),
      required: false,
      tone: 'danger',
      confirmLabel: t('v3:rechazar'),
    });
    if (reason === null) return;
    setBusy(r.id);
    try {
      await tableOrdersAPI.reject(r.id, reason.trim() || undefined);
      toast.info(t('v3:mesa_pedido_rechazado', { number: r.tableNumber }));
    } catch (err: any) {
      toast.error(err?.message || t('v3:no_se_guardo'));
    } finally {
      setBusy(null);
      refresh();
    }
  };

  return (
    <section aria-label={t('v3:mesa_pedidos_titulo')} className={compact ? 'space-y-2' : 'space-y-2 rounded-[14px] bg-white p-3 shadow-card'}>
      {!compact && (
        <h3 className="flex items-center gap-2 text-sm font-bold text-slate-900">
          <QrCode className="h-4 w-4 text-blue-700" aria-hidden /> {t('v3:mesa_pedidos_titulo')}
        </h3>
      )}
      {requests.map((r) => (
        <div key={r.id} className="flex flex-wrap items-center gap-3 rounded-2xl border-2 border-blue-500 bg-blue-50 p-3" role="alert">
          <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl bg-blue-700 font-heading text-xl font-black text-white">{r.tableNumber}</span>
          <span className="min-w-0 flex-1">
            <span className="block text-xs font-bold uppercase tracking-wide text-blue-800">{t('v3:mesa_pedido_de', { number: r.tableNumber })}</span>
            <span className="block text-sm text-slate-800">{r.items.map((l) => `${l.qty}× ${l.name}${l.note ? ` (${l.note})` : ''}`).join(' · ')}</span>
            {r.notes && <span className="block text-sm italic text-slate-600">“{r.notes}”</span>}
            <span className="block text-sm font-bold tabular-nums text-slate-900">{formatCurrency(r.total)}{r.waiterName ? ` · ${r.waiterName}` : ''}</span>
          </span>
          <span className="flex w-full gap-2 sm:w-auto">
            <button type="button" disabled={busy === r.id} onClick={() => reject(r)} className="inline-flex min-h-[48px] flex-1 items-center justify-center gap-1.5 rounded-xl border-2 border-slate-300 bg-white px-4 font-bold text-slate-700 disabled:opacity-50 sm:flex-none">
              <X className="h-4 w-4" aria-hidden /> {t('v3:rechazar')}
            </button>
            <button type="button" disabled={busy === r.id} onClick={() => accept(r)} className="inline-flex min-h-[48px] flex-1 items-center justify-center gap-1.5 rounded-xl bg-blue-700 px-4 font-bold text-white disabled:opacity-50 sm:flex-none">
              <Check className="h-4 w-4" aria-hidden /> {t('v3:mesa_pedido_aceptar')}
            </button>
          </span>
        </div>
      ))}
    </section>
  );
};
