// ============================================
// FLOOR - Editor del plano del salón (Lantify 3.0)
// ============================================
// Kit completo: rejilla con imán (Shift = libre), guías de alineación, selección
// múltiple (Ctrl/Shift + clic o caja), flechas para mover (Shift = 10 px), girar,
// redimensionar, formas de mesa, elementos (pared, puerta, barra, cocina, baño,
// planta, texto, zona), duplicar, alinear y distribuir, deshacer/rehacer, zoom,
// zonas como capas y numeración automática. Todo se edita en memoria y se guarda
// de una vez con "Guardar".

import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  AlignCenterHorizontal, AlignCenterVertical, AlignEndHorizontal, AlignEndVertical, AlignStartHorizontal, AlignStartVertical,
  Circle, Copy, Grid3x3, Loader2, Magnet, Minus, Plus, Redo2, RotateCcw, RotateCw, Save, Square, Trash2, Undo2, X,
} from 'lucide-react';
import { API_URL } from '../../config';
import { responseError, errorMessage } from '../../services/apiErrors';
import { usePosStore } from '../../store/usePosStore';
import { toast } from '../../shared/toast';
import { confirmDialog } from '../../shared/dialog';
import { t } from '../../i18n';
import {
  align, alignGuides, boundsOf, CANVAS, clamp, DEFAULT_ELEMENT_SIZE, DEFAULT_TABLE_SIZE, distribute, ELEMENT_KINDS, GRID, keepInside,
  MAX_SIZE, MIN_SIZE, nextTableNumber, normRotation, snap, TABLE_SHAPES,
  type AlignMode, type Box, type ElementKind, type Guide, type TableShape,
} from '../../../../src/domain/floorLayout';

interface ETable { key: string; type: 'table'; id?: string; number: string; capacity: number; zone: string | null; x: number; y: number; w: number; h: number; shape: TableShape; rotation: number; reservable: boolean; status?: string }
interface EElement { key: string; type: 'element'; kind: ElementKind; zone: string | null; x: number; y: number; w: number; h: number; rotation: number; label: string | null }
type Item = ETable | EElement;
interface Snapshot { items: Item[]; deleted: string[] }

const ALL = '__all';
const uid = () => Math.random().toString(36).slice(2, 10);
const api = async <T,>(method: string, path: string, body?: unknown): Promise<T> => {
  const token = localStorage.getItem('token');
  const res = await fetch(`${API_URL}${path}`, { method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const data = await res.json().catch(() => null);
  if (!res.ok) throw responseError(res.status, data);
  return data as T;
};

const ELEMENT_STYLE: Record<ElementKind, string> = {
  wall: 'bg-slate-700', door: 'bg-amber-300 border-2 border-amber-500', window: 'bg-sky-200 border-2 border-sky-400',
  bar: 'bg-amber-800/80 text-white', kitchen: 'bg-orange-100 border-2 border-dashed border-orange-400 text-orange-900',
  bathroom: 'bg-sky-50 border-2 border-dashed border-sky-400 text-sky-900', plant: 'bg-emerald-400 rounded-full',
  text: 'bg-transparent text-slate-700 font-black', zone: 'bg-indigo-50/50 border-2 border-dashed border-indigo-300 text-indigo-700',
};

export const FloorEditor: React.FC<{ onClose?: () => void }> = ({ onClose }) => {
  const [items, setItems] = useState<Item[]>([]);
  const [deleted, setDeleted] = useState<string[]>([]);
  const [sel, setSel] = useState<Set<string>>(new Set());
  const [zone, setZone] = useState<string>(ALL);
  const [zoom, setZoom] = useState(0.8);
  const [snapOn, setSnapOn] = useState(true);
  const [guides, setGuides] = useState<Guide[]>([]);
  const [band, setBand] = useState<{ x0: number; y0: number; x1: number; y1: number } | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [dirty, setDirty] = useState(false);
  const past = useRef<Snapshot[]>([]);
  const future = useRef<Snapshot[]>([]);
  const canvas = useRef<HTMLDivElement>(null);
  const drag = useRef<{ kind: 'move' | 'resize'; startX: number; startY: number; origin: Map<string, Box>; free: boolean } | null>(null);

  // ── Cargar ──
  const load = useCallback(async () => {
    setLoading(true);
    try {
      const r = await api<{ tables: any[]; elements: any[] }>('GET', '/floor/layout');
      const tables: Item[] = r.tables.map((tb, i) => {
        const shape: TableShape = TABLE_SHAPES.includes(tb.shape) ? tb.shape : 'square';
        const def = DEFAULT_TABLE_SIZE[shape];
        return { key: tb.id, type: 'table', id: tb.id, number: String(tb.number), capacity: tb.capacity || 4, zone: tb.zone || null, x: tb.positionX ?? 24 + (i % 10) * 120, y: tb.positionY ?? 24 + Math.floor(i / 10) * 120, w: tb.width || def.w, h: tb.height || def.h, shape, rotation: tb.rotation || 0, reservable: !!tb.reservable, status: tb.status };
      });
      const elements: Item[] = r.elements.map((e) => ({ key: e.id, type: 'element', kind: e.kind, zone: e.zone || null, x: e.x, y: e.y, w: e.w, h: e.h, rotation: e.rotation || 0, label: e.label || null }));
      setItems([...elements, ...tables]);
      setDeleted([]); setSel(new Set()); past.current = []; future.current = []; setDirty(false);
    } catch (e) { toast.error(errorMessage(e)); } finally { setLoading(false); }
  }, []);
  useEffect(() => { load(); }, [load]);

  // Avisar si se cierra la ventana con cambios sin guardar
  useEffect(() => {
    const warn = (e: BeforeUnloadEvent) => { if (dirty) { e.preventDefault(); e.returnValue = ''; } };
    window.addEventListener('beforeunload', warn);
    return () => window.removeEventListener('beforeunload', warn);
  }, [dirty]);

  // ── Historial ──
  const commit = useCallback((next: Item[], nextDeleted = deleted) => {
    past.current.push({ items, deleted });
    if (past.current.length > 80) past.current.shift();
    future.current = [];
    setItems(next); setDeleted(nextDeleted); setDirty(true);
  }, [items, deleted]);
  const undo = () => { const p = past.current.pop(); if (!p) return; future.current.push({ items, deleted }); setItems(p.items); setDeleted(p.deleted); setDirty(true); };
  const redo = () => { const f = future.current.pop(); if (!f) return; past.current.push({ items, deleted }); setItems(f.items); setDeleted(f.deleted); setDirty(true); };

  const zones = useMemo(() => [...new Set(items.map((i) => i.zone).filter((z): z is string => !!z))].sort(), [items]);
  const visible = useMemo(() => items.filter((i) => zone === ALL || i.zone === zone), [items, zone]);
  const selected = visible.filter((i) => sel.has(i.key));
  const one = selected.length === 1 ? selected[0] : null;
  const update = (keys: Set<string>, fn: (i: Item) => Item) => commit(items.map((i) => (keys.has(i.key) ? fn(i) : i)));

  // ── Crear ──
  const spot = (w: number, h: number) => {
    const el = canvas.current;
    const cx = el ? (el.scrollLeft + el.clientWidth / 2) / zoom : 200;
    const cy = el ? (el.scrollTop + el.clientHeight / 2) / zoom : 200;
    return keepInside({ id: '', x: snap(cx - w / 2), y: snap(cy - h / 2), w, h, rotation: 0 });
  };
  const addTable = (shape: TableShape) => {
    const def = DEFAULT_TABLE_SIZE[shape];
    const p = spot(def.w, def.h);
    const z = zone === ALL ? null : zone;
    const number = nextTableNumber(items.filter((i): i is ETable => i.type === 'table' && i.zone === z).map((i) => i.number));
    const item: ETable = { key: uid(), type: 'table', number, capacity: shape === 'bar' ? 1 : shape === 'rect' ? 6 : 4, zone: z, x: p.x, y: p.y, w: def.w, h: def.h, shape, rotation: 0, reservable: false };
    commit([...items, item]); setSel(new Set([item.key]));
  };
  const addElement = (kind: ElementKind) => {
    const def = DEFAULT_ELEMENT_SIZE[kind];
    const p = spot(def.w, def.h);
    const item: EElement = { key: uid(), type: 'element', kind, zone: zone === ALL ? null : zone, x: p.x, y: p.y, w: def.w, h: def.h, rotation: 0, label: kind === 'text' || kind === 'zone' ? t(`floor:el_${kind}`) : null };
    // Las zonas y paredes van al fondo
    commit(kind === 'zone' ? [item, ...items] : [...items, item]); setSel(new Set([item.key]));
  };
  const duplicate = () => {
    if (!selected.length) return;
    const used = items.filter((i): i is ETable => i.type === 'table').map((i) => i.number);
    const copies = selected.map((i) => {
      const c = { ...i, key: uid(), x: clamp(i.x + 24, 0, CANVAS.width - i.w), y: clamp(i.y + 24, 0, CANVAS.height - i.h) } as Item;
      if (c.type === 'table') { delete (c as ETable).id; (c as ETable).number = nextTableNumber(used); used.push((c as ETable).number); }
      return c;
    });
    commit([...items, ...copies]); setSel(new Set(copies.map((c) => c.key)));
  };
  const remove = async () => {
    if (!selected.length) return;
    const busy = selected.filter((i): i is ETable => i.type === 'table' && !!i.status && i.status !== 'AVAILABLE');
    if (busy.length) { toast.warning(t('floor:mesa_ocupada', { numbers: busy.map((b) => b.number).join(', ') })); return; }
    const ids = selected.filter((i): i is ETable => i.type === 'table' && !!i.id).map((i) => i.id!);
    commit(items.filter((i) => !sel.has(i.key)), [...deleted, ...ids]); setSel(new Set());
  };

  // ── Alinear y girar ──
  const doAlign = (mode: AlignMode) => { const moved = new Map(align(selected.map((i) => ({ id: i.key, x: i.x, y: i.y, w: i.w, h: i.h, rotation: i.rotation })), mode).map((b) => [b.id, b])); update(sel, (i) => ({ ...i, x: moved.get(i.key)!.x, y: moved.get(i.key)!.y })); };
  const doDistribute = (axis: 'x' | 'y') => { const moved = new Map(distribute(selected.map((i) => ({ id: i.key, x: i.x, y: i.y, w: i.w, h: i.h, rotation: i.rotation })), axis).map((b) => [b.id, b])); update(sel, (i) => ({ ...i, x: moved.get(i.key)!.x, y: moved.get(i.key)!.y })); };
  const rotate = (deg: number) => update(sel, (i) => ({ ...i, rotation: normRotation(i.rotation + deg) }));

  // ── Arrastrar, redimensionar y caja de selección ──
  const toCanvas = (e: { clientX: number; clientY: number }) => {
    const r = canvas.current!.getBoundingClientRect();
    return { x: (e.clientX - r.left + canvas.current!.scrollLeft) / zoom, y: (e.clientY - r.top + canvas.current!.scrollTop) / zoom };
  };
  const startMove = (e: React.PointerEvent, item: Item, kind: 'move' | 'resize') => {
    e.stopPropagation();
    (e.target as Element).setPointerCapture?.(e.pointerId);
    let next = sel;
    if (kind === 'move') {
      if (e.ctrlKey || e.metaKey || e.shiftKey) { next = new Set(sel); if (next.has(item.key)) next.delete(item.key); else next.add(item.key); }
      else if (!sel.has(item.key)) next = new Set([item.key]);
      setSel(next);
    }
    const p = toCanvas(e);
    const keys = kind === 'resize' ? new Set([item.key]) : next;
    drag.current = { kind, startX: p.x, startY: p.y, origin: new Map(items.filter((i) => keys.has(i.key)).map((i) => [i.key, { id: i.key, x: i.x, y: i.y, w: i.w, h: i.h, rotation: i.rotation }])), free: e.altKey };
    past.current.push({ items, deleted });
    future.current = [];
  };
  const onMove = (e: React.PointerEvent) => {
    const d = drag.current;
    if (band) { const p = toCanvas(e); setBand({ ...band, x1: p.x, y1: p.y }); return; }
    if (!d) return;
    const p = toCanvas(e);
    let dx = p.x - d.startX;
    let dy = p.y - d.startY;
    const free = e.shiftKey || !snapOn;
    if (d.kind === 'resize') {
      const [key, o] = [...d.origin.entries()][0];
      const w = clamp(free ? Math.round(o.w + dx) : snap(o.w + dx), MIN_SIZE, MAX_SIZE);
      const h = clamp(free ? Math.round(o.h + dy) : snap(o.h + dy), 4, MAX_SIZE);
      setItems((all) => all.map((i) => (i.key === key ? { ...i, w, h } : i)));
      setDirty(true);
      return;
    }
    const group = boundsOf([...d.origin.values()]);
    let gx = group.x + dx;
    let gy = group.y + dy;
    if (!free) { gx = snap(gx); gy = snap(gy); }
    const others = visible.filter((i) => !d.origin.has(i.key)).map((i) => ({ id: i.key, x: i.x, y: i.y, w: i.w, h: i.h, rotation: 0 }));
    const g = alignGuides({ ...group, x: gx, y: gy }, others);
    gx += g.dx; gy += g.dy;
    gx = clamp(gx, 0, CANVAS.width - group.w); gy = clamp(gy, 0, CANVAS.height - group.h);
    dx = gx - group.x; dy = gy - group.y;
    setGuides(g.guides);
    setItems((all) => all.map((i) => { const o = d.origin.get(i.key); return o ? { ...i, x: Math.round(o.x + dx), y: Math.round(o.y + dy) } : i; }));
    setDirty(true);
  };
  const endMove = () => {
    if (band) {
      const x0 = Math.min(band.x0, band.x1); const x1 = Math.max(band.x0, band.x1);
      const y0 = Math.min(band.y0, band.y1); const y1 = Math.max(band.y0, band.y1);
      if (x1 - x0 > 4 || y1 - y0 > 4) setSel(new Set(visible.filter((i) => i.x < x1 && i.x + i.w > x0 && i.y < y1 && i.y + i.h > y0).map((i) => i.key)));
      setBand(null);
    }
    if (drag.current) {
      // Un clic sin mover no ocupa un paso del historial
      const moved = [...drag.current.origin.entries()].some(([k, o]) => { const i = items.find((x) => x.key === k); return i && (i.x !== o.x || i.y !== o.y || i.w !== o.w || i.h !== o.h); });
      if (!moved) past.current.pop();
    }
    drag.current = null;
    setGuides([]);
  };
  const startBand = (e: React.PointerEvent) => {
    if (e.target !== e.currentTarget && !(e.target as HTMLElement).dataset.canvas) return;
    const p = toCanvas(e);
    if (!e.shiftKey && !e.ctrlKey) setSel(new Set());
    setBand({ x0: p.x, y0: p.y, x1: p.x, y1: p.y });
  };

  // ── Teclado ──
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement).tagName;
      if (tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA') return;
      const mod = e.ctrlKey || e.metaKey;
      if (mod && e.key.toLowerCase() === 'z') { e.preventDefault(); if (e.shiftKey) redo(); else undo(); return; }
      if (mod && e.key.toLowerCase() === 'y') { e.preventDefault(); redo(); return; }
      if (mod && e.key.toLowerCase() === 'd') { e.preventDefault(); duplicate(); return; }
      if (mod && e.key.toLowerCase() === 'a') { e.preventDefault(); setSel(new Set(visible.map((i) => i.key))); return; }
      if (mod && e.key.toLowerCase() === 's') { e.preventDefault(); save(); return; }
      if (e.key === 'Escape') { setSel(new Set()); return; }
      if (!selected.length) return;
      if (e.key === 'Delete' || e.key === 'Backspace') { e.preventDefault(); remove(); return; }
      if (e.key.toLowerCase() === 'r') { rotate(e.shiftKey ? -15 : 15); return; }
      const step = e.shiftKey ? 10 : 1;
      const mv = { ArrowLeft: [-step, 0], ArrowRight: [step, 0], ArrowUp: [0, -step], ArrowDown: [0, step] }[e.key];
      if (mv) { e.preventDefault(); update(sel, (i) => ({ ...i, ...keepInside({ id: i.key, x: i.x + mv[0], y: i.y + mv[1], w: i.w, h: i.h, rotation: i.rotation }), key: i.key } as Item)); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  // ── Guardar ──
  const save = async () => {
    setSaving(true);
    try {
      await api('PUT', '/floor/layout', {
        tables: items.filter((i): i is ETable => i.type === 'table').map((i) => ({ id: i.id, number: i.number, capacity: i.capacity, zone: i.zone, positionX: i.x, positionY: i.y, width: i.w, height: i.h, shape: i.shape, rotation: i.rotation, reservable: i.reservable })),
        elements: items.filter((i): i is EElement => i.type === 'element').map((i) => ({ kind: i.kind, zone: i.zone, x: i.x, y: i.y, w: i.w, h: i.h, rotation: i.rotation, label: i.label })),
        deletedTableIds: deleted,
      });
      toast.success(t('floor:guardado'));
      await load();
      usePosStore.getState().fetchTables();
    } catch (e) { toast.error(errorMessage(e)); } finally { setSaving(false); }
  };
  const discard = async () => {
    if (dirty && !(await confirmDialog({ title: t('floor:descartar'), message: t('floor:descartar_desc'), tone: 'danger', confirmLabel: t('floor:descartar') }))) return;
    await load();
  };

  const setProp = (patch: Record<string, unknown>) => update(sel, (i) => ({ ...i, ...patch } as Item));
  const btn = 'inline-flex h-9 min-w-[36px] items-center justify-center gap-1 rounded-lg px-2 text-xs font-bold text-slate-700 hover:bg-slate-100 disabled:opacity-40';
  const field = 'w-full rounded-lg border border-slate-300 px-2 py-1.5 text-sm';

  if (loading) return <p className="py-16 text-center"><Loader2 className="mx-auto h-6 w-6 animate-spin text-slate-400" aria-label={t('floor:cargando')} /></p>;

  return (
    <div className="space-y-3">
      {/* Barra de herramientas */}
      <div className="flex flex-wrap items-center gap-1 rounded-2xl border border-slate-200 bg-white p-1.5" role="toolbar" aria-label={t('floor:herramientas')}>
        <details className="relative">
          <summary className={`${btn} list-none bg-blue-700 text-white hover:bg-blue-800`}><Plus className="h-4 w-4" aria-hidden />{t('floor:mesa')}</summary>
          <div className="absolute z-20 mt-1 w-44 rounded-xl border border-slate-200 bg-white p-1 shadow-lg">
            {TABLE_SHAPES.map((s) => <button key={s} type="button" onClick={(e) => { addTable(s); (e.currentTarget.closest('details') as HTMLDetailsElement).open = false; }} className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-sm hover:bg-slate-100">{s === 'round' ? <Circle className="h-4 w-4" aria-hidden /> : <Square className="h-4 w-4" aria-hidden />}{t(`floor:forma_${s}`)}</button>)}
          </div>
        </details>
        <details className="relative">
          <summary className={`${btn} list-none border border-slate-300`}><Plus className="h-4 w-4" aria-hidden />{t('floor:elemento')}</summary>
          <div className="absolute z-20 mt-1 w-44 rounded-xl border border-slate-200 bg-white p-1 shadow-lg">
            {ELEMENT_KINDS.map((k) => <button key={k} type="button" onClick={(e) => { addElement(k); (e.currentTarget.closest('details') as HTMLDetailsElement).open = false; }} className="block w-full rounded-lg px-3 py-2 text-left text-sm hover:bg-slate-100">{t(`floor:el_${k}`)}</button>)}
          </div>
        </details>
        <span className="mx-1 h-6 w-px bg-slate-200" aria-hidden />
        <button type="button" className={btn} onClick={undo} disabled={!past.current.length} title={`${t('floor:deshacer')} (Ctrl+Z)`} aria-label={t('floor:deshacer')}><Undo2 className="h-4 w-4" /></button>
        <button type="button" className={btn} onClick={redo} disabled={!future.current.length} title={`${t('floor:rehacer')} (Ctrl+Y)`} aria-label={t('floor:rehacer')}><Redo2 className="h-4 w-4" /></button>
        <button type="button" className={btn} onClick={duplicate} disabled={!selected.length} title={`${t('floor:duplicar')} (Ctrl+D)`} aria-label={t('floor:duplicar')}><Copy className="h-4 w-4" /></button>
        <button type="button" className={btn} onClick={() => rotate(-15)} disabled={!selected.length} title={t('floor:girar_izq')} aria-label={t('floor:girar_izq')}><RotateCcw className="h-4 w-4" /></button>
        <button type="button" className={btn} onClick={() => rotate(15)} disabled={!selected.length} title={`${t('floor:girar_der')} (R)`} aria-label={t('floor:girar_der')}><RotateCw className="h-4 w-4" /></button>
        <button type="button" className={`${btn} text-rose-700`} onClick={remove} disabled={!selected.length} title={`${t('floor:quitar')} (Supr)`} aria-label={t('floor:quitar')}><Trash2 className="h-4 w-4" /></button>
        <span className="mx-1 h-6 w-px bg-slate-200" aria-hidden />
        {([['left', AlignStartVertical], ['hcenter', AlignCenterVertical], ['right', AlignEndVertical], ['top', AlignStartHorizontal], ['vcenter', AlignCenterHorizontal], ['bottom', AlignEndHorizontal]] as const).map(([m, Icon]) => (
          <button key={m} type="button" className={btn} onClick={() => doAlign(m)} disabled={selected.length < 2} title={t(`floor:alinear_${m}`)} aria-label={t(`floor:alinear_${m}`)}><Icon className="h-4 w-4" /></button>
        ))}
        <button type="button" className={btn} onClick={() => doDistribute('x')} disabled={selected.length < 3} title={t('floor:distribuir_x')}>↔</button>
        <button type="button" className={btn} onClick={() => doDistribute('y')} disabled={selected.length < 3} title={t('floor:distribuir_y')}>↕</button>
        <span className="mx-1 h-6 w-px bg-slate-200" aria-hidden />
        <button type="button" className={`${btn} ${snapOn ? 'bg-blue-50 text-blue-800' : ''}`} onClick={() => setSnapOn((s) => !s)} aria-pressed={snapOn} title={t('floor:iman')}><Magnet className="h-4 w-4" aria-hidden /><Grid3x3 className="h-4 w-4" aria-hidden /></button>
        <button type="button" className={btn} onClick={() => setZoom((z) => Math.max(0.3, +(z - 0.1).toFixed(2)))} aria-label={t('floor:alejar')}><Minus className="h-4 w-4" /></button>
        <span className="w-12 text-center text-xs font-bold tabular-nums text-slate-600">{Math.round(zoom * 100)}%</span>
        <button type="button" className={btn} onClick={() => setZoom((z) => Math.min(2, +(z + 0.1).toFixed(2)))} aria-label={t('floor:acercar')}><Plus className="h-4 w-4" /></button>
        <span className="ml-auto flex items-center gap-1">
          {dirty && <span className="px-2 text-xs font-bold text-amber-700">{t('floor:sin_guardar')}</span>}
          <button type="button" className={btn} onClick={discard} disabled={!dirty || saving}><X className="h-4 w-4" aria-hidden />{t('floor:descartar')}</button>
          <button type="button" onClick={save} disabled={!dirty || saving} className="inline-flex h-9 items-center gap-1.5 rounded-lg bg-emerald-600 px-3 text-sm font-bold text-white disabled:opacity-50">
            {saving ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <Save className="h-4 w-4" aria-hidden />}{t('floor:guardar')}
          </button>
          {onClose && <button type="button" className={btn} onClick={onClose} aria-label={t('floor:cerrar')}><X className="h-4 w-4" /></button>}
        </span>
      </div>

      {/* Zonas como capas */}
      <div className="flex flex-wrap items-center gap-1.5" role="tablist" aria-label={t('floor:zonas')}>
        {[ALL, ...zones].map((z) => (
          <button key={z} type="button" role="tab" aria-selected={zone === z} onClick={() => { setZone(z); setSel(new Set()); }} className={`rounded-full border px-3 py-1.5 text-xs font-bold ${zone === z ? 'border-slate-900 bg-slate-900 text-white' : 'border-slate-200 bg-white text-slate-700'}`}>
            {z === ALL ? t('floor:todas_zonas') : z}
          </button>
        ))}
        <form className="flex items-center gap-1" onSubmit={(e) => { e.preventDefault(); const v = String(new FormData(e.currentTarget).get('z') || '').trim().slice(0, 40); if (v) { setZone(v); if (selected.length) setProp({ zone: v }); } e.currentTarget.reset(); }}>
          <input name="z" placeholder={t('floor:nueva_zona')} className="w-32 rounded-full border border-dashed border-slate-300 px-3 py-1.5 text-xs" aria-label={t('floor:nueva_zona')} />
        </form>
      </div>

      <div className="grid gap-3 xl:grid-cols-[1fr_17rem]">
        {/* Lienzo */}
        <div ref={canvas} className="relative h-[68vh] overflow-auto rounded-2xl border border-slate-200 bg-slate-100" onPointerMove={onMove} onPointerUp={endMove} onPointerLeave={endMove}
          onWheel={(e) => { if (e.ctrlKey) { e.preventDefault(); setZoom((z) => clamp(+(z - Math.sign(e.deltaY) * 0.1).toFixed(2), 0.3, 2)); } }}>
          <div
            data-canvas="1"
            onPointerDown={startBand}
            className="relative origin-top-left bg-white"
            style={{
              width: CANVAS.width, height: CANVAS.height, transform: `scale(${zoom})`,
              backgroundImage: snapOn ? 'radial-gradient(circle, #cbd5e1 1px, transparent 1px)' : undefined, backgroundSize: `${GRID * 2}px ${GRID * 2}px`,
            }}
          >
            {visible.map((i) => {
              const on = sel.has(i.key);
              const base: React.CSSProperties = { left: i.x, top: i.y, width: i.w, height: i.h, transform: `rotate(${i.rotation}deg)` };
              if (i.type === 'element') {
                return (
                  <div key={i.key} onPointerDown={(e) => startMove(e, i, 'move')} style={base}
                    className={`absolute flex cursor-move select-none items-center justify-center rounded-md text-xs ${ELEMENT_STYLE[i.kind]} ${on ? 'outline outline-2 outline-offset-2 outline-blue-600' : ''}`}>
                    {i.label && <span className="truncate px-1">{i.label}</span>}
                    {on && one?.key === i.key && <span onPointerDown={(e) => startMove(e, i, 'resize')} className="absolute -bottom-2 -right-2 h-4 w-4 cursor-nwse-resize rounded-sm border-2 border-white bg-blue-600" aria-hidden />}
                  </div>
                );
              }
              return (
                <div key={i.key} onPointerDown={(e) => startMove(e, i, 'move')} style={base}
                  className={`absolute flex cursor-move select-none flex-col items-center justify-center border-2 bg-emerald-50 text-emerald-950 shadow-sm ${i.shape === 'round' ? 'rounded-full' : 'rounded-xl'} ${on ? 'border-blue-600 ring-4 ring-blue-200' : 'border-emerald-300'}`}>
                  <span className="text-lg font-black leading-none" style={{ transform: `rotate(${-i.rotation}deg)` }}>{i.number}</span>
                  <span className="text-[10px] font-semibold opacity-70" style={{ transform: `rotate(${-i.rotation}deg)` }}>{i.capacity}p</span>
                  {on && one?.key === i.key && <span onPointerDown={(e) => startMove(e, i, 'resize')} className="absolute -bottom-2 -right-2 h-4 w-4 cursor-nwse-resize rounded-sm border-2 border-white bg-blue-600" aria-hidden />}
                </div>
              );
            })}
            {guides.map((g, k) => g.axis === 'x'
              ? <div key={k} className="pointer-events-none absolute top-0 h-full w-px bg-fuchsia-500" style={{ left: g.at }} />
              : <div key={k} className="pointer-events-none absolute left-0 h-px w-full bg-fuchsia-500" style={{ top: g.at }} />)}
            {band && <div className="pointer-events-none absolute border border-blue-500 bg-blue-500/10" style={{ left: Math.min(band.x0, band.x1), top: Math.min(band.y0, band.y1), width: Math.abs(band.x1 - band.x0), height: Math.abs(band.y1 - band.y0) }} />}
          </div>
        </div>

        {/* Propiedades */}
        <aside className="space-y-3 rounded-2xl border border-slate-200 bg-white p-4 text-sm">
          {!selected.length && (
            <div className="space-y-2 text-xs text-slate-600">
              <p className="font-bold text-slate-900">{t('floor:atajos')}</p>
              <ul className="space-y-1">{[1, 2, 3, 4, 5, 6].map((n) => <li key={n}>{t(`floor:atajo_${n}`)}</li>)}</ul>
            </div>
          )}
          {selected.length > 1 && (
            <div className="space-y-2">
              <p className="font-bold text-slate-900">{t('floor:n_seleccionados', { count: selected.length })}</p>
              <label className="block text-xs font-bold text-slate-700">{t('floor:zona')}
                <input className={field} defaultValue="" placeholder={t('floor:mover_a_zona')} onBlur={(e) => { const v = e.target.value.trim(); if (v) setProp({ zone: v }); }} />
              </label>
            </div>
          )}
          {one && one.type === 'table' && (
            <div className="space-y-2.5">
              <p className="font-bold text-slate-900">{t('floor:mesa_n', { number: one.number })}</p>
              <div className="grid grid-cols-2 gap-2">
                <label className="text-xs font-bold text-slate-700">{t('floor:numero')}<input className={field} value={one.number} maxLength={12} onChange={(e) => setProp({ number: e.target.value })} /></label>
                <label className="text-xs font-bold text-slate-700">{t('floor:puestos')}<input type="number" min={1} max={99} className={field} value={one.capacity} onChange={(e) => setProp({ capacity: clamp(Number(e.target.value) || 1, 1, 99) })} /></label>
              </div>
              <div className="grid grid-cols-4 gap-1" role="radiogroup" aria-label={t('floor:forma')}>
                {TABLE_SHAPES.map((s) => <button key={s} type="button" role="radio" aria-checked={one.shape === s} onClick={() => setProp({ shape: s, ...(DEFAULT_TABLE_SIZE[s]) && { w: DEFAULT_TABLE_SIZE[s].w, h: DEFAULT_TABLE_SIZE[s].h } })} className={`rounded-lg border px-1 py-1.5 text-[11px] font-bold ${one.shape === s ? 'border-blue-600 bg-blue-50 text-blue-800' : 'border-slate-200'}`}>{t(`floor:forma_${s}`)}</button>)}
              </div>
              <div className="grid grid-cols-3 gap-2">
                <label className="text-xs font-bold text-slate-700">{t('floor:ancho')}<input type="number" className={field} value={one.w} onChange={(e) => setProp({ w: clamp(Number(e.target.value) || MIN_SIZE, MIN_SIZE, MAX_SIZE) })} /></label>
                <label className="text-xs font-bold text-slate-700">{t('floor:alto')}<input type="number" className={field} value={one.h} onChange={(e) => setProp({ h: clamp(Number(e.target.value) || MIN_SIZE, MIN_SIZE, MAX_SIZE) })} /></label>
                <label className="text-xs font-bold text-slate-700">{t('floor:giro')}<input type="number" className={field} value={one.rotation} onChange={(e) => setProp({ rotation: normRotation(Number(e.target.value) || 0) })} /></label>
              </div>
              <label className="block text-xs font-bold text-slate-700">{t('floor:zona')}<input className={field} value={one.zone || ''} onChange={(e) => setProp({ zone: e.target.value.trim() || null })} /></label>
              <label className="flex items-center gap-2 text-xs font-semibold text-slate-700"><input type="checkbox" checked={one.reservable} onChange={(e) => setProp({ reservable: e.target.checked })} className="h-4 w-4 accent-blue-600" />{t('floor:reservable')}</label>
            </div>
          )}
          {one && one.type === 'element' && (
            <div className="space-y-2.5">
              <p className="font-bold text-slate-900">{t(`floor:el_${one.kind}`)}</p>
              <label className="block text-xs font-bold text-slate-700">{t('floor:texto')}<input className={field} value={one.label || ''} maxLength={40} onChange={(e) => setProp({ label: e.target.value || null })} /></label>
              <div className="grid grid-cols-3 gap-2">
                <label className="text-xs font-bold text-slate-700">{t('floor:ancho')}<input type="number" className={field} value={one.w} onChange={(e) => setProp({ w: clamp(Number(e.target.value) || 4, 4, CANVAS.width) })} /></label>
                <label className="text-xs font-bold text-slate-700">{t('floor:alto')}<input type="number" className={field} value={one.h} onChange={(e) => setProp({ h: clamp(Number(e.target.value) || 4, 4, CANVAS.height) })} /></label>
                <label className="text-xs font-bold text-slate-700">{t('floor:giro')}<input type="number" className={field} value={one.rotation} onChange={(e) => setProp({ rotation: normRotation(Number(e.target.value) || 0) })} /></label>
              </div>
              <label className="block text-xs font-bold text-slate-700">{t('floor:zona')}<input className={field} value={one.zone || ''} onChange={(e) => setProp({ zone: e.target.value.trim() || null })} /></label>
            </div>
          )}
        </aside>
      </div>
    </div>
  );
};
