// ============================================
// Verifica que los idiomas estén completos y coherentes:
//  - mismas claves en es y en (sin faltantes ni sobrantes)
//  - mismas variables {{...}} en cada traducción
//  - ninguna traducción vacía
// Uso: node scripts/check-i18n.mjs   (sale con código 1 si algo falla)
// ============================================

import fs from 'fs';
import path from 'path';

const LOCALES = path.resolve('src/locales');
const BASE = 'es';
const langs = fs.readdirSync(LOCALES).filter(d => fs.statSync(path.join(LOCALES, d)).isDirectory());
const load = (lang, ns) => JSON.parse(fs.readFileSync(path.join(LOCALES, lang, `${ns}.json`), 'utf-8'));
const vars = (s) => [...String(s).matchAll(/\{\{(\w+)\}\}/g)].map(m => m[1]).sort().join(',');

const problems = [];
let total = 0;
const namespaces = fs.readdirSync(path.join(LOCALES, BASE)).map(f => f.replace(/\.json$/, ''));

for (const lang of langs.filter(l => l !== BASE)) {
  for (const ns of namespaces) {
    const file = path.join(LOCALES, lang, `${ns}.json`);
    if (!fs.existsSync(file)) {
      problems.push(`[${lang}] falta el archivo ${ns}.json`);
      continue;
    }
    const base = load(BASE, ns);
    const other = load(lang, ns);
    for (const [key, value] of Object.entries(base)) {
      total++;
      if (!(key in other)) problems.push(`[${lang}] ${ns}:${key} sin traducir  (${JSON.stringify(value)})`);
      else if (!String(other[key]).trim()) problems.push(`[${lang}] ${ns}:${key} vacío`);
      else if (vars(value) !== vars(other[key])) problems.push(`[${lang}] ${ns}:${key} variables distintas: es={${vars(value)}} ${lang}={${vars(other[key])}}`);
    }
    for (const key of Object.keys(other)) {
      if (!(key in base)) problems.push(`[${lang}] ${ns}:${key} sobra (no existe en ${BASE})`);
    }
  }
}

if (problems.length) {
  console.log(problems.join('\n'));
  console.log(`\n✗ ${problems.length} problemas de traducción`);
  process.exit(1);
}
console.log(`✓ ${total} textos traducidos en ${langs.length - 1} idioma(s) adicional(es), ${namespaces.length} namespaces`);
