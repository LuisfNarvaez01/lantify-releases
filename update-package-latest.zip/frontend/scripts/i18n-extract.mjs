// ============================================
// i18n — Extractor de textos visibles
// ============================================
// Recorre el frontend con el compilador de TypeScript, detecta el texto que ve el
// usuario y lo reemplaza por t('ns:clave', {...}), guardando el original en
// src/locales/es/<ns>.json.
//
//   node scripts/i18n-extract.mjs --report     → lista lo que encontraría (no modifica nada)
//   node scripts/i18n-extract.mjs --apply      → reescribe los archivos y los JSON
//   node scripts/i18n-extract.mjs --check      → falla si queda texto sin traducir (uso en CI)
//
// Reglas para NO tocar valores internos:
//  - el tipo contextual es una unión de literales ('ORDERED' | 'PENDING', ids de pestañas...)
//  - atributos JSX que no son texto (className, key, type...), comparaciones, switch/case
//  - llamadas técnicas (fetch, localStorage, console, addEventListener, includes...)
//  - constantes de módulo (se evaluarían una sola vez): se reportan para revisión manual

import ts from 'typescript';
import fs from 'fs';
import path from 'path';

const ROOT = path.resolve('src');
const LOCALES = path.join(ROOT, 'locales');
const MODE = process.argv.includes('--apply') ? 'apply' : process.argv.includes('--check') ? 'check' : 'report';
const ONLY = process.argv.find(a => a.startsWith('--only='))?.slice(7);

// ── Archivo → namespace ─────────────────────────────────────
const NAMESPACE_RULES = [
  [/components\/(Login|ChangePasswordScreen)\.tsx$/, 'auth'],
  [/components\/layout\//, 'layout'],
  [/components\/common\/UpdateModal\.tsx$/, 'layout'],
  [/App\.tsx$/, 'layout'],
  [/components\/common\//, 'common'],
  [/shared\/(dialog|toast)\.ts$/, 'common'],
  [/components\/pos\/(CashSessionPanel|CashMovementsTab|ExpenseReportTab|MonthlyArqueoReport)\.tsx$/, 'cash'],
  [/components\/pos\/SalesHistory\.tsx$/, 'sales'],
  [/components\/pos\/AnalyticsModule\.tsx$/, 'analytics'],
  [/components\/pos\/(RappiOrdersPanel|WhatsAppBotSimulator|IncomingOrderNotification)\.tsx$/, 'delivery'],
  [/components\/pos\/ElectronicInvoiceModal\.tsx$/, 'dian'],
  [/components\/pos\//, 'pos'],
  [/store\//, 'pos'],
  [/components\/public\//, 'store'],
  [/components\/admin\/DianBillingAdmin\.tsx$/, 'dian'],
  [/components\/admin\/InventoryModule\.tsx$/, 'inventory'],
  [/components\/admin\/CustomersAdmin\.tsx$/, 'customers'],
  [/components\/admin\/SystemConfigAdmin\.tsx$/, 'settings'],
  [/components\/(AdminPanel|admin\/)/, 'admin'],
  [/services\/(api|authFetch)\.ts$/, 'errors'],
];

// Archivos que no se procesan (se traducen a mano o no tienen texto de interfaz)
const SKIP_FILES = [/locales\//, /i18n\//, /\.d\.ts$/, /services\/printService\.ts$/, /shared\/theme\//, /config\.ts$/, /main\.tsx$/];

const nsFor = (file) => {
  const rel = path.relative(ROOT, file).replace(/\\/g, '/');
  for (const [re, ns] of NAMESPACE_RULES) if (re.test(rel)) return ns;
  return 'common';
};

// ── Heurísticas de texto ─────────────────────────────────────
const TEXT_ATTRS = new Set(['placeholder', 'title', 'aria-label', 'alt', 'label', 'confirmLabel', 'cancelLabel', 'message', 'description', 'subtitle', 'tooltip', 'heading', 'emptyText', 'helperText']);
const NON_TEXT_PROPS = new Set(['id', 'key', 'type', 'status', 'method', 'role', 'variant', 'tone', 'icon', 'color', 'className', 'value', 'code', 'channel', 'paymentMethod', 'mode', 'kind', 'href', 'url', 'path', 'field', 'size', 'align', 'position', 'currency', 'locale', 'sku', 'prefix', 'dot', 'border', 'card', 'badge', 'bg', 'text', 'ring', 'accent', 'primary', 'hover', 'light', 'header', 'fontScale', 'tab', 'subTab', 'action', 'entityType', 'format', 'inputMode', 'autoComplete']);
const TECH_CALLEE = /(^|\.)(fetch|getItem|setItem|removeItem|addEventListener|removeEventListener|querySelector|querySelectorAll|getElementById|includes|startsWith|endsWith|indexOf|split|replace|replaceAll|join|toLocaleDateString|toLocaleTimeString|toLocaleString|NumberFormat|DateTimeFormat|dispatchEvent|CustomEvent|matchMedia|createElement|setProperty|getPropertyValue|parse|stringify|log|warn|error|info|debug|t|tr|setActiveTab|setSubTab|setTab|setFilter|setMode|setView|setStatus|setPaymentMethod|setSortBy|setDeliverySubTab|test|match|padStart|padEnd|toFixed|getAttribute|setAttribute|writeFile|aoa_to_sheet|book_append_sheet|open|focus|scrollTo|closest|atob|btoa|encodeURIComponent|decodeURIComponent)$/;
const SKIP_EXACT = new Set(['Bearer', 'Content-Type', 'Content-Disposition', 'Authorization', 'Escape', 'Enter', 'Tab', 'Backspace', 'Delete', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Rubik', 'Outfit', 'Inter', 'Lantify', 'Lantify POS', 'POS', 'COP', 'DIAN', 'NIT', 'SKU', 'Factus', 'Rappi', 'WhatsApp', 'Excel', 'PDF', 'XML', 'CUFE', 'QR', 'OK', 'Nequi', 'Daviplata', 'Bancolombia', 'Visa', 'Mastercard', 'PSE']);
const SPANISH_CHARS = /[áéíóúñÁÉÍÓÚÑ¿¡]/;
// Palabras reservadas de HTML/CSS que aparecen como valores, no como texto
const TECH_WORDS = new Set(['none', 'auto', 'all', 'text', 'password', 'off', 'on', 'small', 'medium', 'large', 'transparent', 'inherit', 'center', 'left', 'right', 'top', 'bottom', 'block', 'flex', 'grid', 'hidden', 'visible', 'width', 'height', 'submit', 'button', 'reset', 'number', 'email', 'tel', 'search', 'date', 'checkbox', 'radio', 'smooth', 'instant', 'blob', 'arraybuffer', 'utf-8', 'base64', 'default', 'pointer', 'bold', 'normal', 'italic', 'currentColor', 'px']);

const looksLikeText = (raw, { allowSingleLower = false, jsxText = false } = {}) => {
  const s = raw.replace(/\s+/g, ' ').trim();
  if (s.length < 2 || !/[A-Za-zÁÉÍÓÚáéíóúñÑ]/.test(s)) return false;
  if (SKIP_EXACT.has(s) || TECH_WORDS.has(s)) return false;
  if (/<\/?[a-z][^>]*>/i.test(s)) return false; // HTML (tickets impresos: se traducen a mano)
  if (/@/.test(s) && !/\s/.test(s)) return false; // correos de ejemplo
  if (/^[a-z0-9]+(_[a-z0-9]+)+$/i.test(s) || /^_/.test(s)) return false; // snake_case / claves
  if (s.split(' ').every(tk => /^-?\d+(\.\d+)?(px|mm|cm|rem|em|%|ms|s|vh|vw|fr|deg)?$/.test(tk))) return false; // medidas CSS
  if (!/\s/.test(s) && /[,=&?;]/.test(s) && !/^[A-ZÁÉÍÓÚ¿¡]/.test(s)) return false; // CSV, query strings
  if (/\/$/.test(s) && !/\s/.test(s)) return false; // rutas de carpeta
  if (/^[a-z]+\/[a-z0-9+.-]+$/.test(s)) return false; // tipos MIME
  if (/^(https?:|mailto:|tel:|data:|\/|\.\/|#[0-9a-f]{3,8}$)/i.test(s)) return false;
  if (/\.(svg|png|jpe?g|tsx?|jsx?|json|css|xlsx|csv|pdf|xml|txt|zip|db)$/i.test(s)) return false;
  if (/^[A-Z0-9_.-]+$/.test(s) && !SPANISH_CHARS.test(s) && s.length <= 3) return false; // siglas cortas
  if (/^[A-Z][A-Z0-9_]+$/.test(s) && !(jsxText && /^[A-ZÁÉÍÓÚÑ]{4,}$/.test(s))) return false; // CONSTANTES / enums
  if (/^[a-z]+([A-Z][a-z0-9]*)+$/.test(s)) return false; // camelCase
  const tokens = s.split(' ');
  // listas de clases CSS
  if (tokens.every(tk => /^[!a-z0-9:[\]\/.%#()_-]+$/i.test(tk)) && tokens.some(tk => /[-:[]/.test(tk)) && !SPANISH_CHARS.test(s) && !/^[A-ZÁÉÍÓÚ]/.test(s) && !tokens.some(tk => /^[A-ZÁÉÍÓÚ][a-záéíóúñ]+$/.test(tk))) return false;
  if (tokens.length === 1) {
    if (/^[a-z][a-z0-9_-]*$/.test(s) && !SPANISH_CHARS.test(s)) return allowSingleLower;
    if (/^[a-z0-9_-]+\.[a-z0-9_-][a-z0-9_.-]*$/i.test(s)) return false; // claves tipo a.b.c
  }
  return true;
};

// ── Claves ───────────────────────────────────────────────────
const slug = (text) => {
  const base = text
    .normalize('NFD').replace(/[̀-ͯ]/g, '')
    .replace(/\{\{(\w+)\}\}/g, ' $1 ')
    .toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim()
    .split(' ').filter(Boolean).slice(0, 7).join('_');
  return (base || 'texto').slice(0, 50).replace(/_+$/, '');
};

const catalogs = {}; // ns -> { key: text }
const textToKey = {}; // ns -> { text: key }

const loadCatalog = (ns) => {
  if (catalogs[ns]) return;
  const file = path.join(LOCALES, 'es', `${ns}.json`);
  catalogs[ns] = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf-8')) : {};
  textToKey[ns] = Object.fromEntries(Object.entries(catalogs[ns]).map(([k, v]) => [v, k]));
};

const keyFor = (ns, text) => {
  loadCatalog(ns);
  if (textToKey[ns][text]) return textToKey[ns][text];
  let key = slug(text);
  let i = 2;
  while (catalogs[ns][key] !== undefined && catalogs[ns][key] !== text) key = `${slug(text)}_${i++}`;
  catalogs[ns][key] = text;
  textToKey[ns][text] = key;
  return key;
};

// ── Programa TypeScript (para el verificador de tipos) ───────
const configPath = ts.findConfigFile('.', ts.sys.fileExists, 'tsconfig.json');
const parsed = ts.parseJsonConfigFileContent(ts.readConfigFile(configPath, ts.sys.readFile).config, ts.sys, '.');
const program = ts.createProgram(parsed.fileNames, parsed.options);
const checker = program.getTypeChecker();

const isLiteralUnionContext = (node) => {
  const ctx = checker.getContextualType(node);
  if (!ctx) return false;
  const types = ctx.isUnion() ? ctx.types : [ctx];
  const nonUndefined = types.filter(tp => !(tp.flags & (ts.TypeFlags.Undefined | ts.TypeFlags.Null)));
  return nonUndefined.length > 0 && nonUndefined.every(tp => tp.isStringLiteral());
};

const isStringish = (expr) => {
  const type = checker.getTypeAtLocation(expr);
  const types = type.isUnion() ? type.types : [type];
  return types.every(tp =>
    tp.flags & (ts.TypeFlags.StringLike | ts.TypeFlags.NumberLike | ts.TypeFlags.BooleanLike | ts.TypeFlags.Undefined | ts.TypeFlags.Null | ts.TypeFlags.BigIntLike));
};

const insideFunction = (node) => {
  for (let p = node.parent; p; p = p.parent) {
    if (ts.isFunctionLike(p)) return true;
  }
  return false;
};

const calleeText = (call, sf) => call.expression.getText(sf);

const isUserFacingLiteral = (node, sf) => {
  const p = node.parent;
  if (!p) return false;
  if (ts.isImportDeclaration(p) || ts.isExportDeclaration(p) || ts.isLiteralTypeNode(p) || ts.isExternalModuleReference(p)) return false;
  if (ts.isPropertyAssignment(p) && p.name === node) return false;
  if (ts.isElementAccessExpression(p) && p.argumentExpression === node) return false;
  if (ts.isCaseClause(p)) return false;
  if (ts.isBinaryExpression(p) && [ts.SyntaxKind.EqualsEqualsEqualsToken, ts.SyntaxKind.ExclamationEqualsEqualsToken, ts.SyntaxKind.EqualsEqualsToken, ts.SyntaxKind.ExclamationEqualsToken, ts.SyntaxKind.InKeyword].includes(p.operatorToken.kind)) return false;
  if (isLiteralUnionContext(node)) return false;

  // Ancestros: atributos JSX, propiedades y llamadas técnicas
  for (let a = node.parent; a && !ts.isFunctionLike(a) && !ts.isSourceFile(a); a = a.parent) {
    if (ts.isJsxAttribute(a)) {
      const name = a.name.getText(sf);
      return TEXT_ATTRS.has(name);
    }
    if (ts.isPropertyAssignment(a) && ts.isIdentifier(a.name) && NON_TEXT_PROPS.has(a.name.text)) return false;
    if (ts.isCallExpression(a) && TECH_CALLEE.test(calleeText(a, sf))) return false;
    if (ts.isNewExpression(a) && /^(Date|RegExp|URL|CustomEvent|Intl\.)/.test(a.expression.getText(sf))) return false;
    if (ts.isBinaryExpression(a) && [ts.SyntaxKind.EqualsEqualsEqualsToken, ts.SyntaxKind.ExclamationEqualsEqualsToken].includes(a.operatorToken.kind)) return false;
    if (ts.isJsxExpression(a)) {
      if (ts.isJsxAttribute(a.parent)) return TEXT_ATTRS.has(a.parent.name.getText(sf));
      break;
    }
    if (ts.isJsxElement(a)) break;
  }
  return true;
};

// Texto JSX según las reglas de React (líneas recortadas y unidas por espacio)
const cleanJsxText = (raw) => {
  const lines = raw.split(/\r\n|\n|\r/);
  if (lines.length === 1) return raw;
  let out = '';
  lines.forEach((line, i) => {
    let l = line.replace(/\t/g, ' ');
    if (i !== 0) l = l.replace(/^[ ]+/, '');
    if (i !== lines.length - 1) l = l.replace(/[ ]+$/, '');
    if (l) out += (out ? ' ' : '') + l;
  });
  return out;
};

const varName = (expr, sf, used) => {
  let base = 'value';
  let e = expr;
  while (ts.isParenthesizedExpression(e) || ts.isNonNullExpression(e)) e = e.expression;
  if (ts.isIdentifier(e)) base = e.text;
  else if (ts.isPropertyAccessExpression(e)) base = e.name.text;
  else if (ts.isCallExpression(e)) {
    const c = e.expression.getText(sf);
    if (/formatCurrency/.test(c)) base = 'amount';
    else if (ts.isPropertyAccessExpression(e.expression) && /^to(Locale)?/.test(e.expression.name.text) && ts.isIdentifier(e.expression.expression)) base = e.expression.expression.text;
    else if (ts.isPropertyAccessExpression(e.expression) && ts.isPropertyAccessExpression(e.expression.expression)) base = e.expression.expression.name.text;
    else base = 'value';
  } else if (ts.isElementAccessExpression(e) && ts.isIdentifier(e.expression)) base = e.expression.text;
  base = base.replace(/[^A-Za-z0-9_]/g, '') || 'value';
  let name = base;
  let i = 2;
  while (used.has(name)) name = `${base}${i++}`;
  used.add(name);
  return name;
};

const NODE_NAME = /icon|children|element|node|content|component|render|badge|avatar|logo/i;

const isSimpleValueExpr = (e) => {
  while (ts.isParenthesizedExpression(e) || ts.isNonNullExpression(e)) e = e.expression;
  if (ts.isIdentifier(e)) return !NODE_NAME.test(e.text);
  if (ts.isPropertyAccessExpression(e)) return !NODE_NAME.test(e.name.text);
  if (ts.isElementAccessExpression(e)) return true;
  if (ts.isBinaryExpression(e) && [ts.SyntaxKind.BarBarToken, ts.SyntaxKind.QuestionQuestionToken].includes(e.operatorToken.kind)) {
    return isSimpleValueExpr(e.left) && (isSimpleValueExpr(e.right) || ts.isStringLiteral(e.right) || ts.isNumericLiteral(e.right));
  }
  return false;
};

const interpolatable = (expr) => {
  if (!expr) return false;
  let found = false;
  const walk = (n) => {
    if (ts.isJsxElement(n) || ts.isJsxSelfClosingElement(n) || ts.isJsxFragment(n)) found = true;
    if (!found) ts.forEachChild(n, walk);
  };
  walk(expr);
  if (found) return false;
  if (isStringish(expr)) return true;
  const type = checker.getTypeAtLocation(expr);
  return !!(type.flags & ts.TypeFlags.Any) && isSimpleValueExpr(expr);
};

// ── Procesamiento de un archivo ─────────────────────────────
const report = [];
const moduleLevel = [];
let filesChanged = 0;

const declaresLocalT = (sf) => {
  let found = false;
  const walk = (n) => {
    if ((ts.isVariableDeclaration(n) || ts.isParameter(n) || ts.isBindingElement(n) || ts.isFunctionDeclaration(n)) && n.name && ts.isIdentifier(n.name) && n.name.text === 't') found = true;
    if (!found) ts.forEachChild(n, walk);
  };
  walk(sf);
  return found;
};

const processFile = (sf) => {
  const file = sf.fileName;
  const ns = nsFor(file);
  const fn = declaresLocalT(sf) ? 'tr' : 't';
  const edits = []; // { start, end, render(renderRange) }
  const src = sf.text;

  const tCall = (key, params) => {
    const entries = Object.entries(params);
    return entries.length === 0 ? `${fn}('${ns}:${key}')` : `${fn}('${ns}:${key}', { ${entries.map(([k, v]) => (k === v ? k : `${k}: ${v}`)).join(', ')} })`;
  };

  const addLiteralEdit = (node, inJsxAttr) => {
    const text = node.text;
    const message = text;
    if (!looksLikeText(message, { allowSingleLower: !!findJsxAncestor(node) })) return;
    if (!insideFunction(node)) {
      if (asGetter(node, message)) return;
      moduleLevel.push(`${path.relative(ROOT, file)}:${sf.getLineAndCharacterOfPosition(node.getStart(sf)).line + 1}  ${JSON.stringify(message)}`);
      return;
    }
    const key = keyFor(ns, message);
    edits.push({ start: node.getStart(sf), end: node.getEnd(), render: () => (inJsxAttr ? `{${tCall(key, {})}}` : tCall(key, {})) });
    report.push(`${path.relative(ROOT, file)}  ${ns}:${key}  ${JSON.stringify(message)}`);
  };

  // Una palabra suelta en minúscula ('producto' / 'productos') solo cuenta como texto si es
  // hijo directo de un elemento JSX (no atributo, ni objeto de estilos, ni argumento)
  // label: 'Texto' en un objeto de módulo → get label() { return t('ns:clave'); }
  const asGetter = (node, message) => {
    const prop = node.parent;
    if (!prop || !ts.isPropertyAssignment(prop) || prop.initializer !== node || !ts.isIdentifier(prop.name)) return false;
    if (!ts.isObjectLiteralExpression(prop.parent)) return false;
    if (NON_TEXT_PROPS.has(prop.name.text)) return false;
    const key = keyFor(ns, message);
    const name = prop.name.text;
    edits.push({ start: prop.getStart(sf), end: prop.getEnd(), render: () => `get ${name}() { return ${tCall(key, {})}; }` });
    report.push(`${path.relative(ROOT, file)}  ${ns}:${key}  ${JSON.stringify(message)}  (getter)`);
    return true;
  };

  const findJsxAncestor = (node) => {
    for (let a = node.parent; a && !ts.isSourceFile(a); a = a.parent) {
      if (ts.isObjectLiteralExpression(a) || ts.isArrayLiteralExpression(a) || ts.isCallExpression(a)) return null;
      if (ts.isJsxExpression(a)) return ts.isJsxAttribute(a.parent) ? null : a;
      if (ts.isFunctionLike(a)) return null;
    }
    return null;
  };

  const addTemplateEdit = (node) => {
    const used = new Set();
    const params = [];
    let message = node.head.text;
    for (const span of node.templateSpans) {
      const name = varName(span.expression, sf, used);
      params.push([name, span.expression]);
      message += `{{${name}}}` + span.literal.text;
    }
    const plain = message.replace(/\{\{\w+\}\}/g, ' ');
    // Plantillas: al menos una palabra con minúsculas y aspecto de frase (espacio, tilde o mayúscula inicial)
    const hasWord = /[a-záéíóúñ][A-Za-zÁÉÍÓÚáéíóúñ]{1,}/.test(plain);
    const proseLike = /[A-Za-záéíóúñ]{2,}\s+\S/.test(plain.trim()) || /\S\s+[A-Za-záéíóúñ]{2,}/.test(plain.trim()) || SPANISH_CHARS.test(plain) || /^[A-ZÁÉÍÓÚ¿¡][a-záéíóúñ]/.test(plain.trim());
    if (!looksLikeText(plain) || !hasWord || !proseLike) return;
    if (!insideFunction(node)) {
      moduleLevel.push(`${path.relative(ROOT, file)}:${sf.getLineAndCharacterOfPosition(node.getStart(sf)).line + 1}  ${JSON.stringify(message)}`);
      return;
    }
    const key = keyFor(ns, message);
    const inAttr = ts.isJsxExpression(node.parent) ? false : false;
    edits.push({
      start: node.getStart(sf),
      end: node.getEnd(),
      render: (renderRange) => {
        const obj = {};
        for (const [name, expr] of params) obj[name] = renderRange(expr.getStart(sf), expr.getEnd());
        return tCall(key, obj) + (inAttr ? '' : '');
      },
    });
    report.push(`${path.relative(ROOT, file)}  ${ns}:${key}  ${JSON.stringify(message)}`);
  };

  // Secuencias de texto + expresiones simples dentro de un elemento JSX → un solo mensaje
  const processJsxChildren = (children) => {
    let run = [];
    const flush = () => {
      const hasText = run.some(c => ts.isJsxText(c) && /[A-Za-zÁÉÍÓÚáéíóúñ]/.test(c.text));
      if (!hasText) {
        run = [];
        return;
      }
      // recortar expresiones al inicio/final (quedan fuera del mensaje)
      while (run.length && !ts.isJsxText(run[0])) run.shift();
      while (run.length && !ts.isJsxText(run[run.length - 1])) run.pop();
      const used = new Set();
      const params = [];
      let message = '';
      run.forEach((c, idx) => {
        if (ts.isJsxText(c)) {
          let txt = c.text;
          txt = cleanJsxText(txt);
          message += txt;
        } else {
          const name = varName(c.expression, sf, used);
          params.push([name, c.expression]);
          message += `{{${name}}}`;
        }
      });
      const plain = message.replace(/\{\{\w+\}\}/g, ' ').trim();
      const trimmedMessage = message.replace(/^\s+|\s+$/g, '');
      if (!looksLikeText(plain, { allowSingleLower: true, jsxText: true })) {
        run = [];
        return;
      }
      if (!insideFunction(run[0])) {
        run = [];
        return;
      }
      const key = keyFor(ns, trimmedMessage);
      const first = run[0];
      const last = run[run.length - 1];
      // conservar espacios significativos en los bordes (texto pegado a otro elemento)
      // Un espacio al borde es significativo si está en la misma línea que el texto vecino
      const leading = ts.isJsxText(first) && /^[ \t]+\S/.test(first.text) ? ' ' : '';
      const trailing = ts.isJsxText(last) && /\S[ \t]+$/.test(last.text) ? ' ' : '';
      const start = first.getStart(sf, true) === first.getEnd() ? first.pos : first.pos;
      const runParams = params;
      edits.push({
        start: first.pos,
        end: last.getEnd(),
        render: (renderRange) => {
          const obj = {};
          for (const [name, expr] of runParams) obj[name] = renderRange(expr.getStart(sf), expr.getEnd());
          const leadWs = /^\s*\n\s*/.exec(first.text)?.[0] ?? '';
          const trailWs = /\s*\n\s*$/.exec(last.text)?.[0] ?? '';
          const lead = leading ? `{' '}` : '';
          const trail = trailing ? `{' '}` : '';
          return `${leadWs}${lead}{${tCall(key, obj)}}${trail}${trailWs}`;
        },
      });
      report.push(`${path.relative(ROOT, file)}  ${ns}:${key}  ${JSON.stringify(trimmedMessage)}`);
      run = [];
    };
    for (const c of children) {
      if (ts.isJsxText(c)) run.push(c);
      else if (ts.isJsxExpression(c) && c.expression && !ts.isStringLiteral(c.expression) && interpolatable(c.expression) && run.length) run.push(c);
      else flush();
    }
    flush();
  };

  const visit = (node) => {
    if (ts.isJsxElement(node) || ts.isJsxFragment(node)) {
      processJsxChildren(node.children);
    }
    if (ts.isJsxAttribute(node) && node.initializer && ts.isStringLiteral(node.initializer)) {
      const name = node.name.getText(sf);
      if (TEXT_ATTRS.has(name) && looksLikeText(node.initializer.text)) addLiteralEdit(node.initializer, true);
      return;
    }
    if ((ts.isStringLiteral(node) || ts.isNoSubstitutionTemplateLiteral(node)) && !ts.isJsxAttribute(node.parent)) {
      if (isUserFacingLiteral(node, sf)) addLiteralEdit(node, false);
      return;
    }
    if (ts.isTemplateExpression(node)) {
      if (isUserFacingLiteral(node, sf)) {
        addTemplateEdit(node);
      }
    }
    ts.forEachChild(node, visit);
  };
  visit(sf);

  if (edits.length === 0) return;

  // Aplicar ediciones respetando el anidamiento (las internas se aplican dentro de las externas)
  edits.sort((a, b) => a.start - b.start || b.end - a.end);
  const renderRange = (start, end) => {
    let out = '';
    let pos = start;
    for (let i = 0; i < edits.length; i++) {
      const e = edits[i];
      if (e.start < pos || e.start >= end || e.end > end) continue;
      out += src.slice(pos, e.start);
      out += e.render(renderRange);
      pos = e.end;
    }
    return out + src.slice(pos, end);
  };
  let output = renderRange(0, src.length);

  // Import de t
  if (!/import (i18next, )?\{[^}]*\bt\b[^}]*\} from ['"][./]*i18n['"]/.test(output)) {
    const rel = path.relative(path.dirname(file), path.join(ROOT, 'i18n')).replace(/\\/g, '/');
    const spec = rel.startsWith('.') ? rel : `./${rel}`;
    const imports = [...output.matchAll(/^import [\s\S]*?from ['"][^'"]+['"];?\s*$/gm)];
    const at = imports.length ? imports[imports.length - 1].index + imports[imports.length - 1][0].length : 0;
    output = output.slice(0, at) + `\nimport { ${fn === 't' ? 't' : 't as tr'} } from '${spec}';` + output.slice(at);
  }

  if (MODE === 'apply') {
    fs.writeFileSync(file, output, 'utf-8');
  }
  filesChanged++;
};

for (const sf of program.getSourceFiles()) {
  if (sf.isDeclarationFile) continue;
  const f = sf.fileName.replace(/\\/g, '/');
  if (!f.startsWith(ROOT.replace(/\\/g, '/'))) continue;
  if (SKIP_FILES.some(re => re.test(f))) continue;
  if (ONLY && !f.includes(ONLY)) continue;
  processFile(sf);
}

if (MODE === 'apply') {
  for (const [ns, cat] of Object.entries(catalogs)) {
    fs.mkdirSync(path.join(LOCALES, 'es'), { recursive: true });
    const sorted = Object.fromEntries(Object.entries(cat).sort(([a], [b]) => a.localeCompare(b)));
    fs.writeFileSync(path.join(LOCALES, 'es', `${ns}.json`), JSON.stringify(sorted, null, 2) + '\n', 'utf-8');
  }
}

if (MODE === 'report' || MODE === 'apply') {
  console.log(report.join('\n'));
  console.log(`\n${report.length} textos en ${filesChanged} archivos`);
  if (moduleLevel.length) {
    console.log(`\n${moduleLevel.length} textos en constantes de módulo (revisar a mano):`);
    console.log(moduleLevel.join('\n'));
  }
}

if (MODE === 'check') {
  if (report.length) {
    console.log(report.join('\n'));
    console.log(`\n✗ ${report.length} textos visibles sin pasar por t()`);
    process.exit(1);
  }
  console.log('✓ No quedan textos visibles sin traducir');
}
