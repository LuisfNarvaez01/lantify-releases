// ============================================
// Verifica contraste WCAG 2.2 AA de los pares de color clave, en tema claro
// y oscuro y con cada preset de color principal.
// Uso: node scripts/check-contrast.mjs   (sale con código 1 si algo falla)
// ============================================

import defaultColors from 'tailwindcss/colors.js';
import { familyVars, whiteBlackVars, primaryScale, NEUTRALS, STATUS } from '../src/shared/theme/paletteCore.js';

// Presets de src/shared/themeManager.ts (primary, hover, light)
const PRESETS = {
  zafiro: ['#1e40af', '#1e3a8a', '#eff6ff'],
  cobalto: ['#2563eb', '#1d4ed8', '#eff6ff'],
  espresso: ['#78350f', '#572507', '#fef3c7'],
  esmeralda: ['#047857', '#065f46', '#ecfdf5'],
  borgona: ['#9f1239', '#881337', '#fff1f2'],
  purpura: ['#6d28d9', '#5b21b6', '#f5f3ff'],
  terracota: ['#c2410c', '#9a3412', '#fff7ed'],
  marino: ['#0369a1', '#075985', '#f0f9ff'],
  rubi: ['#be185d', '#9d174d', '#fdf2f8'],
  onyx: ['#334155', '#1e293b', '#f1f5f9'],
};

const lum = (rgb) => {
  const [r, g, b] = rgb.map((v) => {
    const c = v / 255;
    return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
};
const ratio = (a, b) => {
  const [l1, l2] = [lum(a), lum(b)].sort((x, y) => y - x);
  return (l1 + 0.05) / (l2 + 0.05);
};
const parse = (triplet) => triplet.split(' ').map(Number);

const varsFor = (mode, preset) => {
  let vars = { ...whiteBlackVars(mode) };
  for (const n of NEUTRALS) vars = { ...vars, ...familyVars(n, defaultColors[n], mode, true) };
  for (const s of STATUS) vars = { ...vars, ...familyVars(s, defaultColors[s], mode, false) };
  vars = { ...vars, ...familyVars('blue', primaryScale(...preset), mode, false) };
  return vars;
};

// [texto, fondo, mínimo, descripción]
const PAIRS = [
  ['slate-900-tx', 'white-bg', 4.5, 'texto principal sobre tarjeta'],
  ['slate-600-tx', 'white-bg', 4.5, 'texto secundario sobre tarjeta'],
  ['slate-500-tx', 'white-bg', 4.5, 'texto atenuado sobre tarjeta'],
  ['slate-700-tx', 'slate-50-bg', 4.5, 'etiquetas sobre campo de formulario'],
  ['white-tx', 'blue-600-bg', 4.5, 'botón principal'],
  ['blue-700-tx', 'white-bg', 4.5, 'enlace / botón secundario'],
  ['blue-700-tx', 'blue-50-bg', 4.5, 'chip del color principal'],
  ['white-tx', 'emerald-700-bg', 4.5, 'botón Cobrar'],
  ['emerald-800-tx', 'emerald-100-bg', 4.5, 'insignia Libre'],
  ['amber-800-tx', 'amber-100-bg', 4.5, 'insignia En consumo'],
  ['violet-800-tx', 'violet-100-bg', 4.5, 'insignia Por cobrar'],
  ['rose-700-tx', 'rose-50-bg', 4.5, 'mensaje de error'],
  ['white-tx', 'rose-600-bg', 4.5, 'botón destructivo'],
];

let failures = 0;
for (const mode of ['light', 'dark']) {
  for (const [name, preset] of Object.entries(PRESETS)) {
    const v = varsFor(mode, preset);
    for (const [fg, bg, min, label] of PAIRS) {
      // Solo los pares del color principal dependen del preset
      if (name !== 'zafiro' && !fg.startsWith('blue') && !bg.startsWith('blue')) continue;
      const r = ratio(parse(v[`--${fg}`]), parse(v[`--${bg}`]));
      if (r < min) {
        failures++;
        console.log(`✗ [${mode}/${name}] ${label}: ${r.toFixed(2)}:1 (mínimo ${min})`);
      }
    }
  }
}
console.log(failures === 0 ? '✓ Todos los pares cumplen WCAG AA' : `\n${failures} pares por debajo de AA`);
process.exit(failures === 0 ? 0 : 1);
