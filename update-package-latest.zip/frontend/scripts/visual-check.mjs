// ============================================
// Revisión visual: capturas de las pantallas principales en tema claro y oscuro
// ============================================
// Requiere el backend (puerto 5000) y Vite (5173) corriendo, y las cuentas de
// prueba de docs/private/CUENTAS_PRUEBA.md (npm run accounts:test).
//
// Uso: node scripts/visual-check.mjs [carpeta-salida]

import { chromium } from 'playwright-core';
import fs from 'fs';
import path from 'path';

const BASE = process.env.APP_URL || 'http://localhost:5173';
const OUT = path.resolve(process.argv[2] || 'visual-check');
// --lang=en: captura en inglés y busca palabras en español que se hayan escapado
const LANG = (process.argv.find(a => a.startsWith('--lang=')) || '--lang=es').slice(7);
const THEMES = LANG === 'en' ? ['light'] : ['light', 'dark'];

// Palabras frecuentes de la interfaz en español (y que no existen en inglés)
const SPANISH_WORDS = /\b(Mesa|Mesas|Cobrar|Pedido|Pedidos|Caja|Ventas|Venta|Cliente|Productos|Producto|Buscar|Guardar|Cancelar|Configuración|Estadísticas|Usuario|Contraseña|Efectivo|Tarjeta|Transferencia|Libre|Libres|Todas|Cerrar|Abrir|Agregar|Eliminar|Nuevo|Nueva|Mostrador|Inventario|Categoría|Fecha|Hora|Motivo|Gastos|Gasto|Egreso|Egresos|Ingreso|Ingresos|Arqueo|Saldo|Descuento|Enviar|cocina|Seleccionar|Acciones|Precio|Cantidad|ANULADO|BAJO|Corporativo|Ejecutivo|Sin|Desde|con|para|del|las|los)\b/;
const leaks = [];

// Textos del catálogo en español que cambian en inglés (≥ 4 letras, sin variables)
const catalogDir = path.resolve('src', 'locales');
const spanishOnly = new Set();
for (const file of fs.readdirSync(path.join(catalogDir, 'es'))) {
  const es = JSON.parse(fs.readFileSync(path.join(catalogDir, 'es', file), 'utf-8'));
  const en = fs.existsSync(path.join(catalogDir, 'en', file)) ? JSON.parse(fs.readFileSync(path.join(catalogDir, 'en', file), 'utf-8')) : {};
  for (const [k, v] of Object.entries(es)) {
    if (en[k] !== v && !/\{\{/.test(v) && /[A-Za-zÁÉÍÓÚáéíóúñ]{4,}/.test(v)) spanishOnly.add(v.trim());
  }
}

const scanSpanish = async (page, name) => {
  if (LANG !== 'en') return;
  const text = await page.evaluate(() => document.body.innerText);
  const found = new Set();
  for (const raw of text.split('\n')) {
    const line = raw.trim();
    if (!line) continue;
    if (spanishOnly.has(line) || SPANISH_WORDS.test(line)) found.add(line.slice(0, 90));
  }
  if (found.size) leaks.push(`${name}:\n  - ${[...found].slice(0, 25).join('\n  - ')}`);
};
const CHROME = process.env.CHROME_PATH || 'C:/Program Files/Google/Chrome/Application/chrome.exe';

const creds = fs.readFileSync(path.resolve('..', 'docs', 'private', 'CUENTAS_PRUEBA.md'), 'utf-8');
const passwordOf = (user) => {
  const line = creds.split('\n').find(l => l.includes(`\`${user}\``));
  if (!line) throw new Error(`No hay credenciales para ${user}`);
  return line.split('`')[3];
};

fs.mkdirSync(OUT, { recursive: true });

const shot = async (page, name) => {
  await page.waitForTimeout(400);
  await page.screenshot({ path: path.join(OUT, `${name}.png`), fullPage: false });
  await scanSpanish(page, name);
  console.log('📸', name);
};

const tryClick = async (page, locator, label) => {
  try {
    await locator.first().click({ timeout: 3000 });
    return true;
  } catch {
    console.warn('⚠️  No se encontró:', label);
    return false;
  }
};

const run = async (theme) => {
  const browser = await chromium.launch({ executablePath: CHROME, headless: true });
  const context = await browser.newContext({ viewport: { width: 1366, height: 768 } });
  await context.addInitScript(([t, lang]) => {
    localStorage.setItem('lantify.themeMode.last', t);
    localStorage.setItem('lantify.lang.last', lang);
    localStorage.setItem('lantify.onboarding.skipTours', '1');
  }, [theme, LANG]);
  const page = await context.newPage();
  page.on('pageerror', (e) => console.error(`[${theme}] error de página:`, e.message));

  await page.goto(BASE);
  await page.waitForSelector('#login-username');
  await shot(page, `${theme}-01-login`);

  await page.fill('#login-username', 'admin.prueba');
  await page.fill('#login-password', passwordOf('admin.prueba'));
  await page.click('button[type=submit]');
  await page.waitForTimeout(1500);
  await shot(page, `${theme}-02-pedidos`);

  // Agregar productos al pedido de mostrador
  // Productos sin variantes (las variantes abren un modal)
  const cards = page.locator('main .grid > *').filter({ hasText: '$' }).filter({ hasNotText: /\d var/ });
  for (let i = 0; i < 3; i++) await cards.nth(i).click({ timeout: 2000 }).catch(() => {});
  await shot(page, `${theme}-03-pedido-con-productos`);

  // Menú de usuario (selector de tema)
  if (await tryClick(page, page.locator('header').getByText('Admin de Prueba'), 'menú de usuario')) {
    await shot(page, `${theme}-03b-menu-usuario`);
    await page.locator('header').getByText('Admin de Prueba').first().click();
  }

  const TABS = LANG === 'en' ? [['Sales', '04-ventas'], ['Register', '05-caja'], ['Statistics', '06-estadisticas']] : [['Ventas', '04-ventas'], ['Caja', '05-caja'], ['Estadísticas', '06-estadisticas']];
  for (const [tab, name] of TABS) {
    if (await tryClick(page, page.locator('header').getByText(tab, { exact: true }), tab)) {
      await page.waitForTimeout(800);
      await shot(page, `${theme}-${name}`);
    }
  }

  // Panel de administración
  await tryClick(page, page.locator('header').getByText(LANG === 'en' ? 'Orders' : 'Pedidos', { exact: true }), 'Pedidos');
  if (await tryClick(page, page.locator('header').getByText('Admin de Prueba'), 'menú de usuario')) {
    await tryClick(page, page.getByText(LANG === 'en' ? 'Settings Panel' : 'Panel de Configuración'), 'Panel de Configuración');
    await page.waitForTimeout(800);
    await shot(page, `${theme}-07-admin`);
    const ADMIN_TABS = LANG === 'en' ? [['Users', '08-usuarios'], ['Settings', '09-configuracion'], ['Inventory', '10-inventario'], ['Customers', '11-clientes']] : [['Usuarios', '08-usuarios'], ['Configuración', '09-configuracion'], ['Inventario', '10-inventario'], ['Clientes', '11-clientes']];
    for (const [label, name] of ADMIN_TABS) {
      if (await tryClick(page, page.getByRole('button', { name: new RegExp(label, 'i') }), label)) {
        await page.waitForTimeout(700);
        await shot(page, `${theme}-${name}`);
        if (name === '09-configuracion' && await tryClick(page, page.getByRole('button', { name: /Apariencia|Appearance/ }), 'Apariencia')) {
          await page.waitForTimeout(500);
          await shot(page, `${theme}-09b-apariencia`);
        }
      }
    }
  }

  await browser.close();
};

/** Vista del mesero: una sola acción principal (Enviar a cocina) */
const runWaiter = async (theme) => {
  const browser = await chromium.launch({ executablePath: CHROME, headless: true });
  const context = await browser.newContext({ viewport: { width: 1366, height: 768 } });
  await context.addInitScript(([t, lang]) => {
    localStorage.setItem('lantify.themeMode.last', t);
    localStorage.setItem('lantify.lang.last', lang);
  }, [theme, LANG]);
  const page = await context.newPage();
  await page.goto(BASE);
  await page.waitForSelector('#login-username');
  await page.fill('#login-username', 'mesero.prueba');
  await page.fill('#login-password', passwordOf('mesero.prueba'));
  await page.click('button[type=submit]');
  await page.waitForTimeout(1500);
  const cards = page.locator('main .grid > *').filter({ hasText: '$' }).filter({ hasNotText: /\d var/ });
  for (let i = 0; i < 2; i++) await cards.nth(i).click({ timeout: 2000 }).catch(() => {});
  await shot(page, `${theme}-12-mesero`);
  await browser.close();
};

for (const theme of THEMES) {
  await run(theme);
  await runWaiter(theme);
}
if (LANG === 'en') {
  console.log(leaks.length ? `\n⚠️  Posibles textos en español:\n${leaks.join('\n')}` : '\n✓ Sin textos en español visibles');
}
console.log(`\nCapturas en ${OUT}`);
