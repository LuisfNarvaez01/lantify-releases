/** @type {import('tailwindcss').Config} */
import defaultColors from 'tailwindcss/colors';
import plugin from 'tailwindcss/plugin';
import {
  SHADES, NEUTRALS, STATUS, PRIMARY_FAMILY,
  familyVars, whiteBlackVars, primaryScale, semanticVars,
} from './src/shared/theme/paletteCore.js';

// ── Clases de color → variables CSS (ver src/shared/theme/paletteCore.js) ──
const v = (name) => `rgb(var(--${name}) / <alpha-value>)`;
const FAMILIES = [...NEUTRALS, ...STATUS, PRIMARY_FAMILY];

const mapped = (kind) => {
  const out = { white: v(`white-${kind}`), black: v(`black-${kind}`) };
  for (const family of FAMILIES) {
    out[family] = Object.fromEntries(SHADES.map((s) => [s, v(`${family}-${s}-${kind}`)]));
  }
  return out;
};

// Valores por defecto en CSS. El color principal (blue) lo recalcula themeManager
// en el navegador según el preset elegido; aquí va el preset por defecto (Zafiro).
const DEFAULT_PRIMARY = primaryScale('#1e40af', '#1e3a8a', '#eff6ff');

const baseVars = (mode) => {
  let vars = { ...whiteBlackVars(mode), ...semanticVars(mode) };
  for (const n of NEUTRALS) vars = { ...vars, ...familyVars(n, defaultColors[n], mode, true) };
  for (const s of STATUS) vars = { ...vars, ...familyVars(s, defaultColors[s], mode, false) };
  vars = { ...vars, ...familyVars(PRIMARY_FAMILY, DEFAULT_PRIMARY, mode, false) };
  return vars;
};

const themePalettePlugin = plugin(({ addBase }) => {
  addBase({
    ':root': { ...baseVars('light'), colorScheme: 'light' },
    '[data-theme="dark"]': { ...baseVars('dark'), colorScheme: 'dark' },
  });
});

export default {
  darkMode: ['selector', '[data-theme="dark"]'],
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      backgroundColor: mapped('bg'),
      gradientColorStops: mapped('bg'),
      ringOffsetColor: mapped('bg'),
      textColor: mapped('tx'),
      placeholderColor: mapped('tx'),
      fill: mapped('tx'),
      stroke: mapped('tx'),
      borderColor: mapped('bd'),
      divideColor: mapped('bd'),
      ringColor: mapped('bd'),
      outlineColor: mapped('bd'),
      colors: {
        // ── Tokens semánticos: usar en código nuevo ──
        canvas: v('canvas'),
        surface: { DEFAULT: v('white-bg'), sunken: v('slate-50-bg'), muted: v('slate-100-bg'), strong: v('slate-200-bg') },
        fg: { DEFAULT: v('slate-900-tx'), secondary: v('slate-600-tx'), muted: v('slate-500-tx'), subtle: v('slate-400-tx') },
        line: { DEFAULT: v('slate-200-bd'), subtle: v('slate-100-bd'), strong: v('slate-300-bd') },
        primary: {
          DEFAULT: v('blue-600-bg'), hover: v('blue-700-bg'), soft: v('blue-50-bg'),
          text: v('blue-700-tx'), border: v('blue-200-bd'),
        },
        success: { DEFAULT: v('emerald-600-bg'), soft: v('emerald-50-bg'), text: v('emerald-700-tx'), border: v('emerald-200-bd') },
        warning: { DEFAULT: v('amber-500-bg'), soft: v('amber-50-bg'), text: v('amber-800-tx'), border: v('amber-200-bd') },
        danger: { DEFAULT: v('rose-600-bg'), soft: v('rose-50-bg'), text: v('rose-700-tx'), border: v('rose-200-bd') },
        info: { DEFAULT: v('sky-600-bg'), soft: v('sky-50-bg'), text: v('sky-700-tx'), border: v('sky-200-bd') },

        // Compatibilidad con los nombres anteriores
        lantify: {
          dark: '#090d16',
          header: 'var(--lantify-header, #0f172a)',
          slate: '#1e293b',
          card: v('white-bg'),
          bg: v('canvas'),
          subtle: v('slate-100-bg'),
          border: v('slate-200-bd'),
          borderDark: '#334155',
          text: v('slate-900-tx'),
          muted: v('slate-500-tx'),
          primary: v('blue-600-bg'),
          primaryHover: v('blue-700-bg'),
          primaryLight: v('blue-50-bg'),
          accent: 'var(--lantify-accent, #06b6d4)',
          success: v('emerald-500-bg'),
          successLight: v('emerald-50-bg'),
          warning: v('amber-500-bg'),
          warningLight: v('amber-50-bg'),
          danger: v('red-500-bg'),
          dangerLight: v('red-50-bg'),
        }
      },
      fontSize: {
        // Mínimo legible: 12px con la escala estándar (14px) y crece con la escala del usuario
        xs: ['0.8572rem', { lineHeight: '1.15rem' }],
      },
      fontFamily: {
        heading: ['Outfit', 'sans-serif'],
        sans: ['Rubik', 'Outfit', '-apple-system', 'BlinkMacSystemFont', 'sans-serif'],
        mono: ['Fira Code', 'monospace'],
      },
      boxShadow: {
        'pos': '0 1px 3px 0 rgba(15, 23, 42, 0.06), 0 1px 2px -1px rgba(15, 23, 42, 0.06)',
        'pos-md': '0 4px 6px -1px rgba(15, 23, 42, 0.08), 0 2px 4px -2px rgba(15, 23, 42, 0.06)',
        'pos-lg': '0 10px 15px -3px rgba(15, 23, 42, 0.08), 0 4px 6px -4px rgba(15, 23, 42, 0.04)',
        'pos-active': '0 0 0 3px rgb(var(--blue-500-bg) / 0.35)',
      }
    },
  },
  plugins: [themePalettePlugin],
}
