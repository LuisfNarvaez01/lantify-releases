// ============================================
// INFRASTRUCTURE - User Repository Implementation
// ============================================

import { PrismaClient, User } from '@prisma/client';

export interface IUserRepository {
  create(data: { username: string; password: string; name: string; role?: string }): Promise<User>;
  findByUsername(username: string): Promise<User | null>;
  findById(id: string): Promise<User | null>;
  getAll(): Promise<User[]>;
  countAll(): Promise<number>;
  update(id: string, data: Partial<User>): Promise<User>;
  delete(id: string): Promise<void>;
}

export class UserRepository implements IUserRepository {
  constructor(private prisma: PrismaClient) {}

  async create(data: { username: string; password: string; name: string; role?: string }): Promise<User> {
    return this.prisma.user.create({ 
      data: {
        username: data.username,
        password: data.password,
        name: data.name,
        role: data.role as any
      }
    });
  }

  async findByUsername(username: string): Promise<User | null> {
    return this.prisma.user.findUnique({ where: { username } });
  }

  async findById(id: string): Promise<User | null> {
    return this.prisma.user.findUnique({ where: { id } });
  }

  async getAll(): Promise<User[]> {
    return this.prisma.user.findMany({ where: { isActive: true } });
  }

  async countAll(): Promise<number> {
    return this.prisma.user.count();
  }

  async update(id: string, data: Partial<User>): Promise<User> {
    return this.prisma.user.update({ where: { id }, data });
  }

  async delete(id: string): Promise<void> {
    await this.prisma.user.update({ where: { id }, data: { isActive: false } });
  }
}
