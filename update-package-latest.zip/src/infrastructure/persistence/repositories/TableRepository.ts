// ============================================
// INFRASTRUCTURE - Table Repository Implementation
// ============================================

import { PrismaClient, Table, TableStatus } from '@prisma/client';
import { ITableRepository } from '../../../domain/repositories/ITableRepository';

export class TableRepository implements ITableRepository {
  constructor(private prisma: PrismaClient) {}

  async create(data: Omit<Table, 'id' | 'createdAt' | 'updatedAt' | 'status'>): Promise<Table> {
    return this.prisma.table.create({
      data: { ...data, status: 'AVAILABLE' },
    });
  }

  async getById(id: string): Promise<Table | null> {
    return this.prisma.table.findUnique({ where: { id } });
  }

  async getAll(): Promise<Table[]> {
    return this.prisma.table.findMany({
      orderBy: { number: 'asc' },
    });
  }

  async getByStatus(status: TableStatus): Promise<Table[]> {
    return this.prisma.table.findMany({
      where: { status },
      orderBy: { number: 'asc' },
    });
  }

  async getAvailable(): Promise<Table[]> {
    return this.prisma.table.findMany({
      where: { status: 'AVAILABLE' },
      orderBy: { number: 'asc' },
    });
  }

  async update(id: string, data: Partial<Table>): Promise<Table> {
    return this.prisma.table.update({ where: { id }, data });
  }

  async updateStatus(id: string, status: TableStatus): Promise<Table> {
    return this.prisma.table.update({
      where: { id },
      data: { status },
    });
  }

  async delete(id: string): Promise<void> {
    await this.prisma.table.delete({ where: { id } });
  }
}