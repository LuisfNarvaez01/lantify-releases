// ============================================
// INFRASTRUCTURE - CashSession Repository Implementation
// ============================================

import { PrismaClient, CashSession, CashSessionStatus } from '@prisma/client';
import { ICashSessionRepository } from '../../../domain/repositories/ICashSessionRepository';
import { calculateFinalBalance } from '../../../domain/entities';

export class CashSessionRepository implements ICashSessionRepository {
  constructor(private prisma: PrismaClient) {}

  async create(data: Omit<CashSession, 'id' | 'sessionNumber' | 'openedAt' | 'closedAt' | 'finalBalance' | 'expectedBalance' | 'difference' | 'status' | 'createdAt' | 'updatedAt'>): Promise<CashSession> {
    const now = new Date();
    const sessionNumber = `CS-${now.getFullYear()}${(now.getMonth() + 1).toString().padStart(2, '0')}${now.getDate().toString().padStart(2, '0')}-${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`;
    
    return this.prisma.cashSession.create({
      data: { ...data, sessionNumber, status: 'OPEN' },
    });
  }

  async getById(id: string): Promise<CashSession | null> {
    return this.prisma.cashSession.findUnique({ 
      where: { id },
      include: { 
        expensesDetails: { include: { category: true } },
        incomesDetails: true
      }
    }) as any;
  }

  async getAll(): Promise<CashSession[]> {
    return this.prisma.cashSession.findMany({
      orderBy: { openedAt: 'desc' },
      include: { 
        expensesDetails: { include: { category: true } },
        incomesDetails: true
      }
    }) as any;
  }

  async getOpenSession(): Promise<CashSession | null> {
    return this.prisma.cashSession.findFirst({
      where: { status: 'OPEN' },
      orderBy: { openedAt: 'desc' },
      include: { 
        expensesDetails: { include: { category: true } },
        incomesDetails: true
      }
    }) as any;
  }

  async getByDateRange(startDate: Date, endDate: Date): Promise<CashSession[]> {
    return this.prisma.cashSession.findMany({
      where: {
        openedAt: { gte: startDate, lte: endDate },
      },
      orderBy: { openedAt: 'desc' },
      include: { 
        expensesDetails: { include: { category: true } },
        incomesDetails: true
      }
    }) as any;
  }

  async update(id: string, data: Partial<CashSession>): Promise<CashSession> {
    return this.prisma.cashSession.update({ where: { id }, data });
  }

  async closeSession(id: string, countedBalance: number, notes?: string): Promise<CashSession> {
    const session = await this.getById(id);
    if (!session) throw new Error('Sesión no encontrada');

    const expectedBalance = calculateFinalBalance(session);
    const difference = countedBalance - expectedBalance;

    return this.prisma.cashSession.update({
      where: { id },
      data: {
        closedAt: new Date(),
        finalBalance: countedBalance,
        expectedBalance,
        difference,
        status: 'CLOSED',
        notes: notes ?? session.notes,
      },
    });
  }

  async addIncome(id: string, amount: number, motive: string, description?: string): Promise<CashSession> {
    // Create the income record
    await this.prisma.income.create({
      data: {
        cashSessionId: id,
        amount,
        motive,
        description
      }
    });

    // Update the session total
    return this.prisma.cashSession.update({
      where: { id },
      data: { income: { increment: amount } },
      include: { 
        expensesDetails: { include: { category: true } },
        incomesDetails: true
      }
    }) as any;
  }

  async addExpense(id: string, amount: number, motive: string, description?: string, categoryId?: string): Promise<CashSession> {
    // Create the expense record
    await this.prisma.expense.create({
      data: {
        cashSessionId: id,
        amount,
        motive,
        description,
        categoryId: categoryId || null,
      }
    });

    // Update the session total
    return this.prisma.cashSession.update({
      where: { id },
      data: { expenses: { increment: amount } },
      include: { 
        expensesDetails: { include: { category: true } },
        incomesDetails: true
      }
    }) as any;
  }

  async cancelIncome(sessionId: string, incomeId: string, reason: string): Promise<CashSession> {
    // 1. Update the income record
    await this.prisma.income.update({
      where: { id: incomeId },
      data: {
        isCancelled: true,
        cancellationReason: reason,
        cancelledAt: new Date()
      }
    });

    // 2. Get the income amount to decrement
    const income = await this.prisma.income.findUnique({ where: { id: incomeId } });
    if (!income) throw new Error('Ingreso no encontrado');

    // 3. Update the session total
    return this.prisma.cashSession.update({
      where: { id: sessionId },
      data: { income: { decrement: income.amount } },
      include: { 
        expensesDetails: { include: { category: true } },
        incomesDetails: true
      }
    }) as any;
  }

  async cancelExpense(sessionId: string, expenseId: string, reason: string): Promise<CashSession> {
    const before = await this.prisma.expense.findUnique({ where: { id: expenseId } });
    if (!before || before.cashSessionId !== sessionId) throw new Error('Egreso no encontrado');
    if (before.isCancelled) throw new Error('Este egreso ya estaba anulado');
    // 1. Update the expense record
    await this.prisma.expense.update({
      where: { id: expenseId },
      data: {
        isCancelled: true,
        cancellationReason: reason,
        cancelledAt: new Date()
      }
    });

    // 2. Get the expense amount to decrement
    const expense = await this.prisma.expense.findUnique({ where: { id: expenseId } });
    if (!expense) throw new Error('Egreso no encontrado');

    // 3. Update the session total
    return this.prisma.cashSession.update({
      where: { id: sessionId },
      // Lo pagado por fuera del cajón nunca sumó al saldo esperado
      data: expense.paymentSource === 'CASH_DRAWER' ? { expenses: { decrement: expense.amount } } : {},
      include: { 
        expensesDetails: { include: { category: true } },
        incomesDetails: true
      }
    }) as any;
  }

  async delete(id: string): Promise<void> {
    await this.prisma.cashSession.delete({ where: { id } });
  }
}