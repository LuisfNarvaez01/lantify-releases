// ============================================
// INFRASTRUCTURE - Database Prisma Client
// ============================================

import { PrismaClient } from '@prisma/client';
import { encryptDianFields, decryptDianFields } from '../../shared/security/secretCipher';

const decryptResult = (result: any) => {
  if (Array.isArray(result)) return result.map(decryptDianFields);
  return decryptDianFields(result);
};

// Los secretos de DianConfig se cifran al escribir y se descifran al leer,
// sin que los servicios de facturación tengan que saberlo.
const prismaClientSingleton = () => {
  const base = new PrismaClient({
    log: ['error', 'warn'],
  });

  return base.$extends({
    query: {
      dianConfig: {
        async create({ args, query }) {
          encryptDianFields(args.data);
          return decryptResult(await query(args));
        },
        async update({ args, query }) {
          encryptDianFields(args.data);
          return decryptResult(await query(args));
        },
        async upsert({ args, query }) {
          encryptDianFields(args.create);
          encryptDianFields(args.update);
          return decryptResult(await query(args));
        },
        async findFirst({ args, query }) {
          return decryptResult(await query(args));
        },
        async findUnique({ args, query }) {
          return decryptResult(await query(args));
        },
        async findMany({ args, query }) {
          return decryptResult(await query(args));
        },
      },
    },
  }) as unknown as PrismaClient;
};

declare global {
  var prisma: undefined | PrismaClient;
}

export const prisma = globalThis.prisma ?? prismaClientSingleton();

if (process.env.NODE_ENV !== 'production') globalThis.prisma = prisma;

export default prisma;
