// ============================================
// INFRASTRUCTURE - Database Prisma Client
// ============================================

import { PrismaClient } from '@prisma/client';
import { encryptDianFields, decryptDianFields } from '../../shared/security/secretCipher';

const decryptResult = (result: any) => {
  if (Array.isArray(result)) return result.map(decryptDianFields);
  return decryptDianFields(result);
};

// Los secretos de DianConfig se cifran al escribir y se descifran al leer,
// sin que los servicios de facturación tengan que saberlo.
const prismaClientSingleton = () => {
  const base = new PrismaClient({
    log: ['error', 'warn'],
    datasourceUrl: singleConnection(process.env.DATABASE_URL),
  });

  return serializeTransactions(base.$extends({
    query: {
      dianConfig: {
        async create({ args, query }) {
          encryptDianFields(args.data);
          return decryptResult(await query(args));
        },
        async update({ args, query }) {
          encryptDianFields(args.data);
          return decryptResult(await query(args));
        },
        async upsert({ args, query }) {
          encryptDianFields(args.create);
          encryptDianFields(args.update);
          return decryptResult(await query(args));
        },
        async findFirst({ args, query }) {
          return decryptResult(await query(args));
        },
        async findUnique({ args, query }) {
          return decryptResult(await query(args));
        },
        async findMany({ args, query }) {
          return decryptResult(await query(args));
        },
      },
    },
  }) as unknown as PrismaClient);
};

// Con varias conexiones, una escritura suelta (p. ej. la auditoría) y una transacción abierta se
// bloquean entre sí en SQLite hasta vencer el tiempo de espera. Con una sola conexión, Prisma pone
// todas las consultas en fila y SQLite nunca ve dos escritores (DEF-18).
function singleConnection(url: string | undefined): string | undefined {
  if (!url || !url.startsWith('file:') || /[?&]connection_limit=/.test(url)) return url;
  return `${url}${url.includes('?') ? '&' : '?'}connection_limit=1`;
}

// SQLite admite un solo escritor. Dos transacciones que leen y luego escriben a la vez se bloquean
// entre sí hasta vencer (5 s): con 15 cobros simultáneos fallaba la mayoría (DEF-18). El servidor
// local es un solo proceso, así que las transacciones se ponen en fila y corren una tras otra.
// Una transacción no debe abrir otra dentro de sí: esperaría a la primera y no terminaría nunca.
function serializeTransactions(client: PrismaClient): PrismaClient {
  let tail: Promise<unknown> = Promise.resolve();
  const transaction = (...args: any[]) => {
    const run = tail.then(() => (client.$transaction as any)(...args));
    tail = run.catch(() => undefined);
    return run;
  };
  return new Proxy(client, {
    get: (target, prop) => {
      if (prop === '$transaction') return transaction;
      const value = Reflect.get(target, prop);
      return typeof value === 'function' ? value.bind(target) : value;
    },
  });
}

declare global {
  var prisma: undefined | PrismaClient;
}

export const prisma = globalThis.prisma ?? prismaClientSingleton();

if (process.env.NODE_ENV !== 'production') globalThis.prisma = prisma;

export default prisma;
