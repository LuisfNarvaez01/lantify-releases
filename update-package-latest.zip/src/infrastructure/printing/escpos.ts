// ============================================
// INFRASTRUCTURE - Ticket → comandos ESC/POS
// ============================================
// El lenguaje de casi todas las impresoras térmicas de recibos (Epson y
// compatibles: Xprinter, 3nStar, Bixolon, Digital POS…). Texto en la página de
// códigos que entiende la impresora, imágenes como mapa de bits (GS v 0) y corte.

import { TicketBlock, TicketDoc, twoColumns, wrapText } from '../../domain/ticketDoc';
import { PrintSettings, columnsFor } from '../../domain/printSettings';

const ESC = 0x1b;
const GS = 0x1d;

// Caracteres del español (y comunes) en la página 850; el resto se aproxima
const CP850: Record<string, number> = {
  'Ç': 0x80, 'ü': 0x81, 'é': 0x82, 'â': 0x83, 'ä': 0x84, 'à': 0x85, 'ç': 0x87, 'ê': 0x88, 'ë': 0x89, 'è': 0x8a,
  'ï': 0x8b, 'î': 0x8c, 'ì': 0x8d, 'Ä': 0x8e, 'É': 0x90, 'ô': 0x93, 'ö': 0x94, 'ò': 0x95, 'û': 0x96, 'ù': 0x97,
  'Ö': 0x99, 'Ü': 0x9a, '£': 0x9c, '×': 0x9e, 'á': 0xa0, 'í': 0xa1, 'ó': 0xa2, 'ú': 0xa3, 'ñ': 0xa4, 'Ñ': 0xa5,
  'ª': 0xa6, 'º': 0xa7, '¿': 0xa8, '®': 0xa9, '½': 0xab, '¡': 0xad, '«': 0xae, '»': 0xaf, 'Á': 0xb5, 'Â': 0xb6,
  'À': 0xb7, '©': 0xb8, 'ã': 0xc6, 'Ã': 0xc7, 'Ê': 0xd2, 'Ë': 0xd3, 'È': 0xd4, '€': 0xd5, 'Í': 0xd6, 'Î': 0xd7,
  'Ï': 0xd8, 'Ó': 0xe0, 'Ô': 0xe2, 'Ò': 0xe3, 'õ': 0xe4, 'Õ': 0xe5, 'Ú': 0xe9, 'Û': 0xea, 'Ù': 0xeb, '°': 0xf8,
  '·': 0xfa,
};

// Signos tipográficos que ninguna impresora térmica trae
const SIMPLE: Record<string, string> = {
  '–': '-', '—': '-', '‒': '-', '“': '"', '”': '"', '„': '"', '‘': "'", '’': "'", '…': '...', '•': '-',
  '→': '>', '←': '<', '✓': 'v', ' ': ' ', ' ': ' ',
};

const stripAccents = (s: string) => s.normalize('NFD').replace(/[̀-ͯ]/g, '');

export const encodeText = (text: string, codepage: PrintSettings['codepage']): number[] => {
  const out: number[] = [];
  for (const raw of text) {
    const ch = SIMPLE[raw] ?? raw;
    for (const c of ch) {
      const code = c.codePointAt(0)!;
      if (code >= 0x20 && code < 0x7f) out.push(code);
      else if (codepage === 'cp850' && CP850[c] !== undefined) out.push(CP850[c]);
      else if (codepage === 'cp1252' && code >= 0xa0 && code <= 0xff) out.push(code);
      else if (codepage === 'cp1252' && c === '€') out.push(0x80);
      else {
        const plain = stripAccents(c);
        if (plain.length && plain.codePointAt(0)! < 0x7f && plain.codePointAt(0)! >= 0x20) out.push(plain.codePointAt(0)!);
        // emojis y símbolos sin equivalente: se omiten
      }
    }
  }
  return out;
};

const CODEPAGE_N: Record<PrintSettings['codepage'], number> = { cp850: 2, cp1252: 16, ascii: 0 };
const ALIGN_N = { left: 0, center: 1, right: 2 } as const;

export const toEscPos = (doc: TicketDoc, settings: Pick<PrintSettings, 'paperWidth' | 'codepage' | 'cut'>, copies = 1): Buffer => {
  const cols = columnsFor(settings.paperWidth);
  // Fuente B (pequeña): 9 puntos por carácter en vez de 12
  const smallCols = Math.floor((cols * 12) / 9);
  const bytes: number[] = [];
  const push = (...b: number[]) => bytes.push(...b);
  const line = (text: string) => {
    push(...encodeText(text, settings.codepage), 0x0a);
  };
  const style = (o: { bold?: boolean; size?: 1 | 2; small?: boolean; invert?: boolean; align?: keyof typeof ALIGN_N }) => {
    push(ESC, 0x61, ALIGN_N[o.align || 'left']);
    push(ESC, 0x45, o.bold ? 1 : 0);
    push(GS, 0x21, o.size === 2 ? 0x11 : 0x00);
    push(ESC, 0x4d, o.small ? 1 : 0);
    push(GS, 0x42, o.invert ? 1 : 0);
  };
  const reset = () => style({});

  const block = (b: TicketBlock) => {
    switch (b.t) {
      case 'text': {
        const width = b.small ? smallCols : b.size === 2 ? Math.floor(cols / 2) : cols;
        style(b);
        for (const l of wrapText(b.text, width)) line(b.invert ? ` ${l} ` : l);
        reset();
        break;
      }
      case 'row': {
        const width = b.small ? smallCols : b.size === 2 ? Math.floor(cols / 2) : cols;
        style({ bold: b.bold, size: b.size, small: b.small });
        for (const l of twoColumns(b.left, b.right, width)) line(l);
        reset();
        break;
      }
      case 'rule':
        line((b.style === 'double' ? '=' : b.style === 'solid' ? '_' : '-').repeat(cols));
        break;
      case 'feed':
        push(ESC, 0x64, Math.max(1, Math.min(8, b.lines || 1)));
        break;
      case 'image': {
        if (!b.width || !b.height || b.width % 8) break;
        const data = Buffer.from(b.bits, 'base64');
        const rowBytes = b.width / 8;
        if (data.length < rowBytes * b.height) break;
        push(ESC, 0x61, ALIGN_N[b.align || 'center']);
        // En franjas: algunas impresoras tienen poca memoria para una imagen grande
        for (let y = 0; y < b.height; y += 128) {
          const h = Math.min(128, b.height - y);
          push(GS, 0x76, 0x30, 0x00, rowBytes & 0xff, rowBytes >> 8, h & 0xff, h >> 8);
          for (const v of data.subarray(y * rowBytes, (y + h) * rowBytes)) push(v);
        }
        reset();
        break;
      }
      case 'box':
        line('-'.repeat(cols));
        b.blocks.forEach(block);
        line('-'.repeat(cols));
        break;
    }
  };

  for (let copy = 0; copy < Math.max(1, copies); copy++) {
    push(ESC, 0x40); // reiniciar
    push(ESC, 0x74, CODEPAGE_N[settings.codepage]);
    doc.blocks.forEach(block);
    if (settings.cut) {
      push(ESC, 0x64, 4);
      push(GS, 0x56, 0x42, 0x00); // avanzar y cortar parcial
    } else {
      push(ESC, 0x64, 5);
    }
  }
  if (doc.drawer) push(ESC, 0x70, 0x00, 0x19, 0xfa); // pulso al cajón (pin 2)
  return Buffer.from(bytes);
};
