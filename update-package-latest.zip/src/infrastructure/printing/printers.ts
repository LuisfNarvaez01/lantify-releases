// ============================================
// INFRASTRUCTURE - Impresoras del equipo y envío directo
// ============================================
// Windows: lista las impresoras instaladas y envía el ticket en modo RAW por la
// cola de impresión (winspool), sin ventanas. Red: envía al puerto 9100 de la
// impresora (el estándar de las térmicas con Ethernet o Wi-Fi). Los trabajos van
// uno detrás de otro para que dos cobros seguidos no se mezclen en el papel.

import { execFile } from 'child_process';
import fs from 'fs';
import net from 'net';
import os from 'os';
import path from 'path';
import crypto from 'crypto';
import { PrinterTarget } from '../../domain/printSettings';
import { getDataDir } from '../../shared/security/secrets';

export interface InstalledPrinter {
  name: string;
  isDefault: boolean;
  port: string | null;
  driver: string | null;
  offline: boolean;
  /** PDF, XPS, fax, OneNote: no son impresoras de recibos */
  virtual: boolean;
}

export class PrintError extends Error {
  constructor(public code: string, message: string) {
    super(message);
    this.name = 'PrintError';
  }
}

const VIRTUAL_RE = /pdf|xps|onenote|fax|send to|enviar a|document writer/i;

const powershell = (args: string[], timeoutMs: number) =>
  new Promise<{ stdout: string; stderr: string }>((resolve, reject) => {
    execFile(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', ...args],
      { timeout: timeoutMs, windowsHide: true, maxBuffer: 2 * 1024 * 1024 },
      (error, stdout, stderr) => (error ? reject(Object.assign(error, { stdout, stderr })) : resolve({ stdout, stderr })),
    );
  });

export const listPrinters = async (): Promise<InstalledPrinter[]> => {
  if (process.platform !== 'win32') return [];
  const script =
    '[Console]::OutputEncoding=[Text.Encoding]::UTF8;' +
    'Get-CimInstance Win32_Printer | Select-Object Name,Default,PortName,DriverName,WorkOffline | ConvertTo-Json -Compress';
  try {
    const { stdout } = await powershell(['-Command', script], 15000);
    const parsed = stdout.trim() ? JSON.parse(stdout) : [];
    const rows: any[] = Array.isArray(parsed) ? parsed : [parsed];
    return rows
      .filter((p) => p?.Name)
      .map((p) => ({
        name: String(p.Name),
        isDefault: !!p.Default,
        port: p.PortName ? String(p.PortName) : null,
        driver: p.DriverName ? String(p.DriverName) : null,
        offline: !!p.WorkOffline,
        virtual: VIRTUAL_RE.test(`${p.Name} ${p.DriverName || ''} ${p.PortName || ''}`),
      }))
      .sort((a, b) => Number(a.virtual) - Number(b.virtual) || Number(b.isDefault) - Number(a.isDefault) || a.name.localeCompare(b.name));
  } catch (err: any) {
    console.warn('[impresión] no se pudieron listar las impresoras:', err?.message || err);
    throw new PrintError('PRINTERS_UNAVAILABLE', 'No se pudo consultar las impresoras de Windows.');
  }
};

// Envío RAW por la cola de Windows. Se compila una vez y queda en la carpeta de datos.
const RAW_PRINT_CS = `
using System;
using System.Runtime.InteropServices;
public static class LantifyRawPrint1 {
  [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
  public class DOCINFO {
    [MarshalAs(UnmanagedType.LPWStr)] public string pDocName;
    [MarshalAs(UnmanagedType.LPWStr)] public string pOutputFile;
    [MarshalAs(UnmanagedType.LPWStr)] public string pDataType;
  }
  [DllImport("winspool.drv", EntryPoint = "OpenPrinterW", SetLastError = true, CharSet = CharSet.Unicode)]
  static extern bool OpenPrinter(string name, out IntPtr h, IntPtr defaults);
  [DllImport("winspool.drv", SetLastError = true)] static extern bool ClosePrinter(IntPtr h);
  [DllImport("winspool.drv", EntryPoint = "StartDocPrinterW", SetLastError = true, CharSet = CharSet.Unicode)]
  static extern int StartDocPrinter(IntPtr h, int level, [In, MarshalAs(UnmanagedType.LPStruct)] DOCINFO di);
  [DllImport("winspool.drv", SetLastError = true)] static extern bool EndDocPrinter(IntPtr h);
  [DllImport("winspool.drv", SetLastError = true)] static extern bool StartPagePrinter(IntPtr h);
  [DllImport("winspool.drv", SetLastError = true)] static extern bool EndPagePrinter(IntPtr h);
  [DllImport("winspool.drv", SetLastError = true)] static extern bool WritePrinter(IntPtr h, byte[] buf, int count, out int written);
  public static string Send(string printer, byte[] data, string docName) {
    IntPtr h;
    if (!OpenPrinter(printer, out h, IntPtr.Zero)) return "OPEN:" + Marshal.GetLastWin32Error();
    try {
      DOCINFO di = new DOCINFO();
      di.pDocName = docName;
      di.pDataType = "RAW";
      if (StartDocPrinter(h, 1, di) == 0) return "DOC:" + Marshal.GetLastWin32Error();
      try {
        StartPagePrinter(h);
        int written;
        bool ok = WritePrinter(h, data, data.Length, out written);
        EndPagePrinter(h);
        if (!ok || written != data.Length) return "WRITE:" + Marshal.GetLastWin32Error();
      } finally { EndDocPrinter(h); }
    } finally { ClosePrinter(h); }
    return "OK";
  }
}`;

const RAW_PRINT_PS1 = `
param([string]$PrinterName, [string]$FilePath, [string]$DllPath, [string]$DocName)
$ErrorActionPreference = 'Stop'
$src = @'
${RAW_PRINT_CS}
'@
if (-not ('LantifyRawPrint1' -as [type])) {
  try {
    if (-not (Test-Path $DllPath)) { Add-Type -TypeDefinition $src -OutputAssembly $DllPath -OutputType Library }
    Add-Type -Path $DllPath
  } catch {
    Add-Type -TypeDefinition $src
  }
}
$bytes = [System.IO.File]::ReadAllBytes($FilePath)
Write-Output ([LantifyRawPrint1]::Send($PrinterName, $bytes, $DocName))
`;

const printingDir = () => {
  const dir = path.join(getDataDir(), 'printing');
  fs.mkdirSync(dir, { recursive: true });
  return dir;
};

const scriptFile = () => {
  const file = path.join(printingDir(), 'raw-print-1.ps1');
  if (!fs.existsSync(file) || fs.readFileSync(file, 'utf8') !== RAW_PRINT_PS1) fs.writeFileSync(file, RAW_PRINT_PS1, 'utf8');
  return file;
};

const sendWindows = async (name: string, data: Buffer, docName: string) => {
  if (process.platform !== 'win32') throw new PrintError('PRINT_UNSUPPORTED', 'La impresión directa por Windows solo funciona en Windows.');
  const tmp = path.join(os.tmpdir(), `lantify-ticket-${crypto.randomUUID()}.bin`);
  fs.writeFileSync(tmp, data);
  try {
    const { stdout } = await powershell(
      ['-File', scriptFile(), '-PrinterName', name, '-FilePath', tmp, '-DllPath', path.join(printingDir(), 'LantifyRawPrint1.dll'), '-DocName', docName.slice(0, 60)],
      30000,
    );
    const result = stdout.trim().split(/\r?\n/).pop() || '';
    if (result === 'OK') return;
    if (result.startsWith('OPEN:')) throw new PrintError('PRINTER_NOT_FOUND', `Windows no encontró la impresora "${name}".`);
    throw new PrintError('PRINT_FAILED', `La impresora no aceptó el ticket (${result || 'sin respuesta'}).`);
  } catch (err: any) {
    if (err instanceof PrintError) throw err;
    console.warn('[impresión] Windows:', err?.stderr || err?.message || err);
    throw new PrintError('PRINT_FAILED', 'No se pudo enviar el ticket a la impresora.');
  } finally {
    fs.rmSync(tmp, { force: true });
  }
};

const sendNetwork = (host: string, port: number, data: Buffer) =>
  new Promise<void>((resolve, reject) => {
    const socket = net.connect({ host, port });
    let done = false;
    const finish = (err?: PrintError) => {
      if (done) return;
      done = true;
      socket.destroy();
      if (err) reject(err);
      else resolve();
    };
    socket.setTimeout(6000, () => finish(new PrintError('PRINTER_UNREACHABLE', `La impresora ${host}:${port} no responde.`)));
    socket.on('error', () => finish(new PrintError('PRINTER_UNREACHABLE', `No se pudo conectar con la impresora ${host}:${port}.`)));
    socket.on('connect', () => {
      socket.end(data, () => setTimeout(() => finish(), 150));
    });
  });

let queue: Promise<unknown> = Promise.resolve();

/** Envía bytes ESC/POS a una impresora. Los trabajos se atienden en orden. */
export const sendToPrinter = (target: PrinterTarget, data: Buffer, docName = 'Lantify POS'): Promise<void> => {
  const job = queue.then(() =>
    target.type === 'network' ? sendNetwork(target.host, target.port, data) : sendWindows(target.name, data, docName),
  );
  queue = job.catch(() => undefined);
  return job;
};
