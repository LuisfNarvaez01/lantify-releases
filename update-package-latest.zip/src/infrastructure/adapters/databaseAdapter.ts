// ============================================
// INFRASTRUCTURE - Database Adapter (SQLite for Offline-First)
// ============================================

import { PrismaClient } from '@prisma/client';

const sqlitePrismaClientSingleton = () => {
  return new PrismaClient({
    datasources: {
      db: {
        url: process.env.DATABASE_URL || 'file:./dev.db',
      },
    },
    log: process.env.NODE_ENV === 'development' ? ['error', 'warn'] : ['error'],
  });
};

declare global {
  var prismaSqlite: undefined | ReturnType<typeof sqlitePrismaClientSingleton>;
}

export const prismaSqlite = globalThis.prismaSqlite ?? sqlitePrismaClientSingleton();

if (process.env.NODE_ENV !== 'production') globalThis.prismaSqlite = prismaSqlite;

export default prismaSqlite;