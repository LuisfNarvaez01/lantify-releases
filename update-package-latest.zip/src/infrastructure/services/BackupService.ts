// ============================================
// INFRASTRUCTURE - Backup Service
// ============================================

import * as fs from 'fs';
import * as path from 'path';

import { backupsDir, databaseFile } from '../../shared/runtime';

// La base y la carpeta de respaldos salen de la configuración (en el programa instalado, %ProgramData%\Lantify)
const DB_PATH = databaseFile();
const BACKUP_DIR = backupsDir();
const MAX_BACKUPS = 15;

export interface BackupInfo {
  name: string;
  sizeBytes: number;
  sizeKB: string;
  createdAt: string;
  path: string;
}

export class BackupService {
  /**
   * Genera un respaldo seguro verificado de la base de datos SQLite.
   */
  static runBackup(prefix = 'dev.db'): BackupInfo | null {
    if (!fs.existsSync(DB_PATH)) {
      console.warn(`⚠️ [BackupService] No se encontró la base de datos en ${DB_PATH}`);
      return null;
    }

    const stat = fs.statSync(DB_PATH);
    if (!fs.existsSync(BACKUP_DIR)) {
      fs.mkdirSync(BACKUP_DIR, { recursive: true });
    }

    const now = new Date();
    const timestamp = now.toISOString().replace(/[:.]/g, '-');
    const backupFileName = `${prefix}.${timestamp}`;
    const targetPath = path.join(BACKUP_DIR, backupFileName);

    try {
      fs.copyFileSync(DB_PATH, targetPath);

      // Verificación de integridad por tamaño exacto
      const targetStat = fs.statSync(targetPath);
      if (targetStat.size !== stat.size) {
        fs.unlinkSync(targetPath);
        throw new Error(`Inconsistencia en el respaldo: origen (${stat.size}B) vs destino (${targetStat.size}B).`);
      }

      console.log(`✅ [BackupService] Respaldo verificado con éxito: ${backupFileName} (${(stat.size / 1024).toFixed(1)} KB)`);

      // Rotación de backups
      this.rotateBackups();

      return {
        name: backupFileName,
        sizeBytes: targetStat.size,
        sizeKB: `${(targetStat.size / 1024).toFixed(1)} KB`,
        createdAt: targetStat.mtime.toISOString(),
        path: targetPath,
      };
    } catch (err) {
      console.error('❌ [BackupService] Error crítico generando respaldo:', err);
      throw err;
    }
  }

  /**
   * Lista todos los respaldos existentes ordenados por fecha descendente.
   */
  static listBackups(): BackupInfo[] {
    if (!fs.existsSync(BACKUP_DIR)) {
      return [];
    }

    return fs.readdirSync(BACKUP_DIR)
      .filter(f => f.startsWith('dev.db.'))
      .map(f => {
        const fullPath = path.join(BACKUP_DIR, f);
        const stat = fs.statSync(fullPath);
        return {
          name: f,
          sizeBytes: stat.size,
          sizeKB: `${(stat.size / 1024).toFixed(1)} KB`,
          createdAt: stat.mtime.toISOString(),
          path: fullPath,
        };
      })
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  /**
   * Elimina copias antiguas si superan el límite configurado.
   */
  private static rotateBackups() {
    const backups = this.listBackups();
    if (backups.length > MAX_BACKUPS) {
      const toDelete = backups.slice(MAX_BACKUPS);
      for (const b of toDelete) {
        try {
          fs.unlinkSync(b.path);
          console.log(`🧹 [BackupService] Depurado backup antiguo: ${b.name}`);
        } catch (e) {
          console.warn(`No se pudo eliminar backup antiguo ${b.name}:`, e);
        }
      }
    }
  }
}
