// ============================================
// INFRASTRUCTURE - Anuncio de la caja en la red local (mDNS, Fase 4 · D · 1)
// ============================================
// Con el acceso de tablets activado (LAN_ACCESS=true) y la función "La app encuentra la
// caja sola" encendida, la caja se anuncia como _lantify._tcp con bonjour-service.
// Se revisa cada minuto (por si encienden o apagan la función) y se retira al apagar
// el servidor. Si el anuncio falla (puerto 5353 ocupado, red sin multicast…), se anota
// en el registro y el servidor sigue igual: nunca afecta una venta.

import os from 'os';
import { Bonjour } from 'bonjour-service';
import { SERVICE_TYPE, announceTxt, tenantTag } from '../../domain/lanDiscovery';

export interface AnnouncerBackend {
  publish(opts: { name: string; type: string; port: number; txt: Record<string, string> }): { on?(event: 'error', cb: (e: Error) => void): unknown };
  unpublishAll(cb?: () => void): void;
  destroy(cb?: () => void): void;
}

interface Options {
  port: () => number;
  version: () => string;
  tenantCode: () => Promise<string | null>;
  enabled: () => Promise<boolean>;
  lan?: () => boolean;
  backend?: (onError: (e: unknown) => void) => AnnouncerBackend;
  log?: (msg: string) => void;
}

const SYNC_MS = 60_000;

export class LanAnnouncer {
  private backend: AnnouncerBackend | null = null;
  private key = '';
  private timer: ReturnType<typeof setInterval> | null = null;
  private log: (msg: string) => void;

  constructor(private opts: Options) {
    this.log = opts.log || ((m) => console.warn(m));
  }

  /** Lo que se anuncia ahora (null = nada) */
  announced: { name: string; txt: Record<string, string> } | null = null;

  start() {
    void this.sync();
    this.timer = setInterval(() => void this.sync(), SYNC_MS);
    this.timer.unref?.();
  }

  private lanOn() {
    return this.opts.lan ? this.opts.lan() : process.env.LAN_ACCESS === 'true';
  }

  /** Anuncia, cambia o retira el anuncio según la configuración actual. Nunca lanza. */
  async sync() {
    try {
      const on = this.lanOn() && (await this.opts.enabled());
      const tag = on ? await tenantTag(await this.opts.tenantCode().catch(() => null)) : '';
      const port = this.opts.port();
      const version = this.opts.version();
      const key = on ? `${tag}|${port}|${version}` : '';
      if (key === this.key) return;
      this.retire();
      this.key = key;
      if (!on) return;
      const name = `Lantify ${os.hostname()}`.replace(/[^\w .-]/g, '').slice(0, 60);
      const txt = announceTxt({ tag, version, port });
      const backend = (this.opts.backend || ((onError) => new Bonjour({}, onError) as unknown as AnnouncerBackend))((e) => this.log(`[mDNS] ${(e as Error)?.message || e}`));
      this.backend = backend;
      const service = backend.publish({ name, type: SERVICE_TYPE, port, txt });
      service?.on?.('error', (e: Error) => this.log(`[mDNS] No se pudo anunciar la caja: ${e?.message || e}`));
      this.announced = { name, txt };
    } catch (e: any) {
      this.log(`[mDNS] No se pudo anunciar la caja: ${e?.message || e}`);
      this.retire();
      // Se vuelve a intentar en el siguiente ciclo
      this.key = '';
    }
  }

  private retire() {
    const b = this.backend;
    this.backend = null;
    this.announced = null;
    if (!b) return;
    try {
      b.unpublishAll(() => { try { b.destroy(); } catch { /* ya cerrado */ } });
    } catch (e: any) {
      this.log(`[mDNS] Al retirar el anuncio: ${e?.message || e}`);
      try { b.destroy(); } catch { /* ya cerrado */ }
    }
  }

  /** Al apagar el servidor */
  stop() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    this.retire();
    this.key = '';
  }
}
