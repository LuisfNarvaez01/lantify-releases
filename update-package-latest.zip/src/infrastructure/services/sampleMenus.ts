// ============================================
// INFRASTRUCTURE - Menús de ejemplo por tipo de negocio
// ============================================
// Se cargan solo si el dueño lo pide en la configuración inicial y el catálogo
// está vacío. Sirven para probar el sistema el primer día; se pueden editar o borrar.

export type BusinessType = 'RESTAURANT' | 'CAFE' | 'BAR' | 'FAST_FOOD' | 'FOOD_TRUCK' | 'RETAIL';

export const BUSINESS_TYPES: BusinessType[] = ['RESTAURANT', 'CAFE', 'BAR', 'FAST_FOOD', 'FOOD_TRUCK', 'RETAIL'];

type Text = { es: string; en: string };

interface SampleVariant {
  name: Text;
  price: number;
  stock?: number; // si viene, se activa el control de inventario
}

interface SampleProduct {
  name: Text;
  variants: SampleVariant[];
  taxType?: 'IVA' | 'INC' | 'NONE';
  taxRate?: number;
}

interface SampleCategory {
  name: Text;
  products: SampleProduct[];
}

const one = (price: number, stock?: number): SampleVariant[] => [
  { name: { es: 'Única', en: 'Regular' }, price, stock },
];

const RESTAURANT: SampleCategory[] = [
  {
    name: { es: 'Entradas', en: 'Starters' },
    products: [
      { name: { es: 'Patacones con hogao', en: 'Patacones with hogao' }, variants: one(14000) },
      { name: { es: 'Empanadas (3 und.)', en: 'Empanadas (3 pcs)' }, variants: one(9000) },
    ],
  },
  {
    name: { es: 'Platos fuertes', en: 'Main courses' },
    products: [
      { name: { es: 'Bandeja paisa', en: 'Bandeja paisa' }, variants: one(32000) },
      { name: { es: 'Pechuga a la plancha', en: 'Grilled chicken breast' }, variants: one(28000) },
      { name: { es: 'Churrasco', en: 'Churrasco steak' }, variants: one(42000) },
    ],
  },
  {
    name: { es: 'Bebidas', en: 'Drinks' },
    products: [
      {
        name: { es: 'Jugo natural', en: 'Fresh juice' },
        variants: [
          { name: { es: 'En agua', en: 'With water' }, price: 7000 },
          { name: { es: 'En leche', en: 'With milk' }, price: 8500 },
        ],
      },
      { name: { es: 'Gaseosa', en: 'Soda' }, variants: one(5000) },
    ],
  },
];

const CAFE: SampleCategory[] = [
  {
    name: { es: 'Café', en: 'Coffee' },
    products: [
      {
        name: { es: 'Americano', en: 'Americano' },
        variants: [
          { name: { es: '8 oz', en: '8 oz' }, price: 4500 },
          { name: { es: '12 oz', en: '12 oz' }, price: 5500 },
        ],
      },
      {
        name: { es: 'Capuchino', en: 'Cappuccino' },
        variants: [
          { name: { es: '8 oz', en: '8 oz' }, price: 6500 },
          { name: { es: '12 oz', en: '12 oz' }, price: 7500 },
        ],
      },
    ],
  },
  {
    name: { es: 'Panadería', en: 'Bakery' },
    products: [
      { name: { es: 'Pandebono', en: 'Pandebono (cheese bread)' }, variants: one(3000) },
      { name: { es: 'Croissant', en: 'Croissant' }, variants: one(5500) },
      { name: { es: 'Torta de zanahoria', en: 'Carrot cake' }, variants: one(8500) },
    ],
  },
];

const BAR: SampleCategory[] = [
  {
    name: { es: 'Cervezas', en: 'Beers' },
    products: [
      { name: { es: 'Cerveza nacional', en: 'Local beer' }, variants: one(7000) },
      { name: { es: 'Cerveza artesanal', en: 'Craft beer' }, variants: one(14000) },
    ],
  },
  {
    name: { es: 'Cócteles', en: 'Cocktails' },
    products: [
      { name: { es: 'Mojito', en: 'Mojito' }, variants: one(24000) },
      { name: { es: 'Margarita', en: 'Margarita' }, variants: one(26000) },
    ],
  },
  {
    name: { es: 'Para picar', en: 'Bar snacks' },
    products: [
      { name: { es: 'Picada para 2', en: 'Sharing platter for 2' }, variants: one(38000) },
      { name: { es: 'Papas a la francesa', en: 'French fries' }, variants: one(12000) },
    ],
  },
];

const FAST_FOOD: SampleCategory[] = [
  {
    name: { es: 'Hamburguesas', en: 'Burgers' },
    products: [
      {
        name: { es: 'Hamburguesa clásica', en: 'Classic burger' },
        variants: [
          { name: { es: 'Sencilla', en: 'Single' }, price: 18000 },
          { name: { es: 'En combo', en: 'Combo' }, price: 25000 },
        ],
      },
      { name: { es: 'Hamburguesa doble carne', en: 'Double patty burger' }, variants: one(26000) },
    ],
  },
  {
    name: { es: 'Perros y salchipapas', en: 'Hot dogs & fries' },
    products: [
      { name: { es: 'Perro caliente', en: 'Hot dog' }, variants: one(14000) },
      { name: { es: 'Salchipapa', en: 'Sausage & fries' }, variants: one(16000) },
    ],
  },
  {
    name: { es: 'Bebidas', en: 'Drinks' },
    products: [{ name: { es: 'Gaseosa', en: 'Soda' }, variants: one(5000) }],
  },
];

const FOOD_TRUCK: SampleCategory[] = [
  {
    name: { es: 'Menú', en: 'Menu' },
    products: [
      { name: { es: 'Arepa rellena', en: 'Stuffed arepa' }, variants: one(12000) },
      { name: { es: 'Taco (2 und.)', en: 'Tacos (2 pcs)' }, variants: one(15000) },
      { name: { es: 'Mazorcada', en: 'Corn platter' }, variants: one(18000) },
    ],
  },
  {
    name: { es: 'Bebidas', en: 'Drinks' },
    products: [
      { name: { es: 'Limonada', en: 'Lemonade' }, variants: one(6000) },
      { name: { es: 'Agua', en: 'Water' }, variants: one(3000) },
    ],
  },
];

// En tiendas los productos llevan inventario y IVA propio (algunos están excluidos)
const RETAIL: SampleCategory[] = [
  {
    name: { es: 'Abarrotes', en: 'Groceries' },
    products: [
      { name: { es: 'Arroz 1 kg', en: 'Rice 1 kg' }, variants: one(4800, 40), taxType: 'NONE' },
      { name: { es: 'Aceite 1 L', en: 'Cooking oil 1 L' }, variants: one(11500, 24), taxType: 'IVA', taxRate: 19 },
      { name: { es: 'Café molido 500 g', en: 'Ground coffee 500 g' }, variants: one(16900, 18), taxType: 'IVA', taxRate: 5 },
    ],
  },
  {
    name: { es: 'Bebidas', en: 'Drinks' },
    products: [
      { name: { es: 'Gaseosa 400 ml', en: 'Soda 400 ml' }, variants: one(3200, 48), taxType: 'IVA', taxRate: 19 },
      { name: { es: 'Agua 600 ml', en: 'Water 600 ml' }, variants: one(2000, 60), taxType: 'IVA', taxRate: 19 },
    ],
  },
  {
    name: { es: 'Aseo', en: 'Cleaning' },
    products: [
      { name: { es: 'Jabón de loza', en: 'Dish soap' }, variants: one(5900, 20), taxType: 'IVA', taxRate: 19 },
    ],
  },
];

const MENUS: Record<BusinessType, SampleCategory[]> = {
  RESTAURANT,
  CAFE,
  BAR,
  FAST_FOOD,
  FOOD_TRUCK,
  RETAIL,
};

/** Carga el menú de ejemplo dentro de la transacción recibida. Devuelve cuántos productos creó. */
export const loadSampleMenu = async (tx: any, type: BusinessType, lang: 'es' | 'en'): Promise<number> => {
  const menu = MENUS[type] || RESTAURANT;
  const suffix = Date.now().toString(36).slice(-4).toUpperCase();
  let created = 0;
  let skuIndex = 1;

  for (const cat of menu) {
    const categoryName = cat.name[lang];
    const category =
      (await tx.category.findFirst({ where: { name: categoryName, isActive: true } })) ||
      (await tx.category.create({ data: { name: categoryName } }));

    for (const p of cat.products) {
      await tx.product.create({
        data: {
          name: p.name[lang],
          categoryId: category.id,
          taxType: p.taxType ?? null,
          taxRate: p.taxType && p.taxType !== 'NONE' ? p.taxRate ?? null : p.taxType === 'NONE' ? 0 : null,
          variants: {
            create: p.variants.map((v) => ({
              name: v.name[lang],
              sku: `DEMO-${suffix}-${String(skuIndex++).padStart(3, '0')}`,
              price: v.price,
              stock: v.stock ?? 0,
              trackInventory: v.stock !== undefined,
            })),
          },
        },
      });
      created++;
    }
  }
  return created;
};

/** Carta leída con IA (foto): categorías y productos reales del negocio, sin inventario */
export const loadMenuFromPhoto = async (tx: any, menu: { name: string; items: { name: string; price: number }[] }[]): Promise<number> => {
  const suffix = Date.now().toString(36).slice(-4).toUpperCase();
  let created = 0;
  let skuIndex = 1;
  for (const cat of menu) {
    const name = cat.name.trim().slice(0, 60);
    if (!name || !cat.items.length) continue;
    const category =
      (await tx.category.findFirst({ where: { name, isActive: true } })) ||
      (await tx.category.create({ data: { name } }));
    for (const item of cat.items.slice(0, 80)) {
      await tx.product.create({
        data: {
          name: item.name.trim().slice(0, 80),
          categoryId: category.id,
          variants: { create: [{ name: 'Única', sku: `MENU-${suffix}-${String(skuIndex++).padStart(3, '0')}`, price: Math.round(item.price) }] },
        },
      });
      created++;
    }
  }
  return created;
};
