// ============================================
// FACTUS API v2 SERVICE
// Proveedor Tecnológico DIAN en la Nube
// No requiere certificado digital local (.p12/.pfx)
// Documentación: https://developers.factus.com.co/
// ============================================

import { prisma } from '../database/prisma';

export interface FactusAuthResponse {
  token_type: string;
  expires_in: number;
  access_token: string;
  refresh_token: string;
}

export interface FactusCustomerPayload {
  identification_document_code: string; // "13" (CC), "31" (NIT), "41" (Pasaporte), etc.
  identification: string;              // Número sin DV
  dv?: string;
  legal_organization_code: string;     // "1" (Jurídica), "2" (Natural)
  tribute_code?: string;               // "ZZ" (No aplica), "01" (IVA), etc.
  responsibilities?: string[];         // ["R-99-PN"]
  company?: string;                    // Requerido si legal_organization_code = "1"
  trade_name?: string;
  names?: string;                      // Requerido si legal_organization_code = "2"
  address?: string;
  email?: string;
  phone?: string;
  country_code?: string;               // "CO"
  municipality_code?: string;          // "11001" (Bogotá), etc.
}

export interface FactusItemTax {
  code: string;                        // "01" = IVA, "04" = INC
  rate: string;                        // "19.00", "8.00", "0.00"
  is_excluded?: boolean;
}

// Códigos de tributo DIAN: 01 = IVA, 04 = Impuesto Nacional al Consumo (impoconsumo)
const factusTaxesFor = (taxType: string | null | undefined, taxRate: number | null | undefined): FactusItemTax[] => {
  const rate = Number(taxRate) || 0;
  if (taxType === 'INC' && rate > 0) return [{ code: '04', rate: rate.toFixed(2) }];
  if (taxType === 'IVA' && rate > 0) return [{ code: '01', rate: rate.toFixed(2) }];
  return [{ code: '01', rate: '0.00', is_excluded: true }];
};

export interface FactusItemPayload {
  code_reference: string;
  name: string;
  quantity: string;
  discount_rate?: string;
  discount_amount?: string;
  price: string;
  unit_measure_code: string;           // "94" = unidad
  standard_code: string;               // "999" = estándar propio
  note?: string;
  taxes: FactusItemTax[];
}

export interface FactusPaymentDetail {
  payment_form: string;                // "1" = contado, "2" = crédito
  payment_method_code: string;         // "10" = efectivo, "42" = transferencia, "48" = débito, "49" = crédito
  reference_code?: string;
  amount: string;
  due_date?: string;
}

export interface FactusBillPayload {
  reference_code: string;
  document?: string;                   // "01" (Factura Electrónica de Venta)
  numbering_range_id?: number;
  operation_type?: string;             // "10" (Estándar)
  observation?: string;
  send_email?: boolean;
  payment_details: FactusPaymentDetail[];
  cash_rounding_amount?: string;
  customer: FactusCustomerPayload;
  items: FactusItemPayload[];
}

export interface FactusBillResponse {
  status: string;
  message: string;
  data: {
    reference_code: string;
    number: string;
    is_validated: boolean;
    validated_at?: string;
    cufe: string;
    links: {
      qr: string;
      public_url?: string;
    };
    totals: {
      gross_amount: string;
      taxable_amount: string;
      tax_amount: string;
      total: string;
    };
    errors?: Record<string, any>;
  };
}

class FactusService {
  private readonly SANDBOX_URL = 'https://api-sandbox.factus.com.co';
  private readonly PROD_URL = 'https://api.factus.com.co';

  private getBaseUrl(env: string = 'SANDBOX'): string {
    return env === 'PRODUCTION' ? this.PROD_URL : this.SANDBOX_URL;
  }

  // 1. Obtener Token de Acceso con Caché Inteligente
  async getAccessToken(forceRefresh = false): Promise<string> {
    const config = await prisma.dianConfig.findFirst();
    if (!config) {
      throw new Error('Configuración de Facturación DIAN no encontrada en el sistema');
    }

    // Verificar si el token actual sigue vigente (con 60s de margen)
    if (
      !forceRefresh &&
      config.factusToken &&
      config.factusTokenExpiry &&
      new Date(config.factusTokenExpiry) > new Date(Date.now() + 60000)
    ) {
      return config.factusToken;
    }

    if (!config.factusClientId || !config.factusClientSecret) {
      throw new Error('Credenciales de Factus API no configuradas. Ingrese client_id y client_secret en Configuración.');
    }

    const baseUrl = this.getBaseUrl(config.factusEnvironment);
    const tokenUrl = `${baseUrl}/oauth/token`;

    const bodyParams = new URLSearchParams({
      grant_type: 'password',
      client_id: config.factusClientId,
      client_secret: config.factusClientSecret,
      username: config.factusUsername || '',
      password: config.factusPassword || ''
    });

    const response = await fetch(tokenUrl, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: bodyParams.toString()
    });

    if (!response.ok) {
      const errText = await response.text();
      let parsedErr: any = {};
      try { parsedErr = JSON.parse(errText); } catch {}
      throw new Error(parsedErr.message || parsedErr.error || `Error de autenticación con Factus API (${response.status}): ${errText}`);
    }

    const authData = (await response.json()) as FactusAuthResponse;
    const expiryDate = new Date(Date.now() + (authData.expires_in || 600) * 1000);

    // Guardar token en base de datos para no pedir uno en cada factura
    await prisma.dianConfig.update({
      where: { id: config.id },
      data: {
        factusToken: authData.access_token,
        factusTokenExpiry: expiryDate
      }
    });

    return authData.access_token;
  }

  // 2. Probar Conexión con Credenciales en Vivo
  async testConnection(credentials: {
    clientId: string;
    clientSecret: string;
    username?: string;
    password?: string;
    environment?: string;
  }): Promise<{ success: boolean; message: string; numberingRanges?: any[] }> {
    const baseUrl = this.getBaseUrl(credentials.environment || 'SANDBOX');
    const tokenUrl = `${baseUrl}/oauth/token`;

    const bodyParams = new URLSearchParams({
      grant_type: 'password',
      client_id: credentials.clientId,
      client_secret: credentials.clientSecret,
      username: credentials.username || '',
      password: credentials.password || ''
    });

    const response = await fetch(tokenUrl, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: bodyParams.toString()
    });

    if (!response.ok) {
      const errText = await response.text();
      let parsedErr: any = {};
      try { parsedErr = JSON.parse(errText); } catch {}
      return {
        success: false,
        message: parsedErr.message || parsedErr.error || `Error de conexión con Factus (${response.status}): ${errText}`
      };
    }

    const authData = (await response.json()) as FactusAuthResponse;

    // Intentar consultar rangos de numeración para verificar permisos
    let numberingRanges: any[] = [];
    try {
      const rangesRes = await fetch(`${baseUrl}/v2/numbering-ranges`, {
        headers: {
          'Authorization': `Bearer ${authData.access_token}`,
          'Accept': 'application/json'
        }
      });
      if (rangesRes.ok) {
        const rangesData = (await rangesRes.json()) as any;
        numberingRanges = rangesData.data || rangesData || [];
      }
    } catch {}

    return {
      success: true,
      message: '¡Conexión exitosa con Factus Cloud API! Token de autorización emitido.',
      numberingRanges
    };
  }

  // 3. Obtener Rangos de Numeración Activos desde Factus
  async getNumberingRanges(): Promise<any[]> {
    const config = await prisma.dianConfig.findFirst();
    const token = await this.getAccessToken();
    const baseUrl = this.getBaseUrl(config?.factusEnvironment || 'SANDBOX');

    const res = await fetch(`${baseUrl}/v2/numbering-ranges`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/json'
      }
    });

    if (!res.ok) {
      return [];
    }

    const json = (await res.json()) as any;
    return json.data || json || [];
  }

  // 4. Mapear Venta de Lantify POS al esquema oficial Factus v2
  mapSaleToFactusPayload(
    sale: any,
    customerData?: {
      nit?: string;
      name?: string;
      email?: string;
      phone?: string;
      address?: string;
      documentType?: string;
    }
  ): FactusBillPayload {
    // 4.1 Identificación y Cliente
    const rawId = (customerData?.nit || '222222222222').replace(/[^0-9]/g, '');
    const isJuridica = (customerData?.documentType === 'NIT' || rawId.length === 9 || rawId.length === 10) && rawId !== '222222222222';
    const isFinalConsumer = rawId === '222222222222';

    const customer: FactusCustomerPayload = {
      identification_document_code: isJuridica ? '31' : '13', // 31 = NIT, 13 = Cédula de Ciudadanía
      identification: rawId || '222222222222',
      legal_organization_code: isJuridica ? '1' : '2',         // 1 = Persona Jurídica, 2 = Persona Natural
      tribute_code: 'ZZ',                                     // No aplica
      responsibilities: ['R-99-PN'],
      country_code: 'CO',
      municipality_code: '11001',                             // Bogotá D.C. por defecto
      email: customerData?.email || (isFinalConsumer ? undefined : 'factura@cliente.com'),
      phone: customerData?.phone || undefined,
      address: customerData?.address || undefined
    };

    if (isJuridica) {
      customer.company = customerData?.name || 'EMPRESA CLIENTE S.A.S.';
    } else {
      customer.names = customerData?.name || 'Consumidor Final';
    }

    // 4.2 Métodos de Pago DIAN
    // Factus codes: 10=Efectivo, 42=Consignación bancaria/Transferencia, 48=Tarjeta Débito, 49=Tarjeta Crédito
    let paymentMethodCode = '10';
    const methodUpper = (sale.paymentMethod || 'CASH').toUpperCase();
    if (methodUpper.includes('CARD') || methodUpper.includes('TARJETA') || methodUpper.includes('DEBIT')) {
      paymentMethodCode = '48';
    } else if (methodUpper.includes('CREDIT') || methodUpper.includes('CREDITO')) {
      paymentMethodCode = '49';
    } else if (methodUpper.includes('TRANSFER') || methodUpper.includes('NEQUI') || methodUpper.includes('DAVIPLATA')) {
      paymentMethodCode = '42';
    }

    const paymentDetails: FactusPaymentDetail[] = [
      {
        payment_form: '1', // Contado
        payment_method_code: paymentMethodCode,
        amount: Number(sale.total).toFixed(2),
        reference_code: `PAGO-${sale.saleNumber}`
      }
    ];

    // 4.3 Ítems de la Venta
    const rawItems = sale.items || sale.saleItems || [];
    const items: FactusItemPayload[] = rawItems.map((item: any, idx: number) => {
      const unitPrice = Number(item.unitPrice || item.productVariant?.price || 0);
      const qty = Number(item.quantity || 1);
      const variantName = item.productVariant?.name ? ` (${item.productVariant.name})` : '';
      const productName = (item.productVariant?.product?.name || item.product?.name || `Producto ${idx + 1}`) + variantName;
      const productSku = item.productVariant?.sku || item.product?.sku || `ITEM-${idx + 1}`;

      // Impuesto guardado en la línea al momento de la venta (IVA, INC o excluido)
      const taxes = factusTaxesFor(item.taxType, item.taxRate);

      return {
        code_reference: productSku,
        name: productName,
        quantity: qty.toFixed(2),
        // El descuento porcentual de la venta se refleja en cada línea para que el total coincida
        discount_rate: (Number(sale.discountPct) || 0).toFixed(2),
        price: unitPrice.toFixed(2),
        unit_measure_code: '94', // Unidad
        standard_code: '999',    // Adopción del contribuyente
        taxes
      };
    });

    // Si la venta no tiene ítems detallados (p. ej. venta directa por monto)
    if (items.length === 0) {
      items.push({
        code_reference: 'SERV-001',
        name: 'Consumo Restaurante / Alimentos y Bebidas',
        quantity: '1.00',
        discount_rate: '0.00',
        price: Number(sale.subtotal || sale.total).toFixed(2),
        unit_measure_code: '94',
        standard_code: '999',
        taxes: factusTaxesFor(null, 0)
      });
    }

    return {
      reference_code: `${sale.saleNumber}-${Date.now().toString().slice(-4)}`,
      document: '01',
      operation_type: '10',
      observation: `Lantify POS - Venta #${sale.saleNumber}`,
      payment_details: paymentDetails,
      cash_rounding_amount: '0.00',
      customer,
      items
    };
  }

  // 5. Emitir y Validar Factura con Factus Cloud
  async createAndValidateBill(
    sale: any,
    customerData?: {
      nit?: string;
      name?: string;
      email?: string;
      phone?: string;
      address?: string;
      documentType?: string;
    }
  ): Promise<FactusBillResponse> {
    const config = await prisma.dianConfig.findFirst();
    const token = await this.getAccessToken();
    const baseUrl = this.getBaseUrl(config?.factusEnvironment || 'SANDBOX');
    const validateUrl = `${baseUrl}/v2/bills/validate`;

    const payload = this.mapSaleToFactusPayload(sale, customerData);

    const response = await fetch(validateUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify(payload)
    });

    const resJson = (await response.json()) as any;

    if (!response.ok) {
      const errMsg = resJson.message || resJson.error || JSON.stringify(resJson.errors || resJson);
      throw new Error(`Factus rechazo la factura (${response.status}): ${errMsg}`);
    }

    return resJson as FactusBillResponse;
  }
}

export const factusService = new FactusService();
