// ============================================
// INFRASTRUCTURE - Imágenes guardadas en el equipo del negocio
// ============================================
// Carpeta de datos/media/<huella>.<ext>. El navegador ya las reduce y recorta;
// aquí solo se comprueba que de verdad sean imágenes y que no pesen de más.

import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { getDataDir } from '../../shared/security/secrets';
import { MEDIA_MAX_BYTES, MEDIA_MIME, MEDIA_NAME_RE, MEDIA_URL_RE } from '../../domain/media';

export class MediaError extends Error {
  constructor(public statusCode: number, public code: string, message: string) {
    super(message);
    this.name = 'MediaError';
  }
}

export const mediaDir = () => path.join(getDataDir(), 'media');

/** Tipo real por los primeros bytes (no por lo que diga el navegador) */
const sniff = (b: Buffer): 'webp' | 'jpg' | 'png' | null => {
  if (b.length > 12 && b.toString('ascii', 0, 4) === 'RIFF' && b.toString('ascii', 8, 12) === 'WEBP') return 'webp';
  if (b.length > 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return 'jpg';
  if (b.length > 8 && b.readUInt32BE(0) === 0x89504e47 && b.readUInt32BE(4) === 0x0d0a1a0a) return 'png';
  return null;
};

export const mediaStore = {
  /** Guarda una imagen (data URL base64) y devuelve su dirección local */
  save(dataUrl: unknown): { url: string; name: string; bytes: number } {
    if (typeof dataUrl !== 'string') throw new MediaError(400, 'MEDIA_INVALID', 'Falta la imagen.');
    const m = /^data:image\/(webp|jpeg|png);base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl);
    if (!m) throw new MediaError(400, 'MEDIA_INVALID', 'La imagen debe ser WebP, JPG o PNG.');
    const bytes = Buffer.from(m[2], 'base64');
    if (bytes.length > MEDIA_MAX_BYTES) throw new MediaError(413, 'MEDIA_TOO_LARGE', 'La imagen pesa demasiado.');
    const ext = sniff(bytes);
    if (!ext) throw new MediaError(400, 'MEDIA_INVALID', 'El archivo no es una imagen válida.');
    const name = `${crypto.createHash('sha256').update(bytes).digest('hex').slice(0, 32)}.${ext}`;
    const dir = mediaDir();
    fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, name);
    if (!fs.existsSync(file)) fs.writeFileSync(file, bytes);
    return { url: `/api/media/${name}`, name, bytes: bytes.length };
  },

  /** Archivo de una imagen por su nombre (solo nombres con huella: nunca rutas) */
  file(name: string): { file: string; mime: string } | null {
    const m = MEDIA_NAME_RE.exec(name);
    if (!m) return null;
    const file = path.join(mediaDir(), name);
    return fs.existsSync(file) ? { file, mime: MEDIA_MIME[m[2]] } : null;
  },

  /** Contenido de una imagen a partir de su dirección local */
  read(url: string): { id: string; ext: string; mime: string; bytes: Buffer } | null {
    const m = MEDIA_URL_RE.exec(url);
    if (!m) return null;
    const found = this.file(`${m[1]}.${m[2]}`);
    if (!found) return null;
    return { id: m[1], ext: m[2], mime: found.mime, bytes: fs.readFileSync(found.file) };
  },
};
