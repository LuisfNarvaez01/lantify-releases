// ============================================
// INFRASTRUCTURE - Audit Logger Service
// ============================================

import { prisma } from '../database/prisma';

export interface AuditLogPayload {
  userId?: string;
  userName?: string;
  userRole?: string;
  action: string;
  entityType: string;
  entityId?: string;
  details?: Record<string, any> | string;
  ipAddress?: string;
}

export class AuditLogger {
  /**
   * Registra un evento en la bitácora de auditoría (asíncrono seguro).
   */
  static async log(payload: AuditLogPayload): Promise<void> {
    try {
      const detailsStr = typeof payload.details === 'object' 
        ? JSON.stringify(payload.details) 
        : payload.details;

      await prisma.auditLog.create({
        data: {
          userId: payload.userId,
          userName: payload.userName,
          userRole: payload.userRole,
          action: payload.action,
          entityType: payload.entityType,
          entityId: payload.entityId,
          details: detailsStr,
          ipAddress: payload.ipAddress
        }
      });
    } catch (error) {
      console.error('⚠️ [AuditLogger] Error registrando evento de auditoría:', error);
      // No lanzamos el error para no romper la transacción principal
    }
  }

  /**
   * Obtiene los registros de auditoría más recientes con paginación y filtros.
   */
  static async getRecentLogs(limit = 50, actionFilter?: string) {
    return prisma.auditLog.findMany({
      where: actionFilter ? { action: actionFilter } : undefined,
      orderBy: { createdAt: 'desc' },
      take: limit
    });
  }
}
