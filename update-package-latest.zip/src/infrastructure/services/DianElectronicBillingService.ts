// ============================================
// SERVICE - Facturación electrónica DIAN (por Lantify Cloud) y cola sin internet
// ============================================
// Lantify es la casa de software: la nube emite la factura ante la DIAN en nombre
// del negocio a través del proveedor tecnológico. Aquí no hay credenciales ni
// envíos de prueba: el negocio solo ve si Lantify ya le activó la facturación.
// El número, el CUFE y el QR los da la DIAN; sin respuesta la factura espera en
// la cola y se reenvía sola (con el mismo número, sin duplicar). Nunca se da por
// aceptada sin respuesta real.

import crypto from 'crypto';
import { prisma } from '../database/prisma';
import { cloudConfig } from '../../shared/cloud/config';
import { allStoredLicenses } from '../../shared/cloud/license';
import { buildEinvoiceDocument, normalizeCustomer, EinvoiceCustomer } from '../../domain/einvoice';

export interface DianCustomerData {
  nit: string;
  name: string;
  email?: string;
  phone?: string;
  address?: string;
  documentType?: string;
}

const STATUS_TTL_MS = 10 * 60_000; // la cola pregunta cada 10 min; la caja, cuando la necesita
const EMIT_TIMEOUT_MS = 45_000;
const MAX_AUTO_ATTEMPTS = 30;

const saleWithItems = (id: string) =>
  prisma.sale.findUnique({ where: { id }, include: { items: { include: { productVariant: { include: { product: true } } } } } });

const notActive = () =>
  Object.assign(new Error('La facturación electrónica aún no está activada para este negocio. Pídele a Lantify que la active.'), { code: 'DIAN_NOT_CONFIGURED' });

export class DianElectronicBillingService {
  /**
   * Obtiene la configuración de la DIAN o crea una vacía (sin datos de ejemplo)
   */
  async getConfig() {
    let config = await prisma.dianConfig.findFirst();
    if (!config) {
      // Sin datos de ejemplo: el emisor es el negocio y la resolución la entrega Lantify
      const business = await prisma.businessSettings.findUnique({ where: { id: 'default' } });
      config = await prisma.dianConfig.create({
        data: {
          operationMode: 'PRODUCCION',
          providerName: '',
          softwareName: 'Lantify POS',
          wsdlUrl: '',
          nit: business?.nit || '',
          dv: business?.dv || '',
          businessName: business?.legalName || business?.businessName || '',
          resolutionNumber: '',
          resolutionDate: '',
          prefix: '',
          rangeFrom: 1,
          rangeTo: 1,
          currentNumber: 1,
          technicalKey: '',
          billingProvider: 'LANTIFY',
          isAssociated: false,
          autoSync: true,
        },
      });
    }
    return config;
  }

  /** ¿Lantify activó la facturación de este negocio? (lo último que dijo la nube) */
  isReady(config: { billingProvider: string; isAssociated: boolean }) {
    return config.billingProvider === 'LANTIFY' && config.isAssociated;
  }

  /**
   * Versiones anteriores dejaban datos de prueba en la configuración (un responsable, NIT,
   * clave técnica y la resolución de habilitación SETP 18760000001). Se borran solo esos
   * valores exactos: lo que el negocio haya escrito se respeta.
   */
  async clearSampleData() {
    const config = await prisma.dianConfig.findFirst();
    if (!config) return false;
    const sample = {
      providerName: ['NARVAEZ LOPEZ LUIS FELIPE'],
      softwareId: ['edce5592-1856-407e-acd4-e4269f7333b5', '4424e8ce-107e-403c-90c9-7023e70cae7d'],
      testSetId: ['1f64e353-a8ff-488e-b2c2-bc4e05265c92'],
      wsdlUrl: ['https://vpfe-hab.dian.gov.co/WcfDianCustomerServices.svc?wsdl'],
      nit: ['901554892'],
      businessName: ['LANTIFY OPERACIONES & SERVICIOS S.A.S.', 'LANTIFY RESTAURANTE & POS'],
      technicalKey: ['fc8eac422eba16e22f8f8b8f94b3f40a6e38162c', 'fc8eac422eba16e122d5aa92a14da838ec4f23b16a407fe150b40a10ebd02c7e66'],
    } as const;
    const data: Record<string, unknown> = {};
    for (const [key, values] of Object.entries(sample)) {
      if ((values as readonly string[]).includes(String((config as any)[key] ?? ''))) data[key] = key === 'softwareId' || key === 'testSetId' ? null : '';
    }
    if (config.softwarePin === '12345') data.softwarePin = null;
    if (config.resolutionNumber === '18760000001' && config.prefix === 'SETP') {
      Object.assign(data, { resolutionNumber: '', resolutionDate: '', prefix: '', rangeFrom: 1, rangeTo: 1, currentNumber: 1 });
    }
    if (config.operationMode !== 'PRODUCCION') data.operationMode = 'PRODUCCION';
    if (config.isAssociated && (data.providerName !== undefined || data.softwareId !== undefined)) data.isAssociated = false;
    // La facturación con credenciales propias (Factus) ya no existe: la activa Lantify
    if (config.billingProvider !== 'LANTIFY') Object.assign(data, { billingProvider: 'LANTIFY', isAssociated: false });
    if (!Object.keys(data).length) return false;
    // El emisor vacío se completa con el negocio
    if (data.nit === '' || data.businessName === '') {
      const business = await prisma.businessSettings.findUnique({ where: { id: 'default' } });
      if (data.nit === '') { data.nit = business?.nit || ''; data.dv = business?.dv || ''; }
      if (data.businessName === '') data.businessName = business?.legalName || business?.businessName || '';
    }
    await prisma.dianConfig.update({ where: { id: config.id }, data });
    return true;
  }

  /**
   * Actualiza los parámetros de configuración de la DIAN
   */
  async updateConfig(data: Partial<any>) {
    const existing = await this.getConfig();
    return prisma.dianConfig.update({
      where: { id: existing.id },
      data
    });
  }

  // ── Lantify Cloud ─────────────────────────────────────────

  /** Licencia más reciente guardada en este equipo (cualquier usuario: también un cajero emite) */
  private license() {
    return allStoredLicenses().sort((a, b) => b.claims.exp - a.claims.exp)[0]?.token ?? null;
  }

  private async cloud(method: 'GET' | 'POST', path: string, body?: unknown, timeoutMs?: number) {
    const token = this.license();
    if (!token) return { status: 0, body: { code: 'NOT_LINKED' } as any };
    const { apiUrl, timeoutMs: defaultTimeout } = cloudConfig();
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs ?? defaultTimeout);
    try {
      const res = await fetch(`${apiUrl}${path}`, {
        method,
        signal: controller.signal,
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: body === undefined ? undefined : JSON.stringify(body),
      });
      return { status: res.status, body: (await res.json().catch(() => ({}))) as any };
    } catch {
      return null; // sin conexión
    } finally {
      clearTimeout(timer);
    }
  }

  /**
   * Pregunta a la nube si la facturación está activa y guarda la respuesta (resolución,
   * prefijo, rango) para trabajar sin internet. Con `force` no usa lo guardado.
   */
  async refreshStatus(force = false) {
    const config = await this.getConfig();
    if (!force && config.statusCheckedAt && Date.now() - config.statusCheckedAt.getTime() < STATUS_TTL_MS) return config;
    const res = await this.cloud('GET', '/v1/einvoicing');
    if (!res) return config; // sin internet: vale lo último que dijo la nube
    if (res.status !== 200) {
      // Sin vincular a la nube o sin licencia vigente: no se puede facturar
      if (res.status === 0 || res.status === 401 || res.status === 403) {
        return prisma.dianConfig.update({ where: { id: config.id }, data: { billingProvider: 'LANTIFY', isAssociated: false, statusCheckedAt: new Date() } });
      }
      return config;
    }
    const s = res.body || {};
    return prisma.dianConfig.update({
      where: { id: config.id },
      data: {
        billingProvider: 'LANTIFY',
        isAssociated: !!s.active,
        documentKind: s.documentKind === 'pos' ? 'pos' : 'invoice',
        ...(s.active
          ? {
              resolutionNumber: String(s.resolutionNumber || ''),
              prefix: String(s.prefix || ''),
              rangeFrom: Number(s.rangeFrom) || 1,
              rangeTo: Number(s.rangeTo) || 1,
              resolutionDate: String(s.validUntil || ''),
            }
          : {}),
        statusCheckedAt: new Date(),
      },
    });
  }

  /** Estado para la pantalla de Configuración → DIAN (sin secretos: no hay) */
  async status(force = false) {
    const config = await this.refreshStatus(force);
    return {
      active: this.isReady(config),
      documentKind: config.documentKind,
      resolutionNumber: config.resolutionNumber || null,
      prefix: config.prefix || null,
      rangeFrom: config.rangeFrom,
      rangeTo: config.rangeTo,
      validUntil: config.resolutionDate || null,
      checkedAt: config.statusCheckedAt,
      autoSync: config.autoSync,
    };
  }

  // ── Emisión ───────────────────────────────────────────────

  /**
   * Registra la factura electrónica de una venta y la envía de una vez. Sin respuesta
   * de la DIAN queda en la cola (con número provisional) y se reenvía sola.
   */
  async enqueueInvoice(saleId: string, customerData: DianCustomerData) {
    let config = await this.refreshStatus();
    // Recién activada por Lantify: se confirma con la nube antes de decir que no
    if (!this.isReady(config)) config = await this.refreshStatus(true);
    if (!this.isReady(config)) throw notActive();

    const existing = await prisma.dianInvoice.findUnique({ where: { saleId } });
    if (existing) return existing;

    const sale = await saleWithItems(saleId);
    if (!sale) throw new Error(`Venta con ID ${saleId} no encontrada`);

    const customer = normalizeCustomer(customerData);
    // La factura electrónica se le envía al cliente: sin correo la DIAN la rechaza
    if (customer && config.documentKind !== 'pos' && !customer.email) {
      throw Object.assign(new Error('Escribe el correo del cliente: allí le llega la factura electrónica.'), { code: 'DIAN_EMAIL_REQUIRED' });
    }

    const id = crypto.randomUUID();
    const tax = Number(sale.tax) || 0;
    const invoice = await prisma.dianInvoice.create({
      data: {
        id,
        saleId,
        // Provisional: el número oficial lo asigna la DIAN al validar
        invoiceNumber: `EN-COLA-${id.slice(0, 8).toUpperCase()}`,
        prefix: config.prefix || '',
        consecutive: 0,
        cufe: '',
        qrCode: '',
        issueDate: new Date(),
        subtotal: sale.total - tax,
        tax,
        total: sale.total,
        customerNit: customer?.idNumber || '222222222222',
        customerName: customer?.name || 'Consumidor Final',
        customerEmail: customer?.email,
        customerPhone: customer?.phone,
        customerAddress: customer?.address,
        customerDocType: customer?.idType ?? null,
        status: 'PENDING_QUEUE',
        syncAttempts: 0,
      },
    });
    return this.transmit(invoice.id, EMIT_TIMEOUT_MS);
  }

  /** Envía una factura a la nube y guarda lo que respondió la DIAN */
  private async transmit(invoiceId: string, timeoutMs?: number) {
    const inv = await prisma.dianInvoice.findUnique({ where: { id: invoiceId } });
    if (!inv || inv.status === 'ACCEPTED') return inv!;
    const sale = await saleWithItems(inv.saleId);
    if (!sale) throw new Error(`Venta con ID ${inv.saleId} no encontrada`);

    const customer: EinvoiceCustomer | null = inv.customerNit === '222222222222' ? null : normalizeCustomer({
      nit: inv.customerNit, name: inv.customerName, email: inv.customerEmail, phone: inv.customerPhone, address: inv.customerAddress, documentType: inv.customerDocType,
    });
    await prisma.dianInvoice.update({ where: { id: inv.id }, data: { status: 'TRANSMITTING', lastAttemptAt: new Date(), syncAttempts: { increment: 1 } } });
    const res = await this.cloud('POST', '/v1/einvoicing/documents', buildEinvoiceDocument(inv.id, sale, customer), timeoutMs);

    if (!res || res.status === 0) {
      // Sin internet el intento no cuenta: se vuelve a intentar en la próxima vuelta
      return prisma.dianInvoice.update({
        where: { id: inv.id },
        data: { status: 'PENDING_QUEUE', syncAttempts: { decrement: 1 }, dianResponseDesc: 'Sin conexión con Lantify Cloud. Se envía sola al volver el internet.' },
      });
    }
    if (res.status !== 200) {
      const code = res.body?.code;
      if (code === 'EINVOICE_NOT_ACTIVE' || code === 'PLAN_FEATURE_REQUIRED') await this.refreshStatus(true);
      return prisma.dianInvoice.update({
        where: { id: inv.id },
        data: {
          status: code === 'EINVOICE_BAD_DOCUMENT' || code === 'EINVOICE_BAD_CUSTOMER' ? 'REJECTED' : 'PENDING_QUEUE',
          dianResponseCode: String(res.status),
          dianResponseDesc: code === 'EINVOICE_NOT_ACTIVE' ? 'La facturación electrónica no está activa para este negocio.' : `Lantify Cloud respondió ${code || res.status}. Se reintenta sola.`,
        },
      });
    }

    const out = res.body;
    if (out.status === 'ACCEPTED') {
      return prisma.dianInvoice.update({
        where: { id: inv.id },
        data: {
          status: 'ACCEPTED',
          invoiceNumber: out.number || inv.invoiceNumber,
          cufe: out.cufe || '',
          qrCode: out.qrUrl || (out.cufe ? `https://catalogo-vpfe.dian.gov.co/document/searchqr?documentkey=${out.cufe}` : ''),
          publicUrl: out.pdfUrl || null,
          dianStatus: 'VALIDADA_DIAN',
          dianResponseCode: '00',
          dianResponseDesc: out.message || 'Validada por la DIAN',
        },
      });
    }
    return prisma.dianInvoice.update({
      where: { id: inv.id },
      data: {
        status: out.status === 'REJECTED' ? 'REJECTED' : 'PENDING_QUEUE',
        cufe: out.cufe || inv.cufe,
        dianStatus: out.status === 'REJECTED' ? 'RECHAZADA_DIAN' : 'EN_VALIDACION',
        dianResponseDesc: out.message || null,
      },
    });
  }

  /**
   * Reenvía las facturas en cola (cada minuto y al volver el internet). Las rechazadas
   * por la DIAN no se reenvían solas: el ADMIN las revisa y las reintenta.
   */
  async processQueue(): Promise<{ processed: number; success: number; failed: number }> {
    const config = await this.refreshStatus();
    if (!config.autoSync || !this.isReady(config)) return { processed: 0, success: 0, failed: 0 };

    const pending = await prisma.dianInvoice.findMany({
      where: { status: { in: ['PENDING_QUEUE', 'TRANSMITTING'] }, syncAttempts: { lt: MAX_AUTO_ATTEMPTS } },
      take: 10,
      orderBy: { createdAt: 'asc' },
    });
    let success = 0;
    let failed = 0;
    for (const inv of pending) {
      try {
        const done = await this.transmit(inv.id);
        if (done.status === 'ACCEPTED') success++;
        else failed++;
      } catch (err: any) {
        failed++;
        console.warn('[DIAN] reenvío de', inv.invoiceNumber, err?.message || err);
      }
    }
    return { processed: pending.length, success, failed };
  }

  /**
   * Reintento manual forzado de una factura electrónica
   */
  async retryInvoice(invoiceId: string) {
    const inv = await prisma.dianInvoice.findUnique({ where: { id: invoiceId } });
    if (!inv) throw new Error(`Factura con ID ${invoiceId} no encontrada`);
    if (!this.isReady(await this.refreshStatus(true))) throw notActive();
    await prisma.dianInvoice.update({ where: { id: invoiceId }, data: { status: 'PENDING_QUEUE', syncAttempts: 0, dianResponseDesc: 'Reintento manual solicitado por usuario' } });
    return this.transmit(invoiceId, EMIT_TIMEOUT_MS);
  }

  /**
   * Resumen y estadísticas en tiempo real de la cola DIAN
   */
  async getQueueStats() {
    const config = await this.getConfig();
    const [pending, accepted, rejected, total] = await Promise.all([
      prisma.dianInvoice.count({ where: { status: { in: ['PENDING_QUEUE', 'TRANSMITTING'] } } }),
      prisma.dianInvoice.count({ where: { status: 'ACCEPTED' } }),
      prisma.dianInvoice.count({ where: { status: 'REJECTED' } }),
      prisma.dianInvoice.count()
    ]);

    const recentInvoices = await prisma.dianInvoice.findMany({
      take: 15,
      orderBy: { createdAt: 'desc' }
    });

    return {
      ready: this.isReady(config),
      queue: {
        pending,
        accepted,
        rejected,
        total
      },
      recentInvoices
    };
  }
}

export const dianService = new DianElectronicBillingService();
