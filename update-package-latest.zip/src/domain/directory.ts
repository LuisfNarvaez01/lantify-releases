// ============================================
// DOMAIN - Directorio "Lugares con Lantify" (Fase 4)
// ============================================
// Lo comparten el POS (qué publica), Lantify Cloud (GET /v1/public/directory) y el
// sitio (lantifypos.com/lugares y /lugares/<ciudad>). Solo datos que ya son públicos
// en la página del negocio: nombre, tipo, ciudad, frase, portada y logo.

export const DIRECTORY_TYPES = ['RESTAURANT', 'CAFE', 'BAR', 'FAST_FOOD', 'FOOD_TRUCK', 'RETAIL'] as const;
export type DirectoryType = typeof DIRECTORY_TYPES[number];

export const DIRECTORY_TYPE_LABEL: Record<DirectoryType, { es: string; en: string; schema: string }> = {
  RESTAURANT: { es: 'Restaurante', en: 'Restaurant', schema: 'Restaurant' },
  CAFE: { es: 'Café', en: 'Café', schema: 'CafeOrCoffeeShop' },
  BAR: { es: 'Bar', en: 'Bar', schema: 'BarOrPub' },
  FAST_FOOD: { es: 'Comidas rápidas', en: 'Fast food', schema: 'FastFoodRestaurant' },
  FOOD_TRUCK: { es: 'Food truck', en: 'Food truck', schema: 'FoodEstablishment' },
  RETAIL: { es: 'Tienda', en: 'Shop', schema: 'Store' },
};

/** Dirección de una ciudad: "Neiva" → "neiva", "Santa Marta" → "santa-marta", "Bogotá D.C." → "bogota-dc" */
export const citySlug = (city: string | null | undefined): string =>
  (city || '')
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 50);

export const normalizeDirectoryType = (t: unknown): DirectoryType =>
  (DIRECTORY_TYPES as readonly string[]).includes(t as string) ? (t as DirectoryType) : 'RESTAURANT';

/** Lo que el POS manda al publicar la página: null = no aparece */
export interface DirectoryListing { type: DirectoryType }

export const normalizeDirectoryListing = (raw: unknown): DirectoryListing | null => {
  const r = raw && typeof raw === 'object' ? (raw as Record<string, unknown>) : null;
  if (!r || r.listed !== true) return null;
  return { type: normalizeDirectoryType(r.type) };
};

export interface DirectoryEntry {
  slug: string;
  name: string;
  type: DirectoryType;
  city: string;
  citySlug: string;
  tagline: string | null;
  coverImage: string | null;
  logoImage: string | null;
}

export interface DirectoryCity { slug: string; name: string; count: number }

/** Ciudades con al menos un negocio (nunca hay páginas de ciudad vacías) */
export const directoryCities = (entries: DirectoryEntry[]): DirectoryCity[] => {
  const by = new Map<string, DirectoryCity>();
  for (const e of entries) {
    if (!e.citySlug) continue;
    const c = by.get(e.citySlug) || { slug: e.citySlug, name: e.city, count: 0 };
    c.count++;
    by.set(e.citySlug, c);
  }
  return [...by.values()].sort((a, b) => b.count - a.count || a.name.localeCompare(b.name, 'es'));
};

/** Entrada que llega de la red (sitio): se sanea para no romper la página */
export const parseDirectoryEntries = (raw: unknown): DirectoryEntry[] => {
  const list = raw && typeof raw === 'object' && Array.isArray((raw as any).places) ? (raw as any).places : [];
  const https = (u: unknown) => (typeof u === 'string' && /^https:\/\/[^\s"'<>]+$/.test(u) ? u : null);
  const out: DirectoryEntry[] = [];
  for (const p of list.slice(0, 2000)) {
    if (!p || typeof p.slug !== 'string' || !/^[a-z0-9-]{3,40}$/.test(p.slug) || typeof p.name !== 'string') continue;
    const city = typeof p.city === 'string' ? p.city.slice(0, 60) : '';
    const slug = citySlug(city);
    if (!slug) continue;
    out.push({
      slug: p.slug,
      name: p.name.slice(0, 120),
      type: normalizeDirectoryType(p.type),
      city,
      citySlug: slug,
      tagline: typeof p.tagline === 'string' ? p.tagline.slice(0, 140) : null,
      coverImage: https(p.coverImage),
      logoImage: https(p.logoImage),
    });
  }
  return out;
};
