// ============================================
// DOMAIN - Reservas: horarios, cupos y mesa
// ============================================
// Lógica pura (sin base de datos ni Node) que comparten el POS y Lantify Cloud,
// para que la página pública y la caja digan exactamente lo mismo:
//   · qué horas de llegada se ofrecen un día (horario del negocio),
//   · qué mesa reservable sirve para un grupo y está libre a esa hora,
//   · si una reserva choca con otra en la misma mesa.
// Las horas se manejan en la hora local del negocio (Colombia: UTC−5, sin horario
// de verano) y se guardan en UTC.

export const ACTIVE_STATUSES = ['PENDING', 'CONFIRMED', 'SEATED'] as const;
export const ALL_STATUSES = ['PENDING', 'CONFIRMED', 'SEATED', 'CANCELLED', 'NO_SHOW'] as const;
export type ReservationStatus = (typeof ALL_STATUSES)[number];

export interface ScheduleBlock {
  /** 0 = domingo … 6 = sábado */
  day: number;
  /** Primera y última hora de llegada (HH:MM). Si `to` < `from`, termina al día siguiente */
  from: string;
  to: string;
}

export interface BookingSettings {
  /** Módulo de reservas activo en el POS */
  enabled: boolean;
  /** Reservas desde la página pública (QR / enlace) */
  online: boolean;
  slotMinutes: number;
  /** Tiempo que la mesa queda apartada por reserva */
  durationMinutes: number;
  minAdvanceMinutes: number;
  maxDaysAhead: number;
  maxPartySize: number;
  /** Las reservas de la página llegan pendientes y el local las confirma */
  requireConfirmation: boolean;
  /** Hasta cuántos minutos antes el cliente puede cancelar desde la página */
  cancelUntilMinutes: number;
  schedule: ScheduleBlock[];
  utcOffsetMinutes: number;
  /** WhatsApp del negocio para grupos grandes o dudas */
  whatsapp: string | null;
  /** Nota que ve el cliente al reservar */
  message: string | null;
}

export const DEFAULT_BOOKING: BookingSettings = {
  enabled: false,
  online: false,
  slotMinutes: 30,
  durationMinutes: 90,
  minAdvanceMinutes: 60,
  maxDaysAhead: 30,
  maxPartySize: 10,
  requireConfirmation: false,
  cancelUntilMinutes: 120,
  schedule: [1, 2, 3, 4, 5, 6, 0].flatMap((day) => [
    { day, from: '12:00', to: '14:30' },
    { day, from: '18:00', to: '21:00' },
  ]),
  utcOffsetMinutes: -300,
  whatsapp: null,
  message: null,
};

const HHMM = /^([01]\d|2[0-3]):([0-5]\d)$/;
const int = (v: unknown, min: number, max: number, fallback: number) => {
  const n = Math.round(Number(v));
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
};
const text = (v: unknown, max: number) => (typeof v === 'string' && v.trim() ? v.trim().slice(0, max) : null);

/** Configuración saneada: lo que llegue de un formulario o de la nube nunca rompe el cálculo */
export const normalizeBooking = (raw: unknown): BookingSettings => {
  const r = (raw && typeof raw === 'object' ? raw : {}) as Record<string, any>;
  const schedule = Array.isArray(r.schedule)
    ? r.schedule
        .filter((b: any) => b && Number.isInteger(b.day) && b.day >= 0 && b.day <= 6 && HHMM.test(b.from) && HHMM.test(b.to))
        .slice(0, 28)
        .map((b: any) => ({ day: b.day, from: b.from, to: b.to }))
    : DEFAULT_BOOKING.schedule;
  return {
    enabled: !!r.enabled,
    online: !!r.online,
    slotMinutes: [15, 30, 60].includes(Number(r.slotMinutes)) ? Number(r.slotMinutes) : DEFAULT_BOOKING.slotMinutes,
    durationMinutes: int(r.durationMinutes, 30, 360, DEFAULT_BOOKING.durationMinutes),
    minAdvanceMinutes: int(r.minAdvanceMinutes, 0, 7 * 24 * 60, DEFAULT_BOOKING.minAdvanceMinutes),
    maxDaysAhead: int(r.maxDaysAhead, 1, 180, DEFAULT_BOOKING.maxDaysAhead),
    maxPartySize: int(r.maxPartySize, 1, 100, DEFAULT_BOOKING.maxPartySize),
    requireConfirmation: !!r.requireConfirmation,
    cancelUntilMinutes: int(r.cancelUntilMinutes, 0, 7 * 24 * 60, DEFAULT_BOOKING.cancelUntilMinutes),
    schedule,
    utcOffsetMinutes: int(r.utcOffsetMinutes, -720, 840, DEFAULT_BOOKING.utcOffsetMinutes),
    whatsapp: text(r.whatsapp, 20)?.replace(/[^\d+]/g, '') || null,
    message: text(r.message, 280),
  };
};

// ── Fechas en la hora del negocio ───────────────────────────

const toMinutes = (hhmm: string) => Number(hhmm.slice(0, 2)) * 60 + Number(hhmm.slice(3, 5));
const pad = (n: number) => String(n).padStart(2, '0');
export const isDateString = (s: unknown): s is string => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && !Number.isNaN(Date.parse(`${s}T00:00:00Z`));

/** Inicio (UTC) del día local `date` + `minutes` minutos */
export const localToUtc = (date: string, minutes: number, offset: number) =>
  new Date(Date.parse(`${date}T00:00:00Z`) + (minutes - offset) * 60000);

/** Fecha y hora local (del negocio) de un instante */
export const utcToLocal = (d: Date, offset: number) => {
  const local = new Date(d.getTime() + offset * 60000);
  return {
    date: `${local.getUTCFullYear()}-${pad(local.getUTCMonth() + 1)}-${pad(local.getUTCDate())}`,
    time: `${pad(local.getUTCHours())}:${pad(local.getUTCMinutes())}`,
    weekday: local.getUTCDay(),
  };
};

const weekdayOf = (date: string) => new Date(`${date}T00:00:00Z`).getUTCDay();

/** Horas de llegada que se ofrecen ese día, en minutos desde la medianoche local (pueden pasar de 24 h) */
export const slotMinutesFor = (settings: BookingSettings, date: string): number[] => {
  const day = weekdayOf(date);
  const out = new Set<number>();
  for (const b of settings.schedule.filter((s) => s.day === day)) {
    const from = toMinutes(b.from);
    let to = toMinutes(b.to);
    if (to < from) to += 24 * 60;
    for (let m = from; m <= to; m += settings.slotMinutes) out.add(m);
  }
  return [...out].sort((a, b) => a - b);
};

export const minutesLabel = (m: number) => `${pad(Math.floor(m / 60) % 24)}:${pad(m % 60)}`;

// ── Mesas y choques ─────────────────────────────────────────

export interface BookableTable {
  id: string;
  label: string;
  capacity: number;
  zone?: string | null;
}

export interface BusyInterval {
  id?: string;
  tableId: string | null;
  startsAt: string | Date;
  endsAt: string | Date;
  status?: string;
}

const ms = (d: string | Date) => (d instanceof Date ? d.getTime() : Date.parse(d));

export const overlaps = (aStart: number, aEnd: number, bStart: number, bEnd: number) => aStart < bEnd && bStart < aEnd;

const isActive = (b: BusyInterval) => !b.status || (ACTIVE_STATUSES as readonly string[]).includes(b.status);

/** ¿La mesa está libre entre start y end? (ignora la reserva `exceptId` al editar) */
export const tableIsFree = (tableId: string, start: Date, end: Date, busy: BusyInterval[], exceptId?: string) =>
  !busy.some(
    (b) =>
      b.tableId === tableId &&
      (exceptId === undefined || b.id !== exceptId) &&
      isActive(b) &&
      overlaps(start.getTime(), end.getTime(), ms(b.startsAt), ms(b.endsAt)),
  );

/** La mesa libre más ajustada al grupo (la más pequeña donde caben) */
export const pickTable = (tables: BookableTable[], busy: BusyInterval[], start: Date, end: Date, party: number, exceptId?: string) =>
  [...tables]
    .filter((t) => t.capacity >= party)
    .sort((a, b) => a.capacity - b.capacity || a.label.localeCompare(b.label, 'es', { numeric: true }))
    .find((t) => tableIsFree(t.id, start, end, busy, exceptId)) || null;

// ── Disponibilidad y validación ─────────────────────────────

export type BookingErrorCode =
  | 'BOOKING_DISABLED'
  | 'BOOKING_BAD_DATE'
  | 'BOOKING_CLOSED_DAY'
  | 'BOOKING_OUTSIDE_HOURS'
  | 'BOOKING_TOO_SOON'
  | 'BOOKING_TOO_FAR'
  | 'BOOKING_PARTY_TOO_BIG'
  | 'BOOKING_NO_TABLE';

export interface SlotAvailability {
  time: string;
  /** Minutos desde la medianoche local del día elegido */
  minutes: number;
  available: boolean;
}

/** Horas del día con o sin mesa libre para el grupo, respetando anticipación y días hacia adelante */
export const availability = (args: {
  settings: BookingSettings;
  tables: BookableTable[];
  busy: BusyInterval[];
  date: string;
  party: number;
  now?: Date;
}): SlotAvailability[] => {
  const { settings, tables, busy, date, party } = args;
  const now = args.now ?? new Date();
  if (!isDateString(date)) return [];
  return slotMinutesFor(settings, date).map((minutes) => {
    const start = localToUtc(date, minutes, settings.utcOffsetMinutes);
    const end = new Date(start.getTime() + settings.durationMinutes * 60000);
    const timing = checkTiming(settings, start, now);
    const available = !timing && party <= settings.maxPartySize && !!pickTable(tables, busy, start, end, party);
    return { time: minutesLabel(minutes), minutes, available };
  });
};

/** Anticipación mínima y días hacia adelante (para la página; la caja puede saltárselo) */
export const checkTiming = (settings: BookingSettings, start: Date, now: Date): BookingErrorCode | null => {
  if (start.getTime() < now.getTime() + settings.minAdvanceMinutes * 60000) return 'BOOKING_TOO_SOON';
  if (start.getTime() > now.getTime() + settings.maxDaysAhead * 86400000) return 'BOOKING_TOO_FAR';
  return null;
};

/**
 * Valida una reserva de la página pública y elige la mesa. La hora debe ser una
 * de las que ofrece el horario de ese día.
 */
export const planOnlineBooking = (args: {
  settings: BookingSettings;
  tables: BookableTable[];
  busy: BusyInterval[];
  date: string;
  minutes: number;
  party: number;
  now?: Date;
}): { ok: true; table: BookableTable; startsAt: Date; endsAt: Date } | { ok: false; code: BookingErrorCode } => {
  const { settings, tables, busy, date, minutes, party } = args;
  const now = args.now ?? new Date();
  if (!settings.enabled || !settings.online) return { ok: false, code: 'BOOKING_DISABLED' };
  if (!isDateString(date)) return { ok: false, code: 'BOOKING_BAD_DATE' };
  // El grupo más grande es el menor entre la regla del negocio y la mesa más grande que se ofrece
  const largest = Math.max(0, ...tables.map((t) => t.capacity));
  if (!Number.isInteger(party) || party < 1 || party > Math.min(settings.maxPartySize, largest)) return { ok: false, code: 'BOOKING_PARTY_TOO_BIG' };
  const offered = slotMinutesFor(settings, date);
  if (!offered.length) return { ok: false, code: 'BOOKING_CLOSED_DAY' };
  if (!offered.includes(minutes)) return { ok: false, code: 'BOOKING_OUTSIDE_HOURS' };
  const startsAt = localToUtc(date, minutes, settings.utcOffsetMinutes);
  const endsAt = new Date(startsAt.getTime() + settings.durationMinutes * 60000);
  const timing = checkTiming(settings, startsAt, now);
  if (timing) return { ok: false, code: timing };
  const table = pickTable(tables, busy, startsAt, endsAt, party);
  if (!table) return { ok: false, code: 'BOOKING_NO_TABLE' };
  return { ok: true, table, startsAt, endsAt };
};

/** Código corto para que el cliente identifique su reserva (sin letras que se confunden) */
export const reservationCode = (random: () => number = Math.random) => {
  const alphabet = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 6; i++) code += alphabet[Math.floor(random() * alphabet.length)];
  return code;
};
