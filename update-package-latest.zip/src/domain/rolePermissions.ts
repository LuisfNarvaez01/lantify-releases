// ============================================
// DOMAIN - Funciones que el ADMIN puede dar a cada rol
// ============================================
// El ADMIN siempre puede todo. Para cajeros y meseros, el ADMIN elige qué
// funciones tienen (Configuración › Usuarios y roles). Tomar pedidos y enviar
// a cocina es de todos; configurar el negocio, usuarios y catálogo es del ADMIN.
// Lo comparten el servidor (política de acceso) y la pantalla (qué se muestra).

export const PERMISSIONS = [
  'charge',         // Cobrar cuentas, cerrar mesas, descuentos, cupones, factura electrónica
  'cash',           // Abrir y cerrar caja, gastos, ingresos y sus informes
  'sales_history',  // Ver el historial de ventas y reimprimir
  'online_orders',  // Atender pedidos de la página y domicilios
  'customers_edit', // Editar clientes y sumar o quitar sellos
  'reservations',   // Agendar y cambiar reservas
  'analytics',      // Ver estadísticas
  'payment_fix',    // Corregir el medio de pago de una venta ya cobrada
] as const;

export type Permission = typeof PERMISSIONS[number];
export type ConfigurableRole = 'CASHIER' | 'WAITER';
export type RolePermissions = Record<ConfigurableRole, Permission[]>;

export const CONFIGURABLE_ROLES: ConfigurableRole[] = ['CASHIER', 'WAITER'];

/** Lo que cada rol podía hacer antes de que esto fuera configurable */
export const DEFAULT_ROLE_PERMISSIONS: RolePermissions = {
  CASHIER: ['charge', 'cash', 'sales_history', 'online_orders', 'customers_edit', 'reservations'],
  WAITER: ['reservations'],
};

const isPermission = (v: unknown): v is Permission => typeof v === 'string' && (PERMISSIONS as readonly string[]).includes(v);

export const normalizeRolePermissions = (raw: unknown): RolePermissions => {
  const src = raw && typeof raw === 'object' ? (raw as Record<string, unknown>) : {};
  const out = {} as RolePermissions;
  for (const role of CONFIGURABLE_ROLES) {
    const list = src[role];
    out[role] = Array.isArray(list)
      ? PERMISSIONS.filter((p) => list.some((x) => x === p && isPermission(x)))
      : [...DEFAULT_ROLE_PERMISSIONS[role]];
  }
  return out;
};

/** ¿El rol tiene alguna de estas funciones? El ADMIN siempre sí. */
export const roleCan = (perms: RolePermissions, role: string | undefined, ...wanted: Permission[]): boolean => {
  if (role === 'ADMIN') return true;
  const list = perms[role as ConfigurableRole];
  return !!list && wanted.some((p) => list.includes(p));
};
