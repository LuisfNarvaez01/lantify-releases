// ============================================
// DOMAIN - Kiosco de autoservicio (Fase 4 · 16)
// ============================================
// Una tablet emparejada con código muestra la carta con fotos; el cliente arma su
// pedido, escribe su nombre y lo envía. Entra a la caja como pedido en línea
// (canal KIOSK) y se cobra allí con su número. Los precios los pone siempre el
// servidor con la carta de la caja: lo que diga la tablet no cuenta.

export class KioskError extends Error {
  constructor(message: string, public code: string, public statusCode = 400) {
    super(message);
  }
}

export const KIOSK_MAX_LINES = 30;
export const KIOSK_MAX_QTY = 20;
/** Segundos sin tocar la pantalla para volver al inicio (y vaciar el pedido) */
export const KIOSK_IDLE_SECONDS = 90;
export type KioskPayment = 'COUNTER' | 'QR';

export interface KioskCatalogVariant { id: string; name: string; price: number; productName: string; available: boolean }
export interface KioskLine { id: string; name: string; price: number; qty: number; note: string | null }
export interface KioskOrderDraft { customerName: string; payment: KioskPayment; lines: KioskLine[]; total: number }

const text = (v: unknown, max: number) => (typeof v === 'string' ? v.replace(/\s+/g, ' ').trim().slice(0, max) : '');

/** "Producto · Presentación" (sin la presentación única) */
export const kioskLineName = (product: string, variant: string) =>
  variant && variant !== 'Única' && !['default', 'regular'].includes(variant.toLowerCase()) ? `${product} · ${variant}` : product;

/**
 * Valida el pedido de la tablet contra la carta. Lanza KioskError con un mensaje
 * que el cliente entiende (lo muestra la tablet).
 */
export const buildKioskOrder = (raw: unknown, catalog: Map<string, KioskCatalogVariant>): KioskOrderDraft => {
  const r = raw && typeof raw === 'object' ? (raw as Record<string, any>) : {};
  const customerName = text(r.customerName, 40);
  if (customerName.length < 2) throw new KioskError('Escribe tu nombre para llamarte cuando esté listo.', 'KIOSK_NAME');
  const payment: KioskPayment = r.payment === 'QR' ? 'QR' : 'COUNTER';
  const items = Array.isArray(r.items) ? r.items : [];
  if (!items.length) throw new KioskError('Tu pedido está vacío.', 'KIOSK_EMPTY');
  if (items.length > KIOSK_MAX_LINES) throw new KioskError('El pedido tiene demasiados productos.', 'KIOSK_TOO_MANY');
  const lines: KioskLine[] = [];
  for (const it of items) {
    const id = typeof it?.variantId === 'string' ? it.variantId : '';
    const v = catalog.get(id);
    if (!v || !v.available) throw new KioskError('Uno de los productos ya no está disponible. Revisa tu pedido.', 'KIOSK_UNAVAILABLE', 409);
    const qty = Math.round(Number(it.qty));
    if (!Number.isInteger(qty) || qty < 1 || qty > KIOSK_MAX_QTY) throw new KioskError('Cantidad inválida.', 'KIOSK_QTY');
    lines.push({ id: v.id, name: kioskLineName(v.productName, v.name), price: v.price, qty, note: text(it.note, 120) || null });
  }
  return { customerName, payment, lines, total: lines.reduce((n, l) => n + l.price * l.qty, 0) };
};

/**
 * Código del pedido: K + consecutivo del día y la fecha (K7-261124). Es único en la
 * caja; al cliente se le muestra y se le llama por la primera parte (K7).
 */
export const kioskCode = (seq: number, day: Date) => {
  const p = (n: number) => String(n).padStart(2, '0');
  return `K${Math.max(1, Math.round(seq))}-${p(day.getFullYear() % 100)}${p(day.getMonth() + 1)}${p(day.getDate())}`;
};

/** Lo que se le dice al cliente: K7 */
export const kioskNumber = (code: string) => code.split('-')[0];
