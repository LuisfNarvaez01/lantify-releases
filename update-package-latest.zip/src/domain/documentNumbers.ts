// Numeración de ventas y comandas: prefijo, fecha local y consecutivo del día (SALE-20261103-0001).
// Antes eran cuatro dígitos al azar por día: con 100 ventas había un 39 % de probabilidad de que un
// cobro chocara con otro número ya usado (DEF-17).

export const dayKey = (now: Date) =>
  `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`;

export const dayPrefix = (prefix: string, now: Date) => `${prefix}-${dayKey(now)}-`;

/**
 * Siguiente número a partir del último emitido hoy. `attempt` lo adelanta cuando otro equipo
 * tomó el mismo número al mismo tiempo (reintento tras un choque de unicidad).
 */
export function nextDocumentNumber(prefix: string, now: Date, last: string | null | undefined, attempt = 0): string {
  const start = dayPrefix(prefix, now);
  const lastSeq = last?.startsWith(start) ? Number.parseInt(last.slice(start.length), 10) : 0;
  const seq = (Number.isFinite(lastSeq) ? lastSeq : 0) + 1 + attempt;
  return `${start}${String(seq).padStart(4, '0')}`;
}

/** Error de Prisma por valor repetido en una columna única (P2002) sobre el campo indicado */
export const isDuplicateOf = (err: any, field: string) =>
  err?.code === 'P2002' && String(err?.meta?.target ?? '').includes(field);

/** Repite la operación completa (normalmente una transacción) si el número ya lo tomó otro cobro */
export async function retryOnDuplicateNumber<T>(field: string, run: (attempt: number) => Promise<T>, tries = 5): Promise<T> {
  for (let attempt = 0; ; attempt++) {
    try {
      return await run(attempt);
    } catch (err) {
      if (!isDuplicateOf(err, field) || attempt >= tries - 1) throw err;
    }
  }
}
