// Numeración de ventas y comandas: prefijo, fecha local y consecutivo del día (SALE-20261103-0001).
// Antes eran cuatro dígitos al azar por día: con 100 ventas había un 39 % de probabilidad de que un
// cobro chocara con otro número ya usado (DEF-17).

export const dayKey = (now: Date) =>
  `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`;

export const dayPrefix = (prefix: string, now: Date) => `${prefix}-${dayKey(now)}-`;

/**
 * Siguiente número a partir del último emitido hoy. `attempt` lo adelanta cuando otro equipo
 * tomó el mismo número al mismo tiempo (reintento tras un choque de unicidad).
 */
export function nextDocumentNumber(prefix: string, now: Date, last: string | null | undefined, attempt = 0): string {
  const start = dayPrefix(prefix, now);
  const lastSeq = last?.startsWith(start) ? Number.parseInt(last.slice(start.length), 10) : 0;
  const seq = (Number.isFinite(lastSeq) ? lastSeq : 0) + 1 + attempt;
  return `${start}${String(seq).padStart(4, '0')}`;
}

/** Error de Prisma por valor repetido en una columna única (P2002) sobre alguno de los campos indicados */
export const isDuplicateOf = (err: any, field: string | string[]) =>
  err?.code === 'P2002' && (Array.isArray(field) ? field : [field]).some((f) => String(err?.meta?.target ?? '').includes(f));

// ── Número corto de venta (C1-000123): consecutivo que nunca reinicia ──

/** Prefijo de caja limpio: letras y números en mayúscula, 1 a 4 caracteres (por defecto C1) */
export const cleanRegisterCode = (code: string | null | undefined) =>
  String(code ?? '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 4) || 'C1';

export const formatReceiptCode = (registerCode: string | null | undefined, receiptNo: number) =>
  `${cleanRegisterCode(registerCode)}-${String(receiptNo).padStart(6, '0')}`;

/** Siguiente consecutivo a partir del mayor emitido; `attempt` lo adelanta tras un choque */
export const nextReceiptNo = (lastNo: number | null | undefined, attempt = 0) => (lastNo ?? 0) + 1 + attempt;

/** Número que se muestra de una venta: el corto si existe, si no el interno (ventas sin migrar) */
export const saleDisplayNumber = (sale: { receiptCode?: string | null; saleNumber?: string | null }) =>
  sale.receiptCode || sale.saleNumber || '';

/** Repite la operación completa (normalmente una transacción) si el número ya lo tomó otro cobro */
export async function retryOnDuplicateNumber<T>(field: string | string[], run: (attempt: number) => Promise<T>, tries = 5): Promise<T> {
  for (let attempt = 0; ; attempt++) {
    try {
      return await run(attempt);
    } catch (err) {
      if (!isDuplicateOf(err, field) || attempt >= tries - 1) throw err;
    }
  }
}
