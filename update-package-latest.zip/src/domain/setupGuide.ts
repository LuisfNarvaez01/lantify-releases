// ============================================
// DOMAIN - Guía de configuración por funciones
// ============================================
// La guía pregunta función por función qué va a usar el negocio (solo las que
// incluye su plan) y arma el paso a paso de lo elegido. Cada paso lleva a la
// pantalla donde se hace; los que el sistema puede comprobar se marcan solos y
// los demás los marca el administrador. Lo comparten el servidor y la pantalla.

/** Pantallas de Administración (y del POS) a las que lleva un paso */
export type GuideSection =
  | 'business' | 'salon' | 'users' | 'printers' | 'appearance'
  | 'products' | 'inventory' | 'suppliers'
  | 'customers' | 'coupons' | 'page'
  | 'dian' | 'subscription' | 'ai' | 'maintenance'
  | 'pos-cash' | 'menu-engine';

export interface GuideStep {
  id: string;
  section: GuideSection;
  /** El servidor sabe si ya está hecho; si no, lo marca el administrador */
  auto: boolean;
  /** Artículo del centro de ayuda que explica el paso */
  article?: string;
}

export interface GuideFunction {
  id: string;
  /** Función del plan que la incluye (null = todos los planes) */
  feature: string | null;
  /** Imprescindible: no se pregunta, siempre está en la guía */
  essential?: boolean;
  /** Solo si el negocio atiende en mesas */
  needsTables?: boolean;
  /** Novedad de Lantify 3.0: se resalta en la guía */
  isNew?: boolean;
  steps: GuideStep[];
}

const step = (id: string, section: GuideSection, auto: boolean, article?: string): GuideStep => ({ id, section, auto, article });

export const GUIDE_FUNCTIONS: GuideFunction[] = [
  // ── Novedades de Lantify 3.0: cada una lleva a la sección donde se enciende ──
  {
    id: 'v3_celular', feature: null, isNew: true,
    steps: [step('v3_celular_instalar', 'users', false, 'vista-celular')],
  },
  {
    id: 'v3_salon', feature: null, needsTables: true, isNew: true,
    steps: [
      step('v3_salon_limpieza', 'salon', false, 'mesa-por-limpiar-y-alertas'),
      step('v3_salon_alertas', 'salon', false, 'mesa-por-limpiar-y-alertas'),
    ],
  },
  {
    id: 'v3_pantallas', feature: 'ops_pro', isNew: true,
    steps: [
      step('v3_pantallas_activar', 'salon', false, 'pantallas'),
      step('v3_pantallas_conectar', 'salon', false, 'pantallas'),
    ],
  },
  {
    id: 'v3_autopilot', feature: 'autopilot', isNew: true,
    steps: [
      step('v3_autopilot_motor', 'menu-engine', false, 'autopilot'),
      step('v3_autopilot_activar', 'salon', false, 'autopilot'),
    ],
  },
  {
    id: 'v3_comandas', feature: null, isNew: true,
    steps: [
      step('v3_comandas_ingredientes', 'products', false, 'comentarios-e-ingredientes'),
      step('v3_comandas_frases', 'salon', false, 'comentarios-e-ingredientes'),
    ],
  },
  {
    id: 'v3_compras', feature: 'suppliers', isNew: true,
    steps: [
      step('v3_compras_minimos', 'inventory', false, 'lista-de-compras'),
      step('v3_compras_activar', 'inventory', false, 'lista-de-compras'),
    ],
  },
  {
    id: 'v3_personal', feature: 'ops_pro', isNew: true,
    steps: [
      step('v3_personal_activar', 'users', false, 'personal-y-pagos'),
      step('v3_personal_propinas', 'users', false, 'reparto-de-propinas'),
    ],
  },
  {
    id: 'v3_cierre', feature: 'ops_pro', isNew: true,
    steps: [step('v3_cierre_activar', 'business', false, 'reporte-de-cierre')],
  },
  // ── Novedades de Lantify 3.2: lo nuevo de la Fase 4, en el orden en que más rinde ──
  {
    id: 'v32_mesa', feature: 'webstore', needsTables: true, isNew: true,
    steps: [
      step('v32_mesa_activar', 'salon', true, 'pedido-desde-la-mesa'),
      step('v32_mesa_imprimir', 'salon', false, 'pedido-desde-la-mesa'),
    ],
  },
  {
    id: 'v32_celulares', feature: null, isNew: true,
    steps: [step('v32_celulares_vincular', 'users', true, 'vista-celular')],
  },
  {
    id: 'v32_happy', feature: 'ops_pro', isNew: true,
    steps: [step('v32_happy_crear', 'products', true, 'precios-por-horario')],
  },
  {
    id: 'v32_resena', feature: 'loyalty', isNew: true,
    steps: [
      step('v32_resena_enlace', 'page', true, 'encuesta-de-satisfaccion'),
      step('v32_resena_recibo', 'printers', true, 'encuesta-de-satisfaccion'),
      step('v32_resena_encuesta', 'page', true, 'encuesta-de-satisfaccion'),
    ],
  },
  {
    id: 'v32_cerca', feature: 'loyalty', isNew: true,
    steps: [step('v32_cerca_activar', 'page', true, 'aviso-al-pasar-cerca')],
  },
  {
    id: 'v32_pantalla_cliente', feature: 'ops_pro', isNew: true,
    steps: [step('v32_pantalla_cliente_conectar', 'salon', true, 'pantalla-del-cliente')],
  },
  {
    id: 'v32_kiosco', feature: 'webstore', isNew: true,
    steps: [step('v32_kiosco_conectar', 'salon', true, 'kiosco')],
  },
  {
    id: 'v32_asistencia', feature: 'ops_pro', isNew: true,
    steps: [step('v32_asistencia_activar', 'users', true, 'asistencia-con-pin')],
  },
  {
    id: 'v32_puerta', feature: 'ops_pro', isNew: true,
    steps: [
      step('v32_puerta_aforo', 'business', true, 'puerta-y-aforo'),
      step('v32_puerta_cover', 'products', true, 'puerta-y-aforo'),
      step('v32_puerta_portero', 'users', true, 'puerta-y-aforo'),
    ],
  },
  {
    id: 'v32_banco', feature: 'ops_pro', isNew: true,
    steps: [step('v32_banco_activar', 'users', false, 'transferencias-con-aviso-del-banco')],
  },
  {
    id: 'v32_contable', feature: 'ops_pro', isNew: true,
    steps: [step('v32_contable_cuentas', 'business', false, 'exportacion-contable')],
  },
  {
    id: 'v32_sedes', feature: 'autopilot', isNew: true,
    steps: [step('v32_sedes_copiar', 'business', false, 'varias-sedes')],
  },
  {
    id: 'v32_directorio', feature: null, isNew: true,
    steps: [step('v32_directorio_activar', 'page', true, 'lugares-con-lantify')],
  },
  {
    id: 'negocio', feature: null, essential: true,
    steps: [
      step('negocio_datos', 'business', true, 'configurar-negocio'),
      step('negocio_logo', 'business', true, 'configurar-negocio'),
      step('negocio_cuenta', 'subscription', true, 'guia-de-configuracion'),
    ],
  },
  {
    id: 'carta', feature: null, essential: true,
    steps: [
      step('carta_productos', 'products', true, 'productos-e-impuestos'),
      step('carta_impuestos', 'products', false, 'productos-e-impuestos'),
      step('carta_fotos', 'products', true, 'productos-e-impuestos'),
    ],
  },
  {
    id: 'salon', feature: null, needsTables: true,
    steps: [
      step('salon_mesas', 'salon', true, 'cocina-y-rondas'),
      step('salon_plano', 'salon', false, 'cocina-y-rondas'),
    ],
  },
  {
    id: 'impresion', feature: null,
    steps: [
      step('impresion_impresora', 'printers', true, 'impresion'),
      step('impresion_prueba', 'printers', false, 'impresion'),
    ],
  },
  {
    id: 'equipo', feature: null,
    steps: [
      step('equipo_usuarios', 'users', true, 'usuarios-y-roles'),
      step('equipo_funciones', 'users', true, 'usuarios-y-roles'),
      step('equipo_tablets', 'users', false, 'tablets'),
    ],
  },
  {
    id: 'caja', feature: null,
    steps: [
      step('caja_propina', 'business', false, 'caja'),
      step('caja_primera', 'pos-cash', true, 'caja'),
    ],
  },
  {
    id: 'inventario', feature: null,
    steps: [step('inventario_control', 'inventory', true, 'productos-e-impuestos')],
  },
  {
    id: 'proveedores', feature: 'suppliers',
    steps: [
      step('proveedores_crear', 'suppliers', true),
      step('proveedores_gastos', 'suppliers', true, 'caja'),
    ],
  },
  {
    id: 'clientes', feature: 'customers',
    steps: [step('clientes_registro', 'customers', true)],
  },
  {
    id: 'cupones', feature: 'coupons',
    steps: [step('cupones_crear', 'coupons', true, 'descuentos')],
  },
  {
    id: 'dian', feature: 'dian',
    steps: [
      step('dian_proveedor', 'dian', true, 'facturacion-dian'),
      step('dian_prueba', 'dian', false, 'facturacion-dian'),
    ],
  },
  {
    id: 'pagina', feature: 'business_page',
    steps: [
      step('pagina_perfil', 'page', false, 'mi-pagina'),
      step('pagina_publicar', 'page', true, 'mi-pagina'),
    ],
  },
  {
    id: 'reservas', feature: 'reservations',
    steps: [step('reservas_activar', 'page', true, 'mi-pagina')],
  },
  {
    id: 'pedidos', feature: 'webstore',
    steps: [step('pedidos_activar', 'page', true, 'mi-pagina')],
  },
  {
    id: 'fidelidad', feature: 'loyalty',
    steps: [
      step('fidelidad_reglas', 'page', true, 'fidelidad-y-juegos'),
      step('fidelidad_registro', 'page', true, 'fidelidad-y-juegos'),
      step('fidelidad_juego', 'page', true, 'fidelidad-y-juegos'),
    ],
  },
  {
    id: 'ia', feature: 'ai_copilot',
    steps: [step('ia_autorizar', 'ai', true)],
  },
  {
    id: 'respaldo', feature: null,
    steps: [step('respaldo_copia', 'maintenance', false, 'problemas-de-conexion')],
  },
];

export type GuideChoice = 'use' | 'skip';

export interface SetupGuideState {
  /** Qué decidió el administrador por cada función (sin entrada = aún no decide) */
  choices: Record<string, GuideChoice>;
  /** Pasos que el administrador marcó como hechos a mano */
  done: string[];
  /** Ocultó el aviso de la guía en el POS */
  hiddenAt: string | null;
}

export const EMPTY_GUIDE: SetupGuideState = { choices: {}, done: [], hiddenAt: null };

const STEP_IDS = new Set(GUIDE_FUNCTIONS.flatMap((f) => f.steps.map((s) => s.id)));
const FN_IDS = new Set(GUIDE_FUNCTIONS.map((f) => f.id));

export const normalizeGuide = (raw: unknown): SetupGuideState => {
  const r = raw && typeof raw === 'object' ? (raw as Record<string, unknown>) : {};
  const choices: Record<string, GuideChoice> = {};
  if (r.choices && typeof r.choices === 'object') {
    for (const [k, v] of Object.entries(r.choices as Record<string, unknown>)) {
      if (FN_IDS.has(k) && (v === 'use' || v === 'skip')) choices[k] = v;
    }
  }
  const done = Array.isArray(r.done) ? [...new Set(r.done.filter((d): d is string => typeof d === 'string' && STEP_IDS.has(d)))] : [];
  const hiddenAt = typeof r.hiddenAt === 'string' && !Number.isNaN(Date.parse(r.hiddenAt)) ? r.hiddenAt : null;
  return { choices, done, hiddenAt };
};

/** Funciones que le aplican al negocio con su plan, y las que están en otros planes */
export const functionsFor = (has: (feature: string) => boolean, usesTables: boolean) => {
  const applies = GUIDE_FUNCTIONS.filter((f) => !f.needsTables || usesTables);
  return {
    available: applies.filter((f) => !f.feature || has(f.feature)),
    locked: applies.filter((f) => f.feature && !has(f.feature)),
  };
};

/** ¿La función está en la guía? Las imprescindibles siempre; las demás si se eligieron */
export const isChosen = (f: GuideFunction, state: SetupGuideState) => !!f.essential || state.choices[f.id] === 'use';

/** Avance: pasos hechos sobre pasos de las funciones elegidas */
export const guideProgress = (
  available: GuideFunction[],
  state: SetupGuideState,
  checks: Record<string, boolean>,
) => {
  const steps = available.filter((f) => isChosen(f, state)).flatMap((f) => f.steps);
  const doneCount = steps.filter((s) => checks[s.id] || state.done.includes(s.id)).length;
  const pendingChoices = available.filter((f) => !f.essential && !state.choices[f.id]).length;
  return { total: steps.length, done: doneCount, pendingChoices, complete: pendingChoices === 0 && doneCount === steps.length };
};
