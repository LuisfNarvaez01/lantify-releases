// ============================================
// DOMAIN - Campañas animadas de la página del negocio
// ============================================
// El negocio arma un anuncio animado con el asistente (Mi página → Campañas) y lo
// publica en la portada de su página o lo descarga como video para redes.
// Aquí solo viven los datos y el tiempo (sin dibujar): el dibujo está en
// web/src/lib/campaignRender.ts y lo usan igual el POS (vista previa y video)
// y la página pública.
//
// Tipo "flavors" (Sabores): cada producto entra sobre su propio color, que inunda
// el cuadro desde abajo; el nombre pasa enorme por detrás y un sello gira.

import { MEDIA_URL_RE } from './media';

export const CAMPAIGN_KINDS = ['flavors'] as const;
/** Cómo sale cada producto: su foto, o una lata dibujada en su color (no necesita fotos) */
export const CAMPAIGN_STYLES = ['photo', 'can'] as const;
export type CampaignStyle = (typeof CAMPAIGN_STYLES)[number];
export type CampaignKind = (typeof CAMPAIGN_KINDS)[number];
export const CAMPAIGN_MIN_FLAVORS = 2;
export const CAMPAIGN_MAX_FLAVORS = 5;
/** Segundos que se queda cada sabor en pantalla */
export const CAMPAIGN_SLOT_SECONDS = 2.6;

export interface CampaignFlavor {
  name: string;
  /** Foto del producto (ideal sin fondo) */
  image: string | null;
  /** Color del sabor (#RRGGBB) */
  color: string;
  /** Producto de la carta al que lleva (para pedirlo desde la página) */
  itemId: string | null;
}

export interface PageCampaign {
  kind: CampaignKind;
  style: CampaignStyle;
  /** Titular corto arriba ("Tres sabores nuevos") */
  headline: string | null;
  /** Texto del sello que gira */
  stamp: string;
  /** Llamado a la acción en la ficha ("Pídelos ya") */
  cta: string | null;
  flavors: CampaignFlavor[];
  /** Se reproduce en la portada de la página publicada */
  onPage: boolean;
}

export const DEFAULT_STAMP = 'FRESCO · NATURAL · HECHO HOY';

const HEX = /^#[0-9a-fA-F]{6}$/;
const text = (v: unknown, max: number) => (typeof v === 'string' && v.trim() ? v.trim().replace(/\s+/g, ' ').slice(0, max) : null);
const imageUrl = (v: unknown) =>
  typeof v === 'string' && (/^https:\/\/[^\s"'<>]{4,500}$/.test(v.trim()) || MEDIA_URL_RE.test(v.trim())) ? v.trim() : null;

/** Campaña válida o null (menos de 2 sabores no alcanza para una campaña) */
export const normalizeCampaign = (raw: unknown): PageCampaign | null => {
  const r = raw && typeof raw === 'object' ? (raw as Record<string, unknown>) : null;
  if (!r) return null;
  const flavors: CampaignFlavor[] = (Array.isArray(r.flavors) ? r.flavors : [])
    .map((f: unknown) => {
      const x = f && typeof f === 'object' ? (f as Record<string, unknown>) : {};
      const name = text(x.name, 40);
      if (!name) return null;
      return {
        name,
        image: imageUrl(x.image),
        color: typeof x.color === 'string' && HEX.test(x.color) ? x.color.toUpperCase() : '#FFB020',
        itemId: typeof x.itemId === 'string' && /^[\w:-]{1,80}$/.test(x.itemId) ? x.itemId : null,
      };
    })
    .filter((f): f is CampaignFlavor => !!f)
    .slice(0, CAMPAIGN_MAX_FLAVORS);
  if (flavors.length < CAMPAIGN_MIN_FLAVORS) return null;
  return {
    kind: (CAMPAIGN_KINDS as readonly string[]).includes(r.kind as string) ? (r.kind as CampaignKind) : 'flavors',
    style: r.style === 'can' ? 'can' : 'photo',
    headline: text(r.headline, 60),
    stamp: (text(r.stamp, 40) || DEFAULT_STAMP).toUpperCase(),
    cta: text(r.cta, 30),
    flavors,
    onPage: r.onPage === true,
  };
};

/**
 * El ejemplo de la casa: "un anuncio cuadrado y contundente para tres sabores nuevos:
 * cada lata entra sobre su propio color, el nombre pasa por detrás y un sello gira".
 * Funciona sin fotos (latas dibujadas) y es la portada de la plantilla Pop.
 */
export const EXAMPLE_CAMPAIGN: PageCampaign = {
  kind: 'flavors',
  style: 'can',
  headline: 'Tres sabores nuevos',
  stamp: 'NUEVO · EDICIÓN LIMITADA',
  cta: 'Pídelos ya',
  flavors: [
    { name: 'Mango Biche', image: null, color: '#FFB020', itemId: null },
    { name: 'Maracuyá', image: null, color: '#F7C948', itemId: null },
    { name: 'Mora Azul', image: null, color: '#5B2A6E', itemId: null },
  ],
  onPage: true,
};

/** Campaña de latas armada con productos de la carta (portada de Pop sin campaña propia) */
export const cansFromItems = (items: { id?: string; name: string }[], colorOf: (name: string, i: number) => string): PageCampaign | null => {
  const picked = items.slice(0, 3);
  if (picked.length < CAMPAIGN_MIN_FLAVORS) return null;
  return {
    ...EXAMPLE_CAMPAIGN,
    headline: null,
    flavors: picked.map((it, i) => ({ name: it.name.slice(0, 40), image: null, color: colorOf(it.name, i), itemId: it.id ?? null })),
  };
};

/** Duración de una vuelta completa (segundos): la del video que se descarga */
export const campaignDuration = (c: Pick<PageCampaign, 'flavors'>) => c.flavors.length * CAMPAIGN_SLOT_SECONDS;

/**
 * En qué sabor va la animación en el segundo `t` y cuánto lleva de su turno.
 * `local` va de 0 a 1 dentro del turno; la vuelta se repite sin corte.
 */
export const campaignSlot = (t: number, count: number) => {
  const n = Math.max(1, count);
  const total = n * CAMPAIGN_SLOT_SECONDS;
  const tt = ((t % total) + total) % total;
  const index = Math.min(n - 1, Math.floor(tt / CAMPAIGN_SLOT_SECONDS));
  return { index, prev: (index - 1 + n) % n, local: (tt - index * CAMPAIGN_SLOT_SECONDS) / CAMPAIGN_SLOT_SECONDS };
};

/** Curva de salida suave (la misma del sistema: frena al llegar) */
export const easeOut = (x: number) => 1 - Math.pow(1 - Math.min(1, Math.max(0, x)), 3);
/** Progreso de un tramo [a, b] del turno, ya suavizado */
export const phase = (local: number, a: number, b: number) => easeOut((local - a) / (b - a));
