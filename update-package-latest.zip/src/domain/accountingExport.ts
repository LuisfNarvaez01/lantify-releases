// ============================================
// DOMAIN - Exportación contable del mes (Fase 4 · Grupo E · beta)
// ============================================
// Lógica pura: arma, a partir de las ventas COBRADAS del mes, el libro de ventas
// (CSV) y un comprobante contable por día con cuentas PUC configurables, en dos
// formatos de importación: Siigo Nube y Alegra. Nunca modifica una venta: solo
// lee lo que ya se cobró. Débitos = créditos por construcción (se cuenta en centavos).
//
// Fuentes consultadas (noviembre 2026) para las columnas:
//  · Siigo Nube · "Subir desde excel – Comprobantes contables":
//    https://siigonube.portaldeclientes.siigo.com/subir-desde-excel-comprobantes-contables/
//    (Configuración › Contabilidad › Importación › Comprobantes contables; tipo de comprobante
//    = solo el código, máx. 3 caracteres; "Consecutivo comprobante" (col. B) se digita y no puede
//    existir ya en Siigo; débito/crédito sin fórmulas y máx. 2 decimales; máx. 500 registros
//    por archivo; el programa pide confirmar qué columna corresponde a cada campo).
//    El nombre de las demás columnas sigue la plantilla de facturas de venta del mismo portal
//    (https://siigonube.portaldeclientes.siigo.com/subir-desde-excel-facturas-de-venta/:
//    "Identificación tercero", "Fecha de elaboración" DD/MM/AAAA, "Código centro/subcentro de costos"…).
//  · Alegra Colombia · "¿Cómo importar comprobantes contables en Alegra?":
//    https://ayuda.alegra.com/col/importar-comprobantes-contables
//    y https://ayuda.alegra.com/int/importar-comprobantes-contables-en-alegra-int
//    (Contabilidad › Comprobante contable › Más acciones › Importar comprobantes; el mismo
//    número en todas las filas de un comprobante; "Débito" y "Crédito" deben sumar igual;
//    al importar se pueden crear contactos, cuentas, numeraciones y tipos de comprobante;
//    máx. 450 kB y 2.000 filas por comprobante). Alegra Colombia importa las FACTURAS de venta
//    solo por XML: por eso las ventas del POS van a Alegra como comprobante contable.
// Ninguno de los dos publica en texto la lista completa de encabezados: BETA, se valida con
// el contador y con la plantilla descargada del programa antes de importar.

export interface AccountingAccounts {
  /** Caja general (efectivo) */
  caja: string;
  /** Bancos (transferencias, Nequi, Daviplata, Bre-B) */
  bancos: string;
  /** Pagos con tarjeta (datáfono) */
  tarjetas: string;
  /** Otros medios (Rappi, plataformas): cuenta por cobrar */
  otros: string;
  /** Ingresos por ventas (4135xx) */
  ingresos: string;
  /** IVA generado */
  iva: string;
  /** Impuesto nacional al consumo */
  impoconsumo: string;
  /** Propinas recibidas para terceros (no son ingreso del negocio) */
  propinas: string;
  /** Siigo: código del tipo de comprobante (máx. 3 caracteres) */
  siigoVoucherType: string;
  /** Siigo: primer consecutivo del mes (no debe existir ya en Siigo) */
  siigoStart: number;
  /** Alegra: tipo de comprobante (se crea al importar si no existe) */
  alegraVoucherType: string;
  /** Alegra: numeración */
  alegraNumbering: string;
  /** Tercero de las ventas: consumidor final */
  thirdPartyId: string;
  /** Centro de costo (opcional) */
  costCenter: string;
}

export const DEFAULT_ACCOUNTS: AccountingAccounts = {
  caja: '110505',
  bancos: '111005',
  tarjetas: '111005',
  otros: '130505',
  ingresos: '413505',
  iva: '240805',
  impoconsumo: '249505',
  propinas: '280505',
  siigoVoucherType: '1',
  siigoStart: 1,
  alegraVoucherType: 'Ventas POS',
  alegraNumbering: 'POS',
  thirdPartyId: '222222222222',
  costCenter: '',
};

const ACCOUNT_KEYS = ['caja', 'bancos', 'tarjetas', 'otros', 'ingresos', 'iva', 'impoconsumo', 'propinas'] as const;

const clean = (v: unknown, max: number) => (typeof v === 'string' ? v.trim().slice(0, max) : '');

export const normalizeAccounts = (raw: unknown): AccountingAccounts => {
  const r = raw && typeof raw === 'object' ? (raw as Record<string, unknown>) : {};
  const out = { ...DEFAULT_ACCOUNTS };
  for (const k of ACCOUNT_KEYS) {
    const v = clean(r[k], 12);
    if (/^\d{4,10}$/.test(v)) out[k] = v;
  }
  const type = clean(r.siigoVoucherType, 3);
  if (/^\d{1,3}$/.test(type)) out.siigoVoucherType = type;
  const start = Math.round(Number(r.siigoStart));
  if (Number.isFinite(start) && start >= 1 && start <= 99_999_999) out.siigoStart = start;
  out.alegraVoucherType = clean(r.alegraVoucherType, 60) || DEFAULT_ACCOUNTS.alegraVoucherType;
  out.alegraNumbering = clean(r.alegraNumbering, 20) || DEFAULT_ACCOUNTS.alegraNumbering;
  const third = clean(r.thirdPartyId, 15).replace(/[^\d]/g, '');
  if (third.length >= 3) out.thirdPartyId = third;
  out.costCenter = clean(r.costCenter, 20);
  return out;
};

// ── Ventas del mes ────────────────────────────────────────────

export interface AccountingSale {
  id: string;
  /** Número corto del recibo (C1-000123); ventas anteriores a la Fase 1 usan saleNumber */
  receiptCode: string | null;
  saleNumber: string;
  /** Fecha local del negocio (YYYY-MM-DD) */
  date: string;
  status: string;
  total: number;
  tip: number;
  discount: number;
  paymentMethod: string;
  payments: { method: string; amount: number }[];
  items: { taxType: string; taxAmount: number; total: number; isCancelled?: boolean }[];
  customerName?: string | null;
  customerNit?: string | null;
  invoiceNumber?: string | null;
}

const cents = (v: unknown) => Math.round((Number(v) || 0) * 100);
const pesos = (c: number) => c / 100;

export const saleNumberOf = (s: Pick<AccountingSale, 'receiptCode' | 'saleNumber'>) => s.receiptCode || s.saleNumber;

/** Qué cuenta recibe cada medio de pago */
export const accountForMethod = (method: string, a: AccountingAccounts): string => {
  if (method === 'CASH') return a.caja;
  if (method === 'CARD') return a.tarjetas;
  if (['TRANSFER', 'NEQUI', 'DAVIPLATA', 'BREB', 'BANCOLOMBIA'].includes(method)) return a.bancos;
  return a.otros;
};

/**
 * Cuánto entró por cada medio, en centavos, sumando EXACTAMENTE total + propina.
 * Si los pagos suman más (vueltas del efectivo), el exceso se descuenta primero del efectivo.
 */
export const splitPayments = (s: AccountingSale): Record<string, number> => {
  const target = cents(s.total) + cents(s.tip);
  const pays = (s.payments || []).filter((p) => cents(p.amount) > 0);
  if (!pays.length) return target > 0 ? { [s.paymentMethod || 'CASH']: target } : {};
  const by: Record<string, number> = {};
  for (const p of pays) by[p.method] = (by[p.method] || 0) + cents(p.amount);
  let excess = Object.values(by).reduce((n, v) => n + v, 0) - target;
  if (excess > 0 && by.CASH) {
    const take = Math.min(excess, by.CASH);
    by.CASH -= take;
    excess -= take;
  }
  if (excess !== 0) {
    // Sobra (sin efectivo) o falta: se ajusta en el medio más grande para cuadrar con la venta
    const biggest = Object.keys(by).sort((x, y) => by[y] - by[x])[0];
    by[biggest] -= excess;
  }
  for (const k of Object.keys(by)) if (by[k] <= 0) delete by[k];
  return by;
};

/** Impuestos incluidos en la venta (los ítems anulados no cuentan) */
export const taxesOf = (s: AccountingSale) => {
  let iva = 0, inc = 0, ivaBase = 0, incBase = 0;
  for (const it of s.items || []) {
    if (it.isCancelled) continue;
    const tax = cents(it.taxAmount);
    if (it.taxType === 'IVA') { iva += tax; ivaBase += cents(it.total) - tax; }
    else if (it.taxType === 'INC') { inc += tax; incBase += cents(it.total) - tax; }
  }
  // El descuento de la venta reduce el impuesto en la misma proporción
  const gross = (s.items || []).filter((i) => !i.isCancelled).reduce((n, i) => n + cents(i.total), 0);
  const total = cents(s.total);
  if (gross > 0 && total < gross) {
    const f = total / gross;
    iva = Math.round(iva * f); inc = Math.round(inc * f); ivaBase = Math.round(ivaBase * f); incBase = Math.round(incBase * f);
  }
  return { iva, inc, ivaBase, incBase };
};

/** Solo ventas cobradas: las anuladas y devueltas no entran a la contabilidad */
export const billable = (sales: AccountingSale[]) => sales.filter((s) => s.status === 'COMPLETED');

// ── Comprobante contable por día ─────────────────────────────

export interface VoucherLine {
  account: string;
  description: string;
  /** En pesos, con máximo 2 decimales */
  debit: number;
  credit: number;
  /** Base gravable (líneas de IVA e impoconsumo) */
  base?: number;
}

export interface Voucher {
  number: number;
  date: string;
  description: string;
  lines: VoucherLine[];
}

export const buildVouchers = (sales: AccountingSale[], accounts: AccountingAccounts): Voucher[] => {
  const byDay = new Map<string, AccountingSale[]>();
  for (const s of billable(sales)) {
    const list = byDay.get(s.date) || [];
    list.push(s);
    byDay.set(s.date, list);
  }
  const days = [...byDay.keys()].sort();
  return days.map((date, i) => {
    const list = byDay.get(date)!;
    const debit = new Map<string, number>();
    let income = 0, iva = 0, inc = 0, ivaBase = 0, incBase = 0, tips = 0;
    for (const s of list) {
      for (const [method, c] of Object.entries(splitPayments(s))) {
        const acc = accountForMethod(method, accounts);
        debit.set(acc, (debit.get(acc) || 0) + c);
      }
      const t = taxesOf(s);
      iva += t.iva; inc += t.inc; ivaBase += t.ivaBase; incBase += t.incBase;
      income += cents(s.total) - t.iva - t.inc;
      tips += cents(s.tip);
    }
    const numbers = list.map(saleNumberOf).sort();
    const range = numbers.length > 1 ? `${numbers[0]} a ${numbers[numbers.length - 1]}` : numbers[0];
    const lines: VoucherLine[] = [];
    const names: Record<string, string> = {
      [accounts.caja]: 'Ventas POS en efectivo', [accounts.bancos]: 'Ventas POS por bancos',
      [accounts.tarjetas]: 'Ventas POS con tarjeta', [accounts.otros]: 'Ventas POS otros medios',
    };
    for (const [acc, c] of [...debit.entries()].sort()) if (c > 0) lines.push({ account: acc, description: names[acc] || 'Ventas POS', debit: pesos(c), credit: 0 });
    if (income) lines.push({ account: accounts.ingresos, description: 'Ingresos por ventas POS', debit: income < 0 ? pesos(-income) : 0, credit: income > 0 ? pesos(income) : 0 });
    if (iva) lines.push({ account: accounts.iva, description: 'IVA generado', debit: 0, credit: pesos(iva), base: pesos(ivaBase) });
    if (inc) lines.push({ account: accounts.impoconsumo, description: 'Impuesto al consumo', debit: 0, credit: pesos(inc), base: pesos(incBase) });
    if (tips) lines.push({ account: accounts.propinas, description: 'Propinas recibidas para terceros', debit: 0, credit: pesos(tips) });
    return { number: accounts.siigoStart + i, date, description: `Ventas POS ${date} · ${list.length} ventas (${range})`, lines };
  });
};

export const voucherTotals = (v: Voucher) => ({
  debit: v.lines.reduce((n, l) => n + cents(l.debit), 0) / 100,
  credit: v.lines.reduce((n, l) => n + cents(l.credit), 0) / 100,
});

export const isBalanced = (v: Voucher) => {
  const t = voucherTotals(v);
  return Math.round(t.debit * 100) === Math.round(t.credit * 100);
};

// ── Formatos de importación ──────────────────────────────────

export type Cell = string | number;
export interface Sheet { name: string; headers: string[]; rows: Cell[][] }

/** DD/MM/AAAA, el formato de fecha de las plantillas de Siigo y Alegra */
export const dmy = (date: string) => {
  const [y, m, d] = date.split('-');
  return `${d}/${m}/${y}`;
};

export const SIIGO_VOUCHER_HEADERS = [
  'Tipo de comprobante',
  'Consecutivo comprobante',
  'Fecha de elaboración',
  'Sigla moneda',
  'Tasa de cambio',
  'Código cuenta contable',
  'Identificación tercero',
  'Sucursal',
  'Código producto',
  'Código de bodega',
  'Acción',
  'Cantidad producto',
  'Prefijo',
  'Consecutivo',
  'No. cuota',
  'Fecha vencimiento',
  'Código impuesto',
  'Código grupo activo fijo',
  'Código activo fijo',
  'Descripción',
  'Código centro/subcentro de costos',
  'Débito',
  'Crédito',
  'Observaciones',
  'Base gravable libro compras/ventas',
  'Base exenta libro compras/ventas',
  'Mes de cierre',
];

/** Siigo Nube admite máximo 500 registros por archivo */
export const SIIGO_MAX_ROWS = 500;

export const siigoSheet = (vouchers: Voucher[], a: AccountingAccounts): Sheet => ({
  name: 'Comprobantes',
  headers: SIIGO_VOUCHER_HEADERS,
  rows: vouchers.flatMap((v) => v.lines.map((l) => {
    const row: Cell[] = SIIGO_VOUCHER_HEADERS.map(() => '');
    row[0] = a.siigoVoucherType;
    row[1] = v.number;
    row[2] = dmy(v.date);
    row[5] = l.account;
    row[6] = a.thirdPartyId;
    row[19] = l.description;
    row[20] = a.costCenter;
    row[21] = l.debit;
    row[22] = l.credit;
    row[23] = v.description;
    if (l.base !== undefined) row[24] = l.base;
    return row;
  })),
});

export const ALEGRA_VOUCHER_HEADERS = [
  'Tipo de comprobante',
  'Numeración',
  'Número',
  'Fecha',
  'Identificación del contacto',
  'Nombre del contacto',
  'Cuenta contable',
  'Descripción',
  'Centro de costo',
  'Débito',
  'Crédito',
  'Observaciones',
];

export const alegraSheet = (vouchers: Voucher[], a: AccountingAccounts): Sheet => ({
  name: 'Plantilla',
  headers: ALEGRA_VOUCHER_HEADERS,
  rows: vouchers.flatMap((v) => v.lines.map((l) => [
    a.alegraVoucherType, a.alegraNumbering, v.number, dmy(v.date), a.thirdPartyId, 'Consumidor final',
    l.account, l.description, a.costCenter, l.debit, l.credit, v.description,
  ])),
});

// ── Libro de ventas (CSV) ────────────────────────────────────

export const SALES_BOOK_HEADERS = [
  'Fecha', 'Número', 'Factura electrónica', 'Cliente', 'NIT/Cédula',
  'Base IVA', 'IVA', 'Base impoconsumo', 'Impoconsumo', 'Base sin impuesto', 'Descuento', 'Total venta', 'Propina', 'Medios de pago',
];

export const salesBookRows = (sales: AccountingSale[]): Cell[][] =>
  billable(sales)
    .slice()
    .sort((x, y) => (x.date === y.date ? saleNumberOf(x).localeCompare(saleNumberOf(y)) : x.date.localeCompare(y.date)))
    .map((s) => {
      const t = taxesOf(s);
      const untaxed = cents(s.total) - t.iva - t.inc - t.ivaBase - t.incBase;
      const methods = Object.entries(splitPayments(s)).map(([m, c]) => `${m} ${pesos(c)}`).join(' + ');
      return [
        s.date, saleNumberOf(s), s.invoiceNumber || '', s.customerName || 'Consumidor final', s.customerNit || '',
        pesos(t.ivaBase), pesos(t.iva), pesos(t.incBase), pesos(t.inc), pesos(untaxed), Number(s.discount) || 0, pesos(cents(s.total)), pesos(cents(s.tip)), methods,
      ];
    });

/** Número con coma decimal (Excel en español de Colombia); sin separador de miles */
const csvNumber = (n: number) => (Number.isInteger(n) ? String(n) : n.toFixed(2).replace('.', ','));

const csvCell = (c: Cell) => {
  const s = typeof c === 'number' ? csvNumber(c) : String(c ?? '');
  return /[";\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};

/** CSV separado por punto y coma, con BOM para que Excel lea las tildes */
export const toCsv = (headers: string[], rows: Cell[][]) =>
  '﻿' + [headers, ...rows].map((r) => r.map(csvCell).join(';')).join('\r\n') + '\r\n';

/** Mes válido (YYYY-MM) */
export const isMonth = (m: unknown): m is string => typeof m === 'string' && /^\d{4}-(0[1-9]|1[0-2])$/.test(m);
