// ============================================
// DOMAIN - La app del celular encuentra la caja sola en la red (Fase 4 · D · 1)
// ============================================
// La caja se anuncia en la red local como _lantify._tcp (mDNS) con TXT t=<negocio>,
// v=<versión>, p=<puerto>. El celular (NsdManager en Android) la busca solo cuando las
// direcciones guardadas fallan, antes de pasar a internet, y nunca usa una caja sin
// comprobar en su /health que es la de SU negocio.
//
// El negocio no viaja en claro por la red: t es una huella corta del código del negocio
// (la misma que devuelve /health), y el celular la calcula con el código de su vinculación.
// Lo comparten el servidor (Node) y la interfaz (WebView): ambos tienen crypto.subtle.

export const SERVICE_TYPE = 'lantify';

const hex = (buf: ArrayBuffer) => Array.from(new Uint8Array(buf), (b) => b.toString(16).padStart(2, '0')).join('');

/** Huella del negocio para el anuncio y /health ('' si la caja no está vinculada) */
export const tenantTag = async (code: string | null | undefined): Promise<string> => {
  const c = String(code || '').trim().toUpperCase();
  if (!c) return '';
  const digest = await globalThis.crypto.subtle.digest('SHA-256', new TextEncoder().encode(`lantify:${c}`));
  return hex(digest).slice(0, 16);
};

export const announceTxt = (p: { tag: string; version: string; port: number }) => ({ t: p.tag, v: p.version.slice(0, 20), p: String(p.port) });

const PRIVATE_V4 = /^(10\.\d{1,3}\.\d{1,3}\.\d{1,3}|192\.168\.\d{1,3}\.\d{1,3}|172\.(1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3})$/;

/**
 * Lo que devuelve el puente de Android (JSON) → direcciones http://ip:puerto utilizables.
 * Solo IPv4 privadas (la caja vive en la red local), sin repetir, como mucho 8.
 */
export const discoveredBases = (raw: unknown): string[] => {
  let list: unknown = raw;
  if (typeof raw === 'string') {
    try { list = JSON.parse(raw); } catch { return []; }
  }
  if (!Array.isArray(list)) return [];
  const out = new Set<string>();
  for (const item of list) {
    if (typeof item !== 'string') continue;
    try {
      const u = new URL(item);
      const port = u.port ? Number(u.port) : 80;
      if (u.protocol !== 'http:' || !PRIVATE_V4.test(u.hostname) || !Number.isInteger(port) || port < 1 || port > 65535) continue;
      out.add(`http://${u.hostname}:${port}`);
    } catch { /* dirección rota: se ignora */ }
    if (out.size >= 8) break;
  }
  return [...out];
};
