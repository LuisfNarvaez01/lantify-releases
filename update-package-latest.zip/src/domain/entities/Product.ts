// ============================================
// DOMAIN ENTITIES - Product
// ============================================

export interface Product {
  id: string;
  name: string;
  description: string | null;
  categoryId: string | null;
  imageUrl: string | null;
  taxType?: string | null;
  taxRate?: number | null;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface ProductVariant {
  id: string;
  productId: string;
  name: string;
  sku: string;
  price: number;
  cost: number | null;
  stock: number;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface Category {
  id: string;
  name: string;
  description: string | null;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

// Factory para crear Product
export const createProduct = (data: Omit<Product, 'id' | 'createdAt' | 'updatedAt'>): Product => {
  return {
    ...data,
    description: data.description ?? null,
    categoryId: data.categoryId ?? null,
    imageUrl: data.imageUrl ?? null,
    id: crypto.randomUUID(),
    createdAt: new Date(),
    updatedAt: new Date(),
  };
};

// Factory para crear ProductVariant
export const createProductVariant = (
  data: Omit<ProductVariant, 'id' | 'createdAt' | 'updatedAt'>
): ProductVariant => {
  return {
    ...data,
    cost: data.cost ?? null,
    id: crypto.randomUUID(),
    createdAt: new Date(),
    updatedAt: new Date(),
  };
};