// ============================================
// DOMAIN ENTITIES - CashSession
// ============================================

export type CashSessionStatus = 'OPEN' | 'CLOSED';

export interface CashSession {
  id: string;
  sessionNumber: string;
  openedAt: Date;
  closedAt: Date | null;
  initialBalance: number;
  income: number;
  expenses: number;
  finalBalance: number | null;
  expectedBalance: number | null;
  difference: number | null;
  status: CashSessionStatus;
  notes: string | null;
  createdAt: Date;
  updatedAt: Date;
}

// Factory para crear CashSession (Apertura de caja)
export const createCashSession = (
  data: Omit<CashSession, 'id' | 'sessionNumber' | 'openedAt' | 'closedAt' | 'finalBalance' | 'expectedBalance' | 'difference' | 'status' | 'createdAt' | 'updatedAt'>
): CashSession => {
  const now = new Date();
  const sessionNumber = `CS-${now.getFullYear()}${(now.getMonth() + 1).toString().padStart(2, '0')}${now.getDate().toString().padStart(2, '0')}-${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`;
  
  return {
    ...data,
    notes: data.notes ?? null,
    id: crypto.randomUUID(),
    sessionNumber,
    openedAt: now,
    closedAt: null,
    finalBalance: null,
    expectedBalance: null,
    difference: null,
    status: 'OPEN',
    createdAt: now,
    updatedAt: now,
  };
};

// Calcular saldo final
export const calculateFinalBalance = (session: CashSession): number => {
  return session.initialBalance + session.income - session.expenses;
};

// Calcular diferencia (para cierre de caja)
export const calculateDifference = (session: CashSession, countedBalance: number): number => {
  const expected = calculateFinalBalance(session);
  return countedBalance - expected;
};