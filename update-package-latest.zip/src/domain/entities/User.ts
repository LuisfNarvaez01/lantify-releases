// ============================================
// DOMAIN ENTITIES - User
// ============================================

export type UserRole = 'ADMIN' | 'CASHIER' | 'WAITER';

export interface User {
  id: string;
  username: string;
  password: string;
  name: string;
  role: UserRole;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface UserLogin {
  username: string;
  password: string;
}

export interface AuthPayload {
  userId: string;
  username: string;
  role: UserRole;
}
