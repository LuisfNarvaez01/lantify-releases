// ============================================
// DOMAIN ENTITIES - Table
// ============================================

export type TableStatus = 'AVAILABLE' | 'ORDERED' | 'PENDING' | 'DIRTY';

export interface Table {
  id: string;
  number: string;
  capacity: number;
  status: TableStatus;
  positionX: number | null;
  positionY: number | null;
  zone?: string | null;
  width?: number | null;
  height?: number | null;
  createdAt: Date;
  updatedAt: Date;
}

// Factory para crear Table
export const createTable = (
  data: Omit<Table, 'id' | 'createdAt' | 'updatedAt' | 'status'>
): Table => {
  return {
    ...data,
    positionX: data.positionX ?? null,
    positionY: data.positionY ?? null,
    id: crypto.randomUUID(),
    status: 'AVAILABLE',
    createdAt: new Date(),
    updatedAt: new Date(),
  };
};

// Transiciones de estado válidas
export const isValidTableStatusTransition = (
  current: TableStatus,
  next: TableStatus
): boolean => {
  const transitions: Record<TableStatus, TableStatus[]> = {
    AVAILABLE: ['ORDERED'],
    ORDERED: ['PENDING', 'AVAILABLE', 'DIRTY'],
    PENDING: ['AVAILABLE', 'ORDERED', 'DIRTY'],
    DIRTY: ['AVAILABLE', 'ORDERED'],
  };
  
  return transitions[current]?.includes(next) ?? false;
};