// ============================================
// DOMAIN - Plano del salón: mesas, elementos y herramientas del editor
// ============================================
// Lo usan el editor (imán, guías, alinear, distribuir, numerar) y el servidor
// (validar lo que se guarda). Funciones puras.

export type TableShape = 'square' | 'round' | 'rect' | 'bar';
export const TABLE_SHAPES: TableShape[] = ['square', 'round', 'rect', 'bar'];

export type ElementKind = 'wall' | 'door' | 'window' | 'bar' | 'kitchen' | 'bathroom' | 'plant' | 'text' | 'zone';
export const ELEMENT_KINDS: ElementKind[] = ['wall', 'door', 'window', 'bar', 'kitchen', 'bathroom', 'plant', 'text', 'zone'];

export const GRID = 8;
export const CANVAS = { width: 1600, height: 1000 };
export const MIN_SIZE = 24;
export const MAX_SIZE = 800;

export interface Box { id: string; x: number; y: number; w: number; h: number; rotation: number }

export const snap = (v: number, grid = GRID) => Math.round(v / grid) * grid;
export const clamp = (v: number, min: number, max: number) => Math.min(max, Math.max(min, v));
export const normRotation = (r: number) => ((Math.round(r) % 360) + 360) % 360;

/** Tamaño por defecto de cada forma de mesa */
export const DEFAULT_TABLE_SIZE: Record<TableShape, { w: number; h: number }> = {
  square: { w: 96, h: 96 }, round: { w: 96, h: 96 }, rect: { w: 160, h: 96 }, bar: { w: 64, h: 64 },
};
export const DEFAULT_ELEMENT_SIZE: Record<ElementKind, { w: number; h: number }> = {
  wall: { w: 240, h: 16 }, door: { w: 80, h: 16 }, window: { w: 120, h: 12 }, bar: { w: 280, h: 64 }, kitchen: { w: 240, h: 160 },
  bathroom: { w: 120, h: 120 }, plant: { w: 40, h: 40 }, text: { w: 160, h: 40 }, zone: { w: 400, h: 280 },
};

export interface Guide { axis: 'x' | 'y'; at: number }

/**
 * Guías de alineación: si un borde o el centro del grupo que se mueve queda a menos
 * de `tol` px de un borde o centro de otro elemento, se pega a él y se dibuja la guía.
 */
export const alignGuides = (moving: Box, others: Box[], tol = 6): { dx: number; dy: number; guides: Guide[] } => {
  const xs = (b: Box) => [b.x, b.x + b.w / 2, b.x + b.w];
  const ys = (b: Box) => [b.y, b.y + b.h / 2, b.y + b.h];
  let bestX: { d: number; at: number } | null = null;
  let bestY: { d: number; at: number } | null = null;
  for (const o of others) {
    for (const a of xs(moving)) for (const b of xs(o)) { const d = b - a; if (Math.abs(d) <= tol && (!bestX || Math.abs(d) < Math.abs(bestX.d))) bestX = { d, at: b }; }
    for (const a of ys(moving)) for (const b of ys(o)) { const d = b - a; if (Math.abs(d) <= tol && (!bestY || Math.abs(d) < Math.abs(bestY.d))) bestY = { d, at: b }; }
  }
  const guides: Guide[] = [];
  if (bestX) guides.push({ axis: 'x', at: bestX.at });
  if (bestY) guides.push({ axis: 'y', at: bestY.at });
  return { dx: bestX?.d ?? 0, dy: bestY?.d ?? 0, guides };
};

/** Caja que encierra varios elementos */
export const boundsOf = (items: Box[]): Box => {
  const x = Math.min(...items.map((i) => i.x));
  const y = Math.min(...items.map((i) => i.y));
  return { id: 'group', x, y, w: Math.max(...items.map((i) => i.x + i.w)) - x, h: Math.max(...items.map((i) => i.y + i.h)) - y, rotation: 0 };
};

export type AlignMode = 'left' | 'hcenter' | 'right' | 'top' | 'vcenter' | 'bottom';

export const align = (items: Box[], mode: AlignMode): Box[] => {
  if (items.length < 2) return items;
  const b = boundsOf(items);
  return items.map((i) => ({
    ...i,
    x: mode === 'left' ? b.x : mode === 'right' ? b.x + b.w - i.w : mode === 'hcenter' ? Math.round(b.x + b.w / 2 - i.w / 2) : i.x,
    y: mode === 'top' ? b.y : mode === 'bottom' ? b.y + b.h - i.h : mode === 'vcenter' ? Math.round(b.y + b.h / 2 - i.h / 2) : i.y,
  }));
};

/** Reparte con el mismo espacio entre ellos (3 o más) */
export const distribute = (items: Box[], axis: 'x' | 'y'): Box[] => {
  if (items.length < 3) return items;
  const key = axis === 'x' ? 'x' : 'y';
  const size = axis === 'x' ? 'w' : 'h';
  const sorted = [...items].sort((a, b) => a[key] - b[key]);
  const start = sorted[0][key];
  const end = sorted[sorted.length - 1][key] + sorted[sorted.length - 1][size];
  const total = sorted.reduce((n, i) => n + i[size], 0);
  const gap = (end - start - total) / (sorted.length - 1);
  let pos = start;
  const placed = new Map<string, number>();
  for (const i of sorted) { placed.set(i.id, Math.round(pos)); pos += i[size] + gap; }
  return items.map((i) => ({ ...i, [key]: placed.get(i.id)! }));
};

/** Siguiente número libre de mesa (los números no numéricos se ignoran) */
export const nextTableNumber = (existing: string[]) => {
  const nums = existing.map((n) => Number(n)).filter((n) => Number.isInteger(n) && n > 0);
  for (let i = 1; i <= nums.length + 1; i++) if (!nums.includes(i)) return String(i);
  return String(nums.length + 1);
};

/** Mover sin salir del lienzo */
export const keepInside = (b: Box): Box => ({ ...b, x: clamp(b.x, 0, CANVAS.width - b.w), y: clamp(b.y, 0, CANVAS.height - b.h) });

// ── Lo que guarda el servidor ──

export interface LayoutTable { id?: string; number: string; capacity: number; zone: string | null; positionX: number; positionY: number; width: number; height: number; shape: TableShape; rotation: number; reservable?: boolean }
export interface LayoutElement { kind: ElementKind; zone: string | null; x: number; y: number; w: number; h: number; rotation: number; label: string | null }

const int = (v: unknown, d: number) => { const n = Math.round(Number(v)); return Number.isFinite(n) ? n : d; };
const zoneOf = (v: unknown) => (typeof v === 'string' && v.trim() ? v.trim().slice(0, 40) : null);

export const cleanLayoutTable = (r: any): LayoutTable | null => {
  const number = typeof r?.number === 'string' || typeof r?.number === 'number' ? String(r.number).trim().slice(0, 12) : '';
  if (!number) return null;
  const shape: TableShape = TABLE_SHAPES.includes(r?.shape) ? r.shape : 'square';
  const def = DEFAULT_TABLE_SIZE[shape];
  const w = clamp(int(r?.width, def.w), MIN_SIZE, MAX_SIZE);
  const h = clamp(int(r?.height, def.h), MIN_SIZE, MAX_SIZE);
  return {
    id: typeof r?.id === 'string' && r.id ? r.id : undefined,
    number, capacity: clamp(int(r?.capacity, 4), 1, 99), zone: zoneOf(r?.zone),
    positionX: clamp(int(r?.positionX, 0), 0, CANVAS.width - w), positionY: clamp(int(r?.positionY, 0), 0, CANVAS.height - h),
    width: w, height: h, shape, rotation: normRotation(int(r?.rotation, 0)), reservable: r?.reservable === true,
  };
};

export const cleanLayoutElement = (r: any): LayoutElement | null => {
  if (!ELEMENT_KINDS.includes(r?.kind)) return null;
  const def = DEFAULT_ELEMENT_SIZE[r.kind as ElementKind];
  const w = clamp(int(r?.w, def.w), 4, CANVAS.width);
  const h = clamp(int(r?.h, def.h), 4, CANVAS.height);
  return {
    kind: r.kind, zone: zoneOf(r?.zone), w, h,
    x: clamp(int(r?.x, 0), 0, CANVAS.width - w), y: clamp(int(r?.y, 0), 0, CANVAS.height - h),
    rotation: normRotation(int(r?.rotation, 0)), label: typeof r?.label === 'string' && r.label.trim() ? r.label.trim().slice(0, 40) : null,
  };
};
