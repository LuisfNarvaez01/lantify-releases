// ============================================
// DOMAIN - Página del negocio (carta, reservas, registro y juegos)
// ============================================
// Lógica pura que comparten el POS (lo que el ADMIN configura y publica) y Lantify
// Cloud (lo que ve el cliente en lantifypos.dpdns.org/m/<slug>). Todo lo que llega
// de un formulario o de la red se sanea aquí: nunca rompe la página.

import { PageTheme, normalizeTheme } from './pageTheme';
export * from './pageTheme';

export interface PageSections {
  /** La carta con precios (todos los planes) */
  menu: boolean;
  /** Reservas en línea (Premium; además se activan en Reservas → Configurar) */
  booking: boolean;
  /** Registro de clientes con su autorización (Premium) */
  signup: boolean;
  /** Juego con premios para clientes registrados (Premium) */
  games: boolean;
  /** Pedidos en línea a domicilio o para recoger (Premium · webstore) */
  orders: boolean;
}

export interface PageProfile {
  tagline: string | null;
  address: string | null;
  city: string | null;
  hours: string | null;
  whatsapp: string | null;
  instagram: string | null;
}

export interface MenuItem {
  /** Presentación (variante) del POS: con ella se puede pedir en línea */
  id?: string;
  name: string;
  price: number;
  description: string | null;
  /** Foto del producto (solo direcciones https) */
  image?: string | null;
  /** La foto es ilustrativa, hecha con IA (solo en la página pública) */
  aiImage?: boolean;
  /** Entre los más pedidos del negocio */
  top?: boolean;
}

export interface MenuCategory {
  name: string;
  items: MenuItem[];
}

export interface Prize {
  id: string;
  /** Lo que ve el cliente: "Limonada de coco gratis", "10 % en tu cuenta" */
  label: string;
  kind: 'PERCENT' | 'AMOUNT';
  value: number;
  minPurchase: number | null;
  /** Peso relativo en el sorteo (frente a "sin premio") */
  weight: number;
  dailyLimit: number | null;
  totalLimit: number | null;
  /** Días que dura el cupón ganado */
  validDays: number;
}

export interface TriviaQuestion {
  q: string;
  options: string[];
  /** Índice de la opción correcta (nunca se envía a la página) */
  answer: number;
}

export type GameType = 'wheel' | 'scratch' | 'trivia';

export interface GamesConfig {
  type: GameType;
  title: string;
  /** Peso de "sigue intentando" frente a los premios */
  noPrizeWeight: number;
  /** Casillas de "sigue intentando" en la ruleta (solo se ven; la probabilidad la da el peso) */
  tryAgainSlots: number;
  prizes: Prize[];
  trivia: TriviaQuestion[];
}

export interface PageLegal {
  /** Responsable del tratamiento de los datos (el negocio) */
  owner: string | null;
  nit: string | null;
  email: string | null;
}

export type OrderPayment = 'CASH' | 'NEQUI' | 'DAVIPLATA' | 'CARD' | 'TRANSFER';
export const ORDER_PAYMENTS: OrderPayment[] = ['CASH', 'NEQUI', 'DAVIPLATA', 'CARD', 'TRANSFER'];

export interface OrderingConfig {
  delivery: boolean;
  pickup: boolean;
  /** Valor del domicilio (se suma al pedido; 0 = gratis) */
  deliveryFee: number;
  /** Pedido mínimo sin el domicilio (0 = sin mínimo) */
  minOrder: number;
  payments: OrderPayment[];
  /** "30 a 45 min" */
  eta: string | null;
  /** Barrios o zona de cobertura, horario de pedidos, etc. */
  notice: string | null;
}

export interface LoyaltyConfig {
  enabled: boolean;
  minSpendPerStamp: number;
  spendPerGamePlay: number;
  stampsRequired: number;
  rewardText: string;
}

export const DEFAULT_LOYALTY: LoyaltyConfig = {
  enabled: true,
  minSpendPerStamp: 20000,
  spendPerGamePlay: 30000,
  stampsRequired: 10,
  rewardText: '1 Plato / Café / Postre Gratis en Caja',
};

export interface SocialConfig {
  googleReviewUrl: string | null;
  instagram: string | null;
  tiktok: string | null;
  facebook: string | null;
  whatsapp: string | null;
}

export const DEFAULT_SOCIAL: SocialConfig = {
  googleReviewUrl: null,
  instagram: null,
  tiktok: null,
  facebook: null,
  whatsapp: null,
};

export interface PageConfig {
  sections: PageSections;
  profile: PageProfile;
  games: GamesConfig;
  legal: PageLegal;
  ordering: OrderingConfig;
  theme: PageTheme;
  loyalty: LoyaltyConfig;
  social: SocialConfig;
  hiddenProductIds: string[];
}

const text = (v: unknown, max: number) => (typeof v === 'string' && v.trim() ? v.trim().slice(0, max) : null);
const num = (v: unknown, min: number, max: number, fallback: number) => {
  const n = Number(v);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
};
const optInt = (v: unknown, min: number, max: number) => {
  if (v === null || v === undefined || v === '') return null;
  const n = Math.round(Number(v));
  return Number.isFinite(n) && n >= min ? Math.min(max, n) : null;
};
const obj = (v: unknown) => (v && typeof v === 'object' ? (v as Record<string, any>) : {});

export const DEFAULT_GAMES: GamesConfig = {
  type: 'wheel',
  title: 'Juega y gana premios',
  noPrizeWeight: 70,
  tryAgainSlots: 3,
  prizes: [],
  trivia: [],
};

export const normalizeSections = (raw: unknown): PageSections => {
  const r = obj(raw);
  return { menu: r.menu !== false, booking: !!r.booking, signup: !!r.signup, games: !!r.games, orders: !!r.orders };
};

export const normalizeProfile = (raw: unknown): PageProfile => {
  const r = obj(raw);
  return {
    tagline: text(r.tagline, 140),
    address: text(r.address, 160),
    city: text(r.city, 60),
    hours: text(r.hours, 200),
    whatsapp: text(r.whatsapp, 20)?.replace(/[^\d+]/g, '') || null,
    instagram: text(r.instagram, 40)?.replace(/^@/, '').replace(/[^\w.]/g, '') || null,
  };
};

export const normalizeLegal = (raw: unknown): PageLegal => {
  const r = obj(raw);
  const email = text(r.email, 120);
  return { owner: text(r.owner, 160), nit: text(r.nit, 20), email: email && /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email) ? email : null };
};

export const normalizeMenu = (raw: unknown): MenuCategory[] =>
  (Array.isArray(raw) ? raw : [])
    .slice(0, 40)
    .map((c: any) => ({
      name: text(c?.name, 60) || 'Carta',
      items: (Array.isArray(c?.items) ? c.items : [])
        .slice(0, 150)
        .map((i: any) => {
          const item: MenuItem = { name: text(i?.name, 100) || '', price: Math.max(0, Math.round(Number(i?.price) || 0)), description: text(i?.description, 240) };
          const id = text(i?.id, 64);
          const image = text(i?.image, 500);
          if (id) item.id = id;
          if (image && /^https:\/\/[^\s"'<>]+$/.test(image)) item.image = image;
          if (i?.top === true) item.top = true;
          return item;
        })
        .filter((i: MenuItem) => i.name && i.price > 0),
    }))
    .filter((c) => c.items.length);

export const normalizeGames = (raw: unknown): GamesConfig => {
  const r = obj(raw);
  const prizes: Prize[] = (Array.isArray(r.prizes) ? r.prizes : [])
    .slice(0, 12)
    .map((p: any, i: number) => {
      const kind = p?.kind === 'AMOUNT' ? 'AMOUNT' : 'PERCENT';
      return {
        id: (text(p?.id, 40) || `premio-${i + 1}`).replace(/[^\w-]/g, ''),
        label: text(p?.label, 80) || '',
        kind,
        value: kind === 'PERCENT' ? Math.round(num(p?.value, 1, 100, 10)) : Math.round(num(p?.value, 100, 1_000_000, 5000)),
        minPurchase: optInt(p?.minPurchase, 1, 10_000_000),
        weight: Math.round(num(p?.weight, 0, 1000, 10)),
        dailyLimit: optInt(p?.dailyLimit, 1, 10_000),
        totalLimit: optInt(p?.totalLimit, 1, 1_000_000),
        validDays: Math.round(num(p?.validDays, 1, 90, 7)),
      } as Prize;
    })
    .filter((p: Prize) => p.label && p.weight > 0);
  const trivia: TriviaQuestion[] = (Array.isArray(r.trivia) ? r.trivia : [])
    .slice(0, 10)
    .map((t: any) => {
      const options = (Array.isArray(t?.options) ? t.options : []).map((o: unknown) => text(o, 80)).filter(Boolean).slice(0, 4) as string[];
      return { q: text(t?.q, 160) || '', options, answer: Math.round(num(t?.answer, 0, Math.max(0, options.length - 1), 0)) };
    })
    .filter((t: TriviaQuestion) => t.q && t.options.length >= 2);
  return {
    type: r.type === 'trivia' && trivia.length ? 'trivia' : r.type === 'scratch' ? 'scratch' : 'wheel',
    title: text(r.title, 60) || DEFAULT_GAMES.title,
    noPrizeWeight: Math.round(num(r.noPrizeWeight, 0, 1000, DEFAULT_GAMES.noPrizeWeight)),
    tryAgainSlots: Math.round(num(r.tryAgainSlots, 0, 12, DEFAULT_GAMES.tryAgainSlots)),
    prizes,
    trivia,
  };
};

export const normalizeOrdering = (raw: unknown): OrderingConfig => {
  const r = obj(raw);
  const payments = (Array.isArray(r.payments) ? r.payments : []).filter((p: unknown): p is OrderPayment => ORDER_PAYMENTS.includes(p as OrderPayment));
  return {
    delivery: r.delivery !== false,
    pickup: r.pickup !== false,
    deliveryFee: Math.round(num(r.deliveryFee, 0, 200_000, 0)),
    minOrder: Math.round(num(r.minOrder, 0, 2_000_000, 0)),
    payments: payments.length ? ([...new Set(payments)] as OrderPayment[]) : ['CASH', 'NEQUI'],
    eta: text(r.eta, 40),
    notice: text(r.notice, 240),
  };
};

export const normalizeLoyalty = (raw: unknown): LoyaltyConfig => {
  const r = obj(raw);
  return {
    enabled: r.enabled !== false,
    minSpendPerStamp: Math.round(num(r.minSpendPerStamp, 1000, 10_000_000, DEFAULT_LOYALTY.minSpendPerStamp)),
    spendPerGamePlay: Math.round(num(r.spendPerGamePlay, 1000, 10_000_000, DEFAULT_LOYALTY.spendPerGamePlay)),
    stampsRequired: Math.round(num(r.stampsRequired, 3, 50, DEFAULT_LOYALTY.stampsRequired)),
    rewardText: text(r.rewardText, 120) || DEFAULT_LOYALTY.rewardText,
  };
};

export const normalizeSocial = (raw: unknown): SocialConfig => {
  const r = obj(raw);
  const cleanHandle = (h: unknown) => text(h, 40)?.replace(/^@/, '').replace(/[^\w.]/g, '') || null;
  const cleanUrl = (u: unknown) => {
    const t = text(u, 250);
    return t && /^https?:\/\/[^\s"'<>]+$/.test(t) ? t : null;
  };
  const phone = text(r.whatsapp, 20)?.replace(/[^\d+]/g, '') || null;

  return {
    googleReviewUrl: cleanUrl(r.googleReviewUrl),
    instagram: cleanHandle(r.instagram),
    tiktok: cleanHandle(r.tiktok),
    facebook: cleanUrl(r.facebook),
    whatsapp: phone,
  };
};

export const normalizePageConfig = (raw: unknown): PageConfig => {
  const r = obj(raw);
  return {
    sections: normalizeSections(r.sections),
    profile: normalizeProfile(r.profile),
    games: normalizeGames(r.games),
    legal: normalizeLegal(r.legal),
    ordering: normalizeOrdering(r.ordering),
    theme: normalizeTheme(r.theme),
    loyalty: normalizeLoyalty(r.loyalty),
    social: normalizeSocial(r.social),
    hiddenProductIds: Array.isArray(r.hiddenProductIds) ? r.hiddenProductIds.filter((x): x is string => typeof x === 'string') : [],
  };
};

export const DEFAULT_PAGE_CONFIG: PageConfig = normalizePageConfig({});

/**
 * Lo que la página pública puede saber del juego: sin pesos, cupos ni respuestas,
 * y tampoco qué premios hay (eso lo maneja el negocio). La ruleta solo sabe
 * cuántas casillas de premio dibujar; el premio se conoce al ganarlo.
 */
export const publicGames = (g: GamesConfig) => ({
  type: g.type,
  title: g.title,
  // Sin "sigue intentando" posible, la ruleta no lo muestra
  tryAgainSlots: g.noPrizeWeight > 0 ? g.tryAgainSlots : 0,
  prizeSlots: Math.min(6, g.prizes.length),
  trivia: g.trivia.map((t) => ({ q: t.q, options: t.options })),
});

/**
 * Sorteo en el servidor. `counts` dice cuántas veces salió cada premio hoy y en
 * total: un premio agotado sale del sorteo. `random` entre 0 y 1.
 */
export const drawPrize = (g: GamesConfig, counts: Record<string, { today: number; total: number }>, random: number): Prize | null => {
  const open = g.prizes.filter((p) => {
    const c = counts[p.id] || { today: 0, total: 0 };
    return (p.dailyLimit === null || c.today < p.dailyLimit) && (p.totalLimit === null || c.total < p.totalLimit);
  });
  const total = g.noPrizeWeight + open.reduce((n, p) => n + p.weight, 0);
  if (total <= 0 || !open.length) return null;
  let pick = Math.min(0.999999, Math.max(0, random)) * total;
  if (pick < g.noPrizeWeight) return null;
  pick -= g.noPrizeWeight;
  for (const p of open) {
    if (pick < p.weight) return p;
    pick -= p.weight;
  }
  return open[open.length - 1];
};

/** ¿Respondió bien toda la trivia? */
export const triviaPassed = (g: GamesConfig, answers: unknown) =>
  Array.isArray(answers) && g.trivia.length > 0 && g.trivia.every((t, i) => Number(answers[i]) === t.answer);

/** Código del cupón ganado (sin letras que se confunden) */
export const prizeCode = (random: () => number = Math.random) => {
  const alphabet = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  let code = 'PREMIO';
  for (let i = 0; i < 6; i++) code += alphabet[Math.floor(random() * alphabet.length)];
  return code;
};

/** Celular solo con dígitos; en Colombia, "+57 300…" y "300…" son el mismo número */
export const normalizePhone = (v: unknown) => {
  const d = typeof v === 'string' ? v.replace(/\D/g, '') : '';
  return d.length === 12 && d.startsWith('57') ? d.slice(2) : d;
};

// ── Pedidos en línea ─────────────────────────────────────────

export const ORDER_STATUSES = ['PENDING', 'ACCEPTED', 'READY', 'COMPLETED', 'REJECTED', 'CANCELLED'] as const;
export type OrderStatus = (typeof ORDER_STATUSES)[number];
export const MAX_ORDER_LINES = 40;
export const MAX_LINE_QTY = 50;

export interface OrderLine {
  id: string;
  name: string;
  price: number;
  qty: number;
  note: string | null;
}

export type OrderPlan =
  | { ok: true; kind: 'DELIVERY' | 'PICKUP'; payment: OrderPayment; lines: OrderLine[]; subtotal: number; deliveryFee: number; total: number }
  | { ok: false; code: string };

/**
 * Valida un pedido contra la carta PUBLICADA: los precios y nombres salen de la
 * carta, nunca de lo que envía el navegador.
 */
export const planOrder = (menu: MenuCategory[], ordering: OrderingConfig, input: { kind?: unknown; payment?: unknown; items?: unknown }): OrderPlan => {
  const kind = input.kind === 'PICKUP' ? 'PICKUP' : input.kind === 'DELIVERY' ? 'DELIVERY' : null;
  if (!kind || (kind === 'DELIVERY' && !ordering.delivery) || (kind === 'PICKUP' && !ordering.pickup)) return { ok: false, code: 'ORDER_BAD_KIND' };
  const payment = ordering.payments.includes(input.payment as OrderPayment) ? (input.payment as OrderPayment) : null;
  if (!payment) return { ok: false, code: 'ORDER_BAD_PAYMENT' };
  const byId = new Map<string, MenuItem>();
  for (const c of menu) for (const i of c.items) if (i.id) byId.set(i.id, i);
  const raw = Array.isArray(input.items) ? input.items : [];
  if (!raw.length) return { ok: false, code: 'ORDER_EMPTY' };
  if (raw.length > MAX_ORDER_LINES) return { ok: false, code: 'ORDER_TOO_BIG' };
  const lines: OrderLine[] = [];
  for (const it of raw as any[]) {
    const item = byId.get(String(it?.id ?? ''));
    const qty = Math.round(Number(it?.qty));
    if (!item) return { ok: false, code: 'ORDER_ITEM_UNAVAILABLE' };
    if (!Number.isFinite(qty) || qty < 1 || qty > MAX_LINE_QTY) return { ok: false, code: 'ORDER_BAD_QTY' };
    const note = text(it?.note, 120);
    const same = lines.find((l) => l.id === item.id && l.note === note);
    if (same) same.qty = Math.min(MAX_LINE_QTY, same.qty + qty);
    else lines.push({ id: item.id!, name: item.name, price: item.price, qty, note });
  }
  const subtotal = lines.reduce((n, l) => n + l.price * l.qty, 0);
  if (ordering.minOrder > 0 && subtotal < ordering.minOrder) return { ok: false, code: 'ORDER_BELOW_MINIMUM' };
  const deliveryFee = kind === 'DELIVERY' ? ordering.deliveryFee : 0;
  return { ok: true, kind, payment, lines, subtotal, deliveryFee, total: subtotal + deliveryFee };
};

/** Código corto del pedido para decirlo por teléfono ("W7K2P") */
export const orderCode = (random: () => number = Math.random) => {
  const alphabet = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  let code = 'W';
  for (let i = 0; i < 5; i++) code += alphabet[Math.floor(random() * alphabet.length)];
  return code;
};
