// ============================================
// DOMAIN - Imágenes del negocio (fotos de productos, logo, portada)
// ============================================
// Se guardan en el equipo del negocio con el nombre de su huella (sha-256): la
// misma foto subida dos veces es un solo archivo, y la nube la recibe una sola vez.
// Lo comparten el programa, la interfaz y Lantify Cloud.

/** Dirección local de una imagen subida: /api/media/<32 hex>.<ext> */
export const MEDIA_URL_RE = /^\/api\/media\/([0-9a-f]{32})\.(webp|jpg|png)$/;
export const MEDIA_NAME_RE = /^([0-9a-f]{32})\.(webp|jpg|png)$/;

export const MEDIA_MIME: Record<string, string> = { webp: 'image/webp', jpg: 'image/jpeg', png: 'image/png' };

/** Tamaño máximo de una imagen ya reducida en el navegador */
export const MEDIA_MAX_BYTES = 1_500_000;

export const isMediaUrl = (v: unknown): v is string => typeof v === 'string' && MEDIA_URL_RE.test(v);

/** Una foto de producto o logo válido: subida al equipo o una dirección https */
export const isImageRef = (v: unknown): v is string =>
  isMediaUrl(v) || (typeof v === 'string' && /^https:\/\/[^\s"'<>]{4,500}$/.test(v));

/** Cómo se debe subir cada imagen: lo usan el recorte y la guía de formato */
export type ImageKind = 'product' | 'logo' | 'cover';

export const IMAGE_SPECS: Record<ImageKind, { aspect: number; width: number; height: number; minSide: number; format: 'webp' | 'png' }> = {
  // Cuadrada: la carta, la caja y la página la muestran recortada al centro
  product: { aspect: 1, width: 800, height: 800, minSide: 400, format: 'webp' },
  // Cuadrado con fondo transparente si lo tiene (PNG para no perder bordes)
  logo: { aspect: 1, width: 512, height: 512, minSide: 200, format: 'png' },
  // Banda ancha de la portada de la página
  cover: { aspect: 16 / 9, width: 1600, height: 900, minSide: 900, format: 'webp' },
};
