// ============================================
// DOMAIN REPOSITORIES - Sale Repository Interface
// ============================================

import { SaleStatus } from '../entities';

// Usar tipos genéricos para compatibilidad con Prisma
export interface ISaleRepository {
  // Sale
  create(data: any): Promise<any>;
  getById(id: string): Promise<any | null>;
  getAll(): Promise<any[]>;
  getByDateRange(startDate: Date, endDate: Date): Promise<any[]>;
  getByTable(tableId: string): Promise<any[]>;
  getByCashSession(cashSessionId: string): Promise<any[]>;
  getByStatus(status: SaleStatus): Promise<any[]>;
  update(id: string, data: any): Promise<any>;
  updateStatus(id: string, status: SaleStatus): Promise<any>;
  delete(id: string): Promise<void>;

  // SaleItem
  createItem(data: any): Promise<any>;
  getItemsBySale(saleId: string): Promise<any[]>;
  deleteItem(id: string): Promise<void>;

  // Aggregations
  getTotalSalesByDate(date: Date): Promise<number>;
  getDailySalesSummary(date: Date): Promise<{ count: number; total: number }>;

  // Paginación por mes — para historial rápido
  getAvailableMonths(): Promise<{ year: number; month: number; label: string; count: number; totalRevenue: number }[]>;
  getByMonth(
    year: number,
    month: number,
    page?: number,
    limit?: number,
    filters?: { cashSessionId?: string; status?: string }
  ): Promise<{
    data: any[];
    total: number;
    page: number;
    totalPages: number;
    stats: {
      totalRevenue: number;
      completedCount: number;
      cancelledCount: number;
      totalItems: number;
      avgTicket: number;
      /** Propinas del período: aparte, no hacen parte de los ingresos */
      totalTips: number;
      paymentBreakdown: {
        CASH: number;
        CARD: number;
        TRANSFER: number;
        MIXED: number;
      };
    };
  }>;
}