// ============================================
// DOMAIN - Enlace para vincular un celular (QR de la caja)
// ============================================
// El QR abre la app de Lantify (o la versión web en el iPhone) con todo lo que el
// celular necesita: el negocio, su identidad y secreto, las direcciones locales de la
// caja y la nube. Va en el fragmento (#) para que nunca llegue a ningún servidor.

export const DEFAULT_APP_URL = 'https://lantifypos.com/app/';

export interface Pairing {
  v: 1;
  /** Código del negocio en Lantify Cloud */
  t: string;
  /** Id y secreto del celular */
  d: string;
  s: string;
  /** Direcciones de la caja en la red local (http://ip:puerto) */
  l: string[];
  /** API de Lantify Cloud (relevo) */
  r: string;
  /** Nombre del negocio (para mostrar) */
  n?: string | null;
}

const b64url = (text: string) => Buffer.from(text, 'utf8').toString('base64url');

export const buildPairingLink = (p: { tenant: string; deviceId: string; secret: string; lan: string[]; cloud: string; business: string | null; appUrl?: string }) => {
  const payload: Pairing = { v: 1, t: p.tenant, d: p.deviceId, s: p.secret, l: p.lan.slice(0, 4), r: p.cloud, n: p.business };
  const base = (p.appUrl || DEFAULT_APP_URL).replace(/#.*$/, '');
  return `${base}#pair=${b64url(JSON.stringify(payload))}`;
};

/** Lee el enlace (lo usa el celular; también sirve para pruebas) */
export const parsePairingLink = (link: string): Pairing | null => {
  const m = /#pair=([A-Za-z0-9_-]+)/.exec(link);
  if (!m) return null;
  try {
    const raw = typeof atob === 'function'
      ? decodeURIComponent(escape(atob(m[1].replace(/-/g, '+').replace(/_/g, '/'))))
      : Buffer.from(m[1], 'base64url').toString('utf8');
    const p = JSON.parse(raw);
    if (p?.v !== 1 || typeof p.t !== 'string' || typeof p.d !== 'string' || typeof p.s !== 'string' || typeof p.r !== 'string' || !Array.isArray(p.l)) return null;
    return { v: 1, t: p.t, d: p.d, s: p.s, l: p.l.filter((u: unknown) => typeof u === 'string'), r: p.r, n: p.n ?? null };
  } catch {
    return null;
  }
};
