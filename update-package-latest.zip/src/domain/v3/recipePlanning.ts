// ============================================
// DOMAIN - Planeación con recetas (Fase 4 · mejoras)
// ============================================
// Con las recetas y las existencias de ingredientes:
//   · cuántas porciones de cada producto alcanzan y qué ingrediente se acaba primero;
//   · la calculadora: qué ingredientes (y cuánto cuestan) se necesitan para X productos
//     y qué falta comprar;
//   · lectura de listas pegadas (Excel, WhatsApp) para crear ingredientes de una vez
//     y de recetas escritas como "200 g carne, 1 pan, 30 g queso".
// Funciones puras: las usan la caja y la pantalla de inventario.

export type BaseUnit = 'g' | 'ml' | 'und';

export interface PlanIngredient { id: string; name: string; unit: BaseUnit; stock: number; avgCost: number; minStock?: number | null; supplierId?: string | null }
export interface PlanProduct { id: string; name: string; recipe: { ingredientId: string; quantity: number }[] }

export interface Yield { productId: string; name: string; canMake: number; limiting: { ingredientId: string; name: string } | null; cost: number }

/** Porciones que alcanzan con lo que hay; el ingrediente que se acaba primero */
export const yields = (products: PlanProduct[], ingredients: PlanIngredient[]): Yield[] => {
  const byId = new Map(ingredients.map((i) => [i.id, i]));
  return products.filter((p) => p.recipe.length).map((p) => {
    let canMake = Infinity;
    let limiting: Yield['limiting'] = null;
    let cost = 0;
    for (const r of p.recipe) {
      const ing = byId.get(r.ingredientId);
      if (!ing || r.quantity <= 0) continue;
      cost += r.quantity * ing.avgCost;
      const n = Math.floor(Math.max(0, ing.stock) / r.quantity + 1e-9);
      if (n < canMake) { canMake = n; limiting = { ingredientId: ing.id, name: ing.name }; }
    }
    return { productId: p.id, name: p.name, canMake: Number.isFinite(canMake) ? canMake : 0, limiting, cost: Math.round(cost) };
  });
};

export interface Need { ingredientId: string; name: string; unit: BaseUnit; need: number; have: number; short: number; cost: number; supplierId: string | null }

/** Calculadora: qué se necesita para producir estas cantidades y qué falta */
export const requirements = (plan: { productId: string; qty: number }[], products: PlanProduct[], ingredients: PlanIngredient[]): { needs: Need[]; cost: number; missingRecipe: string[] } => {
  const byProduct = new Map(products.map((p) => [p.id, p]));
  const byId = new Map(ingredients.map((i) => [i.id, i]));
  const need = new Map<string, number>();
  const missingRecipe: string[] = [];
  for (const line of plan) {
    const qty = Math.max(0, Number(line.qty) || 0);
    if (!qty) continue;
    const p = byProduct.get(line.productId);
    if (!p || !p.recipe.length) { missingRecipe.push(line.productId); continue; }
    for (const r of p.recipe) need.set(r.ingredientId, (need.get(r.ingredientId) || 0) + r.quantity * qty);
  }
  const needs: Need[] = [];
  for (const [id, n] of need) {
    const ing = byId.get(id);
    if (!ing) continue;
    const have = Math.max(0, ing.stock);
    needs.push({ ingredientId: id, name: ing.name, unit: ing.unit, need: round2(n), have: round2(have), short: round2(Math.max(0, n - have)), cost: Math.round(n * ing.avgCost), supplierId: ing.supplierId ?? null });
  }
  needs.sort((a, b) => (b.short > 0 ? 1 : 0) - (a.short > 0 ? 1 : 0) || b.cost - a.cost);
  return { needs, cost: needs.reduce((s, x) => s + x.cost, 0), missingRecipe };
};

const round2 = (n: number) => Math.round(n * 100) / 100;

// ── Unidades ──
// En Colombia la "libra" del mercado es de 500 g y la arroba de 12,5 kg.
const UNITS: Record<string, { base: BaseUnit; factor: number }> = {
  g: { base: 'g', factor: 1 }, gr: { base: 'g', factor: 1 }, grs: { base: 'g', factor: 1 }, gramo: { base: 'g', factor: 1 }, gramos: { base: 'g', factor: 1 },
  kg: { base: 'g', factor: 1000 }, kgs: { base: 'g', factor: 1000 }, kilo: { base: 'g', factor: 1000 }, kilos: { base: 'g', factor: 1000 },
  lb: { base: 'g', factor: 500 }, lbs: { base: 'g', factor: 500 }, libra: { base: 'g', factor: 500 }, libras: { base: 'g', factor: 500 },
  arroba: { base: 'g', factor: 12500 }, '@': { base: 'g', factor: 12500 },
  ml: { base: 'ml', factor: 1 }, cc: { base: 'ml', factor: 1 }, l: { base: 'ml', factor: 1000 }, lt: { base: 'ml', factor: 1000 }, lts: { base: 'ml', factor: 1000 }, litro: { base: 'ml', factor: 1000 }, litros: { base: 'ml', factor: 1000 },
  und: { base: 'und', factor: 1 }, un: { base: 'und', factor: 1 }, u: { base: 'und', factor: 1 }, unid: { base: 'und', factor: 1 }, unidad: { base: 'und', factor: 1 }, unidades: { base: 'und', factor: 1 }, pza: { base: 'und', factor: 1 }, pieza: { base: 'und', factor: 1 }, piezas: { base: 'und', factor: 1 },
};
export const unitOf = (raw: string | null | undefined) => UNITS[String(raw || '').trim().toLowerCase().replace(/\.$/, '')] || null;

const numberOf = (raw: string) => {
  const s = raw.trim().replace(/\s/g, '').replace(/^\$/, '');
  if (s === '½' || s === '1/2') return 0.5;
  if (/^\d+\/\d+$/.test(s)) { const [a, b] = s.split('/').map(Number); return b ? a / b : NaN; }
  // 3.500 / 3,500 / 3.500,50: punto de miles y coma decimal, como se escribe en Colombia
  if (/^\d{1,3}(\.\d{3})+(,\d+)?$/.test(s)) return Number(s.replace(/\./g, '').replace(',', '.'));
  if (/^\d{1,3}(,\d{3})+$/.test(s)) return Number(s.replace(/,/g, ''));
  return Number(s.replace(',', '.'));
};

export interface ListRow { name: string; unit: BaseUnit; costPerBase: number | null; stock: number | null; minStock: number | null; category: string | null; error?: string }

/**
 * Lista pegada (una fila por ingrediente; columnas separadas por tab, ; o ,):
 *   nombre | unidad | costo por esa unidad | existencia | mínimo | categoría
 * "Tomate; kg; 3.500; 10" → tomate en gramos, $3,5 por gramo, 10.000 g.
 * La primera fila se ignora si parece encabezado.
 */
export const parseIngredientList = (text: string): ListRow[] => {
  const rows: ListRow[] = [];
  for (const rawLine of String(text || '').split(/\r?\n/).slice(0, 500)) {
    const line = rawLine.trim();
    if (!line) continue;
    const sep = line.includes('\t') ? '\t' : line.includes(';') ? ';' : line.includes('|') ? '|' : ',';
    const cols = line.split(sep).map((c) => c.trim());
    if (rows.length === 0 && /nombre|ingrediente|producto|name/i.test(cols[0]) && cols.length > 1) continue;
    const name = cols[0].replace(/\s+/g, ' ').slice(0, 80);
    if (!name) continue;
    const u = unitOf(cols[1]) || (cols[1] ? null : { base: 'g' as BaseUnit, factor: 1 });
    if (!u) { rows.push({ name, unit: 'g', costPerBase: null, stock: null, minStock: null, category: null, error: 'UNIT' }); continue; }
    const cost = cols[2] ? numberOf(cols[2]) : NaN;
    const stock = cols[3] ? numberOf(cols[3]) : NaN;
    const min = cols[4] ? numberOf(cols[4]) : NaN;
    rows.push({
      name,
      unit: u.base,
      costPerBase: Number.isFinite(cost) && cost >= 0 ? cost / u.factor : null,
      stock: Number.isFinite(stock) && stock >= 0 ? round2(stock * u.factor) : null,
      minStock: Number.isFinite(min) && min >= 0 ? round2(min * u.factor) : null,
      category: cols[5] ? cols[5].slice(0, 40) : null,
    });
  }
  return rows;
};

export interface RecipeLine { name: string; quantity: number; unit: BaseUnit }

/**
 * Receta escrita: "200 g carne molida, 1 pan, 30g queso, media cebolla" (comas o
 * renglones). Sin unidad: unidades. "media"/"½" = 0,5.
 */
export const parseRecipeText = (text: string): RecipeLine[] => {
  const out: RecipeLine[] = [];
  // La coma entre números es decimal ("0,5 kg"); entre ingredientes, separa
  for (const part of String(text || '').split(/(?<!\d),|,(?!\d)|[\n;]+|\s+y\s+/i)) {
    let s = part.trim().replace(/^[-•*]\s*/, '');
    if (!s) continue;
    s = s.replace(/^(media|medio)\s+/i, '0.5 ').replace(/^un[ao]?\s+/i, '1 ');
    const m = /^(\d+(?:[.,]\d+)?|½|\d+\/\d+)\s*(.*)$/.exec(s);
    if (!m) continue;
    const qty = numberOf(m[1]);
    let rest = m[2].trim();
    // La primera palabra puede ser la unidad ("200 g carne", "30g queso", "2 lb de papa")
    const first = /^([a-zA-Z@]+\.?)(?:\s+|$)(.*)$/.exec(rest);
    let unit = first && first[2] ? unitOf(first[1]) : null;
    if (unit) rest = first![2].replace(/^de\s+/i, '').trim();
    if (!unit) unit = { base: 'und', factor: 1 };
    if (!Number.isFinite(qty) || qty <= 0 || !rest) continue;
    out.push({ name: rest.slice(0, 60), quantity: round2(qty * unit.factor), unit: unit.base });
  }
  return out.slice(0, 40);
};

/** Para encontrar un ingrediente por su nombre sin importar tildes, mayúsculas ni plurales simples */
export const nameKey = (s: string) => s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim().replace(/s$/, '');

/** El ingrediente existente que corresponde a un nombre escrito (exacto, o el que lo contiene) */
export const matchIngredient = <T extends { id: string; name: string }>(name: string, list: T[]): T | null => {
  const k = nameKey(name);
  if (!k) return null;
  const exact = list.find((i) => nameKey(i.name) === k);
  if (exact) return exact;
  const contains = list.filter((i) => { const n = nameKey(i.name); return n.length >= 3 && (n.includes(k) || k.includes(n)); });
  return contains.length === 1 ? contains[0] : null;
};

/** Mensaje de pedido al proveedor con lo que falta (WhatsApp, un toque) */
export const shortageText = (business: string, lines: { name: string; quantity: number; unit: BaseUnit }[], lang: 'es' | 'en' = 'es') => {
  const fmt = (q: number, u: BaseUnit) => (u === 'g' && q >= 1000 ? `${round2(q / 1000)} kg` : u === 'ml' && q >= 1000 ? `${round2(q / 1000)} l` : `${round2(q)} ${u}`);
  const head = lang === 'en' ? `Hello, this is ${business}. We need:` : `Hola, te escribimos de ${business}. Necesitamos:`;
  const tail = lang === 'en' ? 'Thank you!' : '¡Gracias!';
  return [head, ...lines.map((l) => `• ${l.name}: ${fmt(l.quantity, l.unit)}`), tail].join('\n');
};
