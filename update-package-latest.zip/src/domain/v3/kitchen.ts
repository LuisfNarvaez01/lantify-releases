// ============================================
// DOMAIN - Pantallas de cocina, entregas y salón (Lantify 3.0 · bloque 2)
// ============================================
// Funciones puras: arman lo que muestra cada pantalla a partir de las líneas de
// las comandas. La pantalla nunca ve precios, totales ni datos de clientes.

export type DisplayType = 'KITCHEN' | 'PICKUP' | 'FLOOR';
export const DISPLAY_TYPES: DisplayType[] = ['KITCHEN', 'PICKUP', 'FLOOR'];

/** Estados de la línea que pone la cocina o el mesero (el equipo que comanda no los pisa) */
export const KITCHEN_STATES = ['READY', 'SERVED'];

export interface KitchenLineInput {
  id: string;
  orderId: string;
  orderNumber: string;
  channel: string;
  tableNumber: string | null;
  waiterName: string | null;
  roundNumber: number | null;
  sentAt: Date | null;
  readyAt: Date | null;
  status: string;
  quantity: number;
  name: string;
  notes: string | null;
  removed: string[];
  /** Estación de la línea: la del producto, si no la de su categoría; null = cocina principal */
  station: string | null;
}

export interface TicketLine { id: string; quantity: number; name: string; notes: string | null; removed: string[]; ready: boolean }

export interface KitchenTicket {
  key: string;
  orderId: string;
  label: string;
  isTable: boolean;
  waiterName: string | null;
  roundNumber: number | null;
  sentAt: string;
  minutes: number;
  level: 'ok' | 'warn' | 'late';
  lines: TicketLine[];
}

export interface KitchenThresholds { warnMin: number; lateMin: number }
export const DEFAULT_THRESHOLDS: KitchenThresholds = { warnMin: 10, lateMin: 20 };

const minutesSince = (d: Date, now: Date) => Math.max(0, Math.floor((now.getTime() - d.getTime()) / 60_000));

/** Nombre corto del pedido: mesa o número de pedido (los últimos dígitos) */
export const orderLabel = (l: Pick<KitchenLineInput, 'tableNumber' | 'orderNumber' | 'channel'>) =>
  l.tableNumber ? l.tableNumber : `#${l.orderNumber.split('-').pop()?.replace(/^0+(?=\d)/, '') || l.orderNumber}`;

/** ¿La línea le toca a esta pantalla? station null = todas */
export const forStation = (lineStation: string | null, displayStation: string | null) =>
  !displayStation || (displayStation === 'kitchen' ? !lineStation || lineStation === 'kitchen' : lineStation === displayStation);

/**
 * Comandas pendientes de cocina: una tarjeta por pedido y ronda, de la más vieja
 * a la más nueva. Una tarjeta sale cuando todas sus líneas están listas.
 */
export const buildTickets = (lines: KitchenLineInput[], station: string | null, now: Date, th: KitchenThresholds = DEFAULT_THRESHOLDS): KitchenTicket[] => {
  const groups = new Map<string, KitchenLineInput[]>();
  for (const l of lines) {
    if (!l.sentAt || !['SENT', 'IN_PREP', 'READY'].includes(l.status) || !forStation(l.station, station)) continue;
    const key = `${l.orderId}:${l.roundNumber ?? 0}`;
    groups.set(key, [...(groups.get(key) || []), l]);
  }
  const out: KitchenTicket[] = [];
  for (const [key, group] of groups) {
    if (group.every((l) => l.status === 'READY')) continue;
    const first = group[0];
    const sentAt = group.reduce((min, l) => (l.sentAt! < min ? l.sentAt! : min), first.sentAt!);
    const minutes = minutesSince(sentAt, now);
    out.push({
      key,
      orderId: first.orderId,
      label: orderLabel(first),
      isTable: !!first.tableNumber,
      waiterName: first.waiterName,
      roundNumber: first.roundNumber,
      sentAt: sentAt.toISOString(),
      minutes,
      level: minutes >= th.lateMin ? 'late' : minutes >= th.warnMin ? 'warn' : 'ok',
      lines: group.map((l) => ({ id: l.id, quantity: l.quantity, name: l.name, notes: l.notes, removed: l.removed, ready: l.status === 'READY' })),
    });
  }
  return out.sort((a, b) => a.sentAt.localeCompare(b.sentAt));
};

export interface PickupOrder { orderId: string; label: string; ready: boolean; readyAt: string | null }

/** Pedidos sin mesa (mostrador, para llevar, domicilio): preparando o listos para recoger */
export const buildPickup = (
  orders: { id: string; orderNumber: string; channel: string; pickedUpAt: Date | null; lines: { status: string; sentAt: Date | null; readyAt: Date | null }[] }[],
  now: Date,
  readyForMin = 10,
): { preparing: PickupOrder[]; ready: PickupOrder[] } => {
  const preparing: PickupOrder[] = [];
  const ready: PickupOrder[] = [];
  for (const o of orders) {
    if (o.pickedUpAt) continue;
    const sent = o.lines.filter((l) => l.sentAt && l.status !== 'CANCELLED');
    if (!sent.length) continue;
    const label = orderLabel({ tableNumber: null, orderNumber: o.orderNumber, channel: o.channel });
    const allReady = sent.every((l) => KITCHEN_STATES.includes(l.status));
    if (!allReady) { preparing.push({ orderId: o.id, label, ready: false, readyAt: null }); continue; }
    const readyAt = sent.reduce<Date | null>((max, l) => (l.readyAt && (!max || l.readyAt > max) ? l.readyAt : max), null);
    if (readyAt && minutesSince(readyAt, now) >= readyForMin) continue;
    ready.push({ orderId: o.id, label, ready: true, readyAt: readyAt?.toISOString() ?? null });
  }
  return { preparing, ready: ready.sort((a, b) => (b.readyAt || '').localeCompare(a.readyAt || '')) };
};

/** Código de emparejamiento: 6 dígitos */
export const pairingCode = (random: () => number = Math.random) =>
  String(Math.floor(random() * 1_000_000)).padStart(6, '0');
