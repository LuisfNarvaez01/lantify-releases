// ============================================
// DOMAIN - Facturas de compra: emparejar sin guardar (Lantify 3.0)
// ============================================
// Extracción → pre-conciliación → validación humana → persistencia atómica.
// Aquí solo lo puro: limpiar textos, parecido entre nombres, tipo de documento
// y la unidad escrita dentro de la descripción ("Tomate chonto 5 Kg").

export type DocType = 'SUPPLY_PURCHASE' | 'OPERATIONAL_EXPENSE';

const STRIP = /[̀-ͯ]/g;
export const normText = (s: unknown) =>
  (typeof s === 'string' ? s : '').normalize('NFD').replace(STRIP, '').toLowerCase().replace(/[^a-z0-9 ]+/g, ' ').replace(/\s+/g, ' ').trim();

/** Texto de la línea sin cantidades ni unidades: la llave del alias del proveedor */
export const aliasKey = (s: unknown) =>
  normText(s).replace(/\b\d+([.,]\d+)?\s*(kg|kgs|kilo|kilos|g|gr|grs|lb|lbs|libras?|l|lt|lts|litros?|ml|cc|und|unds|unidad(es)?|x|caja|cajas|paquete|paq|bulto)\b/g, ' ').replace(/\b\d+\b/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 120);

export const cleanNit = (s: unknown) => (typeof s === 'string' ? s.replace(/[^\d]/g, '') : '').replace(/^(\d{9})\d$/, '$1');

const bigrams = (s: string) => {
  const t = ` ${s} `;
  const out = new Map<string, number>();
  for (let i = 0; i < t.length - 1; i++) { const b = t.slice(i, i + 2); out.set(b, (out.get(b) || 0) + 1); }
  return out;
};

/** Parecido entre 0 y 1 (coeficiente de Dice sobre pares de letras) */
export const similarity = (a: unknown, b: unknown) => {
  const x = normText(a); const y = normText(b);
  if (!x || !y) return 0;
  if (x === y) return 1;
  if (x.includes(y) || y.includes(x)) return 0.9;
  const A = bigrams(x); const B = bigrams(y);
  let inter = 0; let total = 0;
  for (const [k, n] of A) { inter += Math.min(n, B.get(k) || 0); total += n; }
  for (const n of B.values()) total += n;
  return total ? (2 * inter) / total : 0;
};

export const best = <T>(text: string, options: T[], nameOf: (o: T) => string, min = 0.55) => {
  let top: { item: T; score: number } | null = null;
  for (const o of options) { const s = similarity(text, nameOf(o)); if (!top || s > top.score) top = { item: o, score: s }; }
  return top && top.score >= min ? top : null;
};

/** Cantidad y unidad escritas en la descripción, si la línea no las trae */
export const unitInText = (s: unknown): { quantity: number; unit: string } | null => {
  const m = /(\d+(?:[.,]\d+)?)\s*(kg|kilos?|g|gr|grs|lb|libras?|l|lt|litros?|ml|cc|und|unidades|docena|caja|paquete|bulto)\b/i.exec(typeof s === 'string' ? s : '');
  return m ? { quantity: Number(m[1].replace(',', '.')), unit: m[2].toLowerCase() } : null;
};

const SERVICE = /(energia|electric|acueducto|agua|gas natural|internet|telefon|arriendo|arrendamiento|alquiler|mantenimiento|reparacion|honorario|nomina|seguro|vigilancia|publicidad|software|suscripcion|servicio)/;

/** Tipo de documento: el que diga la IA; si no, por las palabras del proveedor y la categoría */
export const docTypeOf = (r: { docType?: string | null; supplierName?: string | null; supplierCategory?: string | null; category?: string | null; items?: unknown[] }): DocType => {
  if (r.docType === 'SUPPLY_PURCHASE' || r.docType === 'OPERATIONAL_EXPENSE') return r.docType;
  if (SERVICE.test(normText(`${r.supplierName || ''} ${r.supplierCategory || ''} ${r.category || ''}`))) return 'OPERATIONAL_EXPENSE';
  return (r.items || []).length ? 'SUPPLY_PURCHASE' : 'OPERATIONAL_EXPENSE';
};
