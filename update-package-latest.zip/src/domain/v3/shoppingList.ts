// ============================================
// DOMAIN - Lista de compras por proveedor (Lantify 3.0)
// ============================================

export const DEFAULT_MIN_STOCK = 5;

export interface StockItem {
  variantId: string;
  name: string;
  stock: number;
  minStock: number | null;
  reorderQty: number | null;
  purchaseUnit: string | null;
  supplierId: string | null;
}

export interface SupplierRef { id: string; name: string; phone: string | null }

export interface ShoppingLine { variantId: string; name: string; quantity: number; unit: string; stock: number; minStock: number }
export interface ShoppingGroup { supplierId: string | null; supplierName: string; phone: string | null; lines: ShoppingLine[] }

export const minStockOf = (item: { minStock: number | null }) => (item.minStock == null ? DEFAULT_MIN_STOCK : item.minStock);

export const isLowStock = (item: { stock: number; minStock: number | null }) => item.stock <= minStockOf(item);

/** Cantidad sugerida: la configurada, o lo que falta para llegar al doble del mínimo (al menos 1) */
export const suggestedQty = (item: StockItem) => {
  if (item.reorderQty && item.reorderQty > 0) return item.reorderQty;
  const min = minStockOf(item);
  return Math.max(1, min * 2 - Math.max(0, item.stock));
};

export const buildShoppingList = (items: StockItem[], suppliers: SupplierRef[]): ShoppingGroup[] => {
  const byId = new Map(suppliers.map((s) => [s.id, s]));
  const groups = new Map<string, ShoppingGroup>();
  for (const item of items) {
    if (!isLowStock(item)) continue;
    const supplier = item.supplierId ? byId.get(item.supplierId) : undefined;
    const key = supplier ? supplier.id : '';
    if (!groups.has(key)) {
      groups.set(key, { supplierId: supplier ? supplier.id : null, supplierName: supplier ? supplier.name : '', phone: supplier?.phone || null, lines: [] });
    }
    groups.get(key)!.lines.push({
      variantId: item.variantId, name: item.name, quantity: suggestedQty(item),
      unit: (item.purchaseUnit || '').trim(), stock: item.stock, minStock: minStockOf(item),
    });
  }
  const list = [...groups.values()];
  for (const g of list) g.lines.sort((a, b) => a.name.localeCompare(b.name, 'es'));
  // Con proveedor primero (por nombre); "sin proveedor" al final
  return list.sort((a, b) => (a.supplierId ? 0 : 1) - (b.supplierId ? 0 : 1) || a.supplierName.localeCompare(b.supplierName, 'es'));
};

/** "10 cajas de Leche" / "5 Café" */
export const lineText = (l: { quantity: number; unit: string; name: string }) => (l.unit ? `${l.quantity} ${l.unit} de ${l.name}` : `${l.quantity} ${l.name}`);

/** Mensaje listo para copiar o enviar al proveedor */
export const shoppingText = (group: { supplierName: string; lines: { quantity: number; unit: string; name: string }[] }, businessName: string, lang: 'es' | 'en' = 'es') => {
  const head = lang === 'en'
    ? `Hello${group.supplierName ? ` ${group.supplierName}` : ''}, order from ${businessName}:`
    : `Hola${group.supplierName ? ` ${group.supplierName}` : ''}, pedido de ${businessName}:`;
  return [head, ...group.lines.map((l) => `• ${lineText(l)}`)].join('\n');
};
