// ============================================
// DOMAIN - Reparto de propinas (Lantify 3.0)
// ============================================
// El total del periodo se divide por porcentajes entre grupos. Entre meseros:
// partes iguales o según lo que cada uno aportó. En los demás grupos: partes
// iguales entre quienes trabajaron. Todo en pesos enteros y la suma siempre
// da el total exacto.

import { STAFF_GROUPS, type StaffGroup, type TipRules } from './features';

export interface SplitMember { employeeId: string; group: StaffGroup; /** Propinas de las ventas que atendió (solo meseros) */ contributed?: number }

export interface SplitInput { total: number; rules: TipRules; members: SplitMember[] }

export interface SplitShare { employeeId: string; group: StaffGroup; amount: number }
export interface SplitResult {
  shares: SplitShare[];
  /** Parte de un grupo sin nadie que la reciba: el ADMIN la asigna a mano */
  unassigned: { group: StaffGroup; amount: number }[];
  total: number;
}

/** Reparte `total` (entero) según pesos; los pesos que sobran van a los de mayor residuo */
export const allocate = (total: number, weights: number[]): number[] => {
  const sum = weights.reduce((a, w) => a + w, 0);
  if (!weights.length) return [];
  if (sum <= 0) return allocate(total, weights.map(() => 1));
  const exact = weights.map((w) => (total * w) / sum);
  const out = exact.map((x) => Math.floor(x));
  let left = total - out.reduce((a, n) => a + n, 0);
  const order = exact.map((x, i) => ({ i, frac: x - Math.floor(x) })).sort((a, b) => b.frac - a.frac || a.i - b.i);
  for (let k = 0; left > 0; k = (k + 1) % order.length, left--) out[order[k].i] += 1;
  return out;
};

export const splitTips = ({ total, rules, members }: SplitInput): SplitResult => {
  const pot = Math.round(total);
  const groupAmounts = allocate(pot, STAFF_GROUPS.map((g) => rules.groups[g]));
  const shares: SplitShare[] = [];
  const unassigned: SplitResult['unassigned'] = [];
  STAFF_GROUPS.forEach((group, idx) => {
    const amount = groupAmounts[idx];
    if (amount <= 0) return;
    const people = members.filter((m) => m.group === group);
    if (!people.length) { unassigned.push({ group, amount }); return; }
    const byContribution = group === 'WAITER' && rules.waiterMode === 'CONTRIBUTION';
    const weights = people.map((p) => (byContribution ? Math.max(0, p.contributed || 0) : 1));
    allocate(amount, weights).forEach((part, i) => shares.push({ employeeId: people[i].employeeId, group, amount: part }));
  });
  return { shares, unassigned, total: pot };
};

/** Lo confirmado debe sumar el total y no dejar nada sin asignar */
export const validateShares = (total: number, shares: { amount: number }[]): 'OK' | 'NEGATIVE' | 'MISMATCH' => {
  if (shares.some((s) => !(s.amount >= 0))) return 'NEGATIVE';
  return Math.round(shares.reduce((a, s) => a + s.amount, 0)) === Math.round(total) ? 'OK' : 'MISMATCH';
};
