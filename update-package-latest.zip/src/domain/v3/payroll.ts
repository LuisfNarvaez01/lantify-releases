// ============================================
// DOMAIN - Liquidación del personal (Lantify 3.0)
// ============================================
// Control interno: pago base según turnos u horas + propinas − adelantos − descuentos.
// No calcula seguridad social ni prestaciones.

export type PayType = 'SHIFT' | 'HOUR' | 'FIXED';

export interface ShiftSpan { startAt: Date; endAt: Date | null; needsReview: boolean }

export interface PayrollInput {
  payType: PayType;
  payAmount: number;
  shifts: ShiftSpan[];
  tips: number;
  advances: number;
  deductions: number;
}

export interface PayrollResult {
  days: number;
  hours: number;
  /** Turnos que no entran: sin salida o por revisar */
  pendingShifts: number;
  base: number;
  tips: number;
  advances: number;
  deductions: number;
  total: number;
}

const dayKey = (d: Date) => `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;

export const computePayroll = (input: PayrollInput): PayrollResult => {
  const valid = input.shifts.filter((s) => s.endAt && !s.needsReview && s.endAt.getTime() > s.startAt.getTime());
  const pendingShifts = input.shifts.length - valid.length;
  // "Por turno" cuenta como máximo uno por día
  const days = new Set(valid.map((s) => dayKey(s.startAt))).size;
  const hours = Math.round(valid.reduce((a, s) => a + (s.endAt!.getTime() - s.startAt.getTime()) / 3_600_000, 0) * 100) / 100;
  const base = Math.round(
    input.payType === 'SHIFT' ? days * input.payAmount
      : input.payType === 'HOUR' ? hours * input.payAmount
        : input.payAmount,
  );
  const tips = Math.round(input.tips);
  const advances = Math.round(input.advances);
  const deductions = Math.round(input.deductions);
  return { days, hours, pendingShifts, base, tips, advances, deductions, total: base + tips - advances - deductions };
};
