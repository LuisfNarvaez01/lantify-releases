// ============================================
// DOMAIN - Alertas de mesa (Lantify 3.0)
// ============================================
// El servidor decide qué mesas necesitan atención; todos los equipos ven lo mismo.

import type { AlertSettings } from './features';

export type AlertKind = 'idle' | 'ready' | 'bill';

export interface AlertInput {
  tableId: string;
  tableNumber: string;
  waiterId: string | null;
  waiterName: string | null;
  /** Última ronda enviada a cocina */
  lastRoundAt: Date | null;
  /** Cuándo salió de cocina la última comanda (lo llena el visor de cocina; hoy null) */
  lastReadyAt: Date | null;
  billRequestedAt: Date | null;
}

export interface TableAlert {
  tableId: string;
  tableNumber: string;
  waiterId: string | null;
  waiterName: string | null;
  kind: AlertKind;
  minutes: number;
}

const minutesSince = (from: Date, now: Date) => Math.floor((now.getTime() - from.getTime()) / 60_000);

/** Una alerta por mesa como máximo: cuenta pendiente > lista para cuenta > inactiva */
export const computeAlerts = (tables: AlertInput[], cfg: AlertSettings, now: Date): TableAlert[] => {
  const out: TableAlert[] = [];
  for (const t of tables) {
    const base = { tableId: t.tableId, tableNumber: t.tableNumber, waiterId: t.waiterId, waiterName: t.waiterName };
    if (t.billRequestedAt) {
      const m = minutesSince(t.billRequestedAt, now);
      if (cfg.bill && m >= cfg.billMin) out.push({ ...base, kind: 'bill', minutes: m });
      continue; // con la cuenta pedida la mesa ya no está "inactiva"
    }
    if (cfg.ready && t.lastReadyAt) {
      const m = minutesSince(t.lastReadyAt, now);
      if (m >= cfg.readyMin) { out.push({ ...base, kind: 'ready', minutes: m }); continue; }
    }
    if (cfg.idle && t.lastRoundAt) {
      const m = minutesSince(t.lastRoundAt, now);
      if (m >= cfg.idleMin) out.push({ ...base, kind: 'idle', minutes: m });
    }
  }
  return out.sort((a, b) => b.minutes - a.minutes);
};
