// ============================================
// DOMAIN - Motor de menú (Lantify 3.0 · bloque 4)
// ============================================
// Un solo modelo para la pantalla "Motor de menú", las sugerencias al mesero y
// Autopilot. Funciones puras: reciben las ventas y devuelven la lectura.
//
// Clasificación clásica de ingeniería de menú (Kasavana y Smith): popularidad
// contra el 70 % de la participación promedio, y margen unitario contra el
// margen promedio ponderado.

export type MenuClass = 'STAR' | 'PLOWHORSE' | 'PUZZLE' | 'DOG' | 'NO_COST';

export interface SaleLine {
  saleId: string;
  productId: string;
  name: string;
  quantity: number;
  revenue: number;
  /** Costo total de la línea; null si el producto no tiene costo cargado */
  cost: number | null;
  at: Date;
}

export interface PrepSample { productId: string; minutes: number }

export interface MenuItemReading {
  productId: string;
  name: string;
  units: number;
  revenue: number;
  /** Participación en unidades (0–1) */
  mix: number;
  /** Margen unitario promedio en pesos (null sin costo) */
  unitMargin: number | null;
  marginPct: number | null;
  /** Contribución total (ventas − costo) */
  contribution: number | null;
  klass: MenuClass;
  /** Cambio en unidades: últimos 14 días contra los 14 anteriores (%) */
  trendPct: number | null;
  /** Horas del día (0–23) con más unidades */
  peakHours: number[];
  prepMedian: number | null;
  prepP80: number | null;
}

export interface Pairing {
  a: string;
  b: string;
  /** Ventas con los dos */
  together: number;
  /** De las ventas con A, cuántas tienen B (0–1) */
  confidence: number;
  lift: number;
}

export interface MenuReading {
  from: string;
  to: string;
  sales: number;
  items: MenuItemReading[];
  pairings: Pairing[];
}

const DAY = 86_400_000;
const round1 = (n: number) => Math.round(n * 10) / 10;

export const quantile = (values: number[], q: number) => {
  if (!values.length) return null;
  const s = [...values].sort((a, b) => a - b);
  const pos = (s.length - 1) * q;
  const lo = Math.floor(pos);
  const hi = Math.ceil(pos);
  return round1(s[lo] + (s[hi] - s[lo]) * (pos - lo));
};

/** Pares que se piden juntos: mínimo `minTogether` ventas y lift > 1 */
export const pairingsOf = (lines: SaleLine[], minTogether = 5): Pairing[] => {
  const bySale = new Map<string, Set<string>>();
  for (const l of lines) bySale.set(l.saleId, (bySale.get(l.saleId) || new Set()).add(l.productId));
  const total = bySale.size;
  if (!total) return [];
  const single = new Map<string, number>();
  const pair = new Map<string, number>();
  for (const set of bySale.values()) {
    const ids = [...set].sort();
    for (const id of ids) single.set(id, (single.get(id) || 0) + 1);
    for (let i = 0; i < ids.length; i++) for (let j = i + 1; j < ids.length; j++) {
      const k = `${ids[i]}|${ids[j]}`;
      pair.set(k, (pair.get(k) || 0) + 1);
    }
  }
  const out: Pairing[] = [];
  for (const [k, n] of pair) {
    if (n < minTogether) continue;
    const [x, y] = k.split('|');
    for (const [a, b] of [[x, y], [y, x]]) {
      const confidence = n / single.get(a)!;
      const lift = confidence / (single.get(b)! / total);
      if (lift > 1) out.push({ a, b, together: n, confidence: round1(confidence * 100) / 100, lift: round1(lift) });
    }
  }
  return out.sort((p, q) => q.lift - p.lift || q.together - p.together);
};

export const classify = (mix: number, unitMargin: number | null, avgMix: number, avgMargin: number | null): MenuClass => {
  if (unitMargin === null || avgMargin === null) return 'NO_COST';
  const popular = mix >= avgMix * 0.7;
  const profitable = unitMargin >= avgMargin;
  return popular ? (profitable ? 'STAR' : 'PLOWHORSE') : profitable ? 'PUZZLE' : 'DOG';
};

export const readMenu = (lines: SaleLine[], prep: PrepSample[], now: Date, days = 60): MenuReading => {
  const from = new Date(now.getTime() - days * DAY);
  const recent = lines.filter((l) => l.at >= from && l.at <= now);
  const byProduct = new Map<string, { name: string; units: number; revenue: number; cost: number | null; units14: number; unitsPrev14: number; hours: number[] }>();
  const cut14 = now.getTime() - 14 * DAY;
  const cut28 = now.getTime() - 28 * DAY;
  for (const l of recent) {
    const r = byProduct.get(l.productId) || { name: l.name, units: 0, revenue: 0, cost: 0 as number | null, units14: 0, unitsPrev14: 0, hours: Array(24).fill(0) };
    r.units += l.quantity;
    r.revenue += l.revenue;
    r.cost = r.cost === null || l.cost === null ? null : r.cost + l.cost;
    const t = l.at.getTime();
    if (t >= cut14) r.units14 += l.quantity;
    else if (t >= cut28) r.unitsPrev14 += l.quantity;
    r.hours[l.at.getHours()] += l.quantity;
    byProduct.set(l.productId, r);
  }
  const totalUnits = [...byProduct.values()].reduce((n, r) => n + r.units, 0);
  const count = byProduct.size || 1;
  const avgMix = 1 / count;
  const withCost = [...byProduct.values()].filter((r) => r.cost !== null);
  const costUnits = withCost.reduce((n, r) => n + r.units, 0);
  const avgMargin = costUnits ? withCost.reduce((n, r) => n + (r.revenue - (r.cost as number)), 0) / costUnits : null;
  const prepBy = new Map<string, number[]>();
  for (const p of prep) prepBy.set(p.productId, [...(prepBy.get(p.productId) || []), p.minutes]);

  const items: MenuItemReading[] = [...byProduct.entries()].map(([productId, r]) => {
    const mix = totalUnits ? r.units / totalUnits : 0;
    const unitMargin = r.cost === null || !r.units ? null : Math.round((r.revenue - r.cost) / r.units);
    const peak = Math.max(...r.hours);
    return {
      productId,
      name: r.name,
      units: r.units,
      revenue: Math.round(r.revenue),
      mix: round1(mix * 1000) / 1000,
      unitMargin,
      marginPct: r.cost === null || !r.revenue ? null : round1(((r.revenue - r.cost) / r.revenue) * 100),
      contribution: r.cost === null ? null : Math.round(r.revenue - r.cost),
      klass: classify(mix, unitMargin, avgMix, avgMargin === null ? null : Math.round(avgMargin)),
      trendPct: r.unitsPrev14 >= 3 ? round1(((r.units14 - r.unitsPrev14) / r.unitsPrev14) * 100) : null,
      peakHours: peak > 0 ? r.hours.map((n, h) => ({ n, h })).filter((x) => x.n >= peak * 0.7).map((x) => x.h) : [],
      prepMedian: quantile(prepBy.get(productId) || [], 0.5),
      prepP80: quantile(prepBy.get(productId) || [], 0.8),
    };
  }).sort((a, b) => (b.contribution ?? b.revenue) - (a.contribution ?? a.revenue));

  return {
    from: from.toISOString(),
    to: now.toISOString(),
    sales: new Set(recent.map((l) => l.saleId)).size,
    items,
    pairings: pairingsOf(recent),
  };
};

// ── Sugerencias al mesero ──

export interface Suggestion {
  productId: string;
  name: string;
  /** Por qué: con qué va o por qué conviene ahora */
  reason: 'PAIRS' | 'STAR_NOW' | 'PUZZLE_NOW' | 'BOOST';
  /** Producto del pedido con el que combina (PAIRS) */
  with?: string;
  /** De cada 10 que piden `with`, cuántos piden este */
  ofTen?: number;
}

export interface SuggestOptions {
  cart: string[];
  hour: number;
  /** Productos que no se pueden ofrecer (sin existencias, pausados, inactivos) */
  blocked: Set<string>;
  /** Productos que Autopilot pidió priorizar */
  boost?: string[];
  limit?: number;
}

export const suggest = (reading: MenuReading, o: SuggestOptions): Suggestion[] => {
  const limit = o.limit ?? 3;
  const inCart = new Set(o.cart);
  const names = new Map(reading.items.map((i) => [i.productId, i.name]));
  const ok = (id: string) => !inCart.has(id) && !o.blocked.has(id) && names.has(id);
  const out: Suggestion[] = [];
  const add = (s: Suggestion) => { if (out.length < limit && ok(s.productId) && !out.some((x) => x.productId === s.productId)) out.push(s); };

  for (const id of o.boost || []) add({ productId: id, name: names.get(id) || '', reason: 'BOOST' });
  if (o.cart.length) {
    for (const p of reading.pairings) {
      if (inCart.has(p.a) && p.lift >= 1.2) add({ productId: p.b, name: names.get(p.b) || '', reason: 'PAIRS', with: names.get(p.a), ofTen: Math.max(1, Math.round(p.confidence * 10)) });
    }
  }
  const nearHour = (i: MenuItemReading) => !i.peakHours.length || i.peakHours.some((h) => Math.abs(h - o.hour) <= 1);
  for (const i of reading.items) if (i.klass === 'STAR' && nearHour(i)) add({ productId: i.productId, name: i.name, reason: 'STAR_NOW' });
  for (const i of reading.items) if (i.klass === 'PUZZLE' && nearHour(i)) add({ productId: i.productId, name: i.name, reason: 'PUZZLE_NOW' });
  return out;
};
