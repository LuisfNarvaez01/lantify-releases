// ============================================
// DOMAIN - Resumen del cierre de caja para el dueño (Lantify 3.0)
// ============================================
// Texto corto: es lo único del turno que sale del equipo hacia la nube.

export interface CloseReport {
  businessName: string;
  sessionNumber: string;
  openedAt: string;
  closedAt: string;
  openedBy: string | null;
  closedBy: string | null;
  salesCount: number;
  salesTotal: number;
  avgTicket: number;
  byMethod: { method: string; amount: number }[];
  initialBalance: number;
  expected: number;
  counted: number;
  difference: number;
  expenses: number;
  incomes: number;
  tips: number;
  discounts: number;
  cancelledCount: number;
  cancelledTotal: number;
}

export const money = (n: number) => `$${Math.round(n).toLocaleString('es-CO').replace(/,/g, '.')}`;

const METHOD_ES: Record<string, string> = { CASH: 'Efectivo', CARD: 'Tarjeta', TRANSFER: 'Transferencia', MIXED: 'Combinado' };
const METHOD_EN: Record<string, string> = { CASH: 'Cash', CARD: 'Card', TRANSFER: 'Transfer', MIXED: 'Mixed' };

export interface SaleLike { status: string; total: number; tip: number; discount: number }

export const summarizeSales = (sales: SaleLike[], payments: { method: string; amount: number }[]) => {
  const done = sales.filter((s) => s.status === 'COMPLETED');
  const cancelled = sales.filter((s) => s.status === 'CANCELLED');
  const salesTotal = done.reduce((a, s) => a + s.total, 0);
  const methods = new Map<string, number>();
  for (const p of payments) methods.set(p.method, (methods.get(p.method) || 0) + p.amount);
  return {
    salesCount: done.length,
    salesTotal,
    avgTicket: done.length ? salesTotal / done.length : 0,
    byMethod: [...methods.entries()].map(([method, amount]) => ({ method, amount })).sort((a, b) => b.amount - a.amount),
    tips: done.reduce((a, s) => a + (s.tip || 0), 0),
    discounts: done.reduce((a, s) => a + (s.discount || 0), 0),
    cancelledCount: cancelled.length,
    cancelledTotal: cancelled.reduce((a, s) => a + s.total, 0),
  };
};

const when = (iso: string, lang: 'es' | 'en') =>
  new Date(iso).toLocaleString(lang === 'en' ? 'en-US' : 'es-CO', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit', timeZone: 'America/Bogota' });

export const closeReportText = (r: CloseReport, lang: 'es' | 'en' = 'es'): string => {
  const es = lang !== 'en';
  const names = es ? METHOD_ES : METHOD_EN;
  const diff = Math.round(r.difference);
  const diffLabel = diff === 0 ? (es ? 'cuadra' : 'balanced') : diff > 0 ? (es ? `sobran ${money(diff)}` : `over by ${money(diff)}`) : (es ? `faltan ${money(-diff)}` : `short by ${money(-diff)}`);
  const lines = [
    es ? `*Cierre de caja · ${r.businessName}*` : `*Cash close · ${r.businessName}*`,
    `${es ? 'Turno' : 'Shift'} ${r.sessionNumber} · ${when(r.closedAt, lang)}${r.closedBy ? ` · ${es ? 'cerró' : 'closed by'} ${r.closedBy}` : ''}`,
    '',
    `${es ? 'Ventas' : 'Sales'}: ${money(r.salesTotal)} (${r.salesCount}) · ${es ? 'ticket promedio' : 'avg. ticket'} ${money(r.avgTicket)}`,
    ...r.byMethod.map((m) => `• ${names[m.method] || m.method}: ${money(m.amount)}`),
    '',
    `${es ? 'Efectivo esperado' : 'Expected cash'}: ${money(r.expected)}`,
    `${es ? 'Efectivo contado' : 'Counted cash'}: ${money(r.counted)} (${diffLabel})`,
    `${es ? 'Gastos' : 'Expenses'}: ${money(r.expenses)} · ${es ? 'Ingresos' : 'Income'}: ${money(r.incomes)}`,
    `${es ? 'Propinas' : 'Tips'}: ${money(r.tips)} · ${es ? 'Descuentos' : 'Discounts'}: ${money(r.discounts)}`,
  ];
  if (r.cancelledCount) lines.push(`${es ? 'Anulaciones' : 'Voids'}: ${r.cancelledCount} (${money(r.cancelledTotal)})`);
  return lines.join('\n');
};
