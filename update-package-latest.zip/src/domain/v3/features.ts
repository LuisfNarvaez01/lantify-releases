// ============================================
// DOMAIN - Funciones activables del negocio (Lantify 3.0)
// ============================================
// Un solo registro (BusinessSettings.featureSettings, JSON) dice qué funciones
// usa el negocio y guarda sus ajustes. Lo apagado no aparece en la interfaz.
// Lo comparten el servidor y la pantalla.

export const FEATURE_KEYS = [
  'dirty_tables',       // Mesa "por limpiar" al cobrar
  'table_alerts',       // Mesa inactiva / cuenta pendiente
  'waiter_suggestions', // Sugerencias al mesero (bloque 4)
  'shopping_list',      // Lista de compras por proveedor
  'staff',              // Personal, turnos y pagos
  'tip_split',          // Reparto de propinas
  'close_report',       // Reporte de cierre al dueño
  'kitchen_display',    // Pantallas de cocina, entregas y salón (bloque 2)
  'autopilot',          // Autopilot: situaciones e intervenciones (bloque 4)
  'table_details',      // Al abrir mesa: personas, descripción y cliente
] as const;

export type FeatureKey = typeof FEATURE_KEYS[number];

/** Plan mínimo de cada función (null = todos los planes). Cambiar de plan una función es cambiar este dato. */
export const FEATURE_PLAN_CODE: Record<FeatureKey, string | null> = {
  dirty_tables: null,
  table_alerts: 'ops_pro',
  waiter_suggestions: 'autopilot',
  shopping_list: 'suppliers',
  staff: 'ops_pro',
  tip_split: 'ops_pro',
  close_report: 'ops_pro',
  kitchen_display: 'ops_pro',
  autopilot: 'autopilot',
  table_details: null,
};

/** Funciones que necesitan otra encendida */
export const FEATURE_REQUIRES: Partial<Record<FeatureKey, FeatureKey>> = { tip_split: 'staff' };

export const STAFF_GROUPS = ['WAITER', 'CASHIER', 'KITCHEN', 'BAR', 'OTHER'] as const;
export type StaffGroup = typeof STAFF_GROUPS[number];

export interface TipRules {
  /** Porcentaje del total para cada grupo; suman 100 */
  groups: Record<StaffGroup, number>;
  /** Entre meseros: partes iguales o según lo que cada uno aportó */
  waiterMode: 'EQUAL' | 'CONTRIBUTION';
  period: 'WEEK' | 'SESSION' | 'MONTH';
}

export interface AlertSettings {
  idle: boolean; idleMin: number;   // sin pedir otra ronda
  ready: boolean; readyMin: number; // salió de cocina y no pide cuenta (necesita visor de cocina)
  bill: boolean; billMin: number;   // pidió la cuenta y no se cobra
}

export interface FeatureSettings {
  flags: Record<FeatureKey, boolean>;
  alerts: AlertSettings;
  quickNotes: string[];
  ownerWhatsapp: string;
  reportEmail: string;
  tips: TipRules;
  /** El ADMIN ya vio la pantalla de novedades de la 3.0 */
  seenWhatsNew: boolean;
  /** Margen bruto mínimo de los productos con receta; por debajo, alerta (sin tocar el precio) */
  minMarginPct: number;
}

export const DEFAULT_QUICK_NOTES = ['Para llevar', 'Sin picante', 'Término medio', 'Bien cocido', 'Sin hielo', 'Sin azúcar', 'Aparte'];

export const DEFAULT_ALERTS: AlertSettings = { idle: true, idleMin: 20, ready: true, readyMin: 30, bill: true, billMin: 7 };

export const DEFAULT_TIP_RULES: TipRules = {
  groups: { WAITER: 100, CASHIER: 0, KITCHEN: 0, BAR: 0, OTHER: 0 },
  waiterMode: 'EQUAL',
  period: 'WEEK',
};

const int = (v: unknown, min: number, max: number, fallback: number) => {
  const n = Math.round(Number(v));
  return Number.isFinite(n) && n >= min && n <= max ? n : fallback;
};

const text = (v: unknown, max: number) => (typeof v === 'string' ? v.trim().slice(0, max) : '');

const normalizeTipRules = (raw: unknown): TipRules => {
  const src = raw && typeof raw === 'object' ? (raw as Record<string, any>) : {};
  const g = src.groups && typeof src.groups === 'object' ? src.groups : {};
  const groups = {} as Record<StaffGroup, number>;
  for (const k of STAFF_GROUPS) groups[k] = int(g[k], 0, 100, 0);
  const sum = STAFF_GROUPS.reduce((a, k) => a + groups[k], 0);
  return {
    groups: sum === 100 ? groups : { ...DEFAULT_TIP_RULES.groups },
    waiterMode: src.waiterMode === 'CONTRIBUTION' ? 'CONTRIBUTION' : 'EQUAL',
    period: src.period === 'SESSION' || src.period === 'MONTH' ? src.period : 'WEEK',
  };
};

export const normalizeFeatures = (raw: unknown): FeatureSettings => {
  const src = raw && typeof raw === 'object' ? (raw as Record<string, any>) : {};
  const f = src.flags && typeof src.flags === 'object' ? src.flags : {};
  const flags = {} as Record<FeatureKey, boolean>;
  for (const k of FEATURE_KEYS) flags[k] = f[k] === true;
  // Una función que depende de otra apagada no puede quedar encendida
  for (const k of FEATURE_KEYS) {
    const need = FEATURE_REQUIRES[k];
    if (need && !flags[need]) flags[k] = false;
  }
  const a = src.alerts && typeof src.alerts === 'object' ? src.alerts : {};
  const notes = Array.isArray(src.quickNotes)
    ? [...new Set(src.quickNotes.map((n: unknown) => text(n, 30)).filter(Boolean))].slice(0, 16) as string[]
    : [...DEFAULT_QUICK_NOTES];
  return {
    flags,
    alerts: {
      idle: a.idle !== false, idleMin: int(a.idleMin, 1, 240, DEFAULT_ALERTS.idleMin),
      ready: a.ready !== false, readyMin: int(a.readyMin, 1, 240, DEFAULT_ALERTS.readyMin),
      bill: a.bill !== false, billMin: int(a.billMin, 1, 120, DEFAULT_ALERTS.billMin),
    },
    quickNotes: notes,
    ownerWhatsapp: text(src.ownerWhatsapp, 20).replace(/[^0-9+]/g, ''),
    reportEmail: /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(text(src.reportEmail, 120)) ? text(src.reportEmail, 120) : '',
    tips: normalizeTipRules(src.tips),
    seenWhatsNew: src.seenWhatsNew === true,
    minMarginPct: Number.isFinite(Number(src.minMarginPct)) && src.minMarginPct !== null && src.minMarginPct !== undefined && src.minMarginPct !== '' ? Math.min(95, Math.max(0, Math.round(Number(src.minMarginPct)))) : 30,
  };
};

export const parseFeatures = (json: string | null | undefined): FeatureSettings => {
  try {
    return normalizeFeatures(json ? JSON.parse(json) : {});
  } catch {
    return normalizeFeatures({});
  }
};

export const featureOn = (s: FeatureSettings, key: FeatureKey): boolean => s.flags[key] === true;

/** Lista de nombres limpia (ingredientes de un producto, ingredientes quitados) */
export const normalizeNames = (raw: unknown, max = 24): string[] => {
  let list: unknown = raw;
  if (typeof raw === 'string') {
    try { list = JSON.parse(raw); } catch { list = []; }
  }
  if (!Array.isArray(list)) return [];
  const seen = new Set<string>();
  const out: string[] = [];
  for (const item of list) {
    const name = text(item, 40);
    const key = name.toLowerCase();
    if (!name || seen.has(key)) continue;
    seen.add(key);
    out.push(name);
    if (out.length >= max) break;
  }
  return out;
};
