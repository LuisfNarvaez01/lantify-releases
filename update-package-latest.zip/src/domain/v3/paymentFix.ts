// ============================================
// DOMAIN - Corregir el medio de pago de una venta (Lantify 3.0)
// ============================================
// Lo cobrado no cambia (venta + propina); solo cómo se pagó. La propina viaja
// dentro de los pagos, así que sigue al medio de pago. Reglas puras para que el
// caso de uso y las pruebas compartan la misma decisión.

export const PAYMENT_METHODS = ['CASH', 'CARD', 'TRANSFER'] as const;
export type PaymentMethod = typeof PAYMENT_METHODS[number];

export interface PaymentPart { method: PaymentMethod; amount: number }

export interface FixContext {
  saleStatus: string;
  /** Lo cobrado: venta + propina */
  due: number;
  /** ¿Todos los turnos de caja donde la venta tiene pagos siguen abiertos? */
  sessionsOpen: boolean;
  /** Factura electrónica ya transmitida o aceptada */
  invoiceSent: boolean;
  current: PaymentPart[];
}

export type FixError = 'NOT_COMPLETED' | 'SESSION_CLOSED' | 'INVOICE_SENT' | 'BAD_PARTS' | 'TOTAL_MISMATCH' | 'NO_CHANGE' | 'REASON_REQUIRED';

const cents = (n: number) => Math.round(n * 100);

export const cashOf = (parts: PaymentPart[]) => parts.filter((p) => p.method === 'CASH').reduce((a, p) => a + p.amount, 0);

/** Medio de pago que resume la venta (el que guarda Sale.paymentMethod) */
export const summaryMethod = (parts: PaymentPart[]): string => {
  const used = [...new Set(parts.filter((p) => p.amount > 0).map((p) => p.method))];
  return used.length === 1 ? used[0] : 'MIXED';
};

/** Cómo quedó registrada la venta: sus pagos, o un solo pago con el medio de la venta */
export const currentParts = (payments: { paymentMethod: string; amount: number }[], sale: { paymentMethod: string; total: number; tip: number }): PaymentPart[] => {
  const asMethod = (m: string): PaymentMethod => (m === 'CASH' || m === 'CARD' ? m : 'TRANSFER');
  if (payments.length) return payments.map((p) => ({ method: asMethod(p.paymentMethod), amount: p.amount }));
  return [{ method: asMethod(sale.paymentMethod), amount: sale.total + (sale.tip || 0) }];
};

export const validateFix = (ctx: FixContext, next: PaymentPart[], reason: string): FixError | null => {
  if (ctx.saleStatus !== 'COMPLETED') return 'NOT_COMPLETED';
  if (!ctx.sessionsOpen) return 'SESSION_CLOSED';
  if (ctx.invoiceSent) return 'INVOICE_SENT';
  if (!reason || reason.trim().length < 3) return 'REASON_REQUIRED';
  if (!next.length || next.some((p) => !PAYMENT_METHODS.includes(p.method) || !(p.amount > 0))) return 'BAD_PARTS';
  if (cents(next.reduce((a, p) => a + p.amount, 0)) !== cents(ctx.due)) return 'TOTAL_MISMATCH';
  const key = (parts: PaymentPart[]) => PAYMENT_METHODS.map((m) => cents(parts.filter((p) => p.method === m).reduce((a, p) => a + p.amount, 0))).join('|');
  if (key(next) === key(ctx.current)) return 'NO_CHANGE';
  return null;
};

/** Cuánto sube (+) o baja (−) el efectivo esperado de la caja */
export const cashDelta = (current: PaymentPart[], next: PaymentPart[]) => cashOf(next) - cashOf(current);
