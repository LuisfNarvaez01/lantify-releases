// ============================================
// DOMAIN - Ingredientes, recetas y kardex (Lantify 3.0)
// ============================================
// Cada ingrediente vive en una unidad base (g, ml o und). Las compras llegan en
// la unidad de la factura (kg, lb, l, caja…) y se convierten. El costo es el
// promedio ponderado (CPP); el precio de venta nunca se toca solo.

export type BaseUnit = 'g' | 'ml' | 'und';
export const BASE_UNITS: BaseUnit[] = ['g', 'ml', 'und'];

export type MovementType = 'PURCHASE' | 'SALE_CONSUMPTION' | 'VOID_RETURN' | 'WASTE' | 'ADJUSTMENT' | 'COUNT';
export const MOVEMENT_TYPES: MovementType[] = ['PURCHASE', 'SALE_CONSUMPTION', 'VOID_RETURN', 'WASTE', 'ADJUSTMENT', 'COUNT'];

/** Unidades de compra que se convierten solas a la unidad base */
const FACTORS: Record<string, { base: BaseUnit; factor: number }> = {
  g: { base: 'g', factor: 1 }, gr: { base: 'g', factor: 1 }, gramo: { base: 'g', factor: 1 }, gramos: { base: 'g', factor: 1 },
  kg: { base: 'g', factor: 1000 }, kilo: { base: 'g', factor: 1000 }, kilos: { base: 'g', factor: 1000 }, kilogramo: { base: 'g', factor: 1000 },
  lb: { base: 'g', factor: 500 }, libra: { base: 'g', factor: 500 }, libras: { base: 'g', factor: 500 }, // en Colombia la libra comercial es 500 g
  arroba: { base: 'g', factor: 12500 },
  ml: { base: 'ml', factor: 1 }, cc: { base: 'ml', factor: 1 },
  l: { base: 'ml', factor: 1000 }, lt: { base: 'ml', factor: 1000 }, litro: { base: 'ml', factor: 1000 }, litros: { base: 'ml', factor: 1000 },
  galon: { base: 'ml', factor: 3785 }, 'galón': { base: 'ml', factor: 3785 },
  und: { base: 'und', factor: 1 }, un: { base: 'und', factor: 1 }, unidad: { base: 'und', factor: 1 }, unidades: { base: 'und', factor: 1 },
  docena: { base: 'und', factor: 12 },
};

export const normalizeUnit = (u: unknown) => (typeof u === 'string' ? u.trim().toLowerCase().replace(/\.$/, '') : '');

/**
 * Factor para pasar de la unidad de compra a la unidad base del ingrediente.
 * Caja, paquete o bulto no tienen factor fijo: null (lo dice el usuario y queda en el alias).
 */
export const conversionFactor = (purchaseUnit: unknown, base: BaseUnit): number | null => {
  const f = FACTORS[normalizeUnit(purchaseUnit)];
  return f && f.base === base ? f.factor : null;
};

/** Costo promedio ponderado después de una compra (por unidad base) */
export const weightedAverage = (stock: number, avgCost: number, inQty: number, inUnitCost: number) => {
  if (inQty <= 0) return avgCost;
  if (stock <= 0 || avgCost <= 0) return round4(inUnitCost);
  return round4((stock * avgCost + inQty * inUnitCost) / (stock + inQty));
};

export const round4 = (n: number) => Math.round(n * 10000) / 10000;
export const round2 = (n: number) => Math.round(n * 100) / 100;

export interface RecipeLine { ingredientId: string; quantity: number; avgCost: number }

export const recipeCost = (lines: RecipeLine[]) => Math.round(lines.reduce((n, l) => n + l.quantity * l.avgCost, 0));

/** Margen bruto % (null sin precio) */
export const marginPct = (price: number, cost: number) => (price > 0 ? round2(((price - cost) / price) * 100) : null);

/** Cuánto de cada ingrediente consumen las líneas vendidas */
export const consumption = (sold: { productId: string; quantity: number }[], recipes: Map<string, { ingredientId: string; quantity: number }[]>) => {
  const out = new Map<string, number>();
  for (const s of sold) {
    for (const r of recipes.get(s.productId) || []) out.set(r.ingredientId, round4((out.get(r.ingredientId) || 0) + r.quantity * s.quantity));
  }
  return out;
};

/** Variación del costo por unidad base frente al último (en %) */
export const costChangePct = (last: number | null | undefined, next: number) => (last && last > 0 ? round2(((next - last) / last) * 100) : null);

export const DEFAULT_MIN_MARGIN = 30;
