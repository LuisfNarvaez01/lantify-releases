// ============================================
// DOMAIN - Autopilot (Lantify 3.0 · bloque 4)
// ============================================
// 1) Modelo del negocio: lo normal por día de la semana y franja, tiempos de
//    cocina y capacidad observada, a partir del historial local.
// 2) Situaciones: compara el momento actual contra lo normal y propone
//    intervenciones que Lantify puede ejecutar. Reglas y estadística, sin IA:
//    funciona sin internet y responde al instante.

import { quantile } from './menuEngine';

const DAY = 86_400_000;
const SLOT_MIN = 15;
export const MIN_HISTORY_DAYS = 14;

/** Umbrales de las reglas (un solo lugar para ajustarlos) */
export const RULES = {
  kitchenMinOpen: 4,
  kitchenAgeFactor: 1,       // edad promedio > p80 normal × factor
  kitchenHighFactor: 1.5,
  peakPaceFactor: 1.4,       // ritmo de 30 min > lo normal × factor
  stockCover: 0.9,           // existencias < demanda esperada × factor
  stockMinDemand: 2,
  waiterOverloadFactor: 2,
  waiterMinTables: 4,
  slowPaceFactor: 0.5,
  slowMinNormalSales: 3,
  tablesWaiting: 3,
  expireMin: 30,
};

export interface HistorySale { at: Date; total: number }
export interface HistoryTicket { sentAt: Date; readyAt: Date | null }

export interface SlotNormal { sales: number; revenue: number; tickets: number }

export interface AutopilotModel {
  builtAt: string;
  /** Días distintos con ventas en el periodo */
  historyDays: number;
  firstSaleAt: string | null;
  ready: boolean;
  /** [díaSemana 0–6][franja 0–95] → mediana de las semanas */
  slots: SlotNormal[][];
  /** [díaSemana][hora] → minutos de comanda en cocina */
  prep: ({ median: number; p80: number } | null)[][];
  prepAll: { median: number; p80: number } | null;
  /** Comandas en 30 min que la cocina sostiene sin que el tiempo se dispare */
  capacity30: number | null;
}

const slotOf = (d: Date) => d.getHours() * 4 + Math.floor(d.getMinutes() / SLOT_MIN);
const dayKey = (d: Date) => `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
const median = (v: number[]) => quantile(v, 0.5) ?? 0;

export const buildModel = (sales: HistorySale[], tickets: HistoryTicket[], now: Date, weeks = 8): AutopilotModel => {
  const from = new Date(now.getTime() - weeks * 7 * DAY);
  const s = sales.filter((x) => x.at >= from && x.at <= now);
  const t = tickets.filter((x) => x.sentAt >= from && x.sentAt <= now);

  // Por cada fecha y franja: ventas, ingresos y comandas
  const perDay = new Map<string, { wd: number; slots: SlotNormal[] }>();
  const bucket = (d: Date) => {
    const k = dayKey(d);
    let v = perDay.get(k);
    if (!v) { v = { wd: d.getDay(), slots: Array.from({ length: 96 }, () => ({ sales: 0, revenue: 0, tickets: 0 })) }; perDay.set(k, v); }
    return v.slots[slotOf(d)];
  };
  for (const x of s) { const b = bucket(x.at); b.sales += 1; b.revenue += x.total; }
  for (const x of t) bucket(x.sentAt).tickets += 1;

  const days = [...perDay.values()];
  const slots: SlotNormal[][] = Array.from({ length: 7 }, (_, wd) => {
    const same = days.filter((d) => d.wd === wd);
    return Array.from({ length: 96 }, (_, i) => ({
      sales: median(same.map((d) => d.slots[i].sales)),
      revenue: Math.round(median(same.map((d) => d.slots[i].revenue))),
      tickets: median(same.map((d) => d.slots[i].tickets)),
    }));
  });

  const durations = t.filter((x) => x.readyAt).map((x) => ({ at: x.sentAt, min: (x.readyAt!.getTime() - x.sentAt.getTime()) / 60_000 })).filter((x) => x.min > 0 && x.min < 180);
  const prep = Array.from({ length: 7 }, (_, wd) => Array.from({ length: 24 }, (_, h) => {
    const v = durations.filter((x) => x.at.getDay() === wd && x.at.getHours() === h).map((x) => x.min);
    return v.length >= 5 ? { median: median(v), p80: quantile(v, 0.8)! } : null;
  }));
  const all = durations.map((x) => x.min);
  const prepAll = all.length >= 5 ? { median: median(all), p80: quantile(all, 0.8)! } : null;

  // Capacidad: comandas por media hora en las franjas donde la cocina siguió a tiempo
  let capacity30: number | null = null;
  if (prepAll) {
    const per30 = new Map<string, { n: number; late: number }>();
    for (const x of durations) {
      const k = `${dayKey(x.at)}-${Math.floor(slotOf(x.at) / 2)}`;
      const v = per30.get(k) || { n: 0, late: 0 };
      v.n += 1;
      if (x.min > prepAll.p80) v.late += 1;
      per30.set(k, v);
    }
    const onTime = [...per30.values()].filter((v) => v.n >= 2 && v.late / v.n < 0.3).map((v) => v.n);
    capacity30 = onTime.length >= 5 ? Math.max(...onTime) : null;
  }

  const historyDays = days.filter((d) => d.slots.some((x) => x.sales > 0)).length;
  const first = s.reduce<Date | null>((m, x) => (!m || x.at < m ? x.at : m), null);
  return { builtAt: now.toISOString(), historyDays, firstSaleAt: first?.toISOString() ?? null, ready: historyDays >= MIN_HISTORY_DAYS, slots, prep, prepAll, capacity30 };
};

/** Lo normal para las próximas/últimas `minutes` desde `at` (suma de franjas) */
export const normalWindow = (m: AutopilotModel, at: Date, minutes: number, direction: 'past' | 'next') => {
  const n = Math.max(1, Math.round(minutes / SLOT_MIN));
  let sales = 0; let revenue = 0; let tickets = 0;
  for (let i = 0; i < n; i++) {
    const d = new Date(at.getTime() + (direction === 'next' ? i : -(i + 1)) * SLOT_MIN * 60_000);
    const x = m.slots[d.getDay()][slotOf(d)];
    sales += x.sales; revenue += x.revenue; tickets += x.tickets;
  }
  return { sales, revenue, tickets };
};

export const prepNormal = (m: AutopilotModel, at: Date) => m.prep[at.getDay()][at.getHours()] || m.prepAll;

// ── Situaciones ──

export type SituationKind = 'kitchen_load' | 'peak_coming' | 'stockout' | 'waiter_overload' | 'slow_hour' | 'tables_waiting';
export type InterventionKind = 'boost_products' | 'pause_products' | 'notify_staff' | 'flash_coupon' | 'call_staff';
export type Role = 'ADMIN' | 'CASHIER' | 'WAITER';

export interface Intervention {
  id: string;
  kind: InterventionKind;
  params: Record<string, any>;
  /** Se revierte sola a los N minutos (null = no aplica) */
  revertMin: number | null;
}

export interface Situation {
  /** Estable mientras dure la situación (para no repetirla) */
  key: string;
  kind: SituationKind;
  severity: 'medium' | 'high';
  evidence: Record<string, number | string | null>;
  interventions: Intervention[];
}

export interface LiveState {
  now: Date;
  openTickets: { ageMin: number }[];
  ticketsLast30: number;
  salesLast60: number;
  tableAlerts: number;
  waiterLoads: { waiterId: string; name: string; tables: number }[];
  stock: { productId: string; name: string; stock: number; expectedRest: number }[];
  /** Productos ordenados por tiempo de preparación (mediana) */
  fastProducts: string[];
  slowProducts: string[];
  puzzles: string[];
}

export const detect = (m: AutopilotModel, live: LiveState): Situation[] => {
  const out: Situation[] = [];
  const now = live.now;
  const prep = prepNormal(m, now);

  // Cocina saturándose
  const open = live.openTickets.length;
  const avgAge = open ? Math.round(live.openTickets.reduce((n, x) => n + x.ageMin, 0) / open) : 0;
  if (open >= RULES.kitchenMinOpen && prep && avgAge > prep.p80 * RULES.kitchenAgeFactor) {
    const high = avgAge > prep.p80 * RULES.kitchenHighFactor;
    out.push({
      key: 'kitchen_load',
      kind: 'kitchen_load',
      severity: high ? 'high' : 'medium',
      evidence: { open, avgAge, normalP80: Math.round(prep.p80) },
      interventions: [
        ...(live.fastProducts.length ? [{ id: 'boost_fast', kind: 'boost_products' as const, params: { productIds: live.fastProducts.slice(0, 3), minutes: 60 }, revertMin: 60 }] : []),
        ...(live.slowProducts.length ? [{ id: 'pause_slow', kind: 'pause_products' as const, params: { productIds: live.slowProducts.slice(0, 3), minutes: 45 }, revertMin: 45 }] : []),
        { id: 'tell_wait', kind: 'notify_staff', params: { message: 'kitchen_wait', minutes: avgAge }, revertMin: null },
      ],
    });
  }

  // Viene un pico
  if (m.ready && m.capacity30) {
    const past = normalWindow(m, now, 30, 'past');
    const next = normalWindow(m, now, 30, 'next');
    const pace = live.ticketsLast30;
    const projected = Math.max(pace, next.tickets);
    if (pace >= Math.max(2, past.tickets * RULES.peakPaceFactor) && projected > m.capacity30 && !out.some((s) => s.kind === 'kitchen_load')) {
      out.push({
        key: 'peak_coming',
        kind: 'peak_coming',
        severity: projected > m.capacity30 * 1.3 ? 'high' : 'medium',
        evidence: { pace, normalPace: Math.round(past.tickets), capacity: m.capacity30, projected },
        interventions: [
          ...(live.slowProducts.length ? [{ id: 'pause_slow', kind: 'pause_products' as const, params: { productIds: live.slowProducts.slice(0, 3), minutes: 30 }, revertMin: 30 }] : []),
          { id: 'tell_peak', kind: 'notify_staff', params: { message: 'peak' }, revertMin: null },
          { id: 'call_staff', kind: 'call_staff', params: {}, revertMin: null },
        ],
      });
    }
  }

  // Se va a acabar
  for (const p of live.stock) {
    if (p.expectedRest < RULES.stockMinDemand || p.stock >= p.expectedRest * RULES.stockCover) continue;
    out.push({
      key: `stockout:${p.productId}`,
      kind: 'stockout',
      severity: p.stock <= p.expectedRest * 0.4 ? 'high' : 'medium',
      evidence: { product: p.name, productId: p.productId, stock: p.stock, expected: Math.round(p.expectedRest) },
      interventions: [
        { id: 'pause_it', kind: 'pause_products', params: { productIds: [p.productId], untilClose: true }, revertMin: null },
        { id: 'tell_stock', kind: 'notify_staff', params: { message: 'stock_low', product: p.name, stock: p.stock }, revertMin: null },
      ],
    });
  }

  // Mesero sobrecargado
  const loads = live.waiterLoads.filter((w) => w.tables > 0);
  if (loads.length >= 2) {
    const med = median(loads.map((w) => w.tables));
    const least = [...loads].sort((a, b) => a.tables - b.tables)[0];
    for (const w of loads) {
      if (w.tables >= RULES.waiterMinTables && w.tables >= med * RULES.waiterOverloadFactor && w.waiterId !== least.waiterId) {
        out.push({
          key: `waiter_overload:${w.waiterId}`,
          kind: 'waiter_overload',
          severity: 'medium',
          evidence: { waiter: w.name, tables: w.tables, median: med, helper: least.name },
          interventions: [{ id: 'ask_help', kind: 'notify_staff', params: { message: 'help_waiter', waiter: w.name, helper: least.name }, revertMin: null }],
        });
      }
    }
  }

  // Hora floja
  if (m.ready) {
    const normal = normalWindow(m, now, 60, 'past');
    if (normal.sales >= RULES.slowMinNormalSales && live.salesLast60 < normal.sales * RULES.slowPaceFactor) {
      out.push({
        key: 'slow_hour',
        kind: 'slow_hour',
        severity: 'medium',
        evidence: { sales: live.salesLast60, normal: Math.round(normal.sales) },
        interventions: [
          { id: 'flash', kind: 'flash_coupon', params: { percent: 10, hours: 2 }, revertMin: null },
          ...(live.puzzles.length ? [{ id: 'boost_puzzles', kind: 'boost_products' as const, params: { productIds: live.puzzles.slice(0, 3), minutes: 120 }, revertMin: 120 }] : []),
        ],
      });
    }
  }

  // Mesas esperando
  if (live.tableAlerts >= RULES.tablesWaiting) {
    out.push({
      key: 'tables_waiting',
      kind: 'tables_waiting',
      severity: live.tableAlerts >= RULES.tablesWaiting * 2 ? 'high' : 'medium',
      evidence: { tables: live.tableAlerts },
      interventions: [{ id: 'tell_tables', kind: 'notify_staff', params: { message: 'tables_waiting', tables: live.tableAlerts }, revertMin: null }],
    });
  }
  return out;
};

// ── Quién ve qué ──

const SEE: Record<SituationKind, Role[]> = {
  kitchen_load: ['ADMIN', 'CASHIER'],
  peak_coming: ['ADMIN', 'CASHIER'],
  stockout: ['ADMIN', 'CASHIER'],
  waiter_overload: ['ADMIN', 'CASHIER'],
  slow_hour: ['ADMIN'],
  tables_waiting: ['ADMIN', 'CASHIER'],
};
const DECIDE: Record<InterventionKind, Role[]> = {
  boost_products: ['ADMIN', 'CASHIER'],
  pause_products: ['ADMIN', 'CASHIER'],
  notify_staff: ['ADMIN', 'CASHIER'],
  flash_coupon: ['ADMIN'],
  call_staff: ['ADMIN', 'CASHIER'],
};
/** Cifras de ventas que el cajero no ve */
const MONEY_KEYS = ['normal', 'sales', 'revenue'];

export const canSee = (role: string, kind: SituationKind) => SEE[kind].includes(role as Role);
export const canDecide = (role: string, kind: InterventionKind) => DECIDE[kind].includes(role as Role);

export const forRole = (role: string, s: Situation): Situation | null => {
  if (!canSee(role, s.kind)) return null;
  if (role === 'ADMIN') return s;
  const evidence = Object.fromEntries(Object.entries(s.evidence).filter(([k]) => !(s.kind === 'slow_hour' && MONEY_KEYS.includes(k))));
  return { ...s, evidence, interventions: s.interventions.filter((i) => canDecide(role, i.kind)) };
};
