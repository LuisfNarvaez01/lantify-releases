// ============================================
// DOMAIN - Informe de cierre de caja para imprimir (tirilla tipo datáfono)
// ============================================
// Toma la estructura del antiguo "comprobante de informe diario" de la DIAN
// (rango de numeración, totales por medio de pago e impuestos, anulaciones) porque
// es lo que un inspector espera ver. Hoy es un documento de control interno.

export interface ClosingSaleRow {
  code: string;
  createdAt: string;
  place: string;
  method: string;
  total: number;
  tip: number;
  discount: number;
  status: string;
  note?: string | null;
  items: { taxType: string; taxRate: number; taxAmount: number; total: number; isCancelled?: boolean }[];
}

export interface ClosingMovement { createdAt: string; motive: string; amount: number; fromDrawer?: boolean }

export interface ClosingTicketInput {
  sessionNumber: string;
  registerCode: string;
  openedAt: string;
  closedAt: string | null;
  openedBy: string | null;
  closedBy: string | null;
  initialBalance: number;
  expected: number;
  counted: number | null;
  sales: ClosingSaleRow[];
  payments: { method: string; amount: number }[];
  incomes: ClosingMovement[];
  expenses: ClosingMovement[];
}

export interface ClosingTicket extends Omit<ClosingTicketInput, 'payments'> {
  range: { first: string | null; last: string | null; count: number };
  completedCount: number;
  grossTotal: number;
  discounts: number;
  tips: number;
  taxes: { taxType: string; taxRate: number; base: number; amount: number }[];
  byMethod: { method: string; amount: number }[];
  cancelled: { count: number; total: number };
  incomesTotal: number;
  expensesTotal: number;
  difference: number | null;
}

const round = (n: number) => Math.round(n * 100) / 100;

export function buildClosingTicket(input: ClosingTicketInput): ClosingTicket {
  const sales = [...input.sales].sort((a, b) => a.createdAt.localeCompare(b.createdAt));
  const done = sales.filter((s) => s.status === 'COMPLETED');
  const cancelled = sales.filter((s) => s.status === 'CANCELLED');

  const taxMap = new Map<string, { taxType: string; taxRate: number; base: number; amount: number }>();
  for (const s of done) {
    for (const it of s.items) {
      if (it.isCancelled || !it.taxType || it.taxType === 'NONE' || !(it.taxAmount > 0)) continue;
      const key = `${it.taxType}:${it.taxRate}`;
      const row = taxMap.get(key) ?? { taxType: it.taxType, taxRate: it.taxRate, base: 0, amount: 0 };
      row.amount += it.taxAmount;
      row.base += it.total - it.taxAmount;
      taxMap.set(key, row);
    }
  }

  const methods = new Map<string, number>();
  for (const p of input.payments) methods.set(p.method, (methods.get(p.method) ?? 0) + p.amount);

  const sum = <T,>(list: T[], f: (x: T) => number) => list.reduce((a, x) => a + (f(x) || 0), 0);
  const incomesTotal = sum(input.incomes, (x) => x.amount);
  const expensesTotal = sum(input.expenses, (x) => x.amount);

  const { payments: _p, ...rest } = input;
  return {
    ...rest,
    sales,
    range: { first: sales[0]?.code ?? null, last: sales[sales.length - 1]?.code ?? null, count: sales.length },
    completedCount: done.length,
    grossTotal: round(sum(done, (s) => s.total)),
    discounts: round(sum(done, (s) => s.discount)),
    tips: round(sum(done, (s) => s.tip)),
    taxes: [...taxMap.values()].map((t) => ({ ...t, base: round(t.base), amount: round(t.amount) })).sort((a, b) => a.taxType.localeCompare(b.taxType) || a.taxRate - b.taxRate),
    byMethod: [...methods.entries()].map(([method, amount]) => ({ method, amount: round(amount) })).sort((a, b) => b.amount - a.amount),
    cancelled: { count: cancelled.length, total: round(sum(cancelled, (s) => s.total)) },
    incomesTotal: round(incomesTotal),
    expensesTotal: round(expensesTotal),
    difference: input.counted === null ? null : round(input.counted - input.expected),
  };
}
