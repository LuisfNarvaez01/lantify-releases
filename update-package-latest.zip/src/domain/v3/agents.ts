// ============================================
// DOMAIN - Agentes de IA especializados (Lantify 3.0 · bloque 3)
// ============================================
// Lo comparten el programa, el servidor local y el worker de IA:
//  - el perfil del negocio que la IA debe conocer,
//  - las tareas listas de cada agente (qué analizar y cómo responder),
//  - el vocabulario según el tipo de negocio,
//  - el texto de un flyer (la IA nunca dibuja texto dentro de una imagen),
//  - cómo separar la respuesta en vivo (Markdown) de sus datos (bloque ```json final).

export type AgentId = 'backoffice' | 'purchasing' | 'marketing';

const str = (v: unknown, max: number) => (typeof v === 'string' ? v.trim().replace(/\s+/g, ' ').slice(0, max) : '');
const num = (v: unknown) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
};
const HEX = /^#[0-9a-f]{6}$/i;

// ── Perfil del negocio ──

export interface AiProfile {
  /** Qué vende o qué servicio presta, en palabras del dueño */
  offer: string;
  /** A quién le vende */
  audience: string;
  /** Qué lo hace distinto */
  difference: string;
  /** Tono de voz para los textos */
  tone: 'cercano' | 'profesional' | 'divertido' | 'elegante';
  /** Colores de marca para flyers [principal, acento] */
  colors: [string, string];
  instagram: string;
  whatsapp: string;
}

export const AI_TONES: AiProfile['tone'][] = ['cercano', 'profesional', 'divertido', 'elegante'];

export const EMPTY_AI_PROFILE: AiProfile = {
  offer: '', audience: '', difference: '', tone: 'cercano', colors: ['#1d4ed8', '#f59e0b'], instagram: '', whatsapp: '',
};

export const normalizeAiProfile = (raw: unknown): AiProfile => {
  const r = (raw && typeof raw === 'object' ? raw : {}) as Record<string, any>;
  const colors = Array.isArray(r.colors) ? r.colors : [];
  return {
    offer: str(r.offer, 400),
    audience: str(r.audience, 200),
    difference: str(r.difference, 200),
    tone: AI_TONES.includes(r.tone) ? r.tone : 'cercano',
    colors: [HEX.test(colors[0]) ? colors[0] : EMPTY_AI_PROFILE.colors[0], HEX.test(colors[1]) ? colors[1] : EMPTY_AI_PROFILE.colors[1]],
    instagram: str(r.instagram, 40).replace(/^@+/, '').replace(/[^\w.]/g, ''),
    whatsapp: str(r.whatsapp, 20).replace(/[^\d+]/g, ''),
  };
};

export const parseAiProfile = (json: string | null | undefined): AiProfile => {
  try {
    return normalizeAiProfile(json ? JSON.parse(json) : null);
  } catch {
    return { ...EMPTY_AI_PROFILE };
  }
};

/** ¿El perfil tiene lo mínimo para que la IA hable del negocio con propiedad? */
export const profileReady = (p: AiProfile) => p.offer.length >= 10;

// ── Vocabulario según el tipo de negocio ──

export type BusinessKind = 'food' | 'retail' | 'services';

export const kindOf = (businessType: string | null | undefined): BusinessKind =>
  businessType === 'SERVICES' ? 'services' : businessType === 'RETAIL' ? 'retail' : 'food';

export const VOCAB: Record<BusinessKind, { items: string; item: string; place: string; supplies: string; client: string }> = {
  food: { items: 'platos y bebidas de la carta', item: 'producto', place: 'restaurante', supplies: 'insumos e ingredientes', client: 'comensal' },
  retail: { items: 'productos del catálogo', item: 'producto', place: 'tienda', supplies: 'mercancía', client: 'cliente' },
  services: { items: 'servicios', item: 'servicio', place: 'negocio de servicios', supplies: 'insumos y materiales', client: 'cliente' },
};

// ── Tareas listas ──

export interface AgentTask {
  id: string;
  agent: AgentId;
  /** Método de análisis y forma de la respuesta (instrucción para el modelo) */
  focus: string;
  /** Produce un flyer además del texto */
  flyer?: boolean;
}

export const AGENT_TASKS: AgentTask[] = [
  // Administración: analista financiero
  { id: 'semana', agent: 'backoffice', focus: 'Compara esta semana contra la anterior: ventas, tickets, ticket promedio y propinas. Di qué subió, qué bajó y la causa más probable según los datos (día, hora, producto). Incluye un gráfico de ventas por día de ambas semanas.' },
  { id: 'margen', agent: 'backoffice', focus: 'Encuentra los productos o servicios con margen bajo o sin costo cargado. Ordena por plata que se deja de ganar (ventas × margen faltante). Para cada uno: subir precio, bajar costo o dejar de empujarlo. Incluye un gráfico de margen por producto.' },
  { id: 'horas', agent: 'backoffice', focus: 'Identifica los días y franjas horarias flojas y fuertes. Calcula cuánto se vende por hora en cada franja. Propón cómo llenar las horas flojas y cómo atender mejor las fuertes. Incluye un gráfico de ventas por hora.' },
  { id: 'proyeccion', agent: 'backoffice', focus: 'Proyecta las ventas del mes con el ritmo diario actual y compáralas con el mes anterior. Di cuánto falta para igualarlo y cuánto hay que vender por día. Incluye un gráfico de ventas acumuladas.' },
  { id: 'gastos', agent: 'backoffice', focus: 'Revisa los gastos por categoría contra el periodo anterior. Señala los que crecieron más que las ventas y propone dónde recortar.' },
  // Compras
  { id: 'lista', agent: 'purchasing', focus: 'Arma la lista de compras de la semana agrupada por proveedor, con cantidades redondeadas a la unidad de compra y el costo estimado. Prioriza lo que se agota primero. Propón una orden de compra por proveedor.' },
  { id: 'agota', agent: 'purchasing', focus: 'Lista lo que se agota en los próximos 7 días según el consumo diario, con los días de cobertura de cada uno, del más urgente al menos urgente.' },
  { id: 'precios', agent: 'purchasing', focus: 'Compara los precios de los proveedores para los mismos productos e insumos. Di dónde conviene comprar cada uno y cuánto se ahorra al mes.' },
  { id: 'quieto', agent: 'purchasing', focus: 'Encuentra inventario sin movimiento o con mucha cobertura (plata quieta). Estima cuánto dinero hay ahí y propone cómo moverlo.' },
  // Marketing
  { id: 'flyer', agent: 'marketing', flyer: true, focus: 'Diseña el texto de un flyer para la promoción que pida el usuario (si no dice cuál, elige el producto o servicio con mejor margen y tendencia). Explica en 2 frases por qué esa oferta y para qué canal. Incluye el flyer.' },
  { id: 'dia_flojo', agent: 'marketing', focus: 'Toma el día y la franja más flojos y diseña una campaña para llenarlos: oferta concreta, a quién, por qué canal y el texto listo para publicar. Cuida el margen.' },
  { id: 'textos', agent: 'marketing', focus: 'Escribe 3 publicaciones listas para esta semana (WhatsApp, Instagram y estado), cada una con su día sugerido, basadas en lo que más se vende y lo que conviene empujar.' },
  { id: 'regreso', agent: 'marketing', focus: 'Diseña una campaña para que vuelvan los clientes que dejaron de venir: mensaje, beneficio y un cupón con vigencia corta.' },
  { id: 'empujar', agent: 'marketing', focus: 'Elige el producto o servicio que más conviene empujar (buen margen, tendencia al alza o inventario alto) y explica cómo hacerlo esta semana.' },
];

export const taskById = (agent: AgentId, id: unknown) => AGENT_TASKS.find((t) => t.agent === agent && t.id === id) || null;

// ── Flyer ──

export const FLYER_ICONS = ['star', 'clock', 'truck', 'shield', 'sparkles', 'heart', 'tag', 'check', 'leaf', 'gift', 'phone', 'map'] as const;
export type FlyerIcon = (typeof FLYER_ICONS)[number];

export interface FlyerCopy {
  /** Etiqueta corta arriba ("2x1 este viernes") */
  kicker: string;
  /** Primera línea del titular */
  headline: string;
  /** Segunda línea, en el color de acento */
  accent: string;
  subtitle: string;
  benefits: { icon: FlyerIcon; text: string }[];
  /** Oferta o precio destacado ("$25.000", "-20 %") */
  offer: string;
  /** Texto pequeño junto a la oferta ("solo hasta el domingo") */
  offerNote: string;
  cta: string;
  /** Descripción en inglés de la foto ideal (para la IA de imágenes, sin texto) */
  imagePrompt: string;
  /** Producto del negocio cuya foto conviene usar, si aplica */
  product: string;
  /** Estilo sugerido para esta propuesta */
  template?: FlyerTemplate;
}

export type FlyerTemplate = 'claro' | 'oscuro' | 'foto';
export const FLYER_TEMPLATES: FlyerTemplate[] = ['claro', 'oscuro', 'foto'];

export const normalizeFlyer = (raw: unknown): FlyerCopy | null => {
  const r = (raw && typeof raw === 'object' ? raw : null) as Record<string, any> | null;
  if (!r) return null;
  const headline = str(r.headline, 40);
  if (!headline) return null;
  const benefits = (Array.isArray(r.benefits) ? r.benefits : [])
    .map((b: any) => ({ icon: (FLYER_ICONS as readonly string[]).includes(b?.icon) ? b.icon : 'check', text: str(b?.text, 34) }))
    .filter((b: { text: string }) => b.text)
    .slice(0, 4) as FlyerCopy['benefits'];
  return {
    kicker: str(r.kicker, 36),
    headline,
    accent: str(r.accent, 32),
    subtitle: str(r.subtitle, 110),
    benefits,
    offer: str(r.offer, 16),
    offerNote: str(r.offerNote, 40),
    cta: str(r.cta, 28),
    imagePrompt: str(r.imagePrompt, 400),
    product: str(r.product, 80),
    template: FLYER_TEMPLATES.includes(r.template) ? r.template : undefined,
  };
};

/** Hasta 3 propuestas, cada una con su estilo (si no lo trae, se reparte claro, oscuro, foto) */
export const normalizeFlyers = (raw: unknown): FlyerCopy[] =>
  (Array.isArray(raw) ? raw : raw ? [raw] : [])
    .map(normalizeFlyer)
    .filter((f): f is FlyerCopy => !!f)
    .slice(0, 3)
    .map((f, i) => ({ ...f, template: f.template || FLYER_TEMPLATES[i] }));

export interface FlyerProduct { name: string; price: number | null; description?: string | null }

const money = (n: number) => `$${Math.round(n).toLocaleString('es-CO')}`;
const cut = (s: string, n: number) => (s.length > n ? `${s.slice(0, n - 1).trimEnd()}…` : s);

/**
 * Tres flyers armados en el equipo con los productos que más se venden y el perfil
 * del negocio. Se usan cuando el servicio de IA no entrega flyers (sin internet o
 * versión anterior) para que el agente de marketing nunca responda solo con texto.
 */
export const buildLocalFlyers = (o: { businessName: string; profile: AiProfile; products: FlyerProduct[]; businessType: string | null; lang: 'es' | 'en'; focus?: string }): FlyerCopy[] => {
  const es = o.lang !== 'en';
  const kind = kindOf(o.businessType);
  const [p1, p2] = [o.products[0], o.products[1] || o.products[0]];
  const diff = o.profile.difference || (es ? (kind === 'services' ? 'Resultados de verdad' : 'Hecho con cariño') : 'Made with care');
  const offerText = o.profile.offer ? cut(o.profile.offer, 100) : '';
  const contact = o.profile.whatsapp ? (es ? 'Pide por WhatsApp' : 'Order on WhatsApp') : (es ? 'Visítanos hoy' : 'Visit us today');
  const photo = (p?: FlyerProduct) => (p ? `${p.name}${p.description ? `, ${p.description}` : ''}, appetizing professional photo` : '');
  const benefits = (es
    ? [{ icon: 'star', text: cut(diff, 30) }, { icon: kind === 'services' ? 'clock' : 'heart', text: kind === 'services' ? 'Entrega puntual' : 'Calidad de siempre' }, { icon: 'phone', text: contact }]
    : [{ icon: 'star', text: cut(diff, 30) }, { icon: 'heart', text: 'Always great quality' }, { icon: 'phone', text: contact }]) as FlyerCopy['benefits'];
  const fl: FlyerCopy[] = [];
  if (p1) fl.push({
    kicker: es ? (kind === 'services' ? 'El más pedido' : 'El favorito de la casa') : 'House favorite',
    headline: cut(p1.name, 22), accent: es ? 'como te gusta' : 'just how you like it',
    subtitle: offerText || (es ? `Lo mejor de ${o.businessName}.` : `The best of ${o.businessName}.`),
    benefits, offer: p1.price ? money(p1.price) : '', offerNote: '', cta: contact, imagePrompt: photo(p1), product: p1.name, template: 'claro',
  });
  if (p2) fl.push({
    kicker: es ? 'Para esta semana' : 'This week',
    headline: cut(p2.name, 22), accent: es ? '¡no te lo pierdas!' : 'don’t miss it!',
    subtitle: o.focus ? cut(o.focus, 100) : (es ? `Pídelo hoy en ${o.businessName}.` : `Order it today at ${o.businessName}.`),
    benefits: benefits.slice(0, 2), offer: p2.price ? money(p2.price) : '', offerNote: es ? 'precio por unidad' : 'per item', cta: contact, imagePrompt: photo(p2), product: p2.name, template: 'foto',
  });
  fl.push({
    kicker: es ? (kind === 'services' ? 'Servicio de confianza' : 'Te esperamos') : 'We are waiting for you',
    headline: cut(o.businessName, 22), accent: cut(diff, 22),
    subtitle: offerText || (es ? 'Escríbenos y te atendemos de una.' : 'Message us and we will help you right away.'),
    benefits, offer: '', offerNote: '', cta: contact, imagePrompt: photo(p1), product: p1?.name || '', template: 'oscuro',
  });
  return fl.slice(0, 3);
};

// ── Respuesta: texto en vivo + datos al final ──

export interface AgentKpi { label: string; value: string; delta: string | null }

/**
 * El modelo escribe primero el texto (Markdown) y al final un bloque ```json con
 * cifras, gráfico, acciones y flyer. Mientras llega, la pantalla muestra solo el texto.
 */
export const splitStreamed = (raw: string): { text: string; data: any | null } => {
  const at = raw.lastIndexOf('```json');
  if (at < 0) {
    // Respuesta antigua (todo JSON) o sin bloque de datos
    const trimmed = raw.trim();
    if (trimmed.startsWith('{')) {
      try {
        const d = JSON.parse(trimmed.match(/\{[\s\S]*\}/)?.[0] || '');
        if (typeof d?.answer === 'string') return { text: d.answer.trim(), data: d };
      } catch {
        // se usa el texto tal cual
      }
    }
    return { text: trimmed, data: null };
  }
  const text = raw.slice(0, at).trim();
  const body = raw.slice(at + 7).replace(/```\s*$/, '').trim();
  try {
    return { text, data: JSON.parse(body.match(/\{[\s\S]*\}/)?.[0] || 'null') };
  } catch {
    return { text, data: null };
  }
};

/** Lo que se puede mostrar mientras llega: sin el bloque de datos (ni su comienzo) */
export const visiblePart = (raw: string) => {
  const at = raw.indexOf('```');
  return (at < 0 ? raw : raw.slice(0, at)).replace(/`{1,2}$/, '');
};

export const normalizeKpis = (raw: unknown): AgentKpi[] =>
  (Array.isArray(raw) ? raw : [])
    .map((k: any) => ({ label: str(k?.label, 40), value: str(k?.value, 24), delta: str(k?.delta, 16) || null }))
    .filter((k) => k.label && k.value)
    .slice(0, 4);

export { num as toNumber };
