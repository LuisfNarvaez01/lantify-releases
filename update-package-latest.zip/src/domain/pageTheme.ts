// ============================================
// DOMAIN - Diseño de la página del negocio
// ============================================
// Lo que el ADMIN personaliza (o la IA le recomienda): paleta, modo claro u
// oscuro, tipografía, esquinas, cómo se ve la carta y la portada. Todo pasa por
// normalizeTheme: un color que no se lee bien con texto blanco se oscurece solo,
// así ninguna combinación deja la página ilegible. themeVars convierte el tema en
// las variables de color que usan la página pública y la vista previa del POS.

import { MEDIA_URL_RE } from './media';

export type ThemeMode = 'light' | 'dark';
export type ThemeFont = 'moderna' | 'elegante' | 'calida' | 'amigable';
export type ThemeRadius = 'recto' | 'suave' | 'redondo';
export type MenuLayout = 'tarjetas' | 'lista';
export type HeroStyle = 'foto' | 'color';
export type BusinessTemplate = 'gourmet' | 'bar' | 'cafe' | 'fast' | 'bakery' | 'nightlife' | 'grill';
export const BUSINESS_TEMPLATE_KEYS: BusinessTemplate[] = ['bakery', 'cafe', 'nightlife', 'bar', 'gourmet', 'grill', 'fast'];

export interface TemplateMeta {
  id: BusinessTemplate;
  name: string;
  category: string;
  description: string;
  recommendedPreset: string;
  recommendedFont: ThemeFont;
  recommendedMode: ThemeMode;
  recommendedRadius: ThemeRadius;
  recommendedLayout: MenuLayout;
}

export const BUSINESS_TEMPLATES: Record<BusinessTemplate, TemplateMeta> = {
  bakery: {
    id: 'bakery', name: 'Obrador', category: 'Panadería / Repostería',
    description: 'Espresso y dorado, letras espaciadas y la foto enmarcada como en una vitrina. La carta se muestra como el mostrador del día.',
    recommendedPreset: 'obrador', recommendedFont: 'elegante', recommendedMode: 'dark', recommendedRadius: 'recto', recommendedLayout: 'tarjetas',
  },
  cafe: {
    id: 'cafe', name: 'Obrador claro', category: 'Cafetería / Brunch',
    description: 'La misma vitrina en tonos crema y café: cálida, tranquila y con la tarjeta de sellos a la vista.',
    recommendedPreset: 'cafe', recommendedFont: 'elegante', recommendedMode: 'light', recommendedRadius: 'recto', recommendedLayout: 'tarjetas',
  },
  nightlife: {
    id: 'nightlife', name: 'Pulso', category: 'Discoteca / Club',
    description: 'Negro, una franja de color a todo lo ancho y el nombre gigante. Redes en riel lateral y la barra como carteles de evento.',
    recommendedPreset: 'club', recommendedFont: 'moderna', recommendedMode: 'dark', recommendedRadius: 'recto', recommendedLayout: 'tarjetas',
  },
  bar: {
    id: 'bar', name: 'Pulso ámbar', category: 'Bar / Gastrobar',
    description: 'El cartel nocturno en ámbar y violeta para gastrobares: cócteles, picadas y reservas de mesa al frente.',
    recommendedPreset: 'noche', recommendedFont: 'moderna', recommendedMode: 'dark', recommendedRadius: 'recto', recommendedLayout: 'tarjetas',
  },
  gourmet: {
    id: 'gourmet', name: 'Mantel', category: 'Restaurante / Bistró',
    description: 'Editorial y sereno: portada en arco, la carta impresa con precios punteados y reservas como protagonista.',
    recommendedPreset: 'clasico', recommendedFont: 'elegante', recommendedMode: 'light', recommendedRadius: 'recto', recommendedLayout: 'lista',
  },
  grill: {
    id: 'grill', name: 'Brasa', category: 'Asadero / Parrilla',
    description: 'Carbón y brasa: foto a todo lo ancho con resplandor, letras condensadas y los cortes como una pizarra.',
    recommendedPreset: 'brasa', recommendedFont: 'moderna', recommendedMode: 'dark', recommendedRadius: 'suave', recommendedLayout: 'tarjetas',
  },
  fast: {
    id: 'fast', name: 'Calle', category: 'Hamburguesas / Pizza / Comida rápida',
    description: 'Colores de calle, bordes gruesos y etiquetas tipo sticker. Todo pensado para pedir en dos toques.',
    recommendedPreset: 'urbano', recommendedFont: 'amigable', recommendedMode: 'light', recommendedRadius: 'redondo', recommendedLayout: 'tarjetas',
  },
};

/**
 * Vitrina animada de la portada: un producto recortado (PNG o WebP sin fondo)
 * que se mueve según lo que es y rodeado de un ambiente animado.
 *
 * Movimiento (qué hace el producto al abrirse):
 *   lift  → flota y se inclina en 3D siguiendo el mouse (café, botellas, postres)
 *   lid   → la parte de arriba se levanta como una tapa (vasos con tapa domo, cajas)
 *   stack → se separa en capas (hamburguesas, sándwiches, tortas, arepas rellenas)
 *   split → se parte en dos mitades (pan, pizza, croissant, empanada)
 * Los cortes (`cuts`, en % de la imagen) los marca el negocio sobre su foto.
 *
 * Ambiente (lo que pasa alrededor): aura de color, chapoteo líquido, vapor,
 * destellos dorados, brasas, luces de discoteca o estallido gráfico. 'auto'
 * toma el de la plantilla.
 */
export const SHOWCASE_MOTIONS = ['lift', 'lid', 'stack', 'split'] as const;
export type ShowcaseMotion = (typeof SHOWCASE_MOTIONS)[number];
export const SHOWCASE_EFFECTS = ['auto', 'aura', 'splash', 'steam', 'sparkle', 'embers', 'club', 'pop'] as const;
export type ShowcaseEffect = (typeof SHOWCASE_EFFECTS)[number];
export const SHOWCASE_TRIGGERS = ['hover', 'scroll', 'loop'] as const;
export type ShowcaseTrigger = (typeof SHOWCASE_TRIGGERS)[number];
export const SHOWCASE_MAX_EXTRAS = 4;

export interface HeroShowcase {
  /** El producto sin fondo */
  image: string;
  motion: ShowcaseMotion;
  /** Dónde se corta la foto (%): tapa = 1 corte horizontal, capas = 1 a 3, partir = 1 corte vertical */
  cuts: number[];
  /** Hasta 4 recortes de ingredientes (frutas, hojas…) que salen alrededor */
  extras: string[];
  /** Producto de la carta que se pide desde la vitrina (presentación) */
  itemId: string | null;
  effect: ShowcaseEffect;
  /** Cuándo se abre: al pasar el mouse, al bajar por la página o sola cada pocos segundos */
  trigger: ShowcaseTrigger;
  /** Ubicación y tamaño dentro de la portada: corrimiento en % de su tamaño y escala en % */
  layout: { x: number; y: number; size: number };
}

/** El ambiente que trae cada plantilla cuando el negocio no elige uno */
export const TEMPLATE_SHOWCASE_EFFECT: Record<BusinessTemplate, Exclude<ShowcaseEffect, 'auto'>> = {
  bakery: 'sparkle', cafe: 'steam', nightlife: 'club', bar: 'club', gourmet: 'aura', grill: 'embers', fast: 'pop',
};

/** Cortes por defecto de cada movimiento */
export const defaultCuts = (motion: ShowcaseMotion): number[] =>
  motion === 'lid' ? [24] : motion === 'stack' ? [30, 55] : motion === 'split' ? [50] : [];

export interface PageTheme {
  preset: string;
  template: BusinessTemplate;
  primary: string;
  accent: string;
  mode: ThemeMode;
  font: ThemeFont;
  radius: ThemeRadius;
  menuLayout: MenuLayout;
  heroStyle: HeroStyle;
  /** Foto de portada (https) */
  coverImage: string | null;
  /** Logo (https) */
  logoImage: string | null;
  /** Vitrina animada en la portada (null = la foto de portada de siempre) */
  showcase: HeroShowcase | null;
}

type PresetBase = Omit<PageTheme, 'preset' | 'template' | 'coverImage' | 'logoImage' | 'showcase'>;

const clampNum = (v: unknown, min: number, max: number, fallback: number) => {
  const n = Number(v);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, Math.round(n))) : fallback;
};

const normalizeShowcase = (raw: unknown): HeroShowcase | null => {
  const r = raw && typeof raw === 'object' ? (raw as Record<string, unknown>) : null;
  const image = r ? httpsUrl(r.image) : null;
  if (!r || !image) return null;
  // Versión anterior: solo había "tapa" (lid en %)
  const legacyLid = Number(r.lid);
  const motion: ShowcaseMotion = (SHOWCASE_MOTIONS as readonly string[]).includes(r.motion as string)
    ? (r.motion as ShowcaseMotion)
    : Number.isFinite(legacyLid) && legacyLid > 0 ? 'lid' : 'lift';
  const rawCuts = Array.isArray(r.cuts) ? r.cuts : Number.isFinite(legacyLid) && legacyLid > 0 ? [legacyLid] : defaultCuts(motion);
  const max = motion === 'stack' ? 3 : motion === 'lift' ? 0 : 1;
  const [lo, hi] = motion === 'split' ? [20, 80] : [5, 90];
  let cuts = rawCuts.map((c) => clampNum(c, lo, hi, NaN)).filter((c) => Number.isFinite(c)).sort((a, b) => a - b).slice(0, max);
  if (motion !== 'lift' && !cuts.length) cuts = defaultCuts(motion);
  const effect = r.effect === 'neon' ? 'club' : r.effect;
  const layout = r.layout && typeof r.layout === 'object' ? (r.layout as Record<string, unknown>) : {};
  const itemId = typeof r.itemId === 'string' && /^[\w-]{1,64}$/.test(r.itemId) ? r.itemId : null;
  return {
    image,
    motion,
    cuts,
    extras: (Array.isArray(r.extras) ? r.extras : []).map(httpsUrl).filter((u): u is string => !!u).slice(0, SHOWCASE_MAX_EXTRAS),
    itemId,
    effect: (SHOWCASE_EFFECTS as readonly string[]).includes(effect as string) ? (effect as ShowcaseEffect) : 'auto',
    trigger: (SHOWCASE_TRIGGERS as readonly string[]).includes(r.trigger as string) ? (r.trigger as ShowcaseTrigger) : 'hover',
    layout: { x: clampNum(layout.x, -60, 60, 0), y: clampNum(layout.y, -60, 60, 0), size: clampNum(layout.size, 50, 160, 100) },
  };
};

/** Puntos de partida por tipo de negocio (la IA elige uno y lo ajusta) */
export const THEME_PRESETS: Record<string, PresetBase> = {
  brasa: { primary: '#B4441F', accent: '#F2A541', mode: 'dark', font: 'moderna', radius: 'suave', menuLayout: 'tarjetas', heroStyle: 'foto' },
  cafe: { primary: '#6F4E37', accent: '#D9A066', mode: 'light', font: 'calida', radius: 'redondo', menuLayout: 'lista', heroStyle: 'foto' },
  fresco: { primary: '#2F7D4F', accent: '#F4C542', mode: 'light', font: 'amigable', radius: 'redondo', menuLayout: 'tarjetas', heroStyle: 'foto' },
  mar: { primary: '#0F6E8C', accent: '#F28C38', mode: 'light', font: 'moderna', radius: 'suave', menuLayout: 'tarjetas', heroStyle: 'foto' },
  noche: { primary: '#7C3AED', accent: '#F472B6', mode: 'dark', font: 'moderna', radius: 'suave', menuLayout: 'lista', heroStyle: 'color' },
  clasico: { primary: '#7F1D1D', accent: '#C9A227', mode: 'light', font: 'elegante', radius: 'recto', menuLayout: 'lista', heroStyle: 'foto' },
  obrador: { primary: '#7A5230', accent: '#C9A227', mode: 'dark', font: 'elegante', radius: 'recto', menuLayout: 'tarjetas', heroStyle: 'foto' },
  club: { primary: '#D7141A', accent: '#FF4040', mode: 'dark', font: 'moderna', radius: 'recto', menuLayout: 'tarjetas', heroStyle: 'foto' },
  urbano: { primary: '#D62839', accent: '#FFB703', mode: 'light', font: 'amigable', radius: 'redondo', menuLayout: 'tarjetas', heroStyle: 'color' },
};
export const THEME_PRESET_KEYS = Object.keys(THEME_PRESETS);
export const DEFAULT_PRESET = 'brasa';

const HEX = /^#[0-9a-fA-F]{6}$/;
const pick = <T extends string>(v: unknown, allowed: readonly T[], fallback: T): T => (allowed.includes(v as T) ? (v as T) : fallback);
// Dirección https o una foto subida al equipo del negocio (antes de publicar se cambia por la de la nube)
const httpsUrl = (v: unknown) => (typeof v === 'string' && (/^https:\/\/[^\s"'<>]{4,500}$/.test(v.trim()) || MEDIA_URL_RE.test(v.trim())) ? v.trim() : null);

// ── Color ───────────────────────────────────────────────────
type RGB = [number, number, number];
export const hexToRgb = (hex: string): RGB => [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16)) as RGB;
export const rgbToHex = (c: RGB) => '#' + c.map((v) => Math.round(Math.max(0, Math.min(255, v))).toString(16).padStart(2, '0')).join('').toUpperCase();
const mix = (a: RGB, b: RGB, t: number): RGB => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
const lum = (c: RGB) => {
  const ch = c.map((v) => {
    const s = v / 255;
    return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
  });
  return 0.2126 * ch[0] + 0.7152 * ch[1] + 0.0722 * ch[2];
};
export const contrast = (a: RGB, b: RGB) => {
  const [x, y] = [lum(a), lum(b)].sort((m, n) => n - m);
  return (x + 0.05) / (y + 0.05);
};
const WHITE: RGB = [255, 255, 255];
const BLACK: RGB = [0, 0, 0];

/** Oscurece (o aclara) un color hasta que contraste lo suficiente con otro */
const towards = (c: RGB, against: RGB, target: number, dir: RGB) => {
  let out = c;
  for (let i = 0; i < 20 && contrast(out, against) < target; i++) out = mix(out, dir, 0.08);
  return out;
};

const defaultTemplateForPreset = (p: string): BusinessTemplate => {
  if (p === 'noche') return 'bar';
  if (p === 'cafe') return 'cafe';
  if (p === 'clasico') return 'gourmet';
  if (p === 'obrador') return 'bakery';
  if (p === 'club') return 'nightlife';
  if (p === 'brasa') return 'grill';
  if (p === 'urbano') return 'fast';
  return 'gourmet';
};

export const normalizeTheme = (raw: unknown): PageTheme => {
  const r = raw && typeof raw === 'object' ? (raw as Record<string, unknown>) : {};
  const preset = pick(r.preset, THEME_PRESET_KEYS, DEFAULT_PRESET);
  const base = THEME_PRESETS[preset];
  const template = pick(r.template, BUSINESS_TEMPLATE_KEYS, defaultTemplateForPreset(preset));
  const primaryIn = typeof r.primary === 'string' && HEX.test(r.primary) ? r.primary : base.primary;
  const accentIn = typeof r.accent === 'string' && HEX.test(r.accent) ? r.accent : base.accent;
  // El texto de los botones es blanco: el color principal debe leerse con él (WCAG AA)
  const primary = rgbToHex(towards(hexToRgb(primaryIn), WHITE, 4.5, BLACK));
  return {
    preset,
    template,
    primary,
    accent: rgbToHex(hexToRgb(accentIn)),
    mode: pick(r.mode, ['light', 'dark'] as const, base.mode),
    font: pick(r.font, ['moderna', 'elegante', 'calida', 'amigable'] as const, base.font),
    radius: pick(r.radius, ['recto', 'suave', 'redondo'] as const, base.radius),
    menuLayout: pick(r.menuLayout, ['tarjetas', 'lista'] as const, base.menuLayout),
    heroStyle: pick(r.heroStyle, ['foto', 'color'] as const, base.heroStyle),
    coverImage: httpsUrl(r.coverImage),
    logoImage: httpsUrl(r.logoImage),
    showcase: normalizeShowcase(r.showcase),
  };
};

const trip = (c: RGB) => c.map((v) => Math.round(Math.max(0, Math.min(255, v)))).join(' ');

/**
 * Variables de color de la página ("R G B" como las del sitio) a partir del tema.
 * Garantiza contraste: texto ≥ 7:1 sobre el fondo, color de marca legible en
 * enlaces (≥ 4.5:1) y texto del acento en blanco o negro según convenga.
 */
export const themeVars = (t: PageTheme): Record<string, string> => {
  const p = hexToRgb(t.primary);
  const a = hexToRgb(t.accent);
  const dark = t.mode === 'dark';
  const ground: RGB = dark ? mix([14, 13, 12], p, 0.07) : mix([250, 249, 246], p, 0.03);
  const raised: RGB = dark ? mix([28, 26, 24], p, 0.09) : WHITE;
  const ink: RGB = towards(dark ? [246, 243, 238] : mix([22, 19, 16], p, 0.08), ground, 7, dark ? WHITE : BLACK);
  const inkSoft = towards(mix(ink, ground, 0.28), raised, 4.5, dark ? WHITE : BLACK);
  const inkFaint = towards(mix(ink, ground, 0.45), raised, 3.2, dark ? WHITE : BLACK);
  const brandInk = towards(p, ground, 4.5, dark ? WHITE : BLACK);
  const night: RGB = mix(p, [8, 7, 6], dark ? 0.82 : 0.72);
  return {
    '--ground': trip(ground),
    '--raised': trip(raised),
    '--ink': trip(ink),
    '--ink-soft': trip(inkSoft),
    '--ink-faint': trip(inkFaint),
    '--rule': trip(mix(ink, ground, dark ? 0.84 : 0.88)),
    '--brand': trip(p),
    '--brand-deep': trip(mix(p, BLACK, 0.18)),
    '--brand-wash': trip(mix(p, ground, dark ? 0.8 : 0.9)),
    '--brand-ink': trip(brandInk),
    '--night': trip(night),
    '--accent': trip(a),
    '--on-accent': contrast(a, BLACK) >= contrast(a, WHITE) ? '0 0 0' : '255 255 255',
    '--lp-r': t.radius === 'recto' ? '6px' : t.radius === 'suave' ? '14px' : '24px',
  };
};

/** Tipografías de títulos (el cuerpo siempre es la del sitio, legible en celular) */
export const THEME_FONTS: Record<ThemeFont, { family: string; google: string | null }> = {
  moderna: { family: "'Archivo', system-ui, sans-serif", google: null },
  elegante: { family: "'Playfair Display', Georgia, serif", google: 'Playfair+Display:wght@600;700;800' },
  calida: { family: "'Fraunces', Georgia, serif", google: 'Fraunces:opsz,wght@9..144,600;9..144,800' },
  amigable: { family: "'Nunito', system-ui, sans-serif", google: 'Nunito:wght@700;800;900' },
};
