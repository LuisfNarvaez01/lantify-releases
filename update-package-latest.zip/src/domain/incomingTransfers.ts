// ============================================
// DOMAIN - Emparejar una transferencia leída con el cobro que la espera (Fase 4 · D · 3)
// ============================================
// En Cobrar → Transferencia la caja queda "Esperando confirmación…" por un valor exacto.
// Cuando el celular del negocio avisa que llegó una transferencia, se empareja con el
// cobro en espera del MISMO valor (±0) si están a menos de 15 minutos uno del otro.
// Nunca decide la venta: el cajero siempre puede confirmar a mano.

export const MATCH_WINDOW_MS = 15 * 60_000;
/** Las transferencias leídas se borran a las 24 h */
export const TRANSFER_KEEP_MS = 24 * 60 * 60_000;

export interface PendingCharge { id: string; amount: number; createdAt: number }
export interface TransferLite { id: string; amount: number; receivedAt: number; matched: boolean }

/** Mismo valor al centavo */
export const sameAmount = (a: number, b: number) => Math.round(a * 100) === Math.round(b * 100);

const near = (a: number, b: number) => Math.abs(a - b) <= MATCH_WINDOW_MS;

/** El cobro sigue esperando (no venció la ventana) */
export const chargeAlive = (c: PendingCharge, now: number) => now - c.createdAt <= MATCH_WINDOW_MS;

/** Al abrir un cobro: la transferencia libre más antigua del mismo valor que llegó hace poco */
export const transferForCharge = (charge: PendingCharge, transfers: TransferLite[], now: number): TransferLite | null =>
  transfers
    .filter((t) => !t.matched && sameAmount(t.amount, charge.amount) && near(t.receivedAt, charge.createdAt) && now - t.receivedAt <= MATCH_WINDOW_MS)
    .sort((a, b) => a.receivedAt - b.receivedAt)[0] ?? null;

/** Al llegar una transferencia: el cobro en espera más antiguo del mismo valor */
export const chargeForTransfer = (transfer: TransferLite, charges: PendingCharge[], now: number): PendingCharge | null =>
  charges
    .filter((c) => chargeAlive(c, now) && sameAmount(c.amount, transfer.amount) && near(transfer.receivedAt, c.createdAt))
    .sort((a, b) => a.createdAt - b.createdAt)[0] ?? null;
