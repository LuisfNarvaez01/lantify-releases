// ============================================
// DOMAIN - Encuesta corta de satisfacción (Fase 4 · 12)
// ============================================
// Una sola pregunta (1–5) y un comentario opcional que el cliente responde en la
// página del negocio al reclamar sellos o al abrir su tarjeta desde la wallet.
// La nube la guarda y la caja la recibe por el buzón de la página. Aquí: validar,
// resumir por semana y decidir cuándo el Autopilot debe avisar.

export const SURVEY_COMMENT_MAX = 280;
/** Promedio de 7 días por debajo del cual se avisa */
export const SURVEY_LOW_AVG = 3.5;
/** Respuestas mínimas en 7 días para que el promedio cuente */
export const SURVEY_MIN_COUNT = 5;
/** Una calificación de 1–2 con comentario se avisa durante este tiempo */
export const SURVEY_LOW_WINDOW_H = 24;

export interface SurveyInput {
  score: number;
  comment: string | null;
}

/** null = respuesta inválida */
export const normalizeSurvey = (raw: unknown): SurveyInput | null => {
  const r = raw && typeof raw === 'object' ? (raw as Record<string, any>) : {};
  const score = Math.round(Number(r.score));
  if (!Number.isFinite(score) || score < 1 || score > 5) return null;
  const comment = typeof r.comment === 'string'
    ? r.comment.replace(/[\u0000-\u001f\u007f]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, SURVEY_COMMENT_MAX)
    : '';
  return { score, comment: comment || null };
};

export interface SurveyRow {
  id: string;
  score: number;
  comment: string | null;
  at: Date;
  customerName?: string | null;
}

const DAY = 86_400_000;
const round1 = (n: number) => Math.round(n * 10) / 10;

/** Lunes 00:00 (hora local) de la semana de `d` */
export const weekStart = (d: Date): Date => {
  const x = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  const back = (x.getDay() + 6) % 7;
  x.setDate(x.getDate() - back);
  return x;
};

export interface SurveySummary {
  avg7: number | null;
  count7: number;
  weeks: { weekStart: string; avg: number | null; count: number }[];
  /** Reparto de calificaciones en las semanas del resumen (1–5) */
  distribution: number[];
  recent: { id: string; score: number; comment: string; at: string; customerName: string | null }[];
}

/** Promedio semanal de las últimas `weeks` semanas (la actual incluida) y comentarios recientes */
export const summarizeSurveys = (rows: SurveyRow[], now: Date, weeks = 8): SurveySummary => {
  const since7 = now.getTime() - 7 * DAY;
  const last7 = rows.filter((r) => r.at.getTime() > since7 && r.at <= now);
  const first = weekStart(new Date(now.getTime() - (weeks - 1) * 7 * DAY));
  const buckets = Array.from({ length: weeks }, (_, i) => {
    const start = new Date(first);
    start.setDate(first.getDate() + i * 7);
    return { start, sum: 0, count: 0 };
  });
  const distribution = [0, 0, 0, 0, 0];
  for (const r of rows) {
    if (r.at < first || r.at > now) continue;
    const ws = weekStart(r.at).getTime();
    const b = buckets.find((x) => x.start.getTime() === ws);
    if (!b) continue;
    b.sum += r.score;
    b.count += 1;
    distribution[r.score - 1] += 1;
  }
  return {
    avg7: last7.length ? round1(last7.reduce((n, r) => n + r.score, 0) / last7.length) : null,
    count7: last7.length,
    weeks: buckets.map((b) => ({ weekStart: b.start.toISOString(), avg: b.count ? round1(b.sum / b.count) : null, count: b.count })),
    distribution,
    recent: rows
      .filter((r) => r.comment && r.at <= now)
      .sort((a, b) => b.at.getTime() - a.at.getTime())
      .slice(0, 10)
      .map((r) => ({ id: r.id, score: r.score, comment: r.comment!, at: r.at.toISOString(), customerName: r.customerName ?? null })),
  };
};

export interface SatisfactionLive {
  avg7: number | null;
  count7: number;
  /** Calificaciones de 1–2 con comentario de las últimas horas */
  lowComments: { id: string; score: number; comment: string }[];
}

/** Lo que el Autopilot necesita saber de la encuesta en este momento */
export const satisfactionLive = (rows: SurveyRow[], now: Date): SatisfactionLive => {
  const since7 = now.getTime() - 7 * DAY;
  const last7 = rows.filter((r) => r.at.getTime() > since7 && r.at <= now);
  const sinceLow = now.getTime() - SURVEY_LOW_WINDOW_H * 3600_000;
  return {
    avg7: last7.length ? round1(last7.reduce((n, r) => n + r.score, 0) / last7.length) : null,
    count7: last7.length,
    lowComments: rows
      .filter((r) => r.score <= 2 && r.comment && r.at.getTime() > sinceLow && r.at <= now)
      .sort((a, b) => b.at.getTime() - a.at.getTime())
      .slice(0, 3)
      .map((r) => ({ id: r.id, score: r.score, comment: r.comment! })),
  };
};
