// ============================================
// DOMAIN - Impuestos incluidos en el precio
// ============================================
// En Colombia el precio que ve el cliente ya trae el impuesto (IVA o impoconsumo).
// Aquí solo se calcula qué parte de ese precio es impuesto, para el ticket,
// la factura electrónica y los reportes. El total cobrado no cambia.

export type TaxType = 'IVA' | 'INC' | 'NONE';

export const TAX_TYPES: TaxType[] = ['IVA', 'INC', 'NONE'];

// Tarifas vigentes más comunes. El dueño puede escribir otra si su producto lo requiere.
export const STANDARD_TAX_RATES: Record<TaxType, number[]> = {
  IVA: [19, 5],
  INC: [8],
  NONE: [0],
};

export interface TaxProfile {
  taxType: TaxType;
  taxRate: number;
}

export const NO_TAX: TaxProfile = { taxType: 'NONE', taxRate: 0 };

const round2 = (n: number) => Math.round(n * 100) / 100;

export const isTaxType = (value: unknown): value is TaxType =>
  typeof value === 'string' && (TAX_TYPES as string[]).includes(value);

/** Normaliza lo que llega de la API o de la base de datos. Devuelve null si no es válido. */
export const normalizeTaxProfile = (taxType: unknown, taxRate: unknown): TaxProfile | null => {
  if (!isTaxType(taxType)) return null;
  if (taxType === 'NONE') return NO_TAX;
  const rate = Number(taxRate);
  if (!Number.isFinite(rate) || rate <= 0 || rate > 100) return null;
  return { taxType, taxRate: round2(rate) };
};

/** El producto manda; si no tiene impuesto propio se usa el del negocio. */
export const resolveTaxProfile = (
  product: { taxType?: string | null; taxRate?: number | null } | null | undefined,
  businessDefault: TaxProfile,
): TaxProfile => {
  const own = product ? normalizeTaxProfile(product.taxType, product.taxRate) : null;
  return own ?? businessDefault;
};

/** Parte de un valor con impuesto incluido que corresponde al impuesto. */
export const includedTax = (grossAmount: number, rate: number): number => {
  if (!rate || grossAmount <= 0) return 0;
  return round2(grossAmount - grossAmount / (1 + rate / 100));
};

export interface TaxableLine {
  total: number; // valor bruto de la línea (precio × cantidad), con impuesto incluido
  taxType: TaxType;
  taxRate: number;
}

/**
 * Calcula el impuesto de cada línea después de repartir el descuento de la venta
 * en proporción al valor de cada línea.
 */
export const computeSaleTaxes = (lines: TaxableLine[], discountAmount: number) => {
  const gross = lines.reduce((s, l) => s + l.total, 0);
  const factor = gross > 0 ? Math.max(0, gross - discountAmount) / gross : 0;
  const lineTaxes = lines.map((l) => includedTax(l.total * factor, l.taxRate));
  const tax = round2(lineTaxes.reduce((s, t) => s + t, 0));
  return { lineTaxes, tax };
};
