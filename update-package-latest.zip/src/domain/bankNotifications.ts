// ============================================
// DOMAIN - Leer el aviso de transferencia que el banco ya mostró (Fase 4 · D · 3)
// ============================================
// El celular del negocio (app Android de Lantify, con el acceso a notificaciones que el
// dueño activó) le pasa a este analizador el título y el texto de cada aviso de las apps
// de la lista. Si es una transferencia RECIBIDA, devuelve monto, remitente y hora; con
// cualquier otra cosa devuelve null y el aviso se descarta sin guardarlo.
//
// La misma lógica vive en Java (android/src/com/lantify/pos/mobile/BankNotificationParser.java):
// si cambia un patrón aquí, se cambia allá. Las pruebas están en tests/fase4-bank-notifications.test.ts.
//
// Lantify nunca mueve dinero ni entra a las cuentas: solo lee el aviso del teléfono.

export type BankApp = 'NEQUI' | 'DAVIPLATA' | 'BANCOLOMBIA' | 'BREB';

/**
 * Las únicas apps cuyos avisos se leen (nombre del paquete en Android).
 * Bre‑B no tiene app propia: es el sistema de pagos inmediatos del Banco de la República
 * y llega dentro del aviso del banco (p. ej. "por Bre-B"); por eso se marca con `breB`.
 */
export const BANK_APPS: readonly { pkg: string; app: BankApp }[] = [
  { pkg: 'com.nequi.MobileApp', app: 'NEQUI' },
  { pkg: 'com.davivienda.daviplataapp', app: 'DAVIPLATA' },
  { pkg: 'com.todo1.mobile', app: 'BANCOLOMBIA' },          // Bancolombia App Personas
];

export const appForPackage = (pkg: string): BankApp | null => BANK_APPS.find((a) => a.pkg === pkg)?.app ?? null;

export interface BankNotificationInput {
  pkg: string;
  title?: string | null;
  text?: string | null;
  /** Hora del aviso en el celular (ms) */
  postedAt: number;
}

export interface ParsedTransfer {
  app: BankApp;
  amount: number;
  sender: string | null;
  postedAt: number;
  /** Llegó por Bre‑B (pagos inmediatos) */
  breB: boolean;
}

// ── Piezas de los patrones (iguales en Java) ──
const LETTER = 'A-Za-zÁÉÍÓÚÑÜáéíóúñü';
const AMOUNT = '(?:\\$|COP)\\s?([0-9]{1,3}(?:[.,][0-9]{3})+(?:[.,][0-9]{1,2})?|[0-9]+(?:[.,][0-9]{1,2})?)';
const NAME = `([${LETTER}][${LETTER}' ]{1,58}?)`;
const NAME_END = '(?=\\s+(?:en|a|el|por|desde|con|hoy)\\b|\\s*[.,;:!¡(]|\\s*$)';

/** "Recibiste $25.000 de JUAN PEREZ…" · "Recibiste una transferencia por $25,000.00 de JUAN PEREZ en tu cuenta…" */
const RECEIVED = new RegExp(`recib(?:iste|i[oó]|imos)[^$]{0,40}?${AMOUNT}(?:[^.$]{0,14}?\\bde\\s+${NAME}${NAME_END})?`, 'i');
/** "JUAN PEREZ te envió $25.000" */
const SENT_YOU = new RegExp(`${NAME}\\s+te\\s+(?:envi[oó]|transfiri[oó]|mand[oó]|pag[oó])\\s+${AMOUNT}`, 'i');
/** "Te llegaron $25.000 de JUAN PEREZ" · "¡Te llegó plata! $25.000 de JUAN PEREZ" */
const ARRIVED = new RegExp(`te\\s+lleg(?:[oó]|aron)[^$]{0,30}?${AMOUNT}(?:[^.$]{0,14}?\\bde\\s+${NAME}${NAME_END})?`, 'i');

/** Avisos con monto que no son un pago de un cliente (promociones, préstamos, puntos, lo que enviaste tú) */
const NOT_A_PAYMENT = /\b(descuento|cashback|bono|premio|puntos|pr[eé]stamo|cr[eé]dito|oferta|promo|gana|sorteo|reembolso|devoluci[oó]n|enviaste|pagaste|compraste|retiraste|transferiste|recarga)/i;
const BRE_B = /bre[\s-]?b\b/i;

type Pattern = { re: RegExp; amountAt: number; senderAt: number };
const P_RECEIVED: Pattern = { re: RECEIVED, amountAt: 1, senderAt: 2 };
const P_SENT_YOU: Pattern = { re: SENT_YOU, amountAt: 2, senderAt: 1 };
const P_ARRIVED: Pattern = { re: ARRIVED, amountAt: 1, senderAt: 2 };

/** Patrones de cada app, en el orden en que se prueban */
const PATTERNS: Record<BankApp, Pattern[]> = {
  NEQUI: [P_SENT_YOU, P_ARRIVED, P_RECEIVED],
  DAVIPLATA: [P_RECEIVED, P_SENT_YOU, P_ARRIVED],
  BANCOLOMBIA: [P_RECEIVED, P_ARRIVED],
  BREB: [P_RECEIVED, P_ARRIVED, P_SENT_YOU],
};

/**
 * "$25.000" · "$25,000.00" · "$ 25.000,50" → pesos.
 * Con separador de miles (grupos de 3) el último separador de 1–2 cifras son centavos.
 */
export const parseAmount = (raw: string): number | null => {
  const s = raw.replace(/\s/g, '');
  let n: number;
  const grouped = /^([0-9]{1,3}(?:[.,][0-9]{3})+)(?:([.,])([0-9]{1,2}))?$/.exec(s);
  if (grouped) {
    const int = grouped[1].replace(/[.,]/g, '');
    n = Number(grouped[3] ? `${int}.${grouped[3]}` : int);
  } else if (/^[0-9]+(?:[.,][0-9]{1,2})?$/.test(s)) {
    n = Number(s.replace(',', '.'));
  } else {
    return null;
  }
  return Number.isFinite(n) && n > 0 && n < 100_000_000 ? Math.round(n * 100) / 100 : null;
};

const cleanSender = (raw: string | undefined): string | null => {
  if (!raw) return null;
  const s = raw.replace(/\s+/g, ' ').trim().replace(/[.' ]+$/, '');
  return s.length >= 2 ? s.slice(0, 60) : null;
};

/** Transferencia recibida, o null (el aviso se descarta y no se guarda) */
export const parseBankNotification = (input: BankNotificationInput): ParsedTransfer | null => {
  const app = appForPackage(input.pkg);
  if (!app) return null;
  const text = [input.title, input.text].filter((s) => typeof s === 'string' && s.trim()).join(' · ').replace(/\s+/g, ' ').slice(0, 600);
  if (!text || NOT_A_PAYMENT.test(text)) return null;
  const breB = BRE_B.test(text);
  for (const p of PATTERNS[breB ? 'BREB' : app]) {
    const m = p.re.exec(text);
    if (!m) continue;
    const amount = parseAmount(m[p.amountAt] || '');
    if (amount === null) continue;
    return { app: breB ? 'BREB' : app, amount, sender: cleanSender(m[p.senderAt]), postedAt: input.postedAt, breB };
  }
  return null;
};
