// ============================================
// DOMAIN - Copiar la carta entre sedes (Fase 4 · Varias sedes)
// ============================================
// La carta sale de una sede como JSON (categorías, productos, presentaciones y
// recetas) y entra a otra. Al entrar se compara por NOMBRE (sin importar mayúsculas
// ni espacios): lo que ya está igual no se toca, lo distinto se actualiza y lo que
// falta se crea. Importar dos veces el mismo archivo no cambia nada la segunda vez.
// Nunca toca inventario (existencias, costos), ventas ni fotos.

export const MENU_FORMAT = 'lantify-menu';
export const MENU_VERSION = 1;

export interface MenuRecipeLine { ingredient: string; unit: string; quantity: number; removable: boolean }
export interface MenuVariant { name: string; price: number }
export interface MenuProduct {
  name: string;
  category: string | null;
  description: string | null;
  taxType: string | null;
  taxRate: number | null;
  printStation: string | null;
  /** Ingredientes que se pueden quitar al comandar (lista de nombres) */
  ingredients: string[];
  isCover: boolean;
  variants: MenuVariant[];
  recipe: MenuRecipeLine[];
}
export interface MenuCategoryRow { name: string; description: string | null; printStation: string | null }
export interface MenuExport {
  format: typeof MENU_FORMAT;
  version: number;
  exportedAt: string;
  business: string | null;
  categories: MenuCategoryRow[];
  products: MenuProduct[];
}

export const nameKey = (s: string) => s.normalize('NFC').trim().replace(/\s+/g, ' ').toLowerCase();

const text = (v: unknown, max: number) => (typeof v === 'string' && v.trim() ? v.trim().replace(/\s+/g, ' ').slice(0, max) : null);
const money = (v: unknown) => {
  const n = Math.round(Number(v) * 100) / 100;
  return Number.isFinite(n) && n >= 0 && n <= 100_000_000 ? n : null;
};
const TAX_TYPES = ['IVA', 'INC', 'NONE'];

export class MenuFileError extends Error {
  constructor(public code: string) { super(code); this.name = 'MenuFileError'; }
}

/** Sanea el archivo; lanza MenuFileError si no es una carta de Lantify */
export const parseMenuExport = (raw: unknown): MenuExport => {
  const r = raw && typeof raw === 'object' ? (raw as Record<string, any>) : null;
  if (!r || r.format !== MENU_FORMAT) throw new MenuFileError('MENU_FILE_INVALID');
  if (Number(r.version) > MENU_VERSION) throw new MenuFileError('MENU_FILE_NEWER');
  const seenCat = new Set<string>();
  const categories: MenuCategoryRow[] = [];
  for (const c of Array.isArray(r.categories) ? r.categories.slice(0, 200) : []) {
    const name = text(c?.name, 80);
    if (!name || seenCat.has(nameKey(name))) continue;
    seenCat.add(nameKey(name));
    categories.push({ name, description: text(c?.description, 300), printStation: text(c?.printStation, 40) });
  }
  const seenProd = new Set<string>();
  const products: MenuProduct[] = [];
  for (const p of Array.isArray(r.products) ? r.products.slice(0, 3000) : []) {
    const name = text(p?.name, 120);
    if (!name || seenProd.has(nameKey(name))) continue;
    const seenVar = new Set<string>();
    const variants: MenuVariant[] = [];
    for (const v of Array.isArray(p?.variants) ? p.variants.slice(0, 50) : []) {
      const vn = text(v?.name, 60);
      const price = money(v?.price);
      if (!vn || price === null || seenVar.has(nameKey(vn))) continue;
      seenVar.add(nameKey(vn));
      variants.push({ name: vn, price });
    }
    if (!variants.length) continue;
    seenProd.add(nameKey(name));
    const seenIng = new Set<string>();
    const recipe: MenuRecipeLine[] = [];
    for (const it of Array.isArray(p?.recipe) ? p.recipe.slice(0, 80) : []) {
      const ing = text(it?.ingredient, 80);
      const q = Number(it?.quantity);
      if (!ing || !Number.isFinite(q) || q <= 0 || q > 1_000_000 || seenIng.has(nameKey(ing))) continue;
      seenIng.add(nameKey(ing));
      recipe.push({ ingredient: ing, unit: ['g', 'ml', 'und'].includes(it?.unit) ? it.unit : 'g', quantity: Math.round(q * 1000) / 1000, removable: it?.removable !== false });
    }
    const taxType = TAX_TYPES.includes(p?.taxType) ? p.taxType : null;
    const rate = Number(p?.taxRate);
    const category = text(p?.category, 80);
    if (category && !seenCat.has(nameKey(category))) {
      seenCat.add(nameKey(category));
      categories.push({ name: category, description: null, printStation: null });
    }
    products.push({
      name,
      category,
      description: text(p?.description, 500),
      taxType,
      taxRate: taxType && Number.isFinite(rate) && rate >= 0 && rate <= 100 ? rate : null,
      printStation: text(p?.printStation, 40),
      ingredients: (Array.isArray(p?.ingredients) ? p.ingredients : []).map((x: unknown) => text(x, 40)).filter((x: string | null): x is string => !!x).slice(0, 24),
      isCover: p?.isCover === true,
      variants,
      recipe,
    });
  }
  return { format: MENU_FORMAT, version: MENU_VERSION, exportedAt: typeof r.exportedAt === 'string' ? r.exportedAt : '', business: text(r.business, 120), categories, products };
};

// ── Comparar con la carta de esta sede ─────────────────────

export interface LocalProduct {
  id: string;
  name: string;
  category: string | null;
  description: string | null;
  taxType: string | null;
  taxRate: number | null;
  printStation: string | null;
  ingredients: string[];
  isCover: boolean;
  variants: { id: string; name: string; price: number }[];
  recipe: { ingredient: string; quantity: number; removable: boolean }[];
}
export interface LocalMenu { categories: { id: string; name: string }[]; products: LocalProduct[]; ingredients: { id: string; name: string }[] }

export interface MenuPlan {
  createCategories: MenuCategoryRow[];
  createIngredients: { name: string; unit: string }[];
  createProducts: MenuProduct[];
  /** Producto existente: campos a cambiar, presentaciones nuevas, precios y receta */
  updateProducts: {
    id: string;
    name: string;
    fields: Partial<Pick<MenuProduct, 'category' | 'description' | 'taxType' | 'taxRate' | 'printStation' | 'ingredients' | 'isCover'>>;
    newVariants: MenuVariant[];
    prices: { variantId: string; name: string; from: number; to: number }[];
    recipe: MenuRecipeLine[];
  }[];
  unchanged: number;
  summary: { categories: number; ingredients: number; newProducts: number; updatedProducts: number; unchanged: number; newVariants: number; priceChanges: number; recipeLines: number };
}

const sameList = (a: string[], b: string[]) => a.length === b.length && a.every((x, i) => x === b[i]);

export const planMenuImport = (file: MenuExport, local: LocalMenu): MenuPlan => {
  const catKeys = new Set(local.categories.map((c) => nameKey(c.name)));
  const ingKeys = new Set(local.ingredients.map((i) => nameKey(i.name)));
  const byName = new Map<string, LocalProduct>();
  for (const p of local.products) if (!byName.has(nameKey(p.name))) byName.set(nameKey(p.name), p);

  const createCategories = file.categories.filter((c) => !catKeys.has(nameKey(c.name)));
  const createIngredients: { name: string; unit: string }[] = [];
  const addIngredient = (name: string, unit: string) => {
    if (ingKeys.has(nameKey(name))) return;
    ingKeys.add(nameKey(name));
    createIngredients.push({ name, unit });
  };

  const createProducts: MenuProduct[] = [];
  const updateProducts: MenuPlan['updateProducts'] = [];
  let unchanged = 0;
  for (const p of file.products) {
    p.recipe.forEach((r) => addIngredient(r.ingredient, r.unit));
    const cur = byName.get(nameKey(p.name));
    if (!cur) { createProducts.push(p); continue; }
    const fields: MenuPlan['updateProducts'][number]['fields'] = {};
    if (nameKey(cur.category || '') !== nameKey(p.category || '')) fields.category = p.category;
    if ((cur.description || null) !== p.description) fields.description = p.description;
    if ((cur.taxType || null) !== p.taxType || (cur.taxRate ?? null) !== p.taxRate) { fields.taxType = p.taxType; fields.taxRate = p.taxRate; }
    if ((cur.printStation || null) !== p.printStation) fields.printStation = p.printStation;
    if (!sameList(cur.ingredients, p.ingredients)) fields.ingredients = p.ingredients;
    if (cur.isCover !== p.isCover) fields.isCover = p.isCover;
    const vars = new Map(cur.variants.map((v) => [nameKey(v.name), v]));
    const newVariants = p.variants.filter((v) => !vars.has(nameKey(v.name)));
    const prices = p.variants
      .map((v) => ({ v, cur: vars.get(nameKey(v.name)) }))
      .filter((x) => x.cur && Math.round(x.cur.price * 100) !== Math.round(x.v.price * 100))
      .map((x) => ({ variantId: x.cur!.id, name: x.v.name, from: x.cur!.price, to: x.v.price }));
    const rec = new Map(cur.recipe.map((r) => [nameKey(r.ingredient), r]));
    const recipe = p.recipe.filter((r) => {
      const c = rec.get(nameKey(r.ingredient));
      return !c || Math.round(c.quantity * 1000) !== Math.round(r.quantity * 1000) || c.removable !== r.removable;
    });
    if (!Object.keys(fields).length && !newVariants.length && !prices.length && !recipe.length) { unchanged++; continue; }
    updateProducts.push({ id: cur.id, name: cur.name, fields, newVariants, prices, recipe });
  }
  return {
    createCategories,
    createIngredients,
    createProducts,
    updateProducts,
    unchanged,
    summary: {
      categories: createCategories.length,
      ingredients: createIngredients.length,
      newProducts: createProducts.length,
      updatedProducts: updateProducts.length,
      unchanged,
      newVariants: createProducts.reduce((n, p) => n + p.variants.length, 0) + updateProducts.reduce((n, p) => n + p.newVariants.length, 0),
      priceChanges: updateProducts.reduce((n, p) => n + p.prices.length, 0),
      recipeLines: createProducts.reduce((n, p) => n + p.recipe.length, 0) + updateProducts.reduce((n, p) => n + p.recipe.length, 0),
    },
  };
};

export const planIsEmpty = (p: MenuPlan) =>
  !p.createCategories.length && !p.createIngredients.length && !p.createProducts.length && !p.updateProducts.length;
