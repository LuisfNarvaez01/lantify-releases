// ============================================
// DOMAIN - Pedido desde la mesa (Fase 4 · 2)
// ============================================
// Cada mesa tiene un código aleatorio (tableToken) que va en su QR:
//   lantifypos.com/m/<slug>?mesa=<token>
// La caja publica las mesas con su código junto con la página; la nube guarda solo
// la huella del código y con ella sabe de qué mesa viene el pedido. El pedido espera
// a que el mesero lo acepte: aceptado, es una ronda nueva de esa mesa.
// Lo comparten la caja (src/), la nube (cloud/api-worker) y la página (web/).

import { MenuCategory, OrderLine, planLines } from './businessPage';

export const TABLE_TOKEN = /^[A-Za-z0-9_-]{16,64}$/;
export const isTableToken = (v: unknown): v is string => typeof v === 'string' && TABLE_TOKEN.test(v);

/** Código nuevo para el QR de una mesa (18 bytes al azar en base64url: 24 caracteres) */
export const newTableToken = (): string => {
  const bytes = new Uint8Array(18);
  globalThis.crypto.getRandomValues(bytes);
  let bin = '';
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
};

export const TABLE_ORDER_PAGE = 'https://lantifypos.com/m/';
export const tableOrderUrl = (slug: string, token: string) => `${TABLE_ORDER_PAGE}${slug}?mesa=${encodeURIComponent(token)}`;

/** Una mesa tal como la publica la caja (el código solo viaja a la nube; nunca se muestra en la página) */
export interface PublishedTable {
  id: string;
  label: string;
  token: string;
}

export interface TableOrderingConfig {
  enabled: boolean;
  tables: PublishedTable[];
}

export const MAX_PUBLISHED_TABLES = 300;

export const normalizeTableOrdering = (raw: unknown): TableOrderingConfig => {
  const src = raw && typeof raw === 'object' ? (raw as Record<string, unknown>) : {};
  const seen = new Set<string>();
  const tables: PublishedTable[] = [];
  for (const t of (Array.isArray(src.tables) ? src.tables : []).slice(0, MAX_PUBLISHED_TABLES) as any[]) {
    const id = typeof t?.id === 'string' ? t.id.slice(0, 64) : '';
    const label = typeof t?.label === 'string' ? t.label.trim().slice(0, 20) : '';
    if (!id || !label || !isTableToken(t?.token) || seen.has(t.token)) continue;
    seen.add(t.token);
    tables.push({ id, label, token: t.token });
  }
  return { enabled: src.enabled === true && tables.length > 0, tables };
};

export const MAX_TABLE_NOTE = 300;

export type TableOrderPlan =
  | { ok: true; lines: OrderLine[]; subtotal: number; total: number; notes: string | null }
  | { ok: false; code: string };

/**
 * Valida el pedido de la mesa contra la carta PUBLICADA: el navegador solo dice
 * qué y cuánto; nombre y precio salen de la carta. Sin datos personales ni pago:
 * la cuenta se cobra con la de la mesa.
 */
export const planTableOrder = (menu: MenuCategory[], input: { items?: unknown; notes?: unknown }): TableOrderPlan => {
  const planned = planLines(menu, input.items);
  if (!planned.ok) return planned;
  const subtotal = planned.lines.reduce((n, l) => n + l.price * l.qty, 0);
  const notes = typeof input.notes === 'string' && input.notes.trim() ? input.notes.trim().replace(/\s+/g, ' ').slice(0, MAX_TABLE_NOTE) : null;
  return { ok: true, lines: planned.lines, subtotal, total: subtotal, notes };
};

/** Nombre con que se ve el pedido en la caja y en el celular del mesero */
export const tableOrderName = (label: string) => `Mesa ${label}`;
