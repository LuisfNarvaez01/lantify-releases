// ============================================
// DOMAIN - Pantalla del cliente (Fase 4 · 10)
// ============================================
// La caja publica su carrito y la pantalla que mira el cliente lo muestra: líneas,
// total, propina sugerida y el QR de pago del negocio. Lo que llega de la caja se
// limpia aquí (nombres cortos, cantidades y precios razonables); el total se vuelve a
// sumar en el servidor. Es solo para mostrar: nunca cobra ni cambia la venta.

export interface CustomerCartLine {
  name: string;
  qty: number;
  unitPrice: number;
  total: number;
  note: string | null;
  /** Happy hour u otra regla que bajó el precio */
  badge: string | null;
}

export interface CustomerCart {
  lines: CustomerCartLine[];
  total: number;
  /** "Mesa 4", "Para llevar"… */
  label: string | null;
  /** Ya pagado en la mesa (cuentas divididas) */
  paid: number;
}

export const MAX_CART_LINES = 80;
/** El carrito publicado deja de mostrarse si la caja no lo vuelve a enviar en este tiempo */
export const CART_STALE_MS = 2 * 60 * 60_000;

const text = (v: unknown, max: number) => (typeof v === 'string' ? v.replace(/\s+/g, ' ').trim().slice(0, max) : '');
const money = (v: unknown) => {
  const n = Number(v);
  return Number.isFinite(n) && n >= 0 && n <= 1_000_000_000 ? Math.round(n) : 0;
};

/** Limpia el carrito que manda la caja; null si no trae nada que mostrar */
export const normalizeCustomerCart = (raw: unknown): CustomerCart | null => {
  const src = raw && typeof raw === 'object' ? (raw as Record<string, any>) : {};
  const list = Array.isArray(src.lines) ? src.lines.slice(0, MAX_CART_LINES) : [];
  const lines: CustomerCartLine[] = [];
  for (const l of list) {
    if (!l || typeof l !== 'object') continue;
    const name = text(l.name, 80);
    const qty = Math.round(Number(l.qty));
    if (!name || !Number.isFinite(qty) || qty <= 0 || qty > 999) continue;
    const unitPrice = money(l.unitPrice);
    lines.push({ name, qty, unitPrice, total: unitPrice * qty, note: text(l.note, 80) || null, badge: text(l.badge, 30) || null });
  }
  if (!lines.length) return null;
  return {
    lines,
    total: lines.reduce((n, l) => n + l.total, 0),
    label: text(src.label, 40) || null,
    paid: money(src.paid),
  };
};

/** Propina sugerida (la del negocio en Ajustes); 0 si no se usa propina */
export const suggestedTip = (total: number, tip: { enabled: boolean; percent: number }) =>
  tip.enabled && tip.percent > 0 ? Math.round((total * tip.percent) / 100) : 0;
