// ============================================
// DOMAIN - Asistencia con PIN y horario semanal (Fase 4 · 13)
// ============================================
// Cada empleado marca su entrada y salida con un PIN de 4 a 6 dígitos en la caja o
// en una pantalla de asistencia (sin iniciar sesión). El ADMIN programa el horario
// de la semana y ve las llegadas tarde y las horas trabajadas contra lo programado.
// Funciones puras: las horas son las del equipo del negocio.

export class AttendanceError extends Error {
  constructor(message: string, public code: string, public statusCode = 400) {
    super(message);
  }
}

const TIME_RE = /^([01]\d|2[0-3]):([0-5]\d)$/;
export const MAX_SLOTS_PER_WEEK = 21;
/** Minutos de gracia antes de contar una llegada tarde */
export const DEFAULT_GRACE_MIN = 5;

/** PIN válido: solo números, de 4 a 6 */
export const isValidPin = (pin: unknown): pin is string => typeof pin === 'string' && /^\d{4,6}$/.test(pin);

/** PINs demasiado fáciles de adivinar (1234, 0000, 1111…) */
export const isWeakPin = (pin: string) => {
  if (/^(\d)\1+$/.test(pin)) return true;
  const asc = '0123456789012345';
  const desc = '9876543210987654';
  return asc.includes(pin) || desc.includes(pin);
};

export interface ScheduleSlotInput {
  weekday: number;
  start: string;
  end: string;
}

const minutesOf = (hhmm: string) => Number(hhmm.slice(0, 2)) * 60 + Number(hhmm.slice(3, 5));

/** Duración de un turno programado en minutos (si termina antes de empezar, cruza la medianoche) */
export const slotMinutes = (s: Pick<ScheduleSlotInput, 'start' | 'end'>) => {
  const a = minutesOf(s.start);
  const b = minutesOf(s.end);
  return b > a ? b - a : b + 1440 - a;
};

/** Valida el horario de la semana que llega del editor */
export const normalizeSchedule = (raw: unknown): ScheduleSlotInput[] => {
  const list = Array.isArray(raw) ? raw : [];
  if (list.length > MAX_SLOTS_PER_WEEK) throw new AttendanceError(`Máximo ${MAX_SLOTS_PER_WEEK} turnos por semana.`, 'SCHEDULE_TOO_MANY');
  const out: ScheduleSlotInput[] = [];
  for (const item of list) {
    const r = item && typeof item === 'object' ? (item as Record<string, any>) : {};
    const weekday = Math.round(Number(r.weekday));
    if (!Number.isInteger(weekday) || weekday < 0 || weekday > 6) throw new AttendanceError('Día inválido en el horario.', 'SCHEDULE_DAY');
    const start = typeof r.start === 'string' && TIME_RE.test(r.start) ? r.start : '';
    const end = typeof r.end === 'string' && TIME_RE.test(r.end) ? r.end : '';
    if (!start || !end || start === end) throw new AttendanceError('Indica la hora de entrada y de salida de cada turno.', 'SCHEDULE_HOURS');
    out.push({ weekday, start, end });
  }
  // Dos turnos del mismo día no se pueden cruzar
  for (let d = 0; d < 7; d++) {
    const day = out.filter((s) => s.weekday === d).sort((a, b) => a.start.localeCompare(b.start));
    for (let i = 1; i < day.length; i++) {
      const prev = day[i - 1];
      const prevEnd = minutesOf(prev.start) + slotMinutes(prev);
      if (minutesOf(day[i].start) < prevEnd) throw new AttendanceError('Hay turnos que se cruzan el mismo día.', 'SCHEDULE_OVERLAP');
    }
  }
  return out.sort((a, b) => a.weekday - b.weekday || a.start.localeCompare(b.start));
};

export interface ReportEmployee { id: string; name: string }
export interface ReportSlot { employeeId: string; weekday: number; start: string; end: string }
export interface ReportShift { employeeId: string; startAt: Date; endAt: Date | null }

export interface LateArrival { employeeId: string; scheduledAt: string; arrivedAt: string; minutesLate: number }
export interface AttendanceRow {
  employeeId: string;
  name: string;
  scheduledMin: number;
  workedMin: number;
  /** Turnos programados que ya pasaron sin ninguna entrada */
  absences: number;
  lateCount: number;
  lateMin: number;
}

/** Medianoche del día de `d` (hora del equipo) */
const dayStart = (d: Date) => new Date(d.getFullYear(), d.getMonth(), d.getDate());

/**
 * Informe del periodo [from, to]: horas programadas y trabajadas, llegadas tarde y
 * ausencias. Una entrada cuenta para un turno programado si llega entre 3 horas antes
 * del inicio y el final del turno. Un turno sin salida cuenta hasta `now`.
 */
export const attendanceReport = (
  employees: ReportEmployee[],
  slots: ReportSlot[],
  shifts: ReportShift[],
  from: Date,
  to: Date,
  now: Date,
  graceMin = DEFAULT_GRACE_MIN,
): { rows: AttendanceRow[]; late: LateArrival[] } => {
  const rows: AttendanceRow[] = [];
  const late: LateArrival[] = [];
  const end = to < now ? to : now;
  for (const e of employees) {
    const mine = shifts.filter((s) => s.employeeId === e.id).sort((a, b) => a.startAt.getTime() - b.startAt.getTime());
    const mySlots = slots.filter((s) => s.employeeId === e.id);
    const row: AttendanceRow = { employeeId: e.id, name: e.name, scheduledMin: 0, workedMin: 0, absences: 0, lateCount: 0, lateMin: 0 };

    for (const s of mine) {
      const a = Math.max(s.startAt.getTime(), from.getTime());
      const b = Math.min((s.endAt || now).getTime(), to.getTime());
      if (b > a) row.workedMin += Math.round((b - a) / 60_000);
    }

    const used = new Set<ReportShift>();
    for (let d = dayStart(from); d <= to; d = new Date(d.getFullYear(), d.getMonth(), d.getDate() + 1)) {
      for (const slot of mySlots.filter((x) => x.weekday === d.getDay())) {
        const startAt = new Date(d.getFullYear(), d.getMonth(), d.getDate(), Number(slot.start.slice(0, 2)), Number(slot.start.slice(3, 5)));
        if (startAt < from || startAt > to) continue;
        const endAt = new Date(startAt.getTime() + slotMinutes(slot) * 60_000);
        row.scheduledMin += slotMinutes(slot);
        const match = mine.find((s) => !used.has(s) && s.startAt.getTime() >= startAt.getTime() - 3 * 3600_000 && s.startAt < endAt);
        if (!match) {
          if (startAt.getTime() + graceMin * 60_000 < end.getTime()) row.absences += 1;
          continue;
        }
        used.add(match);
        const minutesLate = Math.floor((match.startAt.getTime() - startAt.getTime()) / 60_000);
        if (minutesLate > graceMin) {
          row.lateCount += 1;
          row.lateMin += minutesLate;
          late.push({ employeeId: e.id, scheduledAt: startAt.toISOString(), arrivedAt: match.startAt.toISOString(), minutesLate });
        }
      }
    }
    rows.push(row);
  }
  return { rows, late: late.sort((a, b) => b.arrivedAt.localeCompare(a.arrivedAt)) };
};

// ── Límite de intentos de PIN ───────────────────────────────
// Por empleado (que nadie pruebe los 10 000 PIN de un compañero) y por equipo
// (que una pantalla no recorra a todo el personal).

export interface PinLimits { perEmployee: number; perSource: number; windowMs: number }
export const PIN_LIMITS: PinLimits = { perEmployee: 5, perSource: 15, windowMs: 10 * 60_000 };

export class PinLimiter {
  private fails = new Map<string, { n: number; until: number }>();
  constructor(private limits: PinLimits = PIN_LIMITS, private clock: () => number = Date.now) {}

  private count(key: string) {
    const f = this.fails.get(key);
    return f && f.until > this.clock() ? f.n : 0;
  }

  /** ¿Puede intentar? false = bloqueado hasta que pase la ventana */
  allowed(employeeId: string, source: string) {
    return this.count(`e:${employeeId}`) < this.limits.perEmployee && this.count(`s:${source}`) < this.limits.perSource;
  }

  fail(employeeId: string, source: string) {
    const now = this.clock();
    for (const key of [`e:${employeeId}`, `s:${source}`]) {
      const f = this.fails.get(key);
      const cur = f && f.until > now ? f : { n: 0, until: now + this.limits.windowMs };
      this.fails.set(key, { n: cur.n + 1, until: cur.until });
    }
  }

  /** PIN correcto: se olvidan los fallos de ese empleado (los del equipo siguen contando) */
  success(employeeId: string) {
    this.fails.delete(`e:${employeeId}`);
  }

  reset() {
    this.fails.clear();
  }
}
