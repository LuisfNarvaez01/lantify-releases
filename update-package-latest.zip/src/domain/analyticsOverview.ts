// ============================================
// DOMAIN - Resumen del negocio para Estadísticas
// ============================================
// Funciones puras (sin base de datos) que convierten las ventas y gastos de un
// período en lo que muestra el tablero: indicadores con su variación contra el
// período anterior, día a día, mapa de calor día × hora, medios de pago,
// canales, productos, categorías, equipo, clientes y gastos.
//
// Reglas:
// - Ingresos = total de las ventas COMPLETADAS (la propina no hace parte del total).
// - Anuladas = CANCELLED o REFUNDED; se cuentan aparte y no suman ingresos.
// - Costo y margen solo con los productos que tienen costo: `costCoverage` dice
//   qué parte de lo vendido lo tiene, para no presentar una utilidad inventada.
// - Fechas en la hora local del equipo (el POS corre en el local).

export interface OvItem {
  productId: string;
  productName: string;
  variantName: string;
  categoryName: string | null;
  quantity: number;
  total: number;
  /** Costo unitario de la variante; null = no tiene costo cargado */
  unitCost: number | null;
  cancelled: boolean;
}

export interface OvSale {
  createdAt: Date;
  status: string;
  total: number;
  discount: number;
  tip: number;
  channel: string | null;
  tableId: string | null;
  customerId: string | null;
  customerName: string | null;
  /** true = "Cliente común" (no identificado) */
  defaultCustomer: boolean;
  waiterName: string | null;
  cashierName: string | null;
  paymentMethod: string | null;
  payments: { method: string; amount: number }[];
  items: OvItem[];
}

export interface OvExpense {
  amount: number;
  categoryName: string | null;
  createdAt: Date;
}

export interface OvKpis {
  revenue: number;
  sales: number;
  avgTicket: number;
  items: number;
  itemsPerSale: number;
  tips: number;
  discounts: number;
  cancelledCount: number;
  cancelledAmount: number;
  expenses: number;
  /** Costo de lo vendido (solo productos con costo) */
  cogs: number;
  /** 0–1: parte de lo vendido que tiene costo cargado */
  costCoverage: number;
  /** Ingresos − costo, solo si al menos la mitad de lo vendido tiene costo */
  grossProfit: number | null;
  /** Ingresos − costo − gastos, mismas condiciones */
  netEstimate: number | null;
  /** 0–1: ventas con cliente identificado */
  identifiedShare: number;
  uniqueCustomers: number;
}

export interface Overview {
  range: { from: string; to: string; days: number; prevFrom: string; prevTo: string };
  kpis: OvKpis;
  prev: OvKpis;
  daily: { date: string; revenue: number; sales: number; prevRevenue: number }[];
  /** [día de la semana 0=lunes][hora 0–23] */
  heatmap: { sales: number[][]; revenue: number[][] };
  hourly: { hour: number; revenue: number; sales: number }[];
  /** Promedio por cada día de la semana que hubo en el período (0=lunes) */
  weekday: { day: number; avgRevenue: number; revenue: number; sales: number }[];
  payments: { method: string; amount: number; count: number }[];
  channels: { key: string; revenue: number; sales: number }[];
  productCount: number;
  products: { productId: string; name: string; category: string | null; units: number; revenue: number; cost: number | null; margin: number | null }[];
  categories: { name: string; revenue: number; units: number }[];
  staff: { name: string; sales: number; revenue: number; tips: number; avgTicket: number }[];
  customers: { name: string; sales: number; revenue: number }[];
  expensesByCategory: { name: string; amount: number }[];
}

const DAY_MS = 86_400_000;
export const MAX_RANGE_DAYS = 366;

export const localDateKey = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

/** 'YYYY-MM-DD' → Date local a las 00:00 */
export const parseLocalDate = (key: string): Date | null => {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(key || '');
  if (!m) return null;
  const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
  return Number.isNaN(d.getTime()) || localDateKey(d) !== key ? null : d;
};

const addDays = (d: Date, n: number) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);

/** Lunes = 0 ... domingo = 6 */
const weekdayIndex = (d: Date) => (d.getDay() + 6) % 7;

const isDone = (s: OvSale) => s.status === 'COMPLETED';
const isVoid = (s: OvSale) => s.status === 'CANCELLED' || s.status === 'REFUNDED';

/**
 * Rango del período y del anterior de la misma duración.
 * `to` es inclusivo (todo ese día). Lanza error con un rango inválido.
 */
export function resolveRange(fromKey: string, toKey: string) {
  const from = parseLocalDate(fromKey);
  const to = parseLocalDate(toKey);
  if (!from || !to) throw new Error('Fechas inválidas: usa from y to con formato AAAA-MM-DD');
  if (to < from) throw new Error('La fecha final es anterior a la inicial');
  const days = Math.round((to.getTime() - from.getTime()) / DAY_MS) + 1;
  if (days > MAX_RANGE_DAYS) throw new Error(`El período no puede pasar de ${MAX_RANGE_DAYS} días`);
  const prevTo = addDays(from, -1);
  const prevFrom = addDays(from, -days);
  return {
    from, to, days, prevFrom, prevTo,
    /** Límite exclusivo para consultas: inicio del día siguiente a `to` */
    toExclusive: addDays(to, 1),
    keys: { from: fromKey, to: toKey, prevFrom: localDateKey(prevFrom), prevTo: localDateKey(prevTo) },
  };
}

/**
 * Límite superior (exclusivo) del período anterior. Si el período termina hoy,
 * hoy va a medias: el anterior se corta a la misma hora de su último día para
 * comparar lo mismo (hoy a las 3 p. m. contra ayer hasta las 3 p. m.).
 */
export function prevUpperBound(r: ReturnType<typeof resolveRange>, now: Date): Date {
  if (localDateKey(now) !== r.keys.to) return r.from;
  const elapsed = now.getTime() - new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  return new Date(r.prevTo.getTime() + elapsed);
}

export function computeKpis(sales: OvSale[], expenses: OvExpense[]): OvKpis {
  let revenue = 0, count = 0, items = 0, tips = 0, discounts = 0, cancelledCount = 0, cancelledAmount = 0;
  let cogs = 0, itemRevenue = 0, costedRevenue = 0, identified = 0;
  const customers = new Set<string>();
  for (const s of sales) {
    if (isVoid(s)) { cancelledCount++; cancelledAmount += s.total; continue; }
    if (!isDone(s)) continue;
    count++;
    revenue += s.total;
    tips += s.tip || 0;
    discounts += s.discount || 0;
    if (s.customerId && !s.defaultCustomer) { identified++; customers.add(s.customerId); }
    for (const it of s.items) {
      if (it.cancelled) continue;
      items += it.quantity;
      itemRevenue += it.total;
      if (it.unitCost !== null && it.unitCost !== undefined) {
        cogs += it.unitCost * it.quantity;
        costedRevenue += it.total;
      }
    }
  }
  const expenseTotal = expenses.reduce((a, e) => a + e.amount, 0);
  const costCoverage = itemRevenue > 0 ? costedRevenue / itemRevenue : 0;
  // Con menos de la mitad de lo vendido costeado, la utilidad sería engañosa
  const reliable = costCoverage >= 0.5;
  const grossProfit = reliable ? revenue - cogs : null;
  return {
    revenue,
    sales: count,
    avgTicket: count ? revenue / count : 0,
    items,
    itemsPerSale: count ? items / count : 0,
    tips,
    discounts,
    cancelledCount,
    cancelledAmount,
    expenses: expenseTotal,
    cogs,
    costCoverage,
    grossProfit,
    netEstimate: grossProfit === null ? null : grossProfit - expenseTotal,
    identifiedShare: count ? identified / count : 0,
    uniqueCustomers: customers.size,
  };
}

const channelKey = (s: OvSale) => {
  const c = (s.channel || 'POS').toUpperCase();
  if (c === 'POS') return s.tableId ? 'TABLE' : 'COUNTER';
  return c;
};

const top = <T>(arr: T[], by: (x: T) => number, n: number) => [...arr].sort((a, b) => by(b) - by(a)).slice(0, n);

export function buildOverview(input: {
  fromKey: string;
  toKey: string;
  sales: OvSale[];
  prevSales: OvSale[];
  expenses: OvExpense[];
  prevExpenses: OvExpense[];
}): Overview {
  const r = resolveRange(input.fromKey, input.toKey);
  const done = input.sales.filter(isDone);

  // ── Día a día (con el día equivalente del período anterior) ──
  const daily = Array.from({ length: r.days }, (_, i) => ({ date: localDateKey(addDays(r.from, i)), revenue: 0, sales: 0, prevRevenue: 0 }));
  const dayIndex = new Map(daily.map((d, i) => [d.date, i]));
  for (const s of done) {
    const i = dayIndex.get(localDateKey(s.createdAt));
    if (i !== undefined) { daily[i].revenue += s.total; daily[i].sales++; }
  }
  for (const s of input.prevSales) {
    if (!isDone(s)) continue;
    const i = Math.round((new Date(s.createdAt.getFullYear(), s.createdAt.getMonth(), s.createdAt.getDate()).getTime() - r.prevFrom.getTime()) / DAY_MS);
    if (i >= 0 && i < r.days) daily[i].prevRevenue += s.total;
  }

  // ── Mapa de calor, horas y días de la semana ──
  const heatSales = Array.from({ length: 7 }, () => Array(24).fill(0));
  const heatRevenue = Array.from({ length: 7 }, () => Array(24).fill(0));
  const hourly = Array.from({ length: 24 }, (_, hour) => ({ hour, revenue: 0, sales: 0 }));
  const weekdayAgg = Array.from({ length: 7 }, (_, day) => ({ day, revenue: 0, sales: 0, avgRevenue: 0 }));
  for (const s of done) {
    const wd = weekdayIndex(s.createdAt);
    const h = s.createdAt.getHours();
    heatSales[wd][h]++;
    heatRevenue[wd][h] += s.total;
    hourly[h].revenue += s.total;
    hourly[h].sales++;
    weekdayAgg[wd].revenue += s.total;
    weekdayAgg[wd].sales++;
  }
  const occurrences = Array(7).fill(0);
  for (let i = 0; i < r.days; i++) occurrences[weekdayIndex(addDays(r.from, i))]++;
  for (const w of weekdayAgg) w.avgRevenue = occurrences[w.day] ? w.revenue / occurrences[w.day] : 0;

  // ── Medios de pago (los pagos reales; si no hay, el medio de la venta) ──
  const pay = new Map<string, { method: string; amount: number; count: number }>();
  const addPay = (method: string, amount: number) => {
    const m = (method || 'OTHER').toUpperCase();
    const e = pay.get(m) || { method: m, amount: 0, count: 0 };
    e.amount += amount; e.count++;
    pay.set(m, e);
  };
  for (const s of done) {
    if (s.payments.length) for (const p of s.payments) addPay(p.method, p.amount);
    else addPay(s.paymentMethod || 'CASH', s.total);
  }

  // ── Canales ──
  const ch = new Map<string, { key: string; revenue: number; sales: number }>();
  for (const s of done) {
    const k = channelKey(s);
    const e = ch.get(k) || { key: k, revenue: 0, sales: 0 };
    e.revenue += s.total; e.sales++;
    ch.set(k, e);
  }

  // ── Productos y categorías ──
  const prod = new Map<string, { productId: string; name: string; category: string | null; units: number; revenue: number; costSum: number; costed: boolean }>();
  const cat = new Map<string, { name: string; revenue: number; units: number }>();
  for (const s of done) {
    for (const it of s.items) {
      if (it.cancelled) continue;
      const p = prod.get(it.productId) || { productId: it.productId, name: it.productName, category: it.categoryName, units: 0, revenue: 0, costSum: 0, costed: true };
      p.units += it.quantity;
      p.revenue += it.total;
      if (it.unitCost === null || it.unitCost === undefined) p.costed = false;
      else p.costSum += it.unitCost * it.quantity;
      prod.set(it.productId, p);
      const cn = it.categoryName || 'Sin categoría';
      const c = cat.get(cn) || { name: cn, revenue: 0, units: 0 };
      c.revenue += it.total; c.units += it.quantity;
      cat.set(cn, c);
    }
  }
  const products = top([...prod.values()], (p) => p.revenue, 20).map((p) => ({
    productId: p.productId, name: p.name, category: p.category, units: p.units, revenue: p.revenue,
    cost: p.costed ? p.costSum : null,
    margin: p.costed && p.revenue > 0 ? (p.revenue - p.costSum) / p.revenue : null,
  }));

  // ── Equipo (quién atendió; si no hay mesero, quién cobró) ──
  const staffMap = new Map<string, { name: string; sales: number; revenue: number; tips: number; avgTicket: number }>();
  for (const s of done) {
    const name = (s.waiterName || s.cashierName || '').trim();
    if (!name) continue;
    const e = staffMap.get(name) || { name, sales: 0, revenue: 0, tips: 0, avgTicket: 0 };
    e.sales++; e.revenue += s.total; e.tips += s.tip || 0;
    staffMap.set(name, e);
  }
  for (const e of staffMap.values()) e.avgTicket = e.sales ? e.revenue / e.sales : 0;

  // ── Clientes identificados ──
  const custMap = new Map<string, { name: string; sales: number; revenue: number }>();
  for (const s of done) {
    if (!s.customerId || s.defaultCustomer) continue;
    const e = custMap.get(s.customerId) || { name: s.customerName || 'Cliente', sales: 0, revenue: 0 };
    e.sales++; e.revenue += s.total;
    custMap.set(s.customerId, e);
  }

  // ── Gastos por categoría ──
  const expMap = new Map<string, number>();
  for (const e of input.expenses) {
    const n = e.categoryName || 'Sin categoría';
    expMap.set(n, (expMap.get(n) || 0) + e.amount);
  }

  return {
    range: { ...r.keys, days: r.days },
    kpis: computeKpis(input.sales, input.expenses),
    prev: computeKpis(input.prevSales, input.prevExpenses),
    daily,
    heatmap: { sales: heatSales, revenue: heatRevenue },
    hourly,
    weekday: weekdayAgg,
    payments: top([...pay.values()], (p) => p.amount, 10),
    channels: top([...ch.values()], (c) => c.revenue, 10),
    productCount: prod.size,
    products,
    categories: top([...cat.values()], (c) => c.revenue, 12),
    staff: top([...staffMap.values()], (s) => s.revenue, 12),
    customers: top([...custMap.values()], (c) => c.revenue, 10),
    expensesByCategory: top([...expMap.entries()].map(([name, amount]) => ({ name, amount })), (e) => e.amount, 10),
  };
}

/** Ingresos por mes de un año y del anterior (barras de 12 meses) */
export function monthlyRevenue(sales: { createdAt: Date; total: number; status: string }[], year: number) {
  const current = Array(12).fill(0);
  const previous = Array(12).fill(0);
  const counts = Array(12).fill(0);
  for (const s of sales) {
    if (s.status !== 'COMPLETED') continue;
    const y = s.createdAt.getFullYear();
    const m = s.createdAt.getMonth();
    if (y === year) { current[m] += s.total; counts[m]++; } else if (y === year - 1) previous[m] += s.total;
  }
  return { year, months: current.map((revenue, i) => ({ month: i + 1, revenue, sales: counts[i], prevRevenue: previous[i] })) };
}
