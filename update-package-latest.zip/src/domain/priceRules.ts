// ============================================
// DOMAIN - Happy hour y precios por horario (Fase 4 · 7)
// ============================================
// Una regla baja el precio de parte de la carta en ciertos días y horas:
// porcentaje de descuento (PERCENT) o un precio especial fijo (FIXED). Nunca sube
// un precio. La usan la caja, el celular y la página del negocio para mostrar el
// precio, y el servidor para revisar el cobro: un precio menor al de la carta solo
// se acepta si una regla vigente lo justifica.
// Las horas son las del equipo del negocio. Si la hora de fin es menor que la de
// inicio, la regla cruza la medianoche (22:00–02:00) y cuenta para el día en que empieza.

export type PriceRuleKind = 'PERCENT' | 'FIXED';

export interface PriceRuleScope {
  categoryIds: string[];
  variantIds: string[];
}

export interface PriceRule {
  id: string;
  name: string;
  /** Máscara de días: bit 0 = domingo … bit 6 = sábado */
  weekdays: number;
  start: string; // "HH:mm"
  end: string;   // "HH:mm"
  /** Sin categorías ni productos = toda la carta */
  scope: PriceRuleScope;
  kind: PriceRuleKind;
  value: number;
  active: boolean;
}

export const ALL_DAYS = 0b1111111;
const TIME_RE = /^([01]\d|2[0-3]):([0-5]\d)$/;
/** Diferencia de redondeo que se tolera al revisar un precio (pesos) */
export const PRICE_TOLERANCE = 1;

const ids = (v: unknown, max = 200): string[] =>
  Array.isArray(v) ? [...new Set(v.filter((x): x is string => typeof x === 'string' && x.length > 0 && x.length <= 64))].slice(0, max) : [];

export class PriceRuleError extends Error {
  constructor(message: string, public code: string) {
    super(message);
  }
}

/** Valida lo que llega del formulario; lanza PriceRuleError con un mensaje claro */
export const normalizePriceRule = (raw: unknown): Omit<PriceRule, 'id'> => {
  const r = raw && typeof raw === 'object' ? (raw as Record<string, any>) : {};
  const name = typeof r.name === 'string' ? r.name.trim().slice(0, 40) : '';
  if (!name) throw new PriceRuleError('Ponle un nombre a la regla (por ejemplo, Happy hour).', 'PRICE_RULE_NAME');
  const weekdays = Math.round(Number(r.weekdays)) & ALL_DAYS;
  if (!weekdays) throw new PriceRuleError('Elige al menos un día.', 'PRICE_RULE_DAYS');
  const start = typeof r.start === 'string' && TIME_RE.test(r.start) ? r.start : '';
  const end = typeof r.end === 'string' && TIME_RE.test(r.end) ? r.end : '';
  if (!start || !end) throw new PriceRuleError('Indica la hora de inicio y de fin.', 'PRICE_RULE_HOURS');
  const kind: PriceRuleKind = r.kind === 'FIXED' ? 'FIXED' : 'PERCENT';
  const value = Number(r.value);
  if (kind === 'PERCENT' && !(Number.isFinite(value) && value > 0 && value < 100)) {
    throw new PriceRuleError('El descuento debe estar entre 1 % y 99 %.', 'PRICE_RULE_VALUE');
  }
  if (kind === 'FIXED' && !(Number.isFinite(value) && value > 0 && value <= 100_000_000)) {
    throw new PriceRuleError('Escribe el precio especial.', 'PRICE_RULE_VALUE');
  }
  const s = r.scope && typeof r.scope === 'object' ? r.scope : {};
  const scope = { categoryIds: ids(s.categoryIds), variantIds: ids(s.variantIds, 500) };
  if (kind === 'FIXED' && !scope.categoryIds.length && !scope.variantIds.length) {
    throw new PriceRuleError('Un precio especial necesita productos o categorías.', 'PRICE_RULE_SCOPE');
  }
  return { name, weekdays, start, end, scope, kind, value: kind === 'PERCENT' ? Math.round(value) : Math.round(value), active: r.active !== false };
};

/** Regla guardada en la base (scope en JSON) → regla del dominio; null si está dañada */
export const parsePriceRule = (row: { id: string; name: string; weekdays: number; start: string; end: string; scope: string | null; kind: string; value: number; active: boolean }): PriceRule | null => {
  try {
    const n = normalizePriceRule({ ...row, scope: row.scope ? JSON.parse(row.scope) : {} });
    return { id: row.id, ...n, active: row.active };
  } catch {
    return null;
  }
};

const minutes = (hhmm: string) => Number(hhmm.slice(0, 2)) * 60 + Number(hhmm.slice(3, 5));
const hasDay = (mask: number, day: number) => ((mask >> day) & 1) === 1;

/** ¿La regla está vigente en este momento? */
export const isRuleActive = (rule: PriceRule, now: Date): boolean => {
  if (!rule.active) return false;
  const m = now.getHours() * 60 + now.getMinutes();
  const day = now.getDay();
  const s = minutes(rule.start);
  const e = minutes(rule.end);
  if (s === e) return hasDay(rule.weekdays, day); // todo el día
  if (s < e) return hasDay(rule.weekdays, day) && m >= s && m < e;
  // Cruza la medianoche: la parte de la noche es del día en que empieza
  return (hasDay(rule.weekdays, day) && m >= s) || (hasDay(rule.weekdays, (day + 6) % 7) && m < e);
};

export const activeRules = (now: Date, rules: PriceRule[]): PriceRule[] => rules.filter((r) => isRuleActive(r, now));

export const appliesTo = (rule: PriceRule, variantId: string, categoryId: string | null | undefined): boolean => {
  const { categoryIds, variantIds } = rule.scope;
  if (!categoryIds.length && !variantIds.length) return true;
  return variantIds.includes(variantId) || (!!categoryId && categoryIds.includes(categoryId));
};

/** Precio que deja la regla (nunca más alto que el de la carta) */
export const rulePrice = (rule: PriceRule, base: number): number => {
  const p = rule.kind === 'PERCENT' ? Math.round(base * (1 - rule.value / 100)) : Math.round(rule.value);
  return Math.max(0, Math.min(base, p));
};

/** Precio de una variante a esta hora: el más bajo de las reglas vigentes que la incluyen */
export const priceFor = (
  variant: { id: string; price: number },
  categoryId: string | null | undefined,
  now: Date,
  rules: PriceRule[],
): { price: number; rule?: PriceRule } => {
  let best: { price: number; rule?: PriceRule } = { price: variant.price };
  for (const r of activeRules(now, rules)) {
    if (!appliesTo(r, variant.id, categoryId)) continue;
    const p = rulePrice(r, variant.price);
    if (p < best.price) best = { price: p, rule: r };
  }
  return best;
};

/**
 * Revisión del servidor al cobrar. Un precio igual o mayor al de la carta pasa siempre
 * (como antes). Uno menor pasa solo si alguna regla, vigente en alguno de los momentos
 * dados (ahora, o cuando se pidió en la mesa), lo justifica.
 */
export const justifyPrice = (
  variant: { id: string; price: number },
  categoryId: string | null | undefined,
  unitPrice: number,
  moments: Date[],
  rules: PriceRule[],
): { ok: boolean; rule?: PriceRule } => {
  if (unitPrice >= variant.price - PRICE_TOLERANCE) return { ok: true };
  let found: PriceRule | undefined;
  for (const at of moments) {
    const best = priceFor(variant, categoryId, at, rules);
    if (best.rule && unitPrice >= best.price - PRICE_TOLERANCE && (!found || best.price < rulePrice(found, variant.price))) found = best.rule;
  }
  return found ? { ok: true, rule: found } : { ok: false };
};

// ── Texto para la página del negocio ──

const DAY_ES = ['dom', 'lun', 'mar', 'mié', 'jue', 'vie', 'sáb'];
const DAY_EN = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

/** "5 pm", "5:30 pm", "12 m" */
export const hourLabel = (hhmm: string, lang: 'es' | 'en' = 'es'): string => {
  const total = minutes(hhmm);
  const h = Math.floor(total / 60);
  const m = total % 60;
  const h12 = h % 12 === 0 ? 12 : h % 12;
  const suffix = lang === 'en' ? (h < 12 ? 'am' : 'pm') : h === 12 && m === 0 ? 'm' : h < 12 ? 'am' : 'pm';
  return `${h12}${m ? `:${String(m).padStart(2, '0')}` : ''} ${suffix}`;
};

/** "lun a vie", "todos los días", "sáb y dom", "lun, mié, vie" */
export const daysLabel = (mask: number, lang: 'es' | 'en' = 'es'): string => {
  const names = lang === 'en' ? DAY_EN : DAY_ES;
  const order = [1, 2, 3, 4, 5, 6, 0]; // la semana empieza el lunes
  const on = order.filter((d) => hasDay(mask, d));
  if (on.length === 7) return lang === 'en' ? 'every day' : 'todos los días';
  // Un tramo seguido de 3 o más días: "lun a vie"
  const idx = on.map((d) => order.indexOf(d));
  const consecutive = idx.every((v, i) => i === 0 || v === idx[i - 1] + 1);
  if (consecutive && on.length >= 3) return `${names[on[0]]} ${lang === 'en' ? 'to' : 'a'} ${names[on[on.length - 1]]}`;
  if (on.length === 2) return `${names[on[0]]} ${lang === 'en' ? 'and' : 'y'} ${names[on[1]]}`;
  return on.map((d) => names[d]).join(', ');
};

export interface PublicHappyHour {
  name: string;
  weekdays: number;
  start: string;
  end: string;
  kind: PriceRuleKind;
  value: number;
}

/** Lo que se publica en la página: solo las reglas activas, sin productos ni ids */
export const publicHappyHours = (rules: PriceRule[]): PublicHappyHour[] =>
  rules.filter((r) => r.active).slice(0, 6).map((r) => ({ name: r.name, weekdays: r.weekdays, start: r.start, end: r.end, kind: r.kind, value: r.value }));

export const normalizePublicHappyHours = (raw: unknown): PublicHappyHour[] => {
  if (!Array.isArray(raw)) return [];
  const out: PublicHappyHour[] = [];
  for (const item of raw.slice(0, 6)) {
    try {
      const n = normalizePriceRule({ ...item, scope: { variantIds: ['x'] } });
      out.push({ name: n.name, weekdays: n.weekdays, start: n.start, end: n.end, kind: n.kind, value: n.value });
    } catch {
      // se descarta lo que no es válido
    }
  }
  return out;
};

/** "Happy hour · lun a vie · 5 pm – 7 pm" */
export const happyHourLabel = (h: Pick<PublicHappyHour, 'name' | 'weekdays' | 'start' | 'end'>, lang: 'es' | 'en' = 'es') =>
  `${h.name} · ${daysLabel(h.weekdays, lang)} · ${hourLabel(h.start, lang)} – ${hourLabel(h.end, lang)}`;
