// ============================================
// DOMAIN - Configuración de impresión (compartida por todos los equipos)
// ============================================
// Vive en el servidor del negocio: la caja y las tablets imprimen igual. Con
// impresión directa el ticket sale sin ventanas en la impresora elegida (USB por
// Windows o de red por IP); con "navegador" se abre el diálogo de impresión.

export type PrintMode = 'direct' | 'browser';
export type PaperWidth = '58mm' | '80mm';
export type PrintCodepage = 'cp850' | 'cp1252' | 'ascii';

export type PrinterTarget =
  | { type: 'windows'; name: string }
  | { type: 'network'; host: string; port: number };

export interface PrintSettings {
  mode: PrintMode;
  /** Impresora de la caja: recibos, pre-cuentas y cierres */
  receipt: PrinterTarget | null;
  /** Impresora de la cocina o barra: comandas (vacía = la de la caja) */
  kitchen: PrinterTarget | null;
  paperWidth: PaperWidth;
  /** Margen del diálogo del navegador (la impresión directa usa el ancho del rollo) */
  margin: '0mm' | '2mm' | '4mm';
  fontSize: 'compact' | 'medium' | 'large';
  font: 'sans-serif' | 'monospace';
  language: 'es' | 'en';
  codepage: PrintCodepage;
  showLogo: boolean;
  footer: string;
  /** Imprimir el recibo solo al cobrar (sin preguntar) */
  autoPrintReceipt: boolean;
  /** Enviar la comanda a cocina al pedir */
  autoPrintKitchen: boolean;
  receiptCopies: number;
  kitchenCopies: number;
  cut: boolean;
  /** Abrir el cajón monedero conectado a la impresora al cobrar en efectivo */
  openDrawer: boolean;
}

export const DEFAULT_PRINT_SETTINGS: PrintSettings = {
  mode: 'browser',
  receipt: null,
  kitchen: null,
  paperWidth: '80mm',
  margin: '2mm',
  fontSize: 'medium',
  font: 'sans-serif',
  language: 'es',
  codepage: 'cp850',
  showLogo: true,
  footer: '',
  autoPrintReceipt: true,
  autoPrintKitchen: true,
  receiptCopies: 1,
  kitchenCopies: 1,
  cut: true,
  openDrawer: false,
};

/** Caracteres por línea en la fuente normal de una impresora térmica */
export const columnsFor = (paper: PaperWidth) => (paper === '58mm' ? 32 : 48);
/** Ancho útil en puntos (203 ppp): lo usan el logo y el QR */
export const dotsFor = (paper: PaperWidth) => (paper === '58mm' ? 384 : 576);

const pick = <T extends string>(v: unknown, allowed: readonly T[], fallback: T): T =>
  (allowed as readonly unknown[]).includes(v) ? (v as T) : fallback;

const HOST_RE = /^(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)$|^[a-zA-Z0-9][a-zA-Z0-9.-]{0,62}$/;

export const normalizeTarget = (raw: unknown): PrinterTarget | null => {
  if (!raw || typeof raw !== 'object') return null;
  const r = raw as Record<string, unknown>;
  if (r.type === 'windows' && typeof r.name === 'string') {
    // Nombre tal como lo muestra Windows; sin saltos de línea ni comillas
    const name = r.name.trim().slice(0, 120);
    return name && !/["\r\n\0]/.test(name) ? { type: 'windows', name } : null;
  }
  if (r.type === 'network' && typeof r.host === 'string') {
    const host = r.host.trim();
    const port = Math.round(Number(r.port) || 9100);
    return HOST_RE.test(host) && port > 0 && port < 65536 ? { type: 'network', host, port } : null;
  }
  return null;
};

const count = (v: unknown, fallback: number) => {
  const n = Math.round(Number(v));
  return Number.isFinite(n) ? Math.max(1, Math.min(3, n)) : fallback;
};

export const normalizePrintSettings = (raw: unknown): PrintSettings => {
  const r = raw && typeof raw === 'object' ? (raw as Record<string, unknown>) : {};
  const d = DEFAULT_PRINT_SETTINGS;
  const bool = (v: unknown, fallback: boolean) => (typeof v === 'boolean' ? v : fallback);
  return {
    mode: pick(r.mode, ['direct', 'browser'] as const, d.mode),
    receipt: normalizeTarget(r.receipt),
    kitchen: normalizeTarget(r.kitchen),
    paperWidth: pick(r.paperWidth, ['58mm', '80mm'] as const, d.paperWidth),
    margin: pick(r.margin, ['0mm', '2mm', '4mm'] as const, d.margin),
    fontSize: pick(r.fontSize, ['compact', 'medium', 'large'] as const, d.fontSize),
    font: pick(r.font, ['sans-serif', 'monospace'] as const, d.font),
    language: pick(r.language, ['es', 'en'] as const, d.language),
    codepage: pick(r.codepage, ['cp850', 'cp1252', 'ascii'] as const, d.codepage),
    showLogo: bool(r.showLogo, d.showLogo),
    footer: typeof r.footer === 'string' ? r.footer.replace(/[\r\n]+/g, ' ').trim().slice(0, 200) : d.footer,
    autoPrintReceipt: bool(r.autoPrintReceipt, d.autoPrintReceipt),
    autoPrintKitchen: bool(r.autoPrintKitchen, d.autoPrintKitchen),
    receiptCopies: count(r.receiptCopies, d.receiptCopies),
    kitchenCopies: count(r.kitchenCopies, d.kitchenCopies),
    cut: bool(r.cut, d.cut),
    openDrawer: bool(r.openDrawer, d.openDrawer),
  };
};
