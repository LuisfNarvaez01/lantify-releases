// ============================================
// DOMAIN - Configuración de impresión (compartida por todos los equipos)
// ============================================
// Vive en el servidor del negocio: la caja y las tablets imprimen igual. Con
// impresión directa el ticket sale sin ventanas en la impresora elegida (USB por
// Windows o de red por IP); con "navegador" se abre el diálogo de impresión.

export type PrintMode = 'direct' | 'browser';
export type PaperWidth = '58mm' | '80mm';
export type PrintCodepage = 'cp850' | 'cp1252' | 'ascii';

export type PrinterTarget =
  | { type: 'windows'; name: string }
  | { type: 'network'; host: string; port: number };

/**
 * Estación de comandas: un punto de preparación con su propia impresora (barra,
 * parrilla, postres...). La cocina principal es la estación "kitchen" y usa la
 * impresora `kitchen`; cada categoría o producto elige a cuál va su comanda.
 */
export interface PrintStation {
  id: string;
  name: string;
  /** Vacía = imprime en la impresora de la cocina principal */
  target: PrinterTarget | null;
  copies: number;
}

/** Cocina principal: donde va todo lo que no tiene estación elegida */
export const MAIN_STATION = 'kitchen';
/** Productos que no generan comanda (gaseosas en botella, empacados...) */
export const NO_STATION = 'none';
export const MAX_STATIONS = 6;
const STATION_ID_RE = /^[a-z0-9][a-z0-9-]{0,23}$/;

/** Valor válido para guardar en una categoría o producto (null = sin elegir) */
export const normalizeStationRef = (v: unknown): string | null =>
  typeof v === 'string' && STATION_ID_RE.test(v.trim()) ? v.trim() : null;

/** Identificador corto a partir del nombre: "Barra de jugos" → "barra-de-jugos" */
export const stationIdFrom = (name: string, taken: string[]) => {
  const base = name.normalize('NFD').replace(/\p{M}/gu, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 20) || 'estacion';
  let id = base === MAIN_STATION || base === NO_STATION ? `${base}-2` : base;
  for (let n = 2; taken.includes(id); n++) id = `${base}-${n}`;
  return id;
};

export interface PrintSettings {
  mode: PrintMode;
  /** Impresora de la caja: recibos, pre-cuentas y cierres */
  receipt: PrinterTarget | null;
  /** Impresora de la cocina o barra: comandas (vacía = la de la caja) */
  kitchen: PrinterTarget | null;
  /** Estaciones adicionales a la cocina principal (barra, postres...) */
  stations: PrintStation[];
  paperWidth: PaperWidth;
  /** Margen del diálogo del navegador (la impresión directa usa el ancho del rollo) */
  margin: '0mm' | '2mm' | '4mm';
  fontSize: 'compact' | 'medium' | 'large';
  font: 'sans-serif' | 'monospace';
  /** Qué tan oscura sale la letra (las láser y algunas térmicas la dejan muy clara) */
  darkness: 'normal' | 'dark' | 'extra';
  language: 'es' | 'en';
  codepage: PrintCodepage;
  showLogo: boolean;
  footer: string;
  /** Imprimir el recibo solo al cobrar (sin preguntar) */
  autoPrintReceipt: boolean;
  /** Enviar la comanda a cocina al pedir */
  autoPrintKitchen: boolean;
  receiptCopies: number;
  kitchenCopies: number;
  cut: boolean;
  /** Abrir el cajón monedero conectado a la impresora al cobrar en efectivo */
  openDrawer: boolean;
}

export const DEFAULT_PRINT_SETTINGS: PrintSettings = {
  mode: 'browser',
  receipt: null,
  kitchen: null,
  stations: [],
  paperWidth: '80mm',
  margin: '2mm',
  fontSize: 'medium',
  font: 'sans-serif',
  darkness: 'normal',
  language: 'es',
  codepage: 'cp850',
  showLogo: true,
  footer: '',
  autoPrintReceipt: true,
  autoPrintKitchen: true,
  receiptCopies: 1,
  kitchenCopies: 1,
  cut: true,
  openDrawer: false,
};

/** Caracteres por línea en la fuente normal de una impresora térmica */
export const columnsFor = (paper: PaperWidth) => (paper === '58mm' ? 32 : 48);
/** Ancho útil en puntos (203 ppp): lo usan el logo y el QR */
export const dotsFor = (paper: PaperWidth) => (paper === '58mm' ? 384 : 576);

const pick = <T extends string>(v: unknown, allowed: readonly T[], fallback: T): T =>
  (allowed as readonly unknown[]).includes(v) ? (v as T) : fallback;

const HOST_RE = /^(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)$|^[a-zA-Z0-9][a-zA-Z0-9.-]{0,62}$/;

export const normalizeTarget = (raw: unknown): PrinterTarget | null => {
  if (!raw || typeof raw !== 'object') return null;
  const r = raw as Record<string, unknown>;
  if (r.type === 'windows' && typeof r.name === 'string') {
    // Nombre tal como lo muestra Windows; sin saltos de línea ni comillas
    const name = r.name.trim().slice(0, 120);
    return name && !/["\r\n\0]/.test(name) ? { type: 'windows', name } : null;
  }
  if (r.type === 'network' && typeof r.host === 'string') {
    const host = r.host.trim();
    const port = Math.round(Number(r.port) || 9100);
    return HOST_RE.test(host) && port > 0 && port < 65536 ? { type: 'network', host, port } : null;
  }
  return null;
};

const count = (v: unknown, fallback: number) => {
  const n = Math.round(Number(v));
  return Number.isFinite(n) ? Math.max(1, Math.min(3, n)) : fallback;
};

export const normalizeStations = (raw: unknown): PrintStation[] => {
  if (!Array.isArray(raw)) return [];
  const out: PrintStation[] = [];
  for (const item of raw) {
    if (!item || typeof item !== 'object' || out.length >= MAX_STATIONS) continue;
    const r = item as Record<string, unknown>;
    const id = normalizeStationRef(r.id);
    const name = typeof r.name === 'string' ? r.name.replace(/[\r\n]+/g, ' ').trim().slice(0, 30) : '';
    if (!id || !name || id === MAIN_STATION || id === NO_STATION || out.some((s) => s.id === id)) continue;
    out.push({ id, name, target: normalizeTarget(r.target), copies: count(r.copies, 1) });
  }
  return out;
};

/** Impresora de una estación: la suya, si no la de cocina, si no la de la caja */
export const stationTarget = (settings: PrintSettings, stationId?: string | null): PrinterTarget | null => {
  const station = stationId ? settings.stations.find((s) => s.id === stationId) : undefined;
  return station?.target || settings.kitchen || settings.receipt;
};

export const normalizePrintSettings = (raw: unknown): PrintSettings => {
  const r = raw && typeof raw === 'object' ? (raw as Record<string, unknown>) : {};
  const d = DEFAULT_PRINT_SETTINGS;
  const bool = (v: unknown, fallback: boolean) => (typeof v === 'boolean' ? v : fallback);
  return {
    mode: pick(r.mode, ['direct', 'browser'] as const, d.mode),
    receipt: normalizeTarget(r.receipt),
    kitchen: normalizeTarget(r.kitchen),
    stations: normalizeStations(r.stations),
    paperWidth: pick(r.paperWidth, ['58mm', '80mm'] as const, d.paperWidth),
    margin: pick(r.margin, ['0mm', '2mm', '4mm'] as const, d.margin),
    fontSize: pick(r.fontSize, ['compact', 'medium', 'large'] as const, d.fontSize),
    font: pick(r.font, ['sans-serif', 'monospace'] as const, d.font),
    darkness: pick(r.darkness, ['normal', 'dark', 'extra'] as const, d.darkness),
    language: pick(r.language, ['es', 'en'] as const, d.language),
    codepage: pick(r.codepage, ['cp850', 'cp1252', 'ascii'] as const, d.codepage),
    showLogo: bool(r.showLogo, d.showLogo),
    footer: typeof r.footer === 'string' ? r.footer.replace(/[\r\n]+/g, ' ').trim().slice(0, 200) : d.footer,
    autoPrintReceipt: bool(r.autoPrintReceipt, d.autoPrintReceipt),
    autoPrintKitchen: bool(r.autoPrintKitchen, d.autoPrintKitchen),
    receiptCopies: count(r.receiptCopies, d.receiptCopies),
    kitchenCopies: count(r.kitchenCopies, d.kitchenCopies),
    cut: bool(r.cut, d.cut),
    openDrawer: bool(r.openDrawer, d.openDrawer),
  };
};

export interface StationGroup<T> {
  /** MAIN_STATION o el id de una estación */
  id: string;
  /** Nombre para el encabezado de la comanda (null = cocina principal) */
  name: string | null;
  items: T[];
}

/**
 * Reparte los productos de un pedido entre las estaciones. Manda el producto; si no
 * eligió, su categoría; si tampoco, la cocina principal. Lo marcado "none" no se
 * imprime, y una estación borrada vuelve a la cocina principal.
 */
export const routeToStations = <T>(
  items: T[],
  stationOf: (item: T) => { product?: string | null; category?: string | null },
  settings: Pick<PrintSettings, 'stations'>,
): StationGroup<T>[] => {
  const known = new Map(settings.stations.map((s) => [s.id, s.name]));
  const groups = new Map<string, T[]>();
  for (const item of items) {
    const ref = stationOf(item);
    const chosen = normalizeStationRef(ref.product) || normalizeStationRef(ref.category);
    if (chosen === NO_STATION) continue;
    const id = chosen && known.has(chosen) ? chosen : MAIN_STATION;
    groups.set(id, [...(groups.get(id) || []), item]);
  }
  const order = [MAIN_STATION, ...settings.stations.map((s) => s.id)];
  return order.filter((id) => groups.has(id)).map((id) => ({ id, name: id === MAIN_STATION ? null : known.get(id) || null, items: groups.get(id)! }));
};
