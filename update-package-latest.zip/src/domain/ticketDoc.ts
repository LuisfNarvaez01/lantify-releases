// ============================================
// DOMAIN - Documento de un ticket (recibo, comanda, cierre)
// ============================================
// La interfaz arma el ticket una sola vez como una lista de bloques. El mismo
// documento se dibuja en HTML (vista previa y diálogo del navegador) y se convierte
// en comandos ESC/POS para la impresión directa. Así lo que se ve es lo que sale.

export type TicketAlign = 'left' | 'center' | 'right';

export type TicketBlock =
  /** Texto que se parte en líneas si no cabe */
  | { t: 'text'; text: string; align?: TicketAlign; bold?: boolean; size?: 1 | 2; small?: boolean; invert?: boolean }
  /** Dos columnas: concepto a la izquierda, valor a la derecha */
  | { t: 'row'; left: string; right: string; bold?: boolean; size?: 1 | 2; small?: boolean }
  | { t: 'rule'; style?: 'dashed' | 'solid' | 'double' }
  | { t: 'feed'; lines?: number }
  /** Imagen en blanco y negro: 1 bit por punto, filas de izquierda a derecha, ancho múltiplo de 8 */
  | { t: 'image'; width: number; height: number; bits: string; src?: string; align?: TicketAlign }
  /** Recuadro con borde punteado (sellos, avisos) */
  | { t: 'box'; blocks: TicketBlock[] };

export interface TicketDoc {
  title: string;
  blocks: TicketBlock[];
  /** Abrir el cajón monedero al terminar (cobro en efectivo) */
  drawer?: boolean;
}

/** Parte un texto en líneas de hasta `width` caracteres, sin cortar palabras si se puede */
export const wrapText = (text: string, width: number): string[] => {
  const out: string[] = [];
  for (const para of String(text ?? '').split(/\r?\n/)) {
    let line = '';
    for (const word of para.split(/\s+/).filter(Boolean)) {
      if (!line) line = word;
      else if (line.length + 1 + word.length <= width) line += ' ' + word;
      else {
        out.push(line);
        line = word;
      }
      while (line.length > width) {
        out.push(line.slice(0, width));
        line = line.slice(width);
      }
    }
    out.push(line);
  }
  return out;
};

/** Concepto y valor en una sola línea; si no caben, el concepto ocupa sus líneas y el valor va al final */
export const twoColumns = (left: string, right: string, width: number): string[] => {
  const r = String(right ?? '');
  const room = width - r.length - 1;
  if (room < 6) return [...wrapText(left, width), r.padStart(width)];
  const lines = wrapText(left, room);
  const last = lines.pop() || '';
  return [...lines, last.padEnd(room) + ' ' + r];
};

export const isTicketDoc = (v: unknown): v is TicketDoc =>
  !!v && typeof v === 'object' && Array.isArray((v as TicketDoc).blocks) && (v as TicketDoc).blocks.length <= 400;
