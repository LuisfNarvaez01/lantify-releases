// ============================================
// DOMAIN - Factura electrónica (venta → documento → proveedor)
// ============================================
// El POS arma un documento neutro con la venta (líneas con base e impuesto ya
// repartido el descuento). Lantify Cloud lo convierte al formato del proveedor
// tecnológico (MATIAS API, Lantify como casa de software) y lee su respuesta.
// Nada de esto inventa números, CUFE ni aprobaciones: eso solo lo da la DIAN.

export type EinvoiceKind = 'invoice' | 'pos';
export type EinvoiceIdType = 'CC' | 'NIT' | 'CE' | 'PAS' | 'TI';
export type EinvoicePayment = 'CASH' | 'CARD' | 'CREDIT_CARD' | 'TRANSFER';

export interface EinvoiceLine {
  code: string;
  description: string;
  quantity: number;
  /** Valor sin impuesto de la línea, después del descuento */
  base: number;
  tax: number;
  taxType: 'IVA' | 'INC' | 'NONE';
  taxRate: number;
}

export interface EinvoiceCustomer {
  idType: EinvoiceIdType;
  idNumber: string;
  name: string;
  email?: string;
  phone?: string;
  address?: string;
}

export interface EinvoiceDocument {
  /** id de la factura en el POS: identifica el documento ante el proveedor (reintentos sin duplicar) */
  localId: string;
  saleNumber: string;
  /** null = consumidor final */
  customer: EinvoiceCustomer | null;
  lines: EinvoiceLine[];
  payment: EinvoicePayment;
  cashier?: string;
  seller?: string;
}

export const FINAL_CONSUMER_ID = '222222222222';
const round2 = (n: number) => Math.round(n * 100) / 100;
const money = (n: number) => round2(n).toFixed(2);
const clip = (v: unknown, max: number) => (typeof v === 'string' ? v.trim().slice(0, max) : '');

/** Medio de pago de la venta en el lenguaje de la factura */
export const paymentOf = (method: string | null | undefined): EinvoicePayment => {
  const m = (method || 'CASH').toUpperCase();
  if (m.includes('CREDIT')) return 'CREDIT_CARD';
  if (m.includes('CARD') || m.includes('TARJETA') || m.includes('DEBIT')) return 'CARD';
  if (m.includes('TRANSFER') || m.includes('NEQUI') || m.includes('DAVIPLATA') || m.includes('BREB')) return 'TRANSFER';
  return 'CASH';
};

const ID_TYPES: EinvoiceIdType[] = ['CC', 'NIT', 'CE', 'PAS', 'TI'];

/** Adquiriente de la factura; sin identificación (o la genérica) es consumidor final */
export const normalizeCustomer = (raw: any): EinvoiceCustomer | null => {
  const idNumber = String(raw?.nit ?? raw?.idNumber ?? '').replace(/\D/g, '').slice(0, 15);
  if (!idNumber || idNumber === FINAL_CONSUMER_ID) return null;
  const type = raw?.documentType === 'PASAPORTE' ? 'PAS' : raw?.documentType ?? raw?.idType;
  return {
    idType: ID_TYPES.includes(type) ? type : idNumber.length >= 9 && idNumber.length <= 10 ? 'NIT' : 'CC',
    idNumber,
    name: clip(raw?.name, 100) || 'Cliente',
    email: clip(raw?.email, 120) || undefined,
    phone: clip(raw?.phone, 30) || undefined,
    address: clip(raw?.address, 150) || undefined,
  };
};

/**
 * Documento de una venta. Los precios traen el impuesto incluido; el descuento de la
 * venta se reparte en proporción al valor de cada línea (igual que al cobrar).
 */
export const buildEinvoiceDocument = (localId: string, sale: any, customer: EinvoiceCustomer | null): EinvoiceDocument => {
  const items = (sale.items || []).filter((i: any) => !i.isCancelled);
  const gross = items.reduce((s: number, i: any) => s + (Number(i.total) || 0), 0);
  const discount = Number(sale.discount) || 0;
  const factor = gross > 0 ? Math.max(0, gross - discount) / gross : 0;
  const lines: EinvoiceLine[] = items.map((i: any, idx: number) => {
    const product = i.productVariant?.product?.name;
    const variant = i.productVariant?.name;
    const description = product ? (variant && variant !== product ? `${product} ${variant}` : product) : i.notes || `Producto ${idx + 1}`;
    const taxType = i.taxType === 'IVA' || i.taxType === 'INC' ? i.taxType : 'NONE';
    const net = round2((Number(i.total) || 0) * factor);
    const tax = taxType === 'NONE' ? 0 : round2(Number(i.taxAmount) || 0);
    return {
      code: clip(i.productVariant?.sku, 50) || `ITEM-${idx + 1}`,
      description: description.slice(0, 300),
      quantity: Number(i.quantity) || 1,
      base: round2(net - tax),
      tax,
      taxType,
      taxRate: taxType === 'NONE' ? 0 : Number(i.taxRate) || 0,
    };
  });
  // Venta sin detalle (cobro por monto): una sola línea con el total
  if (!lines.length) {
    const tax = round2(Number(sale.tax) || 0);
    lines.push({ code: 'CONSUMO', description: 'Consumo restaurante', quantity: 1, base: round2((Number(sale.total) || 0) - tax), tax, taxType: tax ? 'INC' : 'NONE', taxRate: tax ? 8 : 0 });
  }
  return {
    localId,
    saleNumber: String(sale.saleNumber || ''),
    customer,
    lines,
    payment: paymentOf(sale.paymentMethod),
    cashier: clip(sale.cashierName, 80) || undefined,
    seller: clip(sale.waiterName, 80) || undefined,
  };
};

/** Revisa un documento que llega a la nube; devuelve el motivo si no sirve */
export const einvoiceProblem = (doc: any): string | null => {
  if (!doc || typeof doc !== 'object') return 'EINVOICE_BAD_DOCUMENT';
  if (typeof doc.localId !== 'string' || !/^[0-9a-f-]{36}$/i.test(doc.localId)) return 'EINVOICE_BAD_DOCUMENT';
  if (!Array.isArray(doc.lines) || !doc.lines.length || doc.lines.length > 500) return 'EINVOICE_BAD_DOCUMENT';
  for (const l of doc.lines) {
    if (![l?.quantity, l?.base, l?.tax, l?.taxRate].every((n) => typeof n === 'number' && Number.isFinite(n) && n >= 0)) return 'EINVOICE_BAD_DOCUMENT';
    if (typeof l.description !== 'string' || !l.description.trim()) return 'EINVOICE_BAD_DOCUMENT';
  }
  if (doc.customer && (typeof doc.customer.idNumber !== 'string' || !/^\d{3,15}$/.test(doc.customer.idNumber))) return 'EINVOICE_BAD_CUSTOMER';
  return null;
};

// ── MATIAS API (UBL 2.1) ──────────────────────────────────────
// Catálogos públicos de la API: /taxes, /identity-documents, /payment-means, /quantity-units

export interface MatiasConfig {
  kind: EinvoiceKind;
  resolutionNumber: string;
  prefix: string;
  /** Datos del fabricante del software (obligatorios en el documento POS) */
  softwareOwner: string;
  businessAddress?: string;
}

const MATIAS_TAX: Record<'IVA' | 'INC', number> = { IVA: 1, INC: 4 };
const MATIAS_ID: Record<EinvoiceIdType, number> = { CC: 1, CE: 2, NIT: 3, TI: 7, PAS: 9 };
const MATIAS_MEANS: Record<EinvoicePayment, number> = { CASH: 10, CARD: 49, CREDIT_CARD: 48, TRANSFER: 31 };
const UNIT = '70'; // unidad
const OWN_STANDARD = '4'; // estándar de adopción del contribuyente

export const matiasPath = (kind: EinvoiceKind) => (kind === 'pos' ? 'pos-documents' : 'invoices');

export const toMatiasPayload = (doc: EinvoiceDocument, cfg: MatiasConfig) => {
  const taxTotals = new Map<string, { tax_id: string; percent: number; taxable_amount: number; tax_amount: number }>();
  const lines = doc.lines.map((l) => {
    const taxed = l.taxType !== 'NONE' && l.taxRate > 0;
    const lineTax = taxed ? [{ tax_id: String(MATIAS_TAX[l.taxType as 'IVA' | 'INC']), tax_amount: round2(l.tax), taxable_amount: round2(l.base), percent: l.taxRate }] : undefined;
    if (lineTax) {
      const key = `${lineTax[0].tax_id}|${l.taxRate}`;
      const acc = taxTotals.get(key) ?? { tax_id: lineTax[0].tax_id, percent: l.taxRate, taxable_amount: 0, tax_amount: 0 };
      acc.taxable_amount = round2(acc.taxable_amount + l.base);
      acc.tax_amount = round2(acc.tax_amount + l.tax);
      taxTotals.set(key, acc);
    }
    return {
      invoiced_quantity: String(l.quantity),
      base_quantity: String(l.quantity),
      quantity_units_id: UNIT,
      line_extension_amount: money(l.base),
      price_amount: money(l.quantity ? l.base / l.quantity : l.base),
      free_of_charge_indicator: false,
      description: l.description,
      code: l.code,
      type_item_identifications_id: OWN_STANDARD,
      reference_price_id: '1',
      ...(lineTax ? { tax_totals: lineTax } : {}),
    };
  });
  const lineExtension = round2(doc.lines.reduce((s, l) => s + l.base, 0));
  const taxableBase = round2([...taxTotals.values()].reduce((s, t) => s + t.taxable_amount, 0));
  const taxes = round2([...taxTotals.values()].reduce((s, t) => s + t.tax_amount, 0));
  const payable = round2(lineExtension + taxes);
  const c = doc.customer;
  const customer = c
    ? cfg.kind === 'pos'
      ? { company_name: c.name, dni: c.idNumber, ...(c.email ? { email: c.email } : {}) }
      : {
          company_name: c.name,
          dni: c.idNumber,
          identity_document_id: MATIAS_ID[c.idType],
          type_organization_id: c.idType === 'NIT' ? 1 : 2,
          ...(c.email ? { email: c.email } : {}),
          ...(c.phone ? { mobile: c.phone } : {}),
          ...(c.address ? { address: c.address } : {}),
        }
    : undefined;
  return {
    uuid: doc.localId,
    resolution_number: cfg.resolutionNumber,
    ...(cfg.prefix ? { prefix: cfg.prefix } : {}),
    notes: `Venta ${doc.saleNumber}`.trim(),
    graphic_representation: 1,
    send_email: c?.email ? 1 : 0,
    operation_type_id: 1,
    type_document_id: cfg.kind === 'pos' ? 20 : 7,
    payments: [{ payment_method_id: 1, means_payment_id: MATIAS_MEANS[doc.payment] ?? 10, value_paid: money(payable) }],
    document_signature: { cashier: doc.cashier || 'Caja', seller: doc.seller || doc.cashier || 'Caja' },
    ...(customer ? { customer } : {}),
    ...(cfg.kind === 'pos'
      ? {
          point_of_sale: {
            cashier_name: doc.cashier || 'Caja',
            terminal_number: 'CAJA-1',
            cashier_type: 'Caja principal',
            sales_code: doc.saleNumber || 'POS',
            address: cfg.businessAddress || 'Punto de venta',
            sub_total: money(lineExtension),
          },
          software_manufacturer: { owner_name: cfg.softwareOwner, company_name: 'Lantify', software_name: 'Lantify POS' },
        }
      : {}),
    lines,
    legal_monetary_totals: {
      line_extension_amount: money(lineExtension),
      tax_exclusive_amount: money(taxableBase),
      tax_inclusive_amount: money(payable),
      payable_amount: money(payable),
    },
    ...(taxTotals.size ? { tax_totals: [...taxTotals.values()] } : {}),
  };
};

export type EinvoiceStatus = 'ACCEPTED' | 'REJECTED' | 'PENDING';

export interface EinvoiceOutcome {
  status: EinvoiceStatus;
  number?: string | null;
  cufe?: string | null;
  qrUrl?: string | null;
  pdfUrl?: string | null;
  /** id del envío en el proveedor: con él se corrige o se consulta sin gastar otro número */
  shippingUuid?: string | null;
  message: string;
  /** El problema es de Lantify (cupo, credenciales), no del negocio */
  providerIssue?: boolean;
}

const errorText = (body: any): string => {
  const list = body?.response?.ErrorMessage?.string ?? body?.errors;
  if (Array.isArray(list)) return list.join(' · ');
  if (list && typeof list === 'object') return Object.values(list).flat().join(' · ');
  if (typeof list === 'string') return list;
  return typeof body?.message === 'string' ? body.message : '';
};

const numberFrom = (body: any): string | null => {
  const direct = body?.document_number ?? body?.data?.document_number;
  if (typeof direct === 'string' && direct) return direct;
  const m = typeof body?.response?.StatusMessage === 'string' ? body.response.StatusMessage.match(/\b([A-Z0-9]+\d+),?\s+ha sido autorizad/i) : null;
  return m ? m[1] : null;
};

/** Qué quedó del documento según la respuesta del proveedor (null = sin respuesta) */
export const readMatiasResponse = (status: number | null, body: any): EinvoiceOutcome => {
  if (status === null) return { status: 'PENDING', message: 'Sin respuesta del proveedor de facturación. Se reintenta solo.' };
  const shippingUuid = body?.uuid ?? body?.data?.shipping_history_uuid ?? body?.data?.uuid ?? null;
  if (status === 200 && body?.response) {
    const valid = String(body.response.IsValid) === 'true';
    if (valid) {
      return {
        status: 'ACCEPTED',
        number: numberFrom(body),
        cufe: body.XmlDocumentKey ?? body.response.XmlDocumentKey ?? null,
        qrUrl: body.qr?.qrDian ?? null,
        pdfUrl: body.pdf?.url ?? null,
        shippingUuid,
        message: body.response.StatusMessage || 'Validada por la DIAN',
      };
    }
    // Habilitación: la DIAN responde después
    if (body.ZipKey || body.response.ZipKey) return { status: 'PENDING', shippingUuid, cufe: body.XmlDocumentKey ?? null, message: 'La DIAN está validando el documento.' };
    return { status: 'REJECTED', shippingUuid, cufe: body.XmlDocumentKey ?? null, message: errorText(body) || body.response.StatusDescription || 'La DIAN rechazó el documento' };
  }
  // Ya validado antes (reintento): se recupera sin emitir otro
  if (status === 400 && body?.data && (body.data.is_valid === true || body.data.is_valid === 1)) {
    return { status: 'ACCEPTED', number: body.data.document_number ?? null, cufe: body.data.XmlDocumentKey ?? null, shippingUuid, message: 'Validada por la DIAN' };
  }
  if (status === 422) return { status: 'REJECTED', shippingUuid, message: errorText(body) || 'Datos de la factura incompletos' };
  if (status === 402 || status === 429) return { status: 'PENDING', shippingUuid, providerIssue: true, message: 'La facturación electrónica de Lantify no tiene cupo disponible en este momento. Se reintenta sola.' };
  if (status === 401 || status === 403) return { status: 'PENDING', shippingUuid, providerIssue: true, message: 'Lantify no pudo autenticarse con el proveedor de facturación. Se reintenta sola.' };
  if (status === 404) return { status: 'PENDING', shippingUuid, providerIssue: true, message: errorText(body) || 'El proveedor no encontró la resolución de facturación.' };
  // 400 (en cola / ya usado), 409, 503, 500 DOCUMENT_POSSIBLY_SENT: el número se conserva y se consulta después
  return { status: 'PENDING', shippingUuid, message: errorText(body) || 'El proveedor aún no confirma el documento. Se reintenta solo.' };
};
