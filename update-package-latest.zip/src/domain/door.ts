// ============================================
// DOMAIN - Puerta: cover, manillas y aforo (Fase 4 · 9)
// ============================================
// Una "noche" va de mediodía a mediodía (la rumba de un sábado termina el domingo
// de madrugada y es la misma noche). Cuentan como entradas:
//   · cada unidad cobrada de un producto Cover (se leen de las ventas),
//   · cada +1 del portero (entra sin cover: lista, cortesía) y cada manilla que entra.
// Las salidas son los −1 del portero. Ocupación = entradas − salidas (nunca negativa).
// La puerta avisa, nunca bloquea: al llegar al aforo el portero decide.

export type DoorKind = 'IN' | 'OUT';

export class DoorError extends Error {
  constructor(message: string, public code: string, public statusCode = 400) {
    super(message);
    this.name = 'DoorError';
  }
}

/** Hora (local) en que cambia la noche */
export const NIGHT_CUTOFF_HOUR = 12;
/** Desde qué porcentaje del aforo la puerta avisa */
export const CAPACITY_WARN_PCT = 90;
export const MAX_CAPACITY = 100_000;

/** La noche a la que pertenece un momento: [desde, hasta) en hora local */
export const nightWindow = (at: Date, cutoffHour = NIGHT_CUTOFF_HOUR): { from: Date; to: Date } => {
  const from = new Date(at.getFullYear(), at.getMonth(), at.getDate(), cutoffHour, 0, 0, 0);
  if (at < from) from.setDate(from.getDate() - 1);
  const to = new Date(from.getFullYear(), from.getMonth(), from.getDate() + 1, cutoffHour, 0, 0, 0);
  return { from, to };
};

/** La noche que empieza el día dado (YYYY-MM-DD) */
export const nightOf = (date: string, cutoffHour = NIGHT_CUTOFF_HOUR): { from: Date; to: Date } | null => {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(date || '');
  if (!m) return null;
  const from = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]), cutoffHour, 0, 0, 0);
  if (Number.isNaN(from.getTime())) return null;
  return { from, to: new Date(from.getFullYear(), from.getMonth(), from.getDate() + 1, cutoffHour, 0, 0, 0) };
};

/** Código impreso en la manilla: letras y números (se ignoran espacios y guiones) */
export const normalizeWristband = (raw: unknown): string | null => {
  if (raw === undefined || raw === null || raw === '') return null;
  const code = String(raw).toUpperCase().replace(/[\s-]+/g, '');
  if (!/^[A-Z0-9]{1,24}$/.test(code)) throw new DoorError('El código de la manilla solo lleva letras y números.', 'WRISTBAND_INVALID');
  return code;
};

/** Aforo guardado en Ajustes: entero positivo o null (sin aforo) */
export const normalizeCapacity = (raw: unknown): number | null => {
  if (raw === null || raw === undefined || raw === '' || raw === 0) return null;
  const n = Math.round(Number(raw));
  if (!Number.isFinite(n) || n < 1 || n > MAX_CAPACITY) throw new DoorError('El aforo debe ser un número entre 1 y 100.000.', 'CAPACITY_INVALID');
  return n;
};

export type CapacityLevel = 'none' | 'ok' | 'warn' | 'full';

export const capacityLevel = (occupancy: number, capacity: number | null): CapacityLevel => {
  if (!capacity) return 'none';
  if (occupancy >= capacity) return 'full';
  return occupancy * 100 >= capacity * CAPACITY_WARN_PCT ? 'warn' : 'ok';
};

export interface DoorMovement {
  at: Date;
  kind: DoorKind;
  /** Covers cobrados en una venta: varias entradas a la vez */
  count?: number;
  wristband?: string | null;
}

export interface DoorStats {
  coversSold: number;
  /** Entradas de la noche: covers cobrados + entradas marcadas en la puerta */
  entries: number;
  doorEntries: number;
  exits: number;
  occupancy: number;
  peak: number;
  peakAt: Date | null;
}

/**
 * Recorre la noche en orden y cuenta entradas, salidas, ocupación y su pico.
 * `covers` son las ventas con covers (momento y unidades); `events`, lo que marcó el portero.
 */
export const doorStats = (covers: { at: Date; units: number }[], events: { at: Date; kind: string }[]): DoorStats => {
  const moves: DoorMovement[] = [
    ...covers.filter((c) => c.units > 0).map((c) => ({ at: c.at, kind: 'IN' as const, count: Math.round(c.units) })),
    ...events.map((e) => ({ at: e.at, kind: (e.kind === 'OUT' ? 'OUT' : 'IN') as DoorKind, count: 1 })),
  ].sort((a, b) => a.at.getTime() - b.at.getTime());
  let occupancy = 0;
  let peak = 0;
  let peakAt: Date | null = null;
  let exits = 0;
  for (const m of moves) {
    const n = m.count ?? 1;
    if (m.kind === 'IN') occupancy += n;
    else {
      exits += n;
      occupancy = Math.max(0, occupancy - n);
    }
    if (occupancy > peak) {
      peak = occupancy;
      peakAt = m.at;
    }
  }
  const coversSold = covers.reduce((n, c) => n + Math.max(0, Math.round(c.units)), 0);
  const doorEntries = events.filter((e) => e.kind !== 'OUT').length;
  return { coversSold, entries: coversSold + doorEntries, doorEntries, exits, occupancy, peak, peakAt };
};

/** ¿La manilla está adentro? (su último movimiento de la noche fue una entrada) */
export const wristbandInside = (events: { kind: string; wristband?: string | null; at: Date }[], code: string): boolean => {
  const mine = events.filter((e) => e.wristband === code).sort((a, b) => a.at.getTime() - b.at.getTime());
  return mine.length > 0 && mine[mine.length - 1].kind === 'IN';
};
