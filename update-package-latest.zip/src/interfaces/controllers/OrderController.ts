// ============================================
// INTERFACES - Order Controller (Comandas)
// ============================================

import { Response } from 'express';
import { OrderUseCases } from '../../application/usecases/OrderUseCases';
import { AuthRequest } from '../../shared/authMiddleware';
import { resolveAuthorizer } from '../../shared/security/adminOverride';

const ADMIN_AUTH_REQUIRED = { error: 'Esta anulación requiere la autorización de un administrador.', code: 'ADMIN_AUTH_REQUIRED' };

export class OrderController {
  constructor(private orderUseCases: OrderUseCases) {}

  async getActiveOrders(_req: AuthRequest, res: Response) {
    try {
      const orders = await this.orderUseCases.getActiveOrders();
      res.json(orders);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Error al obtener comandas activas' });
    }
  }

  async getActiveOrderByTable(req: AuthRequest, res: Response) {
    try {
      const { tableId } = req.params;
      const order = await this.orderUseCases.getActiveOrderByTable(tableId);
      res.json(order || null);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Error al obtener comanda de mesa' });
    }
  }

  async saveOrder(req: AuthRequest, res: Response) {
    try {
      const userId = req.user?.id || req.user?.userId;
      const userName = req.user?.name || req.user?.username;
      const order = await this.orderUseCases.saveOrder({
        ...req.body,
        userId,
        userName
      });
      res.json(order);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Error al guardar comanda' });
    }
  }

  async sendToKitchen(req: AuthRequest, res: Response) {
    try {
      const { id } = req.params;
      const userId = req.user?.id || req.user?.userId;
      const userName = req.user?.name || req.user?.username;
      const order = await this.orderUseCases.sendToKitchen(id, userId, userName);
      res.json(order);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Error al enviar comanda a cocina' });
    }
  }

  async cancelOrderItem(req: AuthRequest, res: Response) {
    try {
      const { itemId } = req.params;
      const { reason, adminAuthToken } = req.body;
      if (!reason) {
        return res.status(400).json({ error: 'El motivo de anulación es obligatorio' });
      }
      const authorizer = resolveAuthorizer(req.user, adminAuthToken);
      if (!authorizer) return res.status(403).json(ADMIN_AUTH_REQUIRED);
      const userId = req.user?.id || req.user?.userId;
      const order = await this.orderUseCases.cancelOrderItem(itemId, reason, userId, authorizer.adminName);
      res.json(order);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Error al anular item de comanda' });
    }
  }

  async cancelOrderItemPartial(req: AuthRequest, res: Response) {
    try {
      const { itemId } = req.params;
      const { quantity, reason, comments, wasteDestination, adminAuthToken } = req.body;
      if (!reason) {
        return res.status(400).json({ error: 'El motivo de anulación es obligatorio' });
      }
      const qty = Number(quantity);
      if (isNaN(qty) || qty <= 0) {
        return res.status(400).json({ error: 'La cantidad a anular debe ser mayor a 0' });
      }
      const authorizer = resolveAuthorizer(req.user, adminAuthToken);
      if (!authorizer) return res.status(403).json(ADMIN_AUTH_REQUIRED);
      const userId = req.user?.id || req.user?.userId;
      const order = await this.orderUseCases.cancelOrderItemPartial(
        itemId,
        qty,
        reason,
        comments,
        userId,
        authorizer.adminName,
        wasteDestination
      );
      res.json(order);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Error al anular parcialmente el item de comanda' });
    }
  }

  async closeOrder(req: AuthRequest, res: Response) {
    try {
      const { id } = req.params;
      const { status } = req.body;
      const order = await this.orderUseCases.closeOrder(id, status);
      res.json(order);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Error al cerrar comanda' });
    }
  }
}
