// ============================================
// INTERFACES - CashSession Controller
// ============================================

import { Request, Response } from 'express';
import { CashSessionUseCases } from '../../application/usecases';

export class CashSessionController {
  constructor(private cashSessionUseCases: CashSessionUseCases) {}

  async openSession(req: Request, res: Response) {
    try {
      const session = await this.cashSessionUseCases.openSession(req.body);
      res.status(201).json(session);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async getOpenSession(req: Request, res: Response) {
    try {
      const session = await this.cashSessionUseCases.getOpenSession();
      // Return null instead of 404 when no session is open
      if (!session) return res.json(null);
      res.json(session);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async getSessionById(req: Request, res: Response) {
    try {
      const session = await this.cashSessionUseCases.getSessionById(req.params.id);
      if (!session) return res.status(404).json({ error: 'Sesión no encontrada' });
      res.json(session);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async getAllSessions(req: Request, res: Response) {
    try {
      const sessions = await this.cashSessionUseCases.getAllSessions();
      res.json(sessions);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async getSessionsByDateRange(req: Request, res: Response) {
    try {
      const { startDate, endDate } = req.query;
      const sessions = await this.cashSessionUseCases.getSessionsByDateRange(
        new Date(startDate as string),
        new Date(endDate as string)
      );
      res.json(sessions);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async addIncome(req: Request, res: Response) {
    try {
      const { amount, motive, description } = req.body;
      const session = await this.cashSessionUseCases.addIncome(req.params.id, amount, motive, description);
      res.json(session);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async addExpense(req: Request, res: Response) {
    try {
      const { amount, motive, description, categoryId } = req.body;
      const session = await this.cashSessionUseCases.addExpense(req.params.id, amount, motive, description, categoryId);
      res.json(session);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }


  async closeSession(req: Request, res: Response) {
    try {
      const session = await this.cashSessionUseCases.closeSession(req.params.id, req.body);
      res.json(session);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async cancelIncome(req: Request, res: Response) {
    try {
      const { incomeId, reason } = req.body;
      const session = await this.cashSessionUseCases.cancelIncome(req.params.id, incomeId, reason);
      res.json(session);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async cancelExpense(req: Request, res: Response) {
    try {
      const { expenseId, reason } = req.body;
      const session = await this.cashSessionUseCases.cancelExpense(req.params.id, expenseId, reason);
      res.json(session);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }
}