// ============================================
// INTERFACES - CashSession Controller
// ============================================

import { prisma } from '../../infrastructure/database/prisma';
import { Request, Response } from 'express';
import { CashSessionUseCases } from '../../application/usecases';

export class CashSessionController {
  constructor(private cashSessionUseCases: CashSessionUseCases, private hooks: { onClosed?: (sessionId: string) => Promise<void> } = {}) {}

  private who(req: Request) {
    const u = (req as any).user;
    return { id: (u?.id || u?.userId || null) as string | null, name: (u?.name || u?.username || null) as string | null };
  }

  async openSession(req: Request, res: Response) {
    try {
      const session = await this.cashSessionUseCases.openSession(req.body);
      const who = this.who(req);
      await prisma.cashSession.update({ where: { id: session.id }, data: { openedById: who.id, openedByName: who.name } }).catch(() => {});
      res.status(201).json({ ...session, openedById: who.id, openedByName: who.name });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async getOpenSession(req: Request, res: Response) {
    try {
      const session = await this.cashSessionUseCases.getOpenSession();
      // Return null instead of 404 when no session is open
      if (!session) return res.json(null);
      res.json(session);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async getSessionById(req: Request, res: Response) {
    try {
      const session = await this.cashSessionUseCases.getSessionById(req.params.id);
      if (!session) return res.status(404).json({ error: 'Sesión no encontrada' });
      res.json(session);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async getAllSessions(req: Request, res: Response) {
    try {
      const sessions = await this.cashSessionUseCases.getAllSessions();
      res.json(sessions);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async getSessionsByDateRange(req: Request, res: Response) {
    try {
      const { startDate, endDate } = req.query;
      const sessions = await this.cashSessionUseCases.getSessionsByDateRange(
        new Date(startDate as string),
        new Date(endDate as string)
      );
      res.json(sessions);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async addIncome(req: Request, res: Response) {
    try {
      const { amount, motive, description } = req.body;
      const session = await this.cashSessionUseCases.addIncome(req.params.id, amount, motive, description);
      res.json(session);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async addExpense(req: Request, res: Response) {
    try {
      const { amount, motive, description, categoryId } = req.body;
      const session = await this.cashSessionUseCases.addExpense(req.params.id, amount, motive, description, categoryId);
      res.json(session);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }


  async closeSession(req: Request, res: Response) {
    try {
      const session = await this.cashSessionUseCases.closeSession(req.params.id, req.body);
      const who = this.who(req);
      await prisma.cashSession.update({ where: { id: req.params.id }, data: { closedById: who.id, closedByName: who.name } }).catch(() => {});
      // El cierre no espera a los turnos ni al reporte: si fallan, la caja ya quedó cerrada
      if (this.hooks.onClosed) await this.hooks.onClosed(req.params.id).catch((err) => console.warn('[cierre] tareas posteriores:', err?.message || err));
      res.json({ ...session, closedById: who.id, closedByName: who.name });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async cancelIncome(req: Request, res: Response) {
    try {
      const { incomeId, reason } = req.body;
      const session = await this.cashSessionUseCases.cancelIncome(req.params.id, incomeId, reason);
      res.json(session);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async cancelExpense(req: Request, res: Response) {
    try {
      const { expenseId, reason } = req.body;
      const session = await this.cashSessionUseCases.cancelExpense(req.params.id, expenseId, reason);
      res.json(session);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }
}