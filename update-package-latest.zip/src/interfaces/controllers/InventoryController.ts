// ============================================
// INTERFACES - Inventory Controller
// ============================================

import { Request, Response } from 'express';
import { InventoryUseCases } from '../../application/usecases/InventoryUseCases';

export class InventoryController {
  constructor(private inventoryUseCases: InventoryUseCases) {}

  async getInventoryStatus(req: Request, res: Response) {
    try {
      const onlyTracked = req.query.onlyTracked !== 'false';
      const data = await this.inventoryUseCases.getInventoryStatus(onlyTracked);
      res.json(data);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async toggleTrackInventory(req: Request, res: Response) {
    try {
      const { enabled } = req.body;
      const result = await this.inventoryUseCases.toggleTrackInventory(req.params.variantId, enabled);
      res.json(result);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async adjustStock(req: Request, res: Response) {
    try {
      const { quantity, type, notes } = req.body;
      const result = await this.inventoryUseCases.adjustStock(req.params.variantId, quantity, type, notes);
      res.json(result);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async submitInventoryCount(req: Request, res: Response) {
    try {
      const { countedStock, justification, userId } = req.body;
      const result = await this.inventoryUseCases.submitInventoryCount(
        req.params.variantId,
        countedStock,
        justification,
        userId
      );
      res.json(result);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async getStockMovements(req: Request, res: Response) {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const data = await this.inventoryUseCases.getStockMovements(req.params.variantId, limit);
      res.json(data);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async getInventoryCountHistory(req: Request, res: Response) {
    try {
      const limit = parseInt(req.query.limit as string) || 20;
      const data = await this.inventoryUseCases.getInventoryCountHistory(req.params.variantId, limit);
      res.json(data);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }
}
