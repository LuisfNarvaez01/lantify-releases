// ============================================
// INTERFACES - Analytics Controller
// ============================================

import { Request, Response } from 'express';
import { AnalyticsUseCases } from '../../application/usecases/AnalyticsUseCases';

export class AnalyticsController {
  constructor(private analyticsUseCases: AnalyticsUseCases) {}

  async compareMonths(req: Request, res: Response) {
    try {
      const monthsParam = (req.query.months as string) || '';
      if (!monthsParam) {
        return res.status(400).json({ error: 'Parámetro months es requerido (ej: ?months=2026-07,2026-08)' });
      }
      const monthKeys = monthsParam.split(',').map(m => m.trim()).filter(Boolean);
      const data = await this.analyticsUseCases.compareMonths(monthKeys);
      res.json(data);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async getAvailableMonths(req: Request, res: Response) {
    try {
      const data = await this.analyticsUseCases.getAvailableMonths();
      res.json(data);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async getOverview(req: Request, res: Response) {
    try {
      const from = String(req.query.from || '');
      const to = String(req.query.to || '');
      res.json(await this.analyticsUseCases.getOverview(from, to));
    } catch (error: any) {
      // Fechas mal escritas o rango muy largo: es error del pedido, no del servidor
      const bad = /Fechas inválidas|anterior a la inicial|no puede pasar/.test(error?.message || '');
      res.status(bad ? 400 : 500).json({ error: error.message });
    }
  }

  async getDaySummary(_req: Request, res: Response) {
    try {
      res.json(await this.analyticsUseCases.getDaySummary());
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async getMonthlyRevenue(req: Request, res: Response) {
    try {
      const year = parseInt(req.query.year as string) || new Date().getFullYear();
      if (year < 2000 || year > 2100) return res.status(400).json({ error: 'Año inválido' });
      res.json(await this.analyticsUseCases.getMonthlyRevenue(year));
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async getChannelStats(_req: Request, res: Response) {
    try {
      res.json(await this.analyticsUseCases.getChannelStats());
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async getTopProducts(req: Request, res: Response) {
    try {
      const year  = parseInt(req.query.year  as string) || 0;
      const month = parseInt(req.query.month as string) || 0;
      const limit = parseInt(req.query.limit as string) || 50;

      const data = await this.analyticsUseCases.getTopProducts(year, month, limit);
      res.json(data);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }
}
