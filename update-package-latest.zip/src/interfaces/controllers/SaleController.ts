// ============================================
// INTERFACES - Sale Controller
// ============================================

import { Request, Response } from 'express';
import { SaleUseCases } from '../../application/usecases';
import { currentFeatures } from '../../shared/cloud/features';
import { SaleError } from '../../application/usecases/SaleUseCases';

export class SaleController {
  constructor(private saleUseCases: SaleUseCases) {}

  async createSale(req: Request, res: Response) {
    try {
      if (req.body?.couponCode) {
        const features = await currentFeatures();
        if (features && !features.includes('coupons')) {
          return res.status(402).json({ code: 'PLAN_FEATURE_REQUIRED', feature: 'coupons', error: 'Esta función no está incluida en el plan del negocio.' });
        }
      }
      // Quién cobra sale de la sesión, nunca del cuerpo de la petición
      const user = (req as any).user;
      const sale = await this.saleUseCases.createSale({ ...req.body, cashierName: user ? user.name || user.username : undefined, cashierId: user ? user.id || user.userId : undefined });
      res.status(201).json(sale);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async getSaleById(req: Request, res: Response) {
    try {
      const sale = await this.saleUseCases.getSaleById(req.params.id);
      if (!sale) return res.status(404).json({ error: 'Venta no encontrada' });
      res.json(sale);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async getAllSales(req: Request, res: Response) {
    try {
      const sales = await this.saleUseCases.getAllSales();
      res.json(sales);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async getSalesByDateRange(req: Request, res: Response) {
    try {
      const { startDate, endDate } = req.query;
      const sales = await this.saleUseCases.getSalesByDateRange(
        new Date(startDate as string),
        new Date(endDate as string)
      );
      res.json(sales);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async getSalesByTable(req: Request, res: Response) {
    try {
      const sales = await this.saleUseCases.getSalesByTable(req.params.tableId);
      res.json(sales);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async updateSale(req: Request, res: Response) {
    try {
      const sale = await this.saleUseCases.updateSale(req.params.id, req.body);
      res.json(sale);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async completeSale(req: Request, res: Response) {
    try {
      const sale = await this.saleUseCases.completeSale(req.params.id);
      res.json(sale);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async cancelSale(req: Request, res: Response) {
    try {
      const sale = await this.saleUseCases.cancelSale(req.params.id);
      res.json(sale);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async deleteSale(req: Request, res: Response) {
    try {
      await this.saleUseCases.deleteSale(req.params.id);
      res.status(204).send();
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async getDailySummary(req: Request, res: Response) {
    try {
      const summary = await this.saleUseCases.getDailySalesSummary();
      res.json(summary);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  // ============================================
  // ANULACIÓN DE ITEMS
  // ============================================
  
  async cancelSaleItem(req: Request, res: Response) {
    try {
      const { reason } = req.body;
      const userId = req.headers['x-user-id'] as string || 'system';
      
      if (!reason) {
        return res.status(400).json({ error: 'Debe proporcionar un motivo de anulación' });
      }
      
      const sale = await this.saleUseCases.cancelSaleItem(req.params.itemId, reason, userId, req.body?.prepared === true || req.body?.wasteDestination === 'waste');
      res.json(sale);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  // ============================================
  // PAGOS PARCIALES / ABONOS
  // ============================================
  
  async addPayment(req: Request, res: Response) {
    try {
      const payment = await this.saleUseCases.addPayment(req.body);
      res.status(201).json(payment);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async getSalePayments(req: Request, res: Response) {
    try {
      const payments = await this.saleUseCases.getSalePayments(req.params.id);
      res.json(payments);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async getSalePaidTotal(req: Request, res: Response) {
    try {
      const total = await this.saleUseCases.getSalePaidTotal(req.params.id);
      res.json({ paid: total });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  /** PATCH /sales/:id/tip (ADMIN): corrige la propina sin cambiar el valor de la venta */
  async adjustTip(req: Request, res: Response) {
    try {
      const user = (req as any).user;
      const actor = user?.name || user?.username || 'ADMIN';
      res.json(await this.saleUseCases.adjustTip(req.params.id, Number(req.body?.tip), String(req.body?.reason || ''), actor));
    } catch (error: any) {
      if (error instanceof SaleError) return res.status(error.status).json({ code: error.code, error: error.message });
      console.error('[propina]', error);
      res.status(500).json({ code: 'SERVER_ERROR', error: 'Error interno del servidor' });
    }
  }

  /** PATCH /sales/:id/customer: asigna o cambia el cliente de la venta */
  async changeCustomer(req: Request, res: Response) {
    try {
      const user = (req as any).user;
      const actor = user?.name || user?.username || 'POS';
      const customerId = typeof req.body?.customerId === 'string' && req.body.customerId ? req.body.customerId : null;
      res.json(await this.saleUseCases.changeCustomer(req.params.id, customerId, actor));
    } catch (error: any) {
      if (error instanceof SaleError) return res.status(error.status).json({ code: error.code, error: error.message });
      console.error('[venta-cliente]', error);
      res.status(500).json({ code: 'SERVER_ERROR', error: 'Error interno del servidor' });
    }
  }

  // ============================================
  // HISTORIAL PAGINADO POR MES
  // ============================================

  async getAvailableMonths(req: Request, res: Response) {
    try {
      const months = await this.saleUseCases.getAvailableMonths();
      res.json(months);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async getSalesByMonth(req: Request, res: Response) {
    try {
      const year  = parseInt(req.query.year  as string) || 0;
      const month = parseInt(req.query.month as string) || 0;
      const page  = parseInt(req.query.page  as string) || 1;
      const limit = parseInt(req.query.limit as string) || 50;

      const filters: { cashSessionId?: string; status?: string } = {};
      if (req.query.cashSessionId) filters.cashSessionId = req.query.cashSessionId as string;
      if (req.query.status)        filters.status = req.query.status as string;

      const result = await this.saleUseCases.getSalesByMonth(year, month, page, limit, filters);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

}