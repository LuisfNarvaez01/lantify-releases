// ============================================
// INTERFACES - Table Controller
// ============================================

import { Request, Response } from 'express';
import { TableUseCases } from '../../application/usecases';
import { OrderUseCases } from '../../application/usecases/OrderUseCases';
import { AuditLogger } from '../../infrastructure/services/AuditLogger';
import { AuthRequest } from '../../shared/authMiddleware';
import { resolveAuthorizer } from '../../shared/security/adminOverride';
import { loadRolePermissions } from '../../shared/security/rolePermissionsStore';
import { roleCan } from '../../domain/rolePermissions';

const orderUseCases = new OrderUseCases();

export class TableController {
  constructor(private tableUseCases: TableUseCases) {}

  async createTable(req: Request, res: Response) {
    try {
      const table = await this.tableUseCases.createTable(req.body);
      res.status(201).json(table);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async getTableById(req: Request, res: Response) {
    try {
      const table = await this.tableUseCases.getTableById(req.params.id);
      if (!table) return res.status(404).json({ error: 'Mesa no encontrada' });
      res.json(table);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async getAllTables(req: Request, res: Response) {
    try {
      const tables = await this.tableUseCases.getAllTables();
      res.json(tables);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async getTablesByStatus(req: Request, res: Response) {
    try {
      const tables = await this.tableUseCases.getTablesByStatus(req.params.status as any);
      res.json(tables);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async getAvailableTables(req: Request, res: Response) {
    try {
      const tables = await this.tableUseCases.getAvailableTables();
      res.json(tables);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async updateTable(req: Request, res: Response) {
    try {
      const table = await this.tableUseCases.updateTable(req.params.id, req.body);
      res.json(table);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async occupyTable(req: Request, res: Response) {
    try {
      const table = await this.tableUseCases.occupyTable(req.params.id);
      res.json(table);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async orderTable(req: Request, res: Response) {
    try {
      const table = await this.tableUseCases.orderTable(req.params.id);
      res.json(table);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  /**
   * Libera una mesa. Si se cancela un pedido (body.reason), la comanda activa
   * queda CANCELLED y la acción se registra en la auditoría con su motivo.
   */
  async releaseTable(req: AuthRequest, res: Response) {
    try {
      const { reason, adminAuthToken } = (req.body || {}) as { reason?: string; adminAuthToken?: string };
      const before = await this.tableUseCases.getTableById(req.params.id);
      if (!before) return res.status(404).json({ error: 'Mesa no encontrada' });

      // Cancelar un pedido ya enviado a cocina: motivo obligatorio + autorización de administrador
      let authorizedBy: string | undefined;
      if (before.status === 'ORDERED') {
        if (!reason?.trim()) {
          return res.status(400).json({ error: 'Indica el motivo de la cancelación.', code: 'REASON_REQUIRED' });
        }
        const authorizer = resolveAuthorizer(req.user, adminAuthToken);
        if (!authorizer) {
          return res.status(403).json({ error: 'Cancelar un pedido enviado a cocina requiere la autorización de un administrador.', code: 'ADMIN_AUTH_REQUIRED' });
        }
        authorizedBy = authorizer.adminName;
      } else if (before.status === 'PENDING' && !roleCan(await loadRolePermissions(), req.user?.role, 'charge')) {
        return res.status(403).json({ error: 'Solo caja puede liberar una mesa con pagos registrados.', code: 'AUTH_FORBIDDEN' });
      }

      const table = await this.tableUseCases.releaseTable(req.params.id);

      if (reason) {
        await orderUseCases.closeOrder(req.params.id, 'CANCELLED').catch(() => null);
        await AuditLogger.log({
          userId: req.user?.id,
          userName: req.user?.name,
          userRole: req.user?.role,
          action: 'TABLE_ORDER_CANCELLED',
          entityType: 'TABLE',
          entityId: req.params.id,
          details: { tableNumber: before.number, previousStatus: before.status, reason, authorizedBy: authorizedBy || req.user?.name },
          ipAddress: req.ip,
        });
      }
      res.json(table);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async setPending(req: Request, res: Response) {
    try {
      const table = await this.tableUseCases.setPending(req.params.id);
      res.json(table);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async closeTable(req: Request, res: Response) {
    try {
      const table = await this.tableUseCases.closeTable(req.params.id);
      res.json(table);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async deleteTable(req: Request, res: Response) {
    try {
      await this.tableUseCases.deleteTable(req.params.id);
      res.status(204).send();
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }
}