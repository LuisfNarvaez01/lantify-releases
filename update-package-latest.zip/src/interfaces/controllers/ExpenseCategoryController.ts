// ============================================
// INTERFACES - ExpenseCategory Controller
// ============================================

import { Request, Response } from 'express';
import { ExpenseCategoryUseCases } from '../../application/usecases/ExpenseCategoryUseCases';

export class ExpenseCategoryController {
  constructor(private expenseCategoryUseCases: ExpenseCategoryUseCases) {}

  async getAll(req: Request, res: Response) {
    try {
      const categories = await this.expenseCategoryUseCases.getAll();
      res.json(categories);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async create(req: Request, res: Response) {
    try {
      const category = await this.expenseCategoryUseCases.create(req.body);
      res.status(201).json(category);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async update(req: Request, res: Response) {
    try {
      const category = await this.expenseCategoryUseCases.update(req.params.id, req.body);
      res.json(category);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async deactivate(req: Request, res: Response) {
    try {
      await this.expenseCategoryUseCases.deactivate(req.params.id);
      res.status(204).send();
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }
}
