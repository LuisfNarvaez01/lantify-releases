// ============================================
// INTERFACES - Product Controller
// ============================================

import { Request, Response } from 'express';
import { ProductUseCases, DuplicateCleanupUseCases } from '../../application/usecases';

export class ProductController {
  constructor(
    private productUseCases: ProductUseCases,
    private duplicateCleanupUseCases?: DuplicateCleanupUseCases
  ) {}

  // Category endpoints
  async createCategory(req: Request, res: Response) {
    try {
      const category = await this.productUseCases.createCategory(req.body);
      res.status(201).json(category);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async getCategories(req: Request, res: Response) {
    try {
      const categories = await this.productUseCases.getAllCategories();
      res.json(categories);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async getCategoryById(req: Request, res: Response) {
    try {
      const category = await this.productUseCases.getCategoryById(req.params.id);
      if (!category) return res.status(404).json({ error: 'Categoría no encontrada' });
      res.json(category);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async updateCategory(req: Request, res: Response) {
    try {
      const category = await this.productUseCases.updateCategory(req.params.id, req.body);
      res.json(category);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async deleteCategory(req: Request, res: Response) {
    try {
      await this.productUseCases.deleteCategory(req.params.id);
      res.status(204).send();
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  // Product endpoints
  async createProduct(req: Request, res: Response) {
    try {
      const product = await this.productUseCases.createProduct(req.body);
      res.status(201).json(product);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async getProducts(req: Request, res: Response) {
    try {
      const products = await this.productUseCases.getAllProducts();
      res.json(products);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async getProductById(req: Request, res: Response) {
    try {
      const product = await this.productUseCases.getProductById(req.params.id);
      if (!product) return res.status(404).json({ error: 'Producto no encontrado' });
      res.json(product);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async getProductsByCategory(req: Request, res: Response) {
    try {
      const products = await this.productUseCases.getProductsByCategory(req.params.categoryId);
      res.json(products);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async updateProduct(req: Request, res: Response) {
    try {
      const product = await this.productUseCases.updateProduct(req.params.id, req.body);
      res.json(product);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async deleteProduct(req: Request, res: Response) {
    try {
      await this.productUseCases.deleteProduct(req.params.id);
      res.status(204).send();
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  // Variant endpoints
  async createVariant(req: Request, res: Response) {
    try {
      const variant = await this.productUseCases.createVariant(req.body);
      res.status(201).json(variant);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async getVariants(req: Request, res: Response) {
    try {
      const variants = await this.productUseCases.getVariantsByProduct(req.params.productId);
      res.json(variants);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async updateVariant(req: Request, res: Response) {
    try {
      const variant = await this.productUseCases.updateVariant(req.params.id, req.body);
      res.json(variant);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async deleteVariant(req: Request, res: Response) {
    try {
      await this.productUseCases.deleteVariant(req.params.id);
      res.status(204).send();
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async updateStock(req: Request, res: Response) {
    try {
      const { quantity } = req.body;
      const variant = await this.productUseCases.updateStock(req.params.id, quantity);
      res.json(variant);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  // Duplicate cleanup endpoints
  async getDuplicates(req: Request, res: Response) {
    try {
      if (!this.duplicateCleanupUseCases) throw new Error('Servicio de limpieza no disponible');
      const duplicates = await this.duplicateCleanupUseCases.findDuplicates();
      res.json(duplicates);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async cleanupDuplicates(req: Request, res: Response) {
    try {
      if (!this.duplicateCleanupUseCases) throw new Error('Servicio de limpieza no disponible');
      const { keys } = req.body;
      const results = await this.duplicateCleanupUseCases.cleanupDuplicates(keys);
      res.json(results);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }
}