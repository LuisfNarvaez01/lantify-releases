// ============================================
// INTERFACES - Customer Controller
// ============================================

import { Request, Response } from 'express';
import { CustomerUseCases } from '../../application/usecases/CustomerUseCases';

export class CustomerController {
  constructor(private customerUseCases: CustomerUseCases) {}

  async getAll(req: Request, res: Response) {
    try {
      const customers = await this.customerUseCases.getAll();
      res.json(customers);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async search(req: Request, res: Response) {
    try {
      const q = (req.query.q as string) || '';
      const customers = await this.customerUseCases.search(q);
      res.json(customers);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async getById(req: Request, res: Response) {
    try {
      const customer = await this.customerUseCases.getById(req.params.id);
      if (!customer) return res.status(404).json({ error: 'Cliente no encontrado' });
      res.json(customer);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async getDefault(req: Request, res: Response) {
    try {
      const customer = await this.customerUseCases.getDefault();
      res.json(customer);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async getBirthdays(req: Request, res: Response) {
    try {
      const customers = await this.customerUseCases.getBirthdays();
      res.json(customers);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async getRecommended(req: Request, res: Response) {
    try {
      const products = await this.customerUseCases.getRecommendedProducts(req.params.id);
      res.json(products);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  async create(req: Request, res: Response) {
    try {
      const customer = await this.customerUseCases.create(req.body);
      res.status(201).json(customer);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async update(req: Request, res: Response) {
    try {
      const customer = await this.customerUseCases.update(req.params.id, req.body);
      res.json(customer);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async deactivate(req: Request, res: Response) {
    try {
      await this.customerUseCases.deactivate(req.params.id);
      res.status(204).send();
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }

  async adjustStamps(req: Request, res: Response) {
    try {
      const delta = Number(req.body.delta) || 0;
      const reason = req.body.reason ? String(req.body.reason) : undefined;
      const actor = (req as any).user?.username || (req as any).user?.name || 'admin';
      const updated = await this.customerUseCases.adjustStamps(req.params.id, delta, reason, actor);
      res.json(updated);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  }
}
