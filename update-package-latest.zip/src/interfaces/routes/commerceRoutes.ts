// ============================================
// INTERFACES - Proveedores y cupones
// ============================================
//   GET    /api/suppliers                      → proveedores con su lista de precios
//   POST   /api/suppliers  · PUT /api/suppliers/:id
//   PUT    /api/suppliers/:id/prices           → agregar o actualizar precios
//   DELETE /api/suppliers/:id/prices/:priceId
//   GET    /api/suppliers/best-prices          → quién vende cada cosa más barato
//   GET    /api/coupons · POST /api/coupons · PUT /api/coupons/:id
//   GET    /api/coupons/validate?code=&subtotal= → caja: ¿sirve el cupón? (descuento exacto)

import { Router, Response } from 'express';
import { SupplierUseCases, SupplierError } from '../../application/usecases/SupplierUseCases';
import { CouponUseCases, CouponError } from '../../application/usecases/CouponUseCases';
import { AuthRequest } from '../../shared/authMiddleware';

const fail = (res: Response, err: unknown) => {
  if (err instanceof SupplierError || err instanceof CouponError) return res.status(err.status).json({ code: err.code, error: err.message });
  console.error('[comercio]', err);
  return res.status(500).json({ code: 'SERVER_ERROR', error: 'Error interno del servidor' });
};

export const createCommerceRoutes = (suppliers = new SupplierUseCases(), coupons = new CouponUseCases()) => {
  const router = Router();
  const actor = (req: AuthRequest) => req.user?.name || req.user?.username;

  router.get('/suppliers', async (_req, res) => {
    try { res.json(await suppliers.list()); } catch (e) { fail(res, e); }
  });
  router.get('/suppliers/best-prices', async (_req, res) => {
    try { res.json(await suppliers.bestPrices()); } catch (e) { fail(res, e); }
  });
  router.post('/suppliers', async (req, res) => {
    try { res.status(201).json(await suppliers.create(req.body || {})); } catch (e) { fail(res, e); }
  });
  router.put('/suppliers/:id', async (req, res) => {
    try { res.json(await suppliers.update(req.params.id, req.body || {})); } catch (e) { fail(res, e); }
  });
  router.put('/suppliers/:id/prices', async (req, res) => {
    try { res.json(await suppliers.upsertPrices(req.params.id, Array.isArray(req.body?.prices) ? req.body.prices : [])); } catch (e) { fail(res, e); }
  });
  router.delete('/suppliers/:id/prices/:priceId', async (req, res) => {
    try { res.json(await suppliers.deletePrice(req.params.id, req.params.priceId)); } catch (e) { fail(res, e); }
  });

  router.get('/coupons/validate', async (req, res) => {
    try { res.json(await coupons.validate(String(req.query.code || ''), Number(req.query.subtotal) || 0)); } catch (e) { fail(res, e); }
  });
  router.get('/coupons', async (_req, res) => {
    try { res.json(await coupons.list()); } catch (e) { fail(res, e); }
  });
  router.post('/coupons', async (req: AuthRequest, res) => {
    try { res.status(201).json(await coupons.create(req.body || {}, actor(req))); } catch (e) { fail(res, e); }
  });
  router.put('/coupons/:id', async (req, res) => {
    try { res.json(await coupons.update(req.params.id, req.body || {})); } catch (e) { fail(res, e); }
  });

  return router;
};
