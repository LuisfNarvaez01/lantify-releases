// ============================================
// INTERFACES - System & Backup Routes
// ============================================

import express, { Router, Request, Response } from 'express';
import { CloudBackupError, CloudBackupService } from '../../application/usecases/CloudBackupService';
import { BackupService } from '../../infrastructure/services/BackupService';
import { requireAuth, adminOnly } from '../../shared/authMiddleware';
import { AuditLogger } from '../../infrastructure/services/AuditLogger';

export function createSystemRoutes(cloudBackup?: CloudBackupService): Router {
  const router = Router();

  // ── Copia en Lantify Cloud ──
  const fail = (res: Response, err: any) => {
    if (err instanceof CloudBackupError) return res.status(err.status >= 400 && err.status < 600 ? err.status : 500).json({ code: err.code, error: err.message });
    console.error('[copia en la nube]', err);
    return res.status(500).json({ code: 'ERROR', error: err?.message || 'Error con la copia en la nube' });
  };
  const audit = (req: Request, action: string, details: Record<string, unknown> = {}) => {
    const u = (req as any).user;
    return AuditLogger.log({ userId: u?.userId, userName: u?.name, userRole: u?.role, action, entityType: 'SYSTEM', details, ipAddress: req.ip || req.socket.remoteAddress }).catch(() => {});
  };
  if (cloudBackup) {
    router.get('/cloud-backup', requireAuth, adminOnly, async (req: Request, res: Response) => {
      res.json(await cloudBackup.status((req as any).user?.id));
    });
    router.post('/cloud-backup', requireAuth, adminOnly, async (req: Request, res: Response) => {
      try {
        const backup = await cloudBackup.upload();
        await audit(req, 'CLOUD_BACKUP_UPLOADED', { sizeBytes: backup?.sizeBytes });
        res.status(201).json({ backup });
      } catch (err) {
        fail(res, err);
      }
    });
    router.post('/cloud-backup/restore', requireAuth, adminOnly, async (req: Request, res: Response) => {
      try {
        await audit(req, 'CLOUD_BACKUP_RESTORE', { source: 'cloud' });
        res.json(await cloudBackup.restoreFromCloud((req as any).user?.id));
      } catch (err) {
        fail(res, err);
      }
    });
    router.post('/cloud-backup/restore-file', requireAuth, adminOnly, express.raw({ type: () => true, limit: '300mb' }), async (req: Request, res: Response) => {
      try {
        if (!Buffer.isBuffer(req.body) || !req.body.length) return res.status(400).json({ code: 'BACKUP_BAD_FILE', error: 'Elige el archivo de la copia.' });
        await audit(req, 'CLOUD_BACKUP_RESTORE', { source: 'file', sizeBytes: req.body.length });
        res.json(await cloudBackup.restoreFromFile(req.body));
      } catch (err) {
        fail(res, err);
      }
    });
  }

  // Listar respaldos existentes (solo administrador)
  router.get('/backups', requireAuth, adminOnly, async (_req: Request, res: Response) => {
    try {
      const backups = BackupService.listBackups();
      res.json({
        success: true,
        count: backups.length,
        backups,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Error al listar respaldos' });
    }
  });

  // Generar respaldo manual verificado (solo administrador)
  router.post('/backups', requireAuth, adminOnly, async (req: Request, res: Response) => {
    try {
      const authReq = req as any;
      const backup = BackupService.runBackup('dev.db.manual');
      if (!backup) {
        return res.status(500).json({ error: 'No se pudo generar el respaldo.' });
      }

      await AuditLogger.log({
        userId: authReq.user?.userId,
        userName: authReq.user?.name,
        userRole: authReq.user?.role,
        action: 'MANUAL_BACKUP_CREATED',
        entityType: 'SYSTEM',
        details: { backupFile: backup.name, size: backup.sizeKB },
        ipAddress: req.ip || req.socket.remoteAddress,
      });

      res.status(201).json({
        success: true,
        message: 'Respaldo generado y verificado correctamente',
        backup,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Error al generar respaldo' });
    }
  });

  return router;
}
