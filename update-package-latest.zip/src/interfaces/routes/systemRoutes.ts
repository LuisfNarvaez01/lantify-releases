// ============================================
// INTERFACES - System & Backup Routes
// ============================================

import { Router, Request, Response } from 'express';
import { BackupService } from '../../infrastructure/services/BackupService';
import { requireAuth, adminOnly } from '../../shared/authMiddleware';
import { AuditLogger } from '../../infrastructure/services/AuditLogger';

export function createSystemRoutes(): Router {
  const router = Router();

  // Listar respaldos existentes (solo administrador)
  router.get('/backups', requireAuth, adminOnly, async (_req: Request, res: Response) => {
    try {
      const backups = BackupService.listBackups();
      res.json({
        success: true,
        count: backups.length,
        backups,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Error al listar respaldos' });
    }
  });

  // Generar respaldo manual verificado (solo administrador)
  router.post('/backups', requireAuth, adminOnly, async (req: Request, res: Response) => {
    try {
      const authReq = req as any;
      const backup = BackupService.runBackup('dev.db.manual');
      if (!backup) {
        return res.status(500).json({ error: 'No se pudo generar el respaldo.' });
      }

      await AuditLogger.log({
        userId: authReq.user?.userId,
        userName: authReq.user?.name,
        userRole: authReq.user?.role,
        action: 'MANUAL_BACKUP_CREATED',
        entityType: 'SYSTEM',
        details: { backupFile: backup.name, size: backup.sizeKB },
        ipAddress: req.ip || req.socket.remoteAddress,
      });

      res.status(201).json({
        success: true,
        message: 'Respaldo generado y verificado correctamente',
        backup,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Error al generar respaldo' });
    }
  });

  return router;
}
