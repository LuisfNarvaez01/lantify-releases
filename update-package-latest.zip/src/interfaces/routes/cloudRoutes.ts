// ============================================
// INTERFACES - Lantify Cloud: vinculación, licencia y asistente
// ============================================
//   GET    /api/cloud/status    → público: ¿licencia obligatoria? ¿negocio vinculado?
//   POST   /api/cloud/activate  → público solo mientras no haya negocio vinculado
//   DELETE /api/cloud/link      → ADMIN: desvincular (cambiar de negocio)
//   GET    /api/license         → cualquier usuario: plan, funciones y estado de pago
//   POST   /api/ai/chat         → cualquier usuario: el asistente, firmado con su licencia
//   POST   /api/ai/setup        → ADMIN: configuración inicial sugerida (descripción del negocio)
//   POST   /api/ai/menu         → ADMIN: carta por foto → categorías y productos
//   POST   /api/ai/design       → ADMIN: diseño recomendado para Mi página

import { Router, Response } from 'express';
import { z } from 'zod';
import { CloudAuthService } from '../../application/usecases/CloudAuthService';
import { AuthError, AuthUseCases } from '../../application/usecases/AuthUseCases';
import { AuthRequest } from '../../shared/authMiddleware';
import { createLoginLimiter } from '../../shared/security/rateLimits';
import { cloudConfig } from '../../shared/cloud/config';
import { clearStore, deviceFingerprint } from '../../shared/cloud/license';
import { invalidateFeatureCache } from '../../shared/cloud/features';
import { prisma } from '../../infrastructure/database/prisma';

const sendError = (res: Response, error: any) => {
  if (error instanceof AuthError) {
    return res.status(error.statusCode).json({ error: error.message, code: error.code, ...(error.details || {}) });
  }
  if (error instanceof z.ZodError) return res.status(400).json({ error: 'Datos inválidos.', code: 'VALIDATION_ERROR' });
  console.error('[cloud]', error);
  return res.status(500).json({ error: 'Error interno del servidor', code: 'SERVER_ERROR' });
};

export const createCloudRoutes = (cloud: CloudAuthService, auth?: AuthUseCases) => {
  const router = Router();
  const activateLimiter = createLoginLimiter();

  router.get('/cloud/status', async (_req, res) => {
    try {
      res.json(await cloud.status());
    } catch (error) {
      sendError(res, error);
    }
  });

  router.post('/cloud/activate', activateLimiter, async (req, res) => {
    try {
      if (await cloud.linkedTenant()) {
        throw new AuthError(409, 'CLOUD_ALREADY_LINKED', 'Este equipo ya está vinculado a un negocio.');
      }
      const { code, adminUsername, adminPassword } = z.object({
        code: z.string().min(3).max(40),
        adminUsername: z.string().max(64).optional(),
        adminPassword: z.string().max(256).optional(),
      }).parse(req.body);
      await auth?.assertLocalAdmin(adminUsername, adminPassword);
      const linked = await cloud.activate(code);
      invalidateFeatureCache();
      res.json(linked);
    } catch (error) {
      sendError(res, error);
    }
  });

  router.delete('/cloud/link', async (_req, res) => {
    try {
      await prisma.businessSettings.updateMany({ data: { cloudTenantCode: null, cloudTenantName: null } });
      clearStore();
      invalidateFeatureCache();
      res.json({ linked: false });
    } catch (error) {
      sendError(res, error);
    }
  });

  router.get('/license', async (req: AuthRequest, res) => {
    try {
      res.json(await cloud.licenseInfo(req.user!.id!));
    } catch (error) {
      sendError(res, error);
    }
  });

  // El navegador nunca ve una clave del asistente: este servidor firma con la licencia
  router.post('/ai/chat', async (req: AuthRequest, res) => {
    try {
      const credential = await cloud.aiCredential(req.user!.id!);
      if (!credential) return res.status(503).json({ code: 'AI_NOT_CONFIGURED' });
      const raw = JSON.stringify(req.body ?? {});
      if (raw.length > 16 * 1024) return res.status(413).json({ code: 'AI_BAD_REQUEST' });

      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 25000);
      try {
        const upstream = await fetch(`${cloudConfig().aiUrl}/ai/chat`, {
          method: 'POST',
          signal: controller.signal,
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${credential}`, 'X-Device-Id': deviceFingerprint().slice(0, 32) },
          body: raw,
        });
        const body = await upstream.json().catch(() => ({ code: 'AI_UNAVAILABLE' }));
        res.status(upstream.status).json(body);
      } catch {
        res.status(503).json({ code: controller.signal.aborted ? 'AI_TIMEOUT' : 'AI_UNAVAILABLE' });
      } finally {
        clearTimeout(timer);
      }
    } catch (error) {
      sendError(res, error);
    }
  });

  // Asistente de configuración inicial (lo que el ADMIN escribe o fotografía en ese momento)
  for (const kind of ['setup', 'menu', 'design'] as const) {
    router.post(`/ai/${kind}`, async (req: AuthRequest, res) => {
      try {
        const credential = await cloud.aiCredential(req.user!.id!);
        if (!credential) return res.status(503).json({ code: 'AI_NOT_CONFIGURED' });
        const raw = JSON.stringify(req.body ?? {});
        if (raw.length > (kind === 'menu' ? 2_600_000 : 8 * 1024)) return res.status(413).json({ code: 'AI_BAD_REQUEST' });
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 45000);
        try {
          const upstream = await fetch(`${cloudConfig().aiUrl}/ai/${kind}`, {
            method: 'POST',
            signal: controller.signal,
            headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${credential}`, 'X-Device-Id': deviceFingerprint().slice(0, 32) },
            body: raw,
          });
          res.status(upstream.status).json(await upstream.json().catch(() => ({ code: 'AI_UNAVAILABLE' })));
        } catch {
          res.status(503).json({ code: controller.signal.aborted ? 'AI_TIMEOUT' : 'AI_UNAVAILABLE' });
        } finally {
          clearTimeout(timer);
        }
      } catch (error) {
        sendError(res, error);
      }
    });
  }

  return router;
};
