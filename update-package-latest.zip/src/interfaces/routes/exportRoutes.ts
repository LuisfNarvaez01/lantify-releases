// ============================================
// INTERFACES - Exportar los datos del negocio
// ============================================
// Los datos fiscales son del negocio: se pueden exportar siempre, incluso con la
// suscripción suspendida. Por eso estas rutas no usan la sesión normal sino un
// permiso de exportación de 15 minutos, que se entrega:
//  - a un ADMIN con sesión abierta (POST /api/export/token), o
//  - a un ADMIN que escribió bien su clave pero tiene la cuenta suspendida.
//
//   POST /api/export/token          → ADMIN: permiso de exportación
//   GET  /api/export/sales.csv      → ventas (Bearer permiso de exportación)
//   GET  /api/export/invoices.csv   → facturas electrónicas DIAN

import { Router, Request, Response } from 'express';
import { prisma } from '../../infrastructure/database/prisma';
import { signExportToken, isExportToken, EXPORT_MINUTES } from '../../shared/security/exportToken';
import { AuthRequest } from '../../shared/authMiddleware';

const exportAllowed = (req: Request) => {
  const header = req.headers.authorization || '';
  return header.startsWith('Bearer ') && isExportToken(header.slice(7));
};

// Excel abre bien el CSV con BOM y punto y coma (configuración regional de Colombia)
const cell = (v: unknown) => {
  if (v === null || v === undefined) return '';
  const s = v instanceof Date ? v.toISOString() : String(v);
  return /[";\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};
const toCsv = (header: string[], rows: unknown[][]) =>
  '﻿' + [header, ...rows].map((r) => r.map(cell).join(';')).join('\r\n');

const sendCsv = (res: Response, name: string, csv: string) => {
  const stamp = new Date().toISOString().slice(0, 10);
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="lantify-${name}-${stamp}.csv"`);
  res.send(csv);
};

export const createExportRoutes = () => {
  const router = Router();

  router.post('/token', (req: AuthRequest, res) => {
    res.json({ exportToken: signExportToken(req.user!.username), expiresInMinutes: EXPORT_MINUTES });
  });

  router.get('/sales.csv', async (req, res, next) => {
    try {
      if (!exportAllowed(req)) return res.status(401).json({ code: 'EXPORT_TOKEN_INVALID', error: 'Permiso de exportación inválido o vencido.' });
      const sales = await prisma.sale.findMany({
        orderBy: { createdAt: 'asc' },
        include: { dianInvoice: { select: { invoiceNumber: true, cufe: true } }, customer: { select: { name: true, nit: true } } },
      });
      const rows = sales.map((s) => [
        s.saleNumber, s.createdAt, s.status, s.channel, s.paymentMethod,
        s.subtotal, s.tax, s.discount, s.tip, s.total,
        s.customer?.name ?? s.customerName, s.customer?.nit ?? '',
        s.dianInvoice?.invoiceNumber ?? '', s.dianInvoice?.cufe ?? '',
      ]);
      sendCsv(res, 'ventas', toCsv(
        ['numero', 'fecha', 'estado', 'canal', 'medio_pago', 'subtotal', 'impuesto', 'descuento', 'propina', 'total', 'cliente', 'documento_cliente', 'factura_dian', 'cufe'],
        rows,
      ));
    } catch (err) {
      next(err);
    }
  });

  router.get('/invoices.csv', async (req, res, next) => {
    try {
      if (!exportAllowed(req)) return res.status(401).json({ code: 'EXPORT_TOKEN_INVALID', error: 'Permiso de exportación inválido o vencido.' });
      const invoices = await prisma.dianInvoice.findMany({ orderBy: { issueDate: 'asc' } });
      const rows = invoices.map((i) => [
        i.invoiceNumber, i.issueDate, i.status, i.subtotal, i.tax, i.total,
        i.customerNit, i.customerName, i.customerEmail, i.cufe, i.publicUrl,
      ]);
      sendCsv(res, 'facturas-dian', toCsv(
        ['factura', 'fecha', 'estado', 'subtotal', 'impuesto', 'total', 'nit_cliente', 'cliente', 'correo_cliente', 'cufe', 'enlace'],
        rows,
      ));
    } catch (err) {
      next(err);
    }
  });

  return router;
};
