// ============================================
// INTERFACES - Product Import Routes
// ============================================

import { Router } from 'express';
import { ProductImportUseCases } from '../../application/usecases/ProductImportUseCases';
import { ProductRepository } from '../../infrastructure/persistence/repositories/ProductRepository';
import { prisma } from '../../infrastructure/database/prisma';
import path from 'path';
import fs from 'fs';

const productRepository = new ProductRepository(prisma);
const productImportUseCases = new ProductImportUseCases(productRepository);

const router = Router();

// Importar productos desde CSV (sin auth para pruebas)
// Nota: La ruta padre ya es /api/products/import, entonces aquí solo /
router.post('/', async (req, res) => {
  try {
    if (!req.body.csvContent) {
      return res.status(400).json({ error: 'Se requiere contenido CSV' });
    }

    // Guardar temporalmente el archivo
    const tempPath = path.join(__dirname, '../../temp_import.csv');
    fs.writeFileSync(tempPath, req.body.csvContent);

    const result = await productImportUseCases.importFromCSV(tempPath);
    
    // Limpiar archivo temporal
    fs.unlinkSync(tempPath);

    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Obtener plantilla CSV (sin auth)
router.get('/template', (req, res) => {
  const template = productImportUseCases.getCSVTemplate();
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename=plantilla_productos.csv');
  res.send(template);
});

export const createProductImportRoutes = () => router;
