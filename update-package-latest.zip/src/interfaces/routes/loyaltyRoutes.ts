// ============================================
// INTERFACES - Tarjeta de sellos del cliente (Premium · loyalty)
// ============================================
//   GET  /api/loyalty/customers/:id            → saldo, meta y si tiene tarjeta digital
//   POST /api/loyalty/customers/:id/stamps     → sumar o quitar sellos a mano
//   POST /api/loyalty/customers/:id/card-link  → enlace para recuperar su tarjeta en otro celular
//   GET  /api/loyalty/events/:id               → ¿ya llegó a su tarjeta o sigue en cola?

import { Router, Request, Response } from 'express';
import { AuthRequest } from '../../shared/authMiddleware';
import { CustomerUseCases } from '../../application/usecases/CustomerUseCases';
import { ReservationSyncService } from '../../application/usecases/ReservationSyncService';

export const createLoyaltyRoutes = (customers: CustomerUseCases, sync: ReservationSyncService) => {
  const router = Router();
  const fail = (res: Response, error: any) => res.status(400).json({ error: error?.message || 'No se pudo completar' });

  router.get('/customers/:id', async (req: Request, res: Response) => {
    try {
      res.json(await customers.loyaltyStatus(req.params.id));
    } catch (e) {
      fail(res, e);
    }
  });

  router.post('/customers/:id/stamps', async (req: AuthRequest, res: Response) => {
    try {
      const actor = req.user?.username || 'admin';
      const reason = req.body?.reason ? String(req.body.reason) : undefined;
      res.json(await customers.adjustStamps(req.params.id, Number(req.body?.delta) || 0, reason, actor));
    } catch (e) {
      fail(res, e);
    }
  });

  router.post('/customers/:id/card-link', async (req: Request, res: Response) => {
    const result = await sync.cardLink(req.params.id);
    if (result.ok) return res.json(result);
    res.status(result.code === 'OFFLINE' ? 503 : 409).json({ code: `LOYALTY_LINK_${result.code}` });
  });

  router.get('/events/:id', async (req: Request, res: Response) => {
    try {
      res.json(await customers.stampEvent(req.params.id));
    } catch (e) {
      res.status(404).json({ error: (e as Error).message });
    }
  });

  return router;
};
