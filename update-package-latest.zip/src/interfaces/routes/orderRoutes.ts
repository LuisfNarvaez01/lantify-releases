// ============================================
// INTERFACES - Order Routes
// ============================================

import { Router } from 'express';
import { OrderController } from '../controllers/OrderController';
import { optionalAuth, requirePermission } from '../../shared/authMiddleware';

export const createOrderRoutes = (controller: OrderController) => {
  const router = Router();

  // Consultas de comandas activas
  router.get('/active', optionalAuth, controller.getActiveOrders.bind(controller));
  router.get('/table/:tableId', optionalAuth, controller.getActiveOrderByTable.bind(controller));

  // Guardar/Actualizar comanda activa (meseros, cajeros, admins)
  router.post('/', optionalAuth, controller.saveOrder.bind(controller));

  // Enviar a cocina
  router.post('/:id/send', optionalAuth, controller.sendToKitchen.bind(controller));

  // Anulación de item de comanda (total o parcial)
  router.patch('/items/:itemId/cancel', optionalAuth, controller.cancelOrderItem.bind(controller));
  router.patch('/items/:itemId/cancel-partial', optionalAuth, controller.cancelOrderItemPartial.bind(controller));

  // Cerrar o cancelar comanda
  router.patch('/:id/close', optionalAuth, requirePermission('charge'), controller.closeOrder.bind(controller));

  return router;
};
