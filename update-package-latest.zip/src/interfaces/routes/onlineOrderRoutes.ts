// ============================================
// INTERFACES - Pedidos en línea (caja)
// ============================================
//   GET  /api/online-orders?date=YYYY-MM-DD → abiertos y los del día
//   GET  /api/online-orders/summary         → por aceptar (aviso del encabezado)
//   POST /api/online-orders/:id/accept      → a cocina ({ eta? })
//   POST /api/online-orders/:id/reject      → con motivo ({ reason }); el cliente lo ve
//   POST /api/online-orders/:id/ready       → listo / en camino
//   POST /api/online-orders/:id/complete    → cobrar en el arqueo abierto

import { Router, Response } from 'express';
import { OnlineOrderUseCases } from '../../application/usecases/OnlineOrderUseCases';
import { BookingError } from '../../application/usecases/ReservationUseCases';
import { AuthRequest } from '../../shared/authMiddleware';

const fail = (res: Response, err: unknown) => {
  if (err instanceof BookingError) return res.status(err.status).json({ code: err.code, error: err.message, ...err.extra });
  console.error('[pedidos-web]', err);
  const message = err instanceof Error ? err.message : 'Error interno del servidor';
  return res.status(500).json({ code: 'SERVER_ERROR', error: message });
};

export const createOnlineOrderRoutes = (orders: OnlineOrderUseCases) => {
  const router = Router();
  const actorOf = (req: AuthRequest) => req.user?.name || req.user?.username || 'POS';

  router.get('/online-orders', async (req, res) => {
    try {
      res.json(await orders.list(typeof req.query.date === 'string' ? req.query.date : undefined));
    } catch (err) {
      fail(res, err);
    }
  });

  router.get('/online-orders/summary', async (_req, res) => {
    try {
      res.json(await orders.summary());
    } catch (err) {
      fail(res, err);
    }
  });

  router.post('/online-orders/:id/:action', async (req: AuthRequest, res) => {
    try {
      const { id, action } = req.params;
      const actor = actorOf(req);
      if (action === 'accept') return res.json(await orders.accept(id, actor, req.body?.eta));
      if (action === 'reject') return res.json(await orders.reject(id, req.body?.reason, actor));
      if (action === 'ready') return res.json(await orders.ready(id));
      if (action === 'complete') return res.json(await orders.complete(id, actor));
      return res.status(404).json({ code: 'NOT_FOUND', error: 'Acción desconocida' });
    } catch (err) {
      fail(res, err);
    }
  });

  return router;
};
