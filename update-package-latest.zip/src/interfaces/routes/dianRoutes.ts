// ============================================
// ROUTES - Facturación electrónica DIAN y cola sin internet
// Lantify Cloud emite ante la DIAN (Lantify es la casa de software); el negocio no
// configura credenciales: solo ve si su facturación está activa y sus facturas.
// ============================================

import { Router, Request, Response } from 'express';
import { dianService } from '../../infrastructure/services/DianElectronicBillingService';
import { prisma } from '../../infrastructure/database/prisma';

export function createDianRoutes(): Router {
  const router = Router();

  // 1. Estado de la facturación (activa o no, resolución que entregó Lantify)
  const sendStatus = async (req: Request, res: Response) => {
    try {
      const status = await dianService.status(req.query.refresh === '1');
      return res.json({ success: true, status, config: status });
    } catch (error: any) {
      console.error('Error fetching DIAN status:', error);
      return res.status(500).json({ error: 'Error al consultar la facturación electrónica' });
    }
  };
  router.get('/status', sendStatus);
  router.get('/config', sendStatus);

  // 2. Lo único que decide el negocio: si la cola se reenvía sola
  router.put('/config', async (req: Request, res: Response) => {
    try {
      if (typeof req.body?.autoSync === 'boolean') await dianService.updateConfig({ autoSync: req.body.autoSync });
      return res.json({ success: true, status: await dianService.status() });
    } catch (error: any) {
      console.error('Error updating DIAN config:', error);
      return res.status(500).json({ error: 'Error al guardar la configuración' });
    }
  });

  // 4. Estadísticas y Monitoreo de Conectividad / Cola DIAN
  router.get('/stats', async (_req: Request, res: Response) => {
    try {
      const stats = await dianService.getQueueStats();
      return res.json({ success: true, ...stats });
    } catch (error: any) {
      console.error('Error fetching DIAN queue stats:', error);
      return res.status(500).json({ error: 'Error al consultar estado de la cola DIAN' });
    }
  });

  // 5. Listar Facturas en Cola
  router.get('/queue', async (req: Request, res: Response) => {
    try {
      const { status } = req.query;
      const where: any = {};
      if (status && typeof status === 'string') {
        where.status = status;
      }

      const invoices = await prisma.dianInvoice.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        include: {
          sale: {
            select: {
              saleNumber: true,
              total: true,
              paymentMethod: true,
              createdAt: true
            }
          }
        }
      });

      return res.json({ success: true, count: invoices.length, invoices });
    } catch (error: any) {
      console.error('Error fetching DIAN queue:', error);
      return res.status(500).json({ error: 'Error al listar cola de facturas' });
    }
  });

  // 6. Disparar Procesamiento Manual de la Cola
  router.post('/queue/process', async (_req: Request, res: Response) => {
    try {
      const result = await dianService.processQueue();
      return res.json({
        success: true,
        message: `Cola procesada: ${result.processed} analizadas, ${result.success} aceptadas, ${result.failed} pendientes/fallidas`,
        result
      });
    } catch (error: any) {
      console.error('Error processing DIAN queue:', error);
      return res.status(500).json({ error: error.message || 'Error al procesar cola DIAN' });
    }
  });

  // 7. Reintentar Envío de una Factura Específica
  router.post('/queue/:id/retry', async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const invoice = await dianService.retryInvoice(id);
      return res.json({
        success: true,
        message: invoice.status === 'ACCEPTED' ? 'Factura validada ante la DIAN' : (invoice.dianResponseDesc || 'Factura reenviada'),
        invoice
      });
    } catch (error: any) {
      if (error?.code === 'DIAN_NOT_CONFIGURED') return res.status(409).json({ code: 'DIAN_NOT_CONFIGURED', error: error.message });
      console.error('Error retrying invoice:', error);
      return res.status(500).json({ error: error.message || 'Error al reintentar factura' });
    }
  });

  // 8. Emitir / Encolar Factura Electrónica para una Venta
  router.post('/emit', async (req: Request, res: Response) => {
    try {
      const { saleId, customer } = req.body;
      if (!saleId) {
        return res.status(400).json({ error: 'El ID de la venta es obligatorio' });
      }

      const invoice = await dianService.enqueueInvoice(saleId, {
        nit: customer?.nit || '222222222222',
        name: customer?.name || 'Consumidor Final',
        email: customer?.email,
        phone: customer?.phone,
        address: customer?.address,
        documentType: customer?.documentType || 'CC'
      });

      return res.json({
        success: true,
        message: invoice.status === 'ACCEPTED'
          ? 'Factura electrónica validada ante la DIAN'
          : invoice.status === 'REJECTED'
            ? `La DIAN rechazó la factura: ${invoice.dianResponseDesc || 'revisa los datos'}`
            : 'Factura electrónica registrada: se valida ante la DIAN apenas haya respuesta',
        invoice
      });
    } catch (error: any) {
      if (error?.code === 'DIAN_NOT_CONFIGURED') return res.status(409).json({ code: 'DIAN_NOT_CONFIGURED', error: error.message });
      if (error?.code === 'DIAN_EMAIL_REQUIRED') return res.status(400).json({ code: 'DIAN_EMAIL_REQUIRED', error: error.message });
      console.error('Error emitting electronic invoice:', error);
      return res.status(500).json({ error: error.message || 'Error al emitir factura electrónica' });
    }
  });

  // Datos de la resolución de facturación (se imprimen en cada factura; no incluye secretos)
  router.get('/resolution', async (_req: Request, res: Response) => {
    try {
      const config = await dianService.refreshStatus();
      return res.json({
        success: true,
        resolution: dianService.isReady(config) ? {
          resolutionNumber: config.resolutionNumber,
          resolutionDate: config.resolutionDate,
          prefix: config.prefix,
          rangeFrom: config.rangeFrom,
          rangeTo: config.rangeTo,
          operationMode: config.operationMode,
        } : null,
      });
    } catch (error: any) {
      console.error('Error fetching DIAN resolution:', error);
      return res.status(500).json({ error: 'Error al consultar la resolución DIAN' });
    }
  });

  // 9. Consultar Factura Electrónica por Venta
  router.get('/sale/:saleId', async (req: Request, res: Response) => {
    try {
      const { saleId } = req.params;
      const invoice = await prisma.dianInvoice.findUnique({
        where: { saleId }
      });

      return res.json({ success: true, invoice });
    } catch (error: any) {
      console.error('Error fetching invoice for sale:', error);
      return res.status(500).json({ error: 'Error al buscar factura de la venta' });
    }
  });

  // 11. Descargar XML UBL 2.1
  router.get('/invoice/:id/xml', async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const invoice = await prisma.dianInvoice.findUnique({
        where: { id }
      });

      if (!invoice || !invoice.xmlContent) {
        return res.status(404).json({ error: 'XML no disponible para esta factura' });
      }

      res.setHeader('Content-Type', 'application/xml');
      res.setHeader('Content-Disposition', `attachment; filename="${invoice.invoiceNumber}.xml"`);
      return res.send(invoice.xmlContent);
    } catch (error: any) {
      console.error('Error downloading XML:', error);
      return res.status(500).json({ error: 'Error al descargar XML' });
    }
  });

  return router;
}
