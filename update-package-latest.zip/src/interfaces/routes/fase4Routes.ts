// ============================================
// INTERFACES - Fase 4 · Precios por horario y encuesta
// ============================================
//   GET    /api/price-rules          → ADMIN: todas las reglas
//   GET    /api/price-rules/active   → todos: reglas que cuentan y cuáles están vigentes (caja y celular)
//   POST   /api/price-rules          → ADMIN
//   PUT    /api/price-rules/:id      → ADMIN
//   DELETE /api/price-rules/:id      → ADMIN
//   GET    /api/surveys/summary      → ADMIN: Estadísticas → Satisfacción
// Quién puede llamar cada una lo decide src/shared/security/accessPolicy.ts.

import { Router, Response } from 'express';
import { AuthRequest } from '../../shared/authMiddleware';
import { AuditLogger } from '../../infrastructure/services/AuditLogger';
import { PriceRuleUseCases } from '../../application/usecases/PriceRuleUseCases';
import { SurveyUseCases } from '../../application/usecases/SurveyUseCases';
import { PriceRuleError } from '../../domain/priceRules';
import { loadFeatures } from '../../shared/featureStore';

type Handler = (req: AuthRequest) => Promise<unknown>;
const run = (fn: Handler, status = 200) => async (req: AuthRequest, res: Response) => {
  try {
    res.status(status).json(await fn(req));
  } catch (error: any) {
    if (error instanceof PriceRuleError) return res.status(error.code === 'PRICE_RULE_NOT_FOUND' ? 404 : 400).json({ error: error.message, code: error.code });
    console.error('[fase4]', error);
    res.status(500).json({ error: 'No se pudo completar la operación.', code: 'FASE4_ERROR' });
  }
};

export const createFase4Routes = (rules = new PriceRuleUseCases(), surveys = new SurveyUseCases()) => {
  const router = Router();
  const who = (req: AuthRequest) => ({ userId: req.user?.id || req.user?.userId, userName: req.user?.name || req.user?.username, userRole: req.user?.role });

  router.get('/price-rules/active', run(() => rules.forRegister()));
  router.get('/price-rules', run(() => rules.list()));
  router.post('/price-rules', run(async (req) => {
    const rule = await rules.create(req.body);
    AuditLogger.log({ action: 'PRICE_RULE_CREATED', entityType: 'PRICE_RULE', entityId: rule.id, ...who(req), details: rule });
    return rule;
  }, 201));
  router.put('/price-rules/:id', run(async (req) => {
    const rule = await rules.update(req.params.id, req.body);
    AuditLogger.log({ action: 'PRICE_RULE_UPDATED', entityType: 'PRICE_RULE', entityId: rule.id, ...who(req), details: rule });
    return rule;
  }));
  router.delete('/price-rules/:id', run(async (req) => {
    AuditLogger.log({ action: 'PRICE_RULE_DELETED', entityType: 'PRICE_RULE', entityId: req.params.id, ...who(req) });
    return rules.remove(req.params.id);
  }));

  router.get('/surveys/summary', run(async () => ({ enabled: (await loadFeatures()).flags.survey, ...(await surveys.summary()) })));
  return router;
};
