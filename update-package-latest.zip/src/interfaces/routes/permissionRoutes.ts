// ============================================
// INTERFACES - Funciones por rol y conexión de tablets
// ============================================
//   GET /api/permissions        → todos: qué puede hacer cada rol (la pantalla oculta lo demás)
//   PUT /api/permissions        → ADMIN
//   GET /api/permissions/devices → ADMIN: dirección para abrir el POS desde tablets
//   GET /api/permissions/devices/doctor · POST …/repair → ADMIN: probar y reparar la conexión

import os from 'os';
import { diagnose, repair } from '../../shared/network/lanDoctor';
import { staticDir } from '../../shared/runtime';
import { getDataDir } from '../../shared/security/secrets';
import { Router } from 'express';
import { AuthRequest } from '../../shared/authMiddleware';
import { AuditLogger } from '../../infrastructure/services/AuditLogger';
import { loadRolePermissions, saveRolePermissions } from '../../shared/security/rolePermissionsStore';

/** Puerto de la pantalla del POS: el del servidor si entrega la interfaz compilada; si no, el de Vite */
const uiPort = () => (staticDir() ? Number(process.env.PORT) || 5000 : Number(process.env.UI_PORT) || 5173);

/** IPv4 de la red local, primero las de WiFi/Ethernet "normales" */
export const lanAddresses = (): string[] => {
  const found: { ip: string; score: number }[] = [];
  for (const [name, list] of Object.entries(os.networkInterfaces())) {
    for (const a of list || []) {
      if (a.family !== 'IPv4' || a.internal) continue;
      if (a.address.startsWith('169.254.')) continue; // sin red (APIPA)
      const virtual = /virtual|vmware|vbox|hyper-v|vethernet|wsl|docker|tailscale|zerotier|loopback/i.test(name);
      const privateNet = /^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(a.address);
      if (!privateNet) continue;
      // 192.168.56.x es la red de VirtualBox
      found.push({ ip: a.address, score: (virtual || a.address.startsWith('192.168.56.') ? 0 : 2) + (/wi-?fi|wlan|ethernet/i.test(name) ? 1 : 0) });
    }
  }
  return found.sort((x, y) => y.score - x.score).map((f) => f.ip);
};

export const createPermissionRoutes = () => {
  const router = Router();

  router.get('/permissions', async (_req, res, next) => {
    try {
      res.json(await loadRolePermissions());
    } catch (err) {
      next(err);
    }
  });

  router.put('/permissions', async (req: AuthRequest, res, next) => {
    try {
      const saved = await saveRolePermissions(req.body);
      AuditLogger.log({
        action: 'ROLE_PERMISSIONS_UPDATED', entityType: 'SETTINGS', entityId: 'default',
        userId: req.user?.id, details: { by: req.user?.username, ...saved },
      });
      res.json(saved);
    } catch (err) {
      next(err);
    }
  });

  router.get('/permissions/devices', (_req, res) => {
    const lanEnabled = process.env.LAN_ACCESS === 'true';
    const ips = lanAddresses();
    res.json({
      lanEnabled,
      hostname: os.hostname(),
      urls: ips.map((ip) => `http://${ip}:${uiPort()}`),
    });
  });

  // Probar conexión: por qué un celular no entra y cómo arreglarlo (ADMIN)
  const opts = () => ({ lanEnabled: process.env.LAN_ACCESS === 'true', port: Number(process.env.PORT) || 5000, uiPort: uiPort() });
  router.get('/permissions/devices/doctor', async (_req, res, next) => {
    try { res.json(await diagnose(opts())); } catch (err) { next(err); }
  });
  router.post('/permissions/devices/repair', async (req: AuthRequest, res, next) => {
    try {
      const o = opts();
      const ok = await repair(getDataDir(), [...new Set([o.port, o.uiPort])]);
      AuditLogger.log({ action: 'LAN_FIREWALL_REPAIR', entityType: 'SETTINGS', entityId: 'network', userId: req.user?.id, details: { ok } });
      res.json({ ok, diagnosis: await diagnose(o) });
    } catch (err) { next(err); }
  });

  return router;
};
