// ============================================
// INTERFACES - Fase 4 · Confirmar transferencias con el aviso del banco
// ============================================
//   POST   /api/payments/incoming          → el celular del negocio: { ref, app, amount, sender?, postedAt }
//   GET    /api/payments/incoming          → transferencias leídas en las últimas 24 h
//   POST   /api/payments/expect            → Cobrar → Transferencia espera { amount }
//   GET    /api/payments/expect/:id        → ¿ya llegó? (WAITING | CONFIRMED | EXPIRED)
//   POST   /api/payments/expect/:id/close  → se terminó el cobro ({ keep: true } si se registró la venta)
// Quién puede llamar cada una lo decide src/shared/security/accessPolicy.ts.
// Lantify nunca mueve dinero: solo lee el aviso que el banco ya mostró en el teléfono.

import { Router, Response } from 'express';
import { AuthRequest } from '../../shared/authMiddleware';
import { featureAllowed } from '../../shared/featureStore';
import { IncomingTransferUseCases, TransferError } from '../../application/usecases/IncomingTransferUseCases';

const fail = (res: Response, error: any) => {
  if (error instanceof TransferError) return res.status(error.statusCode).json({ error: error.message, code: error.code });
  console.error('[transferencias]', error);
  return res.status(500).json({ error: 'No se pudo completar la operación.', code: 'LOCAL_ERROR' });
};

type Handler = (req: AuthRequest) => Promise<unknown>;
const withFeature = (fn: Handler) => async (req: AuthRequest, res: Response) => {
  try {
    if (!(await featureAllowed('bank_notifications'))) return res.status(403).json({ error: 'Esta función está apagada en el negocio.', code: 'FEATURE_OFF', feature: 'bank_notifications' });
    res.json(await fn(req));
  } catch (error) {
    fail(res, error);
  }
};

export const createTransferRoutes = (transfers = new IncomingTransferUseCases()) => {
  const router = Router();
  router.post('/payments/incoming', withFeature((req) => transfers.receive(req.body || {}, { userId: req.user?.id || req.user?.userId, name: req.user?.name || req.user?.username, role: req.user?.role })));
  router.get('/payments/incoming', withFeature(() => transfers.recent()));
  router.post('/payments/expect', withFeature((req) => transfers.expect(req.body?.amount)));
  router.get('/payments/expect/:id', withFeature((req) => transfers.status(req.params.id)));
  // Cerrar siempre funciona (aunque apaguen la función a mitad de un cobro)
  router.post('/payments/expect/:id/close', async (req: AuthRequest, res) => {
    try {
      res.json(await transfers.close(req.params.id, req.body?.keep === true));
    } catch (error) {
      fail(res, error);
    }
  });
  return router;
};
