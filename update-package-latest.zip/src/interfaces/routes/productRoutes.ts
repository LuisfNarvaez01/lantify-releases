// ============================================
// INTERFACES - Product Routes
// ============================================

import { Router } from 'express';
import { ProductController } from '../controllers';
import { AuthRequest } from '../../shared/authMiddleware';
import { VariantMergeError, VariantMergeUseCases } from '../../application/usecases/VariantMergeUseCases';

export const createProductRoutes = (controller: ProductController) => {
  const router = Router();
  const merger = new VariantMergeUseCases();

  // Unificar productos sueltos como variantes de uno solo (antes de /:id)
  router.get('/variant-groups', async (_req, res) => {
    try {
      res.json(await merger.suggestions());
    } catch (error: any) {
      res.status(500).json({ error: error?.message || 'No se pudo revisar los productos.' });
    }
  });
  router.post('/variant-groups/merge', async (req: AuthRequest, res) => {
    try {
      res.json(await merger.merge(req.body || {}, req.user?.name || req.user?.username || 'ADMIN'));
    } catch (error: any) {
      if (error instanceof VariantMergeError) return res.status(400).json({ code: error.code, error: error.message });
      res.status(500).json({ error: error?.message || 'No se pudieron unir los productos.' });
    }
  });

  // Category routes
  router.post('/categories', controller.createCategory.bind(controller));
  router.get('/categories', controller.getCategories.bind(controller));
  router.get('/categories/:id', controller.getCategoryById.bind(controller));
  router.put('/categories/:id', controller.updateCategory.bind(controller));
  router.delete('/categories/:id', controller.deleteCategory.bind(controller));

  // Product routes
  router.post('/', controller.createProduct.bind(controller));
  router.get('/', controller.getProducts.bind(controller));
  router.get('/:id', controller.getProductById.bind(controller));
  router.get('/category/:categoryId', controller.getProductsByCategory.bind(controller));
  router.put('/:id', controller.updateProduct.bind(controller));
  router.delete('/:id', controller.deleteProduct.bind(controller));

  // Variant routes
  router.post('/variants', controller.createVariant.bind(controller));
  router.get('/variants/:productId', controller.getVariants.bind(controller));
  router.put('/variants/:id', controller.updateVariant.bind(controller));
  router.delete('/variants/:id', controller.deleteVariant.bind(controller));
  router.patch('/variants/:id/stock', controller.updateStock.bind(controller));

  // Duplicate cleanup routes
  router.get('/duplicates/find', controller.getDuplicates.bind(controller));
  router.post('/duplicates/cleanup', controller.cleanupDuplicates.bind(controller));

  return router;
};