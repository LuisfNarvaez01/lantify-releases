// ============================================
// INTERFACES - Business Settings Routes
// ============================================
// GET lo usa todo el equipo (ticket, impuestos, módulos visibles).
// Escribir es solo para ADMIN (lo aplica la política global de acceso).

import { Router, Response } from 'express';
import { z } from 'zod';
import { BusinessSettingsUseCases, BusinessError } from '../../application/usecases/BusinessSettingsUseCases';
import { AuthError } from '../../application/usecases/AuthUseCases';
import { AuthRequest } from '../../shared/authMiddleware';
import { BUSINESS_TYPES } from '../../infrastructure/services/sampleMenus';
import { MEDIA_URL_RE } from '../../domain/media';

const optionalText = (max: number) => z.string().max(max).nullable().optional();

const settingsSchema = z.object({
  businessType: z.enum(BUSINESS_TYPES as [string, ...string[]]).optional(),
  businessName: z.string().max(120).optional(),
  legalName: optionalText(160),
  nit: optionalText(20),
  dv: z.string().regex(/^[0-9]?$/).nullable().optional(),
  taxRegime: z.enum(['NO_RESPONSABLE', 'RESPONSABLE_INC', 'RESPONSABLE_IVA']).optional(),
  address: optionalText(200),
  city: optionalText(80),
  phone: optionalText(40),
  email: z.union([z.string().email().max(120), z.literal(''), z.null()]).optional(),
  ticketFooter: optionalText(300),
  logoUrl: z.string().regex(MEDIA_URL_RE).nullable().optional(),
  usesTables: z.boolean().optional(),
  deliveryEnabled: z.boolean().optional(),
  whatsappEnabled: z.boolean().optional(),
  rappiEnabled: z.boolean().optional(),
  inventoryEnabled: z.boolean().optional(),
  tipEnabled: z.boolean().optional(),
  tipPercent: z.number().min(0).max(30).optional(),
  defaultTaxType: z.enum(['IVA', 'INC', 'NONE']).optional(),
  defaultTaxRate: z.number().min(0).max(100).optional(),
  wantsElectronicInvoice: z.boolean().optional(),
}).strict();

const onboardingSchema = z.object({
  settings: settingsSchema.extend({
    businessType: z.enum(BUSINESS_TYPES as [string, ...string[]]),
    businessName: z.string().min(1).max(120),
  }),
  zones: z.array(z.object({ name: z.string().max(40), tables: z.number().int().min(0).max(200) })).max(20).optional(),
  staff: z.array(z.object({
    name: z.string().min(1).max(120),
    username: z.string().min(3).max(32),
    password: z.string().min(1).max(256),
    role: z.enum(['CASHIER', 'WAITER']),
  })).max(20).optional(),
  loadSampleMenu: z.boolean().optional(),
  menu: z.array(z.object({
    name: z.string().min(1).max(60),
    items: z.array(z.object({ name: z.string().min(1).max(80), price: z.number().positive().max(5_000_000) })).max(80),
  })).max(25).optional(),
  language: z.enum(['es', 'en']).optional(),
}).strict();

const sendError = (res: Response, error: any) => {
  if (error instanceof BusinessError || error instanceof AuthError) {
    return res.status(error.statusCode).json({ error: error.message, code: error.code });
  }
  if (error instanceof z.ZodError) {
    return res.status(400).json({ error: 'Datos incompletos o inválidos.', code: 'VALIDATION_ERROR' });
  }
  console.error('[business]', error);
  return res.status(500).json({ error: 'No se pudo guardar la configuración.', code: 'BUSINESS_ERROR' });
};

const actorOf = (req: AuthRequest) => ({
  userId: req.user?.userId,
  name: (req.user as any)?.name || req.user?.username,
  role: req.user?.role,
  ip: req.ip || req.socket.remoteAddress,
});

export const createBusinessRoutes = (useCases: BusinessSettingsUseCases) => {
  const router = Router();

  router.get('/', async (_req, res) => {
    try {
      res.json(await useCases.get());
    } catch (error) {
      sendError(res, error);
    }
  });

  router.put('/', async (req: AuthRequest, res) => {
    try {
      const input = settingsSchema.parse(req.body);
      res.json(await useCases.update(input as any, actorOf(req)));
    } catch (error) {
      sendError(res, error);
    }
  });

  router.post('/onboarding/dismiss', async (req: AuthRequest, res) => {
    try {
      res.json(await useCases.dismissOnboarding(actorOf(req)));
    } catch (error) {
      sendError(res, error);
    }
  });

  router.post('/onboarding', async (req: AuthRequest, res) => {
    try {
      const input = onboardingSchema.parse(req.body);
      res.status(201).json(await useCases.completeOnboarding(input as any, actorOf(req)));
    } catch (error) {
      sendError(res, error);
    }
  });

  return router;
};
