// ============================================
// INTERFACES - Version Routes
// ============================================

import { Router, Request, Response } from 'express';
import fs from 'fs';
import path from 'path';
import { exec, spawn } from 'child_process';
import { isDesktop, projectRoot, versionFile } from '../../shared/runtime';
import { askDesktop, DesktopUpdateStatus } from '../../shared/desktop';

const ROOT_DIR = projectRoot();
const VERSION_PATH = versionFile();
const UPDATE_BAT_PATH = path.join(ROOT_DIR, 'update.bat');

/** Notas del release de GitHub ("- novedad" por línea) → resumen y lista de novedades */
const parseNotes = (notes = '') => {
  const lines = notes.replace(/<[^>]+>/g, '\n').split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  const features = lines.filter((l) => /^[-*•]\s+/.test(l)).map((l) => l.replace(/^[-*•]\s+/, ''));
  const changelog = lines.filter((l) => !/^[-*•#]/.test(l)).join(' ');
  return { features, changelog };
};

/** Programa instalado: la app de escritorio descarga la versión nueva sola y la instala al cerrar */
async function desktopCheck(res: Response) {
  const status = await askDesktop<DesktopUpdateStatus>('update:check', null, 8000);
  if (!status) return res.json({ updateAvailable: false, desktop: true, message: 'Sin respuesta del actualizador' });
  const available = status.state === 'downloading' || status.state === 'ready';
  const notes = parseNotes(status.releaseNotes);
  return res.json({
    updateAvailable: available,
    desktop: true,
    ready: status.state === 'ready',
    percent: status.percent ?? null,
    state: status.state,
    currentVersion: status.currentVersion,
    latestVersion: status.latestVersion || status.currentVersion,
    releaseName: status.releaseName || (status.latestVersion ? `Lantify POS v${status.latestVersion}` : undefined),
    changelog: notes.changelog || undefined,
    features: notes.features,
    fixes: [],
    buildDate: status.releaseDate?.slice(0, 10) || '',
    error: status.error,
  });
}

/**
 * Compara dos versiones SemVer (ej. "1.0.0" vs "1.1.0")
 * Retorna > 0 si remote > local, < 0 si remote < local, 0 si son iguales.
 */
function compareSemVer(local: string, remote: string): number {
  const p1 = local.replace(/^v/i, '').split('.').map(n => parseInt(n, 10) || 0);
  const p2 = remote.replace(/^v/i, '').split('.').map(n => parseInt(n, 10) || 0);

  for (let i = 0; i < Math.max(p1.length, p2.length); i++) {
    const v1 = p1[i] || 0;
    const v2 = p2[i] || 0;
    if (v2 > v1) return 1;
    if (v2 < v1) return -1;
  }
  return 0;
}

export const createVersionRoutes = (): Router => {
  const router = Router();

  // 1. Obtener versión local actual
  router.get('/', (_req: Request, res: Response) => {
    try {
      if (fs.existsSync(VERSION_PATH)) {
        const versionData = JSON.parse(fs.readFileSync(VERSION_PATH, 'utf-8'));
        return res.json(versionData);
      }
      return res.json({ version: '1.0.0', buildDate: new Date().toISOString().split('T')[0] });
    } catch {
      return res.json({ version: '1.0.0' });
    }
  });

  // 2. Comprobar si existe una versión más reciente (para el Login)
  router.get('/check', async (req: Request, res: Response) => {
    if (isDesktop()) return desktopCheck(res);
    let localVersion = '1.0.0';
    let localData: any = {};

    if (fs.existsSync(VERSION_PATH)) {
      try {
        localData = JSON.parse(fs.readFileSync(VERSION_PATH, 'utf-8'));
        localVersion = localData.version || '1.0.0';
      } catch (e) {
        console.error('Error al leer local version.json:', e);
      }
    }

    // Modo de simulación para pruebas desde la UI (?simulate=true)
    if (req.query.simulate === 'true') {
      return res.json({
        updateAvailable: true,
        currentVersion: localVersion,
        latestVersion: '1.1.0',
        releaseName: 'Lantify POS v1.1.0 - Actualización Recomendada',
        changelog: 'Nueva versión con mejoras operativas, reportes avanzados de stock y optimización de facturación.',
        features: [
          'Nuevo generador de reportes de rotación de inventario con gráficas.',
          'Sincronización instantánea de comandas en cocina.',
          'Mejoras visuales y rendimiento optimizado en pantallas táctiles.'
        ],
        fixes: [
          'Corrección en recálculo de propinas automáticas en comandas divididas.',
          'Estabilidad mejorada en conexiones de impresoras térmicas USB.'
        ],
        buildDate: new Date().toISOString().split('T')[0]
      });
    }

    try {
      // Opción A: Comprobar URL remota si está configurada en .env o version.json
      const remoteUrl = process.env.UPDATE_CHECK_URL || localData.updateCheckUrl;

      if (remoteUrl) {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 3500);

        const response = await fetch(remoteUrl, { signal: controller.signal });
        clearTimeout(timeout);

        if (response.ok) {
          const remoteData: any = await response.json();
          const remoteVersion = remoteData.version || '1.0.0';

          if (compareSemVer(localVersion, remoteVersion) > 0) {
            return res.json({
              updateAvailable: true,
              currentVersion: localVersion,
              latestVersion: remoteVersion,
              releaseName: remoteData.releaseName || `Lantify POS v${remoteVersion}`,
              changelog: remoteData.changelog || 'Actualización oficial disponible.',
              features: remoteData.features || [],
              fixes: remoteData.fixes || [],
              buildDate: remoteData.buildDate || ''
            });
          }
        }
      }

      // Opción B: Comprobar Git remoto si existe un upstream configurado
      exec('git fetch --dry-run origin main', { cwd: ROOT_DIR, timeout: 4000 }, (err, stdout, stderr) => {
        // Si hay cambios disponibles en origin/main
        const hasGitUpdates = (stdout && stdout.trim().length > 0) || (stderr && stderr.includes('origin/main'));

        if (!err && hasGitUpdates) {
          return res.json({
            updateAvailable: true,
            currentVersion: localVersion,
            latestVersion: 'Nueva versión disponible en repositorio',
            releaseName: 'Actualización en repositorio central',
            changelog: 'Existen nuevos cambios publicados en el repositorio central de GitHub.',
            features: [
              'Descarga automática de mejoras y parches del sistema.',
              'Sincronización segura de la base de datos sin pérdida de información.'
            ],
            fixes: [
              'Correcciones de estabilidad y optimizaciones operativas.'
            ]
          });
        }

        // Sin actualizaciones pendientes o sin internet (silencioso)
        return res.json({
          updateAvailable: false,
          currentVersion: localVersion,
          message: 'Sistema actualizado'
        });
      });
    } catch {
      // En caso de cualquier error de red o timeout, responder silenciosamente
      return res.json({
        updateAvailable: false,
        currentVersion: localVersion,
        message: 'Modo offline'
      });
    }
  });

  // 3. Iniciar el actualizador seguro en ventana visible
  router.post('/apply-update', async (_req: Request, res: Response) => {
    if (isDesktop()) {
      const status = await askDesktop<DesktopUpdateStatus>('update:status');
      if (status?.state !== 'ready') {
        const percent = status?.percent != null ? ` (${Math.round(status.percent)} %)` : '';
        return res.status(409).json({ error: `La actualización todavía se está descargando${percent}. Intenta de nuevo en un momento.`, code: 'UPDATE_NOT_READY' });
      }
      res.json({
        success: true,
        desktop: true,
        message: 'Lantify se cerrará, instalará la versión nueva y volverá a abrir solo en menos de un minuto. Las tablets se reconectan cuando termine.',
      });
      // Se responde primero: la app se cierra al instalar
      setTimeout(() => void askDesktop('update:install'), 800);
      return;
    }
    try {
      if (!fs.existsSync(UPDATE_BAT_PATH)) {
        return res.status(404).json({ error: 'No se encontró el archivo update.bat en el servidor.' });
      }

      // Ejecutar update.bat en una nueva consola visible de Windows
      if (process.platform === 'win32') {
        spawn('cmd.exe', ['/c', 'start', 'cmd.exe', '/k', UPDATE_BAT_PATH], {
          detached: true,
          stdio: 'ignore'
        });
      } else {
        spawn('bash', [UPDATE_BAT_PATH], {
          detached: true,
          stdio: 'ignore'
        });
      }

      return res.json({
        success: true,
        message: 'Se ha abierto el Asistente de Actualización Segura en una ventana independiente. El respaldo de base de datos se ejecutará automáticamente.'
      });
    } catch (error: any) {
      console.error('Error al ejecutar update.bat:', error);
      return res.status(500).json({ error: error.message || 'No se pudo iniciar la actualización.' });
    }
  });

  return router;
};
