// ============================================
// INTERFACES - Guía de configuración
// ============================================
//   GET /api/setup-guide → ADMIN: lo elegido, lo marcado y lo que el sistema comprueba solo
//   PUT /api/setup-guide → ADMIN: guarda lo elegido y lo marcado

import { Router } from 'express';
import { prisma } from '../../infrastructure/database/prisma';
import { currentFeatures } from '../../shared/cloud/features';
import { normalizeGuide } from '../../domain/setupGuide';
import { normalizePageConfig } from '../../domain/businessPage';
import { normalizeBooking } from '../../domain/booking';

const SETTINGS_ID = 'default';

const parse = (raw: string | null | undefined) => {
  try {
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
};

/** Pasos que el sistema puede comprobar solo, con lo que hay en la base */
const autoChecks = async (): Promise<Record<string, boolean>> => {
  const b = await prisma.businessSettings.findUnique({ where: { id: SETTINGS_ID } });
  const page = normalizePageConfig(parse(b?.pageSettings));
  const booking = normalizeBooking(parse(b?.bookingSettings));
  const dian = await prisma.dianConfig.findFirst();
  const [products, withPhoto, tables, staff, sessions, tracked, suppliers, expenseCats, customers, coupons] = await Promise.all([
    prisma.product.count({ where: { isActive: true } }),
    prisma.product.count({ where: { isActive: true, imageUrl: { not: null } } }),
    prisma.table.count(),
    prisma.user.count({ where: { isActive: true, role: { not: 'ADMIN' } } }),
    prisma.cashSession.count(),
    prisma.productVariant.count({ where: { isActive: true, trackInventory: true } }),
    prisma.supplier.count(),
    prisma.expenseCategory.count(),
    prisma.customer.count({ where: { isDefault: false, isActive: true } }),
    prisma.coupon.count(),
  ]);
  return {
    negocio_datos: !!b?.businessName?.trim() && !!b?.address?.trim() && !!b?.phone?.trim(),
    negocio_logo: !!b?.logoUrl,
    negocio_cuenta: !!b?.cloudTenantCode,
    carta_productos: products > 0,
    carta_fotos: withPhoto > 0,
    salon_mesas: tables > 0,
    impresion_impresora: !!b?.printSettings,
    equipo_usuarios: staff > 0,
    equipo_funciones: !!b?.rolePermissions,
    caja_primera: sessions > 0,
    inventario_control: tracked > 0,
    proveedores_crear: suppliers > 0,
    proveedores_gastos: expenseCats > 0,
    clientes_registro: customers > 0,
    cupones_crear: coupons > 0,
    dian_proveedor: !!dian && !!dian.resolutionNumber && !!dian.factusClientId && !!dian.factusClientSecret,
    pagina_publicar: !!b?.bookingPublishedAt,
    reservas_activar: booking.enabled && booking.online,
    pedidos_activar: page.sections.orders,
    fidelidad_reglas: page.loyalty.enabled,
    fidelidad_registro: page.sections.signup,
    fidelidad_juego: page.sections.games && page.games.prizes.length > 0,
    ia_autorizar: !!b?.aiConsentAt,
  };
};

export const createSetupGuideRoutes = () => {
  const router = Router();

  router.get('/setup-guide', async (_req, res, next) => {
    try {
      const b = await prisma.businessSettings.findUnique({ where: { id: SETTINGS_ID } });
      res.json({
        state: normalizeGuide(parse(b?.setupGuide)),
        checks: await autoChecks(),
        // null = sin negocio vinculado: todo disponible (como en la pantalla)
        features: await currentFeatures(),
        usesTables: b?.usesTables ?? true,
      });
    } catch (err) {
      next(err);
    }
  });

  router.put('/setup-guide', async (req, res, next) => {
    try {
      const state = normalizeGuide(req.body);
      await prisma.businessSettings.upsert({
        where: { id: SETTINGS_ID },
        update: { setupGuide: JSON.stringify(state) },
        create: { id: SETTINGS_ID, setupGuide: JSON.stringify(state) },
      });
      res.json({ state, checks: await autoChecks() });
    } catch (err) {
      next(err);
    }
  });

  return router;
};
