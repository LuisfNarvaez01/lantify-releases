// ============================================
// INTERFACES - Guía de configuración
// ============================================
//   GET /api/setup-guide → ADMIN: lo elegido, lo marcado y lo que el sistema comprueba solo
//   PUT /api/setup-guide → ADMIN: guarda lo elegido y lo marcado

import { Router } from 'express';
import { prisma } from '../../infrastructure/database/prisma';
import { currentFeatures } from '../../shared/cloud/features';
import { normalizeGuide } from '../../domain/setupGuide';
import { normalizePageConfig } from '../../domain/businessPage';
import { normalizeBooking } from '../../domain/booking';
import { normalizePrintSettings } from '../../domain/printSettings';
import { featureAllowed } from '../../shared/featureStore';

const SETTINGS_ID = 'default';

const parse = (raw: string | null | undefined) => {
  try {
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
};

/** Pasos que el sistema puede comprobar solo, con lo que hay en la base */
const autoChecks = async (): Promise<Record<string, boolean>> => {
  const b = await prisma.businessSettings.findUnique({ where: { id: SETTINGS_ID } });
  const page = normalizePageConfig(parse(b?.pageSettings));
  const booking = normalizeBooking(parse(b?.bookingSettings));
  const dian = await prisma.dianConfig.findFirst();
  const [products, withPhoto, tables, staff, sessions, tracked, suppliers, expenseCats, customers, coupons] = await Promise.all([
    prisma.product.count({ where: { isActive: true } }),
    prisma.product.count({ where: { isActive: true, imageUrl: { not: null } } }),
    prisma.table.count(),
    prisma.user.count({ where: { isActive: true, role: { not: 'ADMIN' } } }),
    prisma.cashSession.count(),
    prisma.productVariant.count({ where: { isActive: true, trackInventory: true } }),
    prisma.supplier.count(),
    prisma.expenseCategory.count(),
    prisma.customer.count({ where: { isDefault: false, isActive: true } }),
    prisma.coupon.count(),
  ]);
  // Novedades 3.2: encendidas en Funciones (y dentro del plan) y con lo mínimo hecho
  const on = (key: Parameters<typeof featureAllowed>[0]) => featureAllowed(key).catch(() => false);
  const [tableOrdering, kiosk, customerDisplay, attendance, survey, door, priceRules, directory] = await Promise.all([
    on('table_ordering'), on('kiosk'), on('customer_display'), on('attendance'), on('survey'), on('door'), on('price_rules'), on('directory'),
  ]);
  const [rules, kiosks, customerScreens, phones, covers, doorUsers] = await Promise.all([
    prisma.priceRule.count(),
    prisma.display.count({ where: { type: 'KIOSK' } }),
    prisma.display.count({ where: { type: 'CUSTOMER' } }),
    prisma.relayDevice.count({ where: { revokedAt: null } }),
    prisma.product.count({ where: { isActive: true, isCover: true } }),
    prisma.user.count({ where: { isActive: true, role: 'DOOR' } }),
  ]);
  const print = normalizePrintSettings(parse(b?.printSettings));
  return {
    v32_mesa_activar: tableOrdering,
    v32_celulares_vincular: phones > 0,
    v32_happy_crear: priceRules && rules > 0,
    v32_resena_enlace: !!page.social.googleReviewUrl,
    v32_resena_recibo: print.reviewQr,
    v32_resena_encuesta: survey,
    v32_cerca_activar: page.loyalty.cardMode === 'wallet' && page.loyalty.nearby.enabled,
    v32_pantalla_cliente_conectar: customerDisplay && customerScreens > 0,
    v32_kiosco_conectar: kiosk && kiosks > 0,
    v32_asistencia_activar: attendance,
    v32_puerta_aforo: door && !!b?.maxCapacity,
    v32_puerta_cover: door && covers > 0,
    v32_puerta_portero: door && doorUsers > 0,
    v32_directorio_activar: directory,
    negocio_datos: !!b?.businessName?.trim() && !!b?.address?.trim() && !!b?.phone?.trim(),
    negocio_logo: !!b?.logoUrl,
    negocio_cuenta: !!b?.cloudTenantCode,
    carta_productos: products > 0,
    carta_fotos: withPhoto > 0,
    salon_mesas: tables > 0,
    impresion_impresora: !!b?.printSettings,
    equipo_usuarios: staff > 0,
    equipo_funciones: !!b?.rolePermissions,
    caja_primera: sessions > 0,
    inventario_control: tracked > 0,
    proveedores_crear: suppliers > 0,
    proveedores_gastos: expenseCats > 0,
    clientes_registro: customers > 0,
    cupones_crear: coupons > 0,
    // La facturación la activa Lantify (casa de software): el paso queda hecho cuando la nube la confirma
    dian_proveedor: !!dian && dian.billingProvider === 'LANTIFY' && dian.isAssociated,
    pagina_publicar: !!b?.bookingPublishedAt,
    reservas_activar: booking.enabled && booking.online,
    pedidos_activar: page.sections.orders,
    fidelidad_reglas: page.loyalty.enabled,
    fidelidad_registro: page.sections.signup,
    fidelidad_juego: page.sections.games && page.games.prizes.length > 0,
    ia_autorizar: !!b?.aiConsentAt,
  };
};

export const createSetupGuideRoutes = () => {
  const router = Router();

  router.get('/setup-guide', async (_req, res, next) => {
    try {
      const b = await prisma.businessSettings.findUnique({ where: { id: SETTINGS_ID } });
      res.json({
        state: normalizeGuide(parse(b?.setupGuide)),
        checks: await autoChecks(),
        // null = sin negocio vinculado: todo disponible (como en la pantalla)
        features: await currentFeatures(),
        usesTables: b?.usesTables ?? true,
      });
    } catch (err) {
      next(err);
    }
  });

  router.put('/setup-guide', async (req, res, next) => {
    try {
      const state = normalizeGuide(req.body);
      await prisma.businessSettings.upsert({
        where: { id: SETTINGS_ID },
        update: { setupGuide: JSON.stringify(state) },
        create: { id: SETTINGS_ID, setupGuide: JSON.stringify(state) },
      });
      res.json({ state, checks: await autoChecks() });
    } catch (err) {
      next(err);
    }
  });

  return router;
};
