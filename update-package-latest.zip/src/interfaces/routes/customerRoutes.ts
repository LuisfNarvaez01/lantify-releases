// ============================================
// INTERFACES - Customer Routes
// ============================================

import { Router } from 'express';
import { CustomerController } from '../controllers/CustomerController';

export const createCustomerRoutes = (controller: CustomerController) => {
  const router = Router();

  router.get('/',                    controller.getAll.bind(controller));
  router.get('/search',              controller.search.bind(controller));
  router.get('/default',             controller.getDefault.bind(controller));
  router.get('/birthdays',           controller.getBirthdays.bind(controller));
  router.get('/:id',                 controller.getById.bind(controller));
  router.get('/:id/recommended',     controller.getRecommended.bind(controller));
  router.post('/',                   controller.create.bind(controller));
  router.put('/:id',                 controller.update.bind(controller));
  router.delete('/:id',              controller.deactivate.bind(controller));
  router.post('/:id/stamps',         controller.adjustStamps.bind(controller));

  return router;
};
