// ============================================
// INTERFACES - Gastos y lectura de facturas por foto
// ============================================
//   GET   /api/expenses?from=&to=&sessionId= → gastos con resumen por categoría y medio
//   POST  /api/expenses               → registrar (a mano o revisado tras la foto)
//   POST  /api/expenses/scan          → foto de la factura → lectura (o registro automático)
//   PATCH /api/expenses/:id/cancel    → anular con motivo
//   GET   /api/expenses/:id/image     → la foto guardada
//   GET   /api/ai/settings            → consentimiento de IA y modo automático
//   PUT   /api/ai/settings            → ADMIN: aceptar/retirar el consentimiento, modo automático

import { Router, Response } from 'express';
import { ExpenseUseCases, ExpenseError, InvoiceReading } from '../../application/usecases/ExpenseUseCases';
import { CloudAuthService } from '../../application/usecases/CloudAuthService';
import { AuthRequest } from '../../shared/authMiddleware';
import { cloudConfig } from '../../shared/cloud/config';
import { prisma } from '../../infrastructure/database/prisma';

const SETTINGS_ID = 'default';

const fail = (res: Response, err: unknown) => {
  if (err instanceof ExpenseError) return res.status(err.status).json({ code: err.code, error: err.message });
  console.error('[gastos]', err);
  return res.status(500).json({ code: 'SERVER_ERROR', error: 'Error interno del servidor' });
};

const parseDate = (v: unknown) => {
  if (typeof v !== 'string' || !v) return undefined;
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? undefined : d;
};

const actorOf = (req: AuthRequest) => req.user?.name || req.user?.username;

const aiSettings = async () => {
  const s = await prisma.businessSettings.findUnique({ where: { id: SETTINGS_ID } });
  return {
    consent: !!s?.aiConsentAt,
    consentAt: s?.aiConsentAt ?? null,
    consentBy: s?.aiConsentBy ?? null,
    expenseAutoRegister: !!s?.expenseAutoRegister,
  };
};

/** Pide a Lantify Copilot la lectura de la factura, firmada con la licencia del usuario */
const readInvoice = async (license: string, image: string, mimeType: string, categories: string[], lang: string) => {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 35000);
  try {
    const res = await fetch(`${cloudConfig().aiUrl}/ai/invoice`, {
      method: 'POST',
      signal: controller.signal,
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${license}` },
      body: JSON.stringify({ image, mimeType, categories, lang }),
    });
    const body: any = await res.json().catch(() => ({}));
    return { status: res.status, body };
  } catch {
    return { status: 503, body: { code: controller.signal.aborted ? 'AI_TIMEOUT' : 'AI_UNAVAILABLE' } };
  } finally {
    clearTimeout(timer);
  }
};

export const createExpenseRoutes = (cloud: CloudAuthService, expenses = new ExpenseUseCases()) => {
  const router = Router();

  router.get('/expenses', async (req, res) => {
    try {
      const sessionId = typeof req.query.sessionId === 'string' && req.query.sessionId ? req.query.sessionId : undefined;
      res.json(await expenses.list({ from: parseDate(req.query.from), to: parseDate(req.query.to), sessionId }));
    } catch (err) {
      fail(res, err);
    }
  });

  router.post('/expenses', async (req: AuthRequest, res) => {
    try {
      const body = req.body || {};
      res.status(201).json(await expenses.create({ ...body, captureMode: body.captureMode === 'AI_REVIEWED' ? 'AI_REVIEWED' : 'MANUAL' }, actorOf(req)));
    } catch (err) {
      fail(res, err);
    }
  });

  router.post('/expenses/scan', async (req: AuthRequest, res) => {
    try {
      const settings = await aiSettings();
      if (!settings.consent) {
        return res.status(403).json({ code: 'AI_CONSENT_REQUIRED', error: 'El administrador debe autorizar el uso de la IA con datos del negocio.' });
      }
      const image = typeof req.body?.image === 'string' ? req.body.image : '';
      if (!image) return res.status(400).json({ code: 'AI_BAD_IMAGE', error: 'No llegó la foto.' });
      const license = await cloud.aiLicense(req.user!.id!);
      if (!license) return res.status(503).json({ code: 'AI_NOT_CONFIGURED', error: 'Inicia sesión con conexión a internet para leer facturas.' });

      const ai = await readInvoice(license, image, req.body?.mimeType || 'image/jpeg', await expenses.categoryNames(), req.body?.lang === 'en' ? 'en' : 'es');
      if (ai.status !== 200) return res.status(ai.status).json({ code: ai.body?.code || 'AI_UNAVAILABLE', ...ai.body });
      const reading = ai.body as InvoiceReading;
      if (!reading.isInvoice) return res.status(422).json({ code: 'AI_NOT_AN_INVOICE', error: 'La foto no parece una factura o recibo.' });

      const categoryId = await expenses.matchCategory(reading.category);
      const paymentSource = ExpenseUseCases.paymentSourceFor(reading.paymentMethod);

      // Modo automático: solo si la lectura es confiable y se puede pagar como dice la factura
      if (settings.expenseAutoRegister && expenses.canAutoRegister(reading)) {
        try {
          const expense = await expenses.create({
            amount: reading.total!,
            motive: reading.supplierName || reading.invoiceNumber || undefined,
            supplierName: reading.supplierName,
            supplierNit: reading.supplierNit,
            invoiceNumber: reading.invoiceNumber,
            invoiceDate: reading.invoiceDate,
            subtotal: reading.subtotal,
            taxAmount: reading.tax,
            categoryId,
            paymentSource,
            image,
            captureMode: 'AI_AUTO',
            aiConfidence: reading.confidence,
            items: reading.items,
          }, actorOf(req));
          return res.status(201).json({ mode: 'auto', reading, categoryId, paymentSource, expense });
        } catch (err) {
          // Sin caja abierta para pagar del cajón: se pasa a revisión en lugar de fallar
          if (!(err instanceof ExpenseError) || err.code !== 'EXPENSE_NO_OPEN_SESSION') throw err;
        }
      }
      res.json({ mode: 'review', reading, categoryId, paymentSource });
    } catch (err) {
      fail(res, err);
    }
  });

  router.patch('/expenses/:id/cancel', async (req, res) => {
    try {
      res.json(await expenses.cancel(req.params.id, String(req.body?.reason || '')));
    } catch (err) {
      fail(res, err);
    }
  });

  router.get('/expenses/:id/image', async (req, res) => {
    try {
      const file = await expenses.imagePath(req.params.id);
      if (!file) return res.status(404).json({ code: 'NOT_FOUND', error: 'Este gasto no tiene foto.' });
      res.setHeader('Cache-Control', 'private, max-age=3600');
      res.sendFile(file);
    } catch (err) {
      fail(res, err);
    }
  });

  // ── Consentimiento de IA (lo decide el ADMIN del negocio) ──
  router.get('/ai/settings', async (_req, res) => {
    try {
      res.json(await aiSettings());
    } catch (err) {
      fail(res, err);
    }
  });

  router.put('/ai/settings', async (req: AuthRequest, res) => {
    try {
      const data: Record<string, unknown> = {};
      if (typeof req.body?.consent === 'boolean') {
        data.aiConsentAt = req.body.consent ? new Date() : null;
        data.aiConsentBy = req.body.consent ? actorOf(req) || null : null;
        // Sin consentimiento no hay modo automático
        if (!req.body.consent) data.expenseAutoRegister = false;
      }
      if (typeof req.body?.expenseAutoRegister === 'boolean') {
        const current = await aiSettings();
        const consent = typeof req.body.consent === 'boolean' ? req.body.consent : current.consent;
        data.expenseAutoRegister = consent && req.body.expenseAutoRegister;
      }
      await prisma.businessSettings.upsert({ where: { id: SETTINGS_ID }, create: { id: SETTINGS_ID, ...data }, update: data });
      res.json(await aiSettings());
    } catch (err) {
      fail(res, err);
    }
  });

  return router;
};
