// ============================================
// INTERFACES - Fase 4 · Grupo E: gestión
// ============================================
//   GET  /api/accounting/month?month=AAAA-MM → ventas cobradas, comprobantes por día, arqueos, gastos y facturas
//                                               (la pantalla arma el CSV, Siigo, Alegra y el informe del contador)
//   GET  /api/menu-transfer/export           → la carta de esta sede en JSON
//   POST /api/menu-transfer/preview          → qué crearía y qué cambiaría importar ese JSON
//   POST /api/menu-transfer/import           → lo aplica (idempotente por nombre)
// Las cuentas PUC se guardan con PUT /api/features { accounting }.
// Quién puede llamar cada una lo decide src/shared/security/accessPolicy.ts (solo ADMIN).
// Nada de esto toca una venta ni el inventario.

import { Router, Response } from 'express';
import { AuthRequest } from '../../shared/authMiddleware';
import { featureAllowed } from '../../shared/featureStore';
import type { FeatureKey } from '../../domain/v3/features';
import { AccountingError, AccountingExportUseCases } from '../../application/usecases/AccountingExportUseCases';
import { MenuTransferError, MenuTransferUseCases } from '../../application/usecases/MenuTransferUseCases';

const fail = (res: Response, error: any) => {
  if (error instanceof AccountingError || error instanceof MenuTransferError) return res.status(error.statusCode).json({ error: error.message, code: error.code });
  console.error('[gestión]', error);
  return res.status(500).json({ error: 'No se pudo completar la operación.', code: 'LOCAL_ERROR' });
};

type Handler = (req: AuthRequest) => Promise<unknown>;
const withFeature = (feature: FeatureKey, fn: Handler) => async (req: AuthRequest, res: Response) => {
  try {
    if (!(await featureAllowed(feature))) return res.status(403).json({ error: 'Esta función está apagada en el negocio.', code: 'FEATURE_OFF', feature });
    res.json(await fn(req));
  } catch (error) {
    fail(res, error);
  }
};

export const createGestionRoutes = (accounting = new AccountingExportUseCases(), menu = new MenuTransferUseCases()) => {
  const router = Router();
  router.get('/accounting/month', withFeature('accounting_export', (req) => accounting.month(req.query.month)));
  router.get('/menu-transfer/export', withFeature('multi_branch', () => menu.exportMenu()));
  router.post('/menu-transfer/preview', withFeature('multi_branch', (req) => menu.preview(req.body)));
  router.post('/menu-transfer/import', withFeature('multi_branch', (req) => menu.apply(req.body)));
  return router;
};
