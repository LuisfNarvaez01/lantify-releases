// ============================================
// INTERFACES - Table Routes
// ============================================

import { Router } from 'express';
import { TableController } from '../controllers';

export const createTableRoutes = (controller: TableController) => {
  const router = Router();

  router.post('/', controller.createTable.bind(controller));
  router.get('/', controller.getAllTables.bind(controller));
  router.get('/available', controller.getAvailableTables.bind(controller));
  router.get('/status/:status', controller.getTablesByStatus.bind(controller));
  router.get('/:id', controller.getTableById.bind(controller));
  router.put('/:id', controller.updateTable.bind(controller));
  
  // Estados de mesa
  router.patch('/:id/occupy', controller.occupyTable.bind(controller));    // Libre → Ocupado (hacer pedido)
  router.patch('/:id/order', controller.orderTable.bind(controller));     // Ocupado → Ordenado
  router.patch('/:id/pending', controller.setPending.bind(controller));    // Ocupado → Pendiente (cobrar)
  router.patch('/:id/close', controller.closeTable.bind(controller));      // Pendiente → Libre (cerrar mesa)
  router.patch('/:id/release', controller.releaseTable.bind(controller));   // Liberar mesa
  
  router.delete('/:id', controller.deleteTable.bind(controller));

  return router;
};