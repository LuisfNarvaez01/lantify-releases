// ============================================
// INTERFACES - Reservas
// ============================================
//   GET   /api/reservations?date=YYYY-MM-DD      → agenda del día (hora local del negocio)
//   GET   /api/reservations/summary               → pendientes por confirmar / choques / próximas
//   GET   /api/reservations/availability?date&party → horas con mesa libre para el grupo
//   POST  /api/reservations                       → reserva manual (WhatsApp, teléfono, en persona)
//   PATCH /api/reservations/:id                   → confirmar, llegó, no llegó, cancelar, reprogramar
//   GET   /api/reservations/settings              → reglas, mesas reservables y dirección pública
//   PUT   /api/reservations/settings              → ADMIN: guardar (y publicar en la nube si hay reservas en línea)

import { Router, Response } from 'express';
import { ReservationUseCases, BookingError } from '../../application/usecases/ReservationUseCases';
import { AuthRequest } from '../../shared/authMiddleware';

const fail = (res: Response, err: unknown) => {
  if (err instanceof BookingError) return res.status(err.status).json({ code: err.code, error: err.message, ...err.extra });
  console.error('[reservas]', err);
  return res.status(500).json({ code: 'SERVER_ERROR', error: 'Error interno del servidor' });
};

const actorOf = (req: AuthRequest) => req.user?.name || req.user?.username || 'POS';

export interface ReservationRouteHooks {
  /** Tras guardar la configuración (publicar en Lantify Cloud) */
  afterSettingsSaved?: (req: AuthRequest) => Promise<Record<string, unknown> | void>;
  /** Tras un cambio en una reserva (subirlo a la nube cuanto antes) */
  afterChange?: () => void;
}

export const createReservationRoutes = (reservations = new ReservationUseCases(), hooks: ReservationRouteHooks = {}) => {
  const router = Router();

  router.get('/reservations/settings', async (_req, res) => {
    try {
      res.json(await reservations.settings());
    } catch (err) {
      fail(res, err);
    }
  });

  router.put('/reservations/settings', async (req: AuthRequest, res) => {
    try {
      const saved = await reservations.updateSettings(req.body || {}, actorOf(req));
      const publish = hooks.afterSettingsSaved ? await hooks.afterSettingsSaved(req) : undefined;
      res.json({ ...saved, ...(publish ? { publish } : {}) });
    } catch (err) {
      fail(res, err);
    }
  });

  router.get('/reservations/summary', async (_req, res) => {
    try {
      res.json(await reservations.summary());
    } catch (err) {
      fail(res, err);
    }
  });

  router.get('/reservations/availability', async (req, res) => {
    try {
      res.json(await reservations.availability(String(req.query.date || ''), Number(req.query.party) || 2));
    } catch (err) {
      fail(res, err);
    }
  });

  router.get('/reservations', async (req, res) => {
    try {
      const q = (k: string) => (typeof req.query[k] === 'string' ? (req.query[k] as string) : undefined);
      res.json(await reservations.list({ date: q('date'), from: q('from'), to: q('to') }));
    } catch (err) {
      fail(res, err);
    }
  });

  router.post('/reservations', async (req: AuthRequest, res) => {
    try {
      res.status(201).json(await reservations.create(req.body || {}, actorOf(req)));
      hooks.afterChange?.();
    } catch (err) {
      fail(res, err);
    }
  });

  router.patch('/reservations/:id', async (req: AuthRequest, res) => {
    try {
      res.json(await reservations.update(req.params.id, req.body || {}, actorOf(req)));
      hooks.afterChange?.();
    } catch (err) {
      fail(res, err);
    }
  });

  return router;
};
