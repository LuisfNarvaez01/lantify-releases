// ============================================
// INTERFACES - Mi página (ADMIN)
// ============================================
//   GET  /api/page            → configuración, dirección, estado y actividad (registros y premios)
//   PUT  /api/page            → guardar secciones, perfil, juego, responsable de datos y publicar
//   POST /api/page/publish    → publicar ya (p. ej. tras cambiar precios)
//   GET  /api/page/birthdays  → cumpleaños de la semana con lo que más pide cada cliente

import { prisma } from '../../infrastructure/database/prisma';
import { legalMissing, normalizeLegal, normalizeProfile } from '../../domain/businessPage';
import { Router, Response } from 'express';
import { PageUseCases } from '../../application/usecases/PageUseCases';
import { BookingError } from '../../application/usecases/ReservationUseCases';
import { AuthRequest } from '../../shared/authMiddleware';

const fail = (res: Response, err: unknown) => {
  if (err instanceof BookingError) return res.status(err.status).json({ code: err.code, error: err.message, ...err.extra });
  console.error('[mi-pagina]', err);
  return res.status(500).json({ code: 'SERVER_ERROR', error: 'Error interno del servidor' });
};

export const createPageRoutes = (publish: (req: AuthRequest) => Promise<Record<string, unknown>>, pages = new PageUseCases()) => {
  const router = Router();
  const actorOf = (req: AuthRequest) => req.user?.name || req.user?.username || 'ADMIN';

  router.get('/page', async (_req, res) => {
    try {
      res.json({ ...(await pages.config()), activity: await pages.activity() });
    } catch (err) {
      fail(res, err);
    }
  });

  router.put('/page', async (req: AuthRequest, res) => {
    try {
      // Primera publicación: la página no sale sin términos y política de datos completos.
      // Un negocio ya publicado sigue publicando (solo ve el aviso en Mi página).
      const row = await prisma.businessSettings.findUnique({ where: { id: 'default' }, select: { bookingPublishedAt: true } });
      const missing = legalMissing(normalizeLegal(req.body?.legal), normalizeProfile(req.body?.profile));
      if (!row?.bookingPublishedAt && missing.length) {
        return res.status(400).json({ error: 'Completa los datos legales del negocio para publicar la página.', code: 'PAGE_LEGAL_REQUIRED', missing });
      }
      await pages.save(req.body || {}, actorOf(req));
      const result = await publish(req);
      res.json({ ...(await pages.config()), activity: await pages.activity(), publish: result });
    } catch (err) {
      fail(res, err);
    }
  });

  router.post('/page/publish', async (req: AuthRequest, res) => {
    try {
      res.json({ publish: await publish(req), ...(await pages.config()) });
    } catch (err) {
      fail(res, err);
    }
  });

  router.get('/page/birthdays', async (req, res) => {
    try {
      res.json(await pages.birthdays(Math.min(31, Math.max(0, Number(req.query.days) || 7))));
    } catch (err) {
      fail(res, err);
    }
  });

  return router;
};
