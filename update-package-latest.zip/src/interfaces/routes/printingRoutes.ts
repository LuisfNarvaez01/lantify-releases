// ============================================
// INTERFACES - Impresión directa de tickets
// ============================================
//   GET  /api/printing/settings   → todos: cómo imprimir (papel, impresoras, opciones)
//   PUT  /api/printing/settings   → ADMIN
//   GET  /api/printing/printers   → ADMIN: impresoras instaladas en este equipo
//   POST /api/printing/print      → todos: imprime un ticket en la impresora de su función
//   POST /api/printing/test       → ADMIN: prueba una impresora antes de guardarla

import { Router, Response } from 'express';
import { prisma } from '../../infrastructure/database/prisma';
import { AuthRequest } from '../../shared/authMiddleware';
import { AuditLogger } from '../../infrastructure/services/AuditLogger';
import { DEFAULT_PRINT_SETTINGS, normalizePrintSettings, normalizeTarget, PrintSettings } from '../../domain/printSettings';
import { isTicketDoc } from '../../domain/ticketDoc';
import { toEscPos } from '../../infrastructure/printing/escpos';
import { listPrinters, sendToPrinter, PrintError } from '../../infrastructure/printing/printers';

const SETTINGS_ID = 'default';

export const loadPrintSettings = async (): Promise<PrintSettings> => {
  const row = await prisma.businessSettings.findUnique({ where: { id: SETTINGS_ID }, select: { printSettings: true, ticketFooter: true } });
  if (!row?.printSettings) return { ...DEFAULT_PRINT_SETTINGS, footer: row?.ticketFooter || '' };
  try {
    return normalizePrintSettings(JSON.parse(row.printSettings));
  } catch {
    return { ...DEFAULT_PRINT_SETTINGS, footer: row.ticketFooter || '' };
  }
};

const sendError = (res: Response, err: any) => {
  if (err instanceof PrintError) {
    const status = err.code === 'PRINTERS_UNAVAILABLE' || err.code === 'PRINT_UNSUPPORTED' ? 503 : 502;
    return res.status(status).json({ error: err.message, code: err.code });
  }
  console.error('[impresión]', err);
  return res.status(500).json({ error: 'No se pudo imprimir.', code: 'PRINT_ERROR' });
};

export const createPrintingRoutes = () => {
  const router = Router();

  router.get('/printing/settings', async (_req, res) => {
    try {
      const row = await prisma.businessSettings.findUnique({ where: { id: SETTINGS_ID }, select: { printSettings: true } });
      // configured: false → nadie la ha guardado; cada equipo conserva sus ajustes anteriores
      res.json({ ...(await loadPrintSettings()), configured: !!row?.printSettings });
    } catch (err) {
      sendError(res, err);
    }
  });

  router.put('/printing/settings', async (req: AuthRequest, res) => {
    try {
      const settings = normalizePrintSettings(req.body);
      await prisma.businessSettings.upsert({
        where: { id: SETTINGS_ID },
        create: { id: SETTINGS_ID, printSettings: JSON.stringify(settings), ticketFooter: settings.footer || null },
        // El pie del ticket también lo usa la factura electrónica
        update: { printSettings: JSON.stringify(settings), ticketFooter: settings.footer || null },
      });
      AuditLogger.log({
        action: 'PRINT_SETTINGS_UPDATED', entityType: 'SETTINGS', entityId: SETTINGS_ID,
        details: { by: req.user?.username, mode: settings.mode, receipt: settings.receipt?.type ?? null, kitchen: settings.kitchen?.type ?? null },
      });
      res.json(settings);
    } catch (err) {
      sendError(res, err);
    }
  });

  router.get('/printing/printers', async (_req, res) => {
    try {
      res.json({ supported: process.platform === 'win32', printers: await listPrinters() });
    } catch (err) {
      sendError(res, err);
    }
  });

  router.post('/printing/print', async (req: AuthRequest, res) => {
    try {
      const role = req.body?.role === 'kitchen' ? 'kitchen' : 'receipt';
      const doc = req.body?.doc;
      if (!isTicketDoc(doc)) return res.status(400).json({ error: 'Ticket inválido.', code: 'PRINT_INVALID' });
      const settings = await loadPrintSettings();
      const target = role === 'kitchen' ? settings.kitchen || settings.receipt : settings.receipt;
      if (settings.mode !== 'direct' || !target) {
        return res.status(409).json({ error: 'La impresión directa no está configurada.', code: 'PRINT_NOT_CONFIGURED' });
      }
      const copies = role === 'kitchen' ? settings.kitchenCopies : Math.max(1, Math.min(3, Number(req.body?.copies) || settings.receiptCopies));
      // El cajón solo se abre desde la caja
      await sendToPrinter(target, toEscPos({ ...doc, drawer: role === 'receipt' && settings.openDrawer && !!doc.drawer }, settings, copies), doc.title);
      res.json({ ok: true });
    } catch (err) {
      sendError(res, err);
    }
  });

  router.post('/printing/test', async (req: AuthRequest, res) => {
    try {
      const target = normalizeTarget(req.body?.target);
      const doc = req.body?.doc;
      if (!target) return res.status(400).json({ error: 'Elige una impresora.', code: 'PRINT_NO_TARGET' });
      if (!isTicketDoc(doc)) return res.status(400).json({ error: 'Ticket inválido.', code: 'PRINT_INVALID' });
      const settings = normalizePrintSettings({ ...(await loadPrintSettings()), ...(req.body?.settings || {}) });
      await sendToPrinter(target, toEscPos({ ...doc, drawer: !!req.body?.drawer }, settings), doc.title);
      res.json({ ok: true });
    } catch (err) {
      sendError(res, err);
    }
  });

  return router;
};
