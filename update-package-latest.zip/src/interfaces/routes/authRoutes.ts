// ============================================
// INTERFACES - Auth Routes
// ============================================
// El control de acceso lo aplica la política global (shared/security/accessPolicy.ts).
// Aquí solo se agregan los límites de intentos y la validación de entrada.

import { Router, Response } from 'express';
import { z } from 'zod';
import { AuthUseCases, AuthError } from '../../application/usecases/AuthUseCases';
import { AuthRequest } from '../../shared/authMiddleware';
import { createLoginLimiter, createLoginLongLimiter } from '../../shared/security/rateLimits';

const loginSchema = z.object({
  username: z.string().min(1).max(64),
  password: z.string().min(1).max(256),
});

const setupSchema = z.object({
  name: z.string().min(1).max(120),
  username: z.string().min(3).max(32),
  password: z.string().min(1).max(256),
});

const registerSchema = setupSchema.extend({
  role: z.enum(['ADMIN', 'CASHIER', 'WAITER']).default('CASHIER'),
});

const updateUserSchema = z.object({
  name: z.string().min(1).max(120).optional(),
  role: z.enum(['ADMIN', 'CASHIER', 'WAITER']).optional(),
  password: z.string().max(256).optional(),
});

const changePasswordSchema = z.object({
  currentPassword: z.string().min(1).max(256),
  newPassword: z.string().min(1).max(256),
});

const sendError = (res: Response, error: any, fallbackStatus = 400) => {
  if (error instanceof AuthError) {
    return res.status(error.statusCode).json({ error: error.message, code: error.code, ...(error.details || {}) });
  }
  if (error instanceof z.ZodError) {
    return res.status(400).json({ error: 'Datos incompletos o inválidos.', code: 'VALIDATION_ERROR' });
  }
  console.error('[auth]', error);
  return res.status(fallbackStatus).json({ error: 'No se pudo completar la operación.', code: 'AUTH_ERROR' });
};

export const createAuthRoutes = (authUseCases: AuthUseCases) => {
  const router = Router();
  const loginLimiter = createLoginLimiter();
  const loginLongLimiter = createLoginLongLimiter();

  // Login (público, con límite de intentos)
  router.post('/login', loginLongLimiter, loginLimiter, async (req, res) => {
    try {
      const { username, password } = loginSchema.parse(req.body);
      res.json(await authUseCases.login(username, password));
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(401).json({ error: 'Usuario o contraseña incorrectos', code: 'AUTH_INVALID_CREDENTIALS' });
      }
      sendError(res, error, 401);
    }
  });

  // Primer arranque (público, solo funciona mientras no exista ningún usuario)
  router.get('/setup-status', async (_req, res) => {
    try {
      res.json(await authUseCases.getSetupStatus());
    } catch (error) {
      sendError(res, error, 500);
    }
  });

  router.post('/setup', loginLimiter, async (req, res) => {
    try {
      res.status(201).json(await authUseCases.setupFirstAdmin(setupSchema.parse(req.body)));
    } catch (error) {
      sendError(res, error);
    }
  });

  // Crear usuario (solo ADMIN, según la política)
  router.post('/register', async (req: AuthRequest, res) => {
    try {
      const { username, password, name, role } = registerSchema.parse(req.body);
      res.status(201).json(await authUseCases.register(username, password, name, role, req.user?.id));
    } catch (error) {
      sendError(res, error);
    }
  });

  // Listar usuarios (solo ADMIN)
  router.get('/users', async (req: AuthRequest, res) => {
    try {
      const users = await authUseCases.getAllUsers(req.user?.id);
      res.json(users.map(u => ({ id: u.id, username: u.username, name: u.name, role: u.role, isActive: u.isActive, lastLoginAt: u.lastLoginAt })));
    } catch (error) {
      sendError(res, error, 500);
    }
  });

  // Actualizar usuario (solo ADMIN)
  router.put('/users/:id', async (req: AuthRequest, res) => {
    try {
      res.json(await authUseCases.updateUser(req.params.id, updateUserSchema.parse(req.body), req.user?.id));
    } catch (error) {
      sendError(res, error);
    }
  });

  // Desactivar usuario (solo ADMIN)
  router.delete('/users/:id', async (req: AuthRequest, res) => {
    try {
      res.json(await authUseCases.deleteUser(req.params.id, req.user?.id));
    } catch (error) {
      sendError(res, error);
    }
  });

  // Verificar sesión (cualquier usuario autenticado)
  router.get('/verify', async (req: AuthRequest, res) => {
    res.json({ valid: true, user: req.user, mustChangePassword: !!req.mustChangePassword });
  });

  // Cambiar la propia contraseña
  router.post('/change-password', loginLimiter, async (req: AuthRequest, res) => {
    try {
      const { currentPassword, newPassword } = changePasswordSchema.parse(req.body);
      res.json(await authUseCases.changeOwnPassword(req.user!.id!, currentPassword, newPassword));
    } catch (error) {
      sendError(res, error);
    }
  });

  // Verificar clave de administrador para acciones protegidas (anulaciones)
  router.post('/verify-admin', loginLongLimiter, loginLimiter, async (req, res) => {
    try {
      res.json(await authUseCases.verifyAdminPassword(req.body?.password));
    } catch (error) {
      sendError(res, error, 401);
    }
  });

  return router;
};
