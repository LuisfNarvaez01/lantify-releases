// ============================================
// INTERFACES - Imágenes (fotos de productos, logo, portada)
// ============================================
//   POST /api/media              → ADMIN: sube una imagen ya recortada (data URL)
//   GET  /api/media/:name        → la imagen (pública: la usan <img> de la caja y las tablets)

import { Router } from 'express';
import { mediaStore, MediaError } from '../../infrastructure/services/MediaStore';

export const createMediaRoutes = () => {
  const router = Router();

  router.post('/media', (req, res) => {
    try {
      const saved = mediaStore.save(req.body?.image);
      res.status(201).json({ url: saved.url, bytes: saved.bytes });
    } catch (error: any) {
      if (error instanceof MediaError) return res.status(error.statusCode).json({ error: error.message, code: error.code });
      console.error('[media]', error);
      res.status(500).json({ error: 'No se pudo guardar la imagen.', code: 'MEDIA_ERROR' });
    }
  });

  router.get('/media/:name', (req, res) => {
    const found = mediaStore.file(req.params.name);
    if (!found) return res.status(404).end();
    // El nombre es la huella del contenido: nunca cambia
    res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
    res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
    res.type(found.mime).sendFile(found.file);
  });

  return router;
};
