// ============================================
// INTERFACES - Propinas
// ============================================
//   GET /api/tips?from=&to=        → ADMIN: reporte (resumen, por mes, por turno, por mesero)
//   GET /api/tips/session/:id      → caja: propinas del turno para el arqueo

import { Router } from 'express';
import { TipsUseCases } from '../../application/usecases/TipsUseCases';

const parseDate = (v: unknown) => {
  if (typeof v !== 'string' || !v) return undefined;
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? undefined : d;
};

export const createTipsRoutes = (tips = new TipsUseCases()) => {
  const router = Router();

  router.get('/', async (req, res, next) => {
    try {
      res.json(await tips.report({ from: parseDate(req.query.from), to: parseDate(req.query.to) }));
    } catch (err) {
      next(err);
    }
  });

  router.get('/session/:id', async (req, res, next) => {
    try {
      res.json(await tips.forSession(req.params.id));
    } catch (err) {
      next(err);
    }
  });

  return router;
};
