// ============================================
// INTERFACES - Avisos para las pantallas del POS
// ============================================
//   GET /api/notifications?since=N[&birthdays=1] → todos: lo nuevo desde N
//   (y, si se pide, quién cumple años hoy; la pantalla lo pide pocas veces al día)

import { Router } from 'express';
import { prisma } from '../../infrastructure/database/prisma';
import { notificationsSince } from '../../shared/notifications';

/** Clientes que cumplen años hoy (la fecha se guarda a medianoche UTC) */
const birthdaysToday = async () => {
  const now = new Date();
  const rows = await prisma.customer.findMany({
    where: { isActive: true, isDefault: false, birthDate: { not: null } },
    select: { id: true, name: true, phone: true, birthDate: true },
  });
  return rows
    .filter((c) => c.birthDate!.getUTCMonth() === now.getMonth() && c.birthDate!.getUTCDate() === now.getDate())
    .map(({ id, name, phone }) => ({ id, name, phone }));
};

export const createNotificationRoutes = () => {
  const router = Router();

  router.get('/notifications', async (req, res, next) => {
    try {
      const raw = Number(req.query.since);
      const since = req.query.since !== undefined && Number.isFinite(raw) ? Math.max(0, Math.floor(raw)) : null;
      const birthdays = req.query.birthdays === '1' ? await birthdaysToday() : undefined;
      res.json({ ...notificationsSince(since), ...(birthdays ? { birthdays } : {}) });
    } catch (err) {
      next(err);
    }
  });

  return router;
};
