// ============================================
// INTERFACES - Fase 4 · Clientes en la mesa y en la puerta
// ============================================
// Pedido desde la mesa:
//   GET  /api/table-orders                   → pedidos de mesa esperando al mesero
//   POST /api/table-orders/:id/accept        → ronda nueva de la mesa (a cocina)
//   POST /api/table-orders/:id/reject        → con motivo opcional ({ reason }); el cliente lo ve
//   GET  /api/table-orders/qr                → ADMIN: QR de todas las mesas para imprimir
//   POST /api/table-orders/qr/:tableId/rotate → ADMIN: código nuevo para una mesa
// Puerta:
//   GET  /api/door                           → ocupación de la noche contra el aforo
//   POST /api/door/events                    → +1 / −1 ({ kind: IN|OUT, wristband? })
//   GET  /api/door/report?date=YYYY-MM-DD    → ADMIN: informe de la noche
// Quién puede llamar cada una lo decide src/shared/security/accessPolicy.ts.

import { Router, Response } from 'express';
import { AuthRequest } from '../../shared/authMiddleware';
import { featureAllowed } from '../../shared/featureStore';
import { BookingError } from '../../application/usecases/ReservationUseCases';
import { TableOrderUseCases, type TableActor } from '../../application/usecases/TableOrderUseCases';
import { DoorUseCases } from '../../application/usecases/DoorUseCases';
import { DoorError } from '../../domain/door';
import type { FeatureKey } from '../../domain/v3/features';

const actorOf = (req: AuthRequest): TableActor => ({ userId: req.user?.id || req.user?.userId, name: req.user?.name || req.user?.username, role: req.user?.role });

const fail = (res: Response, error: any) => {
  if (error instanceof BookingError) return res.status(error.status).json({ error: error.message, code: error.code, ...error.extra });
  if (error instanceof DoorError) return res.status(error.statusCode).json({ error: error.message, code: error.code });
  console.error('[mesa-puerta]', error);
  return res.status(500).json({ error: 'No se pudo completar la operación.', code: 'LOCAL_ERROR' });
};

type Handler = (req: AuthRequest) => Promise<unknown>;
/** La función debe estar encendida en Funciones y dentro del plan */
const withFeature = (feature: FeatureKey, fn: Handler) => async (req: AuthRequest, res: Response) => {
  try {
    if (!(await featureAllowed(feature))) return res.status(403).json({ error: 'Esta función está apagada en el negocio.', code: 'FEATURE_OFF', feature });
    res.json(await fn(req));
  } catch (error) {
    fail(res, error);
  }
};

export const createTableDoorRoutes = (tables = new TableOrderUseCases(), door = new DoorUseCases()) => {
  const router = Router();

  router.get('/table-orders', withFeature('table_ordering', () => tables.pending()));
  // Los QR se pueden preparar antes de encender la función (se imprimen una vez)
  router.get('/table-orders/qr', async (_req, res) => {
    try {
      res.json(await tables.qrSheet());
    } catch (error) {
      fail(res, error);
    }
  });
  router.post('/table-orders/qr/:tableId/rotate', async (req: AuthRequest, res) => {
    try {
      res.json(await tables.rotate(req.params.tableId, actorOf(req)));
    } catch (error) {
      fail(res, error);
    }
  });
  router.post('/table-orders/:id/accept', withFeature('table_ordering', (req) => tables.accept(req.params.id, actorOf(req))));
  router.post('/table-orders/:id/reject', withFeature('table_ordering', (req) => tables.reject(req.params.id, req.body?.reason, actorOf(req))));

  router.get('/door', withFeature('door', () => door.state()));
  router.post('/door/events', withFeature('door', (req) => door.mark(req.body || {}, actorOf(req))));
  router.get('/door/report', withFeature('door', (req) => door.report(typeof req.query.date === 'string' ? req.query.date : undefined)));

  return router;
};
