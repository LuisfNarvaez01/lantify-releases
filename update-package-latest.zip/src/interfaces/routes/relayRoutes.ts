// ============================================
// INTERFACES - Celulares vinculados para trabajar por internet (relevo)
// ============================================
//   GET    /api/relay/devices        celulares vinculados y estado de la conexión (ADMIN)
//   POST   /api/relay/devices        vincular uno: devuelve el enlace del QR (una sola vez)
//   DELETE /api/relay/devices/:id    revocar (se desconecta al instante)

import { Router, Response } from 'express';
import { AuthRequest } from '../../shared/authMiddleware';
import { AuditLogger } from '../../infrastructure/services/AuditLogger';
import { prisma } from '../../infrastructure/database/prisma';
import { cloudConfig } from '../../shared/cloud/config';
import { RelayHostService } from '../../application/usecases/RelayHostService';
import { buildPairingLink } from '../../domain/relayPairing';

export const createRelayRoutes = (relay: RelayHostService, lan: () => string[]) => {
  const router = Router();

  router.get('/relay/devices', async (_req, res: Response, next) => {
    try {
      res.json({ status: relay.getStatus(), devices: await relay.listDevices() });
    } catch (err) { next(err); }
  });

  router.post('/relay/devices', async (req: AuthRequest, res: Response, next) => {
    try {
      const settings = await prisma.businessSettings.findUnique({ where: { id: 'default' }, select: { cloudTenantCode: true, businessName: true } });
      if (!settings?.cloudTenantCode) return res.status(409).json({ code: 'RELAY_NOT_LINKED', error: 'Vincula el negocio a Lantify Cloud para usar los celulares por internet' });
      const { device, secret } = await relay.createDevice(String(req.body?.name || ''), req.user?.name || req.user?.username || null);
      const link = buildPairingLink({
        tenant: settings.cloudTenantCode, deviceId: device.id, secret, lan: lan(), cloud: cloudConfig().apiUrl,
        business: settings.businessName || null, appUrl: process.env.LANTIFY_APP_URL,
      });
      AuditLogger.log({ action: 'RELAY_DEVICE_CREATED', entityType: 'SYSTEM', entityId: device.id, userId: req.user?.id, details: { name: device.name } }).catch(() => {});
      res.status(201).json({ device: { id: device.id, name: device.name, createdAt: device.createdAt }, link });
    } catch (err) { next(err); }
  });

  router.delete('/relay/devices/:id', async (req: AuthRequest, res: Response, next) => {
    try {
      const device = await relay.revokeDevice(req.params.id);
      AuditLogger.log({ action: 'RELAY_DEVICE_REVOKED', entityType: 'SYSTEM', entityId: device.id, userId: req.user?.id, details: { name: device.name } }).catch(() => {});
      res.json({ ok: true });
    } catch (err: any) {
      if (err?.code === 'P2025') return res.status(404).json({ code: 'NOT_FOUND' });
      next(err);
    }
  });

  return router;
};
