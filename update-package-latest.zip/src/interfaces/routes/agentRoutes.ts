// ============================================
// INTERFACES - Agentes de IA (Premium, con permiso del ADMIN)
// ============================================
//   GET    /api/agents/:agent/messages   → conversación guardada en este equipo
//   DELETE /api/agents/:agent/messages   → empezar de nuevo
//   GET    /api/agents/:agent/context    → el resumen exacto que se enviaría (transparencia)
//   POST   /api/agents/:agent/ask        → pregunta → respuesta, gráfico y acciones propuestas
//   POST   /api/agents/marketing/coupons → crear el cupón que propuso el agente (con confirmación)

import { Router, Response } from 'express';
import { AgentUseCases, AGENT_IDS, AgentId } from '../../application/usecases/AgentUseCases';
import { CouponUseCases, CouponError } from '../../application/usecases/CouponUseCases';
import { CloudAuthService } from '../../application/usecases/CloudAuthService';
import { AuthRequest } from '../../shared/authMiddleware';
import { cloudConfig } from '../../shared/cloud/config';
import { prisma } from '../../infrastructure/database/prisma';

const isAgent = (v: string): v is AgentId => (AGENT_IDS as string[]).includes(v);

const fail = (res: Response, err: unknown) => {
  if (err instanceof CouponError) return res.status(err.status).json({ code: err.code, error: err.message });
  console.error('[agentes]', err);
  return res.status(500).json({ code: 'SERVER_ERROR', error: 'Error interno del servidor' });
};

const callAgent = async (license: string, body: unknown) => {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 45000);
  try {
    const res = await fetch(`${cloudConfig().aiUrl}/ai/agent`, {
      method: 'POST',
      signal: controller.signal,
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${license}` },
      body: JSON.stringify(body),
    });
    const data: any = await res.json().catch(() => ({}));
    return { status: res.status, body: data };
  } catch {
    return { status: 503, body: { code: controller.signal.aborted ? 'AI_TIMEOUT' : 'AI_UNAVAILABLE' } };
  } finally {
    clearTimeout(timer);
  }
};

const shapeMessage = (m: { id: string; role: string; content: string; payload: string | null; userName: string | null; createdAt: Date }) => {
  let payload: any = null;
  try {
    payload = m.payload ? JSON.parse(m.payload) : null;
  } catch {
    payload = null;
  }
  return { id: m.id, role: m.role, content: m.content, chart: payload?.chart ?? null, actions: payload?.actions ?? [], userName: m.userName, createdAt: m.createdAt };
};

export const createAgentRoutes = (cloud: CloudAuthService, agents = new AgentUseCases(), coupons = new CouponUseCases()) => {
  const router = Router();

  router.get('/agents/:agent/messages', async (req, res) => {
    try {
      if (!isAgent(req.params.agent)) return res.status(404).json({ code: 'NOT_FOUND' });
      const rows = await prisma.agentMessage.findMany({ where: { agent: req.params.agent }, orderBy: { createdAt: 'desc' }, take: 60 });
      res.json(rows.reverse().map(shapeMessage));
    } catch (e) {
      fail(res, e);
    }
  });

  router.delete('/agents/:agent/messages', async (req, res) => {
    try {
      if (!isAgent(req.params.agent)) return res.status(404).json({ code: 'NOT_FOUND' });
      await prisma.agentMessage.deleteMany({ where: { agent: req.params.agent } });
      res.json({ ok: true });
    } catch (e) {
      fail(res, e);
    }
  });

  // Lo que el agente vería, para que el ADMIN sepa exactamente qué sale del equipo
  router.get('/agents/:agent/context', async (req, res) => {
    try {
      if (!isAgent(req.params.agent)) return res.status(404).json({ code: 'NOT_FOUND' });
      res.json(await agents.contextFor(req.params.agent));
    } catch (e) {
      fail(res, e);
    }
  });

  router.post('/agents/:agent/ask', async (req: AuthRequest, res) => {
    try {
      const agent = req.params.agent;
      if (!isAgent(agent)) return res.status(404).json({ code: 'NOT_FOUND' });
      const question = typeof req.body?.question === 'string' ? req.body.question.trim().slice(0, 800) : '';
      if (!question) return res.status(400).json({ code: 'AGENT_QUESTION_REQUIRED', error: 'Escribe tu pregunta.' });

      const settings = await prisma.businessSettings.findUnique({ where: { id: 'default' } });
      if (!settings?.aiConsentAt) {
        return res.status(403).json({ code: 'AI_CONSENT_REQUIRED', error: 'El administrador debe autorizar el uso de la IA con datos del negocio.' });
      }
      const license = await cloud.aiLicense(req.user!.id!);
      if (!license) return res.status(503).json({ code: 'AI_NOT_CONFIGURED', error: 'Inicia sesión con conexión a internet para usar los agentes.' });

      const [context, business, past] = await Promise.all([
        agents.contextFor(agent),
        agents.business(),
        prisma.agentMessage.findMany({ where: { agent }, orderBy: { createdAt: 'desc' }, take: 8 }),
      ]);
      const ai = await callAgent(license, {
        agent,
        question,
        lang: req.body?.lang === 'en' ? 'en' : 'es',
        businessName: business.name,
        businessType: business.type,
        context,
        history: past.reverse().map((m) => ({ role: m.role, content: m.content })),
      });
      if (ai.status !== 200) return res.status(ai.status).json({ code: ai.body?.code || 'AI_UNAVAILABLE', ...ai.body });

      // Las acciones se validan contra los datos reales antes de mostrarlas
      const actions = [];
      for (const a of Array.isArray(ai.body.actions) ? ai.body.actions : []) {
        if (a?.type === 'purchase_order') {
          const supplier = await prisma.supplier.findUnique({ where: { id: String(a.supplierId) } });
          if (supplier) actions.push({ ...a, supplierName: supplier.name, phone: supplier.phone });
        } else if (a?.type === 'create_coupon') {
          const taken = await prisma.coupon.findUnique({ where: { code: String(a.code) } });
          actions.push({ ...a, code: taken ? `${String(a.code).slice(0, 18)}${Math.floor(Math.random() * 90 + 10)}` : a.code });
        }
      }
      const actor = req.user?.name || req.user?.username || null;
      const [, saved] = await prisma.$transaction([
        prisma.agentMessage.create({ data: { agent, role: 'user', content: question, userName: actor } }),
        prisma.agentMessage.create({
          data: { agent, role: 'assistant', content: String(ai.body.answer || ''), payload: JSON.stringify({ chart: ai.body.chart ?? null, actions }) },
        }),
      ]);
      res.json(shapeMessage(saved));
    } catch (e) {
      fail(res, e);
    }
  });

  router.post('/agents/marketing/coupons', async (req: AuthRequest, res) => {
    try {
      const b = req.body || {};
      const days = Math.min(60, Math.max(1, Math.round(Number(b.days) || 7)));
      const coupon = await coupons.create(
        {
          code: b.code,
          description: b.description,
          type: b.discountType === 'AMOUNT' ? 'AMOUNT' : 'PERCENT',
          value: Number(b.value),
          minPurchase: b.minPurchase ?? null,
          startsAt: new Date().toISOString(),
          endsAt: new Date(Date.now() + days * 86_400_000).toISOString(),
        },
        req.user?.name || req.user?.username,
        'AGENT',
      );
      res.status(201).json(coupon);
    } catch (e) {
      fail(res, e);
    }
  });

  return router;
};
