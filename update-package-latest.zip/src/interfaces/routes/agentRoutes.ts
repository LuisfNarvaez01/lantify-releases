// ============================================
// INTERFACES - Agentes de IA (Premium, con permiso del ADMIN)
// ============================================
//   GET    /api/agents/:agent/messages   → conversación guardada en este equipo
//   DELETE /api/agents/:agent/messages   → empezar de nuevo
//   GET    /api/agents/:agent/context    → el resumen exacto que se enviaría (transparencia)
//   POST   /api/agents/:agent/ask        → pregunta → respuesta, gráfico y acciones propuestas
//   POST   /api/agents/:agent/stream     → lo mismo, en vivo (SSE: delta… done)
//   GET/PUT /api/agents/profile          → perfil del negocio que la IA debe conocer
//   POST   /api/agents/marketing/coupons → crear el cupón que propuso el agente (con confirmación)

import { Router, Response } from 'express';
import { AgentUseCases, AGENT_IDS, AgentId } from '../../application/usecases/AgentUseCases';
import { CouponUseCases, CouponError } from '../../application/usecases/CouponUseCases';
import { CloudAuthService } from '../../application/usecases/CloudAuthService';
import { AuthRequest } from '../../shared/authMiddleware';
import { cloudConfig } from '../../shared/cloud/config';
import { prisma } from '../../infrastructure/database/prisma';
import { buildLocalFlyers, normalizeAiProfile, normalizeFlyers, normalizeKpis, parseAiProfile, taskById } from '../../domain/v3/agents';

const isAgent = (v: string): v is AgentId => (AGENT_IDS as string[]).includes(v);

const fail = (res: Response, err: unknown) => {
  if (err instanceof CouponError) return res.status(err.status).json({ code: err.code, error: err.message });
  console.error('[agentes]', err);
  return res.status(500).json({ code: 'SERVER_ERROR', error: 'Error interno del servidor' });
};

const callAgent = async (license: string, body: unknown) => {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 45000);
  try {
    const res = await fetch(`${cloudConfig().aiUrl}/ai/agent`, {
      method: 'POST',
      signal: controller.signal,
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${license}` },
      body: JSON.stringify(body),
    });
    const data: any = await res.json().catch(() => ({}));
    // Ruta que el servicio de IA no conoce: está desactualizado (no es un registro borrado)
    if (res.status === 404) return { status: 502, body: { code: 'AI_SERVICE_OUTDATED' } };
    return { status: res.status, body: data };
  } catch {
    return { status: 503, body: { code: controller.signal.aborted ? 'AI_TIMEOUT' : 'AI_UNAVAILABLE' } };
  } finally {
    clearTimeout(timer);
  }
};

const shapeMessage = (m: { id: string; role: string; content: string; payload: string | null; userName: string | null; createdAt: Date }) => {
  let payload: any = null;
  try {
    payload = m.payload ? JSON.parse(m.payload) : null;
  } catch {
    payload = null;
  }
  return {
    id: m.id, role: m.role, content: m.content, chart: payload?.chart ?? null, actions: payload?.actions ?? [],
    kpis: payload?.kpis ?? [], headline: payload?.headline ?? null, flyer: payload?.flyer ?? null, flyers: payload?.flyers ?? (payload?.flyer ? [payload.flyer] : []),
    userName: m.userName, createdAt: m.createdAt,
  };
};

export const createAgentRoutes = (cloud: CloudAuthService, agents = new AgentUseCases(), coupons = new CouponUseCases()) => {
  const router = Router();

  router.get('/agents/:agent/messages', async (req, res) => {
    try {
      if (!isAgent(req.params.agent)) return res.status(404).json({ code: 'NOT_FOUND' });
      const rows = await prisma.agentMessage.findMany({ where: { agent: req.params.agent }, orderBy: { createdAt: 'desc' }, take: 60 });
      res.json(rows.reverse().map(shapeMessage));
    } catch (e) {
      fail(res, e);
    }
  });

  router.delete('/agents/:agent/messages', async (req, res) => {
    try {
      if (!isAgent(req.params.agent)) return res.status(404).json({ code: 'NOT_FOUND' });
      await prisma.agentMessage.deleteMany({ where: { agent: req.params.agent } });
      res.json({ ok: true });
    } catch (e) {
      fail(res, e);
    }
  });

  // Lo que el agente vería, para que el ADMIN sepa exactamente qué sale del equipo
  router.get('/agents/:agent/context', async (req, res) => {
    try {
      if (!isAgent(req.params.agent)) return res.status(404).json({ code: 'NOT_FOUND' });
      res.json(await agents.contextFor(req.params.agent));
    } catch (e) {
      fail(res, e);
    }
  });

  /** Lo que necesitan las dos formas de preguntar (completa y en vivo) */
  const prepare = async (req: AuthRequest, res: Response) => {
    const agent = req.params.agent;
    if (!isAgent(agent)) { res.status(404).json({ code: 'NOT_FOUND' }); return null; }
    const task = taskById(agent, req.body?.task);
    const question = typeof req.body?.question === 'string' ? req.body.question.trim().slice(0, 800) : '';
    if (!question && !task) { res.status(400).json({ code: 'AGENT_QUESTION_REQUIRED', error: 'Escribe tu pregunta.' }); return null; }

    const settings = await prisma.businessSettings.findUnique({ where: { id: 'default' } });
    if (!settings?.aiConsentAt) {
      res.status(403).json({ code: 'AI_CONSENT_REQUIRED', error: 'El administrador debe autorizar el uso de la IA con datos del negocio.' });
      return null;
    }
    const license = await cloud.aiLicense(req.user!.id!);
    if (!license) { res.status(503).json({ code: 'AI_NOT_CONFIGURED', error: 'Inicia sesión con conexión a internet para usar los agentes.' }); return null; }

    const [context, business, past] = await Promise.all([
      agents.contextFor(agent),
      agents.business(),
      prisma.agentMessage.findMany({ where: { agent }, orderBy: { createdAt: 'desc' }, take: 6 }),
    ]);
    // Lo que el usuario ve en su conversación: la pregunta o el nombre de la tarea
    const shown = question || (typeof req.body?.taskLabel === 'string' ? req.body.taskLabel.trim().slice(0, 120) : '') || task!.id;
    return {
      agent,
      shown,
      license,
      body: {
        agent,
        task: task?.id ?? null,
        // El servicio anterior a la 3.0 exige pregunta: la tarea va también como texto
        question: question || shown,
        lang: req.body?.lang === 'en' ? 'en' : 'es',
        businessName: business.name,
        businessType: business.type,
        profile: parseAiProfile(settings.aiProfile),
        context,
        history: past.reverse().map((m) => ({ role: m.role, content: m.content })),
      },
    };
  };

  /** Valida las acciones contra los datos reales y guarda la conversación */
  const finish = async (req: AuthRequest, agent: AgentId, shown: string, reply: any, task: string | null = null) => {
    const actions = [];
    for (const a of Array.isArray(reply.actions) ? reply.actions : []) {
      if (a?.type === 'purchase_order') {
        const supplier = await prisma.supplier.findUnique({ where: { id: String(a.supplierId) } });
        if (supplier) actions.push({ ...a, supplierName: supplier.name, phone: supplier.phone });
      } else if (a?.type === 'create_coupon') {
        const taken = await prisma.coupon.findUnique({ where: { code: String(a.code) } });
        actions.push({ ...a, code: taken ? `${String(a.code).slice(0, 18)}${Math.floor(Math.random() * 90 + 10)}` : a.code });
      }
    }
    let flyers = normalizeFlyers(reply.flyers ?? reply.flyer);
    // La tarea de flyer siempre entrega 3 propuestas: si la IA no las trajo, se arman aquí
    if (task === 'flyer' && flyers.length < 3) {
      const [business, settings, top] = await Promise.all([
        agents.business(),
        prisma.businessSettings.findUnique({ where: { id: 'default' }, select: { aiProfile: true } }),
        prisma.saleItem.groupBy({ by: ['productVariantId'], where: { isCancelled: false, createdAt: { gte: new Date(Date.now() - 60 * 86_400_000) } }, _sum: { quantity: true }, orderBy: { _sum: { quantity: 'desc' } }, take: 12 }).catch(() => [] as any[]),
      ]);
      const variants = await prisma.productVariant.findMany({ where: { id: { in: top.map((x: any) => x.productVariantId) } }, select: { id: true, price: true, product: { select: { name: true, description: true, imageUrl: true, isActive: true } } } });
      const ranked = top.map((x: any) => variants.find((v) => v.id === x.productVariantId)).filter((v): v is (typeof variants)[number] => !!v && v.product.isActive);
      const fallback = ranked.length ? [] : await prisma.productVariant.findMany({ where: { isActive: true, product: { isActive: true } }, take: 6, select: { id: true, price: true, product: { select: { name: true, description: true, imageUrl: true, isActive: true } } } });
      // Primero los que tienen foto: se ven mejor en un flyer
      const pool = [...ranked, ...fallback].sort((a, b) => Number(!!b.product.imageUrl) - Number(!!a.product.imageUrl));
      const seen = new Set<string>();
      const products = pool.filter((v) => !seen.has(v.product.name) && seen.add(v.product.name)).map((v) => ({ name: v.product.name, price: v.price, description: v.product.description }));
      const local = buildLocalFlyers({ businessName: business.name, businessType: business.type, profile: parseAiProfile(settings?.aiProfile), products, lang: req.body?.lang === 'en' ? 'en' : 'es', focus: shown !== task ? shown : undefined });
      flyers = [...flyers, ...local].slice(0, 3);
    }
    const flyer = flyers[0] ?? null;
    const actor = req.user?.name || req.user?.username || null;
    const [, saved] = await prisma.$transaction([
      prisma.agentMessage.create({ data: { agent, role: 'user', content: shown, userName: actor } }),
      prisma.agentMessage.create({
        data: {
          agent,
          role: 'assistant',
          content: String(reply.answer || ''),
          payload: JSON.stringify({ chart: reply.chart ?? null, actions, kpis: normalizeKpis(reply.kpis), headline: typeof reply.headline === 'string' ? reply.headline.slice(0, 140) : null, flyer, flyers }),
        },
      }),
    ]);
    return shapeMessage(saved);
  };

  router.post('/agents/:agent/ask', async (req: AuthRequest, res) => {
    try {
      const p = await prepare(req, res);
      if (!p) return;
      const ai = await callAgent(p.license, p.body);
      if (ai.status !== 200) return res.status(ai.status).json({ code: ai.body?.code || 'AI_UNAVAILABLE', ...ai.body });
      res.json(await finish(req, p.agent, p.shown, ai.body, p.body.task));
    } catch (e) {
      fail(res, e);
    }
  });

  // En vivo: reenvía los fragmentos del worker (SSE) y al final la respuesta guardada
  router.post('/agents/:agent/stream', async (req: AuthRequest, res) => {
    let p: Awaited<ReturnType<typeof prepare>> = null;
    try {
      p = await prepare(req, res);
      if (!p) return;
    } catch (e) {
      return fail(res, e);
    }
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 75000);
    req.on('close', () => { if (!res.writableEnded) controller.abort(); });
    const send = (event: string, data: unknown) => { if (!res.writableEnded) res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`); };
    try {
      const upstream = await fetch(`${cloudConfig().aiUrl}/ai/agent/stream`, {
        method: 'POST',
        signal: controller.signal,
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${p.license}` },
        body: JSON.stringify(p.body),
      });
      if (upstream.status === 404) {
        // Servicio de IA sin respuesta en vivo (anterior a la 3.0): misma respuesta, completa
        clearTimeout(timer);
        const ai = await callAgent(p.license, p.body);
        if (ai.status !== 200) return res.status(ai.status).json({ code: ai.body?.code || 'AI_UNAVAILABLE', ...ai.body });
        const saved = await finish(req, p.agent, p.shown, ai.body, p.body.task);
        res.status(200).set({ 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-store' });
        send('delta', { t: saved.content });
        send('done', saved);
        return res.end();
      }
      if (!upstream.ok || !upstream.body) {
        const body: any = await upstream.json().catch(() => ({}));
        return res.status(upstream.status || 503).json({ code: body?.code || 'AI_UNAVAILABLE', ...body });
      }
      res.status(200).set({ 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-store', 'X-Accel-Buffering': 'no' });
      res.flushHeaders?.();
      const reader = (upstream.body as any).getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let ended = false;
      while (!ended) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        let sep: number;
        while ((sep = buffer.indexOf('\n\n')) >= 0) {
          const block = buffer.slice(0, sep);
          buffer = buffer.slice(sep + 2);
          const event = /^event: (.+)$/m.exec(block)?.[1]?.trim();
          const raw = /^data: (.+)$/m.exec(block)?.[1];
          if (!event || !raw) continue;
          let data: any;
          try { data = JSON.parse(raw); } catch { continue; }
          if (event === 'delta') send('delta', data);
          else if (event === 'done') { send('done', await finish(req, p.agent, p.shown, data, p.body.task)); ended = true; }
          else if (event === 'error') { send('error', data); ended = true; }
        }
      }
      if (!ended) send('error', { code: 'AI_UNAVAILABLE' });
      res.end();
    } catch (e) {
      if (res.headersSent) { send('error', { code: controller.signal.aborted ? 'AI_TIMEOUT' : 'AI_UNAVAILABLE' }); res.end(); }
      else res.status(503).json({ code: controller.signal.aborted ? 'AI_TIMEOUT' : 'AI_UNAVAILABLE' });
    } finally {
      clearTimeout(timer);
    }
  });

  // Foto con IA para un flyer (la hace la nube; cuenta en el cupo de fotos IA)
  router.post('/agents/flyer-image', async (req: AuthRequest, res) => {
    try {
      const b = req.body || {};
      res.json(await cloud.adminCall(req.user!.id!, 'POST', '/v1/ai/flyer-image', { prompt: String(b.prompt || '').slice(0, 400), kind: b.kind, portrait: !!b.portrait }, 60000));
    } catch (e: any) {
      if (e?.status === 404) return res.status(502).json({ code: 'AI_SERVICE_OUTDATED' });
      if (e?.status) return res.status(e.status).json({ code: e.code || 'AI_UNAVAILABLE', error: e.message });
      fail(res, e);
    }
  });

  // Perfil del negocio para la IA
  router.get('/agents/profile', async (_req, res) => {
    try {
      const s = await prisma.businessSettings.findUnique({ where: { id: 'default' } });
      res.json({ profile: parseAiProfile(s?.aiProfile), businessType: s?.businessType || null, businessName: s?.businessName || null, logoUrl: s?.logoUrl || null });
    } catch (e) {
      fail(res, e);
    }
  });

  router.put('/agents/profile', async (req, res) => {
    try {
      const profile = normalizeAiProfile(req.body?.profile ?? req.body);
      await prisma.businessSettings.update({ where: { id: 'default' }, data: { aiProfile: JSON.stringify(profile) } });
      res.json({ profile });
    } catch (e) {
      fail(res, e);
    }
  });

  router.post('/agents/marketing/coupons', async (req: AuthRequest, res) => {
    try {
      const b = req.body || {};
      const days = Math.min(60, Math.max(1, Math.round(Number(b.days) || 7)));
      const coupon = await coupons.create(
        {
          code: b.code,
          description: b.description,
          type: b.discountType === 'AMOUNT' ? 'AMOUNT' : 'PERCENT',
          value: Number(b.value),
          minPurchase: b.minPurchase ?? null,
          startsAt: new Date().toISOString(),
          endsAt: new Date(Date.now() + days * 86_400_000).toISOString(),
        },
        req.user?.name || req.user?.username,
        'AGENT',
      );
      res.status(201).json(coupon);
    } catch (e) {
      fail(res, e);
    }
  });

  return router;
};
