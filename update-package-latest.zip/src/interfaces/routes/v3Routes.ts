import { PurchaseUseCases, ExpenseError } from '../../application/usecases/v3/PurchaseUseCases';
import { IngredientUseCases } from '../../application/usecases/v3/IngredientUseCases';
import { AutopilotUseCases } from '../../application/usecases/v3/AutopilotUseCases';
// ============================================
// INTERFACES - Rutas de Lantify 3.0 (bloque 1)
// ============================================
//   /api/features            funciones activables y sus ajustes
//   /api/floor/*             salón: por limpiar, cuenta pedida, mesero, alertas
//   /api/ops/*               lista de compras, ingredientes, corrección de pago, reporte de cierre
//   /api/staff/*             personal, turnos, pagos y reparto de propinas
// Quién puede llamar cada una lo decide src/shared/security/accessPolicy.ts.

import { KitchenUseCases } from '../../application/usecases/v3/KitchenUseCases';
import { Router, Response, NextFunction } from 'express';
import { AuthRequest } from '../../shared/authMiddleware';
import { AuditLogger } from '../../infrastructure/services/AuditLogger';
import { loadFeatures, saveFeatures } from '../../shared/featureStore';
import { FEATURE_PLAN_CODE, FEATURE_REQUIRES, type FeatureKey } from '../../domain/v3/features';
import { FloorUseCases, FloorError, type Actor } from '../../application/usecases/v3/FloorUseCases';
import { OpsUseCases, OpsError } from '../../application/usecases/v3/OpsUseCases';
import { StaffUseCases, StaffError } from '../../application/usecases/v3/StaffUseCases';
import { CloseReportService } from '../../application/usecases/v3/CloseReportService';

const actorOf = (req: AuthRequest): Actor => ({ userId: req.user?.id || req.user?.userId, name: req.user?.name || req.user?.username, role: req.user?.role });

const fail = (res: Response, error: any) => {
  if (error instanceof FloorError || error instanceof OpsError || error instanceof StaffError) {
    return res.status(error.statusCode).json({ error: error.message, code: error.code });
  }
  if (error instanceof ExpenseError) return res.status(error.status).json({ error: error.message, code: error.code });
  console.error('[v3]', error);
  return res.status(500).json({ error: 'No se pudo completar la operación.', code: 'V3_ERROR' });
};

type Handler = (req: AuthRequest, res: Response) => Promise<unknown>;
const run = (fn: Handler) => async (req: AuthRequest, res: Response) => {
  try {
    const out = await fn(req, res);
    if (!res.headersSent) res.json(out ?? { ok: true });
  } catch (error) {
    fail(res, error);
  }
};

/** La función debe estar encendida en el negocio */
const needs = (key: FeatureKey) => async (_req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    if ((await loadFeatures()).flags[key]) return next();
    res.status(403).json({ error: 'Esta función está apagada en el negocio.', code: 'FEATURE_OFF', feature: key });
  } catch (error) {
    fail(res, error);
  }
};

const range = (req: AuthRequest) => {
  const from = new Date(String(req.query.from || ''));
  const to = new Date(String(req.query.to || ''));
  if (Number.isNaN(from.getTime()) || Number.isNaN(to.getTime()) || to < from) throw new StaffError('Indica el periodo (desde y hasta)', 'BAD_RANGE');
  return { from, to };
};

const bodyRange = (body: any) => {
  const from = new Date(String(body?.from || ''));
  const to = new Date(String(body?.to || ''));
  if (Number.isNaN(from.getTime()) || Number.isNaN(to.getTime()) || to < from) throw new StaffError('Indica el periodo (desde y hasta)', 'BAD_RANGE');
  return { from, to };
};

// Intentos fallidos de conectar una pantalla, por equipo (un código de 6 dígitos no se adivina en 10 minutos)
const pairFails = new Map<string, { n: number; until: number }>();
const PAIR_MAX = 8;
const PAIR_WINDOW = 10 * 60_000;

export const createV3Routes = (services: { floor: FloorUseCases; ops: OpsUseCases; staff: StaffUseCases; closeReport: CloseReportService; kitchen?: KitchenUseCases; autopilot?: AutopilotUseCases }) => {
  const { floor, ops, staff, closeReport } = services;
  const kitchen = services.kitchen || new KitchenUseCases(floor);
  const autopilot = services.autopilot || new AutopilotUseCases();
  const ingredients = new IngredientUseCases();




  const router = Router();

  // ── Facturas de compra: emparejar, confirmar y cuentas por pagar ──
  const purchases = new PurchaseUseCases();
  router.post('/purchases/prepare', run((req) => purchases.prepare(req.body?.reading || req.body || {})));
  router.post('/purchases', run((req) => purchases.commit(req.body || {}, actorOf(req))));
  router.post('/purchases/suppliers', run((req) => purchases.createSupplier(req.body || {})));
  router.get('/payables', run((req) => purchases.payables(req.query.status === 'PAID' ? 'PAID' : req.query.status === 'ALL' ? 'ALL' : 'PENDING')));
  router.post('/payables/:id/pay', run((req) => purchases.pay(req.params.id, req.body || {}, actorOf(req))));

  // ── Ingredientes, recetas y kardex ──
  router.get('/ingredients', run(() => ingredients.list()));
  router.post('/ingredients', run((req) => ingredients.save(null, req.body || {}, actorOf(req))));
  router.put('/ingredients/:id', run((req) => ingredients.save(req.params.id, req.body || {}, actorOf(req))));
  router.delete('/ingredients/:id', run((req) => ingredients.remove(req.params.id)));
  router.get('/ingredients/:id/movements', run((req) => ingredients.movements(req.params.id, Number(req.query.limit) || 100)));
  router.post('/ingredients/:id/adjust', run((req) => ingredients.adjust(req.params.id, req.body || {}, actorOf(req))));
  router.get('/recipes/costs', run(() => ingredients.costs()));
  router.get('/recipes/:productId', run((req) => ingredients.recipe(req.params.productId)));
  router.put('/recipes/:productId', run((req) => ingredients.setRecipe(req.params.productId, req.body?.items, actorOf(req))));

  // ── Motor de menú, sugerencias y Autopilot (bloque 4) ──
  router.get('/menu', run((req) => autopilot.menu(new Date(), req.query.fresh === '1')));
  router.post('/menu/suggestions', run((req) => autopilot.suggestions((Array.isArray(req.body?.cart) ? req.body.cart : []).filter((x: unknown) => typeof x === 'string').slice(0, 40))));
  router.post('/menu/suggestions/event', run((req) => autopilot.recordSuggestion(String(req.body?.productId || ''), String(req.body?.reason || ''), req.body?.accepted === true, actorOf(req).userId)));
  router.get('/autopilot', run((req) => autopilot.state(String(req.user?.role || ''))));
  router.get('/autopilot/knowledge', needs('autopilot'), run(() => autopilot.knowledge()));
  router.post('/autopilot/tick', needs('autopilot'), run(() => autopilot.tick()));
  router.post('/autopilot/situations/:id/decide', needs('autopilot'), run((req) => autopilot.decide(req.params.id, String(req.body?.interventionId || ''), req.body?.params || {}, { ...actorOf(req), role: req.user?.role })));
  router.post('/autopilot/situations/:id/dismiss', needs('autopilot'), run((req) => autopilot.dismiss(req.params.id, actorOf(req))));
  router.post('/autopilot/actions/:id/revert', needs('autopilot'), run((req) => autopilot.revert(req.params.id, actorOf(req))));

  // ── Funciones activables ────────────────────────────────
  router.get('/features', run(async () => ({ ...(await loadFeatures()), plan: FEATURE_PLAN_CODE, requires: FEATURE_REQUIRES })));

  router.put('/features', run(async (req) => {
    const saved = await saveFeatures(req.body);
    const a = actorOf(req);
    AuditLogger.log({ action: 'FEATURES_UPDATED', entityType: 'SETTINGS', entityId: 'default', userId: a.userId, userName: a.name, userRole: a.role, details: { flags: saved.flags, alerts: saved.alerts, tips: saved.tips } });
    return { ...saved, plan: FEATURE_PLAN_CODE, requires: FEATURE_REQUIRES };
  }));

  // ── Pantallas (bloque 2) ────────────────────────────────
  // Administración (ADMIN): crear, código para conectar, desconectar, borrar
  router.get('/displays', needs('kitchen_display'), run(() => kitchen.list()));
  router.post('/displays', needs('kitchen_display'), run((req) => kitchen.create(req.body || {})));
  router.post('/displays/:id/code', needs('kitchen_display'), run((req) => kitchen.newCode(req.params.id)));
  router.post('/displays/:id/disconnect', run((req) => kitchen.disconnect(req.params.id)));
  router.delete('/displays/:id', run((req) => kitchen.remove(req.params.id)));

  // La pantalla misma: sin usuario, con su token (cabecera X-Display-Token)
  router.post('/display/pair', async (req: AuthRequest, res: Response) => {
    const ip = req.ip || 'sin-ip';
    const f = pairFails.get(ip);
    if (f && f.until > Date.now() && f.n >= PAIR_MAX) {
      return res.status(429).json({ error: 'Demasiados intentos. Espera unos minutos y pide un código nuevo.', code: 'DISPLAY_PAIR_LIMIT' });
    }
    try {
      if (!(await kitchen.enabled())) return res.status(403).json({ error: 'Las pantallas están apagadas. Actívalas en Salón y mesas.', code: 'FEATURE_OFF', feature: 'kitchen_display' });
      const out = await kitchen.pair(req.body?.code);
      pairFails.delete(ip);
      res.json(out);
    } catch (error) {
      const now = Date.now();
      const cur = f && f.until > now ? f : { n: 0, until: now + PAIR_WINDOW };
      pairFails.set(ip, { n: cur.n + 1, until: cur.until });
      fail(res, error);
    }
  });

  const asDisplay = (fn: (display: NonNullable<Awaited<ReturnType<KitchenUseCases['byToken']>>>, req: AuthRequest) => Promise<unknown>) =>
    async (req: AuthRequest, res: Response) => {
      try {
        const display = await kitchen.byToken(String(req.headers['x-display-token'] || ''));
        if (!display) return res.status(401).json({ error: 'Esta pantalla ya no está conectada. Pide un código nuevo en Salón y mesas → Pantallas.', code: 'DISPLAY_UNPAIRED' });
        if (!(await kitchen.enabled())) return res.status(403).json({ error: 'Las pantallas están apagadas en el negocio.', code: 'FEATURE_OFF', feature: 'kitchen_display' });
        res.json(await fn(display, req));
      } catch (error) {
        fail(res, error);
      }
    };
  router.get('/display/feed', asDisplay((d) => kitchen.feed(d)));
  router.post('/display/ready', asDisplay((d, req) => (d.type === 'KITCHEN' ? kitchen.ready(req.body?.itemIds, d.name) : Promise.resolve({ ready: 0 }))));
  router.post('/display/undo', asDisplay((d, req) => (d.type === 'KITCHEN' ? kitchen.undo(req.body?.itemIds) : Promise.resolve({ undone: 0 }))));

  // Meseros y caja
  router.get('/floor/layout', run(() => floor.layout()));
  router.put('/floor/layout', run((req) => floor.saveLayout(req.body || {}, actorOf(req))));
  router.patch('/floor/tables/:id/details', run((req) => floor.details(req.params.id, req.body || {})));
  router.post('/floor/tables/:id/served', run((req) => floor.served(req.params.id, actorOf(req))));
  router.post('/floor/orders/:id/picked-up', run((req) => kitchen.pickedUp(req.params.id, actorOf(req))));

  // ── Salón ───────────────────────────────────────────────
  router.get('/floor', run(() => floor.state()));
  router.patch('/floor/tables/:id/clean', run((req) => floor.cleanTable(req.params.id, actorOf(req))));
  router.post('/floor/tables/:id/bill', run((req) => floor.requestBill(req.params.id, actorOf(req))));
  router.delete('/floor/tables/:id/bill', run((req) => floor.undoBill(req.params.id)));
  router.patch('/floor/tables/:id/waiter', run((req) => floor.assignWaiter(req.params.id, String(req.body?.userId || ''), actorOf(req))));

  // ── Operación ───────────────────────────────────────────
  router.get('/ops/shopping-list', needs('shopping_list'), run((req) => ops.shoppingList(req.query.lang === 'en' ? 'en' : 'es')));
  router.post('/ops/shopping-list/sent', needs('shopping_list'), run(async (req) => {
    ops.logShoppingList(actorOf(req), { supplier: String(req.body?.supplier || '').slice(0, 120), lines: Number(req.body?.lines) || 0, via: req.body?.via === 'whatsapp' ? 'whatsapp' : 'copy' });
  }));
  router.put('/ops/reorder/:variantId', run((req) => ops.setReorder(req.params.variantId, req.body || {})));
  router.put('/ops/products/:id/ingredients', run((req) => ops.setIngredients(req.params.id, req.body?.ingredients)));
  router.put('/ops/sales/:id/payments', run((req) => ops.correctPayments(req.params.id, req.body?.payments, String(req.body?.reason || ''), actorOf(req))));
  router.get('/ops/close-report/:sessionId', run(async (req) => {
    const out = await closeReport.forScreen(req.params.sessionId, req.query.lang === 'en' ? 'en' : 'es');
    if (!out) throw new OpsError('Turno no encontrado', 'SESSION_NOT_FOUND', 404);
    return out;
  }));

  // ── Personal: marcar el propio turno (cualquier usuario) ─
  router.get('/staff/me/shift', needs('staff'), run((req) => staff.myShift(actorOf(req).userId)));
  router.post('/staff/me/clock-in', needs('staff'), run(async (req) => {
    const me = await staff.employeeOfUser(actorOf(req).userId);
    if (!me) throw new StaffError('Tu usuario no tiene ficha de empleado', 'EMPLOYEE_NOT_FOUND', 404);
    return staff.clockIn(me.id, actorOf(req));
  }));
  router.post('/staff/me/clock-out', needs('staff'), run(async (req) => {
    const me = await staff.employeeOfUser(actorOf(req).userId);
    if (!me) throw new StaffError('Tu usuario no tiene ficha de empleado', 'EMPLOYEE_NOT_FOUND', 404);
    return staff.clockOut(me.id);
  }));

  // ── Personal: equipo y turnos ───────────────────────────
  router.get('/staff', needs('staff'), run(() => staff.list()));
  router.post('/staff', needs('staff'), run((req) => staff.create(req.body || {}, actorOf(req))));
  router.put('/staff/:id', needs('staff'), run((req) => staff.update(req.params.id, req.body || {}, actorOf(req))));
  router.post('/staff/:id/clock-in', needs('staff'), run((req) => staff.clockIn(req.params.id, actorOf(req))));
  router.post('/staff/:id/clock-out', needs('staff'), run((req) => staff.clockOut(req.params.id)));

  router.get('/staff/shifts/list', needs('staff'), run((req) => { const r = range(req); return staff.shifts(r.from, r.to, req.query.employeeId ? String(req.query.employeeId) : undefined); }));
  router.post('/staff/shifts', needs('staff'), run((req) => staff.saveShift(null, req.body || {}, actorOf(req))));
  router.put('/staff/shifts/:id', needs('staff'), run((req) => staff.saveShift(req.params.id, req.body || {}, actorOf(req))));
  router.delete('/staff/shifts/:id', needs('staff'), run((req) => staff.deleteShift(req.params.id, actorOf(req))));

  // ── Personal: adelantos, descuentos y liquidación ───────
  router.get('/staff/movements/list', needs('staff'), run((req) => { const r = range(req); return staff.movements(r.from, r.to, req.query.employeeId ? String(req.query.employeeId) : undefined); }));
  router.post('/staff/movements', needs('staff'), run((req) => staff.addMovement(req.body || {}, actorOf(req))));
  router.delete('/staff/movements/:id', needs('staff'), run((req) => staff.deleteMovement(req.params.id, actorOf(req))));

  router.get('/staff/payroll/preview', needs('staff'), run((req) => { const r = range(req); return staff.payrollPreview(r.from, r.to); }));
  router.get('/staff/payroll/list', needs('staff'), run((req) => staff.payrolls(req.query.employeeId ? String(req.query.employeeId) : undefined)));
  router.post('/staff/payroll', needs('staff'), run((req) => { const r = bodyRange(req.body); return staff.createPayroll(String(req.body?.employeeId || ''), r.from, r.to, actorOf(req)); }));
  router.post('/staff/payroll/:id/pay', needs('staff'), run((req) => staff.payPayroll(req.params.id, req.body?.asExpense === true, actorOf(req))));
  router.delete('/staff/payroll/:id', needs('staff'), run((req) => staff.deletePayroll(req.params.id, actorOf(req))));

  // ── Reparto de propinas ─────────────────────────────────
  router.get('/staff/tips/preview', needs('tip_split'), run((req) => { const r = range(req); return staff.tipPreview(r.from, r.to, req.query.cashSessionId ? String(req.query.cashSessionId) : null); }));
  router.get('/staff/tips/list', needs('tip_split'), run(() => staff.tipSplits()));
  router.post('/staff/tips', needs('tip_split'), run((req) => {
    const r = bodyRange(req.body);
    return staff.confirmTips({ ...r, periodType: String(req.body?.periodType || ''), cashSessionId: req.body?.cashSessionId || null, shares: Array.isArray(req.body?.shares) ? req.body.shares : [] }, actorOf(req));
  }));
  router.post('/staff/tips/:id/pay', needs('tip_split'), run((req) => staff.markTipsPaid(req.params.id, actorOf(req))));
  router.delete('/staff/tips/:id', needs('tip_split'), run((req) => staff.deleteTipSplit(req.params.id, actorOf(req))));

  return router;
};
