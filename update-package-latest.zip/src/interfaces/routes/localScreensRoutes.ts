// ============================================
// INTERFACES - Fase 4 · En el local: pantalla del cliente, asistencia y kiosco
// ============================================
// Caja (con sesión):
//   GET  /api/displays/customer           → pantallas del cliente que puede usar esta caja
//   PUT  /api/displays/customer-cart      → la caja publica su carrito ({ displayId, cart })
//   GET  /api/attendance/roster           → quiénes pueden marcar con PIN
//   POST /api/attendance/punch            → marcar entrada o salida ({ employeeId, pin })
// ADMIN (Personal):
//   PUT  /api/staff/:id/pin               → poner o quitar el PIN ({ pin | null })
//   GET  /api/staff/schedule/all          → horario semanal de todos
//   PUT  /api/staff/:id/schedule          → horario semanal de un empleado ({ slots })
//   GET  /api/staff/attendance/report     → llegadas tarde y horas (?from&to)
// La pantalla (sin usuario, con su token en X-Display-Token):
//   GET  /api/display/events              → avisos en vivo (la pantalla del cliente se entera del carrito)
//   POST /api/display/attendance/punch    → pantalla de asistencia
//   POST /api/display/kiosk/order         → el kiosco envía el pedido
// Quién puede llamar cada una lo decide src/shared/security/accessPolicy.ts.

import { Router, Response, Request } from 'express';
import { AuthRequest } from '../../shared/authMiddleware';
import { featureAllowed } from '../../shared/featureStore';
import { liveHandler } from '../../shared/liveEvents';
import { KitchenUseCases } from '../../application/usecases/v3/KitchenUseCases';
import { CustomerDisplayUseCases, CustomerDisplayError } from '../../application/usecases/CustomerDisplayUseCases';
import { AttendanceUseCases } from '../../application/usecases/AttendanceUseCases';
import { KioskUseCases } from '../../application/usecases/KioskUseCases';
import { AttendanceError } from '../../domain/attendance';
import { KioskError } from '../../domain/kiosk';
import { DISPLAY_FEATURE, type DisplayType } from '../../domain/v3/kitchen';
import type { FeatureKey } from '../../domain/v3/features';
import type { Actor } from '../../application/usecases/v3/FloorUseCases';

const actorOf = (req: AuthRequest): Actor => ({ userId: req.user?.id || req.user?.userId, name: req.user?.name || req.user?.username, role: req.user?.role });

const fail = (res: Response, error: any) => {
  if (error instanceof AttendanceError || error instanceof KioskError || error instanceof CustomerDisplayError) {
    return res.status(error.statusCode).json({ error: error.message, code: error.code });
  }
  console.error('[local]', error);
  return res.status(500).json({ error: 'No se pudo completar la operación.', code: 'LOCAL_ERROR' });
};

const off = (res: Response, feature: FeatureKey) =>
  res.status(403).json({ error: 'Esta función está apagada en el negocio.', code: 'FEATURE_OFF', feature });

type Handler = (req: AuthRequest, res: Response) => Promise<unknown>;
/** Con sesión: la función debe estar encendida y en el plan */
const withFeature = (feature: FeatureKey, fn: Handler) => async (req: AuthRequest, res: Response) => {
  try {
    if (!(await featureAllowed(feature))) return off(res, feature);
    const out = await fn(req, res);
    if (!res.headersSent) res.json(out ?? { ok: true });
  } catch (error) {
    fail(res, error);
  }
};

export const createLocalScreensRoutes = (deps: { kitchen?: KitchenUseCases; customer?: CustomerDisplayUseCases; attendance?: AttendanceUseCases; kiosk?: KioskUseCases } = {}) => {
  const kitchen = deps.kitchen || new KitchenUseCases();
  const customer = deps.customer || new CustomerDisplayUseCases();
  const attendance = deps.attendance || new AttendanceUseCases();
  const kiosk = deps.kiosk || new KioskUseCases();
  const router = Router();

  // ── Pantalla del cliente: la caja ─────────────────────────
  router.get('/displays/customer', async (_req, res) => {
    try {
      res.json((await featureAllowed('customer_display')) ? await customer.displays() : []);
    } catch (error) {
      fail(res, error);
    }
  });
  // Nunca detiene una venta: con la función apagada responde sin hacer nada
  router.put('/displays/customer-cart', async (req: AuthRequest, res: Response) => {
    try {
      if (!(await featureAllowed('customer_display'))) return res.json({ ok: false, off: true });
      res.json(await customer.publish(req.body?.displayId, req.body?.cart));
    } catch (error) {
      fail(res, error);
    }
  });

  // ── Asistencia en la caja ─────────────────────────────────
  router.get('/attendance/roster', withFeature('attendance', () => attendance.roster()));
  router.post('/attendance/punch', withFeature('attendance', (req) => {
    const a = actorOf(req);
    return attendance.punch(req.body?.employeeId, req.body?.pin, `caja:${a.userId || req.ip}`, a.name || 'Caja');
  }));

  // ── Asistencia: PIN, horario e informe (ADMIN) ────────────
  router.put('/staff/:id/pin', withFeature('attendance', (req) => attendance.setPin(req.params.id, req.body?.pin ?? null, actorOf(req))));
  router.get('/staff/schedule/all', withFeature('attendance', () => attendance.schedule()));
  router.put('/staff/:id/schedule', withFeature('attendance', (req) => attendance.setSchedule(req.params.id, req.body?.slots, actorOf(req))));
  router.get('/staff/attendance/report', withFeature('attendance', async (req) => {
    const from = new Date(String(req.query.from || ''));
    const to = new Date(String(req.query.to || ''));
    if (Number.isNaN(from.getTime()) || Number.isNaN(to.getTime()) || to < from) throw new AttendanceError('Indica el periodo (desde y hasta)', 'BAD_RANGE');
    return attendance.report(from, to);
  }));

  // ── La pantalla misma (token de pantalla) ─────────────────
  type Display = NonNullable<Awaited<ReturnType<KitchenUseCases['byToken']>>>;
  const asDisplay = (types: DisplayType[] | null, fn: (d: Display, req: Request, res: Response) => Promise<unknown>) =>
    async (req: Request, res: Response) => {
      try {
        const d = await kitchen.byToken(String(req.headers['x-display-token'] || ''));
        if (!d) return res.status(401).json({ error: 'Esta pantalla ya no está conectada. Pide un código nuevo en Salón y mesas → Pantallas.', code: 'DISPLAY_UNPAIRED' });
        if (types && !types.includes(d.type as DisplayType)) return res.status(403).json({ error: 'Esta pantalla no hace eso.', code: 'DISPLAY_WRONG_TYPE' });
        if (!(await kitchen.enabledFor(d.type))) return off(res, DISPLAY_FEATURE[d.type as DisplayType] || 'kitchen_display');
        const out = await fn(d, req, res);
        if (!res.headersSent) res.json(out ?? { ok: true });
      } catch (error) {
        if (!res.headersSent) fail(res, error);
      }
    };

  // Avisos en vivo para la pantalla (lee el token de la cabecera: nunca va en la dirección)
  router.get('/display/events', asDisplay(null, async (_d, req, res) => { liveHandler(req, res); }));
  router.post('/display/attendance/punch', asDisplay(['ATTENDANCE'], (d, req) =>
    attendance.punch(req.body?.employeeId, req.body?.pin, `pantalla:${d.id}`, d.name)));
  router.post('/display/kiosk/order', asDisplay(['KIOSK'], (d, req) => kiosk.order(req.body, d)));

  return router;
};
