// ============================================
// INTERFACES - Rutas públicas (tienda web / menú)
// ============================================
// Solo lectura y sin datos internos: no expone costos ni inventario.

import { Router } from 'express';
import { ProductUseCases } from '../../application/usecases';

const toPublicProduct = (p: any) => ({
  ...p,
  variants: (p.variants || [])
    .filter((v: any) => v.isActive !== false)
    .map(({ cost: _cost, stock: _stock, trackInventory: _t, ...v }: any) => v),
});

export const createPublicRoutes = (productUseCases: ProductUseCases) => {
  const router = Router();

  router.get('/catalog', async (_req, res) => {
    try {
      const [products, categories] = await Promise.all([
        productUseCases.getAllProducts(),
        productUseCases.getAllCategories(),
      ]);
      res.json({
        products: (products as any[]).filter(p => p.isActive !== false && !(p.pausedUntil && new Date(p.pausedUntil) > new Date())).map(toPublicProduct),
        categories,
      });
    } catch {
      res.status(500).json({ error: 'No se pudo cargar el menú', code: 'CATALOG_ERROR' });
    }
  });

  return router;
};
