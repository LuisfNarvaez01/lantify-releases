// ============================================
// INTERFACES - Proyecta (Lantify Música): vínculo con la cabina del DJ y chat
// ============================================
// Todo vive en la nube (cloud/api-worker/src/music.ts, contrato en
// docs/integraciones/lantify-musica.md); el programa solo pasa la petición con la
// licencia del ADMIN que la hace. Solo ADMIN (regla por defecto de accessPolicy.ts).
//
//   GET  /api/proyecta              → { venue | null, tableUrl } (¿vinculado? ¿DJ conectado?)
//   POST /api/proyecta/link-code    → { code, expiresAt } para escribir en Proyecta
//   GET  /api/proyecta/chat?since=  → { messages, online }
//   POST /api/proyecta/chat         { text } → mensaje enviado (firma el nombre del usuario)
//   POST /api/proyecta/decide       { id, action } → aprobar o rechazar un pedido cuando no hay DJ (caja)
//   PUT  /api/proyecta/autopilot    AutopilotRules → piloto automático de la cabina sin DJ (ADMIN)

import { Router, Response } from 'express';
import { AuthError } from '../../application/usecases/AuthUseCases';
import type { AuthRequest } from '../../shared/authMiddleware';

export interface ProyectaCloud {
  adminCall(actorLocalId: string | undefined, method: string, path: string, body?: unknown, timeoutMs?: number): Promise<any>;
}

const sendError = (res: Response, error: any) => {
  if (error instanceof AuthError) {
    return res.status(error.statusCode).json({ error: error.message, code: error.code, ...(error.details || {}) });
  }
  console.error('[proyecta]', error);
  return res.status(500).json({ error: 'Error interno del servidor', code: 'SERVER_ERROR' });
};

export const createProyectaRoutes = (cloud: ProyectaCloud) => {
  const router = Router();
  const run = (fn: (req: AuthRequest) => Promise<unknown>, status = 200) => async (req: AuthRequest, res: Response) => {
    try {
      res.status(status).json(await fn(req));
    } catch (error) {
      sendError(res, error);
    }
  };

  router.get('/proyecta', run((req) => cloud.adminCall(req.user!.id!, 'GET', '/v1/music/mine', undefined, 15_000)));
  router.post('/proyecta/link-code', run((req) => cloud.adminCall(req.user!.id!, 'POST', '/v1/music/link-code', {}, 15_000)));
  router.get('/proyecta/chat', run((req) => {
    const since = typeof req.query.since === 'string' && /^[A-Za-z0-9_-]{1,64}$/.test(req.query.since) ? req.query.since : '';
    return cloud.adminCall(req.user!.id!, 'GET', `/v1/music/mine/chat${since ? `?since=${since}` : ''}`, undefined, 15_000);
  }));
  router.post('/proyecta/chat', run((req) => {
    const text = typeof req.body?.text === 'string' ? req.body.text.trim().slice(0, 280) : '';
    if (!text) throw new AuthError(400, 'PROYECTA_EMPTY', 'Escribe un mensaje.');
    return cloud.adminCall(req.user!.id!, 'POST', '/v1/music/mine/chat', { text, author: (req.user?.name || req.user?.username || 'Lantify').slice(0, 40) }, 15_000);
  }, 201));

  router.post('/proyecta/decide', run((req) => {
    const id = typeof req.body?.id === 'string' ? req.body.id.slice(0, 64) : '';
    const action = req.body?.action === 'approve' || req.body?.action === 'reject' ? req.body.action : '';
    if (!id || !action) throw new AuthError(400, 'PROYECTA_BAD_DECISION', 'Decisión inválida.');
    return cloud.adminCall(req.user!.id!, 'POST', '/v1/music/mine/decide', { id, action }, 15_000);
  }, 202));
  router.put('/proyecta/autopilot', run((req) => {
    const b = req.body || {};
    const n = (v: unknown, max: number, d: number) => (Number.isInteger(v) && (v as number) >= 0 && (v as number) <= max ? v : d);
    const rules = { enabled: b.enabled === true, maxPerHour: n(b.maxPerHour, 60, 12), maxPerTable: n(b.maxPerTable, 20, 3), skipOnLoadError: b.skipOnLoadError !== false };
    return cloud.adminCall(req.user!.id!, 'PUT', '/v1/music/mine/autopilot', rules, 15_000);
  }));

  return router;
};
