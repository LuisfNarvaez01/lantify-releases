// ============================================
// APP - Construcción de la aplicación Express
// ============================================
// Separado de index.ts para poder probar la API sin abrir un puerto.

import express from 'express';
import cors from 'cors';
import helmet from 'helmet';

import { prisma } from './infrastructure/database/prisma';
import { ProductRepository, SaleRepository, CashSessionRepository, TableRepository, UserRepository } from './infrastructure/persistence/repositories';
import { ProductUseCases, SaleUseCases, CashSessionUseCases, TableUseCases, AuthUseCases, DuplicateCleanupUseCases, CustomerUseCases, ExpenseCategoryUseCases, AnalyticsUseCases } from './application/usecases';
import { InventoryUseCases } from './application/usecases/InventoryUseCases';
import { ProductController, SaleController, CashSessionController, TableController, CustomerController, ExpenseCategoryController, AnalyticsController } from './interfaces/controllers';
import { InventoryController } from './interfaces/controllers/InventoryController';
import { createProductRoutes, createSaleRoutes, createCashSessionRoutes, createTableRoutes, createAuthRoutes, createProductImportRoutes, createCustomerRoutes, createExpenseCategoryRoutes, createAnalyticsRoutes } from './interfaces/routes';
import { createInventoryRoutes } from './interfaces/routes/inventoryRoutes';
import { createVersionRoutes } from './interfaces/routes/versionRoutes';
import { OrderUseCases } from './application/usecases/OrderUseCases';
import { OrderController } from './interfaces/controllers/OrderController';
import { createOrderRoutes } from './interfaces/routes/orderRoutes';
import { createSystemRoutes } from './interfaces/routes/systemRoutes';
import { createDianRoutes } from './interfaces/routes/dianRoutes';
import { createPublicRoutes } from './interfaces/routes/publicRoutes';
import { createBusinessRoutes } from './interfaces/routes/businessRoutes';
import { BusinessSettingsUseCases } from './application/usecases/BusinessSettingsUseCases';
import { CloudAuthService } from './application/usecases/CloudAuthService';
import { createCloudRoutes } from './interfaces/routes/cloudRoutes';
import { createExportRoutes } from './interfaces/routes/exportRoutes';
import { createTipsRoutes } from './interfaces/routes/tipsRoutes';
import { createExpenseRoutes } from './interfaces/routes/expenseRoutes';
import { createCommerceRoutes } from './interfaces/routes/commerceRoutes';
import { createAgentRoutes } from './interfaces/routes/agentRoutes';
import { createReservationRoutes } from './interfaces/routes/reservationRoutes';
import { ReservationSyncService } from './application/usecases/ReservationSyncService';
import { registerStampSync } from './application/usecases/stampSync';
import { createLoyaltyRoutes } from './interfaces/routes/loyaltyRoutes';
import { createPageRoutes } from './interfaces/routes/pageRoutes';
import { createOnlineOrderRoutes } from './interfaces/routes/onlineOrderRoutes';
import { createMediaRoutes } from './interfaces/routes/mediaRoutes';
import { createPrintingRoutes } from './interfaces/routes/printingRoutes';
import { createPermissionRoutes } from './interfaces/routes/permissionRoutes';
import { OnlineOrderUseCases } from './application/usecases/OnlineOrderUseCases';
import { normalizeBooking } from './domain/booking';
import { errorHandler, notFoundHandler } from './shared/errorHandler';
import { apiAccessControl } from './shared/authMiddleware';

/**
 * Orígenes permitidos: la interfaz local y, si se habilita la red local,
 * cualquier IP privada (tablets de meseros). Configurable con CORS_ORIGINS.
 */
const isAllowedOrigin = (origin: string | undefined): boolean => {
  if (!origin) return true; // misma máquina, curl, Electron
  const extra = (process.env.CORS_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);
  if (extra.includes(origin)) return true;
  try {
    const { hostname } = new URL(origin);
    if (hostname === 'localhost' || hostname === '127.0.0.1') return true;
    if (process.env.LAN_ACCESS === 'true') {
      return /^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(hostname);
    }
  } catch {
    // origen mal formado
  }
  return false;
};

export const createApp = () => {
  const app = express();

  // Solo el proxy de Vite en este mismo equipo puede indicar la IP real (X-Forwarded-For);
  // cualquier otro cliente se identifica por su socket (límites de intentos y auditoría)
  app.set('trust proxy', 'loopback');
  app.disable('x-powered-by');

  app.use(helmet({ contentSecurityPolicy: false, crossOriginResourcePolicy: { policy: 'same-site' } }));
  app.use(cors({
    origin: (origin, cb) => cb(null, isAllowedOrigin(origin)),
    credentials: true,
  }));
  // Las fotos (facturas, productos, logo) viajan en el cuerpo ya reducidas en el navegador: más margen solo ahí
  const jsonDefault = express.json({ limit: '2mb' });
  const jsonPhotos = express.json({ limit: '4mb' });
  app.use((req, res, next) => (req.path.startsWith('/api/expenses') || req.path === '/api/ai/menu' || req.path === '/api/media' ? jsonPhotos : jsonDefault)(req, res, next));

  // ============================================
  // DEPENDENCY INJECTION (Manual)
  // ============================================

  const productRepository = new ProductRepository(prisma);
  const saleRepository = new SaleRepository(prisma);
  const cashSessionRepository = new CashSessionRepository(prisma);
  const tableRepository = new TableRepository(prisma);
  const userRepository = new UserRepository(prisma);

  const cloudAuth = new CloudAuthService();
  const authUseCases = new AuthUseCases(userRepository, cloudAuth);
  const businessSettingsUseCases = new BusinessSettingsUseCases(authUseCases);
  const productUseCases = new ProductUseCases(productRepository);
  const saleUseCases = new SaleUseCases(saleRepository, productRepository, businessSettingsUseCases);
  const cashSessionUseCases = new CashSessionUseCases(cashSessionRepository);
  const tableUseCases = new TableUseCases(tableRepository);
  const duplicateCleanupUseCases = new DuplicateCleanupUseCases(productRepository);
  const customerUseCases = new CustomerUseCases();
  const expenseCategoryUseCases = new ExpenseCategoryUseCases();
  const analyticsUseCases = new AnalyticsUseCases();
  const inventoryUseCases = new InventoryUseCases();
  const orderUseCases = new OrderUseCases();

  const productController = new ProductController(productUseCases, duplicateCleanupUseCases);
  const saleController = new SaleController(saleUseCases);
  const cashSessionController = new CashSessionController(cashSessionUseCases);
  const tableController = new TableController(tableUseCases);
  const customerController = new CustomerController(customerUseCases);
  const expenseCategoryController = new ExpenseCategoryController(expenseCategoryUseCases);
  const analyticsController = new AnalyticsController(analyticsUseCases);
  const inventoryController = new InventoryController(inventoryUseCases);
  const orderController = new OrderController(orderUseCases);

  // ============================================
  // ROUTES — todo /api pasa por la política de acceso central
  // ============================================

  app.use('/api', apiAccessControl);

  app.use('/api/auth', createAuthRoutes(authUseCases));
  app.use('/api/public', createPublicRoutes(productUseCases));
  app.use('/api/products', createProductRoutes(productController));
  app.use('/api/products/import', createProductImportRoutes());
  app.use('/api/sales', createSaleRoutes(saleController));
  app.use('/api/orders', createOrderRoutes(orderController));
  app.use('/api/cash-sessions', createCashSessionRoutes(cashSessionController));
  app.use('/api/tables', createTableRoutes(tableController));
  app.use('/api/customers', createCustomerRoutes(customerController));
  app.use('/api/expense-categories', createExpenseCategoryRoutes(expenseCategoryController));
  app.use('/api/analytics', createAnalyticsRoutes(analyticsController));
  app.use('/api/inventory', createInventoryRoutes(inventoryController));
  app.use('/api/version', createVersionRoutes());
  app.use('/api/system', createSystemRoutes());
  app.use('/api/business', createBusinessRoutes(businessSettingsUseCases));
  app.use('/api/dian', createDianRoutes());
  app.use('/api/export', createExportRoutes());
  app.use('/api/tips', createTipsRoutes());

  app.get('/health', (_req, res) => {
    res.json({ status: 'OK', timestamp: new Date().toISOString() });
  });

  app.use('/api', createMediaRoutes());
  app.use('/api', createPrintingRoutes());
  app.use('/api', createPermissionRoutes());
  app.use('/api', createExpenseRoutes(cloudAuth));
  app.use('/api', createCommerceRoutes());
  app.use('/api', createAgentRoutes(cloudAuth));
  // Reservas en línea: publicar la página al guardar y subir los cambios de la caja
  // Pedidos en línea: cada cambio de la caja se sube pronto (el cliente lo ve en su enlace)
  let kickSync = () => {};
  const onlineOrders = new OnlineOrderUseCases(saleUseCases, undefined, () => kickSync());
  const reservationSync = new ReservationSyncService(cloudAuth, onlineOrders);
  // Sellos en vivo: cada venta o ajuste sube enseguida a la tarjeta digital del cliente
  registerStampSync(() => reservationSync.stampsSoon());
  app.use('/api/loyalty', createLoyaltyRoutes(customerUseCases, reservationSync));
  kickSync = () => reservationSync.kick();
  app.use('/api', createReservationRoutes(undefined, {
    afterSettingsSaved: async (req) => {
      const row = await prisma.businessSettings.findUnique({ where: { id: 'default' } });
      const settings = normalizeBooking(row?.bookingSettings ? JSON.parse(row.bookingSettings) : {});
      // Se publica al activar en línea, y también al apagarlo si ya estaba publicada (para cerrarla)
      if (!(settings.enabled && settings.online) && !row?.bookingPublishedAt) return;
      const result = await reservationSync.publish(req.user?.id);
      if (result.ok) reservationSync.kick();
      return { ...result };
    },
    afterChange: () => reservationSync.kick(),
  }));
  // Mi página: al guardar se publica (carta, perfil, juego) y se trae lo pendiente
  app.use('/api', createPageRoutes(async (req) => {
    const result = await reservationSync.publish(req.user?.id);
    if (result.ok) reservationSync.kick();
    return { ...result };
  }));
  app.use('/api', createOnlineOrderRoutes(onlineOrders));
  app.use('/api', createCloudRoutes(cloudAuth, authUseCases));
  app.use('/api', notFoundHandler);
  app.use(errorHandler);

  return { app, authUseCases, customerUseCases, expenseCategoryUseCases, cloudAuth, reservationSync };
};
