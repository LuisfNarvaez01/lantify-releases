// ============================================
// APP - Construcción de la aplicación Express
// ============================================
// Separado de index.ts para poder probar la API sin abrir un puerto.

import { AutopilotUseCases } from './application/usecases/v3/AutopilotUseCases';
import { createV3Routes } from './interfaces/routes/v3Routes';
import { createFase4Routes } from './interfaces/routes/fase4Routes';
import { FloorUseCases } from './application/usecases/v3/FloorUseCases';
import { OpsUseCases } from './application/usecases/v3/OpsUseCases';
import { StaffUseCases } from './application/usecases/v3/StaffUseCases';
import { CloseReportService } from './application/usecases/v3/CloseReportService';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import path from 'path';
import { staticDir } from './shared/runtime';

import { prisma } from './infrastructure/database/prisma';
import { ProductRepository, SaleRepository, CashSessionRepository, TableRepository, UserRepository } from './infrastructure/persistence/repositories';
import { ProductUseCases, SaleUseCases, CashSessionUseCases, TableUseCases, AuthUseCases, DuplicateCleanupUseCases, CustomerUseCases, ExpenseCategoryUseCases, AnalyticsUseCases } from './application/usecases';
import { InventoryUseCases } from './application/usecases/InventoryUseCases';
import { ProductController, SaleController, CashSessionController, TableController, CustomerController, ExpenseCategoryController, AnalyticsController } from './interfaces/controllers';
import { InventoryController } from './interfaces/controllers/InventoryController';
import { createProductRoutes, createSaleRoutes, createCashSessionRoutes, createTableRoutes, createAuthRoutes, createProductImportRoutes, createCustomerRoutes, createExpenseCategoryRoutes, createAnalyticsRoutes } from './interfaces/routes';
import { createInventoryRoutes } from './interfaces/routes/inventoryRoutes';
import { createVersionRoutes } from './interfaces/routes/versionRoutes';
import { OrderUseCases } from './application/usecases/OrderUseCases';
import { OrderController } from './interfaces/controllers/OrderController';
import { createOrderRoutes } from './interfaces/routes/orderRoutes';
import { CloudBackupService } from './application/usecases/CloudBackupService';
import { createSystemRoutes } from './interfaces/routes/systemRoutes';
import { createDianRoutes } from './interfaces/routes/dianRoutes';
import { createPublicRoutes } from './interfaces/routes/publicRoutes';
import { createBusinessRoutes } from './interfaces/routes/businessRoutes';
import { BusinessSettingsUseCases } from './application/usecases/BusinessSettingsUseCases';
import { CloudAuthService } from './application/usecases/CloudAuthService';
import { createCloudRoutes } from './interfaces/routes/cloudRoutes';
import { createExportRoutes } from './interfaces/routes/exportRoutes';
import { createTipsRoutes } from './interfaces/routes/tipsRoutes';
import { createExpenseRoutes } from './interfaces/routes/expenseRoutes';
import { createCommerceRoutes } from './interfaces/routes/commerceRoutes';
import { createAgentRoutes } from './interfaces/routes/agentRoutes';
import { createReservationRoutes } from './interfaces/routes/reservationRoutes';
import { ReservationSyncService } from './application/usecases/ReservationSyncService';
import { registerStampSync } from './application/usecases/stampSync';
import { createLoyaltyRoutes } from './interfaces/routes/loyaltyRoutes';
import { createPageRoutes } from './interfaces/routes/pageRoutes';
import { createOnlineOrderRoutes } from './interfaces/routes/onlineOrderRoutes';
import { createLocalScreensRoutes } from './interfaces/routes/localScreensRoutes';
import { createTableDoorRoutes } from './interfaces/routes/tableDoorRoutes';
import { TableOrderUseCases } from './application/usecases/TableOrderUseCases';
import { createTransferRoutes } from './interfaces/routes/transferRoutes';
import { createGestionRoutes } from './interfaces/routes/gestionRoutes';
import { IncomingTransferUseCases } from './application/usecases/IncomingTransferUseCases';
import { LanAnnouncer } from './infrastructure/services/LanAnnouncer';
import { featureAllowed } from './shared/featureStore';
import { tenantTag } from './domain/lanDiscovery';
import { createMediaRoutes } from './interfaces/routes/mediaRoutes';
import { createPrintingRoutes } from './interfaces/routes/printingRoutes';
import { createPermissionRoutes, lanAddresses } from './interfaces/routes/permissionRoutes';
import { createRelayRoutes } from './interfaces/routes/relayRoutes';
import { RelayHostService, RELAY_HEADER, RELAY_MARK } from './application/usecases/RelayHostService';
import fs from 'fs';
import { versionFile } from './shared/runtime';
import { createNotificationRoutes } from './interfaces/routes/notificationRoutes';
import { createSetupGuideRoutes } from './interfaces/routes/setupGuideRoutes';
import { OnlineOrderUseCases } from './application/usecases/OnlineOrderUseCases';
import { normalizeBooking } from './domain/booking';
import { errorHandler, notFoundHandler } from './shared/errorHandler';
import { apiAccessControl } from './shared/authMiddleware';
import { liveAfterChange, liveHandler } from './shared/liveEvents';
import { onCatalogChange } from './shared/catalogEvents';

/**
 * Orígenes permitidos: la interfaz local y, si se habilita la red local,
 * cualquier IP privada (tablets de meseros). Configurable con CORS_ORIGINS.
 */
const APP_ORIGINS = new Set(['https://appassets.androidplatform.net', 'https://lantifypos.com', 'https://lantifypos.dpdns.org', ...(process.env.LANTIFY_APP_ORIGINS || '').split(',').map((s) => s.trim()).filter(Boolean)]);

const isAllowedOrigin = (origin: string | undefined): boolean => {
  if (!origin) return true; // misma máquina, curl, Electron
  const extra = (process.env.CORS_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);
  if (extra.includes(origin)) return true;
  try {
    const { hostname } = new URL(origin);
    if (hostname === 'localhost' || hostname === '127.0.0.1') return true;
    if (process.env.LAN_ACCESS === 'true') {
      // La app de Lantify en el celular (Android: archivos propios; iPhone: versión web) habla
      // directo con la caja en la red local; igual necesita usuario y token como cualquiera
      if (APP_ORIGINS.has(origin)) return true;
      return /^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(hostname);
    }
  } catch {
    // origen mal formado
  }
  return false;
};

export const createApp = () => {
  const app = express();

  // Solo el proxy de Vite en este mismo equipo puede indicar la IP real (X-Forwarded-For);
  // cualquier otro cliente se identifica por su socket (límites de intentos y auditoría)
  app.set('trust proxy', 'loopback');
  app.disable('x-powered-by');

  app.use(helmet({ contentSecurityPolicy: false, crossOriginResourcePolicy: { policy: 'same-site' } }));
  // Las fotos de productos se ven también en la app del celular (otro origen)
  app.use('/api/media', (_req, res, next) => { res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin'); next(); });
  app.use(cors({
    origin: (origin, cb) => cb(null, isAllowedOrigin(origin)),
    credentials: true,
  }));
  // Peticiones que llegan por el relevo de internet: cuentan como de otro equipo (celular)
  app.use((req, _res, next) => {
    const mark = req.headers[RELAY_HEADER];
    if (mark !== undefined) {
      if (mark === RELAY_MARK) (req as any).viaRelay = true;
      delete req.headers[RELAY_HEADER];
    }
    next();
  });
  // Las fotos (facturas, productos, logo) viajan en el cuerpo ya reducidas en el navegador: más margen solo ahí
  const jsonDefault = express.json({ limit: '2mb' });
  const jsonPhotos = express.json({ limit: '4mb' });
  app.use((req, res, next) => (req.path.startsWith('/api/expenses') || req.path === '/api/ai/menu' || req.path === '/api/media' || req.path.startsWith('/api/menu-transfer') ? jsonPhotos : jsonDefault)(req, res, next));

  // ============================================
  // DEPENDENCY INJECTION (Manual)
  // ============================================

  const productRepository = new ProductRepository(prisma);
  const saleRepository = new SaleRepository(prisma);
  const cashSessionRepository = new CashSessionRepository(prisma);
  const tableRepository = new TableRepository(prisma);
  const userRepository = new UserRepository(prisma);

  const cloudAuth = new CloudAuthService();
  // Relevo de meseros por internet: la caja se conecta a la nube solo si hay celulares vinculados
  const apiPort = () => Number(process.env.PORT) || 5000;
  const relayLan = () => (process.env.LAN_ACCESS === 'true' ? lanAddresses().map((ip) => `http://${ip}:${apiPort()}`) : []);
  const relayHost = new RelayHostService(cloudAuth, {
    port: apiPort,
    lan: relayLan,
    version: () => { try { return JSON.parse(fs.readFileSync(versionFile(), 'utf-8')).version || ''; } catch { return ''; } },
  });
  const cloudBackup = new CloudBackupService(cloudAuth);
  const authUseCases = new AuthUseCases(userRepository, cloudAuth);
  const businessSettingsUseCases = new BusinessSettingsUseCases(authUseCases);
  const productUseCases = new ProductUseCases(productRepository);
  const saleUseCases = new SaleUseCases(saleRepository, productRepository, businessSettingsUseCases);
  const cashSessionUseCases = new CashSessionUseCases(cashSessionRepository);
  const tableUseCases = new TableUseCases(tableRepository);
  const duplicateCleanupUseCases = new DuplicateCleanupUseCases(productRepository);
  const customerUseCases = new CustomerUseCases();
  const expenseCategoryUseCases = new ExpenseCategoryUseCases();
  const analyticsUseCases = new AnalyticsUseCases();
  const inventoryUseCases = new InventoryUseCases();
  const orderUseCases = new OrderUseCases();

  const productController = new ProductController(productUseCases, duplicateCleanupUseCases);
  const saleController = new SaleController(saleUseCases);
  // Lantify 3.0: salón, operación, personal y reporte de cierre
  const staffUseCases = new StaffUseCases();
  const closeReport = new CloseReportService(cloudAuth);
  const autopilot = new AutopilotUseCases(cloudAuth);
  const v3 = { floor: new FloorUseCases(), ops: new OpsUseCases(), staff: staffUseCases, closeReport, autopilot };
  const cashSessionController = new CashSessionController(cashSessionUseCases, {
    onClosed: async (sessionId) => {
      await staffUseCases.closeOpenShifts();
      await closeReport.onClosed(sessionId);
    },
  });
  const tableController = new TableController(tableUseCases);
  const customerController = new CustomerController(customerUseCases);
  const expenseCategoryController = new ExpenseCategoryController(expenseCategoryUseCases);
  const analyticsController = new AnalyticsController(analyticsUseCases);
  const inventoryController = new InventoryController(inventoryUseCases);
  const orderController = new OrderController(orderUseCases);

  // ============================================
  // ROUTES — todo /api pasa por la política de acceso central
  // ============================================

  app.use('/api', apiAccessControl);
  // Avisos en vivo: las pantallas se enteran al instante de lo que cambia
  app.get('/api/events', liveHandler);
  app.use('/api', liveAfterChange);

  app.use('/api/auth', createAuthRoutes(authUseCases));
  app.use('/api', createV3Routes(v3));
  app.use('/api', createFase4Routes());
  app.use('/api', createLocalScreensRoutes());
  app.use('/api/public', createPublicRoutes(productUseCases));
  app.use('/api/products', createProductRoutes(productController));
  app.use('/api/products/import', createProductImportRoutes());
  // Resumen del día (inicio de Administración): va bajo /sales para que esté en todos los planes
  app.get('/api/sales/day-summary', analyticsController.getDaySummary.bind(analyticsController));
  app.use('/api/sales', createSaleRoutes(saleController));
  app.use('/api/orders', createOrderRoutes(orderController));
  app.use('/api/cash-sessions', createCashSessionRoutes(cashSessionController));
  app.use('/api/tables', createTableRoutes(tableController));
  app.use('/api/customers', createCustomerRoutes(customerController));
  app.use('/api/expense-categories', createExpenseCategoryRoutes(expenseCategoryController));
  app.use('/api/analytics', createAnalyticsRoutes(analyticsController));
  app.use('/api/inventory', createInventoryRoutes(inventoryController));
  app.use('/api/version', createVersionRoutes());
  app.use('/api/system', createSystemRoutes(cloudBackup));
  app.use('/api/business', createBusinessRoutes(businessSettingsUseCases));
  app.use('/api/dian', createDianRoutes());
  app.use('/api/export', createExportRoutes());
  app.use('/api/tips', createTipsRoutes());

  // tenant: huella del negocio (la app del celular comprueba que una caja encontrada en la red es la suya)
  app.get('/health', async (_req, res) => {
    const tenant = await cloudAuth.linkedTenant().then((t) => tenantTag(t?.code)).catch(() => '');
    res.json({ status: 'OK', timestamp: new Date().toISOString(), tenant });
  });

  app.use('/api', createMediaRoutes());
  app.use('/api', createPrintingRoutes());
  app.use('/api', createPermissionRoutes());
  app.use('/api', createRelayRoutes(relayHost, relayLan));
  app.use('/api', createNotificationRoutes());
  app.use('/api', createSetupGuideRoutes());
  app.use('/api', createExpenseRoutes(cloudAuth));
  app.use('/api', createCommerceRoutes());
  app.use('/api', createAgentRoutes(cloudAuth));
  // Reservas en línea: publicar la página al guardar y subir los cambios de la caja
  // Pedidos en línea: cada cambio de la caja se sube pronto (el cliente lo ve en su enlace)
  let kickSync = () => {};
  const onlineOrders = new OnlineOrderUseCases(saleUseCases, undefined, () => kickSync());
  // Pedido desde la mesa (Fase 4): aceptar o rechazar se sube pronto; los QR se publican con la página
  const tableOrders = new TableOrderUseCases(undefined, onlineOrders, () => kickSync());
  const reservationSync = new ReservationSyncService(cloudAuth, onlineOrders, tableOrders);
  // Sellos en vivo: cada venta o ajuste sube enseguida a la tarjeta digital del cliente
  registerStampSync(() => reservationSync.stampsSoon());
  app.use('/api/loyalty', createLoyaltyRoutes(customerUseCases, reservationSync));
  kickSync = () => {
    // El estado del pedido sube por el camino rápido; lo demás, con la sincronización normal
    reservationSync.ordersSoon();
    reservationSync.kick();
  };
  // Autopilot pausó o reactivó productos: la página se vuelve a publicar ya
  onCatalogChange(() => reservationSync.kick());
  app.use('/api', createReservationRoutes(undefined, {
    afterSettingsSaved: async (req) => {
      const row = await prisma.businessSettings.findUnique({ where: { id: 'default' } });
      const settings = normalizeBooking(row?.bookingSettings ? JSON.parse(row.bookingSettings) : {});
      // Se publica al activar en línea, y también al apagarlo si ya estaba publicada (para cerrarla)
      if (!(settings.enabled && settings.online) && !row?.bookingPublishedAt) return;
      const result = await reservationSync.publish(req.user?.id);
      if (result.ok) reservationSync.kick();
      return { ...result };
    },
    afterChange: () => reservationSync.kick(),
  }));
  // Mi página: al guardar se publica (carta, perfil, juego) y se trae lo pendiente
  app.use('/api', createPageRoutes(async (req) => {
    const result = await reservationSync.publish(req.user?.id);
    if (result.ok) reservationSync.kick();
    return { ...result };
  }));
  app.use('/api', createOnlineOrderRoutes(onlineOrders));
  app.use('/api', createTableDoorRoutes(tableOrders));
  // Fase 4 · transferencias confirmadas con el aviso del banco
  const transfers = new IncomingTransferUseCases();
  app.use('/api', createTransferRoutes(transfers));
  // Fase 4 · gestión: exportación contable y copiar la carta entre sedes (solo lectura de ventas)
  app.use('/api', createGestionRoutes());
  app.use('/api', createCloudRoutes(cloudAuth, authUseCases));
  app.use('/api', notFoundHandler);

  // Programa instalado: el mismo servidor entrega la interfaz, así las tablets entran por http://IP:5000
  const ui = staticDir();
  if (ui) {
    app.use(express.static(ui, { index: false, maxAge: '30d', immutable: true }));
    app.get(/^(?!\/api\/).*/, (_req, res) => res.sendFile(path.join(ui, 'index.html'), { headers: { 'Cache-Control': 'no-cache' } }));
  }
  app.use(errorHandler);

  // Reportes de cierre pendientes: se reintentan cada 5 minutos (no en pruebas)
  if (process.env.NODE_ENV !== 'test') setInterval(() => { closeReport.flush().catch(() => undefined); }, 5 * 60_000).unref();
  // Autopilot: lee el momento cada minuto (solo si está encendido; todo en este equipo)
  if (process.env.NODE_ENV !== 'test') setInterval(() => { autopilot.tick().catch((e) => console.warn('[autopilot]', e?.message || e)); }, 60_000).unref();

  // Transferencias leídas: se borran a las 24 h (cada hora, no en pruebas)
  if (process.env.NODE_ENV !== 'test') setInterval(() => { transfers.purge().catch((e) => console.warn('[transferencias]', e?.message || e)); }, 60 * 60_000).unref();

  // La caja se anuncia en la red local (mDNS) para que la app del celular la encuentre sola
  const lanAnnouncer = new LanAnnouncer({
    port: apiPort,
    version: () => { try { return JSON.parse(fs.readFileSync(versionFile(), 'utf-8')).version || ''; } catch { return ''; } },
    tenantCode: async () => (await cloudAuth.linkedTenant())?.code ?? null,
    enabled: () => featureAllowed('lan_discovery'),
  });

  return { app, authUseCases, customerUseCases, expenseCategoryUseCases, cloudAuth, reservationSync, cloudBackup, closeReport, relayHost, transfers, lanAnnouncer };
};
