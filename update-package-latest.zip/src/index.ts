// ============================================
// MAIN ENTRY POINT - POS System
// ============================================

import dotenv from 'dotenv';
dotenv.config();

import { prisma } from './infrastructure/database/prisma';
import { dianService } from './infrastructure/services/DianElectronicBillingService';
import { createApp } from './app';
import { getJwtSecret } from './shared/security/secrets';
import { REFRESH_INTERVAL_MS } from './shared/cloud/config';
import { touchClock } from './shared/cloud/license';
import fs from 'fs';
import path from 'path';
import { isDesktop } from './shared/runtime';
import { tellDesktop } from './shared/desktop';

// El paquete de actualización trae el actualizador como update.new.bat: reemplazarlo
// mientras corre lo dañaría, así que se pone en su lugar al arrancar el servidor
// (solo en instalaciones antiguas; el programa instalado se actualiza con la app de escritorio)
if (!isDesktop()) {
  try {
    const root = path.resolve(__dirname, '..');
    const next = path.join(root, 'update.new.bat');
    if (fs.existsSync(next)) fs.renameSync(next, path.join(root, 'update.bat'));
  } catch (e: any) {
    console.warn('[Actualizador]', e.message);
  }
}

const PORT = Number(process.env.PORT) || 5000;
// Por defecto solo este equipo. Para tablets en la red local: LAN_ACCESS=true
const HOST = process.env.LAN_ACCESS === 'true' ? '0.0.0.0' : '127.0.0.1';

const { app, authUseCases, customerUseCases, expenseCategoryUseCases, cloudAuth, reservationSync, cloudBackup } = createApp();

// Renovación de licencias con Lantify Cloud (cada 6 h, y al poco de arrancar).
// Sin internet no pasa nada: la venta sigue y se reintenta en el siguiente ciclo.
const refreshLicenses = async () => {
  try {
    if (!(await cloudAuth.linkedTenant())) return;
    const r = await cloudAuth.refreshAll();
    if (r.renewed || r.revoked || r.suspended) {
      console.log(`☁️  Licencias: ${r.renewed} renovadas, ${r.revoked} revocadas${r.suspended ? ', suscripción suspendida' : ''}`);
    }
  } catch (e: any) {
    console.warn('[Cloud] Renovación de licencias:', e.message);
  }
};

const startServer = async () => {
  try {
    await prisma.$connect();
    console.log('✅ Database connected');

    // Genera los secretos de la instalación si no existen
    getJwtSecret();

    // Ya no se crean usuarios con claves de fábrica
    await authUseCases.enforceNoDefaultCredentials();

    // Inicializar cliente común y categorías por defecto
    await customerUseCases.ensureDefaultCustomer();
    await expenseCategoryUseCases.ensureDefaults();
    console.log('✅ Default data initialized (Customers & Expense Categories)');

    // Asegurar configuración DIAN inicial (y cifrar secretos guardados en texto plano por versiones anteriores)
    const dianConfig = await dianService.getConfig();
    await dianService.updateConfig({
      factusClientSecret: dianConfig.factusClientSecret ?? undefined,
      factusPassword: dianConfig.factusPassword ?? undefined,
      factusToken: dianConfig.factusToken ?? undefined,
      certificatePassword: dianConfig.certificatePassword ?? undefined,
      softwarePin: dianConfig.softwarePin ?? undefined,
      technicalKey: dianConfig.technicalKey ?? undefined,
    });
    // Datos de prueba que dejaron versiones anteriores (resolución SETP, responsable de ejemplo)
    if (await dianService.clearSampleData()) console.log('🧹 DIAN: se borraron los datos de ejemplo de la configuración');

    // Background worker for DIAN queue (Offline-first automatic sync every 60s)
    setInterval(async () => {
      try {
        await dianService.processQueue();
      } catch (e: any) {
        console.warn('[DIAN Worker] Sincronización en segundo plano:', e.message);
      }
    }, 60000);

    // Reservas en línea: trae las de la página y sube las de la caja (cada minuto)
    reservationSync.start();
    // Copia liviana y cifrada en Lantify Cloud: una al día y al cerrar la caja (reemplaza la anterior)
    cloudBackup.start();

    setTimeout(refreshLicenses, 30000);
    setInterval(refreshLicenses, REFRESH_INTERVAL_MS);
    // El reloj "visto" solo avanza: así se detecta si alguien atrasa la hora del equipo
    setInterval(() => { try { touchClock(); } catch { /* sin almacenamiento */ } }, 10 * 60 * 1000);

    const server = app.listen(PORT, HOST, () => {
      console.log(`🚀 Server running on http://localhost:${PORT}${HOST === '0.0.0.0' ? ' (red local habilitada)' : ' (solo este equipo)'}`);
      tellDesktop('server:ready', { port: PORT, lan: HOST === '0.0.0.0' });
    });
    // Puerto ocupado (p. ej. una instalación antigua abierta): la app de escritorio lo explica
    server.on('error', (e: any) => {
      console.error('❌ No se pudo abrir el puerto', PORT, e.message);
      tellDesktop('server:error', { code: e.code, message: e.message });
      if (isDesktop()) setTimeout(() => process.exit(1), 300);
    });
    // "localhost" puede resolverse a IPv6 (::1) en el navegador: también se escucha ahí
    if (HOST === '127.0.0.1') {
      app.listen(PORT, '::1').on('error', () => {
        // equipo sin IPv6: basta con 127.0.0.1
      });
    }
  } catch (error) {
    console.error('❌ Failed to start server:', error);
    tellDesktop('server:error', { code: 'START_FAILED', message: (error as any)?.message || String(error) });
    setTimeout(() => process.exit(1), 300);
  }
};

startServer();

export default app;
