// ============================================
// SHARED - Conexión con Lantify Cloud
// ============================================
// Las direcciones se pueden cambiar con variables de entorno (por ejemplo, al
// comprar un dominio). Cambiarlas no permite saltarse la licencia: una nube falsa
// no puede firmar licencias válidas sin la clave privada.

export const cloudConfig = () => ({
  apiUrl: (process.env.LANTIFY_CLOUD_URL || 'https://api.lantifypos.dpdns.org').replace(/\/+$/, ''),
  aiUrl: (process.env.LANTIFY_AI_URL || 'https://lantify-ai.lantifypos.workers.dev').replace(/\/+$/, ''),
  // Clave compartida del asistente, solo para instalaciones sin vincular (modo local)
  aiToken: process.env.LANTIFY_AI_TOKEN || '',
  /**
   * En el instalador (Fase 8) este valor queda fijo en true: sin un negocio vinculado
   * a la nube no se puede iniciar sesión. En desarrollo se puede trabajar en modo local.
   */
  licenseRequired: process.env.LANTIFY_REQUIRE_LICENSE === 'true',
  timeoutMs: Number(process.env.LANTIFY_CLOUD_TIMEOUT_MS) || 12000,
});

export const OFFLINE_CLOCK_TOLERANCE_MS = 10 * 60 * 1000; // el reloj puede retroceder hasta 10 min
export const REFRESH_INTERVAL_MS = 6 * 60 * 60 * 1000;
