// ============================================
// Clave PÚBLICA de las licencias de Lantify Cloud (Ed25519)
// ============================================
// Generada con cloud/api-worker/scripts/generate-keys.mjs el 2026-10-22.
// Solo verifica licencias; no permite fabricarlas. Va dentro del código (no en .env)
// para que nadie pueda reemplazarla por una propia y firmar licencias falsas.
export const LICENSE_PUBLIC_JWK = {"kty":"OKP","crv":"Ed25519","x":"X60yvFMS69-CEZOo6OqymzopFDZDP7IS3gHPmX0LZpE"} as const;
