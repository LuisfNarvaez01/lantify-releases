// ============================================
// SHARED - Verificación y almacenamiento de licencias
// ============================================
// La licencia es un JWS firmado por Lantify Cloud con Ed25519. Este equipo solo
// tiene la clave PÚBLICA: puede comprobarla, pero no fabricarla ni modificarla.

import crypto from 'crypto';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { LICENSE_PUBLIC_JWK } from './licensePublicKey';
import { getDataDir, getEncryptionKey } from '../security/secrets';
import { OFFLINE_CLOCK_TOLERANCE_MS } from './config';

export interface LicenseClaims {
  iss: 'lantify-cloud';
  typ: 'license';
  sub: string;
  tid: string;
  tcode: string;
  tname: string;
  usr: string;
  name: string;
  role: 'ADMIN' | 'CASHIER' | 'WAITER';
  tv: number;
  plan: string;
  features: string[];
  limits: { users: number; devices: number; ai: number };
  subStatus: 'TRIAL' | 'ACTIVE' | 'PAST_DUE' | 'GRACE' | 'SUSPENDED';
  periodEnd: string | null;
  graceUntil: string | null;
  did: string;
  iat: number;
  exp: number;
  olu: number;
}

// ── Verificación ────────────────────────────────────────────

let publicKey: crypto.KeyObject = crypto.createPublicKey({ key: LICENSE_PUBLIC_JWK as any, format: 'jwk' });

/** Solo para pruebas: la nube de prueba firma con otra clave */
export const __setLicensePublicKeyForTests = (jwk: string) => {
  if (process.env.NODE_ENV !== 'test') throw new Error('Solo en pruebas');
  publicKey = crypto.createPublicKey({ key: JSON.parse(jwk), format: 'jwk' });
};

const b64urlJson = (part: string) => JSON.parse(Buffer.from(part, 'base64url').toString('utf-8'));

/** Devuelve las claims solo si la firma es válida y la licencia tiene la forma esperada */
export const verifyLicense = (token: string): LicenseClaims | null => {
  if (typeof token !== 'string') return null;
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  try {
    if (b64urlJson(parts[0]).alg !== 'EdDSA') return null;
    const ok = crypto.verify(null, Buffer.from(`${parts[0]}.${parts[1]}`), publicKey, Buffer.from(parts[2], 'base64url'));
    if (!ok) return null;
    const claims = b64urlJson(parts[1]) as LicenseClaims;
    if (claims.iss !== 'lantify-cloud' || claims.typ !== 'license' || !claims.sub || !claims.tid || !Array.isArray(claims.features)) return null;
    return claims;
  } catch {
    return null;
  }
};

// ── Identidad del equipo ────────────────────────────────────

/** Huella estable de esta instalación (no identifica a la persona, solo al equipo) */
export const deviceFingerprint = () => {
  const file = path.join(getDataDir(), 'device.json');
  let id: string;
  try {
    id = JSON.parse(fs.readFileSync(file, 'utf-8')).id;
  } catch {
    id = crypto.randomUUID();
    fs.mkdirSync(getDataDir(), { recursive: true });
    fs.writeFileSync(file, JSON.stringify({ id, createdAt: new Date().toISOString() }), { mode: 0o600 });
  }
  return crypto.createHash('sha256').update(`${id}|${os.hostname()}`).digest('hex');
};

export const deviceName = () => os.hostname().slice(0, 60);

// ── Almacén cifrado ─────────────────────────────────────────
// Guarda la última licencia de cada usuario (para el ingreso sin conexión) y el
// mayor instante visto, firmado por el cifrado: si el reloj retrocede, se nota.

interface StoredLicense {
  token: string;
  savedAt: string;
}

interface LicenseStore {
  users: Record<string, StoredLicense>; // por id de usuario en la nube
  lastSeenAt: number;
  lastSyncAt: number | null;
  suspended?: { at: number; graceUntil: string | null } | null;
}

const storeFile = () => path.join(getDataDir(), 'license.dat');
const EMPTY: LicenseStore = { users: {}, lastSeenAt: 0, lastSyncAt: null, suspended: null };

const encrypt = (data: LicenseStore) => {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', getEncryptionKey(), iv);
  const body = Buffer.concat([cipher.update(JSON.stringify(data), 'utf-8'), cipher.final()]);
  return Buffer.concat([iv, cipher.getAuthTag(), body]).toString('base64');
};

const decrypt = (raw: string): LicenseStore => {
  const buf = Buffer.from(raw, 'base64');
  const decipher = crypto.createDecipheriv('aes-256-gcm', getEncryptionKey(), buf.subarray(0, 12));
  decipher.setAuthTag(buf.subarray(12, 28));
  return JSON.parse(Buffer.concat([decipher.update(buf.subarray(28)), decipher.final()]).toString('utf-8'));
};

export const readStore = (): LicenseStore => {
  try {
    return { ...EMPTY, ...decrypt(fs.readFileSync(storeFile(), 'utf-8')) };
  } catch {
    // Archivo ausente o manipulado: se trata como vacío (obliga a conectarse)
    return { ...EMPTY, users: {} };
  }
};

const writeStore = (store: LicenseStore) => {
  fs.mkdirSync(getDataDir(), { recursive: true });
  fs.writeFileSync(storeFile(), encrypt(store), { mode: 0o600 });
};

/** Registra que el reloj llegó hasta ahora (solo avanza) */
export const touchClock = (now = Date.now()) => {
  const store = readStore();
  if (now > store.lastSeenAt) {
    store.lastSeenAt = now;
    writeStore(store);
  }
};

export const saveLicense = (token: string, claims: LicenseClaims, now = Date.now()) => {
  const store = readStore();
  store.users[claims.sub] = { token, savedAt: new Date(now).toISOString() };
  store.lastSeenAt = Math.max(store.lastSeenAt, now);
  store.lastSyncAt = now;
  store.suspended = claims.subStatus === 'SUSPENDED' ? { at: now, graceUntil: claims.graceUntil } : null;
  writeStore(store);
};

export const removeLicense = (cloudUserId: string) => {
  const store = readStore();
  delete store.users[cloudUserId];
  writeStore(store);
};

export const markSuspended = (graceUntil: string | null, now = Date.now()) => {
  const store = readStore();
  store.suspended = { at: now, graceUntil };
  writeStore(store);
};

export const clearStore = () => {
  try {
    fs.rmSync(storeFile());
  } catch {
    // no existía
  }
};

export const storedLicenseFor = (cloudUserId: string): { token: string; claims: LicenseClaims } | null => {
  const entry = readStore().users[cloudUserId];
  if (!entry) return null;
  const claims = verifyLicense(entry.token);
  return claims ? { token: entry.token, claims } : null;
};

export const allStoredLicenses = () =>
  Object.entries(readStore().users)
    .map(([userId, entry]) => ({ userId, token: entry.token, claims: verifyLicense(entry.token) }))
    .filter((x): x is { userId: string; token: string; claims: LicenseClaims } => !!x.claims);

/**
 * ¿Se puede iniciar sesión sin conexión con esta licencia?
 * Dentro de la ventana offline, sin retroceso del reloj y sin suspensión.
 */
export const offlineLoginCheck = (claims: LicenseClaims, store: Pick<LicenseStore, 'lastSeenAt' | 'suspended'>, now = Date.now()) => {
  if (now + OFFLINE_CLOCK_TOLERANCE_MS < store.lastSeenAt) return 'CLOUD_CLOCK_TAMPERED' as const;
  if (store.suspended || claims.subStatus === 'SUSPENDED') return 'CLOUD_SUBSCRIPTION_SUSPENDED' as const;
  if (now > claims.olu * 1000) return 'CLOUD_OFFLINE_WINDOW_EXPIRED' as const;
  return null;
};
