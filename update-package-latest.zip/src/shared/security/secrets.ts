// ============================================
// SHARED - Secretos por instalación
// ============================================
// Cada instalación genera su propio secreto JWT y su clave de cifrado la primera
// vez que arranca. Nunca hay un valor por defecto compartido entre equipos.

import crypto from 'crypto';
import fs from 'fs';
import path from 'path';

interface InstallSecrets {
  jwtSecret: string;
  encryptionKey: string; // 32 bytes en base64 (AES-256-GCM)
  createdAt: string;
}

// Valores que alguna vez estuvieron escritos en el código o en .env.example
const KNOWN_WEAK_SECRETS = new Set([
  'pos-secret-key-2024',
  'your-secret-key-here',
  'pos-local-secret-key-2024',
  'secret',
  'changeme',
]);

// Raíz del proyecto (src/shared/security → ../../..; igual desde dist/), no el directorio de arranque:
// si se generara otra clave por arrancar desde otra carpeta, los secretos DIAN cifrados no se podrían leer.
export const getDataDir = (): string =>
  process.env.LANTIFY_DATA_DIR || path.resolve(__dirname, '..', '..', '..', '.lantify');

let cached: InstallSecrets | null = null;

const loadOrCreate = (): InstallSecrets => {
  if (cached) return cached;

  const dir = getDataDir();
  const file = path.join(dir, 'secrets.json');

  if (fs.existsSync(file)) {
    const parsed = JSON.parse(fs.readFileSync(file, 'utf-8')) as InstallSecrets;
    if (parsed.jwtSecret && parsed.encryptionKey) {
      cached = parsed;
      return parsed;
    }
  }

  fs.mkdirSync(dir, { recursive: true });
  const created: InstallSecrets = {
    jwtSecret: crypto.randomBytes(64).toString('base64'),
    encryptionKey: crypto.randomBytes(32).toString('base64'),
    createdAt: new Date().toISOString(),
  };
  fs.writeFileSync(file, JSON.stringify(created, null, 2), { encoding: 'utf-8', mode: 0o600 });
  console.log(`🔐 Secretos de instalación generados en ${file}`);
  cached = created;
  return created;
};

/** Secreto JWT: usa JWT_SECRET del entorno solo si es fuerte; si no, el de la instalación. */
export const getJwtSecret = (): string => {
  const fromEnv = process.env.JWT_SECRET?.trim();
  if (fromEnv && fromEnv.length >= 32 && !KNOWN_WEAK_SECRETS.has(fromEnv)) {
    return fromEnv;
  }
  return loadOrCreate().jwtSecret;
};

export const getEncryptionKey = (): Buffer => Buffer.from(loadOrCreate().encryptionKey, 'base64');

/** Solo para pruebas */
export const __resetSecretsCache = () => {
  cached = null;
};
