// ============================================
// SHARED - Límites de intentos (fuerza bruta)
// ============================================
// Se crean por instancia de la app (fábricas) para que las pruebas no compartan contadores.

import rateLimit from 'express-rate-limit';

const message = (error: string, code: string) => ({ error, code });

/** Login y verificación de clave admin: 5 intentos por minuto por equipo */
export const createLoginLimiter = () => rateLimit({
  windowMs: 60 * 1000,
  limit: 5,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  skipSuccessfulRequests: true,
  message: message('Demasiados intentos. Espera un minuto antes de volver a intentarlo.', 'AUTH_RATE_LIMITED'),
});

/** Bloqueo prolongado: 20 intentos fallidos en 15 minutos */
export const createLoginLongLimiter = () => rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 20,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  skipSuccessfulRequests: true,
  message: message('Demasiados intentos fallidos. El acceso desde este equipo se bloqueó durante 15 minutos.', 'AUTH_RATE_LIMITED'),
});

/** Endpoints públicos que escriben (pedidos de la tienda web) */
export const createPublicWriteLimiter = () => rateLimit({
  windowMs: 60 * 1000,
  limit: 10,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: message('Demasiadas solicitudes. Intenta de nuevo en un momento.', 'RATE_LIMITED'),
});
