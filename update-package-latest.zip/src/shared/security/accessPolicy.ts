// ============================================
// SHARED - Política central de acceso a la API
// ============================================
// Una sola tabla define quién puede llamar cada endpoint. Se evalúa en orden
// y gana la primera regla que coincide. Lo que no aparece aquí queda solo para
// ADMIN (falla cerrada): un endpoint nuevo nunca queda abierto por olvido.
// Las reglas con can(...) dependen de las funciones que el ADMIN dio a cada rol
// (src/domain/rolePermissions.ts); el ADMIN siempre pasa.

import type { Permission } from '../../domain/rolePermissions';

/** DOOR (Fase 4): el portero; solo usa la pantalla Puerta (nunca entra en ALL) */
export type Role = 'ADMIN' | 'CASHIER' | 'WAITER' | 'DOOR';
export type Access = 'public' | 'authenticated' | Role[] | { anyOf: Permission[] };

interface Rule {
  methods: string[] | '*';
  path: RegExp;
  access: Access;
}

const ALL: Role[] = ['ADMIN', 'CASHIER', 'WAITER'];

/** Pasa quien tenga alguna de estas funciones */
const can = (...anyOf: Permission[]): Access => ({ anyOf });

const rule = (methods: string | string[], path: RegExp, access: Access): Rule => ({
  methods: methods === '*' ? '*' : (Array.isArray(methods) ? methods : [methods]),
  path,
  access,
});

// Las rutas son relativas a /api
export const ACCESS_RULES: Rule[] = [
  // ── Público ──────────────────────────────────────────────
  rule('POST', /^\/auth\/login$/, 'public'),
  rule('GET', /^\/auth\/setup-status$/, 'public'),
  rule('POST', /^\/auth\/setup$/, 'public'), // solo funciona si no existe ningún usuario
  rule('GET', /^\/version$/, 'public'),
  rule('GET', /^\/public\/catalog$/, 'public'), // menú de la tienda web (sin costos)
  rule('GET', /^\/cloud\/status$/, 'public'),           // ¿negocio vinculado a Lantify Cloud?
  rule('POST', /^\/cloud\/activate$/, 'public'),        // solo funciona mientras no haya negocio vinculado
  rule('GET', /^\/export\/[a-z-]+\.csv$/, 'public'),     // exige su propio permiso de exportación (exportRoutes.ts)
  rule('GET', /^\/media\/[0-9a-f]{32}\.(webp|jpg|png)$/, 'public'), // fotos de productos y logo (las muestran <img>)

  // ── Sesión (cualquier usuario autenticado) ───────────────
  rule('GET', /^\/auth\/verify$/, 'authenticated'),
  rule('POST', /^\/auth\/change-password$/, 'authenticated'),
  rule('POST', /^\/auth\/verify-admin$/, 'authenticated'),
  rule('GET', /^\/version\/check$/, 'authenticated'),
  rule('GET', /^\/license$/, 'authenticated'),
  rule('POST', /^\/ai\/chat$/, 'authenticated'),
  rule('GET', /^\/ai\/settings$/, 'authenticated'),

  // ── Datos del negocio (ticket, impuestos, módulos): lectura para todos ─
  rule('GET', /^\/business$/, ALL),

  // ── Impresión: todos imprimen; elegir impresoras es del ADMIN ─
  rule('GET', /^\/printing\/settings$/, ALL),
  rule('POST', /^\/printing\/print$/, ALL),
  rule('POST', /^\/tickets\/share$/, ALL),             // enlace de la cuenta para WhatsApp

  // ── Usuarios: solo ADMIN ──────────────────────────────────
  rule('*', /^\/auth\//, ['ADMIN']),

  // ── Catálogo: lectura para todos ─────────────────────────
  rule('GET', /^\/products\/import\/template$/, ['ADMIN']),
  rule('GET', /^\/products\/duplicates\//, ['ADMIN']),
  rule('GET', /^\/products\/variant-groups$/, ['ADMIN']),
  rule('GET', /^\/products(\/.*)?$/, ALL),

  // ── Lantify 3.0 ──────────────────────────────────────────
  rule('GET', /^\/features$/, 'authenticated'),
  rule('GET', /^\/floor$/, ALL),
  // Ingredientes y recetas: los administra el ADMIN; la caja puede verlos
  rule('GET', /^\/(ingredients|recipes)(\/.*)?$/, ['ADMIN', 'CASHIER']),
  rule('*', /^\/(ingredients|recipes)(\/.*)?$/, ['ADMIN']),
  rule('GET', /^\/floor\/layout$/, ALL),
  rule('PUT', /^\/floor\/layout$/, ['ADMIN']),
  // Pantallas: la administración es del ADMIN; la pantalla usa su propio token (v3Routes)
  // Fase 4 · pantalla del cliente: la caja elige su pantalla y publica el carrito (antes de la regla del ADMIN)
  rule('GET', /^\/displays\/customer$/, can('charge')),
  rule('PUT', /^\/displays\/customer-cart$/, can('charge')),
  rule('*', /^\/displays(\/.*)?$/, ['ADMIN']),
  // La pantalla misma se identifica con su token (cabecera X-Display-Token): sin él responde 401
  rule(['GET', 'POST'], /^\/display\/(pair|feed|ready|undo)$/, 'public'),
  rule('GET', /^\/display\/events$/, 'public'),
  rule('POST', /^\/display\/(attendance\/punch|kiosk\/order)$/, 'public'),
  rule('POST', /^\/floor\/tables\/[^/]+\/served$/, ALL),
  // Motor de menú y Autopilot: sugerencias para todos; la lectura del menú, del ADMIN; decidir, ADMIN y caja (el rol se revisa por intervención)
  rule('POST', /^\/menu\/suggestions(\/event)?$/, ALL),
  rule('GET', /^\/menu$/, ['ADMIN']),
  rule('GET', /^\/autopilot$/, ALL),
  // Fase 4 · happy hour: la caja y el celular leen los precios vigentes (editar es del ADMIN)
  rule('GET', /^\/price-rules\/active$/, ALL),
  rule(['GET', 'POST'], /^\/autopilot\/(knowledge|tick)$/, ['ADMIN']),
  rule('POST', /^\/autopilot\/(situations|actions)\/[^/]+\/(decide|dismiss|revert)$/, ['ADMIN', 'CASHIER']),
  rule('POST', /^\/floor\/orders\/[^/]+\/picked-up$/, ALL),
  rule('PATCH', /^\/floor\/tables\/[^/]+\/(clean|details)$/, ALL),
  rule(['POST', 'DELETE'], /^\/floor\/tables\/[^/]+\/bill$/, ALL),
  rule('PUT', /^\/ops\/sales\/[^/]+\/payments$/, can('payment_fix')),
  rule('GET', /^\/ops\/close-report\/[^/]+(\/ticket)?$/, can('cash')),
  rule(['GET', 'POST'], /^\/staff\/me\/(shift|clock-in|clock-out)$/, 'authenticated'),
  // Marcar la entrada o salida de quien no tiene usuario (cocina): la caja
  rule('GET', /^\/staff$/, can('cash')),
  rule('POST', /^\/staff\/[^/]+\/(clock-in|clock-out)$/, can('cash')),
  // Fase 4 · asistencia con PIN en la caja (el PIN identifica a quien marca; intentos limitados)
  rule('GET', /^\/attendance\/roster$/, can('cash')),
  rule('POST', /^\/attendance\/punch$/, can('cash')),
  // PIN, horario semanal e informe de asistencia: solo ADMIN
  rule('PUT', /^\/staff\/[^/]+\/(pin|schedule)$/, ['ADMIN']),
  rule('GET', /^\/staff\/(schedule\/all|attendance\/report)$/, ['ADMIN']),
  // Fase 4 · pedido desde la mesa: el mesero (o la caja) acepta o rechaza; los QR son del ADMIN
  rule('GET', /^\/table-orders$/, ALL),
  rule('POST', /^\/table-orders\/[^/]+\/(accept|reject)$/, ALL),
  rule(['GET', 'POST'], /^\/table-orders\/qr(\/[^/]+\/rotate)?$/, ['ADMIN']),
  // Fase 4 · puerta: el portero (rol DOOR) solo ve la ocupación y marca entradas y salidas;
  // la caja también puede marcarlas. El informe de la noche es del ADMIN.
  rule('GET', /^\/door$/, ['ADMIN', 'CASHIER', 'DOOR']),
  rule('POST', /^\/door\/events$/, ['ADMIN', 'CASHIER', 'DOOR']),
  rule('GET', /^\/door\/report$/, ['ADMIN']),
  // Fase 4 · transferencias con el aviso del banco: solo el celular de ADMIN o CASHIER envía
  // y revisa los avisos; quien cobra espera la suya en Cobrar → Transferencia
  rule(['GET', 'POST'], /^\/payments\/incoming$/, ['ADMIN', 'CASHIER']),
  rule('POST', /^\/payments\/expect$/, can('charge')),
  rule('GET', /^\/payments\/expect\/[^/]+$/, can('charge')),
  rule('POST', /^\/payments\/expect\/[^/]+\/close$/, can('charge')),
  // Fase 4 · gestión: exportación contable del mes y copiar la carta entre sedes, solo el ADMIN
  rule('GET', /^\/accounting\/month$/, ['ADMIN']),
  rule('GET', /^\/menu-transfer\/export$/, ['ADMIN']),
  rule('POST', /^\/menu-transfer\/(preview|import)$/, ['ADMIN']),

  // ── Mesas ────────────────────────────────────────────────
  rule('GET', /^\/tables(\/.*)?$/, ALL),
  rule('PATCH', /^\/tables\/[^/]+\/(occupy|order|pending|release)$/, ALL),
  rule('PATCH', /^\/tables\/[^/]+\/close$/, can('charge')),

  // ── Pedidos / comandas ───────────────────────────────────
  rule('PATCH', /^\/orders\/[^/]+\/close$/, can('charge')),
  rule('*', /^\/orders(\/.*)?$/, ALL),

  // ── Caja ─────────────────────────────────────────────────
  rule('GET', /^\/cash-sessions\/open$/, ALL),
  rule('*', /^\/cash-sessions(\/.*)?$/, can('cash')),

  // ── Ventas (las rutas internas agregan restricciones ADMIN) ─
  // Corregir la propina de una venta: solo ADMIN (no cambia el valor de la venta)
  rule('PATCH', /^\/sales\/[^/]+\/tip$/, ['ADMIN']),
  // Consultar ventas: quien cobra, maneja la caja, ve el historial o las estadísticas
  rule('GET', /^\/sales(\/.*)?$/, can('charge', 'cash', 'sales_history', 'analytics')),
  rule('*', /^\/sales(\/.*)?$/, can('charge')),

  // ── Propinas: la caja ve las de su turno; el reporte completo es del ADMIN ─
  rule('GET', /^\/tips\/session\/[^/]+$/, can('cash')),

  // ── Cupones: la caja los valida al cobrar; crearlos es del ADMIN ─
  rule('GET', /^\/coupons\/validate$/, can('charge')),

  // ── Clientes ─────────────────────────────────────────────
  // Sellos de la tarjeta: todos ven el saldo; sumar, quitar o dar el enlace es de la caja
  rule('POST', /^\/customers\/[^/]+\/stamps$/, can('customers_edit')),
  rule('GET', /^\/loyalty\/(customers|events)\/[^/]+$/, ALL),
  rule('POST', /^\/loyalty\/customers\/[^/]+\/(stamps|card-link)$/, can('customers_edit')),
  // Leer la tarjeta del cliente en caja: quien cobra o toma el pedido (igual que elegir el cliente)
  rule('POST', /^\/loyalty\/member-card$/, ALL),
  rule(['GET', 'POST'], /^\/customers(\/.*)?$/, ALL),
  rule('PUT', /^\/customers\/[^/]+$/, can('customers_edit')),

  // ── Categorías de gasto (lectura para registrar egresos) ─
  rule('GET', /^\/expense-categories$/, can('cash')),

  // ── Reservas: todo el equipo agenda (WhatsApp, teléfono); las reglas son del ADMIN ─
  rule('PUT', /^\/reservations\/settings$/, ['ADMIN']),
  // Todos ven la agenda (la usan las mesas); agendar o cambiar es una función
  rule('GET', /^\/reservations(\/.*)?$/, ALL),
  rule(['POST', 'PATCH'], /^\/reservations(\/.*)?$/, can('reservations')),

  // ── Pedidos en línea: los atiende la caja ────────────────
  rule(['GET', 'POST'], /^\/online-orders(\/.*)?$/, can('online_orders')),

  // ── Gastos: se registran arqueo a arqueo desde la caja ───
  rule(['GET', 'POST'], /^\/expenses$/, can('cash')),
  rule('POST', /^\/purchases(\/(prepare|suppliers))?$/, can('cash')),
  rule('GET', /^\/payables$/, can('cash')),
  rule('POST', /^\/payables\/[^/]+\/pay$/, can('cash')),
  rule('POST', /^\/expenses\/scan$/, can('cash')),
  rule('PATCH', /^\/expenses\/[^/]+\/cancel$/, can('cash')),
  rule('GET', /^\/expenses\/[^/]+\/image$/, can('cash')),

  // ── DIAN: emisión desde caja, configuración solo ADMIN ───
  rule('GET', /^\/dian\/stats$/, ALL),
  rule('POST', /^\/dian\/emit$/, can('charge')),
  rule('GET', /^\/dian\/resolution$/, can('charge')),
  rule('GET', /^\/dian\/(sale|invoice)\/.+$/, can('charge', 'sales_history')),

  // ── Estadísticas ─────────────────────────────────────────
  rule('GET', /^\/analytics(\/.*)?$/, can('analytics')),

  // ── Funciones por rol: cada usuario necesita saber las suyas ─
  rule('GET', /^\/permissions$/, 'authenticated'),
  rule('GET', /^\/notifications$/, 'authenticated'),
  rule('GET', /^\/events$/, 'authenticated'),
  rule('GET', /^\/system\/status-bar$/, 'authenticated'), // barra de la ventana: internet, meseros, caja

  // Todo lo demás (analytics, inventory, system, version/apply-update,
  // dian/config, products POST/PUT/DELETE, etc.) → ADMIN
];

export type Decision =
  | { kind: 'public' }
  | { kind: 'authenticated' }
  | { kind: 'roles'; roles: Role[] }
  | { kind: 'permission'; anyOf: Permission[] };

export const resolveAccess = (method: string, path: string): Decision => {
  const m = method.toUpperCase();
  const cleanPath = path.split('?')[0].replace(/\/+$/, '') || '/';
  for (const r of ACCESS_RULES) {
    if (r.methods !== '*' && !r.methods.includes(m)) continue;
    if (!r.path.test(cleanPath)) continue;
    if (r.access === 'public') return { kind: 'public' };
    if (r.access === 'authenticated') return { kind: 'authenticated' };
    if (Array.isArray(r.access)) return { kind: 'roles', roles: r.access };
    return { kind: 'permission', anyOf: r.access.anyOf };
  }
  return { kind: 'roles', roles: ['ADMIN'] };
};
