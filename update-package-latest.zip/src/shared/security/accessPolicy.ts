// ============================================
// SHARED - Política central de acceso a la API
// ============================================
// Una sola tabla define quién puede llamar cada endpoint. Se evalúa en orden
// y gana la primera regla que coincide. Lo que no aparece aquí queda solo para
// ADMIN (falla cerrada): un endpoint nuevo nunca queda abierto por olvido.
// Las reglas con can(...) dependen de las funciones que el ADMIN dio a cada rol
// (src/domain/rolePermissions.ts); el ADMIN siempre pasa.

import type { Permission } from '../../domain/rolePermissions';

export type Role = 'ADMIN' | 'CASHIER' | 'WAITER';
export type Access = 'public' | 'authenticated' | Role[] | { anyOf: Permission[] };

interface Rule {
  methods: string[] | '*';
  path: RegExp;
  access: Access;
}

const ALL: Role[] = ['ADMIN', 'CASHIER', 'WAITER'];

/** Pasa quien tenga alguna de estas funciones */
const can = (...anyOf: Permission[]): Access => ({ anyOf });

const rule = (methods: string | string[], path: RegExp, access: Access): Rule => ({
  methods: methods === '*' ? '*' : (Array.isArray(methods) ? methods : [methods]),
  path,
  access,
});

// Las rutas son relativas a /api
export const ACCESS_RULES: Rule[] = [
  // ── Público ──────────────────────────────────────────────
  rule('POST', /^\/auth\/login$/, 'public'),
  rule('GET', /^\/auth\/setup-status$/, 'public'),
  rule('POST', /^\/auth\/setup$/, 'public'), // solo funciona si no existe ningún usuario
  rule('GET', /^\/version$/, 'public'),
  rule('GET', /^\/public\/catalog$/, 'public'), // menú de la tienda web (sin costos)
  rule('GET', /^\/cloud\/status$/, 'public'),           // ¿negocio vinculado a Lantify Cloud?
  rule('POST', /^\/cloud\/activate$/, 'public'),        // solo funciona mientras no haya negocio vinculado
  rule('GET', /^\/export\/[a-z-]+\.csv$/, 'public'),     // exige su propio permiso de exportación (exportRoutes.ts)
  rule('GET', /^\/media\/[0-9a-f]{32}\.(webp|jpg|png)$/, 'public'), // fotos de productos y logo (las muestran <img>)

  // ── Sesión (cualquier usuario autenticado) ───────────────
  rule('GET', /^\/auth\/verify$/, 'authenticated'),
  rule('POST', /^\/auth\/change-password$/, 'authenticated'),
  rule('POST', /^\/auth\/verify-admin$/, 'authenticated'),
  rule('GET', /^\/version\/check$/, 'authenticated'),
  rule('GET', /^\/license$/, 'authenticated'),
  rule('POST', /^\/ai\/chat$/, 'authenticated'),
  rule('GET', /^\/ai\/settings$/, 'authenticated'),

  // ── Datos del negocio (ticket, impuestos, módulos): lectura para todos ─
  rule('GET', /^\/business$/, ALL),

  // ── Impresión: todos imprimen; elegir impresoras es del ADMIN ─
  rule('GET', /^\/printing\/settings$/, ALL),
  rule('POST', /^\/printing\/print$/, ALL),

  // ── Usuarios: solo ADMIN ──────────────────────────────────
  rule('*', /^\/auth\//, ['ADMIN']),

  // ── Catálogo: lectura para todos ─────────────────────────
  rule('GET', /^\/products\/import\/template$/, ['ADMIN']),
  rule('GET', /^\/products\/duplicates\//, ['ADMIN']),
  rule('GET', /^\/products(\/.*)?$/, ALL),

  // ── Mesas ────────────────────────────────────────────────
  rule('GET', /^\/tables(\/.*)?$/, ALL),
  rule('PATCH', /^\/tables\/[^/]+\/(occupy|order|pending|release)$/, ALL),
  rule('PATCH', /^\/tables\/[^/]+\/close$/, can('charge')),

  // ── Pedidos / comandas ───────────────────────────────────
  rule('PATCH', /^\/orders\/[^/]+\/close$/, can('charge')),
  rule('*', /^\/orders(\/.*)?$/, ALL),

  // ── Caja ─────────────────────────────────────────────────
  rule('GET', /^\/cash-sessions\/open$/, ALL),
  rule('*', /^\/cash-sessions(\/.*)?$/, can('cash')),

  // ── Ventas (las rutas internas agregan restricciones ADMIN) ─
  // Corregir la propina de una venta: solo ADMIN (no cambia el valor de la venta)
  rule('PATCH', /^\/sales\/[^/]+\/tip$/, ['ADMIN']),
  // Consultar ventas: quien cobra, maneja la caja, ve el historial o las estadísticas
  rule('GET', /^\/sales(\/.*)?$/, can('charge', 'cash', 'sales_history', 'analytics')),
  rule('*', /^\/sales(\/.*)?$/, can('charge')),

  // ── Propinas: la caja ve las de su turno; el reporte completo es del ADMIN ─
  rule('GET', /^\/tips\/session\/[^/]+$/, can('cash')),

  // ── Cupones: la caja los valida al cobrar; crearlos es del ADMIN ─
  rule('GET', /^\/coupons\/validate$/, can('charge')),

  // ── Clientes ─────────────────────────────────────────────
  // Sellos de la tarjeta: todos ven el saldo; sumar, quitar o dar el enlace es de la caja
  rule('POST', /^\/customers\/[^/]+\/stamps$/, can('customers_edit')),
  rule('GET', /^\/loyalty\/(customers|events)\/[^/]+$/, ALL),
  rule('POST', /^\/loyalty\/customers\/[^/]+\/(stamps|card-link)$/, can('customers_edit')),
  rule(['GET', 'POST'], /^\/customers(\/.*)?$/, ALL),
  rule('PUT', /^\/customers\/[^/]+$/, can('customers_edit')),

  // ── Categorías de gasto (lectura para registrar egresos) ─
  rule('GET', /^\/expense-categories$/, can('cash')),

  // ── Reservas: todo el equipo agenda (WhatsApp, teléfono); las reglas son del ADMIN ─
  rule('PUT', /^\/reservations\/settings$/, ['ADMIN']),
  // Todos ven la agenda (la usan las mesas); agendar o cambiar es una función
  rule('GET', /^\/reservations(\/.*)?$/, ALL),
  rule(['POST', 'PATCH'], /^\/reservations(\/.*)?$/, can('reservations')),

  // ── Pedidos en línea: los atiende la caja ────────────────
  rule(['GET', 'POST'], /^\/online-orders(\/.*)?$/, can('online_orders')),

  // ── Gastos: se registran arqueo a arqueo desde la caja ───
  rule(['GET', 'POST'], /^\/expenses$/, can('cash')),
  rule('POST', /^\/expenses\/scan$/, can('cash')),
  rule('PATCH', /^\/expenses\/[^/]+\/cancel$/, can('cash')),
  rule('GET', /^\/expenses\/[^/]+\/image$/, can('cash')),

  // ── DIAN: emisión desde caja, configuración solo ADMIN ───
  rule('GET', /^\/dian\/stats$/, ALL),
  rule('POST', /^\/dian\/emit$/, can('charge')),
  rule('GET', /^\/dian\/resolution$/, can('charge')),
  rule('GET', /^\/dian\/(sale|invoice)\/.+$/, can('charge', 'sales_history')),

  // ── Estadísticas ─────────────────────────────────────────
  rule('GET', /^\/analytics(\/.*)?$/, can('analytics')),

  // ── Funciones por rol: cada usuario necesita saber las suyas ─
  rule('GET', /^\/permissions$/, 'authenticated'),
  rule('GET', /^\/notifications$/, 'authenticated'),

  // Todo lo demás (analytics, inventory, system, version/apply-update,
  // dian/config, products POST/PUT/DELETE, etc.) → ADMIN
];

export type Decision =
  | { kind: 'public' }
  | { kind: 'authenticated' }
  | { kind: 'roles'; roles: Role[] }
  | { kind: 'permission'; anyOf: Permission[] };

export const resolveAccess = (method: string, path: string): Decision => {
  const m = method.toUpperCase();
  const cleanPath = path.split('?')[0].replace(/\/+$/, '') || '/';
  for (const r of ACCESS_RULES) {
    if (r.methods !== '*' && !r.methods.includes(m)) continue;
    if (!r.path.test(cleanPath)) continue;
    if (r.access === 'public') return { kind: 'public' };
    if (r.access === 'authenticated') return { kind: 'authenticated' };
    if (Array.isArray(r.access)) return { kind: 'roles', roles: r.access };
    return { kind: 'permission', anyOf: r.access.anyOf };
  }
  return { kind: 'roles', roles: ['ADMIN'] };
};
