// ============================================
// SHARED - Permiso de exportación de datos (15 minutos)
// ============================================
// Lo reciben un ADMIN con sesión abierta o un ADMIN con la cuenta suspendida
// (los datos fiscales siempre se pueden sacar). Solo sirve para /api/export.

import jwt from 'jsonwebtoken';
import { getJwtSecret } from './secrets';

export const EXPORT_MINUTES = 15;

export const signExportToken = (username: string) =>
  jwt.sign({ scope: 'export', username }, getJwtSecret(), { expiresIn: `${EXPORT_MINUTES}m` });

export const isExportToken = (token: string) => {
  try {
    return (jwt.verify(token, getJwtSecret()) as { scope?: string }).scope === 'export';
  } catch {
    return false;
  }
};
