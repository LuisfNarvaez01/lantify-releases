// ============================================
// SHARED - Cifrado de secretos en reposo (AES-256-GCM)
// ============================================

import crypto from 'crypto';
import { getEncryptionKey } from './secrets';

const PREFIX = 'enc:v1:';

export const isEncrypted = (value: unknown): boolean =>
  typeof value === 'string' && value.startsWith(PREFIX);

export const encryptSecret = (plain: string | null | undefined): string | null | undefined => {
  if (plain === null || plain === undefined || plain === '' || isEncrypted(plain)) return plain;
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', getEncryptionKey(), iv);
  const data = Buffer.concat([cipher.update(plain, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return PREFIX + Buffer.concat([iv, tag, data]).toString('base64');
};

export const decryptSecret = (value: string | null | undefined): string | null | undefined => {
  // Valores antiguos guardados en texto plano se devuelven tal cual (se cifran al siguiente guardado)
  if (!isEncrypted(value)) return value;
  try {
    const raw = Buffer.from((value as string).slice(PREFIX.length), 'base64');
    const iv = raw.subarray(0, 12);
    const tag = raw.subarray(12, 28);
    const data = raw.subarray(28);
    const decipher = crypto.createDecipheriv('aes-256-gcm', getEncryptionKey(), iv);
    decipher.setAuthTag(tag);
    return Buffer.concat([decipher.update(data), decipher.final()]).toString('utf8');
  } catch {
    console.error('⚠️ No se pudo descifrar un secreto (¿cambió la clave de instalación?)');
    return null;
  }
};

// Campos sensibles de DianConfig
export const DIAN_SECRET_FIELDS = [
  'factusClientSecret',
  'factusPassword',
  'factusToken',
  'certificatePassword',
  'softwarePin',
  'technicalKey',
] as const;

export const SECRET_MASK = '••••••••';

const mapFields = (obj: any, fn: (v: any) => any) => {
  if (!obj || typeof obj !== 'object') return obj;
  for (const field of DIAN_SECRET_FIELDS) {
    if (field in obj && typeof obj[field] === 'string') {
      obj[field] = fn(obj[field]);
    }
  }
  return obj;
};

export const encryptDianFields = (data: any) => mapFields(data, encryptSecret);
export const decryptDianFields = (record: any) => mapFields(record, decryptSecret);

/** Copia segura para enviar al navegador: los secretos se reemplazan por una máscara */
export const maskDianConfig = (config: any) => {
  if (!config) return config;
  const copy = { ...config };
  for (const field of DIAN_SECRET_FIELDS) {
    copy[field] = copy[field] ? SECRET_MASK : null;
  }
  return copy;
};

/** Al guardar desde el navegador: una máscara o un vacío en un campo secreto significa "no cambiar" */
export const stripUnchangedSecrets = (data: any) => {
  const copy = { ...data };
  for (const field of DIAN_SECRET_FIELDS) {
    if (copy[field] === SECRET_MASK || copy[field] === '' || copy[field] === undefined) {
      delete copy[field];
    }
  }
  return copy;
};
