// ============================================
// SHARED - Autorización puntual de administrador
// ============================================
// Cuando un cajero o mesero necesita autorización (anular un producto ya enviado
// a cocina, cancelar el pedido de una mesa), un administrador escribe su clave y
// el servidor emite un token firmado de corta duración. El servidor exige ese
// token: un nombre de administrador enviado desde el navegador no sirve.

import jwt from 'jsonwebtoken';
import { getJwtSecret } from './secrets';

const PURPOSE = 'admin-override';
const TTL = '2m';

export interface AdminOverride {
  adminId: string;
  adminName: string;
}

export const issueAdminOverride = (admin: AdminOverride): string =>
  jwt.sign({ purpose: PURPOSE, adminId: admin.adminId, adminName: admin.adminName }, getJwtSecret(), { expiresIn: TTL });

export const verifyAdminOverride = (token: unknown): AdminOverride | null => {
  if (typeof token !== 'string' || !token) return null;
  try {
    const decoded = jwt.verify(token, getJwtSecret()) as any;
    if (decoded.purpose !== PURPOSE) return null;
    return { adminId: decoded.adminId, adminName: decoded.adminName };
  } catch {
    return null;
  }
};

/**
 * Quién autoriza una acción sensible: el propio usuario si es ADMIN,
 * o el administrador del token. null = falta autorización.
 */
export const resolveAuthorizer = (
  user: { id?: string; name?: string; username?: string; role?: string } | undefined,
  overrideToken: unknown
): AdminOverride | null => {
  if (user?.role === 'ADMIN') {
    return { adminId: user.id || '', adminName: user.name || user.username || 'Administrador' };
  }
  return verifyAdminOverride(overrideToken);
};
