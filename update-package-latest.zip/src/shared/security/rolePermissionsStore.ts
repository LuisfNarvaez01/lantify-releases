// ============================================
// SHARED - Funciones por rol guardadas en el negocio (con caché)
// ============================================
// La política de acceso las consulta en cada petición; se guardan en memoria y
// se refrescan al cambiarlas (o cada minuto, por si otra instancia las cambió).

import { prisma } from '../../infrastructure/database/prisma';
import { DEFAULT_ROLE_PERMISSIONS, normalizeRolePermissions, RolePermissions } from '../../domain/rolePermissions';

const SETTINGS_ID = 'default';
const TTL_MS = 60_000;

let cache: { value: RolePermissions; at: number } | null = null;

export const loadRolePermissions = async (): Promise<RolePermissions> => {
  if (cache && Date.now() - cache.at < TTL_MS) return cache.value;
  const row = await prisma.businessSettings.findUnique({ where: { id: SETTINGS_ID }, select: { rolePermissions: true } });
  let value: RolePermissions;
  try {
    value = row?.rolePermissions ? normalizeRolePermissions(JSON.parse(row.rolePermissions)) : normalizeRolePermissions(DEFAULT_ROLE_PERMISSIONS);
  } catch {
    value = normalizeRolePermissions(DEFAULT_ROLE_PERMISSIONS);
  }
  cache = { value, at: Date.now() };
  return value;
};

export const saveRolePermissions = async (raw: unknown): Promise<RolePermissions> => {
  const value = normalizeRolePermissions(raw);
  const json = JSON.stringify(value);
  await prisma.businessSettings.upsert({
    where: { id: SETTINGS_ID },
    create: { id: SETTINGS_ID, rolePermissions: json },
    update: { rolePermissions: json },
  });
  cache = { value, at: Date.now() };
  return value;
};

/** Solo para pruebas: olvida la caché */
export const resetRolePermissionsCache = () => { cache = null; };
