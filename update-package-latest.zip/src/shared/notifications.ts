// ============================================
// SHARED - Avisos para las pantallas del POS (abajo a la derecha)
// ============================================
// Lo que llega de la página del negocio (pedidos, reservas, registros, premios)
// se anota aquí al sincronizar. Las pantallas preguntan cada pocos segundos por lo
// nuevo desde su último número. Vive en memoria: es un aviso, no un registro (lo
// que pasó queda guardado en su módulo: pedidos, reservas, clientes, cupones).

export type NotificationKind = 'ONLINE_ORDER' | 'RESERVATION' | 'NEW_CUSTOMER' | 'PRIZE' | 'CARD_COMPLETE';

export interface PosNotification {
  id: number;
  at: string;
  kind: NotificationKind;
  /** Datos para armar el texto en el idioma de cada pantalla */
  data: Record<string, string | number | null>;
}

const MAX = 200;
let seq = 0;
const feed: PosNotification[] = [];

export const notify = (kind: NotificationKind, data: PosNotification['data']) => {
  feed.push({ id: ++seq, at: new Date().toISOString(), kind, data });
  if (feed.length > MAX) feed.splice(0, feed.length - MAX);
};

/** Lo nuevo después de `since`. Sin `since` solo devuelve el número actual (no repite lo viejo al abrir). */
export const notificationsSince = (since: number | null) => ({
  cursor: seq,
  items: since == null || since > seq ? [] : feed.filter((n) => n.id > since),
});

/** Solo para pruebas */
export const resetNotifications = () => {
  seq = 0;
  feed.length = 0;
};
