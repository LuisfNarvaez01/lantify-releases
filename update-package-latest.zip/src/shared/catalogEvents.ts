// ============================================
// SHARED - "La carta cambió" (productos pausados, reactivados, precios)
// ============================================
// Lo usa Autopilot, que corre también sin una petición HTTP de por medio: avisa a
// las pantallas en vivo y pide volver a publicar la página del negocio.

import { publish } from './liveEvents';

let listener: () => void = () => {};

/** app.ts conecta aquí la publicación de la página */
export const onCatalogChange = (fn: () => void) => { listener = fn; };

export const catalogChanged = () => {
  publish('catalog', 'floor');
  try { listener(); } catch { /* la publicación se reintenta en la próxima vuelta */ }
};
