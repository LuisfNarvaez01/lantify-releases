// ============================================
// SHARED - Avisos en vivo para las pantallas (Lantify 3.0)
// ============================================
// Las pantallas del POS y los celulares mantienen abierta una conexión
// (GET /api/events) y el servidor les avisa en cuanto algo cambia: una mesa, la
// cocina, la carta o un aviso nuevo. El aviso solo dice QUÉ cambió; cada pantalla
// vuelve a pedir lo suyo con sus permisos de siempre. Si la conexión se cae, las
// pantallas siguen preguntando cada pocos segundos como antes.

import type { Request, Response, NextFunction } from 'express';

export type LiveTopic = 'floor' | 'catalog' | 'notifications';

const clients = new Set<Response>();
const pending = new Set<LiveTopic>();
let timer: ReturnType<typeof setTimeout> | null = null;
/** Varios cambios seguidos (una comanda guarda mesa, pedido y líneas) salen en un solo aviso */
const BATCH_MS = 120;

const flush = () => {
  timer = null;
  if (!pending.size) return;
  const data = JSON.stringify({ topics: [...pending], at: Date.now() });
  pending.clear();
  for (const res of clients) {
    try {
      res.write(`event: change\ndata: ${data}\n\n`);
    } catch {
      clients.delete(res);
    }
  }
};

/** Avisa a todas las pantallas que algo de `topic` cambió */
export const publish = (...topics: LiveTopic[]) => {
  topics.forEach((t) => pending.add(t));
  if (!timer) timer = setTimeout(flush, BATCH_MS);
};

/** Cuántas pantallas están escuchando (diagnóstico y pruebas) */
export const liveClients = () => clients.size;

/** GET /api/events: deja la conexión abierta y manda los avisos */
export const liveHandler = (req: Request, res: Response) => {
  res.status(200);
  res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders?.();
  res.write(`retry: 3000\nevent: hello\ndata: {}\n\n`);
  clients.add(res);
  // Latido: mantiene viva la conexión a través de routers y proxies
  const beat = setInterval(() => {
    try { res.write(': ping\n\n'); } catch { /* se limpia al cerrar */ }
  }, 25_000);
  req.on('close', () => {
    clearInterval(beat);
    clients.delete(res);
  });
};

/** Qué pantallas deben refrescarse según la ruta que cambió algo */
export const topicsFor = (path: string): LiveTopic[] => {
  const p = path.toLowerCase();
  if (/^\/(orders|tables|floor|sales|display|cash-sessions|online-orders)\b/.test(p)) return ['floor'];
  // Consultas por POST que no cambian nada (sugerencias, revisar Autopilot): sin aviso, o se arma un bucle
  if (/^\/(menu|autopilot\/tick)\b/.test(p)) return [];
  if (/^\/(products|categories|recipes|ingredients|inventory|autopilot|ops\/products)\b/.test(p)) return ['catalog', 'floor'];
  if (/^\/(reservations|loyalty)\b/.test(p)) return ['notifications'];
  return [];
};

/**
 * Middleware: después de cualquier cambio que salió bien (POST, PUT, PATCH,
 * DELETE con respuesta < 400), avisa a las pantallas. Va antes de las rutas.
 */
export const liveAfterChange = (req: Request, res: Response, next: NextFunction) => {
  if (req.method !== 'GET' && req.method !== 'HEAD' && req.method !== 'OPTIONS') {
    const path = req.path;
    res.on('finish', () => {
      if (res.statusCode < 400) {
        const topics = topicsFor(path);
        if (topics.length) publish(...topics);
      }
    });
  }
  next();
};

/** Solo para pruebas */
export const resetLive = () => {
  for (const res of clients) { try { res.end(); } catch { /* nada */ } }
  clients.clear();
  pending.clear();
  if (timer) clearTimeout(timer);
  timer = null;
};
