// ============================================
// SHARED - Error Handler
// ============================================
// Toda respuesta de error lleva { error, code }. El código permite que la
// interfaz muestre un mensaje claro en el idioma del usuario; el detalle
// técnico solo queda en el registro del servidor.

import { Request, Response, NextFunction } from 'express';

export class AppError extends Error {
  constructor(public statusCode: number, message: string, public code = 'APP_ERROR') {
    super(message);
    this.name = 'AppError';
  }
}

export const notFoundHandler = (_req: Request, res: Response) => {
  res.status(404).json({ error: 'La ruta solicitada no existe.', code: 'ROUTE_NOT_FOUND' });
};

export const errorHandler = (
  err: any,
  _req: Request,
  res: Response,
  _next: NextFunction
) => {
  if (err instanceof AppError) {
    return res.status(err.statusCode).json({ error: err.message, code: err.code });
  }

  // Errores de express.json()
  if (err?.type === 'entity.parse.failed') {
    return res.status(400).json({ error: 'La solicitud no tiene un formato válido.', code: 'INVALID_JSON' });
  }
  if (err?.type === 'entity.too.large') {
    return res.status(413).json({ error: 'La información enviada es demasiado grande.', code: 'PAYLOAD_TOO_LARGE' });
  }

  // Errores conocidos de Prisma
  if (err?.code === 'P2002') {
    return res.status(409).json({ error: 'Ya existe un registro con esos datos.', code: 'DUPLICATE' });
  }
  if (err?.code === 'P2025') {
    return res.status(404).json({ error: 'El registro no existe o ya fue eliminado.', code: 'NOT_FOUND' });
  }

  console.error(err);
  return res.status(500).json({ error: 'Error interno del servidor', code: 'SERVER_ERROR' });
};
