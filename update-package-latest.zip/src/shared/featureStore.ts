// ============================================
// SHARED - Funciones activables guardadas en el negocio (con caché)
// ============================================

import { prisma } from '../infrastructure/database/prisma';
import { FEATURE_PLAN_CODE, FeatureKey, FeatureSettings, normalizeFeatures, parseFeatures } from '../domain/v3/features';
import { currentFeatures } from './cloud/features';

const SETTINGS_ID = 'default';
const TTL_MS = 30_000;

let cache: { value: FeatureSettings; at: number } | null = null;

export const invalidateFeatureSettings = () => { cache = null; };

export const loadFeatures = async (): Promise<FeatureSettings> => {
  if (cache && Date.now() - cache.at < TTL_MS) return cache.value;
  const row = await prisma.businessSettings.findUnique({ where: { id: SETTINGS_ID }, select: { featureSettings: true } });
  const value = parseFeatures(row?.featureSettings);
  cache = { value, at: Date.now() };
  return value;
};

/** Guarda fusionando: quien edita una parte (p. ej. las frases rápidas) no borra el resto */
export const saveFeatures = async (patch: unknown): Promise<FeatureSettings> => {
  const current = await loadFeatures();
  const p = patch && typeof patch === 'object' ? (patch as Record<string, any>) : {};
  const value = normalizeFeatures({
    ...current,
    ...p,
    flags: { ...current.flags, ...(p.flags || {}) },
    alerts: { ...current.alerts, ...(p.alerts || {}) },
    tips: p.tips ? { ...current.tips, ...p.tips } : current.tips,
    accounting: p.accounting ? { ...current.accounting, ...p.accounting } : current.accounting,
  });
  const json = JSON.stringify(value);
  await prisma.businessSettings.upsert({
    where: { id: SETTINGS_ID },
    update: { featureSettings: json },
    create: { id: SETTINGS_ID, featureSettings: json },
  });
  cache = { value, at: Date.now() };
  return value;
};

export const isFeatureOn = async (key: FeatureKey) => (await loadFeatures()).flags[key] === true;

/** Encendida en Funciones y dentro del plan del negocio (sin negocio vinculado no hay candados) */
export const featureAllowed = async (key: FeatureKey): Promise<boolean> => {
  if (!(await isFeatureOn(key))) return false;
  const plan = await currentFeatures();
  const code = FEATURE_PLAN_CODE[key];
  return !plan || !code || plan.includes(code);
};
