// ============================================
// SHARED - Canal con la app de escritorio (Lantify.exe)
// ============================================
// En el programa instalado, el servidor corre como proceso hijo de la app de escritorio
// (utilityProcess de Electron) y le habla por process.parentPort. Así las pantallas de
// "Actualización disponible" funcionan igual desde el equipo principal o una tablet:
// preguntan al servidor, y el servidor le pregunta a la app.

import crypto from 'crypto';
import { isDesktop } from './runtime';

export interface DesktopUpdateStatus {
  state: 'idle' | 'checking' | 'downloading' | 'ready' | 'up-to-date' | 'error' | 'disabled';
  currentVersion: string;
  latestVersion?: string;
  releaseName?: string;
  releaseNotes?: string;
  releaseDate?: string;
  percent?: number;
  verified?: boolean;
  error?: string;
}

interface Port {
  postMessage(message: unknown): void;
  on(event: 'message', listener: (e: { data: any }) => void): void;
}

const port = (): Port | null => (isDesktop() ? ((process as any).parentPort as Port | undefined) ?? null : null);

const pending = new Map<string, (value: any) => void>();
let listening = false;

const listen = (p: Port) => {
  if (listening) return;
  listening = true;
  p.on('message', ({ data }) => {
    const done = data?.id ? pending.get(data.id) : undefined;
    if (done) {
      pending.delete(data.id);
      done(data.result);
    }
  });
};

/** Pide algo a la app de escritorio; null si no hay app o no responde a tiempo */
export function askDesktop<T>(type: string, payload?: unknown, timeoutMs = 5000): Promise<T | null> {
  const p = port();
  if (!p) return Promise.resolve(null);
  listen(p);
  const id = crypto.randomUUID();
  return new Promise((resolve) => {
    const timer = setTimeout(() => {
      pending.delete(id);
      resolve(null);
    }, timeoutMs);
    pending.set(id, (result) => {
      clearTimeout(timer);
      resolve(result as T);
    });
    p.postMessage({ id, type, payload });
  });
}

/** Avisa a la app de escritorio sin esperar respuesta (p. ej. "el servidor ya arrancó") */
export const tellDesktop = (type: string, payload?: unknown) => port()?.postMessage({ type, payload });
