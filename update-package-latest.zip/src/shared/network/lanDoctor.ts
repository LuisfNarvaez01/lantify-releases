// ============================================
// SHARED - Diagnóstico de la conexión de celulares y tablets (Lantify 3.0)
// ============================================
// "Se queda cargando y no abre" casi siempre es: el acceso desde la red apagado,
// el Firewall de Windows bloqueando el programa que atiende (Lantify.exe en el
// programa instalado, node.exe en desarrollo), una IP equivocada (adaptador
// virtual o VPN) o la red del local aislando a los equipos entre sí.
// Aquí se revisa lo que se puede revisar desde la caja y se dice cómo arreglarlo.

import os from 'os';
import fs from 'fs';
import path from 'path';
import { execFile } from 'child_process';

export const FW_RULE = 'Lantify POS (celulares y tablets)';
const VIRTUAL = /virtual|vmware|vbox|hyper-v|vethernet|wsl|docker|tailscale|zerotier|loopback|vpn|hamachi|radmin/i;

export interface LanAddress { ip: string; iface: string; virtual: boolean }

export const lanInterfaces = (): LanAddress[] => {
  const out: LanAddress[] = [];
  for (const [name, list] of Object.entries(os.networkInterfaces())) {
    for (const a of list || []) {
      if (a.family !== 'IPv4' || a.internal || a.address.startsWith('169.254.')) continue;
      if (!/^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(a.address)) continue;
      out.push({ ip: a.address, iface: name, virtual: VIRTUAL.test(name) || a.address.startsWith('192.168.56.') });
    }
  }
  // Primero wifi/ethernet reales; los virtuales al final
  const score = (x: LanAddress) => (x.virtual ? 0 : 2) + (/wi-?fi|wlan|inal[aá]mbrica|ethernet/i.test(x.iface) ? 1 : 0);
  return out.sort((a, b) => score(b) - score(a));
};

const ps = (script: string, timeoutMs = 8000) =>
  new Promise<string>((resolve, reject) => {
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], { timeout: timeoutMs, windowsHide: true }, (err, stdout) => (err ? reject(err) : resolve(String(stdout).trim())));
  });
const q = (s: string) => `'${s.replace(/'/g, "''")}'`;

export interface Diagnosis {
  platform: string;
  lanEnabled: boolean;
  port: number;
  uiPort: number;
  program: string;
  addresses: LanAddress[];
  /** null = no se pudo saber (no es Windows o PowerShell no respondió) */
  firewall: { allowed: boolean; blocked: number } | null;
  /** Perfil de cada red: Public, Private, DomainAuthenticated */
  networks: { alias: string; category: string }[];
  problems: string[];
}

export const diagnose = async (opts: { lanEnabled: boolean; port: number; uiPort: number }): Promise<Diagnosis> => {
  const addresses = lanInterfaces();
  const program = process.execPath;
  let firewall: Diagnosis['firewall'] = null;
  let networks: Diagnosis['networks'] = [];
  if (process.platform === 'win32') {
    try {
      const out = await ps([
        `$exe = ${q(program)}`,
        `$rules = @(Get-NetFirewallApplicationFilter -Program $exe -ErrorAction SilentlyContinue | Get-NetFirewallRule -ErrorAction SilentlyContinue | Where-Object { $_.Direction -eq 'Inbound' -and $_.Enabled -eq 'True' })`,
        `$block = @($rules | Where-Object { $_.Action -eq 'Block' }).Count`,
        `$allow = @($rules | Where-Object { $_.Action -eq 'Allow' -and ($_.Profile -eq 'Any' -or $_.Profile -match 'Public') }).Count`,
        `$ports = @(Get-NetFirewallRule -DisplayName ${q(FW_RULE)} -ErrorAction SilentlyContinue | Where-Object { $_.Enabled -eq 'True' -and $_.Action -eq 'Allow' }).Count`,
        `Write-Output "FW:$allow,$block,$ports"`,
        `Get-NetConnectionProfile -ErrorAction SilentlyContinue | ForEach-Object { Write-Output ("NET:" + $_.InterfaceAlias + "|" + $_.NetworkCategory) }`,
      ].join('; '));
      const fw = /FW:(\d+),(\d+),(\d+)/.exec(out);
      if (fw) firewall = { allowed: Number(fw[1]) > 0 || Number(fw[3]) > 0, blocked: Number(fw[2]) };
      networks = out.split(/\r?\n/).filter((l) => l.startsWith('NET:')).map((l) => { const [alias, category] = l.slice(4).split('|'); return { alias, category }; });
    } catch { /* sin PowerShell: se informa como desconocido */ }
  }
  const problems: string[] = [];
  if (!opts.lanEnabled) problems.push('LAN_OFF');
  if (!addresses.length) problems.push('NO_NETWORK');
  else if (addresses.every((a) => a.virtual)) problems.push('ONLY_VIRTUAL');
  if (addresses.filter((a) => !a.virtual).length > 1) problems.push('MANY_NETWORKS');
  if (firewall && (firewall.blocked > 0 || !firewall.allowed)) problems.push('FIREWALL');
  if (networks.some((n) => /public/i.test(n.category))) problems.push('PUBLIC_NETWORK');
  return { platform: process.platform, lanEnabled: opts.lanEnabled, port: opts.port, uiPort: opts.uiPort, program, addresses, firewall, networks, problems };
};

/**
 * Deja entrar a celulares y tablets: quita bloqueos del programa y crea la regla para
 * él y para los puertos de Lantify, en todos los perfiles (muchas redes de restaurante
 * quedan como "Pública"). Windows pide el permiso de administrador en la caja.
 */
export const repair = async (dataDir: string, ports: number[]): Promise<boolean> => {
  if (process.platform !== 'win32') return true;
  const dir = path.join(dataDir, 'red');
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, 'permitir-celulares.ps1');
  const program = process.execPath;
  fs.writeFileSync(file, [
    '$ErrorActionPreference = "Continue"',
    `$exe = ${q(program)}`,
    'Get-NetFirewallApplicationFilter -Program $exe -ErrorAction SilentlyContinue | Get-NetFirewallRule -ErrorAction SilentlyContinue | Where-Object { $_.Direction -eq "Inbound" -and $_.Action -eq "Block" } | Remove-NetFirewallRule',
    `Get-NetFirewallRule -DisplayName ${q(FW_RULE)} -ErrorAction SilentlyContinue | Remove-NetFirewallRule`,
    `New-NetFirewallRule -DisplayName ${q(FW_RULE)} -Direction Inbound -Action Allow -Program $exe -Protocol TCP -Profile Any -Enabled True | Out-Null`,
    `New-NetFirewallRule -DisplayName ${q(FW_RULE)} -Direction Inbound -Action Allow -Protocol TCP -LocalPort ${ports.join(',')} -Profile Any -Enabled True | Out-Null`,
  ].join('\r\n'), 'utf-8');
  try {
    await ps(`Start-Process powershell.exe -Verb RunAs -Wait -WindowStyle Hidden -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File',${q(file)}`, 120000);
    return true;
  } catch {
    return false; // el usuario no aceptó el permiso de Windows
  }
};
