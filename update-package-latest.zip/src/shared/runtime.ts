// ============================================
// SHARED - Dónde y cómo corre el servidor
// ============================================
// En desarrollo, todo vive junto al código (prisma/, backups/, .lantify/). En el programa
// instalado (Lantify.exe) la app de escritorio pasa las rutas por variables de entorno:
// los datos van en %ProgramData%\Lantify y nunca dentro de la carpeta del programa.

import fs from 'fs';
import path from 'path';

/** Raíz del proyecto en desarrollo (src/shared → ../..; igual desde dist/) */
export const projectRoot = () => path.resolve(__dirname, '..', '..');

/** true cuando corre dentro de Lantify.exe */
export const isDesktop = () => process.env.LANTIFY_DESKTOP === '1';

/** Archivo SQLite de DATABASE_URL (relativo a prisma/, como lo resuelve Prisma) */
export const databaseFile = (): string => {
  const url = process.env.DATABASE_URL || 'file:./dev.db';
  const raw = url.replace(/^file:/, '').split('?')[0];
  return path.isAbsolute(raw) ? raw : path.resolve(projectRoot(), 'prisma', raw);
};

export const backupsDir = () => process.env.LANTIFY_BACKUPS_DIR || path.join(projectRoot(), 'backups');

/** Interfaz compilada que sirve el propio servidor (solo en el programa instalado) */
export const staticDir = (): string | null => {
  // En desarrollo, LANTIFY_SERVE_DIST=true sirve la interfaz compilada (frontend/dist) en el
  // mismo puerto del servidor, igual que el programa instalado: así se prueba con celulares
  // sin el servidor de desarrollo de Vite, que es muy lento en un teléfono.
  const dir = process.env.LANTIFY_STATIC_DIR || (process.env.LANTIFY_SERVE_DIST === 'true' ? path.join(projectRoot(), 'frontend', 'dist') : '');
  return dir && fs.existsSync(path.join(dir, 'index.html')) ? dir : null;
};

/** Datos de la versión: en el programa instalado vienen junto al servidor empaquetado */
export const versionFile = () => process.env.LANTIFY_VERSION_FILE || path.join(projectRoot(), 'version.json');
