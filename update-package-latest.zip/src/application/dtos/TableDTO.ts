// ============================================
// APPLICATION DTOs - Table
// ============================================

import { TableStatus } from '../../domain/entities';

export interface CreateTableDTO {
  number: string;
  capacity?: number;
  positionX?: number;
  positionY?: number;
  zone?: string | null;
  width?: number | null;
  height?: number | null;
}

export interface UpdateTableDTO {
  number?: string;
  capacity?: number;
  positionX?: number;
  positionY?: number;
  zone?: string | null;
  width?: number | null;
  height?: number | null;
}

export interface TableResponseDTO {
  id: string;
  number: string;
  capacity: number;
  status: TableStatus;
  positionX?: number;
  positionY?: number;
  zone?: string | null;
  width?: number | null;
  height?: number | null;
  createdAt: Date;
}