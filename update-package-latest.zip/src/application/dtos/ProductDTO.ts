// ============================================
// APPLICATION DTOs - Product
// ============================================

export interface CreateCategoryDTO {
  name: string;
  description?: string;
}

export interface UpdateCategoryDTO {
  name?: string;
  description?: string;
  isActive?: boolean;
}

export interface CreateProductDTO {
  name: string;
  description?: string;
  categoryId?: string;
  imageUrl?: string | null;
  taxType?: 'IVA' | 'INC' | 'NONE' | null;
  taxRate?: number | null;
}

export interface UpdateProductDTO {
  name?: string;
  description?: string;
  categoryId?: string;
  imageUrl?: string | null;
  isActive?: boolean;
  taxType?: 'IVA' | 'INC' | 'NONE' | null;
  taxRate?: number | null;
}

export interface CreateProductVariantDTO {
  productId: string;
  name: string;
  sku: string;
  price: number;
  cost?: number;
  stock?: number;
}

export interface UpdateProductVariantDTO {
  name?: string;
  sku?: string;
  price?: number;
  cost?: number;
  stock?: number;
  isActive?: boolean;
}