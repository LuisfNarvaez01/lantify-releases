// ============================================
// APPLICATION DTOs - Sale
// ============================================

import { PaymentMethod, SaleStatus } from '../../domain/entities';

export interface CreateSaleItemDTO {
  productVariantId: string;
  quantity: number;
  unitPrice: number;
  notes?: string;
}

export interface CreateSaleDTO {
  tableId?: string;
  cashSessionId?: string;
  customerId?: string;
  items: CreateSaleItemDTO[];
  paymentMethod?: PaymentMethod;
  discount?: number;
  discountPct?: number;
  payments?: { method: string; amount: number }[];
  notes?: string;
  taxRate?: number; // obsoleto: el impuesto sale del producto o del negocio
  tip?: number;
  channel?: string;
  customerName?: string;
  status?: SaleStatus;
  idempotencyKey?: string;
  discountReason?: string;
  authorizedBy?: string;
  /** Lo pone el servidor con la sesión: quién cobró (no viene del navegador) */
  cashierName?: string;
  /** Cupón: el descuento lo calcula el servidor (reemplaza cualquier descuento manual) */
  couponCode?: string;
}

export interface UpdateSaleDTO {
  tableId?: string;
  paymentMethod?: PaymentMethod;
  discount?: number;
  notes?: string;
}

export interface SaleResponseDTO {
  id: string;
  saleNumber: string;
  tableId?: string;
  cashSessionId?: string;
  subtotal: number;
  tax: number;
  discount: number;
  total: number;
  paymentMethod: PaymentMethod;
  status: SaleStatus;
  notes?: string;
  createdAt: Date;
  items: SaleItemResponseDTO[];
}

export interface SaleItemResponseDTO {
  id: string;
  productVariantId: string;
  productName?: string;
  variantName?: string;
  quantity: number;
  unitPrice: number;
  total: number;
  notes?: string;
}