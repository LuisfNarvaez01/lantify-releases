// ============================================
// APPLICATION - Mi página y reservas en línea ⇄ Lantify Cloud
// ============================================
// Publicar: la página lantifypos.dpdns.org/m/<slug> con la carta (productos
// activos), el perfil, el juego y sus premios, las mesas reservables y el horario.
// Se vuelve a publicar sola si algo cambia (huella), p. ej. un precio.
// Sincronizar (cada minuto y tras cada cambio en la caja):
//   · sube las reservas de la caja SIN datos personales (mesa, horas, estado),
//   · trae las de la página (nuevas o canceladas por el cliente) y las agenda aquí;
//     el cliente que reservó queda en Clientes con su autorización de datos,
//   · trae quienes se registraron en la página (Clientes) y los premios que ganaron
//     (Cupones de un solo uso a su nombre); quien pide borrar sus datos, se borra aquí,
//   · sube los sellos que dio la caja (al instante tras cada venta o ajuste) y trae los
//     saldos de las tarjetas que cambiaron en la página (QR del ticket, jugadas, premios).
// Sin internet no pasa nada: la caja sigue funcionando y se pone al día al volver.

import crypto from 'crypto';
import { prisma } from '../../infrastructure/database/prisma';
import { cloudConfig } from '../../shared/cloud/config';
import { allStoredLicenses, storedLicenseFor } from '../../shared/cloud/license';
import { normalizeBooking } from '../../domain/booking';
import { isValidSiteSlug, normalizePageConfig, normalizePhone } from '../../domain/businessPage';
import { CloudAuthService } from './CloudAuthService';
import { slugify } from './ReservationUseCases';
import { PageUseCases, birthDateFrom } from './PageUseCases';
import { OnlineOrderUseCases } from './OnlineOrderUseCases';
import { cloudImages } from './CloudImages';
import { notify } from '../../shared/notifications';

const SETTINGS_ID = 'default';
const TICK_MS = 60_000;

export interface PublishResult {
  ok: boolean;
  /** NOT_LINKED, OFFLINE, SLUG_TAKEN, NO_ADMIN_LICENSE, DISABLED o el código que respondió la nube */
  code?: string;
  slug?: string;
}

/** Un pedido de la página solo avisa en la caja si sigue pendiente y es reciente */
const NOTIFY_ORDER_MAX_AGE_MS = 6 * 60 * 60 * 1000;

const digits = (v: unknown) => (typeof v === 'string' ? v.replace(/\D/g, '') : '');
const parse = (raw: string | null | undefined) => {
  try {
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
};

export class ReservationSyncService {
  private running = false;
  private kickTimer: NodeJS.Timeout | null = null;
  private stampTimer: NodeJS.Timeout | null = null;
  private pushingStamps = false;
  private started = false;

  constructor(private cloud: CloudAuthService, private onlineOrders = new OnlineOrderUseCases()) {}

  // ── Publicar la página ────────────────────────────────────
  /** Lo que se publica. Con `token` sube primero las fotos del equipo que la nube aún no tenga. */
  private async siteBody(token: string | null = null) {
    const row = await prisma.businessSettings.findUnique({ where: { id: SETTINGS_ID } });
    const settings = normalizeBooking(row?.bookingSettings ? JSON.parse(row.bookingSettings) : {});
    const tables = (await prisma.table.findMany({ where: { reservable: true } }))
      .sort((a, b) => a.number.localeCompare(b.number, 'es', { numeric: true }))
      .map((t) => ({ id: t.id, label: t.number, capacity: t.capacity, zone: t.zone }));
    let slug = row?.bookingSlug || slugify(row?.businessName || row?.cloudTenantName || '') || 'mi-restaurante';
    // Un nombre como «Lantify» o «Admin» no sirve de dirección: se le agrega el código del negocio
    if (!isValidSiteSlug(slug)) {
      const suffix = slugify((row?.cloudTenantCode || '').split('-').pop() || '') || 'local';
      slug = slugify(`${slug.slice(0, 30)}-${suffix}`);
      if (!isValidSiteSlug(slug)) slug = `negocio-${suffix}`;
    }
    const bookingOn = settings.enabled && settings.online;
    // La página (carta, registro, juego) solo existe si el ADMIN la configuró en Mi página
    const page = row?.pageSettings ? normalizePageConfig(parse(row.pageSettings)) : null;
    const sections = {
      menu: !!page?.sections.menu,
      booking: bookingOn,
      signup: !!page?.sections.signup,
      games: !!page?.sections.games,
      orders: !!page?.sections.orders,
    };
    const pageOn = sections.menu || sections.signup || sections.games || sections.orders;
    const menu = sections.menu || sections.orders ? await new PageUseCases().menu() : [];
    // Sin logo propio de la página se usa el del negocio (el de los tickets e informes)
    const theme: Record<string, unknown> = page?.theme ? { ...page.theme, logoImage: page.theme.logoImage || row?.logoUrl || null } : {};
    const showcase = page?.theme.showcase ?? null;
    const images = await cloudImages.resolve(
      [
        ...menu.flatMap((c) => c.items.map((i) => i.image)), theme.logoImage as string, theme.coverImage as string,
        ...(showcase ? [showcase.image, ...showcase.extras] : []),
      ],
      token,
      (method, path, t, b) => this.request(method, path, t, b),
    );
    const publicImage = (url: unknown) => (typeof url === 'string' ? images.get(url) ?? null : null);
    for (const item of menu.flatMap((c) => c.items)) {
      const image = publicImage(item.image);
      if (image) item.image = image;
      else delete item.image;
    }
    if (page?.theme) {
      theme.logoImage = publicImage(theme.logoImage);
      theme.coverImage = publicImage(theme.coverImage);
      const image = showcase ? publicImage(showcase.image) : null;
      theme.showcase = showcase && image
        ? { ...showcase, image, extras: showcase.extras.map(publicImage).filter((u): u is string => !!u) }
        : null;
    }
    const body = {
      slug,
      businessName: row?.businessName || row?.cloudTenantName || 'Lantify',
      settings,
      tables,
      sections,
      menu,
      profile: page?.profile ?? {},
      games: page?.games ?? {},
      legal: page?.legal ?? {},
      ordering: page?.ordering ?? {},
      theme,
      loyalty: page?.loyalty ?? {},
      social: page?.social ?? {},
    };
    const hash = crypto.createHash('sha256').update(JSON.stringify(body)).digest('hex');
    return { row, settings, body, hash, bookingOn, pageOn, sections };
  }

  private async request(method: string, path: string, token: string, body: unknown) {
    const { apiUrl, timeoutMs } = cloudConfig();
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const res = await fetch(`${apiUrl}${path}`, {
        method,
        signal: controller.signal,
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(body),
      });
      return { status: res.status, body: (await res.json().catch(() => ({}))) as any };
    } catch {
      return null; // sin conexión
    } finally {
      clearTimeout(timer);
    }
  }

  /** Licencia de un ADMIN del negocio (la de quien guardó, o cualquiera guardada en este equipo) */
  private async adminLicense(localUserId?: string) {
    if (localUserId) {
      const user = await prisma.user.findUnique({ where: { id: localUserId } });
      const own = user?.cloudUserId ? storedLicenseFor(user.cloudUserId) : null;
      if (own?.claims.role === 'ADMIN') return own.token;
    }
    return allStoredLicenses().filter((l) => l.claims.role === 'ADMIN').sort((a, b) => b.claims.exp - a.claims.exp)[0]?.token || null;
  }

  async publish(localUserId?: string): Promise<PublishResult> {
    if (!(await this.cloud.linkedTenant())) return { ok: false, code: 'NOT_LINKED' };
    const token = await this.adminLicense(localUserId);
    if (!token) return { ok: false, code: 'NO_ADMIN_LICENSE' };
    const { body, hash } = await this.siteBody(token);
    const res = await this.request('PUT', '/v1/site', token, body);
    if (!res) return { ok: false, code: 'OFFLINE' };
    if (res.status === 409) return { ok: false, code: 'SLUG_TAKEN' };
    if (res.status !== 200) {
      const code = typeof res.body?.code === 'string' ? res.body.code : `HTTP_${res.status}`;
      console.warn(`[página] no se pudo publicar: ${code} (HTTP ${res.status})`);
      return { ok: false, code };
    }
    await prisma.businessSettings.update({
      where: { id: SETTINGS_ID },
      data: { bookingSlug: res.body.slug, bookingPublishedAt: new Date(), bookingPublishedHash: hash },
    });
    return { ok: true, slug: res.body.slug };
  }

  // ── Sincronizar ───────────────────────────────────────────
  async sync(): Promise<{ ok: boolean; imported?: number; pushed?: number; members?: number; prizes?: number; orders?: number; reason?: string }> {
    if (this.running) return { ok: false, reason: 'BUSY' };
    this.running = true;
    try {
      if (!(await this.cloud.linkedTenant())) return { ok: false, reason: 'NOT_LINKED' };
      const { row, hash, bookingOn, pageOn, sections } = await this.siteBody(await this.adminLicense());
      if (!bookingOn && !pageOn) {
        // Se apagó todo: la página publicada se cierra una vez
        if (row?.bookingPublishedAt && row.bookingPublishedHash !== hash) await this.publish();
        return { ok: false, reason: 'DISABLED' };
      }
      // Carta, mesas, horario, juego o nombre cambiaron desde la última publicación
      if (row?.bookingPublishedHash !== hash) await this.publish();

      const license = allStoredLicenses().sort((a, b) => b.claims.exp - a.claims.exp)[0]?.token;
      if (!license) return { ok: false, reason: 'NO_LICENSE' };

      let members = 0;
      let prizes = 0;
      // Primero se suben los sellos en cola: así el saldo que baja de la nube ya los incluye
      await this.pushStampEvents();
      if (sections.signup || sections.games || (await prisma.stampToken.count({ where: { synced: false } }))) {
        const inbox = await this.pullInbox(license, row?.pageSyncCursors);
        if (inbox) ({ members, prizes } = inbox);
        await this.syncStampTokens(license);
      }
      // Pedidos: también cuando se apagaron, para cerrar los que quedaron abiertos
      const orders = sections.orders || (await this.onlineOrders.dirty()).length ? await this.syncOrders(license, row?.ordersSyncCursor) : 0;
      if (!bookingOn) {
        await prisma.businessSettings.update({ where: { id: SETTINGS_ID }, data: { bookingSyncAt: new Date() } });
        return { ok: true, imported: 0, pushed: 0, members, prizes, orders };
      }

      let cursor = row?.bookingSyncCursor || undefined;
      let imported = 0;
      let pushed = 0;
      for (let round = 0; round < 5; round++) {
        const dirty = await prisma.reservation.findMany({ where: { dirty: true }, take: 300, orderBy: { updatedAt: 'asc' } });
        const res = await this.request('POST', '/v1/reservations/sync', license, {
          cursor,
          // Solo mesa, horas y estado: los datos del cliente se quedan en el negocio
          changes: dirty.map((r) => ({ id: r.id, code: r.code, tableId: r.tableId, partySize: r.partySize, startsAt: r.startsAt, endsAt: r.endsAt, status: r.status })),
        });
        if (!res) return { ok: false, reason: 'OFFLINE' };
        if (res.status !== 200) return { ok: false, reason: res.body?.code || `HTTP_${res.status}` };

        // Lo subido queda limpio, salvo que lo hayan vuelto a cambiar mientras tanto
        for (const r of dirty) {
          await prisma.reservation.updateMany({ where: { id: r.id, updatedAt: r.updatedAt }, data: { dirty: false } });
        }
        pushed += dirty.length;
        for (const incoming of res.body.reservations || []) {
          if (await this.importOnline(incoming)) imported++;
        }
        if (Array.isArray(res.body.conflicts) && res.body.conflicts.length) {
          await prisma.reservation.updateMany({ where: { id: { in: res.body.conflicts } }, data: { cloudConflict: true } });
        }
        cursor = res.body.cursor;
        if (!res.body.more && dirty.length < 300) break;
      }
      await prisma.businessSettings.update({ where: { id: SETTINGS_ID }, data: { bookingSyncCursor: cursor ?? null, bookingSyncAt: new Date() } });
      if (imported) console.log(`📅 Reservas: ${imported} nueva(s) o actualizada(s) desde la página`);
      return { ok: true, imported, pushed, members, prizes, orders };
    } catch (err: any) {
      console.warn('[reservas] sincronización:', err?.message || err);
      return { ok: false, reason: 'ERROR' };
    } finally {
      this.running = false;
    }
  }

  // ── Pedidos en línea ──────────────────────────────────────
  /** Sube los estados que cambió la caja y trae los pedidos nuevos; devuelve cuántos llegaron */
  private async syncOrders(license: string, cursor: string | null | undefined) {
    let count = 0;
    for (let round = 0; round < 5; round++) {
      const dirty = await this.onlineOrders.dirty();
      const res = await this.request('POST', '/v1/site/orders/sync', license, {
        cursor: cursor || undefined,
        updates: dirty.map((o) => ({ id: o.id, status: o.status, note: o.statusNote })),
      });
      if (!res || res.status !== 200) break; // sin conexión o sin el plan: se intenta en la próxima vuelta
      await this.onlineOrders.markClean(dirty);
      for (const o of res.body.orders || []) {
        if (!(await this.onlineOrders.importFromCloud(o, (r) => this.customerFor(r)))) continue;
        count++;
        // Los pedidos viejos o ya resueltos (p. ej. al vincular un equipo nuevo) entran sin avisar
        const placed = Date.parse(o.createdAt);
        if (o.status !== 'PENDING' || (Number.isFinite(placed) && Date.now() - placed > NOTIFY_ORDER_MAX_AGE_MS)) continue;
        notify('ONLINE_ORDER', { code: o.code ?? null, name: o.customerName ?? null, total: Number(o.total) || 0, kind: o.kind ?? null });
      }
      cursor = res.body.cursor;
      await prisma.businessSettings.update({ where: { id: SETTINGS_ID }, data: { ordersSyncCursor: cursor ?? null } });
      if (!res.body.more && dirty.length < 300) break;
    }
    if (count) console.log(`🛵 Pedidos web: ${count} nuevo(s) desde la página`);
    return count;
  }

  // ── Tokens de Sellos QR para clientes ─────────────────────
  private async syncStampTokens(license: string) {
    try {
      const pending = await prisma.stampToken.findMany({
        where: { synced: false },
        take: 50,
      });
      if (!pending.length) return 0;

      const res = await this.request('POST', '/v1/site/stamps/tokens', license, {
        tokens: pending.map((t) => ({
          id: t.id,
          saleId: t.saleId,
          stamps: t.stamps,
          gamePlays: t.gamePlays,
          totalAmount: t.totalAmount,
          expiresAt: t.expiresAt.toISOString(),
        })),
      });

      if (res && res.status === 200) {
        await prisma.stampToken.updateMany({
          where: { id: { in: pending.map((t) => t.id) } },
          data: { synced: true },
        });
        return pending.length;
      }
    } catch (e) {
      console.warn('[SyncStampTokens] Error al sincronizar sellos:', e);
    }
    return 0;
  }

  // ── Sellos en vivo hacia la tarjeta digital ────────────────
  /** Tras una venta o un ajuste: sube la cola enseguida (agrupa los que llegan juntos) */
  stampsSoon() {
    if (this.stampTimer) clearTimeout(this.stampTimer);
    this.stampTimer = setTimeout(() => {
      this.stampTimer = null;
      this.pushStampEvents().catch(() => {});
    }, 300);
  }

  /**
   * Sube los sellos en cola. La nube responde cómo quedó cada tarjeta y la caja copia
   * ese saldo (la nube manda: allí se entrega el premio al completar la tarjeta).
   * Sin internet no pasa nada: la cola espera a la próxima vuelta.
   */
  async pushStampEvents(): Promise<number> {
    if (this.pushingStamps) return 0;
    this.pushingStamps = true;
    try {
      if (!(await this.cloud.linkedTenant())) return 0;
      const license = allStoredLicenses().sort((a, b) => b.claims.exp - a.claims.exp)[0]?.token;
      if (!license) return 0;
      let sent = 0;
      for (let round = 0; round < 5; round++) {
        const queued = await prisma.stampEvent.findMany({ where: { status: 'QUEUED' }, orderBy: { createdAt: 'asc' }, take: 100 });
        if (!queued.length) break;
        const customers = new Map(
          (await prisma.customer.findMany({ where: { id: { in: [...new Set(queued.map((e) => e.customerId))] } } })).map((c) => [c.id, c]),
        );
        const res = await this.request('POST', '/v1/site/stamps/events', license, {
          events: queued.map((e) => ({
            id: e.id,
            customerId: customers.get(e.customerId)?.cloudId || undefined,
            phone: customers.get(e.customerId)?.phone || undefined,
            stamps: e.stamps,
            gamePlays: e.gamePlays,
            saleId: e.saleId || undefined,
            reason: e.reason || undefined,
          })),
        });
        if (!res || res.status !== 200) break; // sin conexión o sin el plan: siguen en cola
        const byId = new Map(queued.map((e) => [e.id, e]));
        for (const r of res.body.results || []) {
          const event = byId.get(r.id);
          if (!event) continue;
          await prisma.stampEvent.update({
            where: { id: event.id },
            data: { status: r.status === 'APPLIED' ? 'APPLIED' : 'WAITING_SIGNUP', syncedAt: new Date() },
          });
          const customer = customers.get(event.customerId);
          if (r.status !== 'APPLIED' || r.stampsBalance == null || !customer) continue;
          // Si quedan otros sellos de este cliente en cola, el saldo de la nube aún no los incluye
          const pending = await prisma.stampEvent.count({ where: { customerId: customer.id, status: 'QUEUED' } });
          const taken = r.customerId && !customer.cloudId ? await prisma.customer.findUnique({ where: { cloudId: r.customerId } }) : null;
          await prisma.customer.update({
            where: { id: customer.id },
            data: {
              ...(pending ? {} : { stampsCount: Math.max(0, Number(r.stampsBalance) || 0), lifetimeStamps: Math.max(0, Number(r.lifetimeStamps) || 0) }),
              // Ya tenía tarjeta en la página con ese celular: queda enlazado
              ...(r.customerId && !customer.cloudId && !taken ? { cloudId: r.customerId } : {}),
            },
          });
        }
        sent += queued.length;
        if (queued.length < 100) break;
      }
      if (sent) console.log(`🏷️ Fidelidad: ${sent} movimiento(s) de sellos enviados a las tarjetas`);
      return sent;
    } catch (e: any) {
      console.warn('[fidelidad] no se pudieron subir los sellos:', e?.message || e);
      return 0;
    } finally {
      this.pushingStamps = false;
    }
  }

  /** Enlace de un solo uso para que el cliente recupere su tarjeta en otro celular */
  async cardLink(customerId: string): Promise<{ ok: true; url: string; expiresAt: string; phone: string | null } | { ok: false; code: string }> {
    if (!(await this.cloud.linkedTenant())) return { ok: false, code: 'NOT_LINKED' };
    const customer = await prisma.customer.findUnique({ where: { id: customerId } });
    if (!customer) return { ok: false, code: 'NOT_FOUND' };
    const license = allStoredLicenses().sort((a, b) => b.claims.exp - a.claims.exp)[0]?.token;
    if (!license) return { ok: false, code: 'NO_LICENSE' };
    const res = await this.request('POST', '/v1/site/members/recovery-link', license, {
      customerId: customer.cloudId || undefined,
      phone: customer.phone || undefined,
    });
    if (!res) return { ok: false, code: 'OFFLINE' };
    if (res.status === 404) return { ok: false, code: res.body?.code === 'SITE_NOT_FOUND' ? 'NO_PAGE' : 'NO_CARD' };
    if (res.status !== 200) return { ok: false, code: res.body?.code || 'ERROR' };
    return { ok: true, url: res.body.url, expiresAt: res.body.expiresAt, phone: res.body.phone || customer.phone || null };
  }

  // ── Registros y premios de la página ──────────────────────
  private async pullInbox(license: string, rawCursors: string | null | undefined) {
    let cursors = parse(rawCursors) as { customersCursor?: string; playsCursor?: string; stampsCursor?: string };
    let members = 0;
    let prizes = 0;
    for (let round = 0; round < 5; round++) {
      const res = await this.request('POST', '/v1/site/inbox', license, cursors);
      if (!res || res.status !== 200) break; // sin conexión o sin el plan: se intenta en la próxima vuelta
      for (const c of res.body.customers || []) if (await this.importMember(c)) members++;
      for (const p of res.body.prizes || []) if (await this.importPrize(p)) prizes++;
      for (const st of res.body.stamps || []) await this.importStamps(st);
      cursors = { customersCursor: res.body.customersCursor, playsCursor: res.body.playsCursor, stampsCursor: res.body.stampsCursor };
      await prisma.businessSettings.update({ where: { id: SETTINGS_ID }, data: { pageSyncCursors: JSON.stringify(cursors) } });
      if (!res.body.more) break;
    }
    if (members || prizes) console.log(`🎉 Mi página: ${members} registro(s) y ${prizes} premio(s) nuevos`);
    return { members, prizes };
  }

  /** Quien se registró en la página queda en Clientes (o se borra si lo pidió) */
  private async importMember(c: any): Promise<boolean> {
    const existing = await prisma.customer.findUnique({ where: { cloudId: c.id } });
    if (c.deleted) {
      if (!existing) return false;
      // Ley 1581: se suprimen sus datos personales; las ventas quedan sin nombre
      await prisma.customer.update({
        where: { id: existing.id },
        data: { name: 'Cliente que pidió borrar sus datos', phone: null, email: null, birthDate: null, marketingOptIn: false, isActive: false, consentAt: null },
      });
      return true;
    }
    if (!c.name || !c.consentAt) return false;
    const data = {
      name: String(c.name).slice(0, 120),
      phone: c.phone || null,
      ...(c.email ? { email: String(c.email).slice(0, 120) } : {}),
      ...(birthDateFrom(c.birthDay, c.birthMonth) ? { birthDate: birthDateFrom(c.birthDay, c.birthMonth) } : {}),
      consentAt: new Date(c.consentAt),
      consentVersion: c.consentVersion || null,
      marketingOptIn: !!c.marketingOptIn,
    };
    if (existing) {
      await prisma.customer.update({ where: { id: existing.id }, data: { ...data, isActive: true } });
      return true;
    }
    // ¿Ya era cliente del negocio con ese celular? Se enlaza en vez de duplicarlo
    const phone = normalizePhone(c.phone);
    const match = phone.length >= 7
      ? await prisma.customer.findFirst({ where: { isActive: true, isDefault: false, cloudId: null, phone: { contains: phone.slice(-10) } }, orderBy: { updatedAt: 'desc' } })
      : null;
    if (match) await prisma.customer.update({ where: { id: match.id }, data: { ...data, cloudId: c.id } });
    else await prisma.customer.create({ data: { ...data, cloudId: c.id, source: 'ONLINE' } });
    notify('NEW_CUSTOMER', { name: data.name });
    return true;
  }

  /** Saldo de la tarjeta que cambió en la página (QR del ticket, jugadas); lo que sigue en cola manda */
  private async importStamps(st: any) {
    if (!st?.customerId) return;
    const customer = await prisma.customer.findUnique({ where: { cloudId: st.customerId } });
    if (!customer) return;
    if (await prisma.stampEvent.count({ where: { customerId: customer.id, status: 'QUEUED' } })) return;
    await prisma.customer.update({
      where: { id: customer.id },
      data: { stampsCount: Math.max(0, Number(st.stampsBalance) || 0), lifetimeStamps: Math.max(0, Number(st.lifetimeStamps) || 0) },
    });
  }

  /** Un premio ganado es un cupón de un solo uso a nombre del cliente */
  private async importPrize(p: any): Promise<boolean> {
    if (!p.code || (await prisma.coupon.findUnique({ where: { code: p.code } }))) return false;
    const owner = p.customerId ? await prisma.customer.findUnique({ where: { cloudId: p.customerId } }) : null;
    await prisma.coupon.create({
      data: {
        code: String(p.code).slice(0, 20),
        description: `Premio de la página: ${String(p.label || '').slice(0, 80)}`,
        type: p.kind === 'AMOUNT' ? 'AMOUNT' : 'PERCENT',
        value: Number(p.value) || 0,
        minPurchase: p.minPurchase ? Number(p.minPurchase) : null,
        startsAt: p.createdAt ? new Date(p.createdAt) : null,
        endsAt: p.expiresAt ? new Date(p.expiresAt) : null,
        maxUses: 1,
        source: 'GAME',
        customerId: owner?.id ?? null,
        createdBy: 'Página del negocio',
      },
    });
    // El premio de la tarjeta de sellos llena se avisa distinto al de los juegos
    notify(p.prizeId === 'loyalty-stamp-reward' ? 'CARD_COMPLETE' : 'PRIZE', { name: owner?.name ?? null, label: p.label ?? null, code: p.code });
    return true;
  }

  /** Agenda (o actualiza) una reserva hecha en la página; devuelve true si cambió algo */
  private async importOnline(r: any): Promise<boolean> {
    const existing = await prisma.reservation.findUnique({ where: { id: r.id } });
    const tableId = r.tableId && (await prisma.table.findUnique({ where: { id: r.tableId } })) ? r.tableId : null;
    const common = {
      tableId,
      partySize: Math.max(1, Number(r.partySize) || 1),
      startsAt: new Date(r.startsAt),
      endsAt: new Date(r.endsAt),
      status: r.status,
      cancelReason: r.cancelReason || null,
      cloudConflict: !!r.conflict,
      dirty: false,
    };
    if (existing) {
      // Si alguien la cambió en la caja y aún no subió, gana el cambio de la caja
      if (existing.dirty) return false;
      await prisma.reservation.update({ where: { id: r.id }, data: common });
      return existing.status !== r.status || existing.startsAt.getTime() !== common.startsAt.getTime();
    }
    if (!r.customerName) return false; // datos ya borrados de la nube (reserva vieja)
    const customerId = await this.customerFor(r);
    try {
      await prisma.reservation.create({
        data: {
          id: r.id,
          code: r.code,
          ...common,
          customerId,
          customerName: String(r.customerName).slice(0, 120),
          customerPhone: r.customerPhone || null,
          customerEmail: r.customerEmail || null,
          notes: r.notes || null,
          channel: 'ONLINE',
          createdBy: 'Página de reservas',
          consentAt: r.consentAt ? new Date(r.consentAt) : null,
          marketingOptIn: !!r.marketingOptIn,
        },
      });
      notify('RESERVATION', { code: r.code ?? null, name: String(r.customerName).slice(0, 120), party: Math.max(1, Number(r.partySize) || 1), startsAt: r.startsAt ?? null });
      return true;
    } catch (err: any) {
      console.warn('[reservas] no se pudo agendar la reserva de la página', r.code, err?.code || err?.message);
      return false;
    }
  }

  /** Quien reservó en la página queda en Clientes (lo autorizó al reservar) */
  private async customerFor(r: any) {
    const phone = digits(r.customerPhone);
    if (phone.length >= 7) {
      const match = await prisma.customer.findFirst({
        where: { isActive: true, isDefault: false, phone: { contains: phone.slice(-10) } },
        orderBy: { updatedAt: 'desc' },
      });
      if (match) {
        // Aceptar promociones al reservar se respeta; nunca se apaga por una reserva
        if (r.marketingOptIn && !match.marketingOptIn) await prisma.customer.update({ where: { id: match.id }, data: { marketingOptIn: true } });
        return match.id;
      }
    }
    if (!r.consentAt) return null;
    const created = await prisma.customer.create({
      data: {
        name: String(r.customerName).slice(0, 120),
        phone: r.customerPhone || null,
        email: r.customerEmail || null,
        source: 'ONLINE',
        consentAt: new Date(r.consentAt),
        consentVersion: r.consentVersion || null,
        marketingOptIn: !!r.marketingOptIn,
      },
    });
    return created.id;
  }

  // ── Programación ──────────────────────────────────────────
  start() {
    if (this.started) return;
    this.started = true;
    setTimeout(() => this.sync(), 15_000);
    setInterval(() => this.sync(), TICK_MS);
  }

  /** Tras un cambio en la caja: sube pronto (agrupa cambios seguidos) */
  kick() {
    if (!this.started) return;
    if (this.kickTimer) clearTimeout(this.kickTimer);
    this.kickTimer = setTimeout(() => {
      this.kickTimer = null;
      this.sync();
    }, 1500);
  }
}

