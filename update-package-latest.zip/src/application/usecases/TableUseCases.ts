// ============================================
// APPLICATION USE CASES - Table Use Cases
// ============================================

import { ITableRepository } from '../../domain/repositories/index';
import { isValidTableStatusTransition, TableStatus } from '../../domain/entities';
import { CreateTableDTO, UpdateTableDTO } from '../dtos';
import { prisma } from '../../infrastructure/database/prisma';
import { markDirty, statusAfterClose } from './v3/FloorUseCases';

export class TableUseCases {
  constructor(private tableRepository: ITableRepository) {}

  /** Al cobrar o liberar: libre, o "por limpiar" si el negocio usa esa función */
  private async freeTable(id: string) {
    if ((await statusAfterClose()) === 'DIRTY') {
      await markDirty(id);
      return this.tableRepository.getById(id);
    }
    return this.tableRepository.updateStatus(id, 'AVAILABLE');
  }

  /** El número identifica la mesa en caja, cocina y tickets: no se repite */
  private async assertNumberFree(number: string, exceptId?: string) {
    const clean = String(number ?? '').trim();
    if (!clean) throw new Error('Escribe el número o nombre de la mesa.');
    if (clean.length > 20) throw new Error('El número de la mesa es demasiado largo (máximo 20 caracteres).');
    const all = await prisma.table.findMany({ select: { id: true, number: true } });
    if (all.some((t) => t.id !== exceptId && t.number.trim().toLowerCase() === clean.toLowerCase())) {
      throw new Error(`Ya existe la mesa ${clean}.`);
    }
    return clean;
  }

  private assertCapacity(capacity: unknown) {
    if (capacity === undefined) return undefined;
    const n = Math.round(Number(capacity));
    if (!Number.isFinite(n) || n < 1 || n > 50) throw new Error('La capacidad debe estar entre 1 y 50 personas.');
    return n;
  }

  async createTable(data: CreateTableDTO) {
    const number = await this.assertNumberFree(data.number);
    return this.tableRepository.create({ ...data, number, capacity: this.assertCapacity(data.capacity) ?? 4 });
  }

  async getTableById(id: string) {
    return this.tableRepository.getById(id);
  }

  async getAllTables() {
    return this.tableRepository.getAll();
  }

  async getTablesByStatus(status: TableStatus) {
    return this.tableRepository.getByStatus(status);
  }

  async getAvailableTables() {
    return this.tableRepository.getAvailable();
  }

  async updateTable(id: string, data: UpdateTableDTO) {
    const next = { ...data };
    if (data.number !== undefined) next.number = await this.assertNumberFree(data.number, id);
    if (data.capacity !== undefined) next.capacity = this.assertCapacity(data.capacity);
    return this.tableRepository.update(id, next);
  }

  async occupyTable(id: string) {
    // Ya no se usa - eliminado para simplificar
    throw new Error('Función deshabilitada');
  }

  async orderTable(id: string) {
    const table = await this.tableRepository.getById(id);
    if (!table) throw new Error('Mesa no encontrada');

    // AVAILABLE → ORDERED (hacer pedido)
    // ORDERED → ORDERED (agregar pedido adicional)
    // PENDING → ORDERED (agregar pedido adicional durante un cobro parcial o tras error)
    if (table.status !== 'AVAILABLE' && table.status !== 'ORDERED' && table.status !== 'PENDING' && table.status !== 'DIRTY') {
      throw new Error(`No se puede ordenar desde estado: ${table.status}`);
    }
    // Sentaron clientes en una mesa que nadie marcó como limpia: cuenta como limpiada ahora
    if (table.status === 'DIRTY') {
      await prisma.tableCleaning.updateMany({ where: { tableId: id, cleanedAt: null }, data: { cleanedAt: new Date() } });
      await prisma.table.update({ where: { id }, data: { dirtyAt: null } });
    }

    return this.tableRepository.updateStatus(id, 'ORDERED');
  }

  async releaseTable(id: string) {
    const table = await this.tableRepository.getById(id);
    if (!table) throw new Error('Mesa no encontrada');

    // ORDERED → AVAILABLE (cancelar/Liberar)
    // PENDING → AVAILABLE (confirmar pago y liberar)
    if (table.status !== 'ORDERED' && table.status !== 'PENDING') {
      throw new Error(`No se puede liberar la mesa desde estado: ${table.status}`);
    }

    // Abierta pero sin nada pedido: queda libre de una vez (no hay nada que limpiar)
    if (await this.nothingOrdered(id)) return this.tableRepository.updateStatus(id, 'AVAILABLE');
    return this.freeTable(id);
  }

  /** La mesa se abrió pero nunca se envió nada a cocina ni se cobró nada */
  async nothingOrdered(id: string) {
    const [sent, sales, sentOrders] = await Promise.all([
      prisma.orderItem.count({
        where: {
          sentAt: { not: null },
          status: { not: 'CANCELLED' },
          order: { tableId: id, status: { in: ['ACTIVE', 'SENT', 'IN_PREP', 'READY'] } },
        },
      }),
      prisma.sale.count({ where: { tableId: id, status: 'PENDING' } }),
      // Una comanda que ya pasó a cocina cuenta como pedido aunque no tenga productos
      prisma.order.count({ where: { tableId: id, status: { in: ['SENT', 'IN_PREP', 'READY'] } } }),
    ]);
    return sent === 0 && sales === 0 && sentOrders === 0;
  }

  async setPending(id: string) {
    const table = await this.tableRepository.getById(id);
    if (!table) throw new Error('Mesa no encontrada');

    // ORDERED → PENDING (cobrar)
    if (table.status !== 'ORDERED') {
      throw new Error(`No se puede cobrar desde estado: ${table.status}`);
    }

    return this.tableRepository.updateStatus(id, 'PENDING');
  }

  async closeTable(id: string) {
    const table = await this.tableRepository.getById(id);
    if (!table) throw new Error('Mesa no encontrada');

    // PENDING o ORDERED → AVAILABLE (confirmar pago)
    if (table.status !== 'PENDING' && table.status !== 'ORDERED') {
      throw new Error(`No se puede cerrar la mesa desde estado: ${table.status}`);
    }

    // Solo loguear si hay ventas pendientes por si acaso, pero permitir cerrar para no bloquear al usuario
    const pendingSales = await prisma.sale.findMany({
      where: { 
        tableId: id, 
        status: 'PENDING'
      }
    });
    
    if (pendingSales.length > 0) {
      console.warn(`Cerrando mesa ${id} con ${pendingSales.length} ventas pendientes detectadas.`);
    }

    return this.freeTable(id);
  }

  /**
   * Una mesa con pedido abierto no se borra. Las ventas y pedidos ya cerrados
   * se conservan (quedan sin mesa asignada) para no perder la historia.
   */
  async deleteTable(id: string) {
    const table = await prisma.table.findUnique({ where: { id } });
    if (!table) throw new Error('Mesa no encontrada');
    const active = await prisma.order.count({ where: { tableId: id, status: { notIn: ['COMPLETED', 'CANCELLED'] } } });
    if (table.status !== 'AVAILABLE' || active > 0) {
      throw new Error(`La mesa ${table.number} tiene un pedido abierto. Ciérralo antes de eliminarla.`);
    }
    await prisma.$transaction([
      prisma.sale.updateMany({ where: { tableId: id }, data: { tableId: null } }),
      prisma.order.updateMany({ where: { tableId: id }, data: { tableId: null } }),
      prisma.table.delete({ where: { id } }),
    ]);
  }
}