// ============================================
// APPLICATION - Cupones y promociones
// ============================================
// El descuento de un cupón lo calcula SIEMPRE el servidor al cobrar (la caja
// solo envía el código): así no se puede inflar desde el navegador.

import { prisma } from '../../infrastructure/database/prisma';

export class CouponError extends Error {
  constructor(public status: number, public code: string, message: string) {
    super(message);
    this.name = CouponError.name;
  }
}

export interface CouponInput {
  code?: string;
  description?: string | null;
  type?: 'PERCENT' | 'AMOUNT';
  value?: number;
  minPurchase?: number | null;
  startsAt?: string | null;
  endsAt?: string | null;
  maxUses?: number | null;
  isActive?: boolean;
}

const normCode = (v: unknown) => (typeof v === 'string' ? v.trim().toUpperCase().replace(/[^A-Z0-9-]/g, '').slice(0, 24) : '');
const optDate = (v: unknown) => {
  if (v === null || v === '' || v === undefined) return null;
  const d = new Date(String(v));
  return Number.isNaN(d.getTime()) ? null : d;
};

type CouponRow = NonNullable<Awaited<ReturnType<typeof prisma.coupon.findUnique>>>;

export class CouponUseCases {
  async list() {
    return prisma.coupon.findMany({ orderBy: [{ isActive: 'desc' }, { createdAt: 'desc' }] });
  }

  private parse(input: CouponInput, partial = false) {
    const data: Record<string, unknown> = {};
    if (!partial || input.code !== undefined) {
      const code = normCode(input.code);
      if (code.length < 3) throw new CouponError(400, 'COUPON_CODE_INVALID', 'El código debe tener al menos 3 letras o números.');
      data.code = code;
    }
    if (!partial || input.type !== undefined) data.type = input.type === 'AMOUNT' ? 'AMOUNT' : 'PERCENT';
    if (!partial || input.value !== undefined) {
      const value = Number(input.value);
      const type = (data.type as string) || input.type;
      if (!Number.isFinite(value) || value <= 0 || (type !== 'AMOUNT' && value > 100)) {
        throw new CouponError(400, 'COUPON_VALUE_INVALID', 'El descuento debe ser mayor que cero (y máximo 100 % si es porcentaje).');
      }
      data.value = Math.round(value * 100) / 100;
    }
    if (input.description !== undefined) data.description = typeof input.description === 'string' ? input.description.trim().slice(0, 200) || null : null;
    if (input.minPurchase !== undefined) data.minPurchase = input.minPurchase ? Math.max(0, Math.round(Number(input.minPurchase))) : null;
    if (input.maxUses !== undefined) data.maxUses = input.maxUses ? Math.max(1, Math.round(Number(input.maxUses))) : null;
    if (input.startsAt !== undefined) data.startsAt = optDate(input.startsAt);
    if (input.endsAt !== undefined) data.endsAt = optDate(input.endsAt);
    if (input.isActive !== undefined) data.isActive = !!input.isActive;
    return data;
  }

  async create(input: CouponInput, actor?: string, source: 'MANUAL' | 'AGENT' = 'MANUAL') {
    const data = this.parse(input);
    if (await prisma.coupon.findUnique({ where: { code: data.code as string } })) {
      throw new CouponError(409, 'COUPON_CODE_TAKEN', `Ya existe el cupón ${data.code}.`);
    }
    return prisma.coupon.create({ data: { ...(data as any), source, createdBy: actor || null } });
  }

  async update(id: string, input: CouponInput) {
    if (!(await prisma.coupon.findUnique({ where: { id } }))) throw new CouponError(404, 'COUPON_NOT_FOUND', 'Cupón no encontrado.');
    const data = this.parse(input, true);
    if (data.code) {
      const other = await prisma.coupon.findUnique({ where: { code: data.code as string } });
      if (other && other.id !== id) throw new CouponError(409, 'COUPON_CODE_TAKEN', `Ya existe el cupón ${data.code}.`);
    }
    return prisma.coupon.update({ where: { id }, data });
  }

  /** ¿Sirve este cupón para una cuenta de este subtotal? Devuelve el descuento exacto */
  check(coupon: CouponRow | null, subtotal: number, now = new Date()) {
    if (!coupon || !coupon.isActive) throw new CouponError(404, 'COUPON_NOT_FOUND', 'Ese cupón no existe o está desactivado.');
    if (coupon.startsAt && now < coupon.startsAt) throw new CouponError(409, 'COUPON_NOT_STARTED', 'Ese cupón todavía no está vigente.');
    if (coupon.endsAt && now > coupon.endsAt) throw new CouponError(409, 'COUPON_EXPIRED', 'Ese cupón ya venció.');
    if (coupon.maxUses && coupon.uses >= coupon.maxUses) throw new CouponError(409, 'COUPON_EXHAUSTED', 'Ese cupón ya se usó todas las veces permitidas.');
    if (coupon.minPurchase && subtotal < coupon.minPurchase) {
      throw new CouponError(409, 'COUPON_MIN_PURCHASE', `Ese cupón aplica desde una compra de $${Math.round(coupon.minPurchase).toLocaleString('es-CO')}.`);
    }
    const discount = coupon.type === 'AMOUNT' ? Math.min(coupon.value, subtotal) : Math.round(subtotal * (coupon.value / 100));
    return { code: coupon.code, type: coupon.type, value: coupon.value, description: coupon.description, discount: Math.round(discount) };
  }

  async validate(code: string, subtotal: number) {
    return this.check(await prisma.coupon.findUnique({ where: { code: normCode(code) } }), Math.max(0, Number(subtotal) || 0));
  }

  /** Estadísticas para el agente de marketing (sin datos de clientes) */
  async usageSummary() {
    const coupons = await prisma.coupon.findMany({ orderBy: { createdAt: 'desc' }, take: 30 });
    const sales = await prisma.sale.groupBy({
      by: ['couponCode'],
      where: { couponCode: { not: null }, status: 'COMPLETED' },
      _count: true,
      _sum: { discount: true, total: true },
    });
    return coupons.map((c) => {
      const s = sales.find((x) => x.couponCode === c.code);
      return { code: c.code, type: c.type, value: c.value, isActive: c.isActive, uses: c.uses, endsAt: c.endsAt, sales: s?._count ?? 0, discountGiven: s?._sum.discount ?? 0, revenue: s?._sum.total ?? 0 };
    });
  }
}
