// ============================================
// APPLICATION - Kiosco de autoservicio (Fase 4 · 16)
// ============================================
// La tablet del kiosco (pantalla emparejada con código) pide la carta y envía el
// pedido. Entra como pedido en línea con canal KIOSK: la caja lo ve con los de la
// página (Domicilios → Pedidos web), lo acepta (va a cocina) y lo cobra con su
// número. Nunca se sube a la nube. Los precios son los de la carta de la caja.

import crypto from 'crypto';
import { prisma } from '../../infrastructure/database/prisma';
import { AuditLogger } from '../../infrastructure/services/AuditLogger';
import { publish } from '../../shared/liveEvents';
import { normalizeNames } from '../../domain/v3/features';
import { buildKioskOrder, KIOSK_IDLE_SECONDS, kioskCode, kioskNumber, type KioskCatalogVariant } from '../../domain/kiosk';

export const KIOSK_CHANNEL = 'KIOSK';

const isPaused = (p: { pausedUntil: Date | null }, now: Date) => !!p.pausedUntil && p.pausedUntil > now;

export class KioskUseCases {
  private async products(now: Date) {
    const rows = await prisma.product.findMany({
      where: { isActive: true },
      select: {
        id: true, name: true, description: true, imageUrl: true, categoryId: true, ingredients: true, pausedUntil: true,
        variants: { where: { isActive: true }, select: { id: true, name: true, price: true }, orderBy: { price: 'asc' } },
      },
      orderBy: { name: 'asc' },
    });
    return rows.filter((p) => p.variants.length && !isPaused(p, now));
  }

  /** Los más pedidos de los últimos 30 días (para "Lo más pedido" y "¿Algo más?") */
  private async popular(products: { id: string; variants: { id: string }[] }[], now: Date) {
    const productOf = new Map(products.flatMap((p) => p.variants.map((v) => [v.id, p.id] as const)));
    const rows = await prisma.orderItem.groupBy({
      by: ['productVariantId'],
      where: { isCancelled: false, createdAt: { gte: new Date(now.getTime() - 30 * 86_400_000) } },
      _sum: { quantity: true },
      orderBy: { _sum: { quantity: 'desc' } },
      take: 60,
    }).catch(() => [] as { productVariantId: string; _sum: { quantity: number | null } }[]);
    const out: string[] = [];
    for (const r of rows) {
      const id = productOf.get(r.productVariantId);
      if (id && !out.includes(id)) out.push(id);
      if (out.length >= 8) break;
    }
    return out;
  }

  /** La carta para la tablet: categorías, fotos, presentaciones y precios (sin costos ni inventario) */
  async menu(display: { name: string; type: string }, now = new Date()) {
    const [s, categories, products] = await Promise.all([
      prisma.businessSettings.findUnique({ where: { id: 'default' }, select: { businessName: true, logoUrl: true, paymentQrUrl: true, paymentQrLabel: true } }),
      prisma.category.findMany({ orderBy: { name: 'asc' }, select: { id: true, name: true } }),
      this.products(now),
    ]);
    const used = new Set(products.map((p) => p.categoryId));
    return {
      now: now.toISOString(),
      display: { name: display.name, type: display.type, station: null },
      business: { name: s?.businessName || '', logoUrl: s?.logoUrl || null },
      paymentQr: s?.paymentQrUrl ? { url: s.paymentQrUrl, label: s.paymentQrLabel || '' } : null,
      idleSeconds: KIOSK_IDLE_SECONDS,
      categories: categories.filter((c) => used.has(c.id)),
      popular: await this.popular(products, now),
      products: products.map((p) => ({
        id: p.id,
        name: p.name,
        description: p.description,
        imageUrl: p.imageUrl,
        categoryId: p.categoryId,
        removable: normalizeNames(p.ingredients),
        variants: p.variants,
      })),
    };
  }

  /** La tablet envía el pedido: queda por aceptar en la caja */
  async order(raw: unknown, display: { id: string; name: string }, now = new Date()) {
    const products = await this.products(now);
    const catalog = new Map<string, KioskCatalogVariant>();
    for (const p of products) for (const v of p.variants) catalog.set(v.id, { id: v.id, name: v.name, price: v.price, productName: p.name, available: true });
    const draft = buildKioskOrder(raw, catalog);
    const toGo = !!raw && typeof raw === 'object' && (raw as { dineIn?: unknown }).dineIn === 'TOGO';
    // Los ingredientes quitados llegan como nota de la línea ("Sin cebolla"), como en la página

    const dayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const today = await prisma.onlineOrder.count({ where: { channel: KIOSK_CHANNEL, placedAt: { gte: dayStart } } });
    let created = null;
    for (let attempt = 1; attempt <= 5 && !created; attempt++) {
      const code = kioskCode(today + attempt, now);
      created = await prisma.onlineOrder.create({
        data: {
          id: `kiosk-${crypto.randomUUID()}`,
          code,
          kind: 'PICKUP',
          channel: KIOSK_CHANNEL,
          status: 'PENDING',
          customerName: draft.customerName,
          notes: `Kiosco · ${display.name}${toGo ? ' · para llevar' : ' · para comer aquí'}${draft.payment === 'QR' ? ' · paga con QR' : ' · paga en caja'}`.slice(0, 200),
          paymentMethod: draft.payment === 'QR' ? 'TRANSFER' : 'CASH',
          items: JSON.stringify(draft.lines),
          subtotal: draft.total,
          total: draft.total,
          placedAt: now,
          dirty: false,
        },
      }).catch((e: any) => {
        if (e?.code === 'P2002') return null; // otro pedido tomó el número: se usa el siguiente
        throw e;
      });
    }
    if (!created) throw new Error('No se pudo numerar el pedido del kiosco');
    AuditLogger.log({ action: 'KIOSK_ORDER_PLACED', entityType: 'ORDER', entityId: created.id, userName: display.name, details: { code: created.code, total: draft.total, lines: draft.lines.length } });
    publish('floor', 'notifications');
    return { id: created.id, code: created.code, number: kioskNumber(created.code), total: draft.total, payment: draft.payment };
  }
}
