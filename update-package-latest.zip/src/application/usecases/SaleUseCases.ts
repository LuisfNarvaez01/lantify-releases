import crypto from 'crypto';
import { ISaleRepository, IProductRepository } from '../../domain/repositories/index';
import { calculateSaleTotal, SaleStatus } from '../../domain/entities';
import { CreateSaleDTO, UpdateSaleDTO } from '../dtos';
import { prisma } from '../../infrastructure/database/prisma';
import { AuditLogger } from '../../infrastructure/services/AuditLogger';
import { BusinessSettingsUseCases } from './BusinessSettingsUseCases';
import { CouponUseCases } from './CouponUseCases';
import { computeSaleTaxes, resolveTaxProfile, NO_TAX, TaxProfile, TaxType } from '../../domain/tax';
import { normalizeLoyalty } from '../../domain/businessPage';
import { currentFeatures } from '../../shared/cloud/features';
import { stampSyncSoon } from './stampSync';

export class SaleUseCases {
  constructor(
    private saleRepository: ISaleRepository,
    private productRepository: IProductRepository,
    private businessSettings?: BusinessSettingsUseCases,
    private coupons = new CouponUseCases(),
  ) {}

  /** Impuesto de cada variante según su producto o, si no tiene, el del negocio. */
  private async taxProfilesFor(variantIds: string[]): Promise<Map<string, TaxProfile>> {
    const businessDefault = this.businessSettings ? await this.businessSettings.getDefaultTax() : NO_TAX;
    const variants = await prisma.productVariant.findMany({
      where: { id: { in: Array.from(new Set(variantIds)) } },
      select: { id: true, product: { select: { taxType: true, taxRate: true } } },
    });
    const map = new Map<string, TaxProfile>();
    for (const v of variants) map.set(v.id, resolveTaxProfile(v.product, businessDefault));
    return map;
  }

  /** Sellos y jugadas que da una compra según las reglas de Mi página (función del plan Premium) */
  private async loyaltyFor(total: number, customerId?: string | null) {
    const info = {
      eligible: false,
      stamps: 0,
      gamePlays: 0,
      minSpendPerStamp: 0,
      spendPerGamePlay: 0,
      stampsRequired: 0,
      rewardText: '',
      token: undefined as { id: string; saleId?: string; stamps: number; gamePlays: number; totalAmount: number; expiresAt: string; claimUrl: string } | undefined,
      /** A quién se le sumaron y cómo queda su tarjeta (la caja lo muestra al cobrar) */
      customer: undefined as { id: string; name: string; stampsCount: number; eventId: string; hasCard: boolean; linked: boolean } | undefined,
    };
    try {
      const features = await currentFeatures();
      if (features && !features.includes('loyalty')) return info;
      const settings = await prisma.businessSettings.findUnique({ where: { id: 'default' } });
      let page: any = {};
      try {
        page = settings?.pageSettings ? JSON.parse(settings.pageSettings) : {};
      } catch {}
      const loyalty = normalizeLoyalty(page.loyalty);
      if (!loyalty.enabled || !settings?.pageSettings) return info;
      Object.assign(info, {
        minSpendPerStamp: loyalty.minSpendPerStamp,
        spendPerGamePlay: loyalty.spendPerGamePlay,
        stampsRequired: loyalty.stampsRequired,
        rewardText: loyalty.rewardText,
      });
      if (total < loyalty.minSpendPerStamp) return info;
      info.eligible = true;
      info.stamps = Math.floor(total / loyalty.minSpendPerStamp);
      info.gamePlays = loyalty.spendPerGamePlay > 0 ? Math.floor(total / loyalty.spendPerGamePlay) : 0;

      const customer = customerId ? await prisma.customer.findUnique({ where: { id: customerId } }) : null;
      if (customer && !customer.isDefault && customer.isActive) {
        info.customer = {
          id: customer.id,
          name: customer.name,
          stampsCount: (customer.stampsCount ?? 0) + info.stamps,
          eventId: crypto.randomUUID(),
          hasCard: !!customer.cloudId,
          linked: !!settings?.cloudTenantCode,
        };
        return info;
      }
      const id = crypto.randomUUID();
      const slug = settings?.bookingSlug || 'mi-restaurante';
      info.token = {
        id,
        stamps: info.stamps,
        gamePlays: info.gamePlays,
        totalAmount: total,
        expiresAt: new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
        claimUrl: `https://lantifypos.dpdns.org/m/${slug}?claim=${id}`,
      };
    } catch (e) {
      console.warn('[Fidelidad] No se pudieron calcular los sellos:', e);
    }
    return info;
  }

  async createSale(data: CreateSaleDTO) {
    
    // ============================================
    // VALIDACIÓN DE ARQUEO ANTES DE CREAR VENTA
    // ============================================
    if (!data.cashSessionId) {
      throw new Error('Debe abrir un arqueo de caja antes de realizar ventas');
    }

    // ============================================
    // VERIFICACIÓN DE IDEMPOTENCIA (ANTI-DUPLICADOS)
    // ============================================
    if (data.idempotencyKey) {
      const existing = await prisma.sale.findFirst({
        where: { idempotencyKey: data.idempotencyKey }
      });
      if (existing) {
        console.log(`[Idempotencia] Venta existente retornada para clave ${data.idempotencyKey} (#${existing.saleNumber})`);
        return this.saleRepository.getById(existing.id);
      }
    }
    
    // El precio ya incluye el impuesto: el total no cambia, solo se calcula qué parte es impuesto
    const subtotal = data.items.reduce((sum, item) => sum + (item.quantity * item.unitPrice), 0);

    // Apply discount percentage if provided
    const discountPct = Number(data.discountPct ?? 0);
    if (!Number.isFinite(discountPct) || discountPct < 0 || discountPct > 100) {
      throw new Error('El descuento debe estar entre 0 % y 100 %');
    }
    let discountAmount = discountPct > 0 ? Math.round(subtotal * (discountPct / 100)) : (data.discount ?? 0);
    // Cupón: el servidor valida y calcula el descuento; no se suma a un descuento manual
    const coupon = data.couponCode ? await this.coupons.validate(data.couponCode, subtotal) : null;
    if (coupon) {
      discountAmount = coupon.discount;
      data = { ...data, discountPct: 0, discountReason: `Cupón ${coupon.code}`, authorizedBy: data.authorizedBy };
    }
    const total = subtotal - discountAmount;

    // ── Fidelidad: sellos por compra ──
    // Con cliente registrado los sellos van directo a su tarjeta (en cola si no hay internet);
    // sin cliente, el ticket lleva un QR para que él mismo los reclame en la página.
    const loyaltyInfo = await this.loyaltyFor(total, data.customerId);
    const loyaltyStamps = loyaltyInfo.stamps;
    const loyaltyPlays = loyaltyInfo.gamePlays;
    const creditCustomerId = loyaltyInfo.customer?.id ?? null;

    const taxProfiles = await this.taxProfilesFor(data.items.map(i => i.productVariantId));
    const lines = data.items.map(item => {
      const profile = taxProfiles.get(item.productVariantId) ?? NO_TAX;
      return { total: item.quantity * item.unitPrice, taxType: profile.taxType, taxRate: profile.taxRate };
    });
    const { lineTaxes, tax } = computeSaleTaxes(lines, discountAmount);

    // Propina voluntaria: se cobra aparte del total de la venta
    const tip = Math.max(0, Math.round(Number(data.tip) || 0));
    if (tip > total) {
      throw new Error('La propina no puede ser mayor que el total de la venta');
    }

    // Dueño de la propina: quien tomó el pedido de la mesa; en mostrador, quien cobra
    let waiterName: string | null = null;
    if (data.tableId) {
      const order = await prisma.order.findFirst({
        where: { tableId: data.tableId, status: { notIn: ['COMPLETED', 'CANCELLED'] } },
        orderBy: { createdAt: 'desc' },
        select: { userName: true },
      });
      waiterName = order?.userName || null;
    }
    const cashierName = data.cashierName ? String(data.cashierName).slice(0, 120) : null;
    waiterName = waiterName || cashierName;

    // Determine effective payment method
    // If payments array provided with multiple methods, mark as MIXED
    const payments: { method: string; amount: number }[] = data.payments ?? [];
    let paymentMethod: any = data.paymentMethod ?? 'CASH';
    if (payments.length > 1) paymentMethod = 'MIXED';

    // ============================================
    // USAR TRANSACCIÓN PARA ATOMICIDAD
    // ============================================
    const result = await prisma.$transaction(async (tx) => {
      // Crear la venta
      const now = new Date();
      const saleNumber = `SALE-${now.getFullYear()}${(now.getMonth() + 1).toString().padStart(2, '0')}${now.getDate().toString().padStart(2, '0')}-${Math.floor(Math.random() * 10000).toString().padStart(4, '0')}`;
      
      const sale = await tx.sale.create({
        data: {
          saleNumber,
          tableId: data.tableId || null,
          cashSessionId: data.cashSessionId,
          customerId: data.customerId || null,
          channel: data.channel || (data.tableId ? 'POS' : 'COUNTER'),
          customerName: data.customerName || (data.tableId ? null : 'Mostrador'),
          subtotal,
          tax,
          discount: discountAmount,
          tip,
          cashierName,
          waiterName,
          couponCode: coupon?.code ?? null,
          discountPct: coupon ? 0 : discountPct,
          discountReason: data.discountReason || null,
          authorizedBy: data.authorizedBy || null,
          idempotencyKey: data.idempotencyKey || null,
          total,
          paymentMethod,
          status: data.status || 'COMPLETED',
          notes: data.notes,
        },
      });

      // El uso del cupón se cuenta en la misma transacción que la venta
      if (coupon) await tx.coupon.update({ where: { code: coupon.code }, data: { uses: { increment: 1 } } });

      // Crear los items y descontar inventario si aplica
      for (const [index, item] of data.items.entries()) {
        await tx.saleItem.create({
          data: {
            saleId: sale.id,
            productVariantId: item.productVariantId,
            quantity: item.quantity,
            unitPrice: item.unitPrice,
            total: item.quantity * item.unitPrice,
            taxType: lines[index].taxType,
            taxRate: lines[index].taxRate,
            taxAmount: lineTaxes[index],
            notes: item.notes,
          },
        });

        // Descontar inventario si el seguimiento está activo
        try {
          const variant = await tx.productVariant.findUnique({
            where: { id: item.productVariantId },
          });

          if (variant && (variant as any).trackInventory) {
            const prevStock = variant.stock;
            const newStock = prevStock - item.quantity;

            await tx.productVariant.update({
              where: { id: item.productVariantId },
              data: { stock: newStock },
            });

            await (tx as any).stockMovement.create({
              data: {
                productVariantId: item.productVariantId,
                type: 'SALE',
                quantity: -item.quantity,
                previousStock: prevStock,
                newStock: newStock,
                reference: sale.saleNumber,
                notes: `Venta #${sale.saleNumber}`,
              },
            });
          }
        } catch (invErr) {
          console.warn(`[Inventory] No se pudo actualizar inventario para variante ${item.productVariantId}:`, invErr);
        }
      }

      // ── Registrar pagos mixtos ──
      if (payments.length > 0) {
        // Validate that sum of payments covers total
        const totalPaid = payments.reduce((s, p) => s + p.amount, 0);
        // Allow minor rounding differences
        if (totalPaid < total + tip - 1) {
          throw new Error(`Los pagos (${totalPaid}) no cubren el total de la venta (${total + tip})`);
        }

        for (const p of payments) {
          await tx.payment.create({
            data: {
              saleId: sale.id,
              amount: p.amount,
              paymentMethod: p.method,
              cashSessionId: data.cashSessionId,
            }
          });

          // Incrementar caja solo para pagos en efectivo
          if (p.method === 'CASH') {
            await tx.cashSession.update({
              where: { id: data.cashSessionId },
              data: { income: { increment: p.amount } },
            });
          }
        }
      } else {
        // Single payment method (backwards compatible)
        if (paymentMethod === 'CASH') {
          await tx.cashSession.update({
            where: { id: data.cashSessionId },
            data: { income: { increment: total + tip } },
          });
        }
      }

      // Actualizar stats del cliente si hay uno asignado
      if (data.customerId) {
        await tx.customer.update({
          where: { id: data.customerId },
          data: {
            totalSpent: { increment: total },
            visitCount: { increment: 1 },
            ...(creditCustomerId === data.customerId && loyaltyStamps > 0 ? {
              stampsCount: { increment: loyaltyStamps },
              lifetimeStamps: { increment: loyaltyStamps },
            } : {}),
          }
        }).catch(() => {}); // ignore if customer not found
      }
      // El movimiento de sellos queda en la cola hacia su tarjeta digital en la misma transacción
      if (creditCustomerId && loyaltyInfo.customer) {
        await tx.stampEvent.create({
          data: { id: loyaltyInfo.customer.eventId, customerId: creditCustomerId, stamps: loyaltyStamps, gamePlays: loyaltyPlays, saleId: sale.id, reason: 'Compra' },
        });
      }

      return sale;
    });

    // Guardar token en cola local para sincronización a la nube
    if (loyaltyInfo.customer) stampSyncSoon();
    if (loyaltyInfo.token) {
      loyaltyInfo.token.saleId = result.id;
      await prisma.stampToken.create({
        data: {
          id: loyaltyInfo.token.id,
          saleId: result.id,
          stamps: loyaltyInfo.token.stamps,
          gamePlays: loyaltyInfo.token.gamePlays,
          totalAmount: loyaltyInfo.token.totalAmount,
          expiresAt: new Date(loyaltyInfo.token.expiresAt),
          synced: false,
        },
      }).catch((e) => console.warn('[StampToken] Error al guardar en cola local:', e));
    }

    // Auditoría de venta creada
    AuditLogger.log({
      action: 'SALE_CREATED',
      entityType: 'SALE',
      entityId: result.id,
      details: {
        saleNumber: result.saleNumber,
        total: result.total,
        channel: result.channel,
        paymentMethod: result.paymentMethod,
        discountAmount,
        discountPct,
        tax,
        tip,
        discountReason: data.discountReason,
        authorizedBy: data.authorizedBy,
        loyaltyStamps,
        loyaltyPlays,
      }
    });

    const finalSale = await this.saleRepository.getById(result.id);
    if (finalSale) {
      (finalSale as any).loyaltyInfo = loyaltyInfo;
    }
    return finalSale;
  }

  /**
   * Corrige la propina de una venta (solo ADMIN). El valor de la venta no cambia.
   * Si la propina se pagó en efectivo y el turno sigue abierto, el saldo esperado
   * del cajón se ajusta por la diferencia (ese dinero entra o sale del cajón);
   * con el turno cerrado el arqueo ya se cuadró y no se toca.
   */
  async adjustTip(id: string, newTip: number, reason: string, actor: string) {
    const tip = Math.round(Number(newTip));
    const why = String(reason || '').trim().slice(0, 300);
    if (!Number.isFinite(tip) || tip < 0) throw new SaleError(400, 'TIP_INVALID', 'La propina no es válida.');
    if (!why) throw new SaleError(400, 'TIP_REASON_REQUIRED', 'Escribe el motivo de la corrección.');

    const sale = await prisma.sale.findUnique({ where: { id }, include: { payments: true, cashSession: true } });
    if (!sale) throw new SaleError(404, 'SALE_NOT_FOUND', 'Venta no encontrada.');
    if (sale.status !== 'COMPLETED') throw new SaleError(409, 'TIP_SALE_NOT_COMPLETED', 'Solo se corrige la propina de ventas completadas.');
    if (tip > sale.total) throw new SaleError(400, 'TIP_TOO_HIGH', 'La propina no puede ser mayor que el total de la venta.');
    const delta = tip - sale.tip;
    if (delta === 0) return this.saleRepository.getById(id);

    // ¿Entró al cajón? Pago único en efectivo, o la parte en efectivo de un pago mixto
    const cashPayment = sale.payments.find((p) => p.paymentMethod === 'CASH');
    const paidInCash = sale.payments.length ? !!cashPayment : sale.paymentMethod === 'CASH';
    const moveDrawer = paidInCash && sale.cashSession?.status === 'OPEN';
    if (moveDrawer && cashPayment && cashPayment.amount + delta < 0) {
      throw new SaleError(400, 'TIP_INVALID', 'La corrección deja el pago en efectivo en negativo.');
    }

    await prisma.$transaction(async (tx) => {
      await tx.sale.update({
        where: { id },
        data: {
          tip,
          tipOriginal: sale.tipOriginal ?? sale.tip,
          tipEditedBy: actor.slice(0, 120),
          tipEditedAt: new Date(),
          tipEditReason: why,
        },
      });
      if (moveDrawer) {
        if (cashPayment) await tx.payment.update({ where: { id: cashPayment.id }, data: { amount: { increment: delta } } });
        await tx.cashSession.update({ where: { id: sale.cashSessionId! }, data: { income: { increment: delta } } });
      }
    });

    AuditLogger.log({
      action: 'SALE_TIP_ADJUSTED',
      entityType: 'SALE',
      entityId: id,
      details: { saleNumber: sale.saleNumber, from: sale.tip, to: tip, reason: why, by: actor, drawerAdjusted: moveDrawer ? delta : 0 },
    });
    return this.saleRepository.getById(id);
  }

  /**
   * Cambia el cliente de una venta (cliente no registrado al cobrar, o "Cliente
   * común" por error). Los acumulados (total gastado, visitas) pasan del cliente
   * anterior al nuevo en la misma transacción; el valor de la venta no cambia.
   */
  async changeCustomer(id: string, customerId: string | null, actor: string) {
    const sale = await prisma.sale.findUnique({ where: { id }, include: { customer: true } });
    if (!sale) throw new SaleError(404, 'SALE_NOT_FOUND', 'Venta no encontrada.');
    if (sale.status === 'CANCELLED') throw new SaleError(409, 'SALE_CUSTOMER_CANCELLED', 'La venta está anulada.');
    const next = customerId ? await prisma.customer.findFirst({ where: { id: customerId, isActive: true } }) : null;
    if (customerId && !next) throw new SaleError(404, 'CUSTOMER_NOT_FOUND', 'Cliente no encontrado.');
    if ((sale.customerId || null) === (next?.id || null)) return this.saleRepository.getById(id);

    const counts = sale.status === 'COMPLETED';
    await prisma.$transaction(async (tx) => {
      await tx.sale.update({ where: { id }, data: { customerId: next?.id ?? null } });
      if (counts && sale.customerId) {
        await tx.customer.update({ where: { id: sale.customerId }, data: { totalSpent: { decrement: sale.total }, visitCount: { decrement: 1 } } }).catch(() => {});
      }
      if (counts && next) {
        await tx.customer.update({ where: { id: next.id }, data: { totalSpent: { increment: sale.total }, visitCount: { increment: 1 } } });
      }
    });

    AuditLogger.log({
      action: 'SALE_CUSTOMER_CHANGED',
      entityType: 'SALE',
      entityId: id,
      details: { saleNumber: sale.saleNumber, from: sale.customer?.name ?? null, to: next?.name ?? null, by: actor },
    });
    return this.saleRepository.getById(id);
  }

  async getSaleById(id: string) {
    return this.saleRepository.getById(id);
  }

  async getAllSales() {
    return this.saleRepository.getAll();
  }

  async getSalesByDateRange(startDate: Date, endDate: Date) {
    return this.saleRepository.getByDateRange(startDate, endDate);
  }

  async getSalesByTable(tableId: string) {
    return this.saleRepository.getByTable(tableId);
  }

  async getSalesByCashSession(cashSessionId: string) {
    return this.saleRepository.getByCashSession(cashSessionId);
  }

  async updateSale(id: string, data: UpdateSaleDTO) {
    return this.saleRepository.update(id, data);
  }

  async completeSale(id: string) {
    return this.saleRepository.updateStatus(id, 'COMPLETED');
  }

  async cancelSale(id: string) {
    const sale = await this.saleRepository.getById(id);
    if (!sale) throw new Error('Venta no encontrada');

    await prisma.$transaction(async (tx) => {
      // Obtener pagos en efectivo hechos a esta venta
      const payments = await tx.payment.findMany({
        where: { saleId: id, paymentMethod: 'CASH' }
      });
      
      const cashRefundAmount = payments.reduce((sum, p) => sum + p.amount, 0);
      
      let totalToRefund = cashRefundAmount;
      if (payments.length === 0 && sale.paymentMethod === 'CASH') {
        // La propina en efectivo también entró a la caja
        totalToRefund = sale.total + ((sale as any).tip || 0);
      }

      if (totalToRefund > 0 && sale.cashSessionId) {
        await tx.cashSession.update({
          where: { id: sale.cashSessionId },
          data: { income: { decrement: totalToRefund } },
        });
      }

      // Revertir stats del cliente
      if ((sale as any).customerId) {
        await tx.customer.update({
          where: { id: (sale as any).customerId },
          data: {
            totalSpent: { decrement: sale.total },
            visitCount: { decrement: 1 },
          }
        }).catch(() => {});
      }

      // Revertir inventario de los items de la venta
      try {
        const saleItems = await tx.saleItem.findMany({
          where: { saleId: id, isCancelled: false }
        });
        for (const it of saleItems) {
          const variant = await tx.productVariant.findUnique({
            where: { id: it.productVariantId }
          });
          if (variant && (variant as any).trackInventory) {
            const prevStock = variant.stock;
            const newStock = prevStock + it.quantity;
            await tx.productVariant.update({
              where: { id: it.productVariantId },
              data: { stock: newStock }
            });
            await (tx as any).stockMovement.create({
              data: {
                productVariantId: it.productVariantId,
                type: 'ADJUSTMENT',
                quantity: it.quantity,
                previousStock: prevStock,
                newStock: newStock,
                reference: sale.saleNumber,
                notes: `Cancelación de venta #${sale.saleNumber}`
              }
            });
          }
        }
      } catch (invErr) {
        console.warn('[Inventory] Error al revertir inventario en cancelación:', invErr);
      }

      await tx.sale.update({
        where: { id },
        data: { status: 'CANCELLED' },
      });
    });

    AuditLogger.log({
      action: 'SALE_CANCELLED',
      entityType: 'SALE',
      entityId: id,
      details: { saleId: id }
    });

    return this.saleRepository.getById(id);
  }

  async refundSale(id: string) {
    return this.saleRepository.updateStatus(id, 'REFUNDED');
  }

  async deleteSale(id: string) {
    return this.saleRepository.delete(id);
  }

  async getDailySalesSummary(date: Date = new Date()) {
    return this.saleRepository.getDailySalesSummary(date);
  }

  // ============================================
  // ANULACIÓN DE ITEMS
  // ============================================
  
  async cancelSaleItem(itemId: string, reason: string, userId: string) {
    const item = await prisma.saleItem.findUnique({ where: { id: itemId } });
    if (!item) throw new Error('Item no encontrado');
    if (item.isCancelled) throw new Error('El item ya está cancelado');
    
    await prisma.saleItem.update({
      where: { id: itemId },
      data: {
        isCancelled: true,
        cancellationReason: reason,
        cancelledAt: new Date(),
        cancelledBy: userId,
      }
    });
    
    // Revertir inventario si aplica
    try {
      const variant = await prisma.productVariant.findUnique({
        where: { id: item.productVariantId }
      });
      if (variant && (variant as any).trackInventory) {
        const prevStock = variant.stock;
        const newStock = prevStock + item.quantity;
        await prisma.productVariant.update({
          where: { id: item.productVariantId },
          data: { stock: newStock }
        });
        await (prisma as any).stockMovement.create({
          data: {
            productVariantId: item.productVariantId,
            type: 'ADJUSTMENT',
            quantity: item.quantity,
            previousStock: prevStock,
            newStock: newStock,
            reference: item.id,
            notes: `Anulación de item: ${reason}`
          }
        });
      }
    } catch (invErr) {
      console.warn('[Inventory] Error al revertir inventario en anulación de item:', invErr);
    }
    
    await this.recalculateSaleTotals(item.saleId);

    AuditLogger.log({
      action: 'ITEM_CANCELLED',
      entityType: 'SALE_ITEM',
      entityId: itemId,
      userId,
      details: {
        saleId: item.saleId,
        productVariantId: item.productVariantId,
        quantity: item.quantity,
        reason
      }
    });

    return this.saleRepository.getById(item.saleId);
  }

  private async recalculateSaleTotals(saleId: string) {
    const [sale, items] = await Promise.all([
      prisma.sale.findUnique({ where: { id: saleId }, select: { discount: true, discountPct: true } }),
      prisma.saleItem.findMany({ where: { saleId, isCancelled: false } }),
    ]);

    const subtotal = items.reduce((sum, item) => sum + item.total, 0);
    // El descuento se conserva al anular un producto (antes se perdía)
    const discount = sale && sale.discountPct > 0
      ? Math.round(subtotal * (sale.discountPct / 100))
      : Math.min(sale?.discount ?? 0, subtotal);
    const total = subtotal - discount;
    const { lineTaxes, tax } = computeSaleTaxes(
      items.map(i => ({ total: i.total, taxType: i.taxType as TaxType, taxRate: i.taxRate })),
      discount,
    );

    await prisma.$transaction([
      ...items.map((item, idx) => prisma.saleItem.update({ where: { id: item.id }, data: { taxAmount: lineTaxes[idx] } })),
      prisma.sale.update({ where: { id: saleId }, data: { subtotal, discount, tax, total } }),
    ]);
  }

  // ============================================
  // PAGOS ADICIONALES / ABONOS
  // ============================================

  async addPayment(data: {
    saleId: string;
    amount: number;
    paymentMethod: 'CASH' | 'CARD' | 'TRANSFER';
    cashSessionId: string;
    notes?: string;
  }) {
    const sale = await this.saleRepository.getById(data.saleId);
    if (!sale) throw new Error('Venta no encontrada');
    
    const result = await prisma.$transaction(async (tx) => {
      const payment = await tx.payment.create({
        data: {
          saleId: data.saleId,
          amount: data.amount,
          paymentMethod: data.paymentMethod,
          cashSessionId: data.cashSessionId,
          notes: data.notes,
        }
      });

      if (data.paymentMethod === 'CASH') {
        await tx.cashSession.update({
          where: { id: data.cashSessionId },
          data: { income: { increment: data.amount } },
        });
      }

      return payment;
    });
    
    return result;
  }

  async getSalePayments(saleId: string) {
    return prisma.payment.findMany({
      where: { saleId },
      orderBy: { createdAt: 'asc' }
    });
  }

  async getSalePaidTotal(saleId: string) {
    const payments = await prisma.payment.findMany({ where: { saleId } });
    return payments.reduce((sum, p) => sum + p.amount, 0);
  }

  // ============================================
  // HISTORIAL PAGINADO POR MES
  // ============================================

  async getAvailableMonths() {
    return this.saleRepository.getAvailableMonths();
  }

  async getSalesByMonth(
    year: number,
    month: number,
    page: number = 1,
    limit: number = 50,
    filters?: { cashSessionId?: string; status?: string }
  ) {
    return this.saleRepository.getByMonth(year, month, page, limit, filters);
  }
}
export class SaleError extends Error {
  constructor(public status: number, public code: string, message: string) {
    super(message);
    this.name = SaleError.name;
  }
}
