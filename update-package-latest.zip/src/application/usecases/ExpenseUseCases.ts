// ============================================
// APPLICATION - Gastos del negocio
// ============================================
// Los gastos se registran arqueo a arqueo: todo gasto queda en el turno de caja
// abierto. Si se pagó con dinero del cajón descuenta del saldo esperado; si se
// pagó por fuera (banco, tarjeta, Nequi) queda registrado en el arqueo sin
// mover el efectivo. Se registra a mano o con la foto de la factura: la IA la
// lee y propone proveedor, valores y categoría; con el modo automático, una
// lectura confiable queda registrada sin revisión.

import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { prisma } from '../../infrastructure/database/prisma';
import { getDataDir } from '../../shared/security/secrets';
import { SupplierUseCases } from './SupplierUseCases';

export const PAYMENT_SOURCES = ['CASH_DRAWER', 'BANK', 'CARD', 'NEQUI', 'OTHER'] as const;
export type PaymentSource = (typeof PAYMENT_SOURCES)[number];

/** Lectura mínima para registrar sola, sin que nadie la revise */
export const AUTO_REGISTER_CONFIDENCE = 0.85;
const MAX_IMAGE_BYTES = 3 * 1024 * 1024;

export class ExpenseError extends Error {
  constructor(public status: number, public code: string, message: string) {
    super(message);
    this.name = ExpenseError.name;
  }
}

export interface ExpenseInput {
  amount: number;
  motive?: string;
  description?: string | null;
  categoryId?: string | null;
  paymentSource?: string;
  supplierName?: string | null;
  supplierNit?: string | null;
  invoiceNumber?: string | null;
  invoiceDate?: string | null;
  subtotal?: number | null;
  taxAmount?: number | null;
  image?: string | null; // base64 (JPEG/PNG/WebP)
  captureMode?: 'MANUAL' | 'AI_REVIEWED' | 'AI_AUTO';
  aiConfidence?: number | null;
  /** Productos leídos de la factura: actualizan la lista de precios del proveedor */
  items?: { description: string; quantity: number | null; total: number | null }[];
}

export interface InvoiceReading {
  isInvoice: boolean;
  supplierName: string | null;
  supplierNit: string | null;
  invoiceNumber: string | null;
  invoiceDate: string | null;
  subtotal: number | null;
  tax: number | null;
  total: number | null;
  paymentMethod: 'CASH' | 'CARD' | 'TRANSFER' | null;
  category: string | null;
  items: { description: string; quantity: number | null; total: number | null }[];
  confidence: number;
}

const imagesDir = () => path.join(getDataDir(), 'expenses');

const money = (v: unknown) => {
  if (v === null || v === undefined || v === '') return null;
  const n = Math.round(Number(v));
  return Number.isFinite(n) && n >= 0 ? n : null;
};

const clean = (v: unknown, max: number) => (typeof v === 'string' && v.trim() ? v.trim().slice(0, max) : null);

export class ExpenseUseCases {
  // ── Consulta ──────────────────────────────────────────────
  async list(range: { from?: Date; to?: Date; sessionId?: string } = {}) {
    const where = {
      ...(range.from || range.to ? { createdAt: { ...(range.from ? { gte: range.from } : {}), ...(range.to ? { lte: range.to } : {}) } } : {}),
      ...(range.sessionId ? { cashSessionId: range.sessionId } : {}),
    };
    const expenses = await prisma.expense.findMany({
      where,
      include: { category: true, cashSession: { select: { sessionNumber: true } } },
      orderBy: { createdAt: 'desc' },
      take: 500,
    });
    const active = expenses.filter((e) => !e.isCancelled);
    const byCategory = new Map<string, { id: string | null; name: string; color: string | null; total: number; count: number }>();
    for (const e of active) {
      const key = e.categoryId || 'none';
      const row = byCategory.get(key) || { id: e.categoryId, name: e.category?.name || '', color: e.category?.color || null, total: 0, count: 0 };
      row.total += e.amount;
      row.count++;
      byCategory.set(key, row);
    }
    return {
      total: active.reduce((n, e) => n + e.amount, 0),
      count: active.length,
      tax: active.reduce((n, e) => n + (e.taxAmount || 0), 0),
      byCategory: [...byCategory.values()].sort((a, b) => b.total - a.total),
      bySource: PAYMENT_SOURCES.map((s) => ({ source: s, total: active.filter((e) => e.paymentSource === s).reduce((n, e) => n + e.amount, 0) })).filter((x) => x.total > 0),
      expenses: expenses.map(({ imageFile, ...e }) => ({ ...e, hasImage: !!imageFile })),
    };
  }

  // ── Registro ──────────────────────────────────────────────
  async create(input: ExpenseInput, actor?: string) {
    const amount = money(input.amount);
    if (!amount || amount <= 0) throw new ExpenseError(400, 'EXPENSE_AMOUNT_REQUIRED', 'Escribe el valor del gasto.');
    const paymentSource = (PAYMENT_SOURCES as readonly string[]).includes(input.paymentSource || '') ? (input.paymentSource as PaymentSource) : 'CASH_DRAWER';
    const supplierName = clean(input.supplierName, 120);
    const motive = clean(input.motive, 160) || supplierName;
    if (!motive) throw new ExpenseError(400, 'EXPENSE_MOTIVE_REQUIRED', 'Escribe el motivo o el proveedor del gasto.');
    if (input.categoryId) {
      const exists = await prisma.expenseCategory.findUnique({ where: { id: input.categoryId } });
      if (!exists) throw new ExpenseError(400, 'EXPENSE_CATEGORY_NOT_FOUND', 'La categoría no existe.');
    }
    const invoiceDate = input.invoiceDate && /^\d{4}-\d{2}-\d{2}/.test(input.invoiceDate) ? new Date(`${input.invoiceDate.slice(0, 10)}T12:00:00`) : null;

    // Todo gasto queda en el arqueo abierto; sin caja abierta no se registra
    const session = await prisma.cashSession.findFirst({ where: { status: 'OPEN' }, orderBy: { openedAt: 'desc' } });
    if (!session) {
      throw new ExpenseError(409, 'EXPENSE_NO_OPEN_SESSION', 'Abre la caja para registrar gastos: cada gasto queda en el arqueo del turno.');
    }

    const id = crypto.randomUUID();
    const imageFile = input.image ? this.saveImage(id, input.image) : null;
    const expense = await prisma.$transaction(async (tx) => {
      const created = await tx.expense.create({
        data: {
          id,
          amount,
          motive,
          description: clean(input.description, 500),
          categoryId: input.categoryId || null,
          paymentSource,
          cashSessionId: session.id,
          supplierName,
          supplierNit: clean(input.supplierNit, 20),
          invoiceNumber: clean(input.invoiceNumber, 40),
          invoiceDate,
          subtotal: money(input.subtotal),
          taxAmount: money(input.taxAmount),
          imageFile,
          captureMode: input.captureMode && ['MANUAL', 'AI_REVIEWED', 'AI_AUTO'].includes(input.captureMode) ? input.captureMode : 'MANUAL',
          aiConfidence: input.aiConfidence ?? null,
          createdBy: actor || null,
        },
        include: { category: true },
      });
      // Solo el dinero que salió del cajón cambia el saldo esperado
      if (paymentSource === 'CASH_DRAWER') await tx.cashSession.update({ where: { id: session.id }, data: { expenses: { increment: amount } } });
      return created;
    });
    // Lo que costó cada producto en esta factura queda en la lista del proveedor (base del agente de compras)
    if (supplierName && Array.isArray(input.items) && input.items.length) {
      await new SupplierUseCases()
        .learnFromInvoice({ name: supplierName, nit: clean(input.supplierNit, 20) }, input.items)
        .catch((err) => console.warn('[gastos] no se pudo actualizar la lista de precios:', err?.message));
    }
    const { imageFile: _file, ...rest } = expense;
    return { ...rest, hasImage: !!_file };
  }

  async cancel(id: string, reason: string) {
    const expense = await prisma.expense.findUnique({ where: { id }, include: { cashSession: true } });
    if (!expense) throw new ExpenseError(404, 'EXPENSE_NOT_FOUND', 'Gasto no encontrado.');
    if (expense.isCancelled) throw new ExpenseError(409, 'EXPENSE_ALREADY_CANCELLED', 'Este gasto ya estaba anulado.');
    if (!clean(reason, 300)) throw new ExpenseError(400, 'EXPENSE_REASON_REQUIRED', 'Escribe el motivo de la anulación.');
    await prisma.$transaction(async (tx) => {
      await tx.expense.update({ where: { id }, data: { isCancelled: true, cancellationReason: clean(reason, 300), cancelledAt: new Date() } });
      // Si salió del cajón y el turno sigue abierto, el dinero vuelve al saldo esperado
      if (expense.paymentSource === 'CASH_DRAWER' && expense.cashSession && expense.cashSession.status === 'OPEN') {
        await tx.cashSession.update({ where: { id: expense.cashSession.id }, data: { expenses: { decrement: expense.amount } } });
      }
    });
    return { id, isCancelled: true };
  }

  // ── Foto de la factura ────────────────────────────────────
  private saveImage(id: string, base64: string) {
    const data = Buffer.from(base64.replace(/^data:[^;]+;base64,/, ''), 'base64');
    if (!data.length || data.length > MAX_IMAGE_BYTES) throw new ExpenseError(413, 'EXPENSE_IMAGE_TOO_LARGE', 'La foto es demasiado grande.');
    const ext = data[0] === 0x89 ? 'png' : data.subarray(8, 12).toString() === 'WEBP' ? 'webp' : 'jpg';
    fs.mkdirSync(imagesDir(), { recursive: true });
    const name = `${id}.${ext}`;
    fs.writeFileSync(path.join(imagesDir(), name), data, { mode: 0o600 });
    return name;
  }

  async imagePath(id: string) {
    const expense = await prisma.expense.findUnique({ where: { id }, select: { imageFile: true } });
    if (!expense?.imageFile || !/^[0-9a-f-]{36}\.(jpg|png|webp)$/.test(expense.imageFile)) return null;
    const file = path.join(imagesDir(), expense.imageFile);
    return fs.existsSync(file) ? file : null;
  }

  /** Une la lectura de la IA con las categorías del negocio (por nombre) */
  async matchCategory(name: string | null) {
    if (!name) return null;
    const categories = await prisma.expenseCategory.findMany({ where: { isActive: true } });
    return categories.find((c) => c.name.toLowerCase() === name.toLowerCase())?.id || null;
  }

  async categoryNames() {
    return (await prisma.expenseCategory.findMany({ where: { isActive: true }, select: { name: true } })).map((c) => c.name);
  }

  /** ¿La lectura alcanza para registrar sin revisión? */
  canAutoRegister(r: InvoiceReading) {
    return r.isInvoice && !!r.total && r.total > 0 && r.confidence >= AUTO_REGISTER_CONFIDENCE && !!(r.supplierName || r.invoiceNumber);
  }

  static paymentSourceFor(method: InvoiceReading['paymentMethod']): PaymentSource {
    if (method === 'CARD') return 'CARD';
    if (method === 'TRANSFER') return 'BANK';
    return 'CASH_DRAWER';
  }
}
