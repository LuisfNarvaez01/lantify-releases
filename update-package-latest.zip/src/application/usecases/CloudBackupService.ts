// ============================================
// APPLICATION - Copia de seguridad en Lantify Cloud
// ============================================
// Una vez al día (y al cerrar la caja) el programa sube una copia liviana de su base:
//   1. `VACUUM INTO` saca una foto consistente de la base sin detener la caja.
//   2. A esa copia se le quitan los historiales que no hacen falta para seguir vendiendo
//      (bitácora de auditoría y conversaciones del asistente) y se compacta.
//   3. Se comprime con gzip y se sube. La nube la cifra con la clave del negocio y reemplaza
//      la copia anterior: siempre hay una sola, la más reciente.
// Las fotos de los productos y los secretos de este equipo (clave de la DIAN) no se suben.
//
// Restaurar (programa instalado): la copia queda en data/restore-pending.db y la app de
// escritorio detiene el servidor, guarda la base actual, pone la copia y vuelve a arrancar.

import { PrismaClient } from '@prisma/client';
import crypto from 'crypto';
import fs from 'fs';
import os from 'os';
import path from 'path';
import zlib from 'zlib';
import { prisma } from '../../infrastructure/database/prisma';
import { cloudConfig } from '../../shared/cloud/config';
import { allStoredLicenses, deviceName } from '../../shared/cloud/license';
import { askDesktop } from '../../shared/desktop';
import { databaseFile, isDesktop, versionFile } from '../../shared/runtime';
import { CloudAuthService } from './CloudAuthService';

const AUTO_EVERY_MS = 20 * 60 * 60 * 1000; // copia automática: si la última tiene más de 20 h
const AFTER_CLOSE_MS = 60 * 60 * 1000; // al cerrar caja: si la última tiene más de 1 h
const CHECK_EVERY_MS = 60 * 60 * 1000;
const MAX_UPLOAD_BYTES = 15 * 1024 * 1024;
const MAX_RESTORE_BYTES = 1024 * 1024 * 1024;
/** Lo que no hace falta para seguir vendiendo: se quita de la copia en la nube */
const LIGHT_TABLES = ['audit_logs', 'agent_messages'];
/** Lo que se cuenta para mostrar en Mi cuenta qué tiene la copia */
const COUNTED: Record<string, string> = { sales: 'ventas', products: 'productos', customers: 'clientes', users: 'usuarios', categories: 'categorias', cash_sessions: 'cajas' };

export const pendingRestoreFile = () => path.join(path.dirname(databaseFile()), 'restore-pending.db');
const stateFile = () => path.join(path.dirname(databaseFile()), 'cloud-backup.json');

interface State {
  lastUploadAt?: string;
  lastAttemptAt?: string;
  lastError?: string | null;
  lastSizeBytes?: number;
}

const readState = (): State => {
  try {
    return JSON.parse(fs.readFileSync(stateFile(), 'utf-8'));
  } catch {
    return {};
  }
};
const writeState = (patch: State) => {
  try {
    fs.writeFileSync(stateFile(), JSON.stringify({ ...readState(), ...patch }, null, 2));
  } catch {
    /* sin permiso de escritura: se intenta de nuevo más tarde */
  }
};

const appVersion = () => {
  try {
    return String(JSON.parse(fs.readFileSync(versionFile(), 'utf-8')).version || '');
  } catch {
    return '';
  }
};

export class CloudBackupError extends Error {
  constructor(public status: number, public code: string, message: string) {
    super(message);
  }
}

const sqliteHeader = Buffer.from('SQLite format 3\0', 'latin1');

/** La copia gzip es una base de Lantify (SQLite con la tabla de ventas y la configuración del negocio) */
export const unpackBackup = (gz: Buffer): Buffer => {
  let raw: Buffer;
  try {
    raw = zlib.gunzipSync(gz, { maxOutputLength: MAX_RESTORE_BYTES });
  } catch {
    throw new CloudBackupError(400, 'BACKUP_BAD_FILE', 'El archivo no es una copia de Lantify (debe terminar en .db.gz).');
  }
  if (raw.length < 4096 || !raw.subarray(0, 16).equals(sqliteHeader)) {
    throw new CloudBackupError(400, 'BACKUP_BAD_FILE', 'El archivo no es una copia de Lantify.');
  }
  // El esquema está en las primeras páginas de la base
  const text = raw.subarray(0, Math.min(raw.length, 4 * 1024 * 1024)).toString('latin1');
  if (!text.includes('CREATE TABLE "sales"') || !text.includes('CREATE TABLE "business_settings"')) {
    throw new CloudBackupError(400, 'BACKUP_BAD_FILE', 'El archivo no es una copia de Lantify.');
  }
  return raw;
};

let cashClosedHook: (() => void) | null = null;
/** Lo llama el cierre de caja: el servicio activo decide si toca subir una copia */
export const notifyCashClosed = () => cashClosedHook?.();

export class CloudBackupService {
  private running = false;
  private timer: NodeJS.Timeout | null = null;

  constructor(private cloud: CloudAuthService) {}

  start() {
    if (this.timer) return;
    cashClosedHook = () => this.afterCashClose();
    setTimeout(() => void this.auto(AUTO_EVERY_MS), 3 * 60 * 1000);
    this.timer = setInterval(() => void this.auto(AUTO_EVERY_MS), CHECK_EVERY_MS);
  }

  /** Tras cerrar la caja: una copia fresca si la última tiene más de una hora */
  afterCashClose() {
    void this.auto(AFTER_CLOSE_MS);
  }

  private async auto(maxAgeMs: number) {
    const last = Date.parse(readState().lastUploadAt || '');
    if (Number.isFinite(last) && Date.now() - last < maxAgeMs) return;
    try {
      await this.upload();
    } catch (e: any) {
      if (e?.code !== 'NOT_LINKED' && e?.code !== 'NO_LICENSE') console.warn(`[copia en la nube] ${e?.code || ''} ${e?.message || e}`);
    }
  }

  /** Copia liviana de la base, comprimida */
  async snapshot(): Promise<{ gz: Buffer; rawBytes: number; counts: Record<string, number> }> {
    const tmp = path.join(os.tmpdir(), `lantify-nube-${crypto.randomUUID()}.db`);
    try {
      await prisma.$executeRawUnsafe(`VACUUM INTO '${tmp.replace(/'/g, "''")}'`);
      const copy = new PrismaClient({ datasourceUrl: `file:${tmp.replace(/\\/g, '/')}` });
      const counts: Record<string, number> = {};
      try {
        for (const table of LIGHT_TABLES) await copy.$executeRawUnsafe(`DELETE FROM "${table}"`).catch(() => 0);
        for (const [table, label] of Object.entries(COUNTED)) {
          const rows = await copy.$queryRawUnsafe<{ n: bigint | number }[]>(`SELECT COUNT(*) AS n FROM "${table}"`).catch(() => [{ n: 0 }]);
          counts[label] = Number(rows[0]?.n ?? 0);
        }
        await copy.$executeRawUnsafe('VACUUM');
      } finally {
        await copy.$disconnect();
      }
      const raw = fs.readFileSync(tmp);
      return { gz: zlib.gzipSync(raw, { level: 9 }), rawBytes: raw.length, counts };
    } finally {
      for (const f of [tmp, `${tmp}-journal`]) fs.rmSync(f, { force: true });
    }
  }

  private async license(adminLocalUserId?: string) {
    if (!(await this.cloud.linkedTenant())) throw new CloudBackupError(409, 'NOT_LINKED', 'Este equipo no está vinculado a Lantify Cloud.');
    if (adminLocalUserId) {
      const own = await this.cloud.aiLicense(adminLocalUserId);
      if (own) return own;
    }
    const token = allStoredLicenses()
      .filter((l) => !adminLocalUserId || l.claims.role === 'ADMIN')
      .sort((a, b) => b.claims.exp - a.claims.exp)[0]?.token;
    if (!token) throw new CloudBackupError(409, 'NO_LICENSE', 'Inicia sesión con internet para usar la copia en la nube.');
    return token;
  }

  private async call(method: string, pathName: string, token: string, body?: Buffer, headers: Record<string, string> = {}, timeoutMs = 120_000) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      return await fetch(`${cloudConfig().apiUrl}${pathName}`, { method, body, signal: controller.signal, headers: { Authorization: `Bearer ${token}`, ...headers } });
    } catch {
      throw new CloudBackupError(503, 'OFFLINE', 'Sin conexión con Lantify Cloud.');
    } finally {
      clearTimeout(timer);
    }
  }

  private async fail(res: Response): Promise<never> {
    const body: any = await res.json().catch(() => ({}));
    const code = body?.code || `HTTP_${res.status}`;
    throw new CloudBackupError(res.status, code, code);
  }

  /** Sube la copia ahora (reemplaza la anterior en la nube) */
  async upload() {
    if (this.running) throw new CloudBackupError(409, 'BACKUP_RUNNING', 'Ya se está subiendo una copia.');
    this.running = true;
    writeState({ lastAttemptAt: new Date().toISOString() });
    try {
      const token = await this.license();
      const { gz, rawBytes, counts } = await this.snapshot();
      if (gz.length > MAX_UPLOAD_BYTES) throw new CloudBackupError(413, 'BACKUP_TOO_LARGE', 'La copia es demasiado grande para la nube.');
      const meta = encodeURIComponent(JSON.stringify({ rawBytes, counts, device: deviceName(), appVersion: appVersion() }));
      const res = await this.call('POST', '/v1/backups', token, gz, { 'Content-Type': 'application/gzip', 'X-Backup-Meta': meta });
      if (res.status !== 201) await this.fail(res);
      const { backup } = (await res.json()) as any;
      writeState({ lastUploadAt: backup?.createdAt || new Date().toISOString(), lastError: null, lastSizeBytes: gz.length });
      console.log(`☁️  Copia en la nube: ${(gz.length / 1024).toFixed(0)} KB (${Object.entries(counts).map(([k, v]) => `${v} ${k}`).join(', ')})`);
      return backup;
    } catch (e: any) {
      writeState({ lastError: e?.code || 'ERROR' });
      throw e;
    } finally {
      this.running = false;
    }
  }

  /** Lo que muestra Administración: la copia que hay en la nube y el último intento de este equipo */
  async status(localUserId?: string) {
    const state = readState();
    const local = { lastUploadAt: state.lastUploadAt ?? null, lastAttemptAt: state.lastAttemptAt ?? null, lastError: state.lastError ?? null, running: this.running, canRestore: isDesktop() };
    try {
      const token = await this.license(localUserId);
      const res = await this.call('GET', '/v1/backups/latest/meta', token, undefined, {}, 12_000);
      if (res.status !== 200) await this.fail(res);
      return { linked: true, ...local, cloud: ((await res.json()) as any).backup ?? null };
    } catch (e: any) {
      return { linked: e?.code !== 'NOT_LINKED', ...local, cloud: null, cloudError: e?.code || 'ERROR' };
    }
  }

  /** Deja la copia lista y le pide a la app de escritorio que la ponga en lugar de la base actual */
  private async stage(raw: Buffer) {
    if (!isDesktop()) throw new CloudBackupError(409, 'RESTORE_DESKTOP_ONLY', 'Restaurar solo está disponible en el programa instalado.');
    fs.writeFileSync(pendingRestoreFile(), raw);
    const accepted = await askDesktop<boolean>('restore:apply', null, 5000);
    if (!accepted) {
      fs.rmSync(pendingRestoreFile(), { force: true });
      throw new CloudBackupError(503, 'RESTORE_FAILED', 'Lantify no pudo empezar la restauración.');
    }
    return { restarting: true };
  }

  async restoreFromCloud(adminLocalUserId: string) {
    const token = await this.license(adminLocalUserId);
    const res = await this.call('GET', '/v1/backups/latest', token);
    if (res.status !== 200) await this.fail(res);
    const gz = Buffer.from(await res.arrayBuffer());
    const expected = res.headers.get('X-Backup-Sha256');
    if (expected && crypto.createHash('sha256').update(gz).digest('hex') !== expected) {
      throw new CloudBackupError(502, 'BACKUP_CORRUPT', 'La copia llegó incompleta. Intenta de nuevo.');
    }
    return this.stage(unpackBackup(gz));
  }

  async restoreFromFile(gz: Buffer) {
    return this.stage(unpackBackup(gz));
  }
}
