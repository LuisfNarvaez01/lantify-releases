// ============================================
// APPLICATION USE CASES - Product Use Cases
// ============================================

import { IProductRepository } from '../../domain/repositories/index';
import { normalizeTaxProfile } from '../../domain/tax';
import { isImageRef } from '../../domain/media';
import {
  CreateCategoryDTO,
  UpdateCategoryDTO,
  CreateProductDTO,
  UpdateProductDTO,
  CreateProductVariantDTO,
  UpdateProductVariantDTO,
} from '../dtos';

/**
 * taxType null = el producto usa el impuesto por defecto del negocio.
 * Una combinación inválida (p. ej. IVA sin tarifa) se rechaza.
 */
const withValidTax = <T extends { taxType?: string | null; taxRate?: number | null }>(data: T): T => {
  if (data.taxType === undefined) {
    const { taxRate: _ignored, ...rest } = data as any;
    return rest;
  }
  if (data.taxType === null || data.taxType === '') return { ...data, taxType: null, taxRate: null };
  const profile = normalizeTaxProfile(data.taxType, data.taxRate);
  if (!profile) throw new Error('La tarifa del impuesto no es válida');
  return { ...data, taxType: profile.taxType, taxRate: profile.taxRate };
};

/** La foto es opcional: una subida al equipo (/api/media/…) o una dirección https */
const withValidImage = <T extends { imageUrl?: string | null }>(data: T): T => {
  if (data.imageUrl === undefined) return data;
  if (data.imageUrl === null || data.imageUrl === '') return { ...data, imageUrl: null };
  if (!isImageRef(data.imageUrl)) throw new Error('La foto del producto no es válida');
  return data;
};

export class ProductUseCases {
  constructor(private productRepository: IProductRepository) {}

  // Category Use Cases
  async createCategory(data: CreateCategoryDTO) {
    return this.productRepository.createCategory(data);
  }

  async getCategoryById(id: string) {
    return this.productRepository.getCategoryById(id);
  }

  async getAllCategories() {
    return this.productRepository.getAllCategories();
  }

  async updateCategory(id: string, data: UpdateCategoryDTO) {
    return this.productRepository.updateCategory(id, data);
  }

  async deleteCategory(id: string) {
    return this.productRepository.deleteCategory(id);
  }

  // Product Use Cases
  async createProduct(data: CreateProductDTO) {
    return this.productRepository.create(withValidImage(withValidTax(data)));
  }

  async getProductById(id: string) {
    return this.productRepository.getById(id);
  }

  async getAllProducts() {
    return this.productRepository.getAll();
  }

  async getProductsByCategory(categoryId: string) {
    return this.productRepository.getByCategory(categoryId);
  }

  async updateProduct(id: string, data: UpdateProductDTO) {
    return this.productRepository.update(id, withValidImage(withValidTax(data)) as any);
  }

  async deleteProduct(id: string) {
    return this.productRepository.delete(id);
  }

  // ProductVariant Use Cases
  async createVariant(data: CreateProductVariantDTO) {
    // Verificar SKU único
    const existingVariant = await this.productRepository.getVariantBySku(data.sku);
    if (existingVariant) {
      throw new Error(`SKU "${data.sku}" ya existe`);
    }
    return this.productRepository.createVariant(data);
  }

  async getVariantById(id: string) {
    return this.productRepository.getVariantById(id);
  }

  async getVariantsByProduct(productId: string) {
    return this.productRepository.getVariantsByProduct(productId);
  }

  async updateVariant(id: string, data: UpdateProductVariantDTO) {
    // Verificar SKU único si se está actualizando
    if (data.sku) {
      const existingVariant = await this.productRepository.getVariantBySku(data.sku);
      if (existingVariant && existingVariant.id !== id) {
        throw new Error(`SKU "${data.sku}" ya existe`);
      }
    }
    return this.productRepository.updateVariant(id, data);
  }

  async deleteVariant(id: string) {
    return this.productRepository.deleteVariant(id);
  }

  async updateStock(variantId: string, quantity: number) {
    return this.productRepository.updateStock(variantId, quantity);
  }
}