// ============================================
// APPLICATION - Pantallas (Lantify 3.0 · bloque 2)
// ============================================
// Cocina (KDS), entregas para clientes y salón para meseros. Las pantallas se
// conectan con un código de 6 dígitos y quedan con un token propio que solo
// sirve para leer su pantalla y marcar listo. Nunca ven precios ni clientes.

import crypto from 'crypto';
import { prisma } from '../../../infrastructure/database/prisma';
import { AuditLogger } from '../../../infrastructure/services/AuditLogger';
import { loadFeatures } from '../../../shared/featureStore';
import { normalizeNames } from '../../../domain/v3/features';
import { buildPickup, buildTickets, DISPLAY_TYPES, orderLabel, pairingCode, type DisplayType, type KitchenLineInput } from '../../../domain/v3/kitchen';
import { FloorUseCases, FloorError, type Actor } from './FloorUseCases';

const ACTIVE = ['ACTIVE', 'SENT', 'IN_PREP', 'READY'];
const CODE_MINUTES = 10;
/** Horas hacia atrás que mira la cocina */
export const KITCHEN_WINDOW_HOURS = 6;
/** Minutos que un pedido de mostrador ya cobrado sigue en cocina */
const COUNTER_PAID_MINUTES = 90;
const sha = (v: string) => crypto.createHash('sha256').update(v).digest('hex');

const variantName = (product: string, variant: string | null) =>
  variant && variant !== 'Única' && variant.toLowerCase() !== 'default' && variant.toLowerCase() !== 'regular' ? `${product} · ${variant}` : product;

const publicDisplay = (d: { id: string; name: string; type: string; station: string | null; tokenHash: string | null; codeExpiresAt: Date | null; lastSeenAt: Date | null; createdAt: Date }) => ({
  id: d.id,
  name: d.name,
  type: d.type as DisplayType,
  station: d.station,
  connected: !!d.tokenHash,
  pairing: !!d.codeExpiresAt && d.codeExpiresAt > new Date(),
  lastSeenAt: d.lastSeenAt,
  createdAt: d.createdAt,
});

export class KitchenUseCases {
  constructor(private floor = new FloorUseCases()) {}

  // ── Administración de pantallas ──

  async list() {
    return (await prisma.display.findMany({ orderBy: { createdAt: 'asc' } })).map(publicDisplay);
  }

  async create(input: { name?: unknown; type?: unknown; station?: unknown }) {
    const name = typeof input.name === 'string' ? input.name.trim().slice(0, 40) : '';
    const type = DISPLAY_TYPES.includes(input.type as DisplayType) ? (input.type as DisplayType) : null;
    if (!name || !type) throw new FloorError('Escribe un nombre y elige el tipo de pantalla.', 'DISPLAY_INVALID');
    const station = type === 'KITCHEN' && typeof input.station === 'string' && input.station.trim() ? input.station.trim().slice(0, 40) : null;
    const display = await prisma.display.create({ data: { name, type, station } });
    return this.newCode(display.id);
  }

  /** Código nuevo para conectar (o reconectar) la pantalla; desconecta la anterior */
  async newCode(id: string) {
    const code = pairingCode(() => crypto.randomInt(1_000_000) / 1_000_000);
    const expires = new Date(Date.now() + CODE_MINUTES * 60_000);
    const d = await prisma.display.update({ where: { id }, data: { codeHash: sha(code), codeExpiresAt: expires, tokenHash: null } }).catch(() => null);
    if (!d) throw new FloorError('Pantalla no encontrada', 'DISPLAY_NOT_FOUND', 404);
    return { display: publicDisplay(d), code, expiresAt: expires };
  }

  async disconnect(id: string) {
    const d = await prisma.display.update({ where: { id }, data: { tokenHash: null, codeHash: null, codeExpiresAt: null } }).catch(() => null);
    if (!d) throw new FloorError('Pantalla no encontrada', 'DISPLAY_NOT_FOUND', 404);
    return publicDisplay(d);
  }

  async remove(id: string) {
    await prisma.display.delete({ where: { id } }).catch(() => null);
    return { deleted: true };
  }

  // ── La pantalla ──

  /** El TV escribe el código: recibe su token (se muestra una sola vez) */
  async pair(code: unknown) {
    const clean = typeof code === 'string' ? code.replace(/\D/g, '') : '';
    if (clean.length !== 6) throw new FloorError('El código tiene 6 números.', 'DISPLAY_CODE_INVALID');
    const d = await prisma.display.findFirst({ where: { codeHash: sha(clean), codeExpiresAt: { gt: new Date() } } });
    if (!d) throw new FloorError('El código no es válido o ya venció. Pide uno nuevo en Salón y mesas → Pantallas.', 'DISPLAY_CODE_INVALID', 404);
    const token = crypto.randomBytes(32).toString('hex');
    const updated = await prisma.display.update({ where: { id: d.id }, data: { tokenHash: sha(token), codeHash: null, codeExpiresAt: null, lastSeenAt: new Date() } });
    AuditLogger.log({ action: 'DISPLAY_PAIRED', entityType: 'DISPLAY', entityId: d.id, details: { name: d.name, type: d.type } });
    return { token, display: publicDisplay(updated) };
  }

  /** La pantalla que presenta este token, o null */
  async byToken(token: string | undefined) {
    if (!token || token.length < 32) return null;
    const d = await prisma.display.findUnique({ where: { tokenHash: sha(token) } });
    if (!d) return null;
    if (!d.lastSeenAt || Date.now() - d.lastSeenAt.getTime() > 60_000) {
      await prisma.display.update({ where: { id: d.id }, data: { lastSeenAt: new Date() } }).catch(() => undefined);
    }
    return d;
  }

  /**
   * Líneas que le tocan a cocina. Solo lo enviado en las últimas horas (lo de ayer o
   * de antes de conectar la pantalla no se muestra) y nunca mesas ya cobradas: un
   * pedido de mesa cobrado ya se entregó. Los de mostrador se cobran antes de salir
   * de cocina, por eso siguen apareciendo un rato después de cobrarse.
   */
  private async lines(since: Date, now: Date): Promise<KitchenLineInput[]> {
    const paidCounter = new Date(now.getTime() - COUNTER_PAID_MINUTES * 60_000);
    const orders = await prisma.order.findMany({
      where: {
        createdAt: { gte: new Date(since.getTime() - 12 * 3600_000) },
        OR: [
          { status: { in: ACTIVE } },
          { status: 'COMPLETED', tableId: null, updatedAt: { gte: paidCounter } },
        ],
        items: { some: { isCancelled: false, sentAt: { gte: since } } },
      },
      select: {
        id: true, orderNumber: true, channel: true, userName: true, table: { select: { number: true } },
        items: {
          where: { isCancelled: false, sentAt: { gte: since } },
          select: {
            id: true, status: true, quantity: true, notes: true, removed: true, roundNumber: true, sentAt: true, readyAt: true,
            productVariant: { select: { name: true, product: { select: { name: true, printStation: true, category: { select: { printStation: true } } } } } },
          },
        },
      },
    });
    return orders.flatMap((o) => o.items.map((i) => ({
      id: i.id,
      orderId: o.id,
      orderNumber: o.orderNumber,
      channel: o.channel,
      tableNumber: o.table?.number ?? null,
      waiterName: o.userName,
      roundNumber: i.roundNumber,
      sentAt: i.sentAt,
      readyAt: i.readyAt,
      status: i.status,
      quantity: i.quantity,
      name: variantName(i.productVariant.product.name, i.productVariant.name),
      notes: i.notes,
      removed: normalizeNames(safeJson(i.removed)),
      station: i.productVariant.product.printStation || i.productVariant.product.category?.printStation || null,
    })));
  }

  /** Lo que muestra cada tipo de pantalla */
  async feed(display: { type: string; station: string | null; name: string }, now = new Date()) {
    const since = new Date(now.getTime() - 18 * 3600_000);
    const kitchenSince = new Date(now.getTime() - KITCHEN_WINDOW_HOURS * 3600_000);
    const base = { now: now.toISOString(), display: { name: display.name, type: display.type, station: display.station } };
    if (display.type === 'KITCHEN') {
      const lines = await this.lines(kitchenSince, now);
      const tickets = buildTickets(lines, display.station, now);
      // Lo último que salió, para "Deshacer"
      const recent = lines
        .filter((l) => l.status === 'READY' && l.readyAt && now.getTime() - l.readyAt.getTime() < 15 * 60_000)
        .sort((a, b) => b.readyAt!.getTime() - a.readyAt!.getTime());
      const last = recent[0] ? recent.filter((l) => l.orderId === recent[0].orderId && l.roundNumber === recent[0].roundNumber && Math.abs(l.readyAt!.getTime() - recent[0].readyAt!.getTime()) < 5000) : [];
      return { ...base, tickets, lastReady: last.length ? { label: orderLabel(last[0]), itemIds: last.map((l) => l.id) } : null };
    }
    if (display.type === 'PICKUP') {
      const orders = await prisma.order.findMany({
        // Los de mostrador suelen cobrarse antes de salir de cocina: también los ya cobrados
        where: { tableId: null, status: { in: [...ACTIVE, 'COMPLETED'] }, createdAt: { gte: since } },
        select: { id: true, orderNumber: true, channel: true, pickedUpAt: true, items: { where: { isCancelled: false }, select: { status: true, sentAt: true, readyAt: true } } },
      });
      return { ...base, ...buildPickup(orders.map((o) => ({ ...o, lines: o.items })), now) };
    }
    const [floor, tables] = await Promise.all([
      this.floor.state(now),
      prisma.table.findMany({ select: { id: true, number: true, zone: true, status: true }, orderBy: { number: 'asc' } }),
    ]);
    return {
      ...base,
      tables,
      alerts: floor.alerts,
      pickups: floor.pickups.map((p) => ({ tableId: p.tableId, tableNumber: p.tableNumber, waiterName: p.waiterName, count: p.count, readyAt: p.readyAt })),
      dirty: floor.dirty,
      bills: floor.tables.filter((t) => t.billRequestedAt).map((t) => ({ tableId: t.tableId, billRequestedAt: t.billRequestedAt })),
    };
  }

  /** Cocina: estas líneas ya salieron */
  async ready(itemIds: unknown, by: string) {
    const ids = (Array.isArray(itemIds) ? itemIds : []).filter((x): x is string => typeof x === 'string').slice(0, 100);
    if (!ids.length) return { ready: 0 };
    const now = new Date();
    const { count } = await prisma.orderItem.updateMany({ where: { id: { in: ids }, status: { in: ['SENT', 'IN_PREP'] }, isCancelled: false }, data: { status: 'READY', readyAt: now } });
    await this.syncOrders(ids);
    if (count) AuditLogger.log({ action: 'KITCHEN_READY', entityType: 'ORDER_ITEM', entityId: ids[0], userName: by, details: { items: count } });
    return { ready: count };
  }

  /** Cocina: deshacer un "listo" (se marcó por error) */
  async undo(itemIds: unknown) {
    const ids = (Array.isArray(itemIds) ? itemIds : []).filter((x): x is string => typeof x === 'string').slice(0, 100);
    if (!ids.length) return { undone: 0 };
    const { count } = await prisma.orderItem.updateMany({ where: { id: { in: ids }, status: 'READY' }, data: { status: 'SENT', readyAt: null } });
    await this.syncOrders(ids);
    return { undone: count };
  }

  /** El pedido queda READY cuando toda su comanda salió, y vuelve a SENT si se deshace */
  private async syncOrders(itemIds: string[]) {
    const orders = await prisma.order.findMany({
      where: { items: { some: { id: { in: itemIds } } }, status: { in: ACTIVE } },
      select: { id: true, status: true, items: { where: { isCancelled: false, sentAt: { not: null } }, select: { status: true } } },
    });
    for (const o of orders) {
      const allReady = o.items.length > 0 && o.items.every((i) => i.status === 'READY' || i.status === 'SERVED');
      const next = allReady ? 'READY' : o.status === 'READY' ? 'SENT' : o.status;
      if (next !== o.status) await prisma.order.update({ where: { id: o.id }, data: { status: next } });
    }
  }

  /** Caja: el cliente recogió su pedido (sale de la pantalla de entregas) */
  async pickedUp(orderId: string, actor: Actor) {
    const o = await prisma.order.update({ where: { id: orderId }, data: { pickedUpAt: new Date() } }).catch(() => null);
    if (!o) throw new FloorError('Pedido no encontrado', 'ORDER_NOT_FOUND', 404);
    AuditLogger.log({ action: 'ORDER_PICKED_UP', entityType: 'ORDER', entityId: orderId, userId: actor.userId, userName: actor.name, userRole: actor.role });
    return { pickedUp: true };
  }

  async enabled() {
    return (await loadFeatures()).flags.kitchen_display;
  }
}

function safeJson(v: string | null) {
  try {
    return v ? JSON.parse(v) : [];
  } catch {
    return [];
  }
}
