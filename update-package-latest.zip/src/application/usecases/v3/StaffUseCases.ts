// ============================================
// APPLICATION - Personal, turnos, pagos y reparto de propinas (Lantify 3.0)
// ============================================
// Control interno de cada empleado. No es nómina legal.

import { prisma } from '../../../infrastructure/database/prisma';
import { AuditLogger } from '../../../infrastructure/services/AuditLogger';
import { loadFeatures } from '../../../shared/featureStore';
import { STAFF_GROUPS, type StaffGroup, type TipRules } from '../../../domain/v3/features';
import { computePayroll, type PayType } from '../../../domain/v3/payroll';
import { splitTips, validateShares, type SplitMember } from '../../../domain/v3/tipSplit';
import type { Actor } from './FloorUseCases';

export class StaffError extends Error {
  constructor(message: string, public code: string, public statusCode = 400) { super(message); }
}

const PAY_TYPES: PayType[] = ['SHIFT', 'HOUR', 'FIXED'];
const ROLE_POSITION: Record<string, StaffGroup> = { WAITER: 'WAITER', CASHIER: 'CASHIER', ADMIN: 'OTHER' };

const asGroup = (v: unknown): StaffGroup => ((STAFF_GROUPS as readonly string[]).includes(String(v)) ? (v as StaffGroup) : 'OTHER');
const asDate = (v: unknown, label: string) => {
  const d = new Date(String(v));
  if (Number.isNaN(d.getTime())) throw new StaffError(`Fecha inválida (${label})`, 'BAD_DATE');
  return d;
};
const money = (v: unknown) => {
  const n = Math.round(Number(v));
  if (!Number.isFinite(n) || n < 0 || n > 1_000_000_000) throw new StaffError('Valor inválido', 'BAD_AMOUNT');
  return n;
};

export interface EmployeeInput { name?: string; position?: string; phone?: string | null; startDate?: string | null; payType?: string; payAmount?: number; workDays?: number[] | null; userId?: string | null; isActive?: boolean }

export class StaffUseCases {
  /** Cada usuario de Lantify es también un empleado (se crean los que falten) */
  async syncUsers() {
    const [users, linked] = await Promise.all([
      prisma.user.findMany({ select: { id: true, name: true, role: true, isActive: true } }),
      prisma.employee.findMany({ where: { userId: { not: null } }, select: { userId: true } }),
    ]);
    const have = new Set(linked.map((e) => e.userId));
    for (const u of users) {
      if (have.has(u.id) || !u.isActive) continue;
      await prisma.employee.create({ data: { name: u.name, position: ROLE_POSITION[u.role] || 'OTHER', userId: u.id } });
    }
  }

  async list() {
    await this.syncUsers();
    const [employees, users, open] = await Promise.all([
      prisma.employee.findMany({ orderBy: [{ isActive: 'desc' }, { name: 'asc' }] }),
      prisma.user.findMany({ select: { id: true, username: true, role: true, isActive: true } }),
      prisma.shift.findMany({ where: { endAt: null }, select: { id: true, employeeId: true, startAt: true } }),
    ]);
    const byUser = new Map(users.map((u) => [u.id, u]));
    const openBy = new Map(open.map((s) => [s.employeeId, s]));
    return employees.map((e) => ({ ...e, user: e.userId ? byUser.get(e.userId) || null : null, openShift: openBy.get(e.id) || null }));
  }

  private clean(input: EmployeeInput, creating: boolean) {
    const data: Record<string, any> = {};
    if (input.name !== undefined || creating) {
      const name = String(input.name || '').trim().slice(0, 120);
      if (!name) throw new StaffError('Escribe el nombre del empleado', 'NAME_REQUIRED');
      data.name = name;
    }
    if (input.position !== undefined) data.position = asGroup(input.position);
    if (input.phone !== undefined) data.phone = input.phone ? String(input.phone).replace(/[^0-9+ ]/g, '').slice(0, 20) : null;
    if (input.startDate !== undefined) data.startDate = input.startDate ? asDate(input.startDate, 'ingreso') : null;
    if (input.payType !== undefined) {
      if (!PAY_TYPES.includes(input.payType as PayType)) throw new StaffError('Forma de pago inválida', 'BAD_PAY_TYPE');
      data.payType = input.payType;
    }
    if (input.payAmount !== undefined) data.payAmount = money(input.payAmount);
    if (input.workDays !== undefined) data.workDays = Array.isArray(input.workDays) ? [...new Set(input.workDays.map(Number).filter((n) => Number.isInteger(n) && n >= 0 && n <= 6))].sort().join(',') || null : null;
    if (input.isActive !== undefined) data.isActive = !!input.isActive;
    return data;
  }

  async create(input: EmployeeInput, actor: Actor) {
    const employee = await prisma.employee.create({ data: this.clean(input, true) as any });
    AuditLogger.log({ action: 'EMPLOYEE_CREATED', entityType: 'EMPLOYEE', entityId: employee.id, userId: actor.userId, userName: actor.name, userRole: actor.role, details: { name: employee.name, position: employee.position } });
    return employee;
  }

  async update(id: string, input: EmployeeInput, actor: Actor) {
    const before = await prisma.employee.findUnique({ where: { id } });
    if (!before) throw new StaffError('Empleado no encontrado', 'EMPLOYEE_NOT_FOUND', 404);
    const employee = await prisma.employee.update({ where: { id }, data: this.clean(input, false) });
    AuditLogger.log({ action: 'EMPLOYEE_UPDATED', entityType: 'EMPLOYEE', entityId: id, userId: actor.userId, userName: actor.name, userRole: actor.role, details: { payType: employee.payType, payAmount: employee.payAmount, isActive: employee.isActive } });
    return employee;
  }

  // ── Turnos ──────────────────────────────────────────────

  async employeeOfUser(userId?: string) {
    if (!userId) return null;
    await this.syncUsers();
    return prisma.employee.findUnique({ where: { userId } });
  }

  /** Estado del turno de quien tiene la sesión abierta (botón de marcar) */
  async myShift(userId?: string) {
    const employee = await this.employeeOfUser(userId);
    if (!employee) return { employeeId: null, open: null };
    const open = await prisma.shift.findFirst({ where: { employeeId: employee.id, endAt: null }, orderBy: { startAt: 'desc' } });
    return { employeeId: employee.id, open };
  }

  async clockIn(employeeId: string, actor: Actor) {
    const employee = await prisma.employee.findUnique({ where: { id: employeeId } });
    if (!employee || !employee.isActive) throw new StaffError('Empleado no encontrado', 'EMPLOYEE_NOT_FOUND', 404);
    const open = await prisma.shift.findFirst({ where: { employeeId, endAt: null } });
    if (open) return open;
    return prisma.shift.create({ data: { employeeId, startAt: new Date(), markedBy: actor.name || null } });
  }

  async clockOut(employeeId: string) {
    const open = await prisma.shift.findFirst({ where: { employeeId, endAt: null }, orderBy: { startAt: 'desc' } });
    if (!open) throw new StaffError('No hay una entrada marcada', 'NO_OPEN_SHIFT', 409);
    return prisma.shift.update({ where: { id: open.id }, data: { endAt: new Date() } });
  }

  /** Al cerrar la caja: las entradas sin salida se cierran y quedan por revisar */
  async closeOpenShifts() {
    const now = new Date();
    const res = await prisma.shift.updateMany({ where: { endAt: null }, data: { endAt: now, needsReview: true } });
    return res.count;
  }

  async shifts(from: Date, to: Date, employeeId?: string) {
    return prisma.shift.findMany({
      where: { startAt: { gte: from, lte: to }, ...(employeeId ? { employeeId } : {}) },
      include: { employee: { select: { name: true, position: true } } },
      orderBy: { startAt: 'desc' },
      take: 500,
    });
  }

  /** El ADMIN corrige o crea una marca */
  async saveShift(id: string | null, input: { employeeId?: string; startAt?: string; endAt?: string | null }, actor: Actor) {
    const startAt = input.startAt ? asDate(input.startAt, 'entrada') : undefined;
    const endAt = input.endAt ? asDate(input.endAt, 'salida') : input.endAt === null ? null : undefined;
    if (id) {
      const before = await prisma.shift.findUnique({ where: { id } });
      if (!before) throw new StaffError('Turno no encontrado', 'SHIFT_NOT_FOUND', 404);
      const start = startAt || before.startAt;
      const end = endAt === undefined ? before.endAt : endAt;
      if (end && end <= start) throw new StaffError('La salida debe ser posterior a la entrada', 'BAD_RANGE');
      const shift = await prisma.shift.update({ where: { id }, data: { startAt: start, endAt: end, needsReview: false, editedBy: actor.name || null } });
      AuditLogger.log({ action: 'SHIFT_EDITED', entityType: 'SHIFT', entityId: id, userId: actor.userId, userName: actor.name, userRole: actor.role, details: { before: { startAt: before.startAt, endAt: before.endAt }, after: { startAt: start, endAt: end } } });
      return shift;
    }
    if (!input.employeeId || !startAt) throw new StaffError('Faltan el empleado o la entrada', 'VALIDATION_ERROR');
    if (endAt && endAt <= startAt) throw new StaffError('La salida debe ser posterior a la entrada', 'BAD_RANGE');
    const shift = await prisma.shift.create({ data: { employeeId: input.employeeId, startAt, endAt: endAt || null, markedBy: actor.name || null, editedBy: actor.name || null } });
    AuditLogger.log({ action: 'SHIFT_CREATED', entityType: 'SHIFT', entityId: shift.id, userId: actor.userId, userName: actor.name, userRole: actor.role, details: { employeeId: input.employeeId, startAt, endAt } });
    return shift;
  }

  async deleteShift(id: string, actor: Actor) {
    const shift = await prisma.shift.delete({ where: { id } }).catch(() => null);
    if (!shift) throw new StaffError('Turno no encontrado', 'SHIFT_NOT_FOUND', 404);
    AuditLogger.log({ action: 'SHIFT_DELETED', entityType: 'SHIFT', entityId: id, userId: actor.userId, userName: actor.name, userRole: actor.role, details: { employeeId: shift.employeeId, startAt: shift.startAt, endAt: shift.endAt } });
  }

  // ── Adelantos y descuentos ──────────────────────────────

  async addMovement(input: { employeeId: string; type: string; amount: number; reason?: string; date?: string }, actor: Actor) {
    if (input.type !== 'ADVANCE' && input.type !== 'DEDUCTION') throw new StaffError('Tipo inválido', 'BAD_TYPE');
    const amount = money(input.amount);
    if (amount <= 0) throw new StaffError('El valor debe ser mayor que cero', 'BAD_AMOUNT');
    const employee = await prisma.employee.findUnique({ where: { id: input.employeeId } });
    if (!employee) throw new StaffError('Empleado no encontrado', 'EMPLOYEE_NOT_FOUND', 404);
    const movement = await prisma.staffMovement.create({
      data: { employeeId: employee.id, type: input.type, amount, reason: input.reason ? String(input.reason).slice(0, 200) : null, date: input.date ? asDate(input.date, 'movimiento') : new Date(), createdBy: actor.name || null },
    });
    AuditLogger.log({ action: 'STAFF_MOVEMENT_ADDED', entityType: 'EMPLOYEE', entityId: employee.id, userId: actor.userId, userName: actor.name, userRole: actor.role, details: { type: input.type, amount, reason: movement.reason } });
    return movement;
  }

  async movements(from: Date, to: Date, employeeId?: string) {
    return prisma.staffMovement.findMany({ where: { date: { gte: from, lte: to }, ...(employeeId ? { employeeId } : {}) }, include: { employee: { select: { name: true } } }, orderBy: { date: 'desc' }, take: 500 });
  }

  async deleteMovement(id: string, actor: Actor) {
    const m = await prisma.staffMovement.findUnique({ where: { id } });
    if (!m) throw new StaffError('Movimiento no encontrado', 'MOVEMENT_NOT_FOUND', 404);
    if (m.payrollId) throw new StaffError('Ya entró en una liquidación', 'MOVEMENT_SETTLED', 409);
    await prisma.staffMovement.delete({ where: { id } });
    AuditLogger.log({ action: 'STAFF_MOVEMENT_DELETED', entityType: 'EMPLOYEE', entityId: m.employeeId, userId: actor.userId, userName: actor.name, userRole: actor.role, details: { type: m.type, amount: m.amount } });
  }

  // ── Liquidación ─────────────────────────────────────────

  /** Lo que se le debe a cada empleado en el periodo (sin guardar nada) */
  async payrollPreview(from: Date, to: Date) {
    const employees = await prisma.employee.findMany({ where: { isActive: true }, orderBy: { name: 'asc' } });
    const [shifts, movements, shares] = await Promise.all([
      prisma.shift.findMany({ where: { startAt: { gte: from, lte: to } } }),
      prisma.staffMovement.findMany({ where: { date: { gte: from, lte: to }, payrollId: null } }),
      prisma.tipShare.findMany({ where: { payrollId: null, tipSplit: { periodTo: { gte: from, lte: to } } } }),
    ]);
    return employees.map((e) => {
      const mine = movements.filter((m) => m.employeeId === e.id);
      const result = computePayroll({
        payType: e.payType as PayType,
        payAmount: e.payAmount,
        shifts: shifts.filter((s) => s.employeeId === e.id),
        tips: shares.filter((s) => s.employeeId === e.id).reduce((a, s) => a + s.amount, 0),
        advances: mine.filter((m) => m.type === 'ADVANCE').reduce((a, m) => a + m.amount, 0),
        deductions: mine.filter((m) => m.type === 'DEDUCTION').reduce((a, m) => a + m.amount, 0),
      });
      return { employeeId: e.id, name: e.name, position: e.position, payType: e.payType, payAmount: e.payAmount, ...result };
    });
  }

  /** Guarda la liquidación de un empleado y marca lo que incluyó */
  async createPayroll(employeeId: string, from: Date, to: Date, actor: Actor) {
    const row = (await this.payrollPreview(from, to)).find((r) => r.employeeId === employeeId);
    if (!row) throw new StaffError('Empleado no encontrado', 'EMPLOYEE_NOT_FOUND', 404);
    const overlap = await prisma.payroll.findFirst({ where: { employeeId, periodFrom: { lte: to }, periodTo: { gte: from } } });
    if (overlap) throw new StaffError('Ya hay una liquidación que cubre parte de ese periodo', 'PAYROLL_OVERLAP', 409);
    const payroll = await prisma.$transaction(async (tx) => {
      const created = await tx.payroll.create({
        data: {
          employeeId, periodFrom: from, periodTo: to, base: row.base, tips: row.tips, advances: row.advances, deductions: row.deductions, total: row.total,
          detail: JSON.stringify({ days: row.days, hours: row.hours, pendingShifts: row.pendingShifts, payType: row.payType, payAmount: row.payAmount }), createdBy: actor.name || null,
        },
      });
      await tx.staffMovement.updateMany({ where: { employeeId, date: { gte: from, lte: to }, payrollId: null }, data: { payrollId: created.id } });
      await tx.tipShare.updateMany({ where: { employeeId, payrollId: null, tipSplit: { periodTo: { gte: from, lte: to } } }, data: { payrollId: created.id } });
      return created;
    });
    AuditLogger.log({ action: 'PAYROLL_CREATED', entityType: 'PAYROLL', entityId: payroll.id, userId: actor.userId, userName: actor.name, userRole: actor.role, details: { employeeId, from, to, total: payroll.total } });
    return payroll;
  }

  async payrolls(employeeId?: string) {
    return prisma.payroll.findMany({ where: employeeId ? { employeeId } : {}, include: { employee: { select: { name: true, position: true } } }, orderBy: { periodTo: 'desc' }, take: 200 });
  }

  /** Marca como pagada; opcionalmente la registra como gasto (por fuera del cajón) */
  async payPayroll(id: string, asExpense: boolean, actor: Actor) {
    const payroll = await prisma.payroll.findUnique({ where: { id }, include: { employee: true } });
    if (!payroll) throw new StaffError('Liquidación no encontrada', 'PAYROLL_NOT_FOUND', 404);
    if (payroll.status === 'PAID') return payroll;
    let expenseId: string | null = null;
    if (asExpense && payroll.total > 0) {
      const expense = await prisma.expense.create({
        data: { amount: payroll.total, motive: `Pago a ${payroll.employee.name}`, description: 'Liquidación de personal', paymentSource: 'OTHER', createdBy: actor.name || null },
      });
      expenseId = expense.id;
    }
    const paid = await prisma.payroll.update({ where: { id }, data: { status: 'PAID', paidAt: new Date(), expenseId } });
    AuditLogger.log({ action: 'PAYROLL_PAID', entityType: 'PAYROLL', entityId: id, userId: actor.userId, userName: actor.name, userRole: actor.role, details: { total: payroll.total, asExpense } });
    return paid;
  }

  async deletePayroll(id: string, actor: Actor) {
    const payroll = await prisma.payroll.findUnique({ where: { id } });
    if (!payroll) throw new StaffError('Liquidación no encontrada', 'PAYROLL_NOT_FOUND', 404);
    if (payroll.status === 'PAID') throw new StaffError('Una liquidación pagada no se elimina', 'PAYROLL_PAID', 409);
    await prisma.$transaction([
      prisma.staffMovement.updateMany({ where: { payrollId: id }, data: { payrollId: null } }),
      prisma.tipShare.updateMany({ where: { payrollId: id }, data: { payrollId: null } }),
      prisma.payroll.delete({ where: { id } }),
    ]);
    AuditLogger.log({ action: 'PAYROLL_DELETED', entityType: 'PAYROLL', entityId: id, userId: actor.userId, userName: actor.name, userRole: actor.role, details: { employeeId: payroll.employeeId, total: payroll.total } });
  }

  // ── Reparto de propinas ─────────────────────────────────

  /** Propuesta de reparto para un periodo (no guarda nada) */
  async tipPreview(from: Date, to: Date, cashSessionId?: string | null) {
    const features = await loadFeatures();
    const rules: TipRules = features.tips;
    await this.syncUsers();
    const where = cashSessionId ? { cashSessionId } : { createdAt: { gte: from, lte: to } };
    const [sales, employees, shifts, already] = await Promise.all([
      prisma.sale.findMany({ where: { ...where, status: 'COMPLETED', tip: { gt: 0 } }, select: { tip: true, waiterId: true } }),
      prisma.employee.findMany({ where: { isActive: true } }),
      prisma.shift.findMany({ where: { startAt: { lte: to }, OR: [{ endAt: null }, { endAt: { gte: from } }] }, select: { employeeId: true } }),
      prisma.tipSplit.findFirst({ where: cashSessionId ? { cashSessionId } : { periodType: { not: 'SESSION' }, periodFrom: { lte: to }, periodTo: { gte: from } } }),
    ]);
    const total = sales.reduce((a, s) => a + s.tip, 0);
    const byUser = new Map<string, number>();
    for (const s of sales) if (s.waiterId) byUser.set(s.waiterId, (byUser.get(s.waiterId) || 0) + s.tip);
    const worked = new Set(shifts.map((s) => s.employeeId));
    // Recibe quien marcó turno en el periodo; un mesero con propinas propias también, aunque no haya marcado
    const members: (SplitMember & { name: string })[] = employees
      .map((e) => ({ employeeId: e.id, name: e.name, group: asGroup(e.position), contributed: e.userId ? byUser.get(e.userId) || 0 : 0 }))
      .filter((m) => worked.has(m.employeeId) || (m.group === 'WAITER' && (m.contributed || 0) > 0));
    const result = splitTips({ total, rules, members });
    const names = new Map(employees.map((e) => [e.id, e.name]));
    return {
      total: result.total,
      rules,
      shares: result.shares.map((s) => ({ ...s, name: names.get(s.employeeId) || '' })),
      unassigned: result.unassigned,
      employees: employees.map((e) => ({ id: e.id, name: e.name, group: asGroup(e.position) })),
      alreadyConfirmed: !!already,
    };
  }

  /** Confirma el reparto (posiblemente ajustado a mano): queda fijo y entra a la liquidación */
  async confirmTips(input: { from: Date; to: Date; periodType: string; cashSessionId?: string | null; shares: { employeeId: string; amount: number }[] }, actor: Actor) {
    const preview = await this.tipPreview(input.from, input.to, input.cashSessionId);
    if (preview.alreadyConfirmed) throw new StaffError('Ese periodo ya tiene un reparto confirmado', 'TIPS_ALREADY_SPLIT', 409);
    if (preview.total <= 0) throw new StaffError('No hay propinas en ese periodo', 'NO_TIPS', 409);
    const shares = (input.shares || []).map((s) => ({ employeeId: String(s.employeeId), amount: Math.round(Number(s.amount)) })).filter((s) => s.amount > 0 || s.amount < 0);
    const check = validateShares(preview.total, shares);
    if (check === 'NEGATIVE') throw new StaffError('Hay valores negativos', 'BAD_AMOUNT');
    if (check === 'MISMATCH') throw new StaffError('El reparto debe sumar el total de propinas, sin dejar nada sin asignar', 'TIPS_MISMATCH');
    const groups = new Map(preview.employees.map((e) => [e.id, e.group]));
    if (shares.some((s) => !groups.has(s.employeeId))) throw new StaffError('Empleado no encontrado', 'EMPLOYEE_NOT_FOUND', 404);
    const periodType = ['WEEK', 'SESSION', 'MONTH'].includes(input.periodType) ? input.periodType : preview.rules.period;
    const split = await prisma.tipSplit.create({
      data: {
        periodType, periodFrom: input.from, periodTo: input.to, cashSessionId: input.cashSessionId || null, total: preview.total, rules: JSON.stringify(preview.rules), confirmedBy: actor.name || null,
        shares: { create: shares.map((s) => ({ employeeId: s.employeeId, group: groups.get(s.employeeId) as string, amount: s.amount })) },
      },
      include: { shares: true },
    });
    AuditLogger.log({ action: 'TIPS_SPLIT_CONFIRMED', entityType: 'TIP_SPLIT', entityId: split.id, userId: actor.userId, userName: actor.name, userRole: actor.role, details: { total: preview.total, periodType, from: input.from, to: input.to, shares } });
    return split;
  }

  async tipSplits() {
    return prisma.tipSplit.findMany({ include: { shares: { include: { employee: { select: { name: true } } } } }, orderBy: { periodTo: 'desc' }, take: 60 });
  }

  async markTipsPaid(id: string, actor: Actor) {
    const split = await prisma.tipSplit.update({ where: { id }, data: { status: 'PAID', paidAt: new Date() } }).catch(() => null);
    if (!split) throw new StaffError('Reparto no encontrado', 'TIP_SPLIT_NOT_FOUND', 404);
    AuditLogger.log({ action: 'TIPS_SPLIT_PAID', entityType: 'TIP_SPLIT', entityId: id, userId: actor.userId, userName: actor.name, userRole: actor.role, details: { total: split.total } });
    return split;
  }

  /** Deshacer un reparto que aún no se pagó ni entró a una liquidación */
  async deleteTipSplit(id: string, actor: Actor) {
    const split = await prisma.tipSplit.findUnique({ where: { id }, include: { shares: true } });
    if (!split) throw new StaffError('Reparto no encontrado', 'TIP_SPLIT_NOT_FOUND', 404);
    if (split.status === 'PAID' || split.shares.some((s) => s.payrollId)) throw new StaffError('Ya se pagó o entró a una liquidación', 'TIP_SPLIT_LOCKED', 409);
    await prisma.tipSplit.delete({ where: { id } });
    AuditLogger.log({ action: 'TIPS_SPLIT_DELETED', entityType: 'TIP_SPLIT', entityId: id, userId: actor.userId, userName: actor.name, userRole: actor.role, details: { total: split.total } });
  }
}
