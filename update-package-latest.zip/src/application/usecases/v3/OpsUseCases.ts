// ============================================
// APPLICATION - Lista de compras, corrección de pago e ingredientes (Lantify 3.0)
// ============================================

import { prisma } from '../../../infrastructure/database/prisma';
import { AuditLogger } from '../../../infrastructure/services/AuditLogger';
import { normalizeNames } from '../../../domain/v3/features';
import { buildShoppingList, shoppingText } from '../../../domain/v3/shoppingList';
import { cashDelta, currentParts, summaryMethod, validateFix, type FixError, type PaymentPart } from '../../../domain/v3/paymentFix';
import type { Actor } from './FloorUseCases';

export class OpsError extends Error {
  constructor(message: string, public code: string, public statusCode = 400) { super(message); }
}

const FIX_MESSAGES: Record<FixError, string> = {
  NOT_COMPLETED: 'Solo se corrige el pago de una venta cobrada.',
  SESSION_CLOSED: 'El turno de caja de esta venta ya se cerró: el arqueo no se modifica.',
  INVOICE_SENT: 'La venta ya tiene factura electrónica transmitida; el medio de pago quedó reportado.',
  BAD_PARTS: 'Revisa los medios de pago y sus valores.',
  TOTAL_MISMATCH: 'Los pagos deben sumar exactamente lo cobrado.',
  NO_CHANGE: 'Los pagos son iguales a los que ya tenía la venta.',
  REASON_REQUIRED: 'Escribe el motivo de la corrección.',
};

export class OpsUseCases {
  // ── Lista de compras ────────────────────────────────────

  async shoppingList(lang: 'es' | 'en' = 'es') {
    const [variants, suppliers, business] = await Promise.all([
      prisma.productVariant.findMany({ where: { trackInventory: true, isActive: true, product: { isActive: true } }, include: { product: { select: { name: true } } } }),
      prisma.supplier.findMany({ where: { isActive: true }, select: { id: true, name: true, phone: true } }),
      prisma.businessSettings.findUnique({ where: { id: 'default' }, select: { businessName: true } }),
    ]);
    const groups = buildShoppingList(
      variants.map((v) => ({
        variantId: v.id,
        name: v.name && !/^(normal|única|unica|default)$/i.test(v.name) ? `${v.product.name} ${v.name}` : v.product.name,
        stock: v.stock, minStock: v.minStock, reorderQty: v.reorderQty, purchaseUnit: v.purchaseUnit, supplierId: v.preferredSupplierId,
      })),
      suppliers,
    );
    const name = business?.businessName || 'Lantify POS';
    return { businessName: name, groups: groups.map((g) => ({ ...g, text: shoppingText(g, name, lang) })) };
  }

  async setReorder(variantId: string, input: { minStock?: number | null; reorderQty?: number | null; purchaseUnit?: string | null; preferredSupplierId?: string | null }) {
    const variant = await prisma.productVariant.findUnique({ where: { id: variantId } });
    if (!variant) throw new OpsError('Producto no encontrado', 'VARIANT_NOT_FOUND', 404);
    const qty = (v: unknown, label: string) => {
      if (v === null || v === undefined || v === '') return null;
      const n = Math.round(Number(v));
      if (!Number.isFinite(n) || n < 0 || n > 100_000) throw new OpsError(`${label} inválido`, 'VALIDATION_ERROR');
      return n;
    };
    const data: Record<string, any> = {};
    if (input.minStock !== undefined) data.minStock = qty(input.minStock, 'Stock mínimo');
    if (input.reorderQty !== undefined) data.reorderQty = qty(input.reorderQty, 'Cantidad a pedir');
    if (input.purchaseUnit !== undefined) data.purchaseUnit = input.purchaseUnit ? String(input.purchaseUnit).trim().slice(0, 20) : null;
    if (input.preferredSupplierId !== undefined) {
      if (input.preferredSupplierId) {
        const supplier = await prisma.supplier.findUnique({ where: { id: input.preferredSupplierId } });
        if (!supplier) throw new OpsError('Proveedor no encontrado', 'SUPPLIER_NOT_FOUND', 404);
      }
      data.preferredSupplierId = input.preferredSupplierId || null;
    }
    return prisma.productVariant.update({ where: { id: variantId }, data });
  }

  logShoppingList(actor: Actor, detail: Record<string, any>) {
    AuditLogger.log({ action: 'SHOPPING_LIST_SENT', entityType: 'INVENTORY', userId: actor.userId, userName: actor.name, userRole: actor.role, details: detail });
  }

  // ── Ingredientes que se pueden quitar ───────────────────

  async setIngredients(productId: string, raw: unknown) {
    const list = normalizeNames(raw);
    const product = await prisma.product.update({ where: { id: productId }, data: { ingredients: list.length ? JSON.stringify(list) : null } }).catch(() => null);
    if (!product) throw new OpsError('Producto no encontrado', 'PRODUCT_NOT_FOUND', 404);
    return { id: product.id, ingredients: list };
  }

  // ── Corregir el medio de pago ───────────────────────────

  async correctPayments(saleId: string, parts: PaymentPart[], reason: string, actor: Actor) {
    const sale = await prisma.sale.findUnique({ where: { id: saleId }, include: { payments: true, dianInvoice: { select: { status: true } } } });
    if (!sale) throw new OpsError('Venta no encontrada', 'SALE_NOT_FOUND', 404);
    const sessionIds = [...new Set([sale.cashSessionId, ...sale.payments.map((p) => p.cashSessionId)].filter(Boolean) as string[])];
    const sessions = sessionIds.length ? await prisma.cashSession.findMany({ where: { id: { in: sessionIds } }, select: { id: true, status: true } }) : [];
    const current = currentParts(sale.payments, sale);
    const next = (parts || []).map((p) => ({ method: p.method, amount: Math.round(Number(p.amount)) }));
    const error = validateFix({
      saleStatus: sale.status,
      due: current.reduce((a, p) => a + p.amount, 0),
      sessionsOpen: sessions.length > 0 && sessions.every((s) => s.status === 'OPEN'),
      invoiceSent: !!sale.dianInvoice && ['TRANSMITTING', 'ACCEPTED', 'CONTINGENCY'].includes(sale.dianInvoice.status),
      current,
    }, next, reason);
    if (error) throw new OpsError(FIX_MESSAGES[error], error, error === 'SESSION_CLOSED' || error === 'INVOICE_SENT' ? 409 : 400);

    // El efectivo esperado se recalcula por turno, a partir de los pagos
    const targetSession = sale.cashSessionId || sessionIds[0];
    const oldCashBySession = new Map<string, number>();
    if (sale.payments.length) {
      for (const p of sale.payments) if (p.paymentMethod === 'CASH' && p.cashSessionId) oldCashBySession.set(p.cashSessionId, (oldCashBySession.get(p.cashSessionId) || 0) + p.amount);
    } else if (sale.paymentMethod === 'CASH') {
      oldCashBySession.set(targetSession, current[0].amount);
    }
    const method = summaryMethod(next);
    await prisma.$transaction(async (tx) => {
      for (const [sessionId, amount] of oldCashBySession) await tx.cashSession.update({ where: { id: sessionId }, data: { income: { decrement: amount } } });
      await tx.payment.deleteMany({ where: { saleId } });
      for (const p of next) await tx.payment.create({ data: { saleId, amount: p.amount, paymentMethod: p.method, cashSessionId: targetSession, notes: 'Corrección de medio de pago' } });
      const cash = next.filter((p) => p.method === 'CASH').reduce((a, p) => a + p.amount, 0);
      if (cash > 0) await tx.cashSession.update({ where: { id: targetSession }, data: { income: { increment: cash } } });
      await tx.sale.update({ where: { id: saleId }, data: { paymentMethod: method } });
    });
    AuditLogger.log({
      action: 'SALE_PAYMENT_CORRECTED', entityType: 'SALE', entityId: saleId, userId: actor.userId, userName: actor.name, userRole: actor.role,
      details: { saleNumber: sale.saleNumber, reason: reason.trim(), before: current, after: next, cashDelta: cashDelta(current, next) },
    });
    return prisma.sale.findUnique({ where: { id: saleId }, include: { payments: true } });
  }
}
