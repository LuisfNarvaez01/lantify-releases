import { loadFeatures } from '../../../shared/featureStore';
// ============================================
// APPLICATION - De la foto de la factura al inventario y los gastos (Lantify 3.0)
// ============================================
// 1. prepare(): con la lectura de la IA busca el proveedor (NIT, si no por nombre),
//    empareja cada línea (alias del proveedor → ingrediente o producto parecido),
//    convierte a la unidad base y compara el costo con el anterior. No guarda nada.
// 2. commit(): lo que el usuario revisó y confirmó se guarda en una sola transacción:
//    gasto (pagada) o cuenta por pagar (a crédito); por cada línea el alias, la
//    entrada al kardex, existencias, último costo y costo promedio; y el costo de
//    las recetas en cascada con alertas de margen.

import { Prisma } from '@prisma/client';
import { prisma } from '../../../infrastructure/database/prisma';
import { AuditLogger } from '../../../infrastructure/services/AuditLogger';
import { ExpenseUseCases, ExpenseError } from '../ExpenseUseCases';
import { IngredientUseCases, type MarginAlert } from './IngredientUseCases';
import { aliasKey, best, cleanNit, docTypeOf, similarity, unitInText, type DocType } from '../../../domain/v3/purchases';
import { BASE_UNITS, conversionFactor, costChangePct, round4, type BaseUnit } from '../../../domain/v3/recipes';
import { FloorError, type Actor } from './FloorUseCases';

type Tx = Prisma.TransactionClient;

export interface ReadingLike {
  supplierName?: string | null; supplierLegalName?: string | null; supplierNit?: string | null; supplierPhone?: string | null; supplierAddress?: string | null; supplierCategory?: string | null;
  docType?: string | null; category?: string | null;
  items?: { description: string; quantity: number | null; total: number | null; unit?: string | null; unitCost?: number | null }[];
}

const num = (v: unknown) => { const n = Number(v); return Number.isFinite(n) ? n : null; };
const text = (v: unknown, max: number) => (typeof v === 'string' && v.trim() ? v.trim().replace(/\s+/g, ' ').slice(0, max) : null);

export class PurchaseUseCases {
  constructor(private expenses = new ExpenseUseCases(), private ingredients = new IngredientUseCases()) {}

  // ── 2. Pre-conciliación (sin guardar) ──

  async prepare(reading: ReadingLike) {
    const docType: DocType = docTypeOf(reading);
    const suppliers = await prisma.supplier.findMany({ where: { isActive: true }, select: { id: true, name: true, nit: true, phone: true } });
    const nit = cleanNit(reading.supplierNit);
    let supplier = nit ? suppliers.find((s) => s.nit && cleanNit(s.nit) === nit) || null : null;
    let supplierScore = supplier ? 1 : 0;
    if (!supplier && reading.supplierName) {
      const b = best(reading.supplierName, suppliers, (s) => s.name, 0.7);
      if (b) { supplier = b.item; supplierScore = b.score; }
    }
    const suggested = {
      name: text(reading.supplierName, 120) || text(reading.supplierLegalName, 120) || '',
      legalName: text(reading.supplierLegalName, 120), nit: reading.supplierNit || null,
      phone: text(reading.supplierPhone, 30), address: text(reading.supplierAddress, 160), category: text(reading.supplierCategory, 40),
    };

    if (docType === 'OPERATIONAL_EXPENSE') {
      return { docType, supplier: { status: supplier ? 'FOUND' : 'NEW', match: supplier, score: supplierScore, suggested }, lines: [] };
    }

    const [ingredients, variants, aliases] = await Promise.all([
      prisma.ingredient.findMany({ where: { isActive: true }, select: { id: true, name: true, unit: true, lastCost: true, avgCost: true } }),
      prisma.productVariant.findMany({ where: { isActive: true, product: { isActive: true } }, select: { id: true, name: true, cost: true, product: { select: { name: true } } } }),
      supplier ? prisma.supplierItemAlias.findMany({ where: { supplierId: supplier.id } }) : Promise.resolve([]),
    ]);
    const variantName = (v: (typeof variants)[number]) => (v.name && v.name !== 'Única' ? `${v.product.name} ${v.name}` : v.product.name);

    const lines = (reading.items || []).map((it) => {
      const inText = unitInText(it.description);
      const quantity = num(it.quantity) ?? inText?.quantity ?? 1;
      const unit = (it.unit || inText?.unit || '').toLowerCase() || null;
      const total = num(it.total) ?? (num(it.unitCost) !== null ? num(it.unitCost)! * quantity : null);
      const key = aliasKey(it.description);
      const alias = aliases.find((a) => a.text === key);
      let target: { kind: 'ingredient' | 'variant'; id: string; name: string; unit: BaseUnit | 'und'; lastCost: number | null } | null = null;
      let via: 'alias' | 'similar' | 'none' = 'none';
      let confidence = 0;
      if (alias?.ingredientId) {
        const ing = ingredients.find((i) => i.id === alias.ingredientId);
        if (ing) { target = { kind: 'ingredient', id: ing.id, name: ing.name, unit: ing.unit as BaseUnit, lastCost: ing.lastCost ?? ing.avgCost ?? null }; via = 'alias'; confidence = 1; }
      } else if (alias?.productVariantId) {
        const v = variants.find((x) => x.id === alias.productVariantId);
        if (v) { target = { kind: 'variant', id: v.id, name: variantName(v), unit: 'und', lastCost: v.cost ?? null }; via = 'alias'; confidence = 1; }
      }
      if (!target) {
        const bi = best(it.description, ingredients, (i) => i.name);
        const bv = best(it.description, variants, variantName);
        const pick = bi && (!bv || bi.score >= bv.score) ? { kind: 'ingredient' as const, ...bi } : bv ? { kind: 'variant' as const, ...bv } : null;
        if (pick) {
          via = 'similar'; confidence = Math.round(pick.score * 100) / 100;
          target = pick.kind === 'ingredient'
            ? { kind: 'ingredient', id: (pick.item as any).id, name: (pick.item as any).name, unit: (pick.item as any).unit, lastCost: (pick.item as any).lastCost ?? (pick.item as any).avgCost ?? null }
            : { kind: 'variant', id: (pick.item as any).id, name: variantName(pick.item as any), unit: 'und', lastCost: (pick.item as any).cost ?? null };
        }
      }
      const factor = alias?.factor ?? (target ? (target.kind === 'variant' ? (unit && conversionFactor(unit, 'und')) ?? 1 : conversionFactor(unit, target.unit as BaseUnit)) : null);
      const baseQty = factor ? round4(quantity * factor) : null;
      const unitCostBase = baseQty && total ? round4(total / baseQty) : null;
      return {
        text: it.description, key, quantity, unit, total,
        target, via, confidence,
        factor, baseQty, unitCostBase,
        lastCost: target?.lastCost ?? null,
        changePct: unitCostBase !== null ? costChangePct(target?.lastCost, unitCostBase) : null,
        // Si no hay nada parecido, se propone crear el ingrediente con la unidad que se deduzca
        suggestNew: !target ? { name: it.description.replace(/\d+([.,]\d+)?\s*(kg|g|gr|lb|l|lt|ml|und|unidades)\b/gi, '').trim().slice(0, 80) || it.description.slice(0, 80), unit: (conversionFactor(unit, 'g') ? 'g' : conversionFactor(unit, 'ml') ? 'ml' : 'und') as BaseUnit } : null,
      };
    });
    return { docType, supplier: { status: supplier ? 'FOUND' : 'NEW', match: supplier, score: supplierScore, suggested }, lines };
  }

  // ── 4. Confirmar (una transacción) ──

  async commit(body: any, actor: Actor): Promise<{ expenseId?: string; payableId?: string; alerts: MarginAlert[] }> {
    const docType: DocType = body?.docType === 'OPERATIONAL_EXPENSE' ? 'OPERATIONAL_EXPENSE' : 'SUPPLY_PURCHASE';
    const amount = num(body?.total);
    if (!amount || amount <= 0) throw new FloorError('Escribe el total de la factura.', 'PURCHASE_TOTAL');
    const supplier = body?.supplierId ? await prisma.supplier.findUnique({ where: { id: String(body.supplierId) } }) : null;
    const supplierName = supplier?.name || text(body?.supplierName, 120);
    if (!supplierName) throw new FloorError('Elige o crea el proveedor.', 'PURCHASE_SUPPLIER');
    const credit = body?.payment?.mode === 'CREDIT';
    const reference = text(body?.invoiceNumber, 40) || `FAC-${Date.now().toString(36).toUpperCase()}`;

    // Líneas de inventario ya validadas por el usuario
    type Line = { key: string; kind: 'ingredient' | 'variant' | 'new'; id?: string; newName?: string; newUnit?: BaseUnit; purchaseUnit: string | null; factor: number; baseQty: number; total: number };
    const lines: Line[] = docType === 'SUPPLY_PURCHASE'
      ? (Array.isArray(body?.lines) ? body.lines : []).filter((l: any) => !l?.skip).map((l: any) => {
        const factor = num(l?.factor) ?? 1;
        const quantity = num(l?.quantity) ?? 0;
        return {
          key: aliasKey(l?.text || ''),
          kind: l?.target?.kind === 'variant' ? 'variant' : l?.target?.kind === 'ingredient' ? 'ingredient' : 'new',
          id: typeof l?.target?.id === 'string' ? l.target.id : undefined,
          newName: text(l?.create?.name, 80) || undefined,
          newUnit: BASE_UNITS.includes(l?.create?.unit) ? l.create.unit : 'g',
          purchaseUnit: text(l?.unit, 12),
          factor: factor > 0 ? factor : 1,
          baseQty: round4(quantity * (factor > 0 ? factor : 1)),
          total: num(l?.total) ?? 0,
        } as Line;
      }).filter((l: Line) => l.baseQty > 0 && (l.kind !== 'new' || !!l.newName))
      : [];

    const { minMarginPct: minMargin } = await loadFeatures();
    const inventory = async (tx: Tx) => {
      const purchases: { ingredientId: string; quantity: number; unitCost: number }[] = [];
      for (const l of lines) {
        let ingredientId = l.kind === 'ingredient' ? l.id : undefined;
        if (l.kind === 'new') ingredientId = (await tx.ingredient.create({ data: { name: l.newName!, unit: l.newUnit!, preferredSupplierId: supplier?.id ?? null } })).id;
        const unitCost = l.total > 0 ? round4(l.total / l.baseQty) : 0;
        if (supplier && l.key) {
          await tx.supplierItemAlias.upsert({
            where: { supplierId_text: { supplierId: supplier.id, text: l.key } },
            update: { ingredientId: ingredientId ?? null, productVariantId: l.kind === 'variant' ? l.id! : null, purchaseUnit: l.purchaseUnit, factor: l.factor, lastUnitCost: unitCost || null },
            create: { supplierId: supplier.id, text: l.key, ingredientId: ingredientId ?? null, productVariantId: l.kind === 'variant' ? l.id! : null, purchaseUnit: l.purchaseUnit, factor: l.factor, lastUnitCost: unitCost || null },
          });
        }
        if (ingredientId) purchases.push({ ingredientId, quantity: l.baseQty, unitCost });
        else if (l.kind === 'variant' && l.id) {
          // Producto de reventa: entra a su inventario y su costo pasa a ser el de esta compra (el precio no cambia)
          const v = await tx.productVariant.findUnique({ where: { id: l.id } });
          if (v) {
            const qty = Math.round(l.baseQty);
            await tx.productVariant.update({ where: { id: v.id }, data: { stock: v.stock + qty, ...(unitCost ? { cost: Math.round(unitCost) } : {}) } });
            await tx.stockMovement.create({ data: { productVariantId: v.id, type: 'MANUAL_ADD', quantity: qty, previousStock: v.stock, newStock: v.stock + qty, reference, notes: `Compra ${reference}` } });
          }
        }
      }
      return this.ingredients.purchase(tx, purchases, reference, actor.name || null, minMargin);
    };

    const invoiceDate = typeof body?.invoiceDate === 'string' ? body.invoiceDate : null;
    if (credit) {
      const dueDate = typeof body?.payment?.dueDate === 'string' && !Number.isNaN(Date.parse(body.payment.dueDate)) ? new Date(`${body.payment.dueDate.slice(0, 10)}T12:00:00`) : null;
      const imageFile = typeof body?.image === 'string' && body.image ? this.expenses.saveImage(`ap-${Date.now()}`, body.image) : null;
      const result = await prisma.$transaction(async (tx) => {
        const payable = await tx.accountPayable.create({
          data: { supplierId: supplier?.id ?? null, supplierName, invoiceNumber: text(body?.invoiceNumber, 40), invoiceDate: invoiceDate ? new Date(`${invoiceDate.slice(0, 10)}T12:00:00`) : null, amount: Math.round(amount), dueDate, notes: text(body?.notes, 300), imageFile, createdBy: actor.name || null },
        });
        const alerts = await inventory(tx);
        return { payableId: payable.id, alerts };
      });
      AuditLogger.log({ action: 'PURCHASE_ON_CREDIT', entityType: 'ACCOUNT_PAYABLE', entityId: result.payableId, userId: actor.userId, userName: actor.name, userRole: actor.role, details: { supplierName, amount, lines: lines.length } });
      return result;
    }

    let alerts: MarginAlert[] = [];
    const expense = await this.expenses.create({
      amount: Math.round(amount), motive: supplierName, description: text(body?.notes, 500),
      categoryId: typeof body?.categoryId === 'string' && body.categoryId ? body.categoryId : null,
      paymentSource: typeof body?.payment?.source === 'string' ? body.payment.source : 'CASH_DRAWER',
      supplierName, supplierNit: supplier?.nit ?? text(body?.supplierNit, 20), invoiceNumber: text(body?.invoiceNumber, 40), invoiceDate,
      subtotal: num(body?.subtotal), taxAmount: num(body?.tax), image: typeof body?.image === 'string' ? body.image : null,
      captureMode: body?.fromAi ? 'AI_REVIEWED' : 'MANUAL', aiConfidence: num(body?.aiConfidence),
    }, actor.name, async (tx) => { alerts = await inventory(tx); });
    AuditLogger.log({ action: 'PURCHASE_REGISTERED', entityType: 'EXPENSE', entityId: expense.id, userId: actor.userId, userName: actor.name, userRole: actor.role, details: { supplierName, amount, lines: lines.length, docType } });
    return { expenseId: expense.id, alerts };
  }

  // ── Cuentas por pagar ──

  async payables(status: 'PENDING' | 'PAID' | 'ALL' = 'PENDING') {
    const rows = await prisma.accountPayable.findMany({ where: status === 'ALL' ? {} : { status }, orderBy: [{ status: 'asc' }, { dueDate: 'asc' }], take: 200 });
    const now = Date.now();
    return rows.map((r) => ({ ...r, imageFile: undefined, hasImage: !!r.imageFile, overdue: r.status === 'PENDING' && !!r.dueDate && r.dueDate.getTime() < now, daysLeft: r.dueDate ? Math.ceil((r.dueDate.getTime() - now) / 86_400_000) : null }));
  }

  /** Registrar el pago: se vuelve un gasto (del cajón o del banco) y la cuenta queda pagada */
  async pay(id: string, body: { source?: string; categoryId?: string | null }, actor: Actor) {
    const ap = await prisma.accountPayable.findUnique({ where: { id } });
    if (!ap) throw new FloorError('Cuenta no encontrada', 'PAYABLE_NOT_FOUND', 404);
    if (ap.status === 'PAID') throw new FloorError('Esta cuenta ya está pagada.', 'PAYABLE_PAID', 409);
    const expense = await this.expenses.create({
      amount: ap.amount, motive: ap.supplierName, description: `Pago de factura ${ap.invoiceNumber || ''} a crédito`.trim(),
      categoryId: body.categoryId || null, paymentSource: body.source || 'BANK', supplierName: ap.supplierName, invoiceNumber: ap.invoiceNumber,
      invoiceDate: ap.invoiceDate ? ap.invoiceDate.toISOString().slice(0, 10) : null,
    }, actor.name, async (tx) => {
      await tx.accountPayable.update({ where: { id }, data: { status: 'PAID', paidAt: new Date(), paidExpenseId: undefined } });
    });
    await prisma.accountPayable.update({ where: { id }, data: { paidExpenseId: expense.id } });
    return { paid: true, expenseId: expense.id };
  }

  /** Crear el proveedor con los datos de la factura */
  async createSupplier(body: any) {
    const name = text(body?.name, 120);
    if (!name) throw new FloorError('Escribe el nombre del proveedor.', 'SUPPLIER_NAME');
    const nit = text(body?.nit, 20);
    if (nit) {
      const all = await prisma.supplier.findMany({ where: { nit: { not: null } }, select: { id: true, nit: true, name: true } });
      const dup = all.find((s) => cleanNit(s.nit) === cleanNit(nit));
      if (dup) return dup;
    }
    const notes = [text(body?.legalName, 120) && `Razón social: ${text(body.legalName, 120)}`, text(body?.address, 160) && `Dirección: ${text(body.address, 160)}`, text(body?.category, 40) && `Categoría: ${text(body.category, 40)}`].filter(Boolean).join(' · ') || null;
    return prisma.supplier.create({ data: { name, nit, phone: text(body?.phone, 30), email: text(body?.email, 120), contactName: text(body?.contactName, 80), notes } });
  }

  static isServiceSimilar = similarity;
}

export { ExpenseError };
