// ============================================
// APPLICATION - Reporte de cierre de caja al dueño (Lantify 3.0)
// ============================================
// El cierre nunca espera a la nube: el resumen se guarda en una cola local y
// sube cuando hay internet. La nube lo muestra en "Mi cuenta" y lo envía por correo.

import { prisma } from '../../../infrastructure/database/prisma';
import { loadFeatures } from '../../../shared/featureStore';
import { CloseReport, closeReportText, summarizeSales } from '../../../domain/v3/closeReport';
import type { CloudAuthService } from '../CloudAuthService';

const MAX_ATTEMPTS = 40;

export class CloseReportService {
  private flushing = false;

  constructor(private cloudAuth?: CloudAuthService) {}

  async build(sessionId: string): Promise<CloseReport | null> {
    const session = await prisma.cashSession.findUnique({ where: { id: sessionId } });
    if (!session) return null;
    const [business, sales, payments, expenses, incomes] = await Promise.all([
      prisma.businessSettings.findUnique({ where: { id: 'default' }, select: { businessName: true } }),
      prisma.sale.findMany({ where: { cashSessionId: sessionId }, select: { id: true, status: true, total: true, tip: true, discount: true, paymentMethod: true, payments: { select: { paymentMethod: true, amount: true } } } }),
      prisma.payment.findMany({ where: { cashSessionId: sessionId, sale: { status: 'COMPLETED' } }, select: { paymentMethod: true, amount: true, saleId: true } }),
      prisma.expense.findMany({ where: { cashSessionId: sessionId, isCancelled: false }, select: { amount: true } }),
      prisma.income.findMany({ where: { cashSessionId: sessionId, isCancelled: false }, select: { amount: true } }),
    ]);
    // Ventas sin pagos guardados (un solo medio): cuentan con el medio de la venta
    const parts = payments.map((p) => ({ method: p.paymentMethod, amount: p.amount }));
    for (const s of sales) {
      if (s.status === 'COMPLETED' && !s.payments.length) parts.push({ method: s.paymentMethod, amount: s.total + (s.tip || 0) });
    }
    const summary = summarizeSales(sales, parts);
    const expected = session.expectedBalance ?? session.initialBalance + session.income - session.expenses;
    const counted = session.finalBalance ?? expected;
    return {
      businessName: business?.businessName || 'Lantify POS',
      sessionNumber: session.sessionNumber,
      openedAt: session.openedAt.toISOString(),
      closedAt: (session.closedAt || new Date()).toISOString(),
      openedBy: session.openedByName,
      closedBy: session.closedByName,
      initialBalance: session.initialBalance,
      expected,
      counted,
      difference: session.difference ?? counted - expected,
      expenses: expenses.reduce((a, e) => a + e.amount, 0),
      incomes: incomes.reduce((a, e) => a + e.amount, 0),
      ...summary,
    };
  }

  /** Lo que la pantalla de cierre necesita para el botón de WhatsApp */
  async forScreen(sessionId: string, lang: 'es' | 'en' = 'es') {
    const [report, features] = await Promise.all([this.build(sessionId), loadFeatures()]);
    if (!report) return null;
    return { report, text: closeReportText(report, lang), ownerWhatsapp: features.ownerWhatsapp, enabled: features.flags.close_report };
  }

  /** Al cerrar la caja: encola el resumen (si el negocio usa la función) e intenta subirlo */
  async onClosed(sessionId: string) {
    const features = await loadFeatures();
    if (!features.flags.close_report) return;
    const report = await this.build(sessionId);
    if (!report) return;
    await prisma.cloudOutbox.create({
      data: { kind: 'CLOSE_REPORT', payload: JSON.stringify({ sessionId, report, text: closeReportText(report), extraEmail: features.reportEmail || null }) },
    });
    void this.flush();
  }

  /** Sube lo pendiente. Sin internet o sin negocio vinculado, queda para el siguiente intento. */
  async flush(): Promise<number> {
    if (this.flushing || !this.cloudAuth) return 0;
    this.flushing = true;
    let sent = 0;
    try {
      const pending = await prisma.cloudOutbox.findMany({ where: { kind: 'CLOSE_REPORT', sentAt: null, attempts: { lt: MAX_ATTEMPTS } }, orderBy: { createdAt: 'asc' }, take: 20 });
      for (const row of pending) {
        try {
          await this.cloudAuth.adminCall(undefined, 'POST', '/v1/close-reports', JSON.parse(row.payload));
          await prisma.cloudOutbox.update({ where: { id: row.id }, data: { sentAt: new Date(), lastError: null } });
          sent++;
        } catch (err: any) {
          await prisma.cloudOutbox.update({ where: { id: row.id }, data: { attempts: { increment: 1 }, lastError: String(err?.code || err?.message || err).slice(0, 200) } });
          break; // sin conexión: no insistir con el resto ahora
        }
      }
    } finally {
      this.flushing = false;
    }
    return sent;
  }
}
