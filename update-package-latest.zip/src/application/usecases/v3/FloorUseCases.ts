// ============================================
// APPLICATION - Salón (Lantify 3.0): por limpiar, cuenta pedida, mesero y alertas
// ============================================

import { prisma } from '../../../infrastructure/database/prisma';
import { AuditLogger } from '../../../infrastructure/services/AuditLogger';
import { loadFeatures } from '../../../shared/featureStore';
import { computeAlerts, type AlertInput } from '../../../domain/v3/tableAlerts';
import { KITCHEN_STATES } from '../../../domain/v3/kitchen';
import { cleanLayoutElement, cleanLayoutTable, type LayoutElement, type LayoutTable } from '../../../domain/floorLayout';

const ACTIVE = ['ACTIVE', 'SENT', 'IN_PREP', 'READY'];

export interface Actor { userId?: string; name?: string; role?: string }

export class FloorError extends Error {
  constructor(message: string, public code: string, public statusCode = 400) { super(message); }
}

/** Estado en que queda una mesa al cobrarla o liberarla (lo llama TableUseCases) */
export const statusAfterClose = async (): Promise<'AVAILABLE' | 'DIRTY'> =>
  (await loadFeatures()).flags.dirty_tables ? 'DIRTY' : 'AVAILABLE';

export const markDirty = async (tableId: string) => {
  const now = new Date();
  await prisma.$transaction([
    prisma.table.update({ where: { id: tableId }, data: { status: 'DIRTY', dirtyAt: now } }),
    prisma.tableCleaning.create({ data: { tableId, dirtyAt: now } }),
  ]);
};

export class FloorUseCases {
  async cleanTable(tableId: string, actor: Actor) {
    const table = await prisma.table.findUnique({ where: { id: tableId } });
    if (!table) throw new FloorError('Mesa no encontrada', 'TABLE_NOT_FOUND', 404);
    if (table.status !== 'DIRTY') return table;
    const now = new Date();
    const [updated] = await prisma.$transaction([
      prisma.table.update({ where: { id: tableId }, data: { status: 'AVAILABLE', dirtyAt: null } }),
      prisma.tableCleaning.updateMany({ where: { tableId, cleanedAt: null }, data: { cleanedAt: now, cleanedBy: actor.name || null } }),
    ]);
    return updated;
  }

  private async activeOrder(tableId: string) {
    const order = await prisma.order.findFirst({ where: { tableId, status: { in: ACTIVE } }, orderBy: { createdAt: 'desc' } });
    if (!order) throw new FloorError('La mesa no tiene un pedido abierto', 'NO_ACTIVE_ORDER', 409);
    return order;
  }

  /** El cliente pidió la cuenta: la mesa queda "por cobrar" */
  async requestBill(tableId: string, actor: Actor) {
    const order = await this.activeOrder(tableId);
    if (order.billRequestedAt) return order;
    const [updated] = await prisma.$transaction([
      prisma.order.update({ where: { id: order.id }, data: { billRequestedAt: new Date() } }),
      prisma.table.updateMany({ where: { id: tableId, status: 'ORDERED' }, data: { status: 'PENDING' } }),
    ]);
    AuditLogger.log({ action: 'BILL_REQUESTED', entityType: 'ORDER', entityId: order.id, userId: actor.userId, userName: actor.name, userRole: actor.role, details: { tableId } });
    return updated;
  }

  async undoBill(tableId: string) {
    const order = await this.activeOrder(tableId);
    const [updated] = await prisma.$transaction([
      prisma.order.update({ where: { id: order.id }, data: { billRequestedAt: null } }),
      prisma.table.updateMany({ where: { id: tableId, status: 'PENDING' }, data: { status: 'ORDERED' } }),
    ]);
    return updated;
  }

  /** El mesero llevó a la mesa lo que estaba listo en cocina */
  async served(tableId: string, actor: Actor) {
    const order = await this.activeOrder(tableId);
    const { count } = await prisma.orderItem.updateMany({ where: { orderId: order.id, status: 'READY', isCancelled: false }, data: { status: 'SERVED', servedAt: new Date() } });
    if (count) AuditLogger.log({ action: 'ORDER_SERVED', entityType: 'ORDER', entityId: order.id, userId: actor.userId, userName: actor.name, userRole: actor.role, details: { tableId, items: count } });
    return { served: count };
  }

  /** Plano completo: mesas y elementos */
  async layout() {
    const [tables, elements] = await Promise.all([
      prisma.table.findMany({ orderBy: { number: 'asc' } }),
      prisma.floorElement.findMany({ orderBy: { createdAt: 'asc' } }),
    ]);
    return { tables, elements };
  }

  /**
   * Guarda el plano de una vez (el editor ya no guarda en cada arrastre). Las mesas
   * con pedido abierto no se pueden borrar.
   */
  async saveLayout(body: { tables?: unknown[]; elements?: unknown[]; deletedTableIds?: unknown[] }, actor: Actor) {
    const tables = (Array.isArray(body.tables) ? body.tables : []).slice(0, 500).map(cleanLayoutTable).filter((t): t is LayoutTable => !!t);
    const elements = (Array.isArray(body.elements) ? body.elements : []).slice(0, 500).map(cleanLayoutElement).filter((e): e is LayoutElement => !!e);
    const deleted = (Array.isArray(body.deletedTableIds) ? body.deletedTableIds : []).filter((x): x is string => typeof x === 'string');
    const numbers = tables.map((t) => `${t.zone || ''}|${t.number}`);
    if (new Set(numbers).size !== numbers.length) throw new FloorError('Hay dos mesas con el mismo número en la misma zona.', 'TABLE_NUMBER_DUPLICATE');
    if (deleted.length) {
      const busy = await prisma.order.findMany({ where: { tableId: { in: deleted }, status: { in: ACTIVE } }, select: { table: { select: { number: true } } } });
      if (busy.length) throw new FloorError(`No se puede quitar una mesa con pedido abierto (mesa ${busy.map((b) => b.table?.number).join(', ')}).`, 'TABLE_IN_USE', 409);
    }
    await prisma.$transaction(async (tx) => {
      if (deleted.length) await tx.table.deleteMany({ where: { id: { in: deleted } } });
      for (const t of tables) {
        const data = { number: t.number, capacity: t.capacity, zone: t.zone, positionX: t.positionX, positionY: t.positionY, width: t.width, height: t.height, shape: t.shape, rotation: t.rotation, reservable: t.reservable ?? false };
        if (t.id && (await tx.table.findUnique({ where: { id: t.id }, select: { id: true } }))) await tx.table.update({ where: { id: t.id }, data });
        else await tx.table.create({ data });
      }
      await tx.floorElement.deleteMany({});
      if (elements.length) await tx.floorElement.createMany({ data: elements });
    });
    AuditLogger.log({ action: 'FLOOR_LAYOUT_SAVED', entityType: 'SETTINGS', entityId: 'floor', userId: actor.userId, userName: actor.name, userRole: actor.role, details: { tables: tables.length, elements: elements.length, deleted: deleted.length } });
    return this.layout();
  }

  /** Personas y descripción de una mesa abierta */
  async details(tableId: string, body: { guests?: unknown; label?: unknown }) {
    const order = await this.activeOrder(tableId);
    const n = Math.round(Number(body.guests));
    const guests = body.guests === null ? null : Number.isFinite(n) && n >= 1 && n <= 99 ? n : order.guests;
    const label = body.label === undefined ? order.label : typeof body.label === 'string' && body.label.trim() ? body.label.trim().slice(0, 80) : null;
    return prisma.order.update({ where: { id: order.id }, data: { guests, label }, select: { id: true, guests: true, label: true } });
  }

  /** Reasignar la mesa a otro mesero (ADMIN) */
  async assignWaiter(tableId: string, userId: string, actor: Actor) {
    const order = await this.activeOrder(tableId);
    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user || !user.isActive) throw new FloorError('Usuario no encontrado', 'USER_NOT_FOUND', 404);
    const updated = await prisma.order.update({ where: { id: order.id }, data: { userId: user.id, userName: user.name } });
    AuditLogger.log({ action: 'TABLE_WAITER_CHANGED', entityType: 'ORDER', entityId: order.id, userId: actor.userId, userName: actor.name, userRole: actor.role, details: { tableId, from: order.userName, to: user.name } });
    return updated;
  }

  /** Lo que el plano necesita saber de cada mesa con pedido, y las alertas vigentes */
  async state(now = new Date()) {
    const [features, orders, dirty] = await Promise.all([
      loadFeatures(),
      prisma.order.findMany({
        where: { tableId: { not: null }, status: { in: ACTIVE } },
        select: { id: true, tableId: true, userId: true, userName: true, billRequestedAt: true, total: true, guests: true, label: true, table: { select: { number: true } }, items: { where: { isCancelled: false, sentAt: { not: null } }, select: { sentAt: true, status: true, readyAt: true } } },
      }),
      prisma.table.findMany({ where: { status: 'DIRTY' }, select: { id: true, dirtyAt: true } }),
    ]);
    const inputs: (AlertInput & { orderId: string; total: number })[] = orders.map((o) => ({
      orderId: o.id,
      total: o.total,
      tableId: o.tableId as string,
      tableNumber: o.table?.number || '',
      waiterId: o.userId,
      waiterName: o.userName,
      lastRoundAt: o.items.reduce<Date | null>((max, i) => (i.sentAt && (!max || i.sentAt > max) ? i.sentAt : max), null),
      // Toda la comanda salió de cocina (pantalla de cocina): desde cuándo
      lastReadyAt: o.items.length && o.items.every((i) => KITCHEN_STATES.includes(i.status))
        ? o.items.reduce<Date | null>((max, i) => (i.readyAt && (!max || i.readyAt > max) ? i.readyAt : max), null)
        : null,
      billRequestedAt: o.billRequestedAt,
    }));
    // Platos listos en cocina que el mesero aún no lleva a la mesa
    const pickups = features.flags.kitchen_display
      ? orders
        .map((o) => {
          const ready = o.items.filter((i) => i.status === 'READY');
          if (!ready.length) return null;
          const readyAt = ready.reduce<Date | null>((max, i) => (i.readyAt && (!max || i.readyAt > max) ? i.readyAt : max), null);
          return { tableId: o.tableId as string, tableNumber: o.table?.number || '', waiterId: o.userId, waiterName: o.userName, count: ready.length, readyAt };
        })
        .filter((x): x is NonNullable<typeof x> => !!x)
      : [];
    // Avisos de Autopilot al personal (últimos 30 min)
    const notices = features.flags.autopilot
      ? (await prisma.autopilotAction.findMany({ where: { kind: 'notify_staff', status: 'DONE', createdAt: { gt: new Date(now.getTime() - 30 * 60_000) } }, orderBy: { createdAt: 'desc' }, take: 5 }))
        .map((a) => { try { return { id: a.id, ...JSON.parse(a.params), createdAt: a.createdAt }; } catch { return null; } })
        .filter(Boolean)
      : [];
    return {
      now: now.toISOString(),
      pickups,
      notices,
      tables: inputs.map((t) => { const o = orders.find((x) => x.id === t.orderId); return { tableId: t.tableId, tableNumber: t.tableNumber, orderId: t.orderId, total: t.total, waiterId: t.waiterId, waiterName: t.waiterName, lastRoundAt: t.lastRoundAt, billRequestedAt: t.billRequestedAt, guests: o?.guests ?? null, label: o?.label ?? null }; }),
      dirty: dirty.map((d) => ({ tableId: d.id, dirtyAt: d.dirtyAt })),
      alerts: features.flags.table_alerts ? computeAlerts(inputs, features.alerts, now) : [],
    };
  }
}
