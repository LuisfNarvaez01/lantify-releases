// ============================================
// APPLICATION - Motor de menú, sugerencias y Autopilot (Lantify 3.0 · bloque 4)
// ============================================
// Todo se calcula aquí, en el equipo del local. La nube solo entrega mensajes
// al dueño cuando está fuera y le devuelve sus decisiones.

import crypto from 'crypto';
import { prisma } from '../../../infrastructure/database/prisma';
import { AuditLogger } from '../../../infrastructure/services/AuditLogger';
import { loadFeatures } from '../../../shared/featureStore';
import { readMenu, suggest, type MenuReading, type PrepSample, type SaleLine } from '../../../domain/v3/menuEngine';
import { buildModel, detect, forRole, canDecide, RULES, type AutopilotModel, type Intervention, type LiveState, type Situation } from '../../../domain/v3/autopilot';
import { computeAlerts } from '../../../domain/v3/tableAlerts';
import { CouponUseCases } from '../CouponUseCases';
import type { Actor } from './FloorUseCases';
import { FloorError } from './FloorUseCases';
import { catalogChanged } from '../../../shared/catalogEvents';

const DAY = 86_400_000;
const MENU_TTL = 10 * 60_000;
const MODEL_TTL = 15 * 60_000;
const DISMISS_QUIET = 2 * 3600_000;
const NOTICE_MIN = 30;
const ACTIVE = ['ACTIVE', 'SENT', 'IN_PREP', 'READY'];

const json = (v: string | null | undefined, fallback: any) => {
  try { return v ? JSON.parse(v) : fallback; } catch { return fallback; }
};
const endOfDay = (d: Date) => { const e = new Date(d); e.setHours(23, 59, 0, 0); return e; };

/** Mensajero hacia la nube (lo da app.ts); null en pruebas o sin negocio vinculado */
export interface CloudRelay {
  adminCall(actor: string | undefined, method: string, path: string, body?: unknown, timeoutMs?: number): Promise<any>;
}

export class AutopilotUseCases {
  private menuCache: { at: number; reading: MenuReading } | null = null;
  private modelCache: { at: number; model: AutopilotModel } | null = null;
  private ticking = false;
  private coupons = new CouponUseCases();

  constructor(private cloud: CloudRelay | null = null) {}

  // ── Motor de menú ──

  async menu(now = new Date(), fresh = false): Promise<MenuReading> {
    if (!fresh && this.menuCache && now.getTime() - this.menuCache.at < MENU_TTL) return this.menuCache.reading;
    const from = new Date(now.getTime() - 60 * DAY);
    const [sales, prepRows] = await Promise.all([
      prisma.sale.findMany({
        where: { status: 'COMPLETED', createdAt: { gte: from } },
        select: { id: true, createdAt: true, items: { where: { isCancelled: false }, select: { quantity: true, total: true, productVariant: { select: { cost: true, product: { select: { id: true, name: true } } } } } } },
      }),
      prisma.orderItem.findMany({
        where: { readyAt: { not: null }, sentAt: { gte: from }, isCancelled: false },
        select: { sentAt: true, readyAt: true, productVariant: { select: { productId: true } } },
      }),
    ]);
    const lines: SaleLine[] = sales.flatMap((s) => s.items.map((i) => ({
      saleId: s.id,
      productId: i.productVariant.product.id,
      name: i.productVariant.product.name,
      quantity: i.quantity,
      revenue: i.total,
      cost: i.productVariant.cost != null ? i.productVariant.cost * i.quantity : null,
      at: s.createdAt,
    })));
    const prep: PrepSample[] = prepRows
      .map((r) => ({ productId: r.productVariant.productId, minutes: (r.readyAt!.getTime() - r.sentAt!.getTime()) / 60_000 }))
      .filter((p) => p.minutes > 0 && p.minutes < 180);
    const reading = readMenu(lines, prep, now);
    this.menuCache = { at: now.getTime(), reading };
    return reading;
  }

  /** Productos que no se pueden ofrecer ahora: inactivos, pausados o sin existencias */
  private async blocked(now: Date) {
    const products = await prisma.product.findMany({
      select: { id: true, isActive: true, pausedUntil: true, variants: { where: { isActive: true }, select: { trackInventory: true, stock: true } } },
    });
    return new Set(products
      .filter((p) => !p.isActive || (p.pausedUntil && p.pausedUntil > now) || !p.variants.length || p.variants.every((v) => v.trackInventory && v.stock <= 0))
      .map((p) => p.id));
  }

  private async boosted(now: Date) {
    const rows = await prisma.autopilotAction.findMany({ where: { kind: 'boost_products', status: 'DONE', revertAt: { gt: now } }, orderBy: { createdAt: 'desc' } });
    return [...new Set(rows.flatMap((r) => json(r.params, {}).productIds || []))] as string[];
  }

  async suggestions(cart: string[], now = new Date()) {
    const features = await loadFeatures();
    if (!features.flags.waiter_suggestions) return { suggestions: [] };
    const [reading, blocked, boost] = await Promise.all([this.menu(now), this.blocked(now), features.flags.autopilot ? this.boosted(now) : Promise.resolve([])]);
    return { suggestions: suggest(reading, { cart, hour: now.getHours(), blocked, boost }) };
  }

  async recordSuggestion(productId: string, reason: string, accepted: boolean, userId?: string) {
    if (!productId) return { ok: false };
    await prisma.suggestionEvent.create({ data: { productId: productId.slice(0, 60), reason: String(reason || '').slice(0, 20), accepted, userId: userId || null } });
    return { ok: true };
  }

  // ── Modelo del negocio ──

  async model(now = new Date(), fresh = false): Promise<AutopilotModel> {
    if (!fresh && this.modelCache && now.getTime() - this.modelCache.at < MODEL_TTL) return this.modelCache.model;
    const from = new Date(now.getTime() - 8 * 7 * DAY);
    const [sales, tickets] = await Promise.all([
      prisma.sale.findMany({ where: { status: 'COMPLETED', createdAt: { gte: from } }, select: { createdAt: true, total: true } }),
      prisma.orderItem.findMany({ where: { sentAt: { gte: from }, isCancelled: false }, select: { orderId: true, roundNumber: true, sentAt: true, readyAt: true } }),
    ]);
    // Una comanda = pedido + ronda; su tiempo, el de la última línea que salió
    const rounds = new Map<string, { sentAt: Date; readyAt: Date | null }>();
    for (const t of tickets) {
      const k = `${t.orderId}:${t.roundNumber ?? 0}`;
      const r = rounds.get(k);
      if (!r) rounds.set(k, { sentAt: t.sentAt!, readyAt: t.readyAt });
      else {
        if (t.sentAt! < r.sentAt) r.sentAt = t.sentAt!;
        r.readyAt = !t.readyAt || !r.readyAt ? null : t.readyAt > r.readyAt ? t.readyAt : r.readyAt;
      }
    }
    const model = buildModel(sales.map((s) => ({ at: s.createdAt, total: s.total })), [...rounds.values()], now);
    this.modelCache = { at: now.getTime(), model };
    await prisma.autopilotModel.upsert({ where: { id: 'default' }, update: { data: JSON.stringify(model), builtAt: now }, create: { id: 'default', data: JSON.stringify(model), builtAt: now } });
    return model;
  }

  /** Lo que Lantify sabe del negocio, para mostrarlo (sin las 96 franjas de cada día) */
  async knowledge(now = new Date()) {
    const [model, menu] = await Promise.all([this.model(now), this.menu(now)]);
    const today = now.getDay();
    return {
      builtAt: model.builtAt,
      historyDays: model.historyDays,
      ready: model.ready,
      minDays: 14,
      firstSaleAt: model.firstSaleAt,
      prepAll: model.prepAll,
      capacity30: model.capacity30,
      todayByHour: Array.from({ length: 24 }, (_, h) => ({ hour: h, sales: [0, 1, 2, 3].reduce((n, q) => n + model.slots[today][h * 4 + q].sales, 0) })),
      fastest: menu.items.filter((i) => i.prepMedian !== null).sort((a, b) => a.prepMedian! - b.prepMedian!).slice(0, 5).map((i) => ({ name: i.name, minutes: i.prepMedian })),
      slowest: menu.items.filter((i) => i.prepMedian !== null).sort((a, b) => b.prepP80! - a.prepP80!).slice(0, 5).map((i) => ({ name: i.name, minutes: i.prepP80 })),
    };
  }

  // ── El momento actual ──

  private async live(now: Date, menu: MenuReading): Promise<LiveState> {
    const [features, openItems, ticketsLast30, salesLast60, orders, products, history] = await Promise.all([
      loadFeatures(),
      prisma.orderItem.findMany({ where: { status: { in: ['SENT', 'IN_PREP'] }, isCancelled: false, sentAt: { not: null, gte: new Date(now.getTime() - 6 * 3600_000) } }, select: { orderId: true, roundNumber: true, sentAt: true } }),
      prisma.orderItem.findMany({ where: { sentAt: { gte: new Date(now.getTime() - 30 * 60_000) }, isCancelled: false }, select: { orderId: true, roundNumber: true } }),
      prisma.sale.count({ where: { status: 'COMPLETED', createdAt: { gte: new Date(now.getTime() - 60 * 60_000) } } }),
      prisma.order.findMany({
        where: { tableId: { not: null }, status: { in: ACTIVE } },
        select: { userId: true, userName: true, tableId: true, billRequestedAt: true, table: { select: { number: true } }, items: { where: { isCancelled: false, sentAt: { not: null } }, select: { sentAt: true, status: true, readyAt: true } } },
      }),
      prisma.product.findMany({ where: { isActive: true }, select: { id: true, name: true, variants: { where: { isActive: true, trackInventory: true }, select: { stock: true } } } }),
      // Unidades vendidas el mismo día de la semana después de esta hora (8 semanas)
      prisma.sale.findMany({
        where: { status: 'COMPLETED', createdAt: { gte: new Date(now.getTime() - 56 * DAY), lt: new Date(now.getTime() - DAY) } },
        select: { createdAt: true, items: { where: { isCancelled: false }, select: { quantity: true, productVariant: { select: { productId: true } } } } },
      }),
    ]);
    const tickets = new Map<string, Date>();
    for (const i of openItems) {
      const k = `${i.orderId}:${i.roundNumber ?? 0}`;
      const prev = tickets.get(k);
      if (!prev || i.sentAt! < prev) tickets.set(k, i.sentAt!);
    }
    const loads = new Map<string, { waiterId: string; name: string; tables: number }>();
    for (const o of orders) {
      if (!o.userId) continue;
      const v = loads.get(o.userId) || { waiterId: o.userId, name: o.userName || '', tables: 0 };
      v.tables += 1;
      loads.set(o.userId, v);
    }
    const alerts = features.flags.table_alerts
      ? computeAlerts(orders.map((o) => ({
        tableId: o.tableId!, tableNumber: o.table?.number || '', waiterId: o.userId, waiterName: o.userName,
        lastRoundAt: o.items.reduce<Date | null>((m, i) => (i.sentAt && (!m || i.sentAt > m) ? i.sentAt : m), null),
        lastReadyAt: null, billRequestedAt: o.billRequestedAt,
      })), features.alerts, now).length
      : 0;
    // Demanda esperada hasta el cierre por producto con inventario
    const sameDay = history.filter((s) => s.createdAt.getDay() === now.getDay() && (s.createdAt.getHours() * 60 + s.createdAt.getMinutes()) >= now.getHours() * 60 + now.getMinutes());
    const days = new Set(sameDay.map((s) => s.createdAt.toDateString())).size || 1;
    const rest = new Map<string, number>();
    for (const s of sameDay) for (const i of s.items) rest.set(i.productVariant.productId, (rest.get(i.productVariant.productId) || 0) + i.quantity);
    const stock = products
      .filter((p) => p.variants.length)
      .map((p) => ({ productId: p.id, name: p.name, stock: p.variants.reduce((n, v) => n + Math.max(0, v.stock), 0), expectedRest: (rest.get(p.id) || 0) / days }));
    const timed = menu.items.filter((i) => i.prepMedian !== null);
    return {
      now,
      openTickets: [...tickets.values()].map((at) => ({ ageMin: Math.floor((now.getTime() - at.getTime()) / 60_000) })),
      ticketsLast30: new Set(ticketsLast30.map((i) => `${i.orderId}:${i.roundNumber ?? 0}`)).size,
      salesLast60,
      tableAlerts: alerts,
      waiterLoads: [...loads.values()],
      stock,
      fastProducts: [...timed].sort((a, b) => a.prepMedian! - b.prepMedian!).filter((i) => i.klass !== 'DOG').map((i) => i.productId),
      slowProducts: [...timed].sort((a, b) => b.prepP80! - a.prepP80!).map((i) => i.productId),
      puzzles: menu.items.filter((i) => i.klass === 'PUZZLE').map((i) => i.productId),
    };
  }

  /** Cada minuto: detectar, abrir o cerrar situaciones, revertir lo vencido y hablar con la nube */
  async tick(now = new Date()) {
    if (this.ticking) return { situations: 0 };
    this.ticking = true;
    try {
      await this.revertDue(now);
      if (!(await loadFeatures()).flags.autopilot) return { situations: 0 };
      const [model, menu] = await Promise.all([this.model(now), this.menu(now)]);
      const found = detect(model, await this.live(now, menu));
      const open = await prisma.autopilotSituation.findMany({ where: { status: 'OPEN' } });
      const quiet = await prisma.autopilotSituation.findMany({ where: { status: { in: ['DISMISSED', 'ACTED'] }, closedAt: { gt: new Date(now.getTime() - DISMISS_QUIET) } }, select: { key: true } });
      const silenced = new Set(quiet.map((q) => q.key));
      for (const s of found) {
        const cur = open.find((o) => o.key === s.key);
        if (cur) {
          await prisma.autopilotSituation.update({ where: { id: cur.id }, data: { lastSeenAt: now, severity: s.severity, evidence: JSON.stringify(s.evidence), interventions: JSON.stringify(s.interventions) } });
        } else if (!silenced.has(s.key)) {
          await prisma.autopilotSituation.create({ data: { key: s.key, kind: s.kind, severity: s.severity, evidence: JSON.stringify(s.evidence), interventions: JSON.stringify(s.interventions), firstSeenAt: now, lastSeenAt: now } });
        }
      }
      const keys = new Set(found.map((s) => s.key));
      for (const o of open) if (!keys.has(o.key)) await prisma.autopilotSituation.update({ where: { id: o.id }, data: { status: 'RESOLVED', closedAt: now } });
      await this.syncCloud(now).catch(() => undefined);
      return { situations: found.length };
    } finally {
      this.ticking = false;
    }
  }

  private shape(row: { id: string; key: string; kind: string; severity: string; evidence: string; interventions: string; firstSeenAt: Date; lastSeenAt: Date; cloudSentAt: Date | null }): Situation & { id: string; firstSeenAt: Date; ownerNotified: boolean } {
    return { id: row.id, key: row.key, kind: row.kind as Situation['kind'], severity: row.severity as Situation['severity'], evidence: json(row.evidence, {}), interventions: json(row.interventions, []), firstSeenAt: row.firstSeenAt, ownerNotified: !!row.cloudSentAt };
  }

  /** Lo que ve cada rol */
  async state(role: string, now = new Date()) {
    const features = await loadFeatures();
    if (!features.flags.autopilot) return { enabled: false, situations: [], actions: [], learning: null };
    const [rows, actions, model] = await Promise.all([
      prisma.autopilotSituation.findMany({ where: { status: 'OPEN' }, orderBy: { firstSeenAt: 'asc' } }),
      prisma.autopilotAction.findMany({ where: { OR: [{ status: 'DONE', revertAt: { gt: now } }, { createdAt: { gt: new Date(now.getTime() - 3600_000) } }] }, orderBy: { createdAt: 'desc' }, take: 20 }),
      this.model(now),
    ]);
    const situations = rows.map((r) => this.shape(r)).map((s) => {
      const v = forRole(role, s);
      return v ? { ...v, id: s.id, firstSeenAt: s.firstSeenAt, ownerNotified: s.ownerNotified } : null;
    }).filter(Boolean);
    return {
      enabled: true,
      learning: model.ready ? null : { historyDays: model.historyDays, minDays: 14 },
      situations,
      actions: role === 'WAITER' ? [] : actions.map((a) => ({ id: a.id, kind: a.kind, params: json(a.params, {}), status: a.status, source: a.source, decidedBy: a.decidedBy, revertAt: a.revertAt, createdAt: a.createdAt, result: json(a.result, null) })),
    };
  }

  /** Avisos al personal vigentes (los muestra el salón y el celular) */
  async notices(now = new Date()) {
    const rows = await prisma.autopilotAction.findMany({ where: { kind: 'notify_staff', status: 'DONE', createdAt: { gt: new Date(now.getTime() - NOTICE_MIN * 60_000) } }, orderBy: { createdAt: 'desc' }, take: 5 });
    return rows.map((r) => ({ id: r.id, ...json(r.params, {}), createdAt: r.createdAt }));
  }

  // ── Decidir y ejecutar ──

  async decide(situationId: string, interventionId: string, overrides: Record<string, any>, actor: Actor & { role?: string }, source: 'LOCAL' | 'OWNER' = 'LOCAL', now = new Date()) {
    const row = await prisma.autopilotSituation.findUnique({ where: { id: situationId } });
    if (!row) throw new FloorError('Esta situación ya no existe.', 'SITUATION_NOT_FOUND', 404);
    if (row.status !== 'OPEN') throw new FloorError('Esta situación ya se resolvió.', 'SITUATION_CLOSED', 409);
    const s = this.shape(row);
    const iv = s.interventions.find((i) => i.id === interventionId);
    if (!iv) throw new FloorError('Intervención no encontrada.', 'INTERVENTION_NOT_FOUND', 404);
    if (source === 'LOCAL' && !canDecide(actor.role || '', iv.kind)) throw new FloorError('Tu rol no puede tomar esta decisión.', 'AUTH_FORBIDDEN', 403);
    const params = this.adjust(iv, overrides);
    const result = await this.execute(iv.kind, params, actor, now);
    const minutes = params.untilClose ? null : Number(params.minutes) || iv.revertMin;
    const revertAt = iv.kind === 'pause_products' && params.untilClose ? endOfDay(now) : minutes ? new Date(now.getTime() + minutes * 60_000) : null;
    const action = await prisma.autopilotAction.create({
      data: { situationId, interventionId, kind: iv.kind, params: JSON.stringify(params), source, decidedBy: actor.name || null, result: JSON.stringify(result), revertAt },
    });
    await prisma.autopilotSituation.update({ where: { id: situationId }, data: { status: 'ACTED', closedAt: now, decidedBy: actor.name || (source === 'OWNER' ? 'Dueño' : null) } });
    AuditLogger.log({ action: 'AUTOPILOT_ACTION', entityType: 'AUTOPILOT', entityId: action.id, userId: actor.userId, userName: actor.name, userRole: actor.role, details: { situation: s.kind, kind: iv.kind, params, source } });
    return { action: { id: action.id, kind: iv.kind, params, result, revertAt } };
  }

  /** Solo se ajustan los parámetros que la intervención ya trae, dentro de límites */
  private adjust(iv: Intervention, o: Record<string, any>) {
    const p = { ...iv.params };
    const clamp = (v: unknown, min: number, max: number, d: number) => { const n = Number(v); return Number.isFinite(n) ? Math.min(max, Math.max(min, Math.round(n))) : d; };
    if ('minutes' in p && o?.minutes !== undefined) p.minutes = clamp(o.minutes, 5, 240, p.minutes);
    if ('percent' in p && o?.percent !== undefined) p.percent = clamp(o.percent, 5, 30, p.percent);
    if ('hours' in p && o?.hours !== undefined) p.hours = clamp(o.hours, 1, 8, p.hours);
    return p;
  }

  private async execute(kind: Intervention['kind'], params: Record<string, any>, actor: Actor, now: Date) {
    switch (kind) {
      case 'pause_products': {
        const until = params.untilClose ? endOfDay(now) : new Date(now.getTime() + (Number(params.minutes) || 30) * 60_000);
        const { count } = await prisma.product.updateMany({ where: { id: { in: params.productIds || [] } }, data: { pausedUntil: until } });
        // La caja, los celulares y la página dejan de ofrecerlo de inmediato
        catalogChanged();
        return { paused: count, until };
      }
      case 'boost_products':
        return { boosted: (params.productIds || []).length };
      case 'notify_staff':
        return { notified: true };
      case 'flash_coupon': {
        const code = `FLASH${crypto.randomInt(100, 999)}`;
        const coupon = await this.coupons.create({
          code, description: 'Autopilot · hora floja', type: 'PERCENT', value: Number(params.percent) || 10, minPurchase: null,
          startsAt: now.toISOString(), endsAt: new Date(now.getTime() + (Number(params.hours) || 2) * 3600_000).toISOString(),
        } as any, actor.name, 'AGENT');
        return { couponId: (coupon as any).id, code };
      }
      case 'call_staff': {
        const staff = await prisma.employee.findMany({ where: { isActive: true, phone: { not: null } }, select: { name: true, phone: true }, take: 10 });
        return { contacts: staff };
      }
    }
  }

  /** Deshacer una intervención */
  async revert(actionId: string, actor: Actor, now = new Date()) {
    const a = await prisma.autopilotAction.findUnique({ where: { id: actionId } });
    if (!a || a.status !== 'DONE') throw new FloorError('Esta acción ya no se puede deshacer.', 'ACTION_NOT_REVERSIBLE', 409);
    await this.undo(a, now);
    AuditLogger.log({ action: 'AUTOPILOT_REVERTED', entityType: 'AUTOPILOT', entityId: a.id, userId: actor.userId, userName: actor.name, userRole: actor.role, details: { kind: a.kind } });
    return { reverted: true };
  }

  private async undo(a: { id: string; kind: string; params: string; result: string | null }, now: Date) {
    const params = json(a.params, {});
    if (a.kind === 'pause_products') {
      await prisma.product.updateMany({ where: { id: { in: params.productIds || [] }, pausedUntil: { not: null } }, data: { pausedUntil: null } });
      catalogChanged();
    }
    if (a.kind === 'flash_coupon') {
      const r = json(a.result, {});
      if (r.couponId) await prisma.coupon.update({ where: { id: r.couponId }, data: { isActive: false } }).catch(() => undefined);
    }
    await prisma.autopilotAction.update({ where: { id: a.id }, data: { status: 'REVERTED', revertedAt: now } });
  }

  /** Las intervenciones temporales se revierten solas */
  private async revertDue(now: Date) {
    const due = await prisma.autopilotAction.findMany({ where: { status: 'DONE', revertAt: { lte: now } } });
    for (const a of due) await this.undo(a, now);
  }

  async dismiss(situationId: string, actor: Actor, now = new Date()) {
    const row = await prisma.autopilotSituation.findUnique({ where: { id: situationId } });
    if (!row || row.status !== 'OPEN') return { dismissed: false };
    await prisma.autopilotSituation.update({ where: { id: situationId }, data: { status: 'DISMISSED', closedAt: now, decidedBy: actor.name || null } });
    return { dismissed: true };
  }

  // ── El dueño fuera del local (la nube solo hace de mensajero) ──

  private async syncCloud(now: Date) {
    if (!this.cloud) return;
    // Situaciones graves nuevas → Mi cuenta y correo del dueño
    const pending = await prisma.autopilotSituation.findMany({ where: { status: 'OPEN', severity: 'high', cloudSentAt: null }, take: 5 });
    for (const row of pending) {
      const s = this.shape(row);
      await this.cloud.adminCall(undefined, 'POST', '/v1/autopilot/situations', {
        localId: s.id, kind: s.kind, severity: s.severity, evidence: s.evidence,
        interventions: s.interventions.filter((i) => i.kind !== 'call_staff').map((i) => ({ id: i.id, kind: i.kind, params: i.params })),
        expiresAt: new Date(now.getTime() + RULES.expireMin * 60_000).toISOString(),
      }, 15000);
      await prisma.autopilotSituation.update({ where: { id: row.id }, data: { cloudSentAt: now } });
    }
    // Decisiones que tomó el dueño en Mi cuenta
    const r = await this.cloud.adminCall(undefined, 'GET', '/v1/autopilot/decisions', undefined, 15000);
    for (const d of Array.isArray(r?.decisions) ? r.decisions : []) {
      try {
        if (d.decision === 'accept') await this.decide(String(d.localId), String(d.interventionId), {}, { name: 'Dueño (Mi cuenta)' }, 'OWNER', now);
        else await this.dismiss(String(d.localId), { name: 'Dueño (Mi cuenta)' }, now);
      } catch { /* ya resuelta aquí */ }
      await this.cloud.adminCall(undefined, 'POST', '/v1/autopilot/decisions/ack', { id: d.id }, 15000).catch(() => undefined);
    }
  }
}
