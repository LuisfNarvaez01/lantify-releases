// ============================================
// APPLICATION - Ingredientes, recetas y kardex (Lantify 3.0)
// ============================================
// El inventario verdadero: al cobrar, cada producto con receta descuenta sus
// ingredientes; si no alcanza, vende igual y queda en negativo con alerta. Las
// anulaciones nunca borran el kardex: devuelven (VOID_RETURN) o marcan desperdicio
// (WASTE). Las compras actualizan el costo promedio y, en cascada, el costo de
// las recetas (sin tocar el precio de venta).

import { Prisma } from '@prisma/client';
import { prisma } from '../../../infrastructure/database/prisma';
import { AuditLogger } from '../../../infrastructure/services/AuditLogger';
import { loadFeatures } from '../../../shared/featureStore';
import { BASE_UNITS, consumption, marginPct, recipeCost, round4, weightedAverage, type BaseUnit } from '../../../domain/v3/recipes';
import { FloorError, type Actor } from './FloorUseCases';

type Tx = Prisma.TransactionClient | typeof prisma;

const text = (v: unknown, max: number) => (typeof v === 'string' && v.trim() ? v.trim().replace(/\s+/g, ' ').slice(0, max) : null);
const num = (v: unknown) => { const n = Number(v); return Number.isFinite(n) ? n : null; };

export interface MarginAlert { productId: string; name: string; cost: number; price: number; margin: number | null }

export class IngredientUseCases {
  // ── Catálogo ──

  async list() {
    const rows = await prisma.ingredient.findMany({ where: { isActive: true }, orderBy: { name: 'asc' }, include: { _count: { select: { recipeItems: true } } } });
    return rows.map((r) => ({ ...r, low: r.minStock !== null && r.stock <= r.minStock, usedIn: r._count.recipeItems }));
  }

  async save(id: string | null, body: Record<string, unknown>, actor: Actor) {
    const name = text(body.name, 80);
    if (!name) throw new FloorError('Escribe el nombre del ingrediente.', 'INGREDIENT_INVALID');
    const unit = BASE_UNITS.includes(body.unit as BaseUnit) ? (body.unit as BaseUnit) : 'g';
    const data = {
      name, unit,
      minStock: body.minStock === null || body.minStock === '' ? null : num(body.minStock),
      category: text(body.category, 40),
      preferredSupplierId: text(body.preferredSupplierId, 60),
      ...(id ? {} : { avgCost: Math.max(0, num(body.avgCost) ?? 0), lastCost: num(body.avgCost) }),
    };
    if (id) {
      const cur = await prisma.ingredient.findUnique({ where: { id } });
      if (!cur) throw new FloorError('Ingrediente no encontrado', 'INGREDIENT_NOT_FOUND', 404);
      // La unidad no cambia si ya hay movimientos (cambiaría el sentido de las existencias)
      if (cur.unit !== unit && (await prisma.ingredientMovement.count({ where: { ingredientId: id } }))) {
        throw new FloorError('No se puede cambiar la unidad de un ingrediente con movimientos.', 'INGREDIENT_UNIT_LOCKED', 409);
      }
      const costChanged = body.avgCost !== undefined && num(body.avgCost) !== null && num(body.avgCost) !== cur.avgCost;
      const saved = await prisma.ingredient.update({ where: { id }, data: { ...data, ...(costChanged ? { avgCost: Math.max(0, num(body.avgCost)!) } : {}) } });
      if (costChanged || cur.name !== name) await this.cascade([id]);
      return saved;
    }
    const created = await prisma.ingredient.create({ data });
    if ((num(body.stock) ?? 0) > 0) await this.adjust(created.id, { type: 'COUNT', quantity: num(body.stock), notes: 'Existencia inicial' }, actor);
    return prisma.ingredient.findUnique({ where: { id: created.id } });
  }

  async remove(id: string) {
    await prisma.ingredient.update({ where: { id }, data: { isActive: false } }).catch(() => null);
    return { removed: true };
  }

  async movements(id: string, limit = 100) {
    return prisma.ingredientMovement.findMany({ where: { ingredientId: id }, orderBy: { createdAt: 'desc' }, take: Math.min(500, limit) });
  }

  /** Movimiento de existencias: una línea en el kardex y la existencia nueva */
  async move(tx: Tx, ingredientId: string, type: string, delta: number, opts: { unitCost?: number | null; reference?: string | null; notes?: string | null; by?: string | null }) {
    const ing = await tx.ingredient.findUnique({ where: { id: ingredientId } });
    if (!ing) return null;
    const next = round4(ing.stock + delta);
    await tx.ingredient.update({ where: { id: ingredientId }, data: { stock: next } });
    await tx.ingredientMovement.create({ data: { ingredientId, type, quantity: round4(delta), previousStock: ing.stock, newStock: next, unitCost: opts.unitCost ?? ing.avgCost, reference: opts.reference ?? null, notes: opts.notes ?? null, createdBy: opts.by ?? null } });
    return next;
  }

  /** Ajuste, desperdicio o conteo físico (COUNT deja la existencia en el número contado) */
  async adjust(id: string, body: { type?: unknown; quantity?: unknown; notes?: unknown }, actor: Actor) {
    const type = body.type === 'WASTE' || body.type === 'COUNT' ? body.type : 'ADJUSTMENT';
    const q = num(body.quantity);
    if (q === null) throw new FloorError('Indica la cantidad.', 'INGREDIENT_QTY');
    const ing = await prisma.ingredient.findUnique({ where: { id } });
    if (!ing) throw new FloorError('Ingrediente no encontrado', 'INGREDIENT_NOT_FOUND', 404);
    const delta = type === 'COUNT' ? q - ing.stock : type === 'WASTE' ? -Math.abs(q) : q;
    const next = await this.move(prisma, id, type, delta, { notes: text(body.notes, 200), by: actor.name || null });
    AuditLogger.log({ action: 'INGREDIENT_ADJUSTED', entityType: 'INGREDIENT', entityId: id, userId: actor.userId, userName: actor.name, userRole: actor.role, details: { type, delta, stock: next } });
    return prisma.ingredient.findUnique({ where: { id } });
  }

  // ── Recetas y costo teórico ──

  async recipe(productId: string) {
    const product = await prisma.product.findUnique({
      where: { id: productId },
      select: { id: true, name: true, variants: { where: { isActive: true }, select: { id: true, name: true, price: true, cost: true } }, recipe: { orderBy: { createdAt: 'asc' }, include: { ingredient: { select: { id: true, name: true, unit: true, avgCost: true, stock: true } } } } },
    });
    if (!product) throw new FloorError('Producto no encontrado', 'PRODUCT_NOT_FOUND', 404);
    const cost = recipeCost(product.recipe.map((r) => ({ ingredientId: r.ingredientId, quantity: r.quantity, avgCost: r.ingredient.avgCost })));
    const price = product.variants.length ? Math.min(...product.variants.map((v) => v.price)) : 0;
    const { minMarginPct } = await loadFeatures();
    return {
      productId: product.id, name: product.name,
      items: product.recipe.map((r) => ({ ingredientId: r.ingredientId, name: r.ingredient.name, unit: r.ingredient.unit, quantity: r.quantity, removable: r.removable, avgCost: r.ingredient.avgCost, lineCost: Math.round(r.quantity * r.ingredient.avgCost) })),
      cost, price, margin: marginPct(price, cost), minMarginPct,
    };
  }

  async setRecipe(productId: string, items: unknown, actor: Actor) {
    const list = (Array.isArray(items) ? items : [])
      .map((i: any) => ({ ingredientId: typeof i?.ingredientId === 'string' ? i.ingredientId : '', quantity: num(i?.quantity) ?? 0, removable: i?.removable !== false }))
      .filter((i) => i.ingredientId && i.quantity > 0)
      .slice(0, 60);
    const ids = [...new Set(list.map((i) => i.ingredientId))];
    if (ids.length !== list.length) throw new FloorError('Un ingrediente está repetido en la receta.', 'RECIPE_DUPLICATE');
    if (ids.length && (await prisma.ingredient.count({ where: { id: { in: ids } } })) !== ids.length) throw new FloorError('Un ingrediente de la receta no existe.', 'RECIPE_INVALID');
    const base = Date.now();
    await prisma.$transaction([
      prisma.recipeItem.deleteMany({ where: { productId } }),
      // createdAt escalonado: la receta (y los comentarios) conservan el orden en que se escribió
      ...list.map((i, k) => prisma.recipeItem.create({ data: { productId, ingredientId: i.ingredientId, quantity: round4(i.quantity), removable: i.removable, createdAt: new Date(base + k) } })),
    ]);
    await this.cascade(ids, [productId]);
    AuditLogger.log({ action: 'RECIPE_UPDATED', entityType: 'PRODUCT', entityId: productId, userId: actor.userId, userName: actor.name, userRole: actor.role, details: { items: list.length } });
    return this.recipe(productId);
  }

  /**
   * Recalcula el costo de los productos que usan estos ingredientes y lo deja en sus
   * variantes (de ahí lo leen el motor de menú y los agentes). El precio no cambia.
   * Devuelve los productos que quedaron por debajo del margen mínimo.
   */
  async cascade(ingredientIds: string[], alsoProducts: string[] = [], tx: Tx = prisma, minMargin?: number): Promise<MarginAlert[]> {
    const products = await tx.product.findMany({
      where: { OR: [{ recipe: { some: { ingredientId: { in: ingredientIds } } } }, { id: { in: alsoProducts } }] },
      select: { id: true, name: true, ingredients: true, variants: { select: { id: true, price: true } }, recipe: { orderBy: { createdAt: 'asc' }, select: { ingredientId: true, quantity: true, removable: true, ingredient: { select: { avgCost: true, name: true } } } } },
    });
    // Dentro de una transacción no se lee nada por fuera (SQLite tiene un solo escritor): el mínimo llega como parámetro
    const minMarginPct = minMargin ?? (await loadFeatures()).minMarginPct;
    const alerts: MarginAlert[] = [];
    for (const p of products) {
      if (!p.recipe.length) continue;
      const cost = recipeCost(p.recipe.map((r) => ({ ingredientId: r.ingredientId, quantity: r.quantity, avgCost: r.ingredient.avgCost })));
      await tx.productVariant.updateMany({ where: { productId: p.id }, data: { cost } });
      // Lo que el cliente puede pedir "sin" sale de la receta (los empaques y la sal se marcan como fijos)
      const names = JSON.stringify(p.recipe.filter((r) => r.removable).map((r) => r.ingredient.name).slice(0, 24));
      if (names !== (p.ingredients || '[]')) await tx.product.update({ where: { id: p.id }, data: { ingredients: names } });
      const price = p.variants.length ? Math.min(...p.variants.map((v) => v.price)) : 0;
      const margin = marginPct(price, cost);
      if (margin !== null && margin < minMarginPct) alerts.push({ productId: p.id, name: p.name, cost, price, margin });
    }
    return alerts;
  }

  /** Productos con receta: costo, precio y margen (con alerta bajo el mínimo) */
  async costs() {
    const { minMarginPct } = await loadFeatures();
    const products = await prisma.product.findMany({
      where: { recipe: { some: {} } },
      select: { id: true, name: true, variants: { select: { price: true } }, recipe: { select: { ingredientId: true, quantity: true, ingredient: { select: { avgCost: true } } } } },
      orderBy: { name: 'asc' },
    });
    return {
      minMarginPct,
      products: products.map((p) => {
        const cost = recipeCost(p.recipe.map((r) => ({ ingredientId: r.ingredientId, quantity: r.quantity, avgCost: r.ingredient.avgCost })));
        const price = p.variants.length ? Math.min(...p.variants.map((v) => v.price)) : 0;
        const margin = marginPct(price, cost);
        return { productId: p.id, name: p.name, cost, price, margin, low: margin !== null && margin < minMarginPct };
      }),
    };
  }

  // ── Venta y anulación ──

  private async recipesFor(tx: Tx, variantIds: string[]) {
    const variants = await tx.productVariant.findMany({ where: { id: { in: variantIds } }, select: { id: true, productId: true } });
    const productIds = [...new Set(variants.map((v) => v.productId))];
    const rows = await tx.recipeItem.findMany({ where: { productId: { in: productIds } }, select: { productId: true, ingredientId: true, quantity: true } });
    const recipes = new Map<string, { ingredientId: string; quantity: number }[]>();
    for (const r of rows) recipes.set(r.productId, [...(recipes.get(r.productId) || []), { ingredientId: r.ingredientId, quantity: r.quantity }]);
    return { productOf: new Map(variants.map((v) => [v.id, v.productId])), recipes };
  }

  /** Al cobrar: descuenta los ingredientes de lo vendido. Devuelve los que quedaron en negativo. */
  async consumeSale(tx: Tx, reference: string, items: { productVariantId: string; quantity: number }[], by?: string | null) {
    const { productOf, recipes } = await this.recipesFor(tx, items.map((i) => i.productVariantId));
    if (!recipes.size) return [] as string[];
    const used = consumption(items.map((i) => ({ productId: productOf.get(i.productVariantId) || '', quantity: i.quantity })), recipes);
    const negative: string[] = [];
    for (const [ingredientId, qty] of used) {
      const next = await this.move(tx, ingredientId, 'SALE_CONSUMPTION', -qty, { reference, notes: `Venta ${reference}`, by });
      if (next !== null && next < 0) negative.push(ingredientId);
    }
    return negative;
  }

  /**
   * Anulación: lo que se descontó vuelve (VOID_RETURN). Si ya se había preparado,
   * se registra además el desperdicio (WASTE) por la misma cantidad: la existencia
   * no vuelve, pero el kardex dice por qué.
   */
  async voidItems(tx: Tx, reference: string, items: { productVariantId: string; quantity: number }[], prepared: boolean, by?: string | null) {
    const { productOf, recipes } = await this.recipesFor(tx, items.map((i) => i.productVariantId));
    if (!recipes.size) return;
    const used = consumption(items.map((i) => ({ productId: productOf.get(i.productVariantId) || '', quantity: i.quantity })), recipes);
    for (const [ingredientId, qty] of used) {
      await this.move(tx, ingredientId, 'VOID_RETURN', qty, { reference, notes: `Anulación ${reference}`, by });
      if (prepared) await this.move(tx, ingredientId, 'WASTE', -qty, { reference, notes: `Ya preparado: ${reference}`, by });
    }
  }

  // ── Compras (factura) ──

  /** Entrada de compra: existencias, último costo y costo promedio ponderado */
  async purchase(tx: Tx, lines: { ingredientId: string; quantity: number; unitCost: number }[], reference: string, by?: string | null, minMargin?: number) {
    const touched: string[] = [];
    for (const l of lines) {
      if (l.quantity <= 0) continue;
      const ing = await tx.ingredient.findUnique({ where: { id: l.ingredientId } });
      if (!ing) continue;
      const avg = weightedAverage(ing.stock, ing.avgCost, l.quantity, l.unitCost);
      await tx.ingredient.update({ where: { id: ing.id }, data: { avgCost: avg, lastCost: round4(l.unitCost) } });
      await this.move(tx, ing.id, 'PURCHASE', l.quantity, { unitCost: round4(l.unitCost), reference, notes: `Compra ${reference}`, by });
      touched.push(ing.id);
    }
    return this.cascade(touched, [], tx, minMargin);
  }
}
