// ============================================
// APPLICATION - Aviso de sellos nuevos para la tarjeta digital
// ============================================
// La venta o el ajuste manual avisan aquí y el servicio de sincronización los sube
// enseguida (sin esperar la vuelta de cada minuto). Sin internet quedan en la cola.

let pusher: (() => void) | null = null;

export const registerStampSync = (fn: () => void) => {
  pusher = fn;
};

export const stampSyncSoon = () => {
  try {
    pusher?.();
  } catch {
    // la cola se sube en la próxima vuelta
  }
};
