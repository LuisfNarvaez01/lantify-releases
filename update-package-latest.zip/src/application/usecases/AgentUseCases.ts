// ============================================
// APPLICATION - Agentes: lo que cada uno sabe del negocio
// ============================================
// Cada agente recibe un RESUMEN (totales por día, hora, producto, categoría),
// nunca ventas una a una ni datos personales de clientes. El resumen se arma
// aquí, en el equipo del negocio, y solo sale con el permiso del ADMIN.

import { prisma } from '../../infrastructure/database/prisma';
import { SupplierUseCases } from './SupplierUseCases';
import { CouponUseCases } from './CouponUseCases';

export type AgentId = 'backoffice' | 'purchasing' | 'marketing';
export const AGENT_IDS: AgentId[] = ['backoffice', 'purchasing', 'marketing'];

const DAY = 86_400_000;
const round = (n: number) => Math.round(n);
const pct = (a: number, b: number) => (b > 0 ? Math.round(((a - b) / b) * 1000) / 10 : null);
const dayKey = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
const WEEKDAYS = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];

const salesBetween = (from: Date, to: Date) =>
  prisma.sale.findMany({
    where: { status: 'COMPLETED', createdAt: { gte: from, lt: to } },
    select: {
      total: true, discount: true, tip: true, paymentMethod: true, channel: true, createdAt: true, couponCode: true,
      items: {
        where: { isCancelled: false },
        select: { quantity: true, total: true, productVariant: { select: { id: true, name: true, cost: true, product: { select: { name: true, category: { select: { name: true } } } } } } },
      },
    },
  });

type SaleRow = Awaited<ReturnType<typeof salesBetween>>[number];

const productName = (v: SaleRow['items'][number]['productVariant']) =>
  v.name && v.name !== 'Única' && v.name.toLowerCase() !== 'default' ? `${v.product.name} (${v.name})` : v.product.name;

/** Ventas por producto con costo y margen cuando el producto tiene costo cargado */
const byProduct = (sales: SaleRow[]) => {
  const map = new Map<string, { product: string; category: string | null; units: number; revenue: number; cost: number | null }>();
  for (const s of sales) {
    for (const i of s.items) {
      const key = i.productVariant.id;
      const row = map.get(key) || { product: productName(i.productVariant), category: i.productVariant.product.category?.name ?? null, units: 0, revenue: 0, cost: i.productVariant.cost != null ? 0 : null };
      row.units += i.quantity;
      row.revenue += i.total;
      if (row.cost !== null && i.productVariant.cost != null) row.cost += i.productVariant.cost * i.quantity;
      map.set(key, row);
    }
  }
  return [...map.values()].map((r) => ({
    ...r,
    revenue: round(r.revenue),
    cost: r.cost === null ? null : round(r.cost),
    marginPct: r.cost === null || r.revenue === 0 ? null : Math.round(((r.revenue - r.cost) / r.revenue) * 1000) / 10,
  }));
};

const totals = (sales: SaleRow[]) => {
  const revenue = sales.reduce((n, s) => n + s.total, 0);
  return { revenue: round(revenue), tickets: sales.length, avgTicket: sales.length ? round(revenue / sales.length) : 0 };
};

export class AgentUseCases {
  private suppliers = new SupplierUseCases();
  private coupons = new CouponUseCases();

  async business() {
    const s = await prisma.businessSettings.findUnique({ where: { id: 'default' } });
    return { name: s?.businessName || s?.cloudTenantName || 'el negocio', type: s?.businessType || null };
  }

  async contextFor(agent: AgentId, now = new Date()) {
    if (agent === 'backoffice') return this.backoffice(now);
    if (agent === 'purchasing') return this.purchasing(now);
    return this.marketing(now);
  }

  // ── Backoffice: ventas, costos, gastos, propinas ──────────
  private async backoffice(now: Date) {
    const from30 = new Date(now.getTime() - 30 * DAY);
    const from60 = new Date(now.getTime() - 60 * DAY);
    const [cur, prev, expenses, prevExpenses] = await Promise.all([
      salesBetween(from30, now),
      salesBetween(from60, from30),
      prisma.expense.findMany({ where: { isCancelled: false, createdAt: { gte: from30 } }, select: { amount: true, category: { select: { name: true } }, supplierName: true } }),
      prisma.expense.aggregate({ where: { isCancelled: false, createdAt: { gte: from60, lt: from30 } }, _sum: { amount: true } }),
    ]);

    const daily = new Map<string, { revenue: number; tickets: number }>();
    for (let d = 29; d >= 0; d--) daily.set(dayKey(new Date(now.getTime() - d * DAY)), { revenue: 0, tickets: 0 });
    const weekday = WEEKDAYS.map((name) => ({ day: name, revenue: 0, tickets: 0 }));
    const hours = Array.from({ length: 24 }, (_, h) => ({ hour: h, revenue: 0, tickets: 0 }));
    const methods = new Map<string, number>();
    for (const s of cur) {
      const k = dayKey(s.createdAt);
      const d = daily.get(k);
      if (d) { d.revenue += s.total; d.tickets++; }
      weekday[s.createdAt.getDay()].revenue += s.total;
      weekday[s.createdAt.getDay()].tickets++;
      hours[s.createdAt.getHours()].revenue += s.total;
      hours[s.createdAt.getHours()].tickets++;
      methods.set(s.paymentMethod, (methods.get(s.paymentMethod) || 0) + s.total);
    }

    const products = byProduct(cur).sort((a, b) => b.revenue - a.revenue);
    const categories = new Map<string, number>();
    for (const p of products) categories.set(p.category || 'Sin categoría', (categories.get(p.category || 'Sin categoría') || 0) + p.revenue);
    const knownCost = products.filter((p) => p.cost !== null);
    const costOfGoods = knownCost.reduce((n, p) => n + (p.cost || 0), 0);
    const expensesTotal = expenses.reduce((n, e) => n + e.amount, 0);
    const expByCat = new Map<string, number>();
    for (const e of expenses) expByCat.set(e.category?.name || 'Sin categoría', (expByCat.get(e.category?.name || 'Sin categoría') || 0) + e.amount);
    const t = totals(cur);
    const p = totals(prev);

    return {
      period: { from: dayKey(from30), to: dayKey(now), days: 30 },
      sales: { ...t, previous30: p, revenueChangePct: pct(t.revenue, p.revenue), ticketsChangePct: pct(t.tickets, p.tickets) },
      daily: [...daily.entries()].map(([date, v]) => ({ date: date.slice(5), revenue: round(v.revenue), tickets: v.tickets })),
      byWeekday: weekday.map((w) => ({ ...w, revenue: round(w.revenue) })),
      byHour: hours.filter((h) => h.tickets > 0).map((h) => ({ ...h, revenue: round(h.revenue) })),
      paymentMethods: [...methods.entries()].map(([method, total]) => ({ method, total: round(total) })),
      topProducts: products.slice(0, 15),
      lowestProducts: products.slice(-8).reverse(),
      categories: [...categories.entries()].map(([category, revenue]) => ({ category, revenue })).sort((a, b) => b.revenue - a.revenue),
      discounts: round(cur.reduce((n, s) => n + (s.discount || 0), 0)),
      tips: round(cur.reduce((n, s) => n + (s.tip || 0), 0)),
      costs: {
        costOfGoodsKnown: round(costOfGoods),
        productsWithCost: knownCost.length,
        productsWithoutCost: products.length - knownCost.length,
        expenses30: round(expensesTotal),
        expensesPrevious30: round(prevExpenses._sum.amount || 0),
        expensesByCategory: [...expByCat.entries()].map(([category, total]) => ({ category, total: round(total) })).sort((a, b) => b.total - a.total),
        // Utilidad aproximada: ventas − costo de lo vendido (si hay costos) − gastos registrados
        approxProfit: round(t.revenue - costOfGoods - expensesTotal),
      },
    };
  }

  // ── Compras: inventario, ritmo de venta y proveedores ─────
  private async purchasing(now: Date) {
    const from28 = new Date(now.getTime() - 28 * DAY);
    const [variants, sold, best, suppliers, purchases] = await Promise.all([
      prisma.productVariant.findMany({
        where: { trackInventory: true, isActive: true },
        select: { id: true, name: true, stock: true, cost: true, product: { select: { name: true } } },
      }),
      prisma.saleItem.groupBy({
        by: ['productVariantId'],
        where: { isCancelled: false, sale: { status: 'COMPLETED', createdAt: { gte: from28 } } },
        _sum: { quantity: true },
      }),
      this.suppliers.bestPrices(),
      prisma.supplier.findMany({ where: { isActive: true }, select: { id: true, name: true, phone: true } }),
      prisma.expense.findMany({
        where: { isCancelled: false, createdAt: { gte: new Date(now.getTime() - 30 * DAY) }, supplierName: { not: null } },
        select: { supplierName: true, amount: true, createdAt: true },
        orderBy: { createdAt: 'desc' },
        take: 30,
      }),
    ]);
    const COVER_DAYS = 7;
    const inventory = variants.map((v) => {
      const units = sold.find((s) => s.productVariantId === v.id)?._sum.quantity || 0;
      const perDay = Math.round((units / 28) * 100) / 100;
      return {
        product: v.name && v.name !== 'Única' ? `${v.product.name} (${v.name})` : v.product.name,
        stock: v.stock,
        avgDailySales: perDay,
        daysOfCover: perDay > 0 ? Math.round((v.stock / perDay) * 10) / 10 : null,
        suggestedToBuy: Math.max(0, Math.ceil(perDay * COVER_DAYS - v.stock)),
        unitCost: v.cost,
      };
    }).sort((a, b) => (a.daysOfCover ?? 999) - (b.daysOfCover ?? 999));
    return {
      coverTargetDays: COVER_DAYS,
      inventory: inventory.slice(0, 60),
      suppliers: suppliers.map((s) => ({ supplierId: s.id, name: s.name, hasWhatsApp: !!s.phone })),
      supplierPrices: best.slice(0, 80).map((b) => ({ item: b.itemName, unit: b.unit, cheapest: b.best, alternatives: b.others.slice(0, 2) })),
      recentPurchases: purchases.map((p) => ({ supplier: p.supplierName, amount: round(p.amount), date: dayKey(p.createdAt) })),
    };
  }

  // ── Marketing: tendencias, horas flojas, clientes agregados ─
  private async marketing(now: Date) {
    const from14 = new Date(now.getTime() - 14 * DAY);
    const from28 = new Date(now.getTime() - 28 * DAY);
    const [cur, prev, customerCount, newCustomers, repeat, coupons] = await Promise.all([
      salesBetween(from14, now),
      salesBetween(from28, from14),
      prisma.customer.count({ where: { isActive: true, isDefault: false } }),
      prisma.customer.count({ where: { isActive: true, isDefault: false, createdAt: { gte: new Date(now.getTime() - 30 * DAY) } } }),
      prisma.customer.count({ where: { isActive: true, isDefault: false, visitCount: { gte: 2 } } }),
      this.coupons.usageSummary(),
    ]);
    // Cumpleaños del mes: solo cuántos (nunca quiénes)
    const birthdays = (await prisma.customer.findMany({ where: { isActive: true, birthDate: { not: null } }, select: { birthDate: true } }))
      .filter((c) => c.birthDate!.getMonth() === now.getMonth()).length;

    const curP = byProduct(cur);
    const prevP = byProduct(prev);
    const trends = curP.map((p) => {
      const before = prevP.find((x) => x.product === p.product);
      return { product: p.product, units14: p.units, unitsPrev14: before?.units ?? 0, changePct: pct(p.units, before?.units ?? 0), revenue14: p.revenue, marginPct: p.marginPct };
    });
    const weekday = WEEKDAYS.map((name) => ({ day: name, tickets: 0, revenue: 0 }));
    const hours = Array.from({ length: 24 }, (_, h) => ({ hour: h, tickets: 0 }));
    const channels = new Map<string, number>();
    for (const s of [...cur, ...prev]) {
      weekday[s.createdAt.getDay()].tickets++;
      weekday[s.createdAt.getDay()].revenue += s.total;
      hours[s.createdAt.getHours()].tickets++;
      channels.set(s.channel, (channels.get(s.channel) || 0) + 1);
    }
    return {
      period: '14 días contra los 14 anteriores',
      sales: { last14: totals(cur), previous14: totals(prev) },
      rising: trends.filter((t) => (t.changePct ?? 0) > 0).sort((a, b) => (b.changePct ?? 0) - (a.changePct ?? 0)).slice(0, 8),
      falling: trends.filter((t) => (t.changePct ?? 0) < 0).sort((a, b) => (a.changePct ?? 0) - (b.changePct ?? 0)).slice(0, 8),
      slowWithGoodMargin: trends.filter((t) => (t.marginPct ?? 0) >= 50).sort((a, b) => a.units14 - b.units14).slice(0, 8),
      byWeekday: weekday.map((w) => ({ ...w, revenue: round(w.revenue) })),
      busyHours: hours.filter((h) => h.tickets > 0),
      channels: [...channels.entries()].map(([channel, tickets]) => ({ channel, tickets })),
      customers: { total: customerCount, newLast30: newCustomers, repeatCustomers: repeat, birthdaysThisMonth: birthdays },
      coupons,
    };
  }
}
