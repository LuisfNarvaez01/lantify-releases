// ============================================
// APPLICATION - Inicio de sesión y usuarios contra Lantify Cloud
// ============================================
// Cuando la instalación está vinculada a un negocio en la nube:
//  - las credenciales se validan en la nube y se recibe una licencia firmada;
//  - sin internet se puede entrar durante la ventana offline (72 h) con la última
//    licencia y la contraseña guardada como hash en este equipo;
//  - los usuarios se crean y editan en la nube; la tabla local es una caché.
// Un turno abierto nunca se interrumpe: las suspensiones aplican al siguiente ingreso.

import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import { prisma } from '../../infrastructure/database/prisma';
import { AuthError, publicUser } from './AuthUseCases';
import { signToken } from '../../shared/authMiddleware';
import { signExportToken } from '../../shared/security/exportToken';
import { cloudConfig } from '../../shared/cloud/config';
import {
  verifyLicense, deviceFingerprint, deviceName, saveLicense, removeLicense, markSuspended,
  storedLicenseFor, allStoredLicenses, readStore, touchClock, offlineLoginCheck, LicenseClaims,
} from '../../shared/cloud/license';

const SETTINGS_ID = 'default';
const DUMMY_HASH = bcrypt.hashSync('lantify-offline-guard', 10);

class CloudUnreachable extends Error {}

interface CloudResponse {
  status: number;
  body: any;
}

export interface LicenseSummary {
  linked: boolean;
  tenant: { code: string; name: string } | null;
  plan?: string;
  features?: string[];
  subStatus?: string;
  periodEnd?: string | null;
  graceUntil?: string | null;
  offlineUntil?: string;
  lastSyncAt?: string | null;
}

export class CloudAuthService {
  // ── Comunicación ──────────────────────────────────────────
  private async call(method: string, path: string, body?: unknown, bearer?: string): Promise<CloudResponse> {
    const { apiUrl, timeoutMs } = cloudConfig();
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const res = await fetch(`${apiUrl}${path}`, {
        method,
        signal: controller.signal,
        headers: { 'Content-Type': 'application/json', ...(bearer ? { Authorization: `Bearer ${bearer}` } : {}) },
        body: body === undefined ? undefined : JSON.stringify(body),
      });
      return { status: res.status, body: await res.json().catch(() => ({})) };
    } catch {
      throw new CloudUnreachable();
    } finally {
      clearTimeout(timer);
    }
  }

  /** Convierte una respuesta de error de la nube en un error con código para la interfaz */
  private fail(res: CloudResponse, extra: Record<string, unknown> = {}): never {
    const { code = 'CLOUD_ERROR', ...rest } = res.body || {};
    const details = { ...rest, ...extra };
    const status = res.status >= 500 ? 502 : res.status;
    throw new AuthError(status, code, `Lantify Cloud: ${code}`, Object.keys(details).length ? details : undefined);
  }

  private unreachable(): never {
    throw new AuthError(503, 'CLOUD_UNREACHABLE', 'No se pudo conectar con Lantify Cloud.');
  }

  // ── Vinculación del negocio ───────────────────────────────
  async linkedTenant() {
    const s = await prisma.businessSettings.findUnique({ where: { id: SETTINGS_ID } });
    return s?.cloudTenantCode ? { code: s.cloudTenantCode, name: s.cloudTenantName || s.cloudTenantCode } : null;
  }

  async status() {
    const tenant = await this.linkedTenant();
    const { licenseRequired, aiToken } = cloudConfig();
    return {
      licenseRequired,
      linked: !!tenant,
      tenant,
      // Con el negocio vinculado, el asistente usa la licencia; sin vincular, la clave local
      aiAvailable: !!tenant || !!aiToken,
    };
  }

  async activate(rawCode: string) {
    const code = String(rawCode || '').trim().toUpperCase();
    if (!/^[A-Z0-9-]{3,40}$/.test(code)) throw new AuthError(400, 'CLOUD_TENANT_NOT_FOUND', 'Código inválido');
    let res: CloudResponse;
    try {
      res = await this.call('GET', `/v1/tenants/${encodeURIComponent(code)}`);
    } catch {
      this.unreachable();
    }
    if (res.status !== 200) this.fail(res);
    await prisma.businessSettings.upsert({
      where: { id: SETTINGS_ID },
      create: { id: SETTINGS_ID, cloudTenantCode: res.body.code, cloudTenantName: res.body.name },
      update: { cloudTenantCode: res.body.code, cloudTenantName: res.body.name },
    });
    return { code: res.body.code as string, name: res.body.name as string };
  }

  // ── Inicio de sesión ──────────────────────────────────────
  async login(usernameRaw: string, password: string) {
    const tenant = await this.linkedTenant();
    if (!tenant) throw new AuthError(403, 'CLOUD_ACTIVATION_REQUIRED', 'Vincula este equipo con tu negocio en Lantify Cloud.');
    const username = String(usernameRaw || '').trim().toLowerCase();

    let res: CloudResponse;
    try {
      res = await this.call('POST', '/v1/auth/login', {
        tenantCode: tenant.code,
        username,
        password,
        device: { fingerprint: deviceFingerprint(), name: deviceName() },
      });
    } catch (e) {
      if (e instanceof CloudUnreachable) return this.offlineLogin(username, password);
      throw e;
    }
    if (res.status !== 200) {
      // Cuenta suspendida: el ADMIN igual puede sacar sus datos (ventas y facturas)
      const suspendedAdmin = res.body?.code === 'CLOUD_SUBSCRIPTION_SUSPENDED' && res.body?.role === 'ADMIN';
      if (res.body?.code === 'CLOUD_SUBSCRIPTION_SUSPENDED') markSuspended(res.body.graceUntil ?? null);
      this.fail(res, suspendedAdmin ? { exportToken: signExportToken(username) } : {});
    }

    const claims = verifyLicense(res.body.license);
    // Una nube que no firma con la clave correcta (falsa o alterada) no sirve
    if (!claims || claims.tcode !== tenant.code || claims.usr !== username) {
      throw new AuthError(502, 'CLOUD_LICENSE_INVALID', 'La licencia recibida no es válida.');
    }
    const user = await this.cacheUser(claims, password);
    saveLicense(res.body.license, claims);
    if (claims.tname && claims.tname !== tenant.name) {
      await prisma.businessSettings.update({ where: { id: SETTINGS_ID }, data: { cloudTenantName: claims.tname } });
    }
    return this.session(user, claims, false);
  }

  private async offlineLogin(username: string, password: string) {
    const user = await prisma.user.findFirst({ where: { username, cloudUserId: { not: null } } });
    const ok = await bcrypt.compare(password, user?.password || DUMMY_HASH);
    if (!user || !ok || !user.isActive) {
      throw new AuthError(401, 'AUTH_INVALID_CREDENTIALS', 'Usuario o contraseña incorrectos');
    }
    const stored = storedLicenseFor(user.cloudUserId!);
    if (!stored) throw new AuthError(503, 'CLOUD_UNREACHABLE', 'Este usuario necesita conexión para su primer ingreso en este equipo.');
    const problem = offlineLoginCheck(stored.claims, readStore());
    if (problem) {
      const suspended = problem === 'CLOUD_SUBSCRIPTION_SUSPENDED';
      const details = suspended && user.role === 'ADMIN' ? { exportToken: signExportToken(user.username) } : undefined;
      throw new AuthError(suspended ? 403 : 503, problem, 'No se puede ingresar sin conexión.', details);
    }
    touchClock();
    return this.session(user, stored.claims, true);
  }

  /** La tabla local guarda el usuario y un hash de su clave solo para el ingreso sin conexión */
  private async cacheUser(claims: LicenseClaims, password: string | null) {
    const hash = password ? await bcrypt.hash(password, 10) : undefined;
    const existing =
      (await prisma.user.findUnique({ where: { cloudUserId: claims.sub } })) ||
      (await prisma.user.findUnique({ where: { username: claims.usr } }));
    const data = {
      username: claims.usr,
      name: claims.name,
      role: claims.role,
      isActive: true,
      cloudUserId: claims.sub,
      mustChangePassword: false,
      lastLoginAt: new Date(),
      ...(hash ? { password: hash } : {}),
    };
    if (existing) return prisma.user.update({ where: { id: existing.id }, data });
    return prisma.user.create({ data: { ...data, password: hash || (await bcrypt.hash(crypto.randomBytes(24).toString('hex'), 10)) } });
  }

  private session(user: any, claims: LicenseClaims, offline: boolean) {
    const token = signToken({ userId: user.id, username: user.username, role: user.role, tv: user.tokenVersion });
    return {
      token,
      user: publicUser(user),
      offline,
      offlineUntil: new Date(claims.olu * 1000).toISOString(),
      license: this.summarize(claims),
    };
  }

  private summarize(claims: LicenseClaims) {
    return {
      plan: claims.plan,
      features: claims.features,
      subStatus: claims.subStatus,
      periodEnd: claims.periodEnd,
      graceUntil: claims.graceUntil,
    };
  }

  async licenseInfo(localUserId: string): Promise<LicenseSummary> {
    const tenant = await this.linkedTenant();
    if (!tenant) return { linked: false, tenant: null };
    const user = await prisma.user.findUnique({ where: { id: localUserId } });
    const stored = user?.cloudUserId ? storedLicenseFor(user.cloudUserId) : null;
    const store = readStore();
    if (!stored) return { linked: true, tenant, lastSyncAt: store.lastSyncAt ? new Date(store.lastSyncAt).toISOString() : null };
    return {
      linked: true,
      tenant,
      ...this.summarize(stored.claims),
      subStatus: store.suspended ? 'SUSPENDED' : stored.claims.subStatus,
      offlineUntil: new Date(stored.claims.olu * 1000).toISOString(),
      lastSyncAt: store.lastSyncAt ? new Date(store.lastSyncAt).toISOString() : null,
    };
  }

  // ── Renovación en segundo plano ──────────────────────────
  async refreshAll() {
    const results = { renewed: 0, revoked: 0, suspended: false, offline: false };
    for (const { userId, token } of allStoredLicenses()) {
      let res: CloudResponse;
      try {
        res = await this.call('POST', '/v1/license/refresh', {}, token);
      } catch {
        results.offline = true;
        break;
      }
      if (res.status === 200) {
        const claims = verifyLicense(res.body.license);
        if (!claims || claims.sub !== userId) continue;
        saveLicense(res.body.license, claims);
        await prisma.user.updateMany({ where: { cloudUserId: userId }, data: { name: claims.name, role: claims.role } });
        results.renewed++;
      } else if (res.body?.code === 'CLOUD_SUBSCRIPTION_SUSPENDED') {
        markSuspended(res.body.graceUntil ?? null);
        results.suspended = true;
      } else if (res.status === 401 || res.status === 403) {
        // Clave cambiada, usuario desactivado o equipo revocado: debe volver a entrar con conexión
        removeLicense(userId);
        await prisma.user.updateMany({
          where: { cloudUserId: userId },
          data: { tokenVersion: { increment: 1 }, ...(res.body?.code === 'CLOUD_USER_DISABLED' ? { isActive: false } : {}) },
        });
        results.revoked++;
      }
    }
    if (!results.offline) touchClock();
    return results;
  }

  // ── Usuarios (administrados en la nube) ──────────────────
  private async adminLicense(actorLocalId?: string) {
    const actor = actorLocalId ? await prisma.user.findUnique({ where: { id: actorLocalId } }) : null;
    const stored = actor?.cloudUserId ? storedLicenseFor(actor.cloudUserId) : null;
    if (!stored) throw new AuthError(401, 'CLOUD_LICENSE_REQUIRED', 'Vuelve a iniciar sesión con conexión.');
    return stored.token;
  }

  private async cloudUsersCall(method: string, path: string, actorLocalId: string | undefined, body?: unknown) {
    const token = await this.adminLicense(actorLocalId);
    let res: CloudResponse;
    try {
      res = await this.call(method, path, body, token);
    } catch {
      this.unreachable();
    }
    if (res.status >= 300) this.fail(res);
    return res.body;
  }

  /** Copia en la caché local los usuarios de la nube (sin claves: se guardan al primer ingreso) */
  private async syncUsers(remote: { id: string; username: string; name: string; role: string; isActive: boolean }[]) {
    for (const u of remote) {
      const existing =
        (await prisma.user.findUnique({ where: { cloudUserId: u.id } })) ||
        (await prisma.user.findUnique({ where: { username: u.username } }));
      const data = { username: u.username, name: u.name, role: u.role as any, isActive: u.isActive, cloudUserId: u.id };
      if (existing) {
        const revoke = existing.isActive && !u.isActive;
        await prisma.user.update({ where: { id: existing.id }, data: { ...data, ...(revoke ? { tokenVersion: { increment: 1 } } : {}) } });
      } else {
        await prisma.user.create({ data: { ...data, password: await bcrypt.hash(crypto.randomBytes(24).toString('hex'), 10) } });
      }
    }
  }

  async listUsers(actorLocalId?: string) {
    const remote = await this.cloudUsersCall('GET', '/v1/users', actorLocalId);
    await this.syncUsers(remote);
    const local = await prisma.user.findMany({ where: { cloudUserId: { in: remote.map((u: any) => u.id) } } });
    return local;
  }

  async createUser(actorLocalId: string | undefined, data: { username: string; password: string; name: string; role: string }) {
    const created = await this.cloudUsersCall('POST', '/v1/users', actorLocalId, data);
    await this.syncUsers([created]);
    return publicUser((await prisma.user.findUnique({ where: { cloudUserId: created.id } }))!);
  }

  async updateUser(actorLocalId: string | undefined, localId: string, data: { name?: string; role?: string; password?: string; isActive?: boolean }) {
    const target = await prisma.user.findUnique({ where: { id: localId } });
    if (!target?.cloudUserId) throw new AuthError(404, 'AUTH_USER_NOT_FOUND', 'Usuario no encontrado');
    const updated = await this.cloudUsersCall('PATCH', `/v1/users/${target.cloudUserId}`, actorLocalId, data);
    await this.syncUsers([updated]);
    if (data.password) {
      // Las sesiones abiertas de ese usuario en este equipo se cierran
      await prisma.user.update({ where: { id: localId }, data: { tokenVersion: { increment: 1 } } });
      removeLicense(target.cloudUserId);
    }
    return publicUser((await prisma.user.findUnique({ where: { id: localId } }))!);
  }

  async changeOwnPassword(localUserId: string, currentPassword: string, newPassword: string) {
    const user = await prisma.user.findUnique({ where: { id: localUserId } });
    const stored = user?.cloudUserId ? storedLicenseFor(user.cloudUserId) : null;
    if (!user || !stored) throw new AuthError(401, 'CLOUD_LICENSE_REQUIRED', 'Vuelve a iniciar sesión con conexión.');
    let res: CloudResponse;
    try {
      res = await this.call('POST', '/v1/me/password', { currentPassword, newPassword }, stored.token);
    } catch {
      this.unreachable();
    }
    if (res.status !== 200) this.fail(res);
    // Se entra de nuevo con la clave nueva para recibir la licencia actualizada
    return this.login(user.username, newPassword);
  }

  /** Licencia firmada del usuario (lo que piden las funciones de IA con datos del negocio) */
  async aiLicense(localUserId: string) {
    if (!(await this.linkedTenant())) return null;
    const user = await prisma.user.findUnique({ where: { id: localUserId } });
    return user?.cloudUserId ? storedLicenseFor(user.cloudUserId)?.token || null : null;
  }

  /** Credencial para el asistente: la licencia del usuario (o la clave local si no hay negocio vinculado) */
  async aiCredential(localUserId: string) {
    const tenant = await this.linkedTenant();
    if (!tenant) return cloudConfig().aiToken || null;
    const user = await prisma.user.findUnique({ where: { id: localUserId } });
    return user?.cloudUserId ? storedLicenseFor(user.cloudUserId)?.token || null : null;
  }
}
