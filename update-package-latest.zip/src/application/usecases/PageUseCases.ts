// ============================================
// APPLICATION - Mi página (la página pública del negocio)
// ============================================
// El ADMIN decide qué muestra la página (carta, reservas, registro, juego), su
// perfil, el juego con sus premios y quién responde por los datos personales.
// La carta sale sola de los productos activos: al cambiar un precio, la página se
// actualiza en la siguiente sincronización (ReservationSyncService).

import { prisma } from '../../infrastructure/database/prisma';
import { AuditLogger } from '../../infrastructure/services/AuditLogger';
import { MenuCategory, PageConfig, normalizePageConfig } from '../../domain/businessPage';
import { normalizeBooking } from '../../domain/booking';
import { BookingError, slugify } from './ReservationUseCases';
import { isImageRef } from '../../domain/media';

const SETTINGS_ID = 'default';
export const PUBLIC_PAGE_BASE = 'https://lantifypos.dpdns.org/m/';

const parse = (raw: string | null | undefined) => {
  try {
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
};

export class PageUseCases {
  async config() {
    const row = await prisma.businessSettings.findUnique({ where: { id: SETTINGS_ID } });
    const page = normalizePageConfig(parse(row?.pageSettings));
    const booking = normalizeBooking(parse(row?.bookingSettings));
    // "Reservar" lo decide un solo interruptor: Reservas → Configurar → en línea
    page.sections.booking = booking.enabled && booking.online;
    const slug = row?.bookingSlug || null;
    const [menu, stats] = await Promise.all([this.menu(page.hiddenProductIds), this.stats()]);

    const allProducts = await prisma.product.findMany({
      where: { isActive: true },
      include: { category: true, variants: { where: { isActive: true } } },
      orderBy: [{ name: 'asc' }],
    });
    const hiddenSet = new Set(page.hiddenProductIds || []);
    const catalog = allProducts.map((p) => ({
      id: p.id,
      name: p.name,
      categoryName: p.category?.name || 'General',
      price: p.variants[0]?.price || 0,
      visible: !hiddenSet.has(p.id),
      imageUrl: p.imageUrl || null,
    }));

    return {
      ...page,
      slug,
      suggestedSlug: slug || slugify(row?.businessName || row?.cloudTenantName || '') || 'mi-restaurante',
      url: slug ? `${PUBLIC_PAGE_BASE}${slug}` : null,
      publishedAt: row?.bookingPublishedAt ?? null,
      syncAt: row?.bookingSyncAt ?? null,
      linked: !!row?.cloudTenantCode,
      menuSummary: { categories: menu.length, items: menu.reduce((n, c) => n + c.items.length, 0) },
      catalog,
      // Para que la IA recomiende el diseño: solo nombres (nunca precios de costo ni clientes)
      business: { name: row?.businessName || row?.cloudTenantName || '', type: row?.businessType || 'RESTAURANT', city: row?.city || null },
      menuNames: { categories: menu.map((c) => c.name).slice(0, 15), items: menu.flatMap((c) => c.items.map((i) => i.name)).slice(0, 30) },
      stats,
    };
  }

  async save(input: Partial<PageConfig> & { slug?: unknown }, actor: string) {
    const config = normalizePageConfig(input);
    const slug = typeof input.slug === 'string' ? slugify(input.slug) : undefined;
    if (slug !== undefined && slug.length < 3) throw new BookingError(400, 'BOOKING_BAD_SLUG', 'La dirección debe tener al menos 3 letras.');
    if ((config.sections.signup || config.sections.games || config.sections.orders) && !config.legal.owner) {
      throw new BookingError(400, 'PAGE_LEGAL_REQUIRED', 'Para registrar clientes escribe quién responde por sus datos (razón social).');
    }
    const { booking: _derived, ...sections } = config.sections;
    const stored = { ...config, sections: { ...sections, booking: false } };
    await prisma.businessSettings.upsert({
      where: { id: SETTINGS_ID },
      create: { id: SETTINGS_ID, pageSettings: JSON.stringify(stored), ...(slug ? { bookingSlug: slug } : {}) },
      update: { pageSettings: JSON.stringify(stored), ...(slug ? { bookingSlug: slug } : {}) },
    });
    AuditLogger.log({ action: 'PAGE_SETTINGS_UPDATED', entityType: 'SETTINGS', entityId: SETTINGS_ID, details: { by: actor, sections: config.sections, prizes: config.games.prizes.length } });
    return this.config();
  }

  /**
   * La carta: productos activos con sus presentaciones activas (nunca costos ni
   * inventario). Cada línea lleva su presentación (para pedir en línea), la foto
   * (del equipo o https) y si está entre lo más pedido de los últimos 60 días.
   */
  async menu(explicitHidden?: string[]): Promise<MenuCategory[]> {
    let hidden = explicitHidden;
    if (!hidden) {
      const row = await prisma.businessSettings.findUnique({ where: { id: SETTINGS_ID } });
      const page = normalizePageConfig(parse(row?.pageSettings));
      hidden = page.hiddenProductIds || [];
    }
    const hiddenSet = new Set(hidden);

    const products = await prisma.product.findMany({
      where: { isActive: true },
      include: { category: true, variants: { where: { isActive: true }, orderBy: { price: 'asc' } } },
      orderBy: { name: 'asc' },
    });
    const since = new Date(Date.now() - 60 * 86400000);
    const best = await prisma.saleItem.groupBy({
      by: ['productVariantId'],
      where: { isCancelled: false, sale: { status: 'COMPLETED', createdAt: { gte: since } } },
      _sum: { quantity: true },
      orderBy: { _sum: { quantity: 'desc' } },
      take: 6,
    }).catch(() => [] as { productVariantId: string }[]);
    const top = new Set(best.map((b) => b.productVariantId));
    const byCategory = new Map<string, MenuCategory>();
    for (const p of products) {
      if (!p.variants.length) continue;
      if (hiddenSet.has(p.id)) continue;
      const key = p.category?.name || 'Carta';
      const cat = byCategory.get(key) || { name: key, items: [] };
      const single = p.variants.length === 1;
      for (const v of p.variants) {
        if (!(v.price > 0) || hiddenSet.has(v.id)) continue;
        const generic = single || /^(única|unica|default|normal|estándar|estandar)$/i.test(v.name.trim());
        // Subida al equipo o https: al publicar, las del equipo pasan a la nube (CloudImages)
        const image = isImageRef(p.imageUrl) ? p.imageUrl : null;
        cat.items.push({
          id: v.id, name: generic ? p.name : `${p.name} · ${v.name}`, price: Math.round(v.price), description: p.description || null,
          ...(image ? { image } : {}), ...(top.has(v.id) ? { top: true } : {}),
        });
      }
      if (cat.items.length) byCategory.set(key, cat);
    }
    return [...byCategory.values()];
  }

  async stats() {
    const [members, marketing, awarded, redeemed] = await Promise.all([
      prisma.customer.count({ where: { cloudId: { not: null }, isActive: true } }),
      prisma.customer.count({ where: { cloudId: { not: null }, isActive: true, marketingOptIn: true } }),
      prisma.coupon.count({ where: { source: 'GAME' } }),
      prisma.coupon.count({ where: { source: 'GAME', uses: { gt: 0 } } }),
    ]);
    return { members, marketing, prizesAwarded: awarded, prizesRedeemed: redeemed };
  }

  /** Últimos registros y premios de la página (para el panel) */
  async activity() {
    const [members, prizes] = await Promise.all([
      prisma.customer.findMany({
        where: { cloudId: { not: null }, isActive: true },
        orderBy: { createdAt: 'desc' },
        take: 8,
        select: { id: true, name: true, phone: true, createdAt: true, marketingOptIn: true },
      }),
      prisma.coupon.findMany({ where: { source: 'GAME' }, orderBy: { createdAt: 'desc' }, take: 8 }),
    ]);
    const owners = await prisma.customer.findMany({ where: { id: { in: prizes.map((p) => p.customerId).filter((x): x is string => !!x) } }, select: { id: true, name: true } });
    return {
      members,
      prizes: prizes.map((p) => ({
        code: p.code,
        description: p.description,
        redeemed: p.uses > 0,
        endsAt: p.endsAt,
        createdAt: p.createdAt,
        customer: owners.find((o) => o.id === p.customerId)?.name ?? null,
      })),
    };
  }

  /**
   * Cumpleaños de hoy y los próximos días (incluye los de enero cuando el año
   * cambia en medio), con lo que más pide cada uno para recomendarlo en el saludo.
   */
  async birthdays(days = 7, now = new Date()) {
    const customers = await prisma.customer.findMany({ where: { isActive: true, isDefault: false, birthDate: { not: null } } });
    const start = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const upcoming = customers
      .map((c) => {
        const bd = c.birthDate!;
        let next = new Date(start.getFullYear(), bd.getUTCMonth(), bd.getUTCDate());
        if (next < start) next = new Date(start.getFullYear() + 1, bd.getUTCMonth(), bd.getUTCDate());
        return { c, inDays: Math.round((next.getTime() - start.getTime()) / 86400000) };
      })
      .filter((x) => x.inDays <= days)
      .sort((a, b) => a.inDays - b.inDays);

    const out = [];
    for (const { c, inDays } of upcoming) {
      const top = await prisma.saleItem.groupBy({
        by: ['productVariantId'],
        where: { isCancelled: false, sale: { customerId: c.id, status: 'COMPLETED' } },
        _sum: { quantity: true },
        orderBy: { _sum: { quantity: 'desc' } },
        take: 1,
      });
      const variant = top[0] ? await prisma.productVariant.findUnique({ where: { id: top[0].productVariantId }, include: { product: true } }) : null;
      out.push({
        id: c.id,
        name: c.name,
        phone: c.phone,
        marketingOptIn: c.marketingOptIn,
        inDays,
        day: c.birthDate!.getUTCDate(),
        month: c.birthDate!.getUTCMonth() + 1,
        favorite: variant ? variant.product.name : null,
      });
    }
    return out;
  }
}

/** Cumpleaños sin año (registro en la página): se guarda en 1904, bisiesto, para aceptar el 29 de febrero */
export const birthDateFrom = (day: unknown, month: unknown) => {
  const d = Math.round(Number(day));
  const m = Math.round(Number(month));
  if (!Number.isInteger(d) || !Number.isInteger(m) || m < 1 || m > 12 || d < 1 || d > 31) return null;
  const date = new Date(Date.UTC(1904, m - 1, d, 12));
  return date.getUTCMonth() === m - 1 ? date : null;
};
