// ============================================
// APPLICATION - Registro de propinas
// ============================================
// La propina se cobra aparte del total de la venta y es del equipo, no del
// negocio: por eso se reporta por turno de caja (cuánto apartar del cajón),
// por mes, por mesero y en total.

import { prisma } from '../../infrastructure/database/prisma';

const monthKey = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;

/** Solo la propina pagada en efectivo queda físicamente en el cajón */
const isCash = (paymentMethod: string) => paymentMethod === 'CASH';

interface TipSale {
  id: string;
  saleNumber: string;
  createdAt: Date;
  tip: number;
  total: number;
  paymentMethod: string;
  waiterName: string | null;
  cashierName: string | null;
  cashSessionId: string | null;
  table: { number: string } | null;
}

const summarize = (sales: TipSale[]) => {
  const withTip = sales.filter((s) => s.tip > 0);
  const total = withTip.reduce((n, s) => n + s.tip, 0);
  const base = withTip.reduce((n, s) => n + s.total, 0);
  return {
    total,
    count: withTip.length,
    cash: withTip.filter((s) => isCash(s.paymentMethod)).reduce((n, s) => n + s.tip, 0),
    salesCount: sales.length,
    // Qué tanto dejan los clientes que sí dan propina, y en qué parte de las ventas hubo propina
    avgPercent: base > 0 ? Math.round((total / base) * 1000) / 10 : 0,
    tipRate: sales.length ? Math.round((withTip.length / sales.length) * 1000) / 10 : 0,
  };
};

const byWaiter = (sales: TipSale[]) => {
  const map = new Map<string, { name: string; total: number; count: number }>();
  for (const s of sales) {
    if (s.tip <= 0) continue;
    const name = s.waiterName || s.cashierName || 'Sin asignar';
    const row = map.get(name) || { name, total: 0, count: 0 };
    row.total += s.tip;
    row.count++;
    map.set(name, row);
  }
  return [...map.values()].sort((a, b) => b.total - a.total);
};

const SELECT = {
  id: true, saleNumber: true, createdAt: true, tip: true, total: true, paymentMethod: true,
  waiterName: true, cashierName: true, cashSessionId: true, table: { select: { number: true } },
} as const;

export class TipsUseCases {
  /** Reporte completo para el administrador (rango opcional; por defecto, todo) */
  async report(range: { from?: Date; to?: Date } = {}) {
    const where = {
      status: 'COMPLETED' as const,
      ...(range.from || range.to ? { createdAt: { ...(range.from ? { gte: range.from } : {}), ...(range.to ? { lte: range.to } : {}) } } : {}),
    };
    const [sales, settings, allTime] = await Promise.all([
      prisma.sale.findMany({ where, select: SELECT, orderBy: { createdAt: 'desc' } }) as Promise<TipSale[]>,
      prisma.businessSettings.findUnique({ where: { id: 'default' }, select: { tipEnabled: true, tipPercent: true } }),
      prisma.sale.aggregate({ where: { status: 'COMPLETED', tip: { gt: 0 } }, _sum: { tip: true }, _count: true }),
    ]);

    // Por mes
    const months = new Map<string, TipSale[]>();
    for (const s of sales) {
      const k = monthKey(s.createdAt);
      months.set(k, [...(months.get(k) || []), s]);
    }
    const byMonth = [...months.entries()]
      .sort(([a], [b]) => b.localeCompare(a))
      .map(([month, list]) => ({ month, ...summarize(list) }));

    // Por turno de caja (arqueo)
    const sessionIds = [...new Set(sales.map((s) => s.cashSessionId).filter((id): id is string => !!id))];
    const sessions = await prisma.cashSession.findMany({
      where: { id: { in: sessionIds } },
      select: { id: true, sessionNumber: true, openedAt: true, closedAt: true, status: true },
      orderBy: { openedAt: 'desc' },
    });
    const bySession = sessions.map((sess) => {
      const list = sales.filter((s) => s.cashSessionId === sess.id);
      return { ...sess, ...summarize(list), byWaiter: byWaiter(list) };
    });

    return {
      enabled: !!settings?.tipEnabled,
      tipPercent: settings?.tipPercent ?? 0,
      summary: summarize(sales),
      allTime: { total: allTime._sum.tip ?? 0, count: allTime._count },
      byMonth,
      bySession,
      byWaiter: byWaiter(sales),
      recent: sales.filter((s) => s.tip > 0).slice(0, 150).map((s) => ({
        id: s.id,
        saleNumber: s.saleNumber,
        createdAt: s.createdAt,
        tip: s.tip,
        total: s.total,
        paymentMethod: s.paymentMethod,
        cash: isCash(s.paymentMethod),
        waiterName: s.waiterName,
        cashierName: s.cashierName,
        table: s.table?.number ?? null,
      })),
    };
  }

  /** Propinas de un turno: lo que se muestra en el arqueo (cuánto apartar para el equipo) */
  async forSession(cashSessionId: string) {
    const sales = (await prisma.sale.findMany({ where: { cashSessionId, status: 'COMPLETED' }, select: SELECT })) as TipSale[];
    return { ...summarize(sales), byWaiter: byWaiter(sales) };
  }
}
