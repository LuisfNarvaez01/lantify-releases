// ============================================
// APPLICATION - Product Import Use Cases
// ============================================

import { ProductRepository } from '../../infrastructure/persistence/repositories/ProductRepository';
import fs from 'fs';
import { isImageRef } from '../../domain/media';

interface CSVProduct {
  name: string;
  description?: string;
  category?: string;
  variantName: string;
  sku: string;
  price: number;
  cost?: number;
  stock: number;
}

export class ProductImportUseCases {
  constructor(private productRepository: ProductRepository) {}

  async importFromCSV(filePath: string) {
    let content = fs.readFileSync(filePath, 'utf-8');

    // Quitar BOM si existe
    if (content.charCodeAt(0) === 0xFEFF) {
      content = content.slice(1);
    }

    const lines = content.split(/\r?\n/).filter(line => line.trim());

    if (lines.length < 2) {
      throw new Error('El archivo CSV está vacío o no tiene datos');
    }

    // Detectar separador (, o ;)
    const firstLine = lines[0];
    const commaCount = (firstLine.match(/,/g) || []).length;
    const semicolonCount = (firstLine.match(/;/g) || []).length;
    const separator = semicolonCount > commaCount ? ';' : ',';

    const rawHeaders = this.parseCSVLine(lines[0], separator).map(h => h.trim().toLowerCase());

    // Mapeo de cabeceras (Inglés y Español)
    const headerMap: Record<string, string> = {
      'nombre': 'name', 'name': 'name',
      'descripción': 'description', 'descripcion': 'description', 'description': 'description',
      'categoría': 'category', 'categoria': 'category', 'category': 'category',
      'variante': 'variantname', 'variant': 'variantname', 'variantname': 'variantname',
      'sku': 'sku', 'código': 'sku', 'codigo': 'sku',
      'precio': 'price', 'price': 'price',
      'costo': 'cost', 'cost': 'cost',
      'stock': 'stock', 'inventario': 'stock',
      'imagen': 'image', 'foto': 'image', 'image': 'image', 'imageurl': 'image', 'photo': 'image'
    };

    const headers = rawHeaders.map(h => headerMap[h] || h);
    const results = { success: 0, created: 0, updated: 0, errors: [] as string[], products: [] as { name: string; variants: string[] }[] };
    const touched = new Map<string, { name: string; variants: string[] }>();
    const note = (productId: string, name: string, variant: string) => {
      const entry = touched.get(productId) || { name, variants: [] };
      if (!entry.variants.includes(variant)) entry.variants.push(variant);
      touched.set(productId, entry);
    };

    // Obtener categorías existentes
    const categories = await this.productRepository.getAllCategories();
    const categoryMap = new Map(categories.map(c => [c.name.toLowerCase(), c.id]));

    for (let i = 1; i < lines.length; i++) {
      try {
        const values = this.parseCSVLine(lines[i], separator);
        const data: any = {};

        headers.forEach((header, index) => {
          const value = values[index]?.trim();
          if (value !== undefined) data[header] = value;
        });

        if (!data.name || !data.sku || !data.price) {
          results.errors.push(`Fila ${i + 1}: Faltan datos requeridos (Nombre, SKU o Precio)`);
          continue;
        }

        // Normalizar números (manejar coma como decimal)
        const normalizeNumber = (val: string) => {
          if (!val) return 0;
          return parseFloat(val.replace(',', '.'));
        };

        const price = normalizeNumber(data.price);
        const cost = data.cost ? normalizeNumber(data.cost) : null;
        const stock = parseInt(data.stock) || 0;
        // Foto opcional: una dirección https (las fotos del equipo se suben desde Productos)
        const image = data.image && isImageRef(data.image) ? data.image : null;
        if (data.image && !image) results.errors.push(`Fila ${i + 1}: la foto debe ser una dirección https (se importó sin foto)`);

        // Buscar o crear categoría
        let categoryId = null;
        if (data.category) {
          const catName = data.category.toLowerCase();
          if (categoryMap.has(catName)) {
            categoryId = categoryMap.get(catName);
          } else {
            const newCat = await this.productRepository.createCategory({
              name: data.category,
              description: null,
              isActive: true
            });
            categoryId = newCat.id;
            categoryMap.set(catName, categoryId);
          }
        }

        // 1. Verificar si el SKU ya existe (para actualización)
        const existingVariant = await this.productRepository.getVariantBySku(data.sku);

        if (existingVariant) {
          // Actualizar variante existente
          await this.productRepository.updateVariant(existingVariant.id, {
            name: data.variantname || existingVariant.name,
            price: price,
            cost: cost,
            stock: stock,
            isActive: true
          });

          // ¡IMPORTANTE!: Reactivar el producto padre si estaba inactivo
          await this.productRepository.update(existingVariant.productId, {
            isActive: true,
            ...(image ? { imageUrl: image } : {}),
          });

          results.success++;
          results.updated++;
          note(existingVariant.productId, data.name, data.variantname || existingVariant.name);
          continue;
        }

        // 2. Si el SKU no existe, ver si el producto existe por nombre para añadirle la variante
        // Se buscan TODOS incluyendo los inactivos
        const allProducts = await this.productRepository.getAll(true);
        const existingProduct = allProducts.find(p =>
          p.name.toLowerCase() === data.name.toLowerCase() &&
          (p.categoryId === categoryId || (!p.categoryId && !categoryId))
        );

        let productId: string;
        if (existingProduct) {
          productId = existingProduct.id;
          // Si el producto estaba inactivo, lo reactivamos
          if (!existingProduct.isActive || (image && !existingProduct.imageUrl)) {
            await this.productRepository.update(productId, { isActive: true, ...(image && !existingProduct.imageUrl ? { imageUrl: image } : {}) });
          }
        } else {
          // Crear nuevo producto
          const product = await this.productRepository.create({
            name: data.name,
            description: data.description || null,
            categoryId: categoryId ?? null,
            imageUrl: image,
            isActive: true
          });
          productId = product.id;
        }

        // Crear variante
        await this.productRepository.createVariant({
          productId: productId,
          name: data.variantname || 'Normal',
          sku: data.sku,
          price: price,
          cost: cost,
          stock: stock,
          trackInventory: false,
          isActive: true
        });

        results.success++;
        results.created++;
        note(productId, data.name, data.variantname || 'Normal');
      } catch (error: any) {
        results.errors.push(`Fila ${i + 1}: ${error.message}`);
      }
    }

    results.products = [...touched.values()];
    return results;
  }

  private parseCSVLine(line: string, separator: string = ','): string[] {
    const result: string[] = [];
    let current = '';
    let inQuotes = false;

    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      if (char === '"') {
        if (inQuotes && line[i+1] === '"') {
          // Escaped quote
          current += '"';
          i++;
        } else {
          inQuotes = !inQuotes;
        }
      } else if (char === separator && !inQuotes) {
        result.push(current);
        current = '';
      } else {
        current += char;
      }
    }
    result.push(current);

    return result;
  }

  getCSVTemplate() {
    // Mismo nombre en varias filas = un producto con varias presentaciones (variantes)
    return [
      'Nombre,Descripción,Categoría,Variante,SKU,Precio,Costo,Stock,Imagen',
      'Hamburguesa Clásica,Carne 150 g y queso,Comidas,Sencilla,HAM001,18000,8000,100,',
      'Hamburguesa Clásica,Carne 150 g y queso,Comidas,Doble,HAM002,24000,11000,100,',
      'Capuchino,,Bebidas calientes,12 oz,CAP012,7500,2500,0,',
      'Capuchino,,Bebidas calientes,16 oz,CAP016,9000,3000,0,',
    ].join('\n');
  }
}
