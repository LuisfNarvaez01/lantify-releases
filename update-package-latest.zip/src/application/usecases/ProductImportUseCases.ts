// ============================================
// APPLICATION - Product Import Use Cases
// ============================================

import { ProductRepository } from '../../infrastructure/persistence/repositories/ProductRepository';
import fs from 'fs';
import path from 'path';

interface CSVProduct {
  name: string;
  description?: string;
  category?: string;
  variantName: string;
  sku: string;
  price: number;
  cost?: number;
  stock: number;
}

export class ProductImportUseCases {
  constructor(private productRepository: ProductRepository) {}

  async importFromCSV(filePath: string) {
    let content = fs.readFileSync(filePath, 'utf-8');
    
    // Quitar BOM si existe
    if (content.charCodeAt(0) === 0xFEFF) {
      content = content.slice(1);
    }

    const lines = content.split(/\r?\n/).filter(line => line.trim());
    
    if (lines.length < 2) {
      throw new Error('El archivo CSV está vacío o no tiene datos');
    }

    // Detectar separador (, o ;)
    const firstLine = lines[0];
    const commaCount = (firstLine.match(/,/g) || []).length;
    const semicolonCount = (firstLine.match(/;/g) || []).length;
    const separator = semicolonCount > commaCount ? ';' : ',';

    const rawHeaders = this.parseCSVLine(lines[0], separator).map(h => h.trim().toLowerCase());
    
    // Mapeo de cabeceras (Inglés y Español)
    const headerMap: Record<string, string> = {
      'nombre': 'name', 'name': 'name',
      'descripción': 'description', 'descripcion': 'description', 'description': 'description',
      'categoría': 'category', 'categoria': 'category', 'category': 'category',
      'variante': 'variantname', 'variant': 'variantname', 'variantname': 'variantname',
      'sku': 'sku', 'código': 'sku', 'codigo': 'sku',
      'precio': 'price', 'price': 'price',
      'costo': 'cost', 'cost': 'cost',
      'stock': 'stock', 'inventario': 'stock'
    };

    const headers = rawHeaders.map(h => headerMap[h] || h);
    const results = { success: 0, errors: [] as string[] };

    // Obtener categorías existentes
    const categories = await this.productRepository.getAllCategories();
    const categoryMap = new Map(categories.map(c => [c.name.toLowerCase(), c.id]));

    for (let i = 1; i < lines.length; i++) {
      try {
        const values = this.parseCSVLine(lines[i], separator);
        const data: any = {};
        
        headers.forEach((header, index) => {
          const value = values[index]?.trim();
          if (value !== undefined) data[header] = value;
        });

        if (!data.name || !data.sku || !data.price) {
          results.errors.push(`Fila ${i + 1}: Faltan datos requeridos (Nombre, SKU o Precio)`);
          continue;
        }

        // Normalizar números (manejar coma como decimal)
        const normalizeNumber = (val: string) => {
          if (!val) return 0;
          return parseFloat(val.replace(',', '.'));
        };

        const price = normalizeNumber(data.price);
        const cost = data.cost ? normalizeNumber(data.cost) : null;
        const stock = parseInt(data.stock) || 0;

        // Buscar o crear categoría
        let categoryId = null;
        if (data.category) {
          const catName = data.category.toLowerCase();
          if (categoryMap.has(catName)) {
            categoryId = categoryMap.get(catName);
          } else {
            const newCat = await this.productRepository.createCategory({
              name: data.category,
              description: null,
              isActive: true
            });
            categoryId = newCat.id;
            categoryMap.set(catName, categoryId);
          }
        }

        // 1. Verificar si el SKU ya existe (para actualización)
        const existingVariant = await this.productRepository.getVariantBySku(data.sku);
        
        if (existingVariant) {
          // Actualizar variante existente
          await this.productRepository.updateVariant(existingVariant.id, {
            name: data.variantname || existingVariant.name,
            price: price,
            cost: cost,
            stock: stock,
            isActive: true
          });
          
          // ¡IMPORTANTE!: Reactivar el producto padre si estaba inactivo
          await this.productRepository.update(existingVariant.productId, {
            isActive: true
          });
          
          results.success++;
          continue;
        }

        // 2. Si el SKU no existe, ver si el producto existe por nombre para añadirle la variante
        // Se buscan TODOS incluyendo los inactivos
        const allProducts = await this.productRepository.getAll(true);
        const existingProduct = allProducts.find(p => 
          p.name.toLowerCase() === data.name.toLowerCase() && 
          (p.categoryId === categoryId || (!p.categoryId && !categoryId))
        );

        let productId: string;
        if (existingProduct) {
          productId = existingProduct.id;
          // Si el producto estaba inactivo, lo reactivamos
          if (!existingProduct.isActive) {
            await this.productRepository.update(productId, { isActive: true });
          }
        } else {
          // Crear nuevo producto
          const product = await this.productRepository.create({
            name: data.name,
            description: data.description || null,
            categoryId: categoryId ?? null,
            imageUrl: null,
            isActive: true
          });
          productId = product.id;
        }

        // Crear variante
        await this.productRepository.createVariant({
          productId: productId,
          name: data.variantname || 'Normal',
          sku: data.sku,
          price: price,
          cost: cost,
          stock: stock,
          trackInventory: false,
          isActive: true
        });

        results.success++;
      } catch (error: any) {
        results.errors.push(`Fila ${i + 1}: ${error.message}`);
      }
    }

    return results;
  }

  private parseCSVLine(line: string, separator: string = ','): string[] {
    const result: string[] = [];
    let current = '';
    let inQuotes = false;
    
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      if (char === '"') {
        if (inQuotes && line[i+1] === '"') {
          // Escaped quote
          current += '"';
          i++;
        } else {
          inQuotes = !inQuotes;
        }
      } else if (char === separator && !inQuotes) {
        result.push(current);
        current = '';
      } else {
        current += char;
      }
    }
    result.push(current);
    
    return result;
  }

  getCSVTemplate() {
    return 'Nombre,Descripción,Categoría,Variante,SKU,Precio,Costo,Stock\nHamburguesa Clásica,Descripción de ejemplo,Comidas,Normal,HAM001,10.00,5.00,100\nHamburguesa Clásica,Descripción de ejemplo,Comidas,Grande,HAM002,12.00,6.00,100';
  }
}
