// ============================================
// APPLICATION - Proveedores y listas de precios
// ============================================
// Base del agente de compras: a quién se le compra cada cosa y a qué precio.
// Los precios se escriben a mano o salen solos de las facturas leídas con IA.

import { prisma } from '../../infrastructure/database/prisma';

export class SupplierError extends Error {
  constructor(public status: number, public code: string, message: string) {
    super(message);
    this.name = SupplierError.name;
  }
}

export interface SupplierInput {
  name?: string;
  nit?: string | null;
  phone?: string | null;
  email?: string | null;
  contactName?: string | null;
  notes?: string | null;
  isActive?: boolean;
}

export interface PriceInput {
  itemName: string;
  unit?: string | null;
  price: number;
  productVariantId?: string | null;
}

const clean = (v: unknown, max: number) => (typeof v === 'string' && v.trim() ? v.trim().slice(0, max) : null);
const nitDigits = (v: string | null | undefined) => (v || '').replace(/\D/g, '').slice(0, 10);
/** Para comparar nombres de productos de distintas facturas */
export const normalizeItem = (s: string) =>
  s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();

export class SupplierUseCases {
  async list() {
    const suppliers = await prisma.supplier.findMany({
      orderBy: [{ isActive: 'desc' }, { name: 'asc' }],
      include: { prices: { orderBy: { itemName: 'asc' } } },
    });
    return suppliers;
  }

  private parse(input: SupplierInput, partial = false) {
    const data: Record<string, unknown> = {};
    if (!partial || input.name !== undefined) {
      const name = clean(input.name, 120);
      if (!name) throw new SupplierError(400, 'SUPPLIER_NAME_REQUIRED', 'Escribe el nombre del proveedor.');
      data.name = name;
    }
    for (const [k, max] of [['nit', 20], ['email', 120], ['contactName', 120], ['notes', 500]] as const) {
      if (!partial || input[k] !== undefined) data[k] = clean(input[k], max);
    }
    if (!partial || input.phone !== undefined) {
      const phone = typeof input.phone === 'string' ? input.phone.replace(/[^\d+]/g, '').slice(0, 16) : '';
      data.phone = phone || null;
    }
    if (input.isActive !== undefined) data.isActive = !!input.isActive;
    return data;
  }

  async create(input: SupplierInput) {
    return prisma.supplier.create({ data: this.parse(input) as any, include: { prices: true } });
  }

  async update(id: string, input: SupplierInput) {
    if (!(await prisma.supplier.findUnique({ where: { id } }))) throw new SupplierError(404, 'SUPPLIER_NOT_FOUND', 'Proveedor no encontrado.');
    return prisma.supplier.update({ where: { id }, data: this.parse(input, true), include: { prices: true } });
  }

  /** Agrega o actualiza precios de la lista (por nombre del producto) */
  async upsertPrices(supplierId: string, prices: PriceInput[], source: 'MANUAL' | 'INVOICE' = 'MANUAL') {
    if (!(await prisma.supplier.findUnique({ where: { id: supplierId } }))) throw new SupplierError(404, 'SUPPLIER_NOT_FOUND', 'Proveedor no encontrado.');
    for (const p of prices.slice(0, 200)) {
      const itemName = clean(p.itemName, 120);
      const price = Math.round(Number(p.price));
      if (!itemName || !Number.isFinite(price) || price <= 0) continue;
      await prisma.supplierPrice.upsert({
        where: { supplierId_itemName: { supplierId, itemName } },
        create: { supplierId, itemName, unit: clean(p.unit, 20), price, productVariantId: p.productVariantId || null, source },
        update: { price, ...(p.unit !== undefined ? { unit: clean(p.unit, 20) } : {}), ...(p.productVariantId !== undefined ? { productVariantId: p.productVariantId || null } : {}), source },
      });
    }
    return prisma.supplier.findUnique({ where: { id: supplierId }, include: { prices: { orderBy: { itemName: 'asc' } } } });
  }

  async deletePrice(supplierId: string, priceId: string) {
    await prisma.supplierPrice.deleteMany({ where: { id: priceId, supplierId } });
    return { ok: true };
  }

  /**
   * Factura leída con IA → proveedor (por NIT o nombre) y sus precios unitarios.
   * Nunca bloquea el registro del gasto: si algo falla, se omite.
   */
  async learnFromInvoice(supplier: { name: string | null; nit: string | null }, items: { description: string; quantity: number | null; total: number | null }[]) {
    if (!supplier.name || !items.length) return null;
    const nit = nitDigits(supplier.nit);
    const all = await prisma.supplier.findMany();
    let found = (nit && all.find((s) => nitDigits(s.nit) === nit)) || all.find((s) => normalizeItem(s.name) === normalizeItem(supplier.name!));
    if (!found) found = await prisma.supplier.create({ data: { name: supplier.name.slice(0, 120), nit: supplier.nit || null } });
    const prices = items
      .filter((i) => i.total && i.total > 0)
      .map((i) => ({ itemName: i.description, price: i.quantity && i.quantity > 0 ? i.total! / i.quantity : i.total! }));
    if (prices.length) await this.upsertPrices(found.id, prices, 'INVOICE');
    return found.id;
  }

  /** Para cada producto, quién lo vende más barato (base de la recomendación de compras) */
  async bestPrices() {
    const prices = await prisma.supplierPrice.findMany({ include: { supplier: { select: { id: true, name: true, phone: true, isActive: true } } } });
    const byItem = new Map<string, typeof prices>();
    for (const p of prices) {
      if (!p.supplier.isActive) continue;
      const key = normalizeItem(p.itemName);
      byItem.set(key, [...(byItem.get(key) || []), p]);
    }
    return [...byItem.values()].map((list) => {
      const sorted = [...list].sort((a, b) => a.price - b.price);
      const best = sorted[0];
      return {
        itemName: best.itemName,
        unit: best.unit,
        best: { supplierId: best.supplierId, supplier: best.supplier.name, price: best.price, updatedAt: best.updatedAt },
        others: sorted.slice(1).map((p) => ({ supplierId: p.supplierId, supplier: p.supplier.name, price: p.price })),
      };
    });
  }
}
