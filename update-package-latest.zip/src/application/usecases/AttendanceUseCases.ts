// ============================================
// APPLICATION - Asistencia con PIN y horario semanal (Fase 4 · 13)
// ============================================
// El ADMIN le pone un PIN a cada empleado (se guarda con bcrypt y nunca se
// devuelve). En la caja o en una pantalla de asistencia emparejada, el empleado
// toca su nombre y escribe el PIN: si no tiene turno abierto marca la entrada, si
// lo tiene marca la salida (reutiliza los turnos de Personal). Los intentos fallidos
// se limitan por empleado y por equipo.

import bcrypt from 'bcryptjs';
import { prisma } from '../../infrastructure/database/prisma';
import { AuditLogger } from '../../infrastructure/services/AuditLogger';
import { AttendanceError, attendanceReport, isValidPin, isWeakPin, normalizeSchedule, PinLimiter } from '../../domain/attendance';
import { StaffUseCases } from './v3/StaffUseCases';
import type { Actor } from './v3/FloorUseCases';

const BCRYPT_ROUNDS = 10;
// Comparación de relleno: un empleado sin PIN tarda lo mismo que uno con PIN equivocado
const DUMMY_HASH = bcrypt.hashSync('lantify-pin-guard', BCRYPT_ROUNDS);

/** Límite de intentos compartido por la caja y las pantallas de asistencia */
export const pinLimiter = new PinLimiter();

export class AttendanceUseCases {
  constructor(private staff = new StaffUseCases(), private limiter = pinLimiter) {}

  /** ADMIN: pone, cambia o quita (null) el PIN de un empleado */
  async setPin(employeeId: string, pin: unknown, actor: Actor) {
    const e = await prisma.employee.findUnique({ where: { id: employeeId }, select: { id: true, name: true } });
    if (!e) throw new AttendanceError('Empleado no encontrado', 'EMPLOYEE_NOT_FOUND', 404);
    let pinHash: string | null = null;
    if (pin !== null && pin !== '') {
      if (!isValidPin(pin)) throw new AttendanceError('El PIN tiene de 4 a 6 números.', 'PIN_INVALID');
      if (isWeakPin(pin)) throw new AttendanceError('Ese PIN es muy fácil de adivinar. Elige otro (no 1234 ni 0000).', 'PIN_WEAK');
      pinHash = await bcrypt.hash(pin, BCRYPT_ROUNDS);
    }
    await prisma.employee.update({ where: { id: e.id }, data: { pinHash } });
    this.limiter.success(e.id);
    AuditLogger.log({ action: pinHash ? 'EMPLOYEE_PIN_SET' : 'EMPLOYEE_PIN_REMOVED', entityType: 'EMPLOYEE', entityId: e.id, userId: actor.userId, userName: actor.name, userRole: actor.role, details: { name: e.name } });
    return { employeeId: e.id, hasPin: !!pinHash };
  }

  /** Quiénes pueden marcar: empleados activos con PIN, y si están en turno */
  async roster() {
    const [employees, open] = await Promise.all([
      prisma.employee.findMany({ where: { isActive: true, pinHash: { not: null } }, select: { id: true, name: true, position: true }, orderBy: { name: 'asc' } }),
      prisma.shift.findMany({ where: { endAt: null }, select: { employeeId: true, startAt: true } }),
    ]);
    const openBy = new Map(open.map((s) => [s.employeeId, s.startAt]));
    return employees.map((e) => ({ ...e, onShift: openBy.has(e.id), since: openBy.get(e.id) || null }));
  }

  /** Marcar con PIN: entrada si no tiene turno abierto, salida si lo tiene */
  async punch(employeeId: unknown, pin: unknown, source: string, by: string) {
    const id = typeof employeeId === 'string' ? employeeId.slice(0, 64) : '';
    if (!id) throw new AttendanceError('Elige tu nombre.', 'EMPLOYEE_REQUIRED');
    if (!this.limiter.allowed(id, source)) {
      throw new AttendanceError('Demasiados intentos. Espera unos minutos o pide ayuda en la caja.', 'PIN_LOCKED', 429);
    }
    const e = await prisma.employee.findUnique({ where: { id }, select: { id: true, name: true, isActive: true, pinHash: true } });
    const ok = await bcrypt.compare(typeof pin === 'string' ? pin.slice(0, 12) : '', e?.pinHash || DUMMY_HASH);
    if (!e || !e.isActive || !e.pinHash || !ok) {
      this.limiter.fail(id, source);
      AuditLogger.log({ action: 'ATTENDANCE_PIN_FAILED', entityType: 'EMPLOYEE', entityId: id, userName: by, details: { source } });
      throw new AttendanceError('PIN incorrecto.', 'PIN_WRONG', 401);
    }
    this.limiter.success(e.id);
    const open = await prisma.shift.findFirst({ where: { employeeId: e.id, endAt: null } });
    if (open) {
      const shift = await this.staff.clockOut(e.id);
      AuditLogger.log({ action: 'ATTENDANCE_OUT', entityType: 'SHIFT', entityId: shift.id, userName: by, details: { employee: e.name } });
      return { action: 'OUT' as const, name: e.name, at: shift.endAt, startAt: shift.startAt };
    }
    const shift = await this.staff.clockIn(e.id, { name: `PIN · ${by}`.slice(0, 60) });
    AuditLogger.log({ action: 'ATTENDANCE_IN', entityType: 'SHIFT', entityId: shift.id, userName: by, details: { employee: e.name } });
    return { action: 'IN' as const, name: e.name, at: shift.startAt, startAt: shift.startAt };
  }

  // ── Horario semanal ─────────────────────────────────────

  async schedule() {
    return prisma.scheduleSlot.findMany({ orderBy: [{ employeeId: 'asc' }, { weekday: 'asc' }, { start: 'asc' }], select: { id: true, employeeId: true, weekday: true, start: true, end: true } });
  }

  /** Reemplaza el horario de la semana de un empleado */
  async setSchedule(employeeId: string, raw: unknown, actor: Actor) {
    const e = await prisma.employee.findUnique({ where: { id: employeeId }, select: { id: true, name: true } });
    if (!e) throw new AttendanceError('Empleado no encontrado', 'EMPLOYEE_NOT_FOUND', 404);
    const slots = normalizeSchedule(raw);
    await prisma.$transaction([
      prisma.scheduleSlot.deleteMany({ where: { employeeId } }),
      ...slots.map((s) => prisma.scheduleSlot.create({ data: { employeeId, ...s } })),
    ]);
    AuditLogger.log({ action: 'SCHEDULE_UPDATED', entityType: 'EMPLOYEE', entityId: employeeId, userId: actor.userId, userName: actor.name, userRole: actor.role, details: { name: e.name, slots: slots.length } });
    return prisma.scheduleSlot.findMany({ where: { employeeId }, orderBy: [{ weekday: 'asc' }, { start: 'asc' }], select: { id: true, employeeId: true, weekday: true, start: true, end: true } });
  }

  /** Llegadas tarde y horas trabajadas contra lo programado */
  async report(from: Date, to: Date, now = new Date()) {
    const [employees, slots, shifts] = await Promise.all([
      prisma.employee.findMany({ where: { isActive: true }, select: { id: true, name: true }, orderBy: { name: 'asc' } }),
      prisma.scheduleSlot.findMany({ select: { employeeId: true, weekday: true, start: true, end: true } }),
      // Turnos que tocan el periodo (los que empezaron hasta 1 día antes pueden cruzar al primer día)
      prisma.shift.findMany({ where: { startAt: { gte: new Date(from.getTime() - 86_400_000), lte: to } }, select: { employeeId: true, startAt: true, endAt: true } }),
    ]);
    return { from: from.toISOString(), to: to.toISOString(), ...attendanceReport(employees, slots, shifts, from, to, now) };
  }
}
