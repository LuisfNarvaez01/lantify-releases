// ============================================
// APPLICATION - Configuración del negocio y configuración inicial
// ============================================

import { prisma } from '../../infrastructure/database/prisma';
import { AuditLogger } from '../../infrastructure/services/AuditLogger';
import { currentFeatures } from '../../shared/cloud/features';
import { loadSampleMenu, loadMenuFromPhoto, BusinessType } from '../../infrastructure/services/sampleMenus';
import { AuthUseCases } from './AuthUseCases';
import { normalizeTaxProfile, NO_TAX, TaxProfile } from '../../domain/tax';

const SETTINGS_ID = 'default';

export class BusinessError extends Error {
  constructor(public statusCode: number, public code: string, message: string) {
    super(message);
    this.name = 'BusinessError';
  }
}

export interface BusinessSettingsInput {
  businessType?: BusinessType;
  businessName?: string;
  legalName?: string | null;
  nit?: string | null;
  dv?: string | null;
  taxRegime?: 'NO_RESPONSABLE' | 'RESPONSABLE_INC' | 'RESPONSABLE_IVA';
  address?: string | null;
  city?: string | null;
  phone?: string | null;
  email?: string | null;
  ticketFooter?: string | null;
  usesTables?: boolean;
  deliveryEnabled?: boolean;
  whatsappEnabled?: boolean;
  rappiEnabled?: boolean;
  inventoryEnabled?: boolean;
  tipEnabled?: boolean;
  tipPercent?: number;
  defaultTaxType?: 'IVA' | 'INC' | 'NONE';
  defaultTaxRate?: number;
  wantsElectronicInvoice?: boolean;
}

export interface OnboardingInput {
  settings: BusinessSettingsInput & { businessType: BusinessType; businessName: string };
  zones?: { name: string; tables: number }[];
  staff?: { name: string; username: string; password: string; role: 'CASHIER' | 'WAITER' }[];
  loadSampleMenu?: boolean;
  /** Carta leída con IA de una foto: reemplaza al menú de ejemplo */
  menu?: { name: string; items: { name: string; price: number }[] }[];
  language?: 'es' | 'en';
}

interface Actor {
  userId?: string;
  name?: string;
  role?: string;
  ip?: string;
}

const MAX_TABLES = 200;

const clean = (v: string | null | undefined) => {
  if (v === undefined) return undefined;
  const t = (v ?? '').trim();
  return t ? t : null;
};

export class BusinessSettingsUseCases {
  constructor(private authUseCases: AuthUseCases) {}

  async get() {
    return prisma.businessSettings.upsert({
      where: { id: SETTINGS_ID },
      create: { id: SETTINGS_ID },
      update: {},
    });
  }

  /** Impuesto que se aplica a los productos que no tienen uno propio. */
  async getDefaultTax(): Promise<TaxProfile> {
    const s = await prisma.businessSettings.findUnique({ where: { id: SETTINGS_ID } });
    if (!s) return NO_TAX;
    return normalizeTaxProfile(s.defaultTaxType, s.defaultTaxRate) ?? NO_TAX;
  }

  private toData(input: BusinessSettingsInput) {
    const data: Record<string, unknown> = {};
    if (input.businessType !== undefined) data.businessType = input.businessType;
    if (input.businessName !== undefined) {
      const name = input.businessName.trim();
      if (!name) throw new BusinessError(400, 'BUSINESS_NAME_REQUIRED', 'El nombre del negocio es obligatorio.');
      data.businessName = name;
    }
    for (const key of ['legalName', 'nit', 'dv', 'address', 'city', 'phone', 'email', 'ticketFooter'] as const) {
      const v = clean(input[key]);
      if (v !== undefined) data[key] = v;
    }
    if (typeof data.nit === 'string') data.nit = (data.nit as string).replace(/[^0-9]/g, '') || null;
    for (const key of ['usesTables', 'deliveryEnabled', 'whatsappEnabled', 'rappiEnabled', 'inventoryEnabled', 'tipEnabled', 'wantsElectronicInvoice'] as const) {
      if (input[key] !== undefined) data[key] = !!input[key];
    }
    if (input.taxRegime !== undefined) data.taxRegime = input.taxRegime;
    if (input.tipPercent !== undefined) data.tipPercent = input.tipPercent;

    if (input.defaultTaxType !== undefined) {
      const profile = normalizeTaxProfile(input.defaultTaxType, input.defaultTaxRate);
      if (!profile) throw new BusinessError(400, 'BUSINESS_INVALID_TAX', 'La tarifa del impuesto no es válida.');
      data.defaultTaxType = profile.taxType;
      data.defaultTaxRate = profile.taxRate;
    }
    return data;
  }

  /** El emisor de la factura electrónica es el mismo negocio. */
  private async syncDianIssuer(tx: any, settings: { businessName: string; legalName: string | null; nit: string | null; dv: string | null }) {
    const dian = await tx.dianConfig.findFirst();
    if (!dian || !settings.nit) return;
    await tx.dianConfig.update({
      where: { id: dian.id },
      data: {
        nit: settings.nit,
        dv: settings.dv || dian.dv,
        businessName: settings.legalName || settings.businessName,
      },
    });
  }

  /** El asistente se ofrece una sola vez: si el dueño lo pospone, queda en Configuración. */
  async dismissOnboarding(actor: Actor) {
    const settings = await prisma.businessSettings.upsert({
      where: { id: SETTINGS_ID },
      create: { id: SETTINGS_ID, onboardingDismissedAt: new Date() },
      update: { onboardingDismissedAt: new Date() },
    });
    await AuditLogger.log({
      userId: actor.userId,
      userName: actor.name,
      userRole: actor.role,
      action: 'ONBOARDING_DISMISSED',
      entityType: 'SYSTEM',
      ipAddress: actor.ip,
    });
    return settings;
  }

  async update(input: BusinessSettingsInput, actor: Actor) {
    const data = this.toData(input);
    // Un canal de venta solo se enciende si el plan lo incluye (apagarlo siempre se puede)
    const features = await currentFeatures();
    const current = features ? await prisma.businessSettings.findUnique({ where: { id: SETTINGS_ID } }) : null;
    for (const [key, feature] of [['whatsappEnabled', 'whatsapp'], ['rappiEnabled', 'delivery']] as const) {
      if (data[key] === true && !current?.[key] && features && !features.includes(feature)) {
        throw new BusinessError(402, 'PLAN_FEATURE_REQUIRED', 'Tu plan no incluye este canal.');
      }
    }
    const settings = await prisma.$transaction(async (tx) => {
      const s = await tx.businessSettings.upsert({
        where: { id: SETTINGS_ID },
        create: { id: SETTINGS_ID, ...data },
        update: data,
      });
      await this.syncDianIssuer(tx, s);
      return s;
    });

    await AuditLogger.log({
      userId: actor.userId,
      userName: actor.name,
      userRole: actor.role,
      action: 'BUSINESS_SETTINGS_UPDATED',
      entityType: 'SYSTEM',
      details: { fields: Object.keys(data) },
      ipAddress: actor.ip,
    });
    return settings;
  }

  /**
   * Aplica la configuración inicial en una sola transacción: datos del negocio,
   * mesas, usuarios del equipo y, si se pide, el menú de ejemplo.
   * Nunca borra ni reemplaza datos existentes.
   */
  async completeOnboarding(input: OnboardingInput, actor: Actor) {
    const data = this.toData(input.settings);
    const zones = (input.settings.usesTables ? input.zones || [] : [])
      .map((z) => ({ name: z.name.trim(), tables: Math.floor(z.tables) }))
      .filter((z) => z.tables > 0);
    const totalTables = zones.reduce((n, z) => n + z.tables, 0);
    if (totalTables > MAX_TABLES) {
      throw new BusinessError(400, 'BUSINESS_TOO_MANY_TABLES', `Máximo ${MAX_TABLES} mesas.`);
    }

    // Se validan los usuarios antes de escribir nada
    const staff = input.staff || [];
    const usernames = new Set<string>();
    const preparedStaff: Awaited<ReturnType<AuthUseCases["prepareNewUser"]>>[] = [];
    for (const member of staff) {
      const prepared = await this.authUseCases.prepareNewUser(member.username, member.password, member.name, member.role);
      if (usernames.has(prepared.username)) {
        throw new BusinessError(400, 'BUSINESS_DUPLICATE_USERNAME', 'Hay dos usuarios con el mismo nombre de usuario.');
      }
      usernames.add(prepared.username);
      preparedStaff.push(prepared);
    }

    const result = await prisma.$transaction(async (tx) => {
      const settings = await tx.businessSettings.upsert({
        where: { id: SETTINGS_ID },
        create: { id: SETTINGS_ID, ...data, onboardingCompletedAt: new Date() },
        update: { ...data, onboardingCompletedAt: new Date() },
      });
      await this.syncDianIssuer(tx, settings);

      // Mesas: solo si todavía no hay ninguna (una reconfiguración no toca el plano existente)
      let tablesCreated = 0;
      if (zones.length > 0 && (await tx.table.count()) === 0) {
        let number = 1;
        for (const zone of zones) {
          for (let i = 0; i < zone.tables; i++) {
            await tx.table.create({ data: { number: String(number++), zone: zone.name || null } });
            tablesCreated++;
          }
        }
      }

      for (const member of preparedStaff) {
        await tx.user.create({ data: member as any });
      }

      // Menú de ejemplo: solo con el catálogo vacío, para no mezclarlo con productos reales
      let sampleProducts = 0;
      const emptyCatalog = (await tx.product.count({ where: { isActive: true } })) === 0;
      if (input.menu?.length && emptyCatalog) {
        sampleProducts = await loadMenuFromPhoto(tx, input.menu);
      } else if (input.loadSampleMenu && emptyCatalog) {
        sampleProducts = await loadSampleMenu(tx, settings.businessType as BusinessType, input.language === 'en' ? 'en' : 'es');
      }

      return { settings, tablesCreated, staffCreated: preparedStaff.length, sampleProducts };
    });

    await AuditLogger.log({
      userId: actor.userId,
      userName: actor.name,
      userRole: actor.role,
      action: 'ONBOARDING_COMPLETED',
      entityType: 'SYSTEM',
      details: {
        businessType: result.settings.businessType,
        tablesCreated: result.tablesCreated,
        staffCreated: result.staffCreated,
        sampleProducts: result.sampleProducts,
      },
      ipAddress: actor.ip,
    });

    return result;
  }
}
