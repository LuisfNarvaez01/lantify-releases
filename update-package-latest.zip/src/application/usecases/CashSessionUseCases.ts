// ============================================
// APPLICATION USE CASES - CashSession Use Cases
// ============================================

import { ICashSessionRepository } from '../../domain/repositories/index';
import { calculateFinalBalance, calculateDifference } from '../../domain/entities';
import { OpenCashSessionDTO, CloseCashSessionDTO } from '../dtos';
import { BackupService } from '../../infrastructure/services/BackupService';
import { notifyCashClosed } from './CloudBackupService';
import { AuditLogger } from '../../infrastructure/services/AuditLogger';

export class CashSessionUseCases {
  constructor(private cashSessionRepository: ICashSessionRepository) {}

  async openSession(data: OpenCashSessionDTO) {
    // Verificar que no haya una sesión abierta
    const openSession = await this.cashSessionRepository.getOpenSession();
    if (openSession) {
      throw new Error('Ya existe una sesión de caja abierta');
    }

    return this.cashSessionRepository.create({
      initialBalance: data.initialBalance,
      income: 0,
      expenses: 0,
      notes: data.notes,
    });
  }

  async getOpenSession() {
    return this.cashSessionRepository.getOpenSession();
  }

  async getSessionById(id: string) {
    return this.cashSessionRepository.getById(id);
  }

  async getAllSessions() {
    return this.cashSessionRepository.getAll();
  }

  async getSessionsByDateRange(startDate: Date, endDate: Date) {
    return this.cashSessionRepository.getByDateRange(startDate, endDate);
  }

  async addIncome(sessionId: string, amount: number, motive: string, description?: string) {
    if (amount <= 0) {
      throw new Error('El monto debe ser mayor a 0');
    }
    if (!motive) {
      throw new Error('El motivo es obligatorio');
    }
    return this.cashSessionRepository.addIncome(sessionId, amount, motive, description);
  }

  async addExpense(sessionId: string, amount: number, motive: string, description?: string, categoryId?: string) {
    if (amount <= 0) {
      throw new Error('El monto debe ser mayor a 0');
    }
    if (!motive) {
      throw new Error('El motivo es obligatorio');
    }
    return this.cashSessionRepository.addExpense(sessionId, amount, motive, description, categoryId);
  }


  async closeSession(sessionId: string, data: CloseCashSessionDTO) {
    const session = await this.cashSessionRepository.getById(sessionId);
    if (!session) {
      throw new Error('Sesión no encontrada');
    }

    if (session.status === 'CLOSED') {
      throw new Error('La sesión ya está cerrada');
    }

    // Calcular esperado y diferencia
    const expected = calculateFinalBalance(session);
    const difference = calculateDifference(
      { ...session, finalBalance: expected },
      data.countedBalance
    );

    const closed = await this.cashSessionRepository.closeSession(
      sessionId,
      data.countedBalance,
      data.notes
    );

    // Respaldo automático verificado al cerrar la caja del turno/día
    try {
      const backup = BackupService.runBackup('dev.db.cierre-caja');
      notifyCashClosed();
      await AuditLogger.log({
        action: 'CASH_SESSION_CLOSE_BACKUP',
        entityType: 'CASH_SESSION',
        entityId: sessionId,
        details: {
          countedBalance: data.countedBalance,
          expectedBalance: expected,
          difference,
          backupFile: backup?.name,
        }
      });
    } catch (err) {
      console.warn('Advertencia: fallo no bloqueante al generar respaldo en cierre de caja:', err);
    }

    return closed;
  }

  async cancelIncome(sessionId: string, incomeId: string, reason: string) {
    if (!reason) {
      throw new Error('El motivo de la cancelación es obligatorio');
    }
    return this.cashSessionRepository.cancelIncome(sessionId, incomeId, reason);
  }

  async cancelExpense(sessionId: string, expenseId: string, reason: string) {
    if (!reason) {
      throw new Error('El motivo de la cancelación es obligatorio');
    }
    return this.cashSessionRepository.cancelExpense(sessionId, expenseId, reason);
  }
}