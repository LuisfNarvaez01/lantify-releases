// ============================================
// APPLICATION - Conexión de la caja con el relevo de meseros (Lantify Cloud)
// ============================================
// Si hay celulares vinculados, la caja mantiene un WebSocket saliente con su objeto de
// relevo en la nube (no hay que abrir puertos en el router). Cada petición que llega por
// ahí se ejecuta contra este mismo servidor, con el token del mesero y la marca de
// "relevo", así pasa por los mismos permisos, límites y planes que en la red local.
// Sin internet no pasa nada: la red local sigue igual y se reintenta solo.

import crypto from 'crypto';
import { prisma } from '../../infrastructure/database/prisma';
import { cloudConfig } from '../../shared/cloud/config';
import { onLiveChunk } from '../../shared/liveEvents';
import type { CloudAuthService } from './CloudAuthService';

/** Marca secreta del proceso: solo el relevo la conoce, así la petición cuenta como de otro equipo */
export const RELAY_MARK = crypto.randomBytes(24).toString('hex');
export const RELAY_HEADER = 'x-lantify-relay';

const FORWARD_HEADERS = ['authorization', 'content-type', 'accept', 'accept-language', 'x-idempotency-key', 'idempotency-key', 'x-lantify-lang'];
const TEXT_TYPES = /^(application\/(json|javascript|xml)|text\/)/i;
const MAX_BODY = 850_000;
const BACKOFF_MS = [2_000, 5_000, 15_000, 30_000, 60_000];

export const hashSecret = (secret: string) => crypto.createHash('sha256').update(secret).digest('hex');

export interface RelayStatus {
  enabled: boolean;
  connected: boolean;
  devices: number;
  lastError: string | null;
  since: string | null;
}

type Ws = { send(d: string): void; close(): void; readyState: number; onopen: any; onclose: any; onerror: any; onmessage: any };

export class RelayHostService {
  private ws: Ws | null = null;
  private attempt = 0;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private stopped = true;
  private offLive: (() => void) | null = null;
  private status: RelayStatus = { enabled: false, connected: false, devices: 0, lastError: null, since: null };

  constructor(
    private cloudAuth: CloudAuthService,
    private opts: { port: () => number; lan: () => string[]; version: () => string },
  ) {}

  getStatus(): RelayStatus { return { ...this.status }; }

  start() {
    this.stopped = false;
    this.offLive ??= onLiveChunk((chunk) => this.send({ t: 'sse', chunk }));
    void this.ensure();
  }

  stop() {
    this.stopped = true;
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
    this.ws?.close();
    this.ws = null;
  }

  /** Vuelve a revisar si hace falta la conexión (se llama al vincular o revocar celulares) */
  async refresh() {
    if (this.ws && this.ws.readyState === 1) await this.pushDevices();
    await this.ensure();
  }

  private send(frame: unknown) {
    if (this.ws && this.ws.readyState === 1) {
      try { this.ws.send(JSON.stringify(frame)); } catch { /* se reconecta al cerrar */ }
    }
  }

  private async activeDevices() {
    return prisma.relayDevice.findMany({ where: { revokedAt: null }, select: { id: true, name: true, secretHash: true } });
  }

  private async pushDevices() {
    const list = await this.activeDevices();
    this.status.devices = list.length;
    this.send({ t: 'devices', list: list.map((d) => ({ id: d.id, hash: d.secretHash, name: d.name })) });
  }

  private async pushHello() {
    const settings = await prisma.businessSettings.findUnique({ where: { id: 'default' }, select: { businessName: true } }).catch(() => null);
    this.send({ t: 'hello', lan: this.opts.lan(), business: settings?.businessName || null, version: this.opts.version() });
  }

  private schedule() {
    if (this.stopped || this.timer) return;
    const wait = BACKOFF_MS[Math.min(this.attempt, BACKOFF_MS.length - 1)];
    this.attempt++;
    this.timer = setTimeout(() => { this.timer = null; void this.ensure(); }, wait);
  }

  private async ensure() {
    if (this.stopped) return;
    const devices = await this.activeDevices().catch(() => []);
    this.status.devices = devices.length;
    this.status.enabled = devices.length > 0;
    // Sin celulares vinculados no se gasta conexión en la nube
    if (!devices.length) {
      this.ws?.close();
      this.ws = null;
      this.status.connected = false;
      return;
    }
    if (this.ws) return;
    const tenant = await this.cloudAuth.linkedTenant().catch(() => null);
    if (!tenant) {
      this.status.lastError = 'NOT_LINKED';
      return;
    }
    let ticket: { ticket: string; code: string };
    try {
      ticket = await this.cloudAuth.adminCall(undefined, 'POST', '/v1/relay/ticket', {}, 10_000);
    } catch (err: any) {
      this.status.lastError = String(err?.code || err?.message || 'TICKET_FAILED').slice(0, 80);
      return this.schedule();
    }
    const base = cloudConfig().apiUrl.replace(/^http/, 'ws');
    const WebSocketImpl = (globalThis as any).WebSocket;
    if (!WebSocketImpl) {
      this.status.lastError = 'NO_WEBSOCKET';
      return;
    }
    const ws: Ws = new WebSocketImpl(`${base}/v1/relay/host/${encodeURIComponent(ticket.code)}?ticket=${encodeURIComponent(ticket.ticket)}`);
    this.ws = ws;
    ws.onopen = async () => {
      this.attempt = 0;
      this.status = { ...this.status, connected: true, lastError: null, since: new Date().toISOString() };
      await this.pushDevices();
      await this.pushHello();
    };
    ws.onmessage = (ev: { data: unknown }) => {
      const raw = typeof ev.data === 'string' ? ev.data : String(ev.data);
      let frame: any;
      try { frame = JSON.parse(raw); } catch { return; }
      if (frame?.t === 'req') void this.handle(frame);
    };
    ws.onerror = () => { this.status.lastError = 'SOCKET_ERROR'; };
    ws.onclose = () => {
      if (this.ws === ws) this.ws = null;
      this.status.connected = false;
      this.schedule();
    };
  }

  /** Ejecuta la petición del celular contra este mismo servidor y devuelve la respuesta */
  async handle(frame: { rid: string; did: string; method: string; path: string; headers?: Record<string, string>; body?: string | null }) {
    const reply = (status: number, body: string, headers: Record<string, string> = { 'content-type': 'application/json' }) =>
      this.send({ t: 'res', rid: frame.rid, did: frame.did, status, headers, body });
    const device = await prisma.relayDevice.findUnique({ where: { id: frame.did } }).catch(() => null);
    if (!device || device.revokedAt) return reply(403, JSON.stringify({ code: 'RELAY_DEVICE_REVOKED' }));
    if (!frame.path.startsWith('/api/') || frame.path.includes('..')) return reply(400, JSON.stringify({ code: 'RELAY_BAD_PATH' }));

    const headers: Record<string, string> = { [RELAY_HEADER]: RELAY_MARK };
    for (const [k, v] of Object.entries(frame.headers || {})) {
      if (FORWARD_HEADERS.includes(k.toLowerCase()) && typeof v === 'string') headers[k.toLowerCase()] = v.slice(0, 4000);
    }
    const method = (frame.method || 'GET').toUpperCase();
    try {
      const res = await fetch(`http://127.0.0.1:${this.opts.port()}${frame.path}`, {
        method,
        headers,
        body: method === 'GET' || method === 'HEAD' ? undefined : frame.body ?? undefined,
        signal: AbortSignal.timeout(20_000),
      });
      const type = res.headers.get('content-type') || '';
      const out: Record<string, string> = { 'content-type': type };
      let body: string;
      if (!type || TEXT_TYPES.test(type)) body = await res.text();
      else {
        body = Buffer.from(await res.arrayBuffer()).toString('base64');
        out['x-relay-b64'] = '1';
      }
      if (body.length > MAX_BODY) return reply(413, JSON.stringify({ code: 'RELAY_TOO_LARGE' }));
      const disposition = res.headers.get('content-disposition');
      if (disposition) out['content-disposition'] = disposition;
      reply(res.status, body, out);
      // Última vez que se vio el celular (como mucho una escritura por minuto)
      if (!device.lastSeenAt || Date.now() - device.lastSeenAt.getTime() > 60_000) {
        void prisma.relayDevice.update({ where: { id: device.id }, data: { lastSeenAt: new Date() } }).catch(() => {});
      }
    } catch (err: any) {
      reply(502, JSON.stringify({ code: 'RELAY_LOCAL_ERROR', error: String(err?.message || err).slice(0, 120) }));
    }
  }

  // ── Vincular y revocar celulares ──────────────────────────

  async createDevice(name: string, createdBy: string | null) {
    const clean = String(name || '').trim().slice(0, 60) || 'Celular';
    const secret = crypto.randomBytes(32).toString('base64url');
    const device = await prisma.relayDevice.create({ data: { name: clean, secretHash: hashSecret(secret), createdBy } });
    await this.refresh();
    return { device, secret };
  }

  async revokeDevice(id: string) {
    const device = await prisma.relayDevice.update({ where: { id }, data: { revokedAt: new Date() } });
    await this.refresh();
    return device;
  }

  listDevices() {
    return prisma.relayDevice.findMany({ where: { revokedAt: null }, orderBy: { createdAt: 'desc' }, select: { id: true, name: true, createdAt: true, lastSeenAt: true, createdBy: true } });
  }
}
