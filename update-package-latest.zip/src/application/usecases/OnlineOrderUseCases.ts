// ============================================
// APPLICATION - Pedidos en línea (domicilio o para recoger)
// ============================================
// Llegan de la página del negocio (ReservationSyncService los trae de Lantify
// Cloud). En la caja:
//   PENDING  → aceptar (se crea la comanda y va a cocina) o rechazar (con motivo)
//   ACCEPTED → listo (para recoger) / en camino (domicilio)
//   READY    → cobrar: queda como venta del arqueo abierto, con su medio de pago
// Cada cambio se sube a la nube y el cliente lo ve en el enlace de su pedido.

import { prisma } from '../../infrastructure/database/prisma';
import { AuditLogger } from '../../infrastructure/services/AuditLogger';
import { BookingError } from './ReservationUseCases';
import { OrderUseCases } from './OrderUseCases';
import type { SaleUseCases } from './SaleUseCases';

export interface OrderLineView {
  id: string;
  name: string;
  price: number;
  qty: number;
  note: string | null;
}

const OPEN = ['PENDING', 'ACCEPTED', 'READY'];
// La venta guarda el medio de pago con el vocabulario de la caja
const SALE_PAYMENT: Record<string, string> = { CASH: 'CASH', CARD: 'CARD', NEQUI: 'NEQUI', DAVIPLATA: 'DAVIPLATA', TRANSFER: 'TRANSFER' };

const lines = (raw: string): OrderLineView[] => {
  try {
    const v = JSON.parse(raw);
    return Array.isArray(v) ? v : [];
  } catch {
    return [];
  }
};

export class OnlineOrderUseCases {
  constructor(
    private sales?: SaleUseCases,
    private orders = new OrderUseCases(),
    private afterChange: () => void = () => {},
  ) {}

  private view(o: Awaited<ReturnType<typeof prisma.onlineOrder.findFirst>> & {}) {
    return { ...o, items: lines(o.items) };
  }

  /** Abiertos y los de hoy (o los del día pedido) */
  async list(date?: string) {
    const day = date && /^\d{4}-\d{2}-\d{2}$/.test(date) ? new Date(`${date}T00:00:00`) : new Date(new Date().setHours(0, 0, 0, 0));
    const next = new Date(day.getTime() + 86400000);
    const rows = await prisma.onlineOrder.findMany({
      where: { OR: [{ status: { in: OPEN } }, { placedAt: { gte: day, lt: next } }] },
      orderBy: { placedAt: 'desc' },
      take: 200,
    });
    return rows.map((r) => this.view(r));
  }

  async summary() {
    const [pending, open, latest] = await Promise.all([
      prisma.onlineOrder.count({ where: { status: 'PENDING' } }),
      prisma.onlineOrder.count({ where: { status: { in: OPEN } } }),
      prisma.onlineOrder.findFirst({ orderBy: { placedAt: 'desc' }, select: { id: true, code: true, customerName: true, total: true, kind: true } }),
    ]);
    return { pending, open, latest: latest?.id || '', latestOrder: latest };
  }

  private async get(id: string) {
    const o = await prisma.onlineOrder.findUnique({ where: { id } });
    if (!o) throw new BookingError(404, 'ORDER_NOT_FOUND', 'El pedido no existe.');
    return o;
  }

  private async setStatus(id: string, status: string, data: Record<string, unknown> = {}) {
    const updated = await prisma.onlineOrder.update({ where: { id }, data: { status, dirty: true, ...data } });
    this.afterChange();
    return this.view(updated);
  }

  /** Aceptar: la comanda va a cocina con los productos del pedido */
  async accept(id: string, actor: string, eta?: string) {
    const o = await this.get(id);
    if (o.status !== 'PENDING') throw new BookingError(409, 'ORDER_BAD_STATUS', 'El pedido ya fue atendido.');
    const items = lines(o.items);
    const variants = await prisma.productVariant.findMany({ where: { id: { in: items.map((l) => l.id) } }, select: { id: true } });
    const missing = items.filter((l) => !variants.some((v) => v.id === l.id));
    if (missing.length) {
      throw new BookingError(409, 'ORDER_ITEM_MISSING', `Ya no existe en la carta: ${missing.map((l) => l.name).join(', ')}. Rechaza el pedido o llama al cliente.`);
    }
    const label = o.kind === 'DELIVERY' ? 'Domicilio' : 'Para recoger';
    const kitchen = await this.orders.saveOrder({
      channel: 'WEB',
      customerId: o.customerId || undefined,
      userName: actor,
      notes: [`Pedido web ${o.code} · ${label} · ${o.customerName}`, o.address, o.notes].filter(Boolean).join(' · '),
      items: items.map((l) => ({ productVariantId: l.id, quantity: l.qty, unitPrice: l.price, notes: l.note || undefined, status: 'SENT' })),
    });
    AuditLogger.log({ action: 'ONLINE_ORDER_ACCEPTED', entityType: 'ORDER', entityId: id, details: { code: o.code, by: actor } });
    return this.setStatus(id, 'ACCEPTED', { kitchenOrderId: kitchen?.id ?? null, acceptedBy: actor, statusNote: eta ? String(eta).slice(0, 80) : null });
  }

  async reject(id: string, reason: string, actor: string) {
    const o = await this.get(id);
    if (!OPEN.includes(o.status)) throw new BookingError(409, 'ORDER_BAD_STATUS', 'El pedido ya está cerrado.');
    const note = String(reason || '').trim().slice(0, 200);
    if (note.length < 3) throw new BookingError(400, 'ORDER_REASON_REQUIRED', 'Escribe el motivo: el cliente lo verá.');
    if (o.kitchenOrderId) await prisma.order.updateMany({ where: { id: o.kitchenOrderId }, data: { status: 'CANCELLED' } });
    AuditLogger.log({ action: 'ONLINE_ORDER_REJECTED', entityType: 'ORDER', entityId: id, details: { code: o.code, by: actor, reason: note } });
    return this.setStatus(id, o.status === 'PENDING' ? 'REJECTED' : 'CANCELLED', { statusNote: note });
  }

  /** Listo para recoger / salió el domicilio */
  async ready(id: string) {
    const o = await this.get(id);
    if (o.status !== 'ACCEPTED') throw new BookingError(409, 'ORDER_BAD_STATUS', 'Primero acepta el pedido.');
    return this.setStatus(id, 'READY');
  }

  /** Cobrar: venta del arqueo abierto (el domicilio no hace parte de la venta: es del domiciliario) */
  async complete(id: string, actor: string) {
    if (!this.sales) throw new Error('Ventas no disponibles');
    const o = await this.get(id);
    if (!['ACCEPTED', 'READY'].includes(o.status)) throw new BookingError(409, 'ORDER_BAD_STATUS', 'Primero acepta el pedido.');
    const session = await prisma.cashSession.findFirst({ where: { status: 'OPEN' }, orderBy: { openedAt: 'desc' } });
    if (!session) throw new BookingError(409, 'CASH_SESSION_REQUIRED', 'Abre la caja para cobrar el pedido.');
    const items = lines(o.items);
    const amount = items.reduce((n, l) => n + l.price * l.qty, 0);
    const method = SALE_PAYMENT[o.paymentMethod] || 'CASH';
    const sale: any = await this.sales.createSale({
      cashSessionId: session.id,
      customerId: o.customerId || undefined,
      customerName: o.customerName,
      channel: 'WEB',
      items: items.map((l) => ({ productVariantId: l.id, quantity: l.qty, unitPrice: l.price, notes: l.note || undefined })),
      paymentMethod: method as any,
      payments: [{ method, amount }],
      cashierName: actor,
      idempotencyKey: `online-${o.id}`,
      notes: `Pedido web ${o.code}${o.deliveryFee ? ` · domicilio ${o.deliveryFee} aparte` : ''}`,
    });
    await prisma.sale.update({
      where: { id: sale.id },
      data: { customerPhone: o.customerPhone, customerAddress: o.address || 'Para recoger en el local', deliveryNotes: o.notes },
    });
    if (o.kitchenOrderId) await prisma.order.updateMany({ where: { id: o.kitchenOrderId }, data: { status: 'COMPLETED' } });
    AuditLogger.log({ action: 'ONLINE_ORDER_COMPLETED', entityType: 'ORDER', entityId: id, details: { code: o.code, by: actor, saleId: sale.id } });
    return this.setStatus(id, 'COMPLETED', { saleId: sale.id });
  }

  // ── Sincronización (ReservationSyncService) ───────────────
  async dirty() {
    return prisma.onlineOrder.findMany({ where: { dirty: true }, take: 300, orderBy: { updatedAt: 'asc' } });
  }

  async markClean(rows: { id: string; updatedAt: Date }[]) {
    for (const r of rows) await prisma.onlineOrder.updateMany({ where: { id: r.id, updatedAt: r.updatedAt }, data: { dirty: false } });
  }

  /** Un pedido nuevo de la página; quien pidió queda en Clientes (lo autorizó al pedir) */
  async importFromCloud(o: any, customerFor: (r: any) => Promise<string | null>): Promise<boolean> {
    if (!o?.id || !o.customerName || (await prisma.onlineOrder.findUnique({ where: { id: o.id } }))) return false;
    const customerId = await customerFor({ customerName: o.customerName, customerPhone: o.customerPhone, consentAt: o.consentAt, consentVersion: o.consentVersion, marketingOptIn: o.marketingOptIn });
    await prisma.onlineOrder.create({
      data: {
        id: String(o.id).slice(0, 64),
        code: String(o.code).slice(0, 12),
        kind: o.kind === 'PICKUP' ? 'PICKUP' : 'DELIVERY',
        status: o.status === 'PENDING' ? 'PENDING' : String(o.status),
        customerId,
        customerName: String(o.customerName).slice(0, 120),
        customerPhone: o.customerPhone || null,
        address: o.address || null,
        notes: o.notes || null,
        paymentMethod: String(o.payment || 'CASH'),
        items: JSON.stringify(Array.isArray(o.items) ? o.items : []),
        subtotal: Number(o.subtotal) || 0,
        deliveryFee: Number(o.deliveryFee) || 0,
        total: Number(o.total) || 0,
        placedAt: o.createdAt ? new Date(o.createdAt) : new Date(),
      },
    });
    return true;
  }
}
