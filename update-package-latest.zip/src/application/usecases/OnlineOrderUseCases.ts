// ============================================
// APPLICATION - Pedidos en línea (domicilio o para recoger)
// ============================================
// Llegan de la página del negocio (ReservationSyncService los trae de Lantify
// Cloud). En la caja:
//   PENDING  → aceptar (se crea la comanda y va a cocina) o rechazar (con motivo)
//   ACCEPTED → listo (para recoger) / en camino (domicilio)
//   READY    → cobrar: queda como venta del arqueo abierto, con su medio de pago
// Cada cambio se sube a la nube y el cliente lo ve en el enlace de su pedido.
// Los del kiosco del local (canal KIOSK, Fase 4) siguen el mismo camino en la caja
// pero nunca se suben a la nube.

import { prisma } from '../../infrastructure/database/prisma';
import { AuditLogger } from '../../infrastructure/services/AuditLogger';
import { BookingError } from './ReservationUseCases';
import { OrderUseCases } from './OrderUseCases';
import type { SaleUseCases } from './SaleUseCases';

export interface OrderLineView {
  id: string;
  name: string;
  price: number;
  qty: number;
  note: string | null;
}

const OPEN = ['PENDING', 'ACCEPTED', 'READY'];
// La venta guarda el medio de pago con el vocabulario de la caja
const SALE_PAYMENT: Record<string, string> = { CASH: 'CASH', CARD: 'CARD', NEQUI: 'NEQUI', DAVIPLATA: 'DAVIPLATA', TRANSFER: 'TRANSFER' };

const isKiosk = (o: { channel?: string | null }) => o.channel === 'KIOSK';
/** Pedido desde la mesa (Fase 4): lo atiende el mesero en Mesas (TableOrderUseCases), no esta bandeja */
const NOT_TABLE = { kind: { not: 'TABLE' } };
const isTable = (o: { kind?: string | null }) => o.kind === 'TABLE';

const lines = (raw: string): OrderLineView[] => {
  try {
    const v = JSON.parse(raw);
    return Array.isArray(v) ? v : [];
  } catch {
    return [];
  }
};

/** La mesa del pedido, si aún existe en la caja */
const existingTable = async (id: unknown) =>
  typeof id === 'string' && id && (await prisma.table.findUnique({ where: { id: id.slice(0, 64) }, select: { id: true } })) ? id.slice(0, 64) : null;

export class OnlineOrderUseCases {
  constructor(
    private sales?: SaleUseCases,
    private orders = new OrderUseCases(),
    private afterChange: () => void = () => {},
  ) {}

  private view(o: Awaited<ReturnType<typeof prisma.onlineOrder.findFirst>> & {}) {
    return { ...o, items: lines(o.items) };
  }

  /** Abiertos y los de hoy (o los del día pedido) */
  async list(date?: string) {
    const day = date && /^\d{4}-\d{2}-\d{2}$/.test(date) ? new Date(`${date}T00:00:00`) : new Date(new Date().setHours(0, 0, 0, 0));
    const next = new Date(day.getTime() + 86400000);
    const rows = await prisma.onlineOrder.findMany({
      where: { ...NOT_TABLE, OR: [{ status: { in: OPEN } }, { placedAt: { gte: day, lt: next } }] },
      orderBy: { placedAt: 'desc' },
      take: 200,
    });
    return rows.map((r) => this.view(r));
  }

  async summary() {
    const [pending, open, latest] = await Promise.all([
      prisma.onlineOrder.count({ where: { ...NOT_TABLE, status: 'PENDING' } }),
      prisma.onlineOrder.count({ where: { ...NOT_TABLE, status: { in: OPEN } } }),
      prisma.onlineOrder.findFirst({ where: NOT_TABLE, orderBy: { placedAt: 'desc' }, select: { id: true, code: true, customerName: true, total: true, kind: true } }),
    ]);
    return { pending, open, latest: latest?.id || '', latestOrder: latest };
  }

  private async get(id: string) {
    const o = await prisma.onlineOrder.findUnique({ where: { id } });
    if (!o || isTable(o)) throw new BookingError(404, 'ORDER_NOT_FOUND', 'El pedido no existe.');
    return o;
  }

  private async setStatus(id: string, status: string, data: Record<string, unknown> = {}) {
    const current = await prisma.onlineOrder.findUnique({ where: { id }, select: { channel: true } });
    const updated = await prisma.onlineOrder.update({ where: { id }, data: { status, dirty: !current || !isKiosk(current), ...data } });
    this.afterChange();
    return this.view(updated);
  }

  /** Aceptar: la comanda va a cocina con los productos del pedido */
  async accept(id: string, actor: string, eta?: string) {
    const o = await this.get(id);
    if (o.status !== 'PENDING') throw new BookingError(409, 'ORDER_BAD_STATUS', 'El pedido ya fue atendido.');
    const items = await this.resolveVariants(lines(o.items), 'ORDER_ITEM_MISSING');
    const label = o.kind === 'DELIVERY' ? 'Domicilio' : 'Para recoger';
    const kitchen = await this.orders.saveOrder({
      channel: isKiosk(o) ? 'KIOSK' : 'WEB',
      customerId: o.customerId || undefined,
      userName: actor,
      notes: (isKiosk(o)
        ? [`Kiosco ${o.code.split('-')[0]} · ${o.customerName}`, o.notes]
        : [`Pedido web ${o.code} · ${label} · ${o.customerName}`, o.address, o.notes]).filter(Boolean).join(' · '),
      items: items.map((l) => ({ productVariantId: l.id, quantity: l.qty, unitPrice: l.price, notes: l.note || undefined, status: 'SENT' })),
    });
    AuditLogger.log({ action: 'ONLINE_ORDER_ACCEPTED', entityType: 'ORDER', entityId: id, details: { code: o.code, by: actor } });
    return this.setStatus(id, 'ACCEPTED', { kitchenOrderId: kitchen?.id ?? null, acceptedBy: actor, statusNote: eta ? String(eta).slice(0, 80) : null });
  }

  async reject(id: string, reason: string, actor: string) {
    const o = await this.get(id);
    if (!OPEN.includes(o.status)) throw new BookingError(409, 'ORDER_BAD_STATUS', 'El pedido ya está cerrado.');
    const note = String(reason || '').trim().slice(0, 200);
    if (note.length < 3) throw new BookingError(400, 'ORDER_REASON_REQUIRED', 'Escribe el motivo: el cliente lo verá.');
    if (o.kitchenOrderId) await prisma.order.updateMany({ where: { id: o.kitchenOrderId }, data: { status: 'CANCELLED' } });
    AuditLogger.log({ action: 'ONLINE_ORDER_REJECTED', entityType: 'ORDER', entityId: id, details: { code: o.code, by: actor, reason: note } });
    return this.setStatus(id, o.status === 'PENDING' ? 'REJECTED' : 'CANCELLED', { statusNote: note });
  }

  /** Listo para recoger / salió el domicilio */
  async ready(id: string) {
    const o = await this.get(id);
    if (o.status !== 'ACCEPTED') throw new BookingError(409, 'ORDER_BAD_STATUS', 'Primero acepta el pedido.');
    return this.setStatus(id, 'READY');
  }

  /** Cobrar: venta del arqueo abierto (el domicilio no hace parte de la venta: es del domiciliario) */
  async complete(id: string, actor: string) {
    if (!this.sales) throw new Error('Ventas no disponibles');
    const o = await this.get(id);
    if (!['ACCEPTED', 'READY'].includes(o.status)) throw new BookingError(409, 'ORDER_BAD_STATUS', 'Primero acepta el pedido.');
    const session = await prisma.cashSession.findFirst({ where: { status: 'OPEN' }, orderBy: { openedAt: 'desc' } });
    if (!session) throw new BookingError(409, 'CASH_SESSION_REQUIRED', 'Abre la caja para cobrar el pedido.');
    const items = await this.resolveVariants(lines(o.items));
    const amount = items.reduce((n, l) => n + l.price * l.qty, 0);
    const method = SALE_PAYMENT[o.paymentMethod] || 'CASH';
    const sale: any = await this.sales.createSale({
      cashSessionId: session.id,
      customerId: o.customerId || undefined,
      customerName: o.customerName,
      channel: isKiosk(o) ? 'KIOSK' : 'WEB',
      items: items.map((l) => ({ productVariantId: l.id, quantity: l.qty, unitPrice: l.price, notes: l.note || undefined })),
      paymentMethod: method as any,
      payments: [{ method, amount }],
      cashierName: actor,
      idempotencyKey: `online-${o.id}`,
      notes: isKiosk(o) ? `Kiosco ${o.code.split('-')[0]}` : `Pedido web ${o.code}${o.deliveryFee ? ` · domicilio ${o.deliveryFee} aparte` : ''}`,
    });
    await prisma.sale.update({
      where: { id: sale.id },
      data: isKiosk(o) ? { deliveryNotes: o.notes } : { customerPhone: o.customerPhone, customerAddress: o.address || 'Para recoger en el local', deliveryNotes: o.notes },
    });
    if (o.kitchenOrderId) await prisma.order.updateMany({ where: { id: o.kitchenOrderId }, data: { status: 'COMPLETED' } });
    AuditLogger.log({ action: 'ONLINE_ORDER_COMPLETED', entityType: 'ORDER', entityId: id, details: { code: o.code, by: actor, saleId: sale.id } });
    return this.setStatus(id, 'COMPLETED', { saleId: sale.id });
  }

  /**
   * La página guarda el id de la presentación que había al publicar. Si el producto se editó
   * y la presentación cambió de id, se busca por su nombre ("Producto · Presentación");
   * si ya no existe en la caja, se avisa cuál falta en vez de fallar la venta.
   */
  async resolveVariants(items: OrderLineView[], code = 'ORDER_PRODUCT_MISSING'): Promise<OrderLineView[]> {
    const found = new Set(
      (await prisma.productVariant.findMany({ where: { id: { in: items.map((l) => l.id) } }, select: { id: true } })).map((v) => v.id),
    );
    const missing: string[] = [];
    const out: OrderLineView[] = [];
    for (const l of items) {
      if (found.has(l.id)) { out.push(l); continue; }
      const [productName, variantName] = String(l.name || '').split(' · ').map((s) => s.trim());
      const candidates = productName
        ? await prisma.productVariant.findMany({
            where: { isActive: true, product: { name: productName, isActive: true } },
            select: { id: true, name: true },
          })
        : [];
      const match = variantName
        ? candidates.find((v) => v.name.trim().toLowerCase() === variantName.toLowerCase())
        : candidates.length === 1 ? candidates[0] : undefined;
      if (match) out.push({ ...l, id: match.id });
      else missing.push(l.name || l.id);
    }
    if (missing.length) {
      throw new BookingError(409, code, code === 'ORDER_ITEM_MISSING'
        ? `Ya no existe en la carta: ${missing.join(', ')}. Rechaza el pedido o llama al cliente.`
        : `No se puede cobrar: ${missing.join(', ')} ya no existe en la caja. Vuelve a crearlo o rechaza el pedido.`, { missing });
    }
    return out;
  }

  // ── Sincronización (ReservationSyncService) ───────────────
  async dirty() {
    // Los del kiosco no existen en la nube: nunca se suben
    return prisma.onlineOrder.findMany({ where: { dirty: true, channel: { not: 'KIOSK' } }, take: 300, orderBy: { updatedAt: 'asc' } });
  }

  async markClean(rows: { id: string; updatedAt: Date }[]) {
    for (const r of rows) await prisma.onlineOrder.updateMany({ where: { id: r.id, updatedAt: r.updatedAt }, data: { dirty: false } });
  }

  /** Un pedido nuevo de la página; quien pidió queda en Clientes (lo autorizó al pedir) */
  async importFromCloud(o: any, customerFor: (r: any) => Promise<string | null>): Promise<boolean> {
    if (!o?.id || !o.customerName || (await prisma.onlineOrder.findUnique({ where: { id: o.id } }))) return false;
    // Pedido desde la mesa: sin datos personales (no crea cliente)
    const customerId = o.kind === 'TABLE' ? null : await customerFor({ customerName: o.customerName, customerPhone: o.customerPhone, consentAt: o.consentAt, consentVersion: o.consentVersion, marketingOptIn: o.marketingOptIn });
    await prisma.onlineOrder.create({
      data: {
        id: String(o.id).slice(0, 64),
        code: String(o.code).slice(0, 12),
        kind: o.kind === 'PICKUP' ? 'PICKUP' : o.kind === 'TABLE' ? 'TABLE' : 'DELIVERY',
        status: o.status === 'PENDING' ? 'PENDING' : String(o.status),
        customerId,
        customerName: String(o.customerName).slice(0, 120),
        customerPhone: o.customerPhone || null,
        address: o.address || null,
        notes: o.notes || null,
        paymentMethod: String(o.payment || 'CASH'),
        items: JSON.stringify(Array.isArray(o.items) ? o.items : []),
        subtotal: Number(o.subtotal) || 0,
        deliveryFee: Number(o.deliveryFee) || 0,
        total: Number(o.total) || 0,
        placedAt: o.createdAt ? new Date(o.createdAt) : new Date(),
        ...(o.kind === 'TABLE' ? { tableId: await existingTable(o.tableId), tableLabel: typeof o.tableLabel === 'string' ? o.tableLabel.slice(0, 20) : null } : {}),
      },
    });
    return true;
  }
}
