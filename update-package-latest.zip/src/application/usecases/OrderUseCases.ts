// ============================================
// APPLICATION USE CASES - Order (Comandas en Servidor)
// ============================================

import { KITCHEN_STATES } from '../../domain/v3/kitchen';
import { prisma } from '../../infrastructure/database/prisma';
import { AuditLogger } from '../../infrastructure/services/AuditLogger';
import { dayPrefix, nextDocumentNumber, retryOnDuplicateNumber } from '../../domain/documentNumbers';
import { normalizeNames } from '../../domain/v3/features';

export interface OrderItemInput {
  productVariantId: string;
  variantId?: string; // alias usado por versiones anteriores de la interfaz
  clientItemId?: string;
  quantity: number;
  unitPrice: number;
  notes?: string;
  status?: string;
  roundNumber?: number;
  sentAt?: string;
  /** Ingredientes quitados ("sin cebolla") */
  removed?: string[];
}

const ACTIVE_ORDER_STATUSES = ['ACTIVE', 'SENT', 'IN_PREP', 'READY'];

/** Normaliza los estados que envía la interfaz al vocabulario del servidor. */
/** Personas en la mesa: 1 a 99 */
const cleanGuests = (v: unknown) => { const n = Math.round(Number(v)); return Number.isFinite(n) && n >= 1 && n <= 99 ? n : null; };
const cleanLabel = (v: unknown) => (typeof v === 'string' && v.trim() ? v.trim().replace(/\s+/g, ' ').slice(0, 80) : null);

const normalizeItemStatus = (status?: string) => {
  if (!status || status === 'DRAFT') return 'DRAFT';
  if (status === 'SENT_TO_KITCHEN' || status === 'SENT') return 'SENT';
  if (['IN_PREP', 'READY', 'SERVED'].includes(status)) return status;
  return 'DRAFT';
};

export interface SaveOrderInput {
  guests?: number | null;
  label?: string | null;
  orderId?: string;
  tableId?: string;
  customerId?: string;
  channel?: string;
  notes?: string;
  userId?: string;
  userName?: string;
  items: OrderItemInput[];
}

export class OrderUseCases {
  /** Busca una línea por su id del servidor o por el id que le dio el equipo que la creó. */
  private async findActiveItem(itemId: string) {
    return prisma.orderItem.findFirst({
      where: { OR: [{ id: itemId }, { clientItemId: itemId }], isCancelled: false },
      include: { order: true },
      orderBy: { createdAt: 'desc' },
    });
  }

  /**
   * Obtiene todas las comandas/pedidos activos (no completados ni cancelados).
   */
  async getActiveOrders() {
    return prisma.order.findMany({
      where: {
        status: { in: ['ACTIVE', 'SENT', 'IN_PREP', 'READY'] }
      },
      include: {
        table: true,
        customer: true,
        items: {
          include: {
            productVariant: {
              include: {
                product: true
              }
            }
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    });
  }

  /**
   * Obtiene la comanda activa de una mesa específica.
   */
  async getActiveOrderByTable(tableId: string) {
    return prisma.order.findFirst({
      where: {
        tableId,
        status: { in: ['ACTIVE', 'SENT', 'IN_PREP', 'READY'] }
      },
      include: {
        table: true,
        customer: true,
        items: {
          include: {
            productVariant: {
              include: {
                product: true
              }
            }
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    });
  }

  /**
   * Guarda o actualiza una comanda en el servidor (persistencia real multi-dispositivo).
   */
  async saveOrder(data: SaveOrderInput) {
    const channel = data.channel || (data.tableId ? 'POS' : 'COUNTER');

    // 1. Si se provee tableId, buscar si ya existe una orden activa para la mesa
    let existingOrder = data.orderId 
      ? await prisma.order.findUnique({ where: { id: data.orderId }, include: { items: true } })
      : (data.tableId 
          ? await prisma.order.findFirst({
              where: { tableId: data.tableId, status: { in: ['ACTIVE', 'SENT', 'IN_PREP', 'READY'] } },
              include: { items: true }
            })
          : null);

    const items = (data.items || [])
      .map((it) => ({ ...it, productVariantId: it.productVariantId || it.variantId || '' }))
      .filter((it) => it.productVariantId && it.quantity > 0);
    if (items.length !== (data.items || []).length) {
      throw new Error('La comanda tiene productos sin variante o con cantidad inválida');
    }
    const total = items.reduce((sum, it) => sum + (it.quantity * it.unitPrice), 0);

    // Si otra caja tomó el mismo consecutivo al mismo tiempo, la transacción se repite completa
    return retryOnDuplicateNumber('orderNumber', (attempt) => prisma.$transaction(async (tx) => {
      let order;

      if (existingOrder) {
        // Actualizar cabecera de la orden e incrementar versión
        order = await tx.order.update({
          where: { id: existingOrder.id },
          data: {
            customerId: data.customerId || existingOrder.customerId,
            notes: data.notes ?? existingOrder.notes,
            ...(data.guests !== undefined ? { guests: cleanGuests(data.guests) } : {}),
            ...(data.label !== undefined ? { label: cleanLabel(data.label) } : {}),
            total,
            version: { increment: 1 },
          }
        });

        // El equipo que edita la comanda envía la lista completa de líneas activas.
        // Las que ya existen se actualizan en su sitio (conservan identidad y hora de envío);
        // las que ya no vienen se quitan. Las anuladas se conservan para la trazabilidad.
      } else {
        // Crear orden nueva con el consecutivo del día
        const now = new Date();
        const last = await tx.order.findFirst({
          where: { orderNumber: { startsWith: dayPrefix('ORD', now) } },
          orderBy: { createdAt: 'desc' },
          select: { orderNumber: true },
        });
        order = await tx.order.create({
          data: {
            orderNumber: nextDocumentNumber('ORD', now, last?.orderNumber, attempt),
            tableId: data.tableId || null,
            customerId: data.customerId || null,
            userId: data.userId || null,
            userName: data.userName || null,
            channel,
            status: 'ACTIVE',
            notes: data.notes || null,
            guests: cleanGuests(data.guests),
            label: cleanLabel(data.label),
            total,
            version: 1
          }
        });

        // Si es mesa, asegurar que su estado cambie a OCCUPIED / ORDERED
        if (data.tableId) {
          await tx.table.update({
            where: { id: data.tableId },
            data: { status: 'ORDERED' }
          }).catch(() => {});
        }
      }

      // Líneas vigentes: actualizar las conocidas, crear las nuevas, quitar las que ya no vienen
      const current = existingOrder ? existingOrder.items.filter((i) => !i.isCancelled) : [];
      const byClientId = new Map(current.filter((i) => i.clientItemId).map((i) => [i.clientItemId as string, i]));
      const kept = new Set<string>();
      const now = new Date(); // la hora de envío la pone el servidor, no el equipo
      let newRound = false;
      for (const it of items) {
        const status = normalizeItemStatus(it.status);
        const removed = normalizeNames(it.removed);
        const known = it.clientItemId ? byClientId.get(it.clientItemId) : undefined;
        const fields = {
          productVariantId: it.productVariantId,
          quantity: it.quantity,
          unitPrice: it.unitPrice,
          total: it.quantity * it.unitPrice,
          notes: it.notes || null,
          removed: removed.length ? JSON.stringify(removed) : null,
          status,
          roundNumber: status === 'DRAFT' ? null : it.roundNumber ?? null,
        };
        if (known && !kept.has(known.id)) {
          kept.add(known.id);
          const firstSend = status !== 'DRAFT' && !known.sentAt;
          if (firstSend) newRound = true;
          // Lo que la cocina marcó listo o el mesero entregó se conserva aunque el equipo lo mande como "enviado"
          const kitchen = status !== 'DRAFT' && KITCHEN_STATES.includes(known.status);
          await tx.orderItem.update({
            where: { id: known.id },
            data: { ...fields, ...(kitchen ? { status: known.status } : {}), sentAt: status === 'DRAFT' ? null : known.sentAt ?? now },
          });
        } else {
          if (status !== 'DRAFT') newRound = true;
          await tx.orderItem.create({
            data: { ...fields, orderId: order.id, clientItemId: it.clientItemId || null, sentAt: status === 'DRAFT' ? null : now },
          });
        }
      }
      const gone = current.filter((i) => !kept.has(i.id)).map((i) => i.id);
      if (gone.length) await tx.orderItem.deleteMany({ where: { id: { in: gone } } });

      // Otra ronda después de pedir la cuenta: la mesa vuelve a estar en consumo
      if (existingOrder && newRound && existingOrder.billRequestedAt) {
        await tx.order.update({ where: { id: order.id }, data: { billRequestedAt: null } });
        if (order.tableId) {
          await tx.table.updateMany({ where: { id: order.tableId, status: 'PENDING' }, data: { status: 'ORDERED' } });
        }
      }
      // Comandas anteriores a la 3.0 sin mesero: lo toma quien la edita
      if (existingOrder && !existingOrder.userId && data.userId) {
        await tx.order.update({ where: { id: order.id }, data: { userId: data.userId, userName: data.userName || null } });
      }

      // La comanda pasa a "enviada" cuando tiene algo en cocina
      if (items.some((it) => normalizeItemStatus(it.status) !== 'DRAFT') && order.status === 'ACTIVE') {
        await tx.order.update({ where: { id: order.id }, data: { status: 'SENT' } });
      }

      return tx.order.findUnique({
        where: { id: order.id },
        include: {
          table: true,
          customer: true,
          items: {
            include: {
              productVariant: {
                include: { product: true }
              }
            }
          }
        }
      });
    }));
  }

  /**
   * Marca los items en borrador como enviados a cocina.
   */
  async sendToKitchen(orderId: string, userId?: string, userName?: string) {
    const order = await prisma.order.findUnique({
      where: { id: orderId },
      include: { items: true, table: true }
    });

    if (!order) throw new Error('Comanda no encontrada');

    // Marcar items en DRAFT a SENT
    await prisma.orderItem.updateMany({
      where: {
        orderId,
        status: 'DRAFT'
      },
      data: {
        status: 'SENT'
      }
    });

    // Actualizar estado general de la comanda
    const updated = await prisma.order.update({
      where: { id: orderId },
      data: {
        status: 'SENT',
        version: { increment: 1 }
      },
      include: {
        table: true,
        customer: true,
        items: {
          include: {
            productVariant: {
              include: { product: true }
            }
          }
        }
      }
    });

    // Registrar en auditoría
    AuditLogger.log({
      action: 'ORDER_SENT_TO_KITCHEN',
      entityType: 'ORDER',
      entityId: orderId,
      userId,
      userName,
      details: {
        orderNumber: order.orderNumber,
        tableNumber: order.table?.number || 'Mostrador',
        itemsCount: order.items.length
      }
    });

    return updated;
  }

  /**
   * Anula un item de la comanda con motivo obligatorio y registro en auditoría.
   */
  async cancelOrderItem(itemId: string, reason: string, userId?: string, userName?: string) {
    const item = await this.findActiveItem(itemId);

    if (!item) throw new Error('Item de comanda no encontrado');
    if (item.isCancelled) throw new Error('El item ya se encuentra anulado');

    await prisma.orderItem.update({
      where: { id: item.id },
      data: {
        isCancelled: true,
        status: 'CANCELLED',
        cancellationReason: reason,
        cancelledAt: new Date(),
        cancelledBy: userName || userId || 'Usuario'
      }
    });

    // Recalcular total de la comanda
    const activeItems = await prisma.orderItem.findMany({
      where: { orderId: item.orderId, isCancelled: false }
    });
    const newTotal = activeItems.reduce((s, it) => s + it.total, 0);

    await prisma.order.update({
      where: { id: item.orderId },
      data: {
        total: newTotal,
        version: { increment: 1 }
      }
    });

    // Auditoría
    AuditLogger.log({
      action: 'ORDER_ITEM_CANCELLED',
      entityType: 'ORDER_ITEM',
      entityId: itemId,
      userId,
      userName,
      details: {
        orderId: item.orderId,
        reason,
        productVariantId: item.productVariantId
      }
    });

    return prisma.order.findUnique({
      where: { id: item.orderId },
      include: {
        table: true,
        items: {
          include: {
            productVariant: {
              include: { product: true }
            }
          }
        }
      }
    });
  }

  /**
   * Anula parcialmente (o totalmente) unidades de un item de comanda con motivo y auditoría.
   */
  async cancelOrderItemPartial(
    itemId: string,
    quantityToCancel: number,
    reason: string,
    comments?: string,
    userId?: string,
    userName?: string,
    wasteDestination?: 'waste' | 'restock'
  ) {
    const item = await this.findActiveItem(itemId);

    if (!item) throw new Error('Item de comanda no encontrado');
    if (item.isCancelled) throw new Error('El item ya se encuentra anulado');
    if (quantityToCancel <= 0) throw new Error('La cantidad a cancelar debe ser mayor a 0');

    const fullReason = comments ? `${reason} - ${comments}` : reason;
    const authorizer = userName || userId || 'Administrador';

    if (quantityToCancel >= item.quantity) {
      // Cancelación completa
      await prisma.orderItem.update({
        where: { id: item.id },
        data: {
          isCancelled: true,
          status: 'CANCELLED',
          cancellationReason: fullReason,
          cancelledAt: new Date(),
          cancelledBy: authorizer
        }
      });
    } else {
      // Cancelación parcial: reducir cantidad activa
      const remainingQty = item.quantity - quantityToCancel;
      const newSubtotal = remainingQty * item.unitPrice;
      const cancellationNote = `[Anulado -${quantityToCancel}x por ${authorizer}: ${fullReason}]`;
      const updatedNotes = item.notes ? `${item.notes} | ${cancellationNote}` : cancellationNote;

      await prisma.orderItem.update({
        where: { id: item.id },
        data: {
          quantity: remainingQty,
          total: newSubtotal,
          notes: updatedNotes
        }
      });
    }

    // El inventario se descuenta al cobrar, no al comandar: un producto anulado antes del
    // cobro nunca salió del stock, así que "reintegrar" no suma nada (antes inflaba el inventario).
    // El destino (merma o reintegro) queda en la auditoría.

    // Recalcular total de la comanda
    const activeItems = await prisma.orderItem.findMany({
      where: { orderId: item.orderId, isCancelled: false }
    });
    const newTotal = activeItems.reduce((s, it) => s + it.total, 0);

    await prisma.order.update({
      where: { id: item.orderId },
      data: {
        total: newTotal,
        version: { increment: 1 }
      }
    });

    // Auditoría
    AuditLogger.log({
      action: 'ORDER_ITEM_PARTIAL_CANCELLED',
      entityType: 'ORDER_ITEM',
      entityId: itemId,
      userId,
      userName: authorizer,
      details: {
        orderId: item.orderId,
        productVariantId: item.productVariantId,
        cancelledQuantity: quantityToCancel,
        originalQuantity: item.quantity,
        remainingQuantity: Math.max(0, item.quantity - quantityToCancel),
        reason,
        comments,
        wasteDestination: wasteDestination || 'waste'
      }
    });

    return prisma.order.findUnique({
      where: { id: item.orderId },
      include: {
        table: true,
        items: {
          include: {
            productVariant: {
              include: { product: true }
            }
          }
        }
      }
    });
  }

  /**
   * Cierra una comanda cuando se paga o se cancela.
   */
  /**
   * Cierra una comanda. Acepta el id de la comanda o el id de la mesa
   * (el POS cierra "la comanda activa de la mesa X").
   */
  async closeOrder(orderIdOrTableId: string, status: 'COMPLETED' | 'CANCELLED' = 'COMPLETED') {
    const byId = await prisma.order.findUnique({ where: { id: orderIdOrTableId } });
    if (byId) {
      return prisma.order.update({
        where: { id: byId.id },
        data: { status, version: { increment: 1 } }
      });
    }

    const active = await prisma.order.findMany({
      where: { tableId: orderIdOrTableId, status: { in: ['ACTIVE', 'SENT', 'IN_PREP', 'READY'] } },
      select: { id: true },
    });
    if (active.length === 0) {
      throw new Error('No hay una comanda activa para cerrar');
    }
    await prisma.order.updateMany({
      where: { id: { in: active.map(o => o.id) } },
      data: { status, version: { increment: 1 } },
    });
    return { closed: active.length, status };
  }
}
