// ============================================
// APPLICATION USE CASES - Order (Comandas en Servidor)
// ============================================

import { prisma } from '../../infrastructure/database/prisma';
import { AuditLogger } from '../../infrastructure/services/AuditLogger';

export interface OrderItemInput {
  productVariantId: string;
  variantId?: string; // alias usado por versiones anteriores de la interfaz
  clientItemId?: string;
  quantity: number;
  unitPrice: number;
  notes?: string;
  status?: string;
  roundNumber?: number;
  sentAt?: string;
}

const ACTIVE_ORDER_STATUSES = ['ACTIVE', 'SENT', 'IN_PREP', 'READY'];

/** Normaliza los estados que envía la interfaz al vocabulario del servidor. */
const normalizeItemStatus = (status?: string) => {
  if (!status || status === 'DRAFT') return 'DRAFT';
  if (status === 'SENT_TO_KITCHEN' || status === 'SENT') return 'SENT';
  if (['IN_PREP', 'READY', 'SERVED'].includes(status)) return status;
  return 'DRAFT';
};

export interface SaveOrderInput {
  orderId?: string;
  tableId?: string;
  customerId?: string;
  channel?: string;
  notes?: string;
  userId?: string;
  userName?: string;
  items: OrderItemInput[];
}

export class OrderUseCases {
  /** Busca una línea por su id del servidor o por el id que le dio el equipo que la creó. */
  private async findActiveItem(itemId: string) {
    return prisma.orderItem.findFirst({
      where: { OR: [{ id: itemId }, { clientItemId: itemId }], isCancelled: false },
      include: { order: true },
      orderBy: { createdAt: 'desc' },
    });
  }

  /**
   * Obtiene todas las comandas/pedidos activos (no completados ni cancelados).
   */
  async getActiveOrders() {
    return prisma.order.findMany({
      where: {
        status: { in: ['ACTIVE', 'SENT', 'IN_PREP', 'READY'] }
      },
      include: {
        table: true,
        customer: true,
        items: {
          include: {
            productVariant: {
              include: {
                product: true
              }
            }
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    });
  }

  /**
   * Obtiene la comanda activa de una mesa específica.
   */
  async getActiveOrderByTable(tableId: string) {
    return prisma.order.findFirst({
      where: {
        tableId,
        status: { in: ['ACTIVE', 'SENT', 'IN_PREP', 'READY'] }
      },
      include: {
        table: true,
        customer: true,
        items: {
          include: {
            productVariant: {
              include: {
                product: true
              }
            }
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    });
  }

  /**
   * Guarda o actualiza una comanda en el servidor (persistencia real multi-dispositivo).
   */
  async saveOrder(data: SaveOrderInput) {
    const channel = data.channel || (data.tableId ? 'POS' : 'COUNTER');

    // 1. Si se provee tableId, buscar si ya existe una orden activa para la mesa
    let existingOrder = data.orderId 
      ? await prisma.order.findUnique({ where: { id: data.orderId }, include: { items: true } })
      : (data.tableId 
          ? await prisma.order.findFirst({
              where: { tableId: data.tableId, status: { in: ['ACTIVE', 'SENT', 'IN_PREP', 'READY'] } },
              include: { items: true }
            })
          : null);

    const now = new Date();
    const orderNumber = existingOrder?.orderNumber || `ORD-${now.getFullYear()}${(now.getMonth() + 1).toString().padStart(2, '0')}${now.getDate().toString().padStart(2, '0')}-${Math.floor(Math.random() * 10000).toString().padStart(4, '0')}`;

    const items = (data.items || [])
      .map((it) => ({ ...it, productVariantId: it.productVariantId || it.variantId || '' }))
      .filter((it) => it.productVariantId && it.quantity > 0);
    if (items.length !== (data.items || []).length) {
      throw new Error('La comanda tiene productos sin variante o con cantidad inválida');
    }
    const total = items.reduce((sum, it) => sum + (it.quantity * it.unitPrice), 0);

    return prisma.$transaction(async (tx) => {
      let order;

      if (existingOrder) {
        // Actualizar cabecera de la orden e incrementar versión
        order = await tx.order.update({
          where: { id: existingOrder.id },
          data: {
            customerId: data.customerId || existingOrder.customerId,
            notes: data.notes ?? existingOrder.notes,
            total,
            version: { increment: 1 },
          }
        });

        // El equipo que edita la comanda envía la lista completa de líneas activas:
        // se reemplazan todas las vigentes. Las anuladas se conservan para la trazabilidad.
        await tx.orderItem.deleteMany({
          where: {
            orderId: order.id,
            isCancelled: false
          }
        });
      } else {
        // Crear orden nueva
        order = await tx.order.create({
          data: {
            orderNumber,
            tableId: data.tableId || null,
            customerId: data.customerId || null,
            userId: data.userId || null,
            userName: data.userName || null,
            channel,
            status: 'ACTIVE',
            notes: data.notes || null,
            total,
            version: 1
          }
        });

        // Si es mesa, asegurar que su estado cambie a OCCUPIED / ORDERED
        if (data.tableId) {
          await tx.table.update({
            where: { id: data.tableId },
            data: { status: 'ORDERED' }
          }).catch(() => {});
        }
      }

      // Crear las líneas vigentes
      for (const it of items) {
        const status = normalizeItemStatus(it.status);
        await tx.orderItem.create({
          data: {
            orderId: order.id,
            productVariantId: it.productVariantId,
            clientItemId: it.clientItemId || null,
            quantity: it.quantity,
            unitPrice: it.unitPrice,
            total: it.quantity * it.unitPrice,
            notes: it.notes || null,
            status,
            roundNumber: status === 'DRAFT' ? null : it.roundNumber ?? null,
            sentAt: status === 'DRAFT' ? null : it.sentAt ? new Date(it.sentAt) : new Date(),
          }
        });
      }

      // La comanda pasa a "enviada" cuando tiene algo en cocina
      if (items.some((it) => normalizeItemStatus(it.status) !== 'DRAFT') && order.status === 'ACTIVE') {
        await tx.order.update({ where: { id: order.id }, data: { status: 'SENT' } });
      }

      return tx.order.findUnique({
        where: { id: order.id },
        include: {
          table: true,
          customer: true,
          items: {
            include: {
              productVariant: {
                include: { product: true }
              }
            }
          }
        }
      });
    });
  }

  /**
   * Marca los items en borrador como enviados a cocina.
   */
  async sendToKitchen(orderId: string, userId?: string, userName?: string) {
    const order = await prisma.order.findUnique({
      where: { id: orderId },
      include: { items: true, table: true }
    });

    if (!order) throw new Error('Comanda no encontrada');

    // Marcar items en DRAFT a SENT
    await prisma.orderItem.updateMany({
      where: {
        orderId,
        status: 'DRAFT'
      },
      data: {
        status: 'SENT'
      }
    });

    // Actualizar estado general de la comanda
    const updated = await prisma.order.update({
      where: { id: orderId },
      data: {
        status: 'SENT',
        version: { increment: 1 }
      },
      include: {
        table: true,
        customer: true,
        items: {
          include: {
            productVariant: {
              include: { product: true }
            }
          }
        }
      }
    });

    // Registrar en auditoría
    AuditLogger.log({
      action: 'ORDER_SENT_TO_KITCHEN',
      entityType: 'ORDER',
      entityId: orderId,
      userId,
      userName,
      details: {
        orderNumber: order.orderNumber,
        tableNumber: order.table?.number || 'Mostrador',
        itemsCount: order.items.length
      }
    });

    return updated;
  }

  /**
   * Anula un item de la comanda con motivo obligatorio y registro en auditoría.
   */
  async cancelOrderItem(itemId: string, reason: string, userId?: string, userName?: string) {
    const item = await this.findActiveItem(itemId);

    if (!item) throw new Error('Item de comanda no encontrado');
    if (item.isCancelled) throw new Error('El item ya se encuentra anulado');

    await prisma.orderItem.update({
      where: { id: item.id },
      data: {
        isCancelled: true,
        status: 'CANCELLED',
        cancellationReason: reason,
        cancelledAt: new Date(),
        cancelledBy: userName || userId || 'Usuario'
      }
    });

    // Recalcular total de la comanda
    const activeItems = await prisma.orderItem.findMany({
      where: { orderId: item.orderId, isCancelled: false }
    });
    const newTotal = activeItems.reduce((s, it) => s + it.total, 0);

    await prisma.order.update({
      where: { id: item.orderId },
      data: {
        total: newTotal,
        version: { increment: 1 }
      }
    });

    // Auditoría
    AuditLogger.log({
      action: 'ORDER_ITEM_CANCELLED',
      entityType: 'ORDER_ITEM',
      entityId: itemId,
      userId,
      userName,
      details: {
        orderId: item.orderId,
        reason,
        productVariantId: item.productVariantId
      }
    });

    return prisma.order.findUnique({
      where: { id: item.orderId },
      include: {
        table: true,
        items: {
          include: {
            productVariant: {
              include: { product: true }
            }
          }
        }
      }
    });
  }

  /**
   * Anula parcialmente (o totalmente) unidades de un item de comanda con motivo y auditoría.
   */
  async cancelOrderItemPartial(
    itemId: string,
    quantityToCancel: number,
    reason: string,
    comments?: string,
    userId?: string,
    userName?: string,
    wasteDestination?: 'waste' | 'restock'
  ) {
    const item = await this.findActiveItem(itemId);

    if (!item) throw new Error('Item de comanda no encontrado');
    if (item.isCancelled) throw new Error('El item ya se encuentra anulado');
    if (quantityToCancel <= 0) throw new Error('La cantidad a cancelar debe ser mayor a 0');

    const fullReason = comments ? `${reason} - ${comments}` : reason;
    const authorizer = userName || userId || 'Administrador';

    if (quantityToCancel >= item.quantity) {
      // Cancelación completa
      await prisma.orderItem.update({
        where: { id: item.id },
        data: {
          isCancelled: true,
          status: 'CANCELLED',
          cancellationReason: fullReason,
          cancelledAt: new Date(),
          cancelledBy: authorizer
        }
      });
    } else {
      // Cancelación parcial: reducir cantidad activa
      const remainingQty = item.quantity - quantityToCancel;
      const newSubtotal = remainingQty * item.unitPrice;
      const cancellationNote = `[Anulado -${quantityToCancel}x por ${authorizer}: ${fullReason}]`;
      const updatedNotes = item.notes ? `${item.notes} | ${cancellationNote}` : cancellationNote;

      await prisma.orderItem.update({
        where: { id: item.id },
        data: {
          quantity: remainingQty,
          total: newSubtotal,
          notes: updatedNotes
        }
      });
    }

    // El inventario se descuenta al cobrar, no al comandar: un producto anulado antes del
    // cobro nunca salió del stock, así que "reintegrar" no suma nada (antes inflaba el inventario).
    // El destino (merma o reintegro) queda en la auditoría.

    // Recalcular total de la comanda
    const activeItems = await prisma.orderItem.findMany({
      where: { orderId: item.orderId, isCancelled: false }
    });
    const newTotal = activeItems.reduce((s, it) => s + it.total, 0);

    await prisma.order.update({
      where: { id: item.orderId },
      data: {
        total: newTotal,
        version: { increment: 1 }
      }
    });

    // Auditoría
    AuditLogger.log({
      action: 'ORDER_ITEM_PARTIAL_CANCELLED',
      entityType: 'ORDER_ITEM',
      entityId: itemId,
      userId,
      userName: authorizer,
      details: {
        orderId: item.orderId,
        productVariantId: item.productVariantId,
        cancelledQuantity: quantityToCancel,
        originalQuantity: item.quantity,
        remainingQuantity: Math.max(0, item.quantity - quantityToCancel),
        reason,
        comments,
        wasteDestination: wasteDestination || 'waste'
      }
    });

    return prisma.order.findUnique({
      where: { id: item.orderId },
      include: {
        table: true,
        items: {
          include: {
            productVariant: {
              include: { product: true }
            }
          }
        }
      }
    });
  }

  /**
   * Cierra una comanda cuando se paga o se cancela.
   */
  /**
   * Cierra una comanda. Acepta el id de la comanda o el id de la mesa
   * (el POS cierra "la comanda activa de la mesa X").
   */
  async closeOrder(orderIdOrTableId: string, status: 'COMPLETED' | 'CANCELLED' = 'COMPLETED') {
    const byId = await prisma.order.findUnique({ where: { id: orderIdOrTableId } });
    if (byId) {
      return prisma.order.update({
        where: { id: byId.id },
        data: { status, version: { increment: 1 } }
      });
    }

    const active = await prisma.order.findMany({
      where: { tableId: orderIdOrTableId, status: { in: ['ACTIVE', 'SENT', 'IN_PREP', 'READY'] } },
      select: { id: true },
    });
    if (active.length === 0) {
      throw new Error('No hay una comanda activa para cerrar');
    }
    await prisma.order.updateMany({
      where: { id: { in: active.map(o => o.id) } },
      data: { status, version: { increment: 1 } },
    });
    return { closed: active.length, status };
  }
}
