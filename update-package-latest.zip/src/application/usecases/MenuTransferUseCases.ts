// ============================================
// APPLICATION - Copiar la carta entre sedes (Fase 4 · Varias sedes)
// ============================================
// Exportar: la carta de esta sede como JSON. Importar: primero la vista previa
// (qué se crea y qué cambia) y luego aplicar. Por nombre e idempotente; no toca
// existencias, costos, ventas ni fotos (ver src/domain/menuTransfer.ts).

import crypto from 'crypto';
import { prisma } from '../../infrastructure/database/prisma';
import { normalizeNames } from '../../domain/v3/features';
import {
  LocalMenu, MENU_FORMAT, MENU_VERSION, MenuExport, MenuFileError, MenuPlan, nameKey, parseMenuExport, planIsEmpty, planMenuImport,
} from '../../domain/menuTransfer';

export class MenuTransferError extends Error {
  constructor(public statusCode: number, public code: string, message: string) {
    super(message);
    this.name = 'MenuTransferError';
  }
}

const newSku = (name: string) =>
  `${name.normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-zA-Z0-9]+/g, '').slice(0, 8).toUpperCase() || 'PROD'}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;

export class MenuTransferUseCases {
  private async local(): Promise<LocalMenu> {
    const [categories, products, ingredients] = await Promise.all([
      prisma.category.findMany({ select: { id: true, name: true } }),
      prisma.product.findMany({
        orderBy: { createdAt: 'asc' },
        include: {
          category: { select: { name: true } },
          variants: { select: { id: true, name: true, price: true }, orderBy: { createdAt: 'asc' } },
          recipe: { include: { ingredient: { select: { name: true } } } },
        },
      }),
      prisma.ingredient.findMany({ select: { id: true, name: true } }),
    ]);
    return {
      categories,
      ingredients,
      products: products.map((p) => ({
        id: p.id,
        name: p.name,
        category: p.category?.name ?? null,
        description: p.description?.trim() || null,
        taxType: p.taxType ?? null,
        taxRate: p.taxType ? p.taxRate ?? null : null,
        printStation: p.printStation ?? null,
        ingredients: normalizeNames(p.ingredients),
        isCover: p.isCover,
        variants: p.variants,
        recipe: p.recipe.map((r) => ({ ingredient: r.ingredient.name, quantity: r.quantity, removable: r.removable })),
      })),
    };
  }

  /** La carta activa de esta sede (sin costos, existencias ni fotos) */
  async exportMenu(): Promise<MenuExport> {
    const [settings, categories, products] = await Promise.all([
      prisma.businessSettings.findUnique({ where: { id: 'default' }, select: { businessName: true } }),
      prisma.category.findMany({ where: { isActive: true }, orderBy: { name: 'asc' } }),
      prisma.product.findMany({
        where: { isActive: true },
        orderBy: { name: 'asc' },
        include: {
          category: { select: { name: true } },
          variants: { where: { isActive: true }, orderBy: { createdAt: 'asc' }, select: { name: true, price: true } },
          recipe: { include: { ingredient: { select: { name: true, unit: true } } } },
        },
      }),
    ]);
    return {
      format: MENU_FORMAT,
      version: MENU_VERSION,
      exportedAt: new Date().toISOString(),
      business: settings?.businessName ?? null,
      categories: categories.map((c) => ({ name: c.name, description: c.description ?? null, printStation: c.printStation ?? null })),
      products: products.filter((p) => p.variants.length).map((p) => ({
        name: p.name,
        category: p.category?.name ?? null,
        description: p.description?.trim() || null,
        taxType: p.taxType ?? null,
        taxRate: p.taxType ? p.taxRate ?? null : null,
        printStation: p.printStation ?? null,
        ingredients: normalizeNames(p.ingredients),
        isCover: p.isCover,
        variants: p.variants,
        recipe: p.recipe.map((r) => ({ ingredient: r.ingredient.name, unit: r.ingredient.unit, quantity: r.quantity, removable: r.removable })),
      })),
    };
  }

  private parse(raw: unknown) {
    try {
      return parseMenuExport(raw);
    } catch (e) {
      if (e instanceof MenuFileError) {
        throw new MenuTransferError(400, e.code, e.code === 'MENU_FILE_NEWER'
          ? 'El archivo viene de una versión más nueva de Lantify. Actualiza esta sede primero.'
          : 'El archivo no es una carta exportada desde Lantify.');
      }
      throw e;
    }
  }

  async preview(raw: unknown): Promise<MenuPlan> {
    return planMenuImport(this.parse(raw), await this.local());
  }

  /** Aplica la vista previa en una sola transacción (todo o nada) */
  async apply(raw: unknown): Promise<MenuPlan> {
    const file = this.parse(raw);
    const plan = planMenuImport(file, await this.local());
    if (planIsEmpty(plan)) return plan;
    await prisma.$transaction(async (tx) => {
      const cats = new Map((await tx.category.findMany({ select: { id: true, name: true } })).map((c) => [nameKey(c.name), c.id]));
      for (const c of plan.createCategories) {
        const row = await tx.category.create({ data: { name: c.name, description: c.description, printStation: c.printStation } });
        cats.set(nameKey(c.name), row.id);
      }
      const ings = new Map((await tx.ingredient.findMany({ select: { id: true, name: true } })).map((i) => [nameKey(i.name), i.id]));
      // Insumo nuevo: solo el nombre y la unidad, con existencia 0 (no es un movimiento de inventario)
      for (const i of plan.createIngredients) {
        const row = await tx.ingredient.create({ data: { name: i.name, unit: i.unit } });
        ings.set(nameKey(i.name), row.id);
      }
      const catId = (name: string | null) => (name ? cats.get(nameKey(name)) ?? null : null);
      const upsertRecipe = async (productId: string, lines: MenuPlan['createProducts'][number]['recipe']) => {
        for (const r of lines) {
          const ingredientId = ings.get(nameKey(r.ingredient));
          if (!ingredientId) continue;
          await tx.recipeItem.upsert({
            where: { productId_ingredientId: { productId, ingredientId } },
            update: { quantity: r.quantity, removable: r.removable },
            create: { productId, ingredientId, quantity: r.quantity, removable: r.removable },
          });
        }
      };
      for (const p of plan.createProducts) {
        const row = await tx.product.create({
          data: {
            name: p.name, description: p.description, categoryId: catId(p.category), taxType: p.taxType, taxRate: p.taxRate,
            printStation: p.printStation, ingredients: p.ingredients.length ? JSON.stringify(p.ingredients) : null, isCover: p.isCover,
            variants: { create: p.variants.map((v) => ({ name: v.name, price: v.price, sku: newSku(p.name) })) },
          },
        });
        await upsertRecipe(row.id, p.recipe);
      }
      for (const u of plan.updateProducts) {
        const f = u.fields;
        const data: Record<string, unknown> = {};
        if ('category' in f) data.categoryId = catId(f.category ?? null);
        if ('description' in f) data.description = f.description;
        if ('taxType' in f) { data.taxType = f.taxType; data.taxRate = f.taxRate; }
        if ('printStation' in f) data.printStation = f.printStation;
        if ('ingredients' in f) data.ingredients = f.ingredients?.length ? JSON.stringify(f.ingredients) : null;
        if ('isCover' in f) data.isCover = f.isCover;
        if (Object.keys(data).length) await tx.product.update({ where: { id: u.id }, data });
        for (const v of u.newVariants) await tx.productVariant.create({ data: { productId: u.id, name: v.name, price: v.price, sku: newSku(u.name) } });
        // Solo el precio de venta: existencias y costo quedan como estaban
        for (const p of u.prices) await tx.productVariant.update({ where: { id: p.variantId }, data: { price: p.to } });
        await upsertRecipe(u.id, u.recipe);
      }
    });
    return plan;
  }
}
