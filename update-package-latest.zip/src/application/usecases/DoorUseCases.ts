// ============================================
// APPLICATION - Puerta: cover, manillas y aforo (Fase 4 · 9)
// ============================================
// El portero (rol DOOR, o la caja) marca +1 / −1 o escribe el código de la manilla.
// La ocupación de la noche suma los covers cobrados (productos marcados como Cover)
// y lo que marcó la puerta, contra el aforo de Ajustes. Avisa al 90 %; nunca bloquea
// una venta ni una entrada: el portero decide.

import { prisma } from '../../infrastructure/database/prisma';
import { AuditLogger } from '../../infrastructure/services/AuditLogger';
import { publish } from '../../shared/liveEvents';
import {
  CAPACITY_WARN_PCT, DoorError, capacityLevel, doorStats, nightOf, nightWindow, normalizeWristband, wristbandInside,
} from '../../domain/door';

export interface DoorActor { userId?: string; name?: string; role?: string }

export class DoorUseCases {
  /** Covers cobrados en la noche: cada unidad vendida de un producto Cover */
  private async covers(from: Date, to: Date) {
    const rows = await prisma.saleItem.findMany({
      where: {
        sale: { status: 'COMPLETED', createdAt: { gte: from, lt: to } },
        productVariant: { product: { isCover: true } },
      },
      select: { quantity: true, sale: { select: { createdAt: true } } },
    });
    return rows.map((r) => ({ at: r.sale.createdAt, units: r.quantity }));
  }

  private events(from: Date, to: Date) {
    return prisma.doorEvent.findMany({ where: { at: { gte: from, lt: to } }, orderBy: { at: 'asc' } });
  }

  private async capacity() {
    const row = await prisma.businessSettings.findUnique({ where: { id: 'default' }, select: { maxCapacity: true } });
    return row?.maxCapacity ?? null;
  }

  private async summary(from: Date, to: Date) {
    const [covers, events, capacity] = await Promise.all([this.covers(from, to), this.events(from, to), this.capacity()]);
    const stats = doorStats(covers, events);
    return { stats, events, capacity };
  }

  /** Lo que ve el portero: ocupación en vivo contra el aforo */
  async state(now = new Date()) {
    const { from, to } = nightWindow(now);
    const { stats, events, capacity } = await this.summary(from, to);
    return {
      nightFrom: from.toISOString(),
      capacity,
      warnPct: CAPACITY_WARN_PCT,
      occupancy: stats.occupancy,
      level: capacityLevel(stats.occupancy, capacity),
      entries: stats.entries,
      exits: stats.exits,
      coversSold: stats.coversSold,
      peak: stats.peak,
      recent: events.slice(-8).reverse().map((e) => ({ id: e.id, kind: e.kind, wristband: e.wristband, at: e.at, by: e.by })),
    };
  }

  /** +1 / −1, con o sin manilla. Una manilla que ya está adentro no entra dos veces. */
  async mark(body: { kind?: unknown; wristband?: unknown }, actor: DoorActor) {
    const kind = body.kind === 'OUT' ? 'OUT' : body.kind === 'IN' ? 'IN' : null;
    if (!kind) throw new DoorError('Indica si es una entrada o una salida.', 'DOOR_BAD_KIND');
    const wristband = normalizeWristband(body.wristband);
    if (wristband) {
      const { from, to } = nightWindow(new Date());
      const tonight = await prisma.doorEvent.findMany({ where: { wristband, at: { gte: from, lt: to } }, select: { kind: true, wristband: true, at: true } });
      const inside = wristbandInside(tonight, wristband);
      if (kind === 'IN' && inside) throw new DoorError(`La manilla ${wristband} ya entró esta noche y no ha salido.`, 'WRISTBAND_INSIDE', 409);
    }
    const event = await prisma.doorEvent.create({ data: { kind, wristband, by: actor.name || null, byUserId: actor.userId || null } });
    if (wristband) AuditLogger.log({ action: 'DOOR_WRISTBAND', entityType: 'DOOR', entityId: event.id, userId: actor.userId, userName: actor.name, userRole: actor.role, details: { kind, wristband } });
    publish('door');
    return { event: { id: event.id, kind: event.kind, wristband: event.wristband, at: event.at }, state: await this.state() };
  }

  /** Informe de una noche (la que empieza ese día a mediodía): covers, entradas y pico */
  async report(date?: string) {
    const night = (date && nightOf(date)) || nightWindow(new Date());
    const { stats, capacity } = await this.summary(night.from, night.to);
    return {
      from: night.from.toISOString(),
      to: night.to.toISOString(),
      capacity,
      coversSold: stats.coversSold,
      entries: stats.entries,
      doorEntries: stats.doorEntries,
      exits: stats.exits,
      peak: stats.peak,
      peakAt: stats.peakAt,
      peakPct: capacity ? Math.round((stats.peak * 100) / capacity) : null,
    };
  }
}
