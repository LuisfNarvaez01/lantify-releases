// ============================================
// APPLICATION - Unificar productos sueltos en un producto con variantes
// ============================================
// Muchos negocios crean "Batido de fresa 12 oz", "Batido de fresa 16 oz" y
// "Jugo de mora en agua" / "Jugo de mora en leche" como productos separados.
// Esto los reconoce y los junta en un solo producto con sus presentaciones.
//
// Solo se reconocen terminaciones que de verdad son una presentación (tamaño,
// medida, "en agua/leche", "caliente/frío", "sencillo/doble"…) o un separador
// explícito ("Producto - Grande", "Producto (Grande)"). "Jugo de mora" y "Jugo de
// mango" NO se juntan: son productos distintos.
//
// Al unificar, las presentaciones (con su SKU, precio, costo, inventario e
// historial de ventas) se mueven al producto que queda; los productos vacíos se
// desactivan. Nada se borra.

import { prisma } from '../../infrastructure/database/prisma';
import { AuditLogger } from '../../infrastructure/services/AuditLogger';

const UNIT = String.raw`(?:oz|onz|onzas?|ml|cc|l|lt|lts|litros?|g|gr|grs|gramos?|kg|kilos?|lb|libras?|cm|pulg(?:adas)?|und|unds|unidades?|porciones?|pzs?|piezas?|presas?)`;
const WORDS = [
  'peque[ñn][oa]', 'mediano', 'mediana', 'grande', 'extra ?grande', 'jumbo', 'mini', 'personal', 'familiar', 'mega', 'xl', 'xxl',
  'sencill[oa]', 'doble', 'triple', 'media', 'entera', 'entero', 'porci[oó]n', 'combo', 'solo', 'sola',
  'caliente', 'fr[ií]o', 'fr[ií]a', 'helad[oa]', 'en agua', 'en leche', 'con leche', 'sin az[uú]car', 'light', 'normal', 'regular',
];
/** "12 oz", "1.5 L", "x6", "6 und", "Grande", "en leche" al final del nombre */
const SUFFIX = new RegExp(String.raw`^(.*?\S)\s+((?:x\s?\d+)|(?:\d+(?:[.,]\d+)?\s?${UNIT}\.?)|(?:${WORDS.join('|')}))$`, 'i');
/** "Producto - Grande", "Producto · 16 oz", "Producto / Grande", "Producto (Grande)" */
const PAREN = /^(.{3,}?)\s*\(([^()]{1,24})\)$/;
const SEPARATED = /^(.{3,}?)\s+[-–·\/|]\s+(.{1,24})$/;

const GENERIC = /^(única|unica|default|normal|estándar|estandar|regular)$/i;
const norm = (s: string) => s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
const cap = (s: string) => (s ? s[0].toUpperCase() + s.slice(1) : s);

/** Separa "Batido de fresa 16 oz" en base "Batido de fresa" y presentación "16 oz" */
export const splitVariantName = (name: string): { base: string; label: string } | null => {
  const n = name.trim().replace(/\s+/g, ' ');
  const sep = PAREN.exec(n) || SEPARATED.exec(n);
  if (sep && sep[2].trim()) return { base: sep[1].trim(), label: sep[2].trim() };
  const m = SUFFIX.exec(n);
  if (m && m[1].trim().length >= 3) return { base: m[1].trim(), label: m[2].trim() };
  return null;
};

export interface VariantGroupItem {
  productId: string;
  name: string;
  label: string;
  /** El producto ya se llama como la base (queda como "Normal" si no tiene presentación) */
  isBase: boolean;
  price: number;
  variants: number;
  imageUrl: string | null;
}

export interface VariantGroup {
  key: string;
  base: string;
  categoryId: string | null;
  categoryName: string;
  items: VariantGroupItem[];
}

export class VariantMergeError extends Error {
  constructor(public code: string, message: string) {
    super(message);
  }
}

export class VariantMergeUseCases {
  /** Grupos de productos sueltos que parecen presentaciones del mismo producto */
  async suggestions(): Promise<VariantGroup[]> {
    const products = await prisma.product.findMany({
      where: { isActive: true },
      include: { category: true, variants: { where: { isActive: true }, orderBy: { price: 'asc' } } },
      orderBy: { name: 'asc' },
    });
    const groups = new Map<string, VariantGroup>();
    const byName = new Map<string, (typeof products)[number]>();
    for (const p of products) byName.set(`${p.categoryId || '-'}|${norm(p.name)}`, p);

    const add = (key: string, base: string, p: (typeof products)[number], label: string, isBase: boolean) => {
      let g = groups.get(key);
      if (!g) {
        g = { key, base, categoryId: p.categoryId, categoryName: p.category?.name || 'Sin categoría', items: [] };
        groups.set(key, g);
      }
      if (g.items.some((i) => i.productId === p.id)) return;
      g.items.push({ productId: p.id, name: p.name, label, isBase, price: p.variants[0]?.price ?? 0, variants: p.variants.length, imageUrl: p.imageUrl });
    };

    for (const p of products) {
      if (!p.variants.length) continue;
      const split = splitVariantName(p.name);
      if (!split) continue;
      const key = `${p.categoryId || '-'}|${norm(split.base)}`;
      add(key, cap(split.base), p, split.label, false);
      // Si existe el producto "a secas" (Batido de fresa), entra al grupo como la presentación normal
      const plain = byName.get(key);
      if (plain && plain.id !== p.id && plain.variants.length) {
        const own = plain.variants.length === 1 && !GENERIC.test(plain.variants[0].name.trim()) ? plain.variants[0].name.trim() : 'Normal';
        add(key, plain.name, plain, own, true);
      }
    }
    return [...groups.values()]
      .filter((g) => g.items.length >= 2)
      .map((g) => ({ ...g, items: g.items.sort((a, b) => a.price - b.price) }))
      .sort((a, b) => a.categoryName.localeCompare(b.categoryName, 'es') || a.base.localeCompare(b.base, 'es'));
  }

  /**
   * Une los productos de un grupo en uno solo. `labels` = nombre de la presentación
   * para cada producto (lo que se ve en la caja y en la página: "12 oz", "En leche").
   */
  async merge(input: { base: unknown; productIds: unknown; labels?: unknown }, actor: string) {
    const base = typeof input.base === 'string' ? input.base.trim().replace(/\s+/g, ' ').slice(0, 100) : '';
    const ids = Array.isArray(input.productIds) ? [...new Set(input.productIds.filter((x): x is string => typeof x === 'string'))] : [];
    const labels = (input.labels && typeof input.labels === 'object' ? input.labels : {}) as Record<string, unknown>;
    if (base.length < 2) throw new VariantMergeError('VARIANT_MERGE_BAD_NAME', 'Escribe el nombre del producto.');
    if (ids.length < 2 || ids.length > 20) throw new VariantMergeError('VARIANT_MERGE_FEW', 'Elige al menos dos productos para unir.');

    const products = await prisma.product.findMany({
      where: { id: { in: ids }, isActive: true },
      include: { variants: { where: { isActive: true }, orderBy: { price: 'asc' } } },
    });
    if (products.length !== ids.length) throw new VariantMergeError('VARIANT_MERGE_GONE', 'Algún producto ya no existe o está desactivado.');

    // Se queda el que ya se llama como la base; si no, el que tiene foto, luego el más antiguo
    const master = products.find((p) => norm(p.name) === norm(base))
      || [...products].sort((a, b) => Number(!!b.imageUrl) - Number(!!a.imageUrl) || a.createdAt.getTime() - b.createdAt.getTime())[0];
    const labelOf = (p: (typeof products)[number]) => {
      const l = typeof labels[p.id] === 'string' ? (labels[p.id] as string).trim().slice(0, 40) : '';
      return l || splitVariantName(p.name)?.label || (norm(p.name) === norm(base) ? 'Normal' : p.name);
    };

    const moved = await prisma.$transaction(async (tx) => {
      let count = 0;
      let dup = 0;
      const used = new Set<string>();
      for (const p of products) {
        const label = cap(labelOf(p));
        for (const v of p.variants) {
          // Una sola presentación genérica toma el nombre del producto; si tenía varias, se combinan
          const many = p.variants.length > 1 && !GENERIC.test(v.name.trim());
          let name = many ? `${label} ${v.name.trim()}` : label;
          while (used.has(norm(name))) name = `${name} (${++dup})`;
          used.add(norm(name));
          await tx.productVariant.update({ where: { id: v.id }, data: { name, productId: master.id } });
          count++;
        }
        if (p.id !== master.id) {
          await tx.product.update({ where: { id: p.id }, data: { isActive: false } });
        }
      }
      const donor = products.find((p) => p.imageUrl);
      const describer = products.find((p) => p.description);
      await tx.product.update({
        where: { id: master.id },
        data: {
          name: base,
          imageUrl: master.imageUrl || donor?.imageUrl || null,
          description: master.description || describer?.description || null,
        },
      });
      return count;
    });

    AuditLogger.log({
      action: 'PRODUCTS_MERGED_AS_VARIANTS',
      entityType: 'PRODUCT',
      entityId: master.id,
      details: { by: actor, base, merged: products.map((p) => ({ id: p.id, name: p.name, label: labelOf(p) })) },
    });
    return { productId: master.id, variants: moved, deactivated: products.length - 1 };
  }
}
