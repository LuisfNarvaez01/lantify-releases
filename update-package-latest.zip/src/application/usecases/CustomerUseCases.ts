// ============================================
// APPLICATION USE CASES - Customer Use Cases
// ============================================

import { prisma } from '../../infrastructure/database/prisma';
import { AuditLogger } from '../../infrastructure/services/AuditLogger';
import { normalizeLoyalty } from '../../domain/businessPage';
import { stampSyncSoon } from './stampSync';

export class CustomerUseCases {

  async getAll() {
    return prisma.customer.findMany({
      where: { isActive: true },
      orderBy: { name: 'asc' },
      include: { _count: { select: { sales: true } } }
    });
  }

  async search(q: string) {
    return prisma.customer.findMany({
      where: {
        isActive: true,
        OR: [
          { name: { contains: q } },
          { nit:  { contains: q } },
          { phone: { contains: q } },
        ]
      },
      orderBy: { name: 'asc' },
      take: 15,
    });
  }

  async getById(id: string) {
    return prisma.customer.findUnique({
      where: { id },
      include: {
        sales: {
          where: { status: 'COMPLETED' },
          orderBy: { createdAt: 'desc' },
          take: 20,
          include: { items: { include: { productVariant: { include: { product: true } } } } }
        }
      }
    });
  }

  async getDefault() {
    return prisma.customer.findFirst({ where: { isDefault: true } });
  }

  async getBirthdays() {
    // Get customers with birthday in the next 7 days (or today)
    const today = new Date();
    const customers = await prisma.customer.findMany({
      where: { isActive: true, birthDate: { not: null } }
    });
    const start = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    const upcoming = customers.filter(c => {
      if (!c.birthDate) return false;
      const bd = new Date(c.birthDate);
      // El próximo cumpleaños: si ya pasó este año, el del siguiente (el 28 de diciembre ve el 2 de enero)
      let next = new Date(start.getFullYear(), bd.getUTCMonth(), bd.getUTCDate());
      if (next < start) next = new Date(start.getFullYear() + 1, bd.getUTCMonth(), bd.getUTCDate());
      const diff = Math.round((next.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
      return diff <= 7;
    });
    return upcoming;
  }

  async getRecommendedProducts(customerId: string) {
    // Find most purchased products by this customer
    const items = await prisma.saleItem.findMany({
      where: {
        sale: { customerId, status: 'COMPLETED' },
        isCancelled: false
      },
      include: { productVariant: { include: { product: true } } }
    });
    // Aggregate by product
    const map: Record<string, { name: string; count: number; variantName: string; price: number }> = {};
    for (const item of items) {
      const key = item.productVariant.product.id;
      if (!map[key]) map[key] = { name: item.productVariant.product.name, variantName: item.productVariant.name, count: 0, price: item.productVariant.price };
      map[key].count += item.quantity;
    }
    return Object.values(map).sort((a, b) => b.count - a.count).slice(0, 5);
  }

  async create(data: {
    name: string;
    nit?: string;
    phone?: string;
    email?: string;
    address?: string;
    birthDate?: string;
    notes?: string;
  }) {
    if (!data.name) throw new Error('El nombre del cliente es obligatorio');
    return prisma.customer.create({
      data: {
        name: data.name,
        nit: data.nit || null,
        phone: data.phone || null,
        email: data.email || null,
        address: data.address || null,
        birthDate: data.birthDate ? new Date(data.birthDate) : null,
        notes: data.notes || null,
      }
    });
  }

  async update(id: string, data: any) {
    return prisma.customer.update({
      where: { id },
      data: {
        name: data.name,
        nit: data.nit || null,
        phone: data.phone || null,
        email: data.email || null,
        address: data.address || null,
        birthDate: data.birthDate ? new Date(data.birthDate) : null,
        notes: data.notes || null,
      }
    });
  }

  async deactivate(id: string) {
    const customer = await prisma.customer.findUnique({ where: { id } });
    if (!customer) throw new Error('Cliente no encontrado');
    if (customer.isDefault) throw new Error('No se puede eliminar el cliente por defecto');
    return prisma.customer.update({ where: { id }, data: { isActive: false } });
  }

  async ensureDefaultCustomer() {
    const existing = await prisma.customer.findFirst({ where: { isDefault: true } });
    if (!existing) {
      await prisma.customer.create({
        data: {
          name: 'Cliente Común',
          nit: '22222222',
          isDefault: true,
        }
      });
    }
  }

  /**
   * Suma o quita sellos a mano (cortesía, corrección). Se ve de inmediato en la caja y
   * el movimiento queda en la cola hacia su tarjeta digital (sin internet espera).
   */
  async adjustStamps(id: string, delta: number, reason?: string, actor?: string) {
    const customer = await prisma.customer.findUnique({ where: { id } });
    if (!customer) throw new Error('Cliente no encontrado');
    if (customer.isDefault) throw new Error('El cliente genérico no tiene tarjeta de sellos');
    const step = Math.max(-100, Math.min(100, Math.round(delta)));
    if (!step) throw new Error('Indica cuántos sellos sumar o quitar');
    const currentStamps = customer.stampsCount ?? 0;
    // No se pueden quitar más sellos de los que tiene
    const applied = Math.max(-currentStamps, step);
    if (!applied) throw new Error('El cliente no tiene sellos para quitar');
    const newStamps = currentStamps + applied;
    const newLifetime = (customer.lifetimeStamps ?? 0) + Math.max(0, applied);

    const [updated, event] = await prisma.$transaction([
      prisma.customer.update({ where: { id }, data: { stampsCount: newStamps, lifetimeStamps: newLifetime } }),
      prisma.stampEvent.create({ data: { customerId: id, stamps: applied, reason: (reason || 'Ajuste manual').slice(0, 120) } }),
    ]);

    AuditLogger.log({
      action: 'CUSTOMER_STAMPS_ADJUSTED',
      entityType: 'CUSTOMER',
      entityId: id,
      details: { previousStamps: currentStamps, newStamps, delta: applied, reason: reason || 'Ajuste manual', actor: actor || 'admin' },
    });
    stampSyncSoon();
    return { ...updated, stampEventId: event.id };
  }

  /** Tarjeta de sellos del cliente: saldo, meta, si tiene tarjeta digital y lo que falta por subir */
  async loyaltyStatus(id: string) {
    const customer = await prisma.customer.findUnique({ where: { id } });
    if (!customer) throw new Error('Cliente no encontrado');
    const settings = await prisma.businessSettings.findUnique({ where: { id: 'default' }, select: { pageSettings: true, cloudTenantCode: true } });
    let page: any = {};
    try {
      page = settings?.pageSettings ? JSON.parse(settings.pageSettings) : {};
    } catch {}
    const loyalty = normalizeLoyalty(page.loyalty);
    const [queued, waiting, last] = await Promise.all([
      prisma.stampEvent.count({ where: { customerId: id, status: 'QUEUED' } }),
      prisma.stampEvent.count({ where: { customerId: id, status: 'WAITING_SIGNUP' } }),
      prisma.stampEvent.findFirst({ where: { customerId: id }, orderBy: { createdAt: 'desc' } }),
    ]);
    return {
      stampsCount: customer.stampsCount ?? 0,
      lifetimeStamps: customer.lifetimeStamps ?? 0,
      stampsRequired: loyalty.stampsRequired,
      rewardText: loyalty.rewardText,
      enabled: loyalty.enabled && !!settings?.pageSettings,
      hasCard: !!customer.cloudId,
      /** Sin Lantify Cloud no hay tarjeta digital: los sellos solo viven en este equipo */
      linked: !!settings?.cloudTenantCode,
      hasPhone: !!customer.phone,
      queued,
      waitingSignup: waiting,
      lastEvent: last ? { id: last.id, stamps: last.stamps, status: last.status, createdAt: last.createdAt, syncedAt: last.syncedAt } : null,
    };
  }

  async stampEvent(id: string) {
    const e = await prisma.stampEvent.findUnique({ where: { id } });
    if (!e) throw new Error('Movimiento no encontrado');
    return { id: e.id, status: e.status, stamps: e.stamps, syncedAt: e.syncedAt };
  }
}
