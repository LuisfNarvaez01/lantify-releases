// ============================================
// APPLICATION - Pantalla del cliente (Fase 4 · 10)
// ============================================
// La caja publica su carrito (PUT /api/displays/customer-cart, con antirrebote en
// la caja) y se guarda en memoria por pantalla: no toca la base ni la venta. La
// pantalla se entera por el aviso en vivo "customer" y pide lo suyo. En reposo
// muestra los productos destacados, el happy hour y el QR de la página.

import { prisma } from '../../infrastructure/database/prisma';
import { publish } from '../../shared/liveEvents';
import { CART_STALE_MS, normalizeCustomerCart, suggestedTip, type CustomerCart } from '../../domain/customerDisplay';
import { publicHappyHours, activeRules } from '../../domain/priceRules';
import { normalizePageConfig } from '../../domain/businessPage';
import { PriceRuleUseCases } from './PriceRuleUseCases';

export class CustomerDisplayError extends Error {
  constructor(message: string, public code: string, public statusCode = 400) {
    super(message);
  }
}

/** Carrito publicado por cada pantalla del cliente (id de la pantalla → carrito) */
const carts = new Map<string, { cart: CustomerCart; at: number }>();
export const resetCustomerCarts = () => carts.clear();

const PAGE_BASE = 'https://lantifypos.com/m/';

const safeJson = (v: string | null | undefined) => {
  try {
    return v ? JSON.parse(v) : {};
  } catch {
    return {};
  }
};

export class CustomerDisplayUseCases {
  constructor(private rules = new PriceRuleUseCases()) {}

  /** Pantallas del cliente que puede elegir la caja */
  async displays() {
    const rows = await prisma.display.findMany({ where: { type: 'CUSTOMER' }, orderBy: { createdAt: 'asc' } });
    return rows.map((d) => ({ id: d.id, name: d.name, connected: !!d.tokenHash }));
  }

  /** La caja manda su carrito (vacío = la pantalla vuelve al reposo) */
  async publish(displayId: unknown, raw: unknown) {
    const id = typeof displayId === 'string' ? displayId : '';
    const d = id ? await prisma.display.findUnique({ where: { id }, select: { id: true, type: true } }) : null;
    if (!d || d.type !== 'CUSTOMER') throw new CustomerDisplayError('Pantalla del cliente no encontrada', 'DISPLAY_NOT_FOUND', 404);
    const cart = normalizeCustomerCart(raw);
    if (cart) carts.set(d.id, { cart, at: Date.now() });
    else carts.delete(d.id);
    publish('customer');
    return { ok: true, lines: cart?.lines.length ?? 0 };
  }

  /** Lo que muestra la pantalla del cliente */
  async feed(display: { id: string; name: string; type: string }, now = new Date()) {
    const s = await prisma.businessSettings.findUnique({ where: { id: 'default' } });
    const entry = carts.get(display.id);
    const cart = entry && now.getTime() - entry.at < CART_STALE_MS ? entry.cart : null;
    if (entry && !cart) carts.delete(display.id);
    const tip = { enabled: !!s?.tipEnabled, percent: s?.tipPercent ?? 0 };
    const due = cart ? Math.max(0, cart.total - cart.paid) : 0;

    // Reposo: happy hour, destacados y la página (solo se arma si no hay carrito)
    let idle: Record<string, unknown> | null = null;
    if (!cart) {
      const rules = await this.rules.enabledRules().catch(() => []);
      const activeIds = new Set(activeRules(now, rules).map((r) => r.id));
      const page = normalizePageConfig(safeJson(s?.pageSettings));
      const featuredIds = page.featured.mode === 'manual' ? page.featured.productIds : [];
      const products = await prisma.product.findMany({
        where: { isActive: true, imageUrl: { not: null }, ...(featuredIds.length ? { id: { in: featuredIds } } : {}) },
        select: { id: true, name: true, imageUrl: true, pausedUntil: true, variants: { where: { isActive: true }, select: { price: true }, orderBy: { price: 'asc' }, take: 1 } },
        take: 12,
      });
      const featured = products
        .filter((p) => !(p.pausedUntil && p.pausedUntil > now) && p.variants.length)
        .sort((a, b) => (featuredIds.length ? featuredIds.indexOf(a.id) - featuredIds.indexOf(b.id) : 0))
        .slice(0, 6)
        .map((p) => ({ name: p.name, imageUrl: p.imageUrl, price: p.variants[0].price }));
      idle = {
        happyHours: rules.filter((r) => r.active).slice(0, 6).map((r) => ({ ...publicHappyHours([r])[0], active: activeIds.has(r.id) })),
        featured,
        pageUrl: s?.bookingSlug && s?.bookingPublishedAt ? `${PAGE_BASE}${s.bookingSlug}` : null,
      };
    }

    return {
      now: now.toISOString(),
      display: { name: display.name, type: display.type, station: null },
      business: { name: s?.businessName || '', logoUrl: s?.logoUrl || null },
      cart,
      due,
      tip: cart ? suggestedTip(due, tip) : 0,
      tipPercent: tip.enabled ? tip.percent : 0,
      paymentQr: s?.paymentQrUrl ? { url: s.paymentQrUrl, label: s.paymentQrLabel || '' } : null,
      idle,
    };
  }
}
