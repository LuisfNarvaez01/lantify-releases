// ============================================
// APPLICATION - Exportación contable del mes (Fase 4 · beta)
// ============================================
// Solo LEE: ventas cobradas, arqueos, gastos y facturas del mes. Nunca cambia una
// venta. Los archivos (CSV, Siigo, Alegra, informe del contador) los arma la
// pantalla con src/domain/accountingExport.ts, igual que aquí se prueban.

import { prisma } from '../../infrastructure/database/prisma';
import { AccountingSale, buildVouchers, isMonth, voucherTotals } from '../../domain/accountingExport';
import { loadFeatures } from '../../shared/featureStore';

export class AccountingError extends Error {
  constructor(public statusCode: number, public code: string, message: string) {
    super(message);
    this.name = 'AccountingError';
  }
}

const pad = (n: number) => String(n).padStart(2, '0');
/** Fecha local del equipo de la caja (YYYY-MM-DD) */
export const localDay = (d: Date) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

export class AccountingExportUseCases {
  async month(month: unknown) {
    if (!isMonth(month)) throw new AccountingError(400, 'BAD_MONTH', 'El mes debe tener el formato AAAA-MM.');
    const [y, m] = month.split('-').map(Number);
    const from = new Date(y, m - 1, 1);
    const to = new Date(y, m, 1);
    const range = { gte: from, lt: to };

    const [rows, sessions, expenses, invoices, features] = await Promise.all([
      prisma.sale.findMany({
        where: { createdAt: range, status: 'COMPLETED' },
        orderBy: { createdAt: 'asc' },
        select: {
          id: true, saleNumber: true, receiptCode: true, createdAt: true, status: true, total: true, tip: true, discount: true, paymentMethod: true,
          customerName: true,
          customer: { select: { name: true, nit: true, isDefault: true } },
          payments: { select: { paymentMethod: true, amount: true } },
          items: { select: { taxType: true, taxAmount: true, total: true, isCancelled: true } },
          dianInvoice: { select: { invoiceNumber: true } },
        },
      }),
      prisma.cashSession.findMany({
        where: { openedAt: range },
        orderBy: { openedAt: 'asc' },
        select: { sessionNumber: true, openedAt: true, closedAt: true, initialBalance: true, income: true, expenses: true, expectedBalance: true, finalBalance: true, difference: true, status: true, closedByName: true },
      }),
      prisma.expense.findMany({
        where: { createdAt: range, isCancelled: false },
        orderBy: { createdAt: 'asc' },
        select: { createdAt: true, amount: true, motive: true, paymentSource: true, supplierName: true, supplierNit: true, invoiceNumber: true, subtotal: true, taxAmount: true, category: { select: { name: true } } },
      }),
      prisma.dianInvoice.findMany({
        where: { issueDate: range },
        orderBy: { issueDate: 'asc' },
        select: { invoiceNumber: true, issueDate: true, customerName: true, customerNit: true, subtotal: true, tax: true, total: true, status: true },
      }),
      loadFeatures(),
    ]);

    const sales: AccountingSale[] = rows.map((s) => ({
      id: s.id,
      saleNumber: s.saleNumber,
      receiptCode: s.receiptCode,
      date: localDay(s.createdAt),
      status: String(s.status),
      total: s.total,
      tip: s.tip,
      discount: s.discount,
      paymentMethod: s.paymentMethod,
      payments: s.payments.map((p) => ({ method: p.paymentMethod, amount: p.amount })),
      items: s.items,
      customerName: s.customer && !s.customer.isDefault ? s.customer.name : s.customerName,
      customerNit: s.customer && !s.customer.isDefault ? s.customer.nit : null,
      invoiceNumber: s.dianInvoice?.invoiceNumber ?? null,
    }));

    const vouchers = buildVouchers(sales, features.accounting);
    return {
      month,
      accounts: features.accounting,
      sales,
      vouchers,
      // Cada comprobante debe cuadrar (débitos = créditos); la pantalla lo muestra
      balanced: vouchers.every((v) => { const t = voucherTotals(v); return Math.round(t.debit * 100) === Math.round(t.credit * 100); }),
      sessions: sessions.map((s) => ({ ...s, openedAt: s.openedAt.toISOString(), closedAt: s.closedAt?.toISOString() ?? null })),
      expenses: expenses.map((e) => ({ ...e, createdAt: e.createdAt.toISOString(), category: e.category?.name ?? null })),
      invoices: invoices.map((i) => ({ ...i, issueDate: i.issueDate.toISOString() })),
    };
  }
}
