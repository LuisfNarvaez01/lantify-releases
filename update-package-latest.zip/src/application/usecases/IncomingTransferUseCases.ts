// ============================================
// APPLICATION - Transferencias confirmadas por el aviso del banco (Fase 4 · D · 3)
// ============================================
// El celular del negocio lee el aviso de Nequi, Daviplata, Bancolombia o Bre‑B y envía
// solo monto, remitente y hora (POST /api/payments/incoming). La caja lo guarda 24 h y lo
// empareja con el cobro en espera del mismo valor (Cobrar → Transferencia).
// Los cobros en espera viven en memoria: duran 15 minutos y, si el servidor se reinicia,
// el cajero confirma a mano como siempre. Nada de esto bloquea ni registra una venta.

import crypto from 'crypto';
import { prisma } from '../../infrastructure/database/prisma';
import { publish } from '../../shared/liveEvents';
import type { BankApp } from '../../domain/bankNotifications';
import {
  MATCH_WINDOW_MS, TRANSFER_KEEP_MS, chargeAlive, chargeForTransfer, transferForCharge, type PendingCharge,
} from '../../domain/incomingTransfers';

export class TransferError extends Error {
  constructor(message: string, public code: string, public statusCode = 400) { super(message); }
}

const APPS: BankApp[] = ['NEQUI', 'DAVIPLATA', 'BANCOLOMBIA', 'BREB'];

interface Charge extends PendingCharge { transferId: string | null }

export interface TransferActor { userId?: string; name?: string; role?: string }

const view = (t: { id: string; app: string; amount: number; sender: string | null; postedAt: Date; receivedAt: Date; matchedAt: Date | null }) => ({
  id: t.id, app: t.app, amount: t.amount, sender: t.sender, postedAt: t.postedAt, receivedAt: t.receivedAt, matched: !!t.matchedAt,
});

export class IncomingTransferUseCases {
  private charges = new Map<string, Charge>();

  constructor(private clock: () => number = Date.now) {}

  private sweep() {
    const now = this.clock();
    for (const [id, c] of this.charges) if (!chargeAlive(c, now)) this.charges.delete(id);
  }

  /** Lo que envía el celular: ya viene analizado; aquí se vuelve a validar */
  async receive(body: Record<string, unknown>, actor: TransferActor) {
    const app = String(body.app || '').toUpperCase() as BankApp;
    const amount = Math.round(Number(body.amount) * 100) / 100;
    const postedAt = Number(body.postedAt);
    const ref = String(body.ref || '');
    const sender = typeof body.sender === 'string' ? body.sender.replace(/[^\p{L}' ]/gu, ' ').replace(/\s+/g, ' ').trim().slice(0, 60) || null : null;
    if (!APPS.includes(app)) throw new TransferError('Aviso de una app que Lantify no lee.', 'TRANSFER_BAD_APP');
    if (!Number.isFinite(amount) || amount <= 0 || amount >= 100_000_000) throw new TransferError('Monto no válido.', 'TRANSFER_BAD_AMOUNT');
    if (!/^[A-Za-z0-9:_|.-]{8,120}$/.test(ref)) throw new TransferError('Aviso sin identificador.', 'TRANSFER_BAD_REF');
    const now = this.clock();
    if (!Number.isFinite(postedAt) || postedAt > now + 5 * 60_000 || now - postedAt > TRANSFER_KEEP_MS) {
      throw new TransferError('El aviso es demasiado antiguo.', 'TRANSFER_STALE');
    }

    // El celular puede reenviar el mismo aviso (Android lo vuelve a publicar)
    const existing = await prisma.incomingTransfer.findUnique({ where: { ref } });
    if (existing) return { transfer: view(existing), matched: !!existing.matchedAt, duplicate: true };

    let created;
    try {
      created = await prisma.incomingTransfer.create({
        data: { ref, app, amount, sender, postedAt: new Date(postedAt), receivedAt: new Date(now), deviceUser: actor.name || null },
      });
    } catch {
      // Dos envíos del mismo aviso a la vez: el otro ya lo guardó
      const again = await prisma.incomingTransfer.findUnique({ where: { ref } });
      if (again) return { transfer: view(again), matched: !!again.matchedAt, duplicate: true };
      throw new TransferError('No se pudo guardar el aviso.', 'TRANSFER_SAVE', 500);
    }

    this.sweep();
    const waiting = [...this.charges.values()].filter((c) => !c.transferId);
    const picked = chargeForTransfer({ id: created.id, amount, receivedAt: now, matched: false }, waiting, now);
    const charge = picked ? this.charges.get(picked.id) : undefined;
    let matched = false;
    if (charge) matched = await this.claim(charge, created.id);
    publish('payments');
    const fresh = matched ? await prisma.incomingTransfer.findUnique({ where: { id: created.id } }) : created;
    return { transfer: view(fresh || created), matched, duplicate: false };
  }

  /** Marca la transferencia como de este cobro, solo si nadie la tomó antes */
  private async claim(charge: Charge, transferId: string): Promise<boolean> {
    const r = await prisma.incomingTransfer.updateMany({ where: { id: transferId, matchedAt: null }, data: { matchedAt: new Date(this.clock()), chargeRef: charge.id } });
    if (r.count !== 1) return false;
    charge.transferId = transferId;
    return true;
  }

  /** Cobrar → Transferencia: la caja espera una transferencia de este valor */
  async expect(rawAmount: unknown) {
    const amount = Math.round(Number(rawAmount) * 100) / 100;
    if (!Number.isFinite(amount) || amount <= 0) throw new TransferError('Monto no válido.', 'TRANSFER_BAD_AMOUNT');
    this.sweep();
    const now = this.clock();
    const charge: Charge = { id: crypto.randomUUID(), amount, createdAt: now, transferId: null };
    this.charges.set(charge.id, charge);
    // Quizá el cliente ya pagó (la transferencia llegó antes de abrir el cobro)
    const recent = await prisma.incomingTransfer.findMany({
      where: { matchedAt: null, amount, receivedAt: { gte: new Date(now - MATCH_WINDOW_MS) } },
      orderBy: { receivedAt: 'asc' },
    });
    const found = transferForCharge(charge, recent.map((t) => ({ id: t.id, amount: t.amount, receivedAt: t.receivedAt.getTime(), matched: false })), now);
    if (found) await this.claim(charge, found.id);
    return this.status(charge.id);
  }

  async status(id: string) {
    this.sweep();
    const charge = this.charges.get(id);
    if (!charge) return { id, status: 'EXPIRED' as const, transfer: null };
    const transfer = charge.transferId ? await prisma.incomingTransfer.findUnique({ where: { id: charge.transferId } }) : null;
    return {
      id,
      amount: charge.amount,
      status: transfer ? ('CONFIRMED' as const) : ('WAITING' as const),
      expiresAt: new Date(charge.createdAt + MATCH_WINDOW_MS).toISOString(),
      transfer: transfer ? view(transfer) : null,
    };
  }

  /**
   * Se terminó el cobro. Con keep=true (se registró la venta) la transferencia queda usada;
   * si se canceló o cambió el medio de pago, se libera para otro cobro del mismo valor.
   */
  async close(id: string, keep: boolean) {
    const charge = this.charges.get(id);
    this.charges.delete(id);
    if (charge?.transferId && !keep) {
      await prisma.incomingTransfer.updateMany({ where: { id: charge.transferId, chargeRef: id }, data: { matchedAt: null, chargeRef: null } });
    }
    return { ok: true };
  }

  /** Últimas 24 h, para revisar a mano */
  async recent() {
    const since = new Date(this.clock() - TRANSFER_KEEP_MS);
    const rows = await prisma.incomingTransfer.findMany({ where: { receivedAt: { gte: since } }, orderBy: { receivedAt: 'desc' }, take: 100 });
    return rows.map(view);
  }

  /** Se borran a las 24 h (lo corre el servidor cada hora) */
  async purge() {
    const r = await prisma.incomingTransfer.deleteMany({ where: { receivedAt: { lt: new Date(this.clock() - TRANSFER_KEEP_MS) } } });
    this.sweep();
    return r.count;
  }
}
