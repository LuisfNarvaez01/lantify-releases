// ============================================
// APPLICATION - Fotos del equipo → Lantify Cloud
// ============================================
// La página pública no puede leer fotos del equipo del negocio. Antes de publicar,
// cada foto subida aquí (/api/media/…) se sube una vez a la nube y en lo publicado
// se cambia por su dirección pública. Si no hay internet, la foto se omite y la
// página se vuelve a publicar con ella cuando suba (la huella de lo publicado cambia).

import { cloudConfig } from '../../shared/cloud/config';
import { mediaStore } from '../../infrastructure/services/MediaStore';
import { MEDIA_URL_RE } from '../../domain/media';

type Request = (method: string, path: string, token: string, body: unknown) => Promise<{ status: number; body: any } | null>;

// Fotos que ya están en la nube (por instalación; se reconstruye al reiniciar)
const confirmed = new Set<string>();

const publicUrl = (id: string, ext: string) => `${new URL(cloudConfig().apiUrl).origin}/v1/public/images/${id}.${ext}`;

export const cloudImages = {
  /**
   * Cambia cada foto local por su dirección en la nube. Con `token` sube las que
   * falten; sin él (o sin conexión) las que no estén confirmadas quedan en null.
   */
  async resolve(urls: (string | null | undefined)[], token: string | null, request: Request): Promise<Map<string, string | null>> {
    const out = new Map<string, string | null>();
    const pending = new Map<string, { id: string; ext: string; url: string }>();
    for (const url of urls) {
      if (!url || out.has(url)) continue;
      const m = MEDIA_URL_RE.exec(url);
      if (!m) {
        out.set(url, /^https:\/\//.test(url) ? url : null);
        continue;
      }
      if (confirmed.has(m[1])) out.set(url, publicUrl(m[1], m[2]));
      else pending.set(m[1], { id: m[1], ext: m[2], url });
    }
    if (pending.size && token) {
      const check = await request('POST', '/v1/site/images/missing', token, { ids: [...pending.keys()] });
      const missing: string[] | null = check?.status === 200 && Array.isArray(check.body?.missing) ? check.body.missing : null;
      if (missing) {
        for (const id of pending.keys()) if (!missing.includes(id)) confirmed.add(id);
        for (const id of missing) {
          const local = pending.get(id) && mediaStore.read(pending.get(id)!.url);
          if (!local) continue;
          const res = await request('PUT', '/v1/site/images', token, { data: local.bytes.toString('base64') });
          if (res && (res.status === 200 || res.status === 201) && res.body?.id === id) confirmed.add(id);
          else if (!res) break; // sin conexión: se intenta en la próxima sincronización
          else console.warn(`[página] la foto ${id} no se pudo subir (HTTP ${res.status} ${res.body?.code || ''})`);
        }
      }
    }
    for (const { id, ext, url } of pending.values()) out.set(url, confirmed.has(id) ? publicUrl(id, ext) : null);
    return out;
  },

  /** Solo para pruebas */
  _reset() {
    confirmed.clear();
  },
};
