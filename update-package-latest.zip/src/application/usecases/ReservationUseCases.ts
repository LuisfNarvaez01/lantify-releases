// ============================================
// APPLICATION - Reservas
// ============================================
// La caja registra reservas que llegan por WhatsApp, teléfono o en persona; las
// de la página pública llegan desde Lantify Cloud (ReservationSyncService). Una
// mesa nunca queda con dos reservas activas que se crucen. Las reglas de horario
// y anticipación son para la página; la caja puede agendar fuera de ellas.

import { prisma } from '../../infrastructure/database/prisma';
import { AuditLogger } from '../../infrastructure/services/AuditLogger';
import {
  ACTIVE_STATUSES, ALL_STATUSES, BookingSettings, BookableTable, availability, isDateString, localToUtc,
  normalizeBooking, pickTable, reservationCode, tableIsFree, utcToLocal,
} from '../../domain/booking';

export class BookingError extends Error {
  constructor(public status: number, public code: string, message: string, public extra: Record<string, unknown> = {}) {
    super(message);
    this.name = BookingError.name;
  }
}

export const CHANNELS = ['POS', 'WHATSAPP', 'PHONE', 'WALK_IN', 'ONLINE'] as const;
const SETTINGS_ID = 'default';
const HHMM = /^([01]\d|2[0-3]):([0-5]\d)$/;
const clean = (v: unknown, max: number) => (typeof v === 'string' && v.trim() ? v.trim().slice(0, max) : null);
const digits = (v: unknown) => (typeof v === 'string' ? v.replace(/\D/g, '') : '');

export interface ReservationInput {
  customerName?: string;
  customerPhone?: string | null;
  customerEmail?: string | null;
  customerId?: string | null;
  partySize?: number;
  date?: string;
  time?: string;
  durationMinutes?: number;
  tableId?: string | null;
  channel?: string;
  notes?: string | null;
  /** Guardar a la persona en Clientes (solo si dio sus datos y aceptó) */
  saveCustomer?: boolean;
}

const INCLUDE = { table: { select: { id: true, number: true, zone: true, capacity: true } }, customer: { select: { id: true, name: true, phone: true } } };

export class ReservationUseCases {
  // ── Configuración ─────────────────────────────────────────
  async settings() {
    const [row, tables] = await Promise.all([
      prisma.businessSettings.findUnique({ where: { id: SETTINGS_ID } }),
      prisma.table.findMany({ orderBy: { number: 'asc' } }),
    ]);
    return {
      settings: normalizeBooking(row?.bookingSettings ? JSON.parse(row.bookingSettings) : {}),
      slug: row?.bookingSlug ?? null,
      publishedAt: row?.bookingPublishedAt ?? null,
      syncAt: row?.bookingSyncAt ?? null,
      tables: tables
        .sort((a, b) => a.number.localeCompare(b.number, 'es', { numeric: true }))
        .map((t) => ({ id: t.id, number: t.number, zone: t.zone, capacity: t.capacity, reservable: t.reservable })),
    };
  }

  async updateSettings(input: { settings?: unknown; reservableTableIds?: unknown; slug?: unknown }, actor: string) {
    const settings = normalizeBooking(input.settings);
    const ids = Array.isArray(input.reservableTableIds) ? input.reservableTableIds.filter((x): x is string => typeof x === 'string') : null;
    const slug = typeof input.slug === 'string' ? slugify(input.slug) : undefined;
    if (slug !== undefined && slug && slug.length < 3) throw new BookingError(400, 'BOOKING_BAD_SLUG', 'La dirección debe tener al menos 3 letras.');
    if (settings.online && ids && ids.length === 0) {
      throw new BookingError(400, 'BOOKING_NO_TABLES', 'Elige al menos una mesa que se pueda reservar.');
    }
    await prisma.$transaction(async (tx) => {
      await tx.businessSettings.upsert({
        where: { id: SETTINGS_ID },
        create: { id: SETTINGS_ID, bookingSettings: JSON.stringify(settings), ...(slug !== undefined ? { bookingSlug: slug || null } : {}) },
        update: { bookingSettings: JSON.stringify(settings), ...(slug !== undefined ? { bookingSlug: slug || null } : {}) },
      });
      if (ids) {
        await tx.table.updateMany({ data: { reservable: false } });
        if (ids.length) await tx.table.updateMany({ where: { id: { in: ids } }, data: { reservable: true } });
      }
    });
    AuditLogger.log({ action: 'BOOKING_SETTINGS_UPDATED', entityType: 'SETTINGS', entityId: SETTINGS_ID, details: { by: actor, online: settings.online, tables: ids?.length } });
    return this.settings();
  }

  /** Mesas que se ofrecen para reservar (las marcadas por el ADMIN) */
  async bookableTables(): Promise<BookableTable[]> {
    const tables = await prisma.table.findMany({ where: { reservable: true } });
    return tables.map((t) => ({ id: t.id, label: t.number, capacity: t.capacity, zone: t.zone }));
  }

  // ── Consulta ──────────────────────────────────────────────
  /** Reservas de un día local (o de un rango UTC) */
  async list(q: { date?: string; from?: string; to?: string }) {
    const { settings } = await this.settings();
    let from: Date;
    let to: Date;
    if (isDateString(q.date)) {
      from = localToUtc(q.date, 0, settings.utcOffsetMinutes);
      to = localToUtc(q.date, 24 * 60, settings.utcOffsetMinutes);
    } else {
      from = q.from ? new Date(q.from) : new Date();
      to = q.to ? new Date(q.to) : new Date(from.getTime() + 7 * 86400000);
      if (Number.isNaN(from.getTime()) || Number.isNaN(to.getTime())) throw new BookingError(400, 'BOOKING_BAD_DATE', 'Fecha no válida.');
    }
    const rows = await prisma.reservation.findMany({
      where: { startsAt: { gte: from, lt: to } },
      include: INCLUDE,
      orderBy: { startsAt: 'asc' },
    });
    return rows.map((r) => this.present(r, settings));
  }

  /** Pendientes por confirmar y próximas de hoy (para el aviso en el encabezado) */
  async summary() {
    const now = new Date();
    const [pending, conflicts, upcoming, latest] = await Promise.all([
      prisma.reservation.count({ where: { status: 'PENDING', startsAt: { gte: now } } }),
      prisma.reservation.count({ where: { cloudConflict: true, status: { in: [...ACTIVE_STATUSES] }, startsAt: { gte: now } } }),
      prisma.reservation.count({ where: { status: 'CONFIRMED', startsAt: { gte: now, lt: new Date(now.getTime() + 3 * 3600000) } } }),
      // Cualquier cambio (también una reserva de la página que llega confirmada) recarga la agenda abierta
      prisma.reservation.aggregate({ _max: { updatedAt: true }, _count: true }),
    ]);
    return { pending, conflicts, upcoming, latest: `${latest._count}:${latest._max.updatedAt?.toISOString() ?? ''}` };
  }

  async availability(date: string, party: number) {
    if (!isDateString(date)) throw new BookingError(400, 'BOOKING_BAD_DATE', 'Fecha no válida.');
    const { settings } = await this.settings();
    const tables = await this.bookableTables();
    const busy = await this.busyAround(localToUtc(date, 0, settings.utcOffsetMinutes), localToUtc(date, 48 * 60, settings.utcOffsetMinutes));
    // La caja ve las horas aunque estén dentro de la anticipación mínima de la página
    return availability({ settings: { ...settings, minAdvanceMinutes: 0, maxDaysAhead: 3650 }, tables, busy, date, party: Math.max(1, Math.round(party) || 1) });
  }

  private busyAround(from: Date, to: Date) {
    return prisma.reservation.findMany({
      where: { status: { in: [...ACTIVE_STATUSES] }, startsAt: { lt: to }, endsAt: { gt: from } },
      select: { id: true, tableId: true, startsAt: true, endsAt: true, status: true },
    });
  }

  // ── Registro desde la caja ────────────────────────────────
  async create(input: ReservationInput, actor: string) {
    const { settings } = await this.settings();
    const customerName = clean(input.customerName, 120);
    if (!customerName) throw new BookingError(400, 'BOOKING_NAME_REQUIRED', 'Escribe el nombre de quien reserva.');
    const partySize = Math.round(Number(input.partySize));
    if (!Number.isInteger(partySize) || partySize < 1 || partySize > 200) throw new BookingError(400, 'BOOKING_BAD_PARTY', 'Número de personas no válido.');
    const { startsAt, endsAt } = this.timesFrom(input, settings);
    const channel = (CHANNELS as readonly string[]).includes(input.channel || '') && input.channel !== 'ONLINE' ? input.channel! : 'POS';

    const tableId = await this.resolveTable(input.tableId ?? null, partySize, startsAt, endsAt);
    const customerId = await this.resolveCustomer(input, customerName);

    const created = await this.withUniqueCode((code) =>
      prisma.reservation.create({
        data: {
          code,
          tableId,
          customerId,
          customerName,
          customerPhone: clean(input.customerPhone, 20),
          customerEmail: clean(input.customerEmail, 120),
          partySize,
          startsAt,
          endsAt,
          status: 'CONFIRMED',
          channel,
          notes: clean(input.notes, 500),
          createdBy: actor,
        },
        include: INCLUDE,
      }),
    );
    AuditLogger.log({ action: 'RESERVATION_CREATED', entityType: 'RESERVATION', entityId: created.id, details: { code: created.code, by: actor, channel } });
    return this.present(created, settings);
  }

  /** Cambiar estado (llegó, no llegó, cancelar, confirmar) o reprogramar */
  async update(id: string, input: ReservationInput & { status?: string; cancelReason?: string }, actor: string) {
    const { settings } = await this.settings();
    const current = await prisma.reservation.findUnique({ where: { id } });
    if (!current) throw new BookingError(404, 'BOOKING_NOT_FOUND', 'Reserva no encontrada.');

    const data: Record<string, unknown> = { dirty: true };
    if (input.status !== undefined) {
      if (!(ALL_STATUSES as readonly string[]).includes(input.status)) throw new BookingError(400, 'BOOKING_BAD_STATUS', 'Estado no válido.');
      if (input.status === 'CANCELLED' && !clean(input.cancelReason, 300)) throw new BookingError(400, 'BOOKING_REASON_REQUIRED', 'Escribe el motivo de la cancelación.');
      data.status = input.status;
      if (input.status === 'CANCELLED') data.cancelReason = clean(input.cancelReason, 300);
    }
    if (input.notes !== undefined) data.notes = clean(input.notes, 500);
    if (input.customerName !== undefined) {
      const name = clean(input.customerName, 120);
      if (!name) throw new BookingError(400, 'BOOKING_NAME_REQUIRED', 'Escribe el nombre de quien reserva.');
      data.customerName = name;
    }
    if (input.customerPhone !== undefined) data.customerPhone = clean(input.customerPhone, 20);

    // Reprogramar: hora, mesa o personas → se vuelve a revisar que la mesa esté libre
    const moving = input.date !== undefined || input.time !== undefined || input.tableId !== undefined || input.partySize !== undefined;
    const nextStatus = (data.status as string) || current.status;
    if (moving && (ACTIVE_STATUSES as readonly string[]).includes(nextStatus)) {
      const local = utcToLocal(current.startsAt, settings.utcOffsetMinutes);
      const partySize = input.partySize !== undefined ? Math.round(Number(input.partySize)) : current.partySize;
      if (!Number.isInteger(partySize) || partySize < 1 || partySize > 200) throw new BookingError(400, 'BOOKING_BAD_PARTY', 'Número de personas no válido.');
      const { startsAt, endsAt } = this.timesFrom(
        { date: input.date ?? local.date, time: input.time ?? local.time, durationMinutes: Math.round((current.endsAt.getTime() - current.startsAt.getTime()) / 60000) },
        settings,
      );
      const wanted = input.tableId !== undefined ? input.tableId : current.tableId;
      data.tableId = await this.resolveTable(wanted, partySize, startsAt, endsAt, id);
      Object.assign(data, { startsAt, endsAt, partySize, cloudConflict: false });
    } else if ((ACTIVE_STATUSES as readonly string[]).includes(nextStatus) && !(ACTIVE_STATUSES as readonly string[]).includes(current.status) && current.tableId) {
      // Reactivar una cancelada: su mesa debe seguir libre
      if (!tableIsFree(current.tableId, current.startsAt, current.endsAt, await this.busyAround(current.startsAt, current.endsAt), id)) {
        throw new BookingError(409, 'BOOKING_TABLE_TAKEN', 'Esa mesa ya tiene otra reserva a esa hora.');
      }
    }
    if (nextStatus === 'CANCELLED') data.cloudConflict = false;

    const updated = await prisma.reservation.update({ where: { id }, data, include: INCLUDE });
    AuditLogger.log({ action: 'RESERVATION_UPDATED', entityType: 'RESERVATION', entityId: id, details: { code: updated.code, by: actor, status: updated.status, moved: moving } });
    return this.present(updated, settings);
  }

  // ── Apoyo ─────────────────────────────────────────────────
  private timesFrom(input: { date?: string; time?: string; durationMinutes?: number }, settings: BookingSettings) {
    if (!isDateString(input.date)) throw new BookingError(400, 'BOOKING_BAD_DATE', 'Elige la fecha.');
    if (typeof input.time !== 'string' || !HHMM.test(input.time)) throw new BookingError(400, 'BOOKING_BAD_TIME', 'Elige la hora.');
    const minutes = Number(input.time.slice(0, 2)) * 60 + Number(input.time.slice(3, 5));
    const duration = Math.min(720, Math.max(15, Math.round(Number(input.durationMinutes) || settings.durationMinutes)));
    const startsAt = localToUtc(input.date, minutes, settings.utcOffsetMinutes);
    return { startsAt, endsAt: new Date(startsAt.getTime() + duration * 60000) };
  }

  /** Mesa elegida (si está libre y existe) o la más ajustada entre las reservables (o todas si no hay) */
  private async resolveTable(tableId: string | null, party: number, startsAt: Date, endsAt: Date, exceptId?: string) {
    const busy = await this.busyAround(startsAt, endsAt);
    if (tableId) {
      const table = await prisma.table.findUnique({ where: { id: tableId } });
      if (!table) throw new BookingError(404, 'BOOKING_TABLE_NOT_FOUND', 'Esa mesa no existe.');
      if (table.capacity < party) {
        throw new BookingError(400, 'BOOKING_TABLE_TOO_SMALL', `La mesa ${table.number} es para ${table.capacity} personas.`, { capacity: table.capacity, table: table.number });
      }
      if (!tableIsFree(table.id, startsAt, endsAt, busy, exceptId)) {
        const other = busy.find((b) => b.tableId === table.id && b.id !== exceptId);
        const who = other ? await prisma.reservation.findUnique({ where: { id: other.id }, select: { code: true, customerName: true, startsAt: true } }) : null;
        throw new BookingError(409, 'BOOKING_TABLE_TAKEN', `La mesa ${table.number} ya está reservada a esa hora${who ? ` (${who.customerName})` : ''}.`, { reservation: who, table: table.number });
      }
      return table.id;
    }
    let candidates = await this.bookableTables();
    if (!candidates.length) {
      candidates = (await prisma.table.findMany()).map((t) => ({ id: t.id, label: t.number, capacity: t.capacity, zone: t.zone }));
    }
    if (!candidates.length) return null; // negocio sin mesas: reserva sin mesa asignada
    const picked = pickTable(candidates, busy, startsAt, endsAt, party, exceptId);
    if (!picked) throw new BookingError(409, 'BOOKING_NO_TABLE', 'No hay una mesa libre para ese grupo a esa hora.');
    return picked.id;
  }

  /** Cliente elegido, o el que ya tiene ese celular; si no existe, se crea solo si lo pidieron */
  private async resolveCustomer(input: ReservationInput, name: string) {
    if (input.customerId) {
      const c = await prisma.customer.findFirst({ where: { id: input.customerId, isActive: true } });
      if (!c) throw new BookingError(404, 'CUSTOMER_NOT_FOUND', 'Cliente no encontrado.');
      return c.id;
    }
    const phone = digits(input.customerPhone);
    if (phone.length >= 7) {
      // Si hay varios con el mismo celular, el que se actualizó más recientemente
      const match = await prisma.customer.findFirst({ where: { isActive: true, isDefault: false, phone: { contains: phone.slice(-10) } }, orderBy: { updatedAt: 'desc' } });
      if (match) return match.id;
    }
    if (input.saveCustomer) {
      const created = await prisma.customer.create({
        data: { name, phone: clean(input.customerPhone, 20), email: clean(input.customerEmail, 120), source: 'POS' },
      });
      return created.id;
    }
    return null;
  }

  private async withUniqueCode<T>(create: (code: string) => Promise<T>): Promise<T> {
    for (let i = 0; i < 6; i++) {
      try {
        return await create(reservationCode());
      } catch (err: any) {
        if (err?.code !== 'P2002') throw err;
      }
    }
    throw new BookingError(500, 'BOOKING_CODE_FAILED', 'No se pudo generar el código de la reserva.');
  }

  present(r: any, settings: BookingSettings) {
    const local = utcToLocal(r.startsAt, settings.utcOffsetMinutes);
    const end = utcToLocal(r.endsAt, settings.utcOffsetMinutes);
    return { ...r, date: local.date, time: local.time, endTime: end.time };
  }
}

export const slugify = (s: string) =>
  s
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40);
