// ============================================
// APPLICATION - Happy hour y precios por horario (Fase 4 · 7)
// ============================================
// El ADMIN crea las reglas en Productos → Precios por horario. La caja y el
// celular las leen para mostrar el precio vigente; el cobro las usa para revisar
// que un precio menor al de la carta venga de una regla (src/domain/priceRules.ts).

import { prisma } from '../../infrastructure/database/prisma';
import { loadFeatures } from '../../shared/featureStore';
import { currentFeatures } from '../../shared/cloud/features';
import { FEATURE_PLAN_CODE } from '../../domain/v3/features';
import { activeRules, normalizePriceRule, parsePriceRule, PriceRule, PriceRuleError } from '../../domain/priceRules';

const CACHE_MS = 15_000;
let cache: { at: number; rules: PriceRule[] } | null = null;

export const invalidatePriceRules = () => { cache = null; };

/** ¿El negocio usa precios por horario y su plan los incluye? */
export const priceRulesEnabled = async (): Promise<boolean> => {
  if (!(await loadFeatures()).flags.price_rules) return false;
  const plan = await currentFeatures();
  const code = FEATURE_PLAN_CODE.price_rules;
  return !plan || !code || plan.includes(code);
};

export class PriceRuleUseCases {
  /** Todas las reglas guardadas (también las pausadas) */
  async list(): Promise<PriceRule[]> {
    const rows = await prisma.priceRule.findMany({ orderBy: { createdAt: 'asc' } });
    return rows.map(parsePriceRule).filter((r): r is PriceRule => !!r);
  }

  /** Reglas que cuentan hoy (encendidas y con la función activa); con caché corta */
  async enabledRules(): Promise<PriceRule[]> {
    if (!(await priceRulesEnabled())) return [];
    if (cache && Date.now() - cache.at < CACHE_MS) return cache.rules;
    const rules = (await this.list()).filter((r) => r.active);
    cache = { at: Date.now(), rules };
    return rules;
  }

  /** Lo que necesita la caja: las reglas encendidas y cuáles están vigentes ahora */
  async forRegister(now = new Date()) {
    const rules = await this.enabledRules();
    return { enabled: await priceRulesEnabled(), rules, activeIds: activeRules(now, rules).map((r) => r.id), now: now.toISOString() };
  }

  async create(raw: unknown): Promise<PriceRule> {
    const n = normalizePriceRule(raw);
    const row = await prisma.priceRule.create({ data: { ...n, scope: JSON.stringify(n.scope) } });
    invalidatePriceRules();
    return parsePriceRule(row)!;
  }

  async update(id: string, raw: unknown): Promise<PriceRule> {
    const existing = await prisma.priceRule.findUnique({ where: { id } });
    if (!existing) throw new PriceRuleError('La regla ya no existe.', 'PRICE_RULE_NOT_FOUND');
    const n = normalizePriceRule(raw);
    const row = await prisma.priceRule.update({ where: { id }, data: { ...n, scope: JSON.stringify(n.scope) } });
    invalidatePriceRules();
    return parsePriceRule(row)!;
  }

  async remove(id: string) {
    await prisma.priceRule.deleteMany({ where: { id } });
    invalidatePriceRules();
    return { ok: true };
  }
}
