// ============================================
// COMPONENTS - Main Layout
// ============================================

import { useState, useEffect } from 'react';
import { usePosStore } from '../../store/usePosStore';
import { Header } from './Header';
import { FloorPlan } from '../pos/FloorPlan';
import { TableSidebar } from '../pos/TableSidebar';
import { getTableViewMode, TableViewMode } from '../../shared/posSettings';
import { ProductGrid } from '../pos/ProductGrid';
import { Cart } from '../pos/Cart';
import { CashSessionPanel } from '../pos/CashSessionPanel';
import { VariantModal } from '../pos/VariantModal';
import { SalesHistory } from '../pos/SalesHistory';
import { AnalyticsModule } from '../pos/AnalyticsModule';
import { RappiOrdersPanel } from '../pos/RappiOrdersPanel';
import { WhatsAppBotSimulator } from '../pos/WhatsAppBotSimulator';
import { IncomingOrderNotification } from '../pos/IncomingOrderNotification';
import { AdminPanel } from '../AdminPanel';
import { prototypeAPI, salesAPI, pageAPI } from '../../services/api';
import { ArrowLeft, Zap, MessageCircle } from 'lucide-react';
import { toast } from '../../shared/toast';
import { useBusiness } from '../../shared/business';
import { HelpCenter } from '../help/HelpCenter';
import { SubscriptionBanner } from './SubscriptionBanner';
import { AgentsModule } from '../agents/AgentsModule';
import { ReservationsModule } from '../reservations/ReservationsModule';
import { OnlineOrdersModule } from '../orders/OnlineOrdersModule';
import { PlanLocked } from '../common/PlanLocked';
import { usePlan } from '../../shared/plan';
import { TourOffer } from '../help/TourOffer';
import { useGuideStore } from '../../guide/guideStore';
import { START_TOUR_EVENT, startTour } from '../../guide/tourRunner';
import { getTour, GuideModule } from '../../guide/tours';

import { t } from '../../i18n';
interface LayoutProps {
  user?: any;
  onLogout?: () => void;
}

type TabType = 'tables' | 'products' | 'sales' | 'reservations' | 'online' | 'delivery' | 'cash' | 'analytics' | 'agents';

export const Layout: React.FC<LayoutProps> = ({ user, onLogout }) => {
  const [activeTab, setActiveTab] = useState<TabType>('products');
  const [showAdmin, setShowAdmin] = useState(false);
  const [viewMode, setViewMode] = useState<TableViewMode>(() => getTableViewMode());
  // Un negocio sin mesas (comidas rápidas, tienda) trabaja siempre en mostrador
  const business = useBusiness();
  const { usesTables } = business;
  const isOperational = viewMode === 'operational' || !usesTables;

  // En vista operativa no existe la pestaña de mapa: mesas y pedido viven en la misma pantalla
  const handleTabChange = (tab: TabType) => {
    const role = (user?.role || 'WAITER').toUpperCase();
    if (role === 'WAITER' && !['products', 'tables', 'reservations'].includes(tab)) {
      return;
    }
    if (role === 'CASHIER' && ['analytics', 'delivery', 'agents'].includes(tab)) {
      return;
    }
    setActiveTab(isOperational && tab === 'tables' ? 'products' : tab);
  };

  // Redirigir si el rol activo no tiene acceso a la pestaña actual
  useEffect(() => {
    const role = (user?.role || 'WAITER').toUpperCase();
    if (role === 'WAITER' && !['products', 'tables', 'reservations'].includes(activeTab)) {
      setActiveTab('products');
    } else if (role === 'CASHIER' && ['analytics', 'delivery', 'agents'].includes(activeTab)) {
      setActiveTab('products');
    }
  }, [user, activeTab]);
  useEffect(() => {
    if (isOperational && activeTab === 'tables') setActiveTab('products');
  }, [isOperational, activeTab]);
  const [adminInitialTab, setAdminInitialTab] = useState<string | undefined>(undefined);
  const role = (user?.role || 'WAITER').toUpperCase();
  const plan = usePlan();

  // La ayuda sabe en qué pantalla está el usuario (artículos y recorridos de esa pantalla)
  const setGuideModule = useGuideStore((s) => s.setModule);
  useEffect(() => {
    const byTab: Record<string, GuideModule> = { products: 'pos', tables: 'pos', cash: 'cash', sales: 'sales' };
    setGuideModule(showAdmin ? 'settings' : byTab[activeTab] || 'other');
  }, [showAdmin, activeTab, setGuideModule]);

  // Un recorrido pedido desde la ayuda o el asistente: primero se abre su pantalla
  useEffect(() => {
    const onStart = (e: Event) => {
      const id = (e as CustomEvent<{ id: string }>).detail?.id;
      const tour = id ? getTour(id) : null;
      if (!tour) return;
      if (tour.module === 'settings') {
        setAdminInitialTab('config');
        setShowAdmin(true);
      } else {
        setShowAdmin(false);
        if (tour.module === 'cash') setActiveTab('cash');
        else if (tour.module === 'sales') setActiveTab('sales');
        else if (tour.module === 'pos') setActiveTab('products');
      }
      setTimeout(() => startTour(tour.id, role), 450);
    };
    window.addEventListener(START_TOUR_EVENT, onStart);
    return () => window.removeEventListener(START_TOUR_EVENT, onStart);
  }, [role]);

  // F1 abre la ayuda desde cualquier pantalla
  const openHelp = useGuideStore((s) => s.openHelp);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'F1') {
        e.preventDefault();
        openHelp();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [openHelp]);

  const [tableOrderMode, setTableOrderMode] = useState(false);
  const [deliverySubTab, setDeliverySubTab] = useState<'rappi' | 'whatsapp'>('rappi');
  const [incomingOrder, setIncomingOrder] = useState<any>(null);
  const [deliverySales, setDeliverySales] = useState<any[]>([]);
  const [isSeeding, setIsSeeding] = useState(false);
  const [isPrototypeMode, setIsPrototypeMode] = useState<boolean>(() => {
    return localStorage.getItem('pos_mode') === 'prototype' || window.location.hash.includes('prototipo');
  });

  // La tienda web del prototipo ahora es la página real del negocio (Administración → Mi página)
  const openBusinessPage = async () => {
    try {
      const page = await pageAPI.get();
      if (page.url && page.publishedAt) window.open(page.url, '_blank', 'noopener');
      else toast.info(t('layout:mi_pagina_sin_publicar'));
    } catch {
      toast.info(t('layout:mi_pagina_sin_publicar'));
    }
  };

  const handleTogglePrototypeMode = () => {
    setIsPrototypeMode((prev) => {
      const next = !prev;
      localStorage.setItem('pos_mode', next ? 'prototype' : 'mvp');
      if (!next && activeTab === 'delivery') {
        setActiveTab('products');
      }
      return next;
    });
  };

  const { 
    products,
    fetchProducts, 
    fetchCategories, 
    fetchTables, 
    fetchOpenSession, 
    selectedTable, 
    clearCart, 
  } = usePosStore();

  const loadDeliverySales = async () => {
    try {
      const res = await salesAPI.getAll();
      setDeliverySales(res || []);
    } catch (err) {
      console.error('Error loading sales for delivery:', err);
    }
  };

  useEffect(() => {
    // Initial data fetch
    fetchProducts();
    fetchCategories();
    fetchTables();
    fetchOpenSession();
    loadDeliverySales();
  }, []);

  const handleIncomingOrder = (order: any) => {
    setIncomingOrder(order);
    setDeliverySales(prev => [order, ...prev]);
  };

  const handleSeedDemo = async () => {
    setIsSeeding(true);
    try {
      const res = await prototypeAPI.seedDemoData();
      toast.success(res.message || t('layout:datos_demo_cargados_con_exito'));
      await fetchProducts();
      await fetchCategories();
      await loadDeliverySales();
    } catch (err: any) {
      toast.error(err.message || 'Error al cargar datos demo');
    } finally {
      setIsSeeding(false);
    }
  };

  const handleTableSelect = () => {
    // Cuando se selecciona una mesa, entrar en modo pedido
    setTableOrderMode(true);
    setActiveTab('products');
  };

  const handleBackToTables = () => {
    setTableOrderMode(false);
    setActiveTab(isOperational ? 'products' : 'tables');
    clearCart();
  };

  // Callback cuando se completa un pedido - volver al inicio
  const handleOrderComplete = () => {
    setTableOrderMode(false);
    setActiveTab(isOperational ? 'products' : 'tables');
    clearCart();
  };

  const renderContent = () => {
    // Modo pedido de mesa
    if (tableOrderMode && selectedTable) {
      return (
        <div className="space-y-4">
          {/* Header del modo pedido */}
          <div className="bg-white rounded-xl shadow p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <button
                onClick={handleBackToTables}
                className="p-2 hover:bg-gray-100 rounded-lg"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div>
                <h2 className="text-xl font-bold">{t('layout:mesa')}{' '}{selectedTable.number}</h2>
                <p className="text-sm text-gray-500">{t('layout:agrega_los_productos_del_pedido')}</p>
              </div>
            </div>
          </div>
          
          {/* Grid de productos */}
          <ProductGrid />
        </div>
      );
    }
    
    switch (activeTab) {
      case 'tables':
        return <FloorPlan onTableSelect={handleTableSelect} />;
      case 'products':
        return <ProductGrid />;
      case 'sales':
        return <SalesHistory />;
      case 'delivery':
        if (!plan.has('delivery') && !plan.has('whatsapp')) return <PlanLocked feature="delivery" />;
        return (
          <div className="space-y-6">
            <div className="flex items-center gap-2 bg-white p-2 rounded-2xl border border-stone-200 w-fit shadow-sm">
              <button
                onClick={() => setDeliverySubTab('rappi')}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs transition-all ${
                  deliverySubTab === 'rappi'
                    ? 'bg-gradient-to-r from-orange-600 to-amber-600 text-white shadow-md'
                    : 'text-gray-600 hover:bg-orange-50'
                }`}
              >
                <Zap className="w-4 h-4" />
                <span>{t('layout:rappi_partners_simulador_despacho')}</span>
              </button>
              <button
                onClick={() => setDeliverySubTab('whatsapp')}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs transition-all ${
                  deliverySubTab === 'whatsapp'
                    ? 'bg-emerald-600 text-white shadow-md'
                    : 'text-gray-600 hover:bg-emerald-50'
                }`}
              >
                <MessageCircle className="w-4 h-4" />
                <span>{t('layout:whatsapp_bot_smartphone_virtual')}</span>
              </button>
            </div>

            {deliverySubTab === 'rappi' ? (
              <RappiOrdersPanel
                sales={deliverySales}
                onOrderSimulated={handleIncomingOrder}
              />
            ) : (
              <WhatsAppBotSimulator
                products={products}
                onOrderCreated={handleIncomingOrder}
              />
            )}
          </div>
        );
      case 'cash':
        return <CashSessionPanel />;
      case 'analytics':
        return plan.has('analytics_adv') ? <AnalyticsModule /> : <PlanLocked feature="analytics_adv" />;
      case 'agents':
        return <AgentsModule />;
      case 'online':
        return <OnlineOrdersModule businessName={business.settings?.businessName || 'Lantify'} />;
      case 'reservations':
        return <ReservationsModule businessName={business.settings?.businessName || 'Lantify'} />;
      default:
        return <ProductGrid />;
    }
  };

  const isCartVisible = (tableOrderMode && !!selectedTable) || activeTab === 'products';

  return (
    <div className="h-screen flex flex-col overflow-hidden bg-slate-100 font-sans">
      <SubscriptionBanner />
      {showAdmin ? (
        <AdminPanel
          key={adminInitialTab || 'admin'}
          user={user}
          onLogout={onLogout!}
          initialTab={adminInitialTab}
          onClose={() => {
            setAdminInitialTab(undefined);
            const mode = getTableViewMode();
            setViewMode(mode);
            if (mode === 'operational' && activeTab === 'tables') setActiveTab('products');
            setShowAdmin(false);
          }}
        />
      ) : (
        <>
          <Header 
            activeTab={activeTab} 
            onTabChange={handleTabChange} 
            tableViewMode={isOperational ? 'operational' : 'floorplan'}
            user={user}
            onLogout={onLogout}
            onOpenAdmin={() => {
              if (user?.role === 'ADMIN') setShowAdmin(true);
            }}
            onOpenStorefront={openBusinessPage}
            onSeedDemo={handleSeedDemo}
            isSeeding={isSeeding}
            isPrototypeMode={isPrototypeMode}
            onTogglePrototypeMode={user?.role === 'ADMIN' ? handleTogglePrototypeMode : undefined}
          />

          {/* Prototype Mode Context Bar */}
          {isPrototypeMode && (
            <div className="bg-slate-900 border-b border-slate-800 text-white px-4 py-1.5 flex items-center justify-between text-xs shadow-inner">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 bg-blue-600 text-white font-bold rounded-full text-xs tracking-wider uppercase shadow-sm">
                  {t('layout:laboratorio_multicanal')}
                </span>
                <span className="font-medium text-slate-300 hidden md:inline">
                  {t('layout:ambiente_omnicanal_delivery_rappi_whatsapp_bot_cat')}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={openBusinessPage}
                  className="text-xs text-cyan-400 hover:text-cyan-300 underline font-bold"
                >
                  {t('layout:abrir_mi_pagina')}
                </button>
                <span className="text-slate-600">•</span>
                <button
                  onClick={handleTogglePrototypeMode}
                  className="text-xs text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 px-2 py-0.5 rounded font-bold transition-all border border-slate-700"
                >
                  {t('layout:volver_a_modo_base')}
                </button>
              </div>
            </div>
          )}
          
          <main className="flex-1 flex overflow-hidden">
            <div className="flex-1 flex flex-col lg:flex-row gap-0 overflow-hidden p-2 lg:p-4">
              {/* Selector lateral de mesas (vista operativa) */}
              {isOperational && usesTables && activeTab === 'products' && (
                <aside className="w-full lg:w-64 xl:w-72 lg:shrink-0 lg:mr-4 h-48 lg:h-full">
                  <TableSidebar />
                </aside>
              )}
              {/* Main Content Area */}
              <div className={`overflow-auto ${
                isCartVisible 
                  ? 'lg:basis-[60%] lg:max-w-[60%]' 
                  : 'flex-1'
              }`}>
                {activeTab === 'cash' && !tableOrderMode ? (
                  <div className="w-full max-w-7xl mx-auto px-2 lg:px-4 py-2">
                    {renderContent()}
                  </div>
                ) : activeTab === 'delivery' && !tableOrderMode ? (
                  <div className="w-full max-w-7xl mx-auto px-2 lg:px-4 py-2">
                    {renderContent()}
                  </div>
                ) : activeTab === 'analytics' && !tableOrderMode ? (
                  <div className="w-full max-w-7xl mx-auto px-2 lg:px-4 py-2">
                    {renderContent()}
                  </div>
                ) : activeTab === 'sales' && !tableOrderMode ? (
                  <div className="w-full max-w-[1550px] mx-auto px-2 lg:px-4 py-2">
                    {renderContent()}
                  </div>
                ) : activeTab === 'tables' && !tableOrderMode ? (
                  <div className="w-full max-w-7xl mx-auto px-2 lg:px-6 py-2">
                    {renderContent()}
                  </div>
                ) : (
                  renderContent()
                )}
              </div>

              {/* Sidebar - Cart (Visible in table order mode and products counter mode) */}
              {isCartVisible && (
                <aside className="w-full lg:basis-[40%] h-full lg:ml-4 relative z-10 flex flex-col overflow-hidden">
                  <div className="h-full flex flex-col overflow-hidden bg-white rounded-3xl shadow-sm border border-slate-200/90">
                    <Cart onOrderComplete={handleOrderComplete} />
                  </div>
                </aside>
              )}
            </div>
          </main>

          {/* Variant Modal */}
          <VariantModal />

          {/* Floating Incoming Order Notification (Prototype Only) */}
          {isPrototypeMode && (
            <IncomingOrderNotification
              order={incomingOrder}
              onClose={() => setIncomingOrder(null)}
              onViewSales={() => {
                setActiveTab('sales');
                setIncomingOrder(null);
              }}
            />
          )}
        </>
      )}
      <HelpCenter role={role} />
      <TourOffer role={role} />
    </div>
  );
};

export default Layout;