// ============================================
// ROUTES - Prototype & Multi-Channel API
// (Rappi Connector, WhatsApp Bot, Public Web Store, Demo Seed)
// ============================================

import { Router, Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';

const router = Router();
const prisma = new PrismaClient();

const generateSaleNumber = () => {
  const now = new Date();
  const ymd = `${now.getFullYear()}${(now.getMonth() + 1).toString().padStart(2, '0')}${now.getDate().toString().padStart(2, '0')}`;
  const rand = Math.floor(1000 + Math.random() * 9000);
  return `SALE-${ymd}-${rand}`;
};

// ----------------------------------------------------
// 1. SEED PROTOTYPE DATA
// ----------------------------------------------------
router.post('/seed-demo-data', async (_req: Request, res: Response) => {
  try {
    // 1. Ensure Categories
    const categoriesData = [
      { name: 'Cafés Especiales', description: 'Selección de origen y filtrados' },
      { name: 'Platos Principales', description: 'Hamburguesas y especialidades de la casa' },
      { name: 'Bowls & Desayunos', description: 'Opciones saludables y energéticas' },
      { name: 'Postres & Dulces', description: 'Repostería artesanal' }
    ];

    const categoryMap: Record<string, string> = {};
    for (const cat of categoriesData) {
      let existing = await prisma.category.findFirst({ where: { name: cat.name } });
      if (!existing) {
        existing = await prisma.category.create({ data: cat });
      }
      categoryMap[cat.name] = existing.id;
    }

    // 2. Ensure Products & Variants
    const demoProducts = [
      {
        name: 'Café Geisha Huila Filtrado',
        description: 'Notas florales de jazmín, melocotón y miel. Preparación en V60.',
        categoryName: 'Cafés Especiales',
        imageUrl: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=500&q=80',
        variants: [
          { name: 'Taza 8oz', sku: 'GEO-8OZ', price: 9500, stock: 80, trackInventory: true },
          { name: 'Taza 12oz', sku: 'GEO-12OZ', price: 13500, stock: 65, trackInventory: true }
        ]
      },
      {
        name: 'Cold Brew Vainilla Nativo',
        description: 'Macerado en frío por 18 horas con infusión de vaina de vainilla.',
        categoryName: 'Cafés Especiales',
        imageUrl: 'https://images.unsplash.com/photo-1517701550927-30cf4ba1dba5?w=500&q=80',
        variants: [
          { name: 'Botella 350ml', sku: 'CB-350', price: 11000, stock: 45, trackInventory: true }
        ]
      },
      {
        name: 'Hamburguesa Nativa Suprema',
        description: 'Carne Angus 180g, queso cheddar madurado, tocineta ahumada y cebollas caramelizadas.',
        categoryName: 'Platos Principales',
        imageUrl: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=500&q=80',
        variants: [
          { name: 'Sencilla (180g)', sku: 'HMB-SUP-180', price: 28000, stock: 40, trackInventory: true },
          { name: 'Doble Carne (360g)', sku: 'HMB-SUP-360', price: 36000, stock: 30, trackInventory: true }
        ]
      },
      {
        name: 'Bowl Campestre de Pollo y Aguacate',
        description: 'Pechuga marinada a las hierbas, quinoa, aguacate hass, tomates cherry y vinagreta de mostaza miel.',
        categoryName: 'Bowls & Desayunos',
        imageUrl: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&q=80',
        variants: [
          { name: 'Mediano', sku: 'BWL-MED', price: 24000, stock: 35, trackInventory: true },
          { name: 'Grande', sku: 'BWL-GRD', price: 29000, stock: 25, trackInventory: true }
        ]
      },
      {
        name: 'Cheesecake de Frutos Rojos',
        description: 'Base de galleta artesanal, queso crema suave y salsa reducida de moras y arándanos frescos.',
        categoryName: 'Postres & Dulces',
        imageUrl: 'https://images.unsplash.com/photo-1533134242443-d4fd215305ad?w=500&q=80',
        variants: [
          { name: 'Porción Individual', sku: 'CHK-FR', price: 14500, stock: 20, trackInventory: true }
        ]
      }
    ];

    const allVariants: any[] = [];

    for (const p of demoProducts) {
      let product = await prisma.product.findFirst({
        where: { name: p.name },
        include: { variants: true }
      });

      if (!product) {
        product = await prisma.product.create({
          data: {
            name: p.name,
            description: p.description,
            imageUrl: p.imageUrl,
            categoryId: categoryMap[p.categoryName],
            variants: {
              create: p.variants.map(v => ({
                name: v.name,
                sku: v.sku,
                price: v.price,
                stock: v.stock,
                trackInventory: v.trackInventory
              }))
            }
          },
          include: { variants: true }
        });
      }

      allVariants.push(...product.variants);
    }

    // 3. Ensure Open Cash Session for demo sales
    let openSession = await prisma.cashSession.findFirst({
      where: { status: 'OPEN' }
    });

    if (!openSession) {
      openSession = await prisma.cashSession.create({
        data: {
          sessionNumber: `ARQ-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-001`,
          initialBalance: 200000,
          status: 'OPEN',
          notes: 'Arqueo de demostración multicanal'
        }
      });
    }

    // 4. Create Simulated Multi-channel Sales
    const simulatedCustomers = [
      { name: 'Valentina Restrepo', phone: '3157894512', address: 'Calle 116 # 15-28 Apto 401', channel: 'RAPPI', payment: 'RAPPI_PAY' },
      { name: 'Carlos Mario Duque', phone: '3104523698', address: 'Carrera 7 # 124-50 Torre 2', channel: 'RAPPI', payment: 'RAPPI_PAY' },
      { name: 'Daniela Salazar', phone: '3189652147', address: 'Calle 140 # 9-33', channel: 'RAPPI', payment: 'RAPPI_PAY' },
      { name: 'Sebastián Morales', phone: '3007418529', address: 'Transversal 23 # 98-15', channel: 'WHATSAPP', payment: 'NEQUI' },
      { name: 'Laura Camila Peña', phone: '3123654789', address: 'Carrera 15 # 82-40 Of 502', channel: 'WHATSAPP', payment: 'DAVIPLATA' },
      { name: 'Andrés Felipe Castro', phone: '3208529631', address: 'Calle 100 # 19A-60', channel: 'WHATSAPP', payment: 'NEQUI' },
      { name: 'Mariana Gómez', phone: '3141237890', address: 'Calle 85 # 11-53', channel: 'WEB', payment: 'NEQUI' },
      { name: 'Felipe Jaramillo', phone: '3114561230', address: 'Carrera 9 # 72-10', channel: 'WEB', payment: 'CASH' },
      { name: 'Cliente Salón Mesa 1', phone: '', address: '', channel: 'POS', payment: 'CARD' },
      { name: 'Cliente Salón Mesa 3', phone: '', address: '', channel: 'POS', payment: 'CASH' },
      { name: 'Cliente Mostrador', phone: '', address: '', channel: 'POS', payment: 'TRANSFER' }
    ];

    let createdCount = 0;

    for (let i = 0; i < simulatedCustomers.length; i++) {
      const c = simulatedCustomers[i];
      const randomVariant1 = allVariants[Math.floor(Math.random() * allVariants.length)];
      const randomVariant2 = allVariants[Math.floor(Math.random() * allVariants.length)];
      
      const items = [
        { variant: randomVariant1, qty: Math.floor(Math.random() * 2) + 1 },
        ...(randomVariant1.id !== randomVariant2.id ? [{ variant: randomVariant2, qty: 1 }] : [])
      ];

      const subtotal = items.reduce((acc, it) => acc + (it.variant.price * it.qty), 0);
      const tax = Math.round(subtotal * 0.08); // impoconsumo 8%
      const total = subtotal + tax;

      // Spread dates across the last 5 days
      const daysAgo = i % 5;
      const saleDate = new Date();
      saleDate.setDate(saleDate.getDate() - daysAgo);
      saleDate.setHours(11 + (i % 10), (i * 17) % 60);

      await prisma.sale.create({
        data: {
          saleNumber: generateSaleNumber(),
          cashSessionId: openSession.id,
          channel: c.channel,
          customerName: c.name,
          customerPhone: c.phone || null,
          customerAddress: c.address || null,
          deliveryNotes: c.channel !== 'POS' ? 'Timbrar al llegar y solicitar confirmación' : null,
          subtotal,
          tax,
          discount: 0,
          discountPct: 0,
          total,
          paymentMethod: c.payment,
          status: 'COMPLETED',
          notes: `Pedido prototipo (${c.channel})`,
          createdAt: saleDate,
          items: {
            create: items.map(it => ({
              productVariantId: it.variant.id,
              quantity: it.qty,
              unitPrice: it.variant.price,
              total: it.variant.price * it.qty
            }))
          },
          payments: {
            create: [
              {
                amount: total,
                paymentMethod: c.payment,
                cashSessionId: openSession.id,
                notes: `Pago verificado (${c.payment})`,
                createdAt: saleDate
              }
            ]
          }
        }
      });

      createdCount++;
    }

    return res.json({
      success: true,
      message: `Prototipo cargado: ${demoProducts.length} productos gourmet y ${createdCount} ventas multicanal generadas.`,
      categoriesCount: Object.keys(categoryMap).length,
      productsCount: demoProducts.length,
      salesCount: createdCount
    });
  } catch (error: any) {
    console.error('Error seeding demo data:', error);
    return res.status(500).json({ error: error.message || 'Error al generar datos demo' });
  }
});

// ----------------------------------------------------
// 2. SIMULADOR RAPPI (Incoming Order Webhook)
// ----------------------------------------------------
router.post('/rappi/simulate-order', async (req: Request, res: Response) => {
  try {
    const variants = await prisma.productVariant.findMany({
      where: { isActive: true },
      include: { product: true },
      take: 6
    });

    if (variants.length === 0) {
      return res.status(400).json({ error: 'No hay productos disponibles para simular pedido de Rappi' });
    }

    // Pick 1-2 random items
    const selectedVariant = variants[Math.floor(Math.random() * variants.length)];
    const secondVariant = variants[(Math.floor(Math.random() * variants.length) + 1) % variants.length];

    const orderItems = [
      { variantId: selectedVariant.id, name: `${selectedVariant.product.name} (${selectedVariant.name})`, price: selectedVariant.price, qty: 1 }
    ];

    if (Math.random() > 0.4 && secondVariant.id !== selectedVariant.id) {
      orderItems.push({
        variantId: secondVariant.id,
        name: `${secondVariant.product.name} (${secondVariant.name})`,
        price: secondVariant.price,
        qty: 1
      });
    }

    const subtotal = orderItems.reduce((acc, it) => acc + it.price * it.qty, 0);
    const tax = Math.round(subtotal * 0.08);
    const total = subtotal + tax;

    const names = ['Sofía Vergara', 'Juan Camilo Reyes', 'Andrea Echeverri', 'Diego Londoño', 'Paula Barrientos'];
    const addresses = ['Calle 127 # 19-45 Apto 502', 'Carrera 11 # 94-22 Edificio Ámbar', 'Transversal 6 # 82-15', 'Calle 106 # 14-30'];
    const phones = ['+57 310 987 6543', '+57 315 874 1236', '+57 301 452 7896', '+57 320 654 3210'];

    const customerName = req.body.customerName || names[Math.floor(Math.random() * names.length)];
    const customerAddress = req.body.customerAddress || addresses[Math.floor(Math.random() * addresses.length)];
    const customerPhone = req.body.customerPhone || phones[Math.floor(Math.random() * phones.length)];
    const deliveryNotes = req.body.deliveryNotes || 'Dejar en portería con el celador si no contesta';

    let openSession = await prisma.cashSession.findFirst({ where: { status: 'OPEN' } });

    const newSale = await prisma.sale.create({
      data: {
        saleNumber: generateSaleNumber(),
        cashSessionId: openSession ? openSession.id : null,
        channel: 'RAPPI',
        customerName,
        customerPhone,
        customerAddress,
        deliveryNotes,
        subtotal,
        tax,
        total,
        paymentMethod: 'RAPPI_PAY',
        status: 'COMPLETED',
        notes: `Rappi ID: #RP-${Math.floor(100000 + Math.random() * 900000)} | Repartidor asignado`,
        items: {
          create: orderItems.map(it => ({
            productVariantId: it.variantId,
            quantity: it.qty,
            unitPrice: it.price,
            total: it.price * it.qty
          }))
        },
        payments: openSession ? {
          create: [{
            amount: total,
            paymentMethod: 'RAPPI_PAY',
            cashSessionId: openSession.id,
            notes: 'Pago digital RappiPay liquidado automáticamente'
          }]
        } : undefined
      },
      include: {
        items: {
          include: {
            productVariant: {
              include: { product: true }
            }
          }
        }
      }
    });

    return res.json({
      success: true,
      message: 'Pedido de Rappi recibido exitosamente',
      order: newSale
    });
  } catch (error: any) {
    console.error('Error simulating Rappi order:', error);
    return res.status(500).json({ error: error.message || 'Error al procesar orden de Rappi' });
  }
});

// ----------------------------------------------------
// 3. WHATSAPP CHATBOT ENDPOINTS
// ----------------------------------------------------
router.post('/whatsapp/order', async (req: Request, res: Response) => {
  try {
    const { customerName, customerPhone, customerAddress, deliveryNotes, items, paymentMethod = 'NEQUI' } = req.body;

    if (!items || !items.length) {
      return res.status(400).json({ error: 'La orden de WhatsApp debe contener al menos un producto' });
    }

    let subtotal = 0;
    const formattedItems: any[] = [];

    for (const it of items) {
      const variant = await prisma.productVariant.findUnique({
        where: { id: it.variantId || it.productVariantId }
      });
      if (variant) {
        const qty = it.quantity || 1;
        const lineTotal = variant.price * qty;
        subtotal += lineTotal;
        formattedItems.push({
          productVariantId: variant.id,
          quantity: qty,
          unitPrice: variant.price,
          total: lineTotal
        });
      }
    }

    const tax = Math.round(subtotal * 0.08);
    const total = subtotal + tax;

    let openSession = await prisma.cashSession.findFirst({ where: { status: 'OPEN' } });

    const newSale = await prisma.sale.create({
      data: {
        saleNumber: generateSaleNumber(),
        cashSessionId: openSession ? openSession.id : null,
        channel: 'WHATSAPP',
        customerName: customerName || 'Cliente WhatsApp',
        customerPhone: customerPhone || null,
        customerAddress: customerAddress || null,
        deliveryNotes: deliveryNotes || 'Confirmado por WhatsApp Bot',
        subtotal,
        tax,
        total,
        paymentMethod: paymentMethod || 'NEQUI',
        status: 'COMPLETED',
        notes: `Chatbot WhatsApp | Comprobante verificado (${paymentMethod})`,
        items: {
          create: formattedItems
        },
        payments: openSession ? {
          create: [{
            amount: total,
            paymentMethod: paymentMethod || 'NEQUI',
            cashSessionId: openSession.id,
            notes: `Transferencia confirmada por Chatbot (${paymentMethod})`
          }]
        } : undefined
      },
      include: {
        items: {
          include: {
            productVariant: {
              include: { product: true }
            }
          }
        }
      }
    });

    return res.json({
      success: true,
      message: 'Pedido de WhatsApp registrado en el POS exitosamente',
      order: newSale
    });
  } catch (error: any) {
    console.error('Error in WhatsApp order:', error);
    return res.status(500).json({ error: error.message || 'Error al procesar orden de WhatsApp' });
  }
});

// ----------------------------------------------------
// 4. TIENDA WEB PUBLICA (Storefront Online Order)
// ----------------------------------------------------
router.post('/web/order', async (req: Request, res: Response) => {
  try {
    const { customerName, customerPhone, customerAddress, deliveryNotes, items, paymentMethod = 'NEQUI' } = req.body;

    if (!customerName || !customerPhone) {
      return res.status(400).json({ error: 'Nombre y teléfono de contacto son requeridos' });
    }

    if (!items || items.length === 0) {
      return res.status(400).json({ error: 'El carrito no contiene productos' });
    }

    let subtotal = 0;
    const formattedItems: any[] = [];

    for (const it of items) {
      const variant = await prisma.productVariant.findUnique({
        where: { id: it.variantId || it.productVariantId }
      });
      if (variant) {
        const qty = it.quantity || 1;
        const lineTotal = variant.price * qty;
        subtotal += lineTotal;
        formattedItems.push({
          productVariantId: variant.id,
          quantity: qty,
          unitPrice: variant.price,
          total: lineTotal
        });
      }
    }

    const tax = Math.round(subtotal * 0.08);
    const total = subtotal + tax;

    let openSession = await prisma.cashSession.findFirst({ where: { status: 'OPEN' } });

    const newSale = await prisma.sale.create({
      data: {
        saleNumber: generateSaleNumber(),
        cashSessionId: openSession ? openSession.id : null,
        channel: 'WEB',
        customerName,
        customerPhone,
        customerAddress: customerAddress || 'Para recoger en el local',
        deliveryNotes: deliveryNotes || 'Pedido desde Tienda Web Lantify',
        subtotal,
        tax,
        total,
        paymentMethod: paymentMethod || 'NEQUI',
        status: 'COMPLETED',
        notes: `Tienda Web Oficial | Contacto: ${customerPhone}`,
        items: {
          create: formattedItems
        },
        payments: openSession ? {
          create: [{
            amount: total,
            paymentMethod: paymentMethod || 'NEQUI',
            cashSessionId: openSession.id,
            notes: `Pago Online (${paymentMethod})`
          }]
        } : undefined
      },
      include: {
        items: {
          include: {
            productVariant: {
              include: { product: true }
            }
          }
        }
      }
    });

    return res.json({
      success: true,
      message: '¡Tu pedido ha sido recibido y enviado directamente a la cocina del restaurante!',
      order: newSale
    });
  } catch (error: any) {
    console.error('Error creating web order:', error);
    return res.status(500).json({ error: error.message || 'Error al procesar orden de la tienda web' });
  }
});

// ----------------------------------------------------
// 5. CANALES STATS SUMMARY
// ----------------------------------------------------
const handleChannelStats = async (_req: Request, res: Response) => {
  try {
    const sales = await prisma.sale.findMany({
      where: { status: 'COMPLETED' },
      select: {
        channel: true,
        total: true,
        paymentMethod: true
      }
    });

    const breakdown: Record<string, { count: number; total: number }> = {
      POS: { count: 0, total: 0 },
      RAPPI: { count: 0, total: 0 },
      WHATSAPP: { count: 0, total: 0 },
      WEB: { count: 0, total: 0 }
    };

    let grandTotal = 0;

    for (const s of sales) {
      const ch = s.channel || 'POS';
      if (!breakdown[ch]) {
        breakdown[ch] = { count: 0, total: 0 };
      }
      breakdown[ch].count += 1;
      breakdown[ch].total += s.total;
      grandTotal += s.total;
    }

    return res.json({
      totalSales: sales.length,
      grandTotal,
      channels: breakdown
    });
  } catch (error: any) {
    console.error('Error fetching channel stats:', error);
    return res.status(500).json({ error: 'Error al consultar estadísticas por canal' });
  }
};

router.get('/channels/stats', handleChannelStats);
router.get('/channel-stats', handleChannelStats);

export default router;
