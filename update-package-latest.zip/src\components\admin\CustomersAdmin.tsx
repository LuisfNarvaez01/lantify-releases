import React, { useState, useEffect } from 'react';
import { confirmDialog } from '../../shared/dialog';
import { customersAPI } from '../../services/api';
import { Customer } from '../../types';
import { Search, Plus, Edit2, Trash2, Cake, Phone, Mail, MapPin, Award, User, Calendar, FileText, Sparkles, X, ShoppingBag } from 'lucide-react';
import { toast } from '../../shared/toast';


import { t } from '../../i18n';
export const CustomersAdmin: React.FC = () => {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [birthdays, setBirthdays] = useState<Customer[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [recommendedProducts, setRecommendedProducts] = useState<any[]>([]);
  const [isLoadingRecs, setIsLoadingRecs] = useState(false);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isAdjustingStamps, setIsAdjustingStamps] = useState(false);

  const handleAdjustStamps = async (customer: Customer, delta: number) => {
    setIsAdjustingStamps(true);
    try {
      const reason = delta > 0 ? 'Ajuste manual desde POS (+)' : 'Ajuste manual desde POS (-)';
      const updated = await customersAPI.adjustStamps(customer.id, delta, reason);
      const newStamps = updated.stampsCount ?? Math.max(0, (customer.stampsCount ?? 0) + delta);
      const updatedCust = {
        ...customer,
        stampsCount: newStamps,
        lifetimeStamps: updated.lifetimeStamps ?? (customer.lifetimeStamps ?? 0) + (delta > 0 ? delta : 0)
      };
      setCustomers((prev) => prev.map((c) => (c.id === customer.id ? updatedCust : c)));
      if (selectedCustomer?.id === customer.id) {
        setSelectedCustomer(updatedCust);
      }
      toast.success(delta > 0 ? `+${delta} Sello agregado` : `${delta} Sello restado`);
    } catch (err: any) {
      console.error('Error adjusting stamps:', err);
      toast.error(err.message || 'Error al ajustar sellos');
    } finally {
      setIsAdjustingStamps(false);
    }
  };

  // Form State
  const [form, setForm] = useState({
    name: '',
    nit: '',
    phone: '',
    email: '',
    address: '',
    birthDate: '',
    notes: ''
  });

  useEffect(() => {
    loadCustomers();
    loadBirthdays();
  }, []);

  const loadCustomers = async () => {
    try {
      const data = await customersAPI.getAll();
      setCustomers(data);
    } catch (err: any) {
      console.error('Error loading customers:', err);
    }
  };

  const loadBirthdays = async () => {
    try {
      const data = await customersAPI.getBirthdays();
      setBirthdays(data);
    } catch (err: any) {
      console.error('Error loading birthdays:', err);
    }
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (searchTerm.trim() === '') {
        loadCustomers();
      } else {
        const data = await customersAPI.search(searchTerm);
        setCustomers(data);
      }
    } catch (err: any) {
      console.error('Error searching customers:', err);
    }
  };

  const openCreateForm = () => {
    setEditingCustomer(null);
    setForm({
      name: '',
      nit: '',
      phone: '',
      email: '',
      address: '',
      birthDate: '',
      notes: ''
    });
    setError(null);
    setIsFormOpen(true);
  };

  const openEditForm = (customer: Customer) => {
    setEditingCustomer(customer);
    setForm({
      name: customer.name,
      nit: customer.nit || '',
      phone: customer.phone || '',
      email: customer.email || '',
      address: customer.address || '',
      birthDate: customer.birthDate ? new Date(customer.birthDate).toISOString().split('T')[0] : '',
      notes: customer.notes || ''
    });
    setError(null);
    setIsFormOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!form.name.trim()) {
      setError(t('customers:el_nombre_es_obligatorio'));
      return;
    }

    try {
      const payload = {
        ...form,
        nit: form.nit.trim() || undefined,
        phone: form.phone.trim() || undefined,
        email: form.email.trim() || undefined,
        address: form.address.trim() || undefined,
        birthDate: form.birthDate || undefined,
        notes: form.notes.trim() || undefined
      };

      if (editingCustomer) {
        await customersAPI.update(editingCustomer.id, payload);
      } else {
        await customersAPI.create(payload);
      }

      setIsFormOpen(false);
      loadCustomers();
      loadBirthdays();
    } catch (err: any) {
      console.error('Error saving customer:', err);
      setError(err.message || t('customers:error_al_guardar_el_cliente'));
    }
  };

  const handleDelete = async (customer: Customer) => {
    if (customer.isDefault) {
      toast.warning(t('customers:no_se_puede_desactivar_el_cliente_comun'));
      return;
    }

    if (!(await confirmDialog({ title: t('customers:desactivar_a_name', { name: customer.name }), message: t('customers:el_cliente_dejara_de_aparecer_en_las'), confirmLabel: t('customers:desactivar'), tone: 'danger' }))) return;

    try {
      await customersAPI.delete(customer.id);
      toast.success(t('customers:cliente_name_desactivado', { name: customer.name }));
      loadCustomers();
      loadBirthdays();
      if (selectedCustomer?.id === customer.id) {
        setSelectedCustomer(null);
      }
    } catch (err: any) {
      console.error('Error deactivating customer:', err);
      toast.error(err.message || 'Error al desactivar el cliente');
    }
  };

  const selectCustomerDetails = async (customer: Customer) => {
    setSelectedCustomer(customer);
    setIsLoadingRecs(true);
    setRecommendedProducts([]);
    try {
      const recs = await customersAPI.getRecommended(customer.id);
      setRecommendedProducts(recs);
    } catch (err) {
      console.error('Error loading recommendations:', err);
    } finally {
      setIsLoadingRecs(false);
    }
  };

  const getLoyaltyBadge = (visits: number) => {
    if (visits >= 20) return { label: t('customers:platino'), style: 'bg-indigo-100 text-indigo-800 border-indigo-200' };
    if (visits >= 10) return { label: t('customers:oro'), style: 'bg-amber-100 text-amber-800 border-amber-200' };
    if (visits >= 5) return { label: t('customers:plata'), style: 'bg-slate-100 text-slate-800 border-slate-200' };
    return { label: t('customers:bronce'), style: 'bg-orange-50 text-orange-800 border-orange-100' };
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Left 2 Cols: Customer List & Birthday Banner */}
      <div className="lg:col-span-2 space-y-6">
        {/* Birthdays Ribbon */}
        {birthdays.length > 0 && (
          <div className="bg-slate-900 border border-slate-800 text-white p-4 rounded-3xl shadow-md flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-amber-500 rounded-2xl shadow-sm text-slate-950">
                <Cake className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-base tracking-wide flex items-center gap-1.5 font-heading">
                  {t('customers:cumpleanos_de_clientes')}
                  <Sparkles className="w-4 h-4 text-amber-400" />
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  {birthdays.length === 1
                    ? t('customers:1_cliente_cumple_anos_esta_semana_ofrecele')
                    : t('customers:length_clientes_cumplen_anos_esta_semana_ofreceles', { length: birthdays.length })}
                </p>
              </div>
            </div>
            <div className="flex -space-x-2 overflow-hidden">
              {birthdays.map((b) => (
                <div
                  key={b.id}
                  onClick={() => selectCustomerDetails(b)}
                  className="w-8 h-8 rounded-full bg-blue-100 border-2 border-white flex items-center justify-center text-xs font-bold text-blue-700 cursor-pointer hover:-translate-y-1 transition-transform shadow-sm"
                  title={b.name}
                >
                  {b.name.charAt(0).toUpperCase()}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Search & Actions */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm flex flex-col md:flex-row gap-4 items-center justify-between">
          <form onSubmit={handleSearch} className="relative w-full md:max-w-md">
            <input
              type="text"
              placeholder={t('customers:buscar_por_nombre_nit_o_telefono')}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-slate-900 font-medium text-sm outline-none"
            />
            <Search className="absolute left-3.5 top-3.5 w-5 h-5 text-slate-400" />
          </form>
          
          <button
            onClick={openCreateForm}
            className="w-full md:w-auto flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-2xl font-bold transition-all shadow-sm"
          >
            <Plus className="w-5 h-5" />
            {t('customers:registrar_cliente')}
          </button>
        </div>

        {/* Customer List */}
        <div className="bg-white rounded-3xl border border-slate-200/80 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-slate-900 text-slate-200 text-xs font-semibold uppercase tracking-wider">
                  <th className="px-6 py-4 text-left font-bold tracking-wider">{t('customers:cliente')}</th>
                  <th className="px-6 py-4 text-left font-bold tracking-wider">{t('customers:nit_cedula')}</th>
                  <th className="px-6 py-4 text-left font-bold tracking-wider">{t('customers:contacto')}</th>
                  <th className="px-6 py-4 text-center font-bold tracking-wider">{t('customers:fidelidad')}</th>
                  <th className="px-6 py-4 text-center font-bold tracking-wider w-24">{t('customers:acciones')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {customers.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="text-center py-8 text-gray-500 font-medium">
                      {t('customers:no_se_encontraron_clientes_registrados')}
                    </td>
                  </tr>
                ) : (
                  customers.map((c) => {
                    const badge = getLoyaltyBadge(c.visitCount);
                    const isBdayUpcoming = birthdays.some((b) => b.id === c.id);
                    return (
                      <tr
                        key={c.id}
                        className={`hover:bg-slate-50 transition-colors cursor-pointer ${
                          selectedCustomer?.id === c.id ? 'bg-blue-50/50' : ''
                        }`}
                        onClick={() => selectCustomerDetails(c)}
                      >
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2">
                            <div>
                              <div className="font-extrabold text-slate-800 flex items-center gap-1.5">
                                {c.isDefault ? t('pos:cliente_comun') : c.name}
                                {c.isDefault && (
                                  <span className="text-xs px-1.5 py-0.5 bg-slate-100 text-slate-600 rounded">
                                    {t('customers:por_defecto')}
                                  </span>
                                )}
                                {isBdayUpcoming && (
                                  <span className="text-pink-600 animate-pulse" title={t('customers:cumpleanos_esta_semana')}>
                                    <Cake className="w-4 h-4 inline" />
                                  </span>
                                )}
                              </div>
                              {c.birthDate && (
                                <div className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                                  <Calendar className="w-3.5 h-3.5" />
                                  {new Date(c.birthDate).toLocaleDateString('es-ES', {
                                    day: 'numeric',
                                    month: 'long',
                                    timeZone: 'UTC'
                                  })}
                                </div>
                              )}
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-sm font-semibold text-slate-600">
                          {c.nit || t('customers:sin_registro')}
                        </td>
                        <td className="px-6 py-4">
                          <div className="space-y-0.5">
                            {c.phone && (
                              <div className="text-xs text-slate-600 flex items-center gap-1 font-medium">
                                <Phone className="w-3.5 h-3.5 text-slate-400" />
                                {c.phone}
                              </div>
                            )}
                            {c.email && (
                              <div className="text-xs text-slate-600 flex items-center gap-1 font-medium">
                                <Mail className="w-3.5 h-3.5 text-slate-400" />
                                {c.email}
                              </div>
                            )}
                            {!c.phone && !c.email && <span className="text-xs text-slate-400 italic">{t('customers:sin_datos')}</span>}
                          </div>
                        </td>
                        <td className="px-6 py-4 text-center">
                          <div className="flex flex-col items-center gap-1">
                            <span className={`text-xs font-bold px-2 py-0.5 rounded-full border ${badge.style}`}>
                              {badge.label}
                            </span>
                            <span className="text-[11px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200/60 tabular-nums">
                              🏷️ {c.stampsCount ?? 0}/10 sellos
                            </span>
                            <span className="text-xs text-slate-500 font-medium tabular-nums">
                              {t('customers:visitcount_compras_totalspent_cop', { visitCount: c.visitCount, totalSpent: c.totalSpent.toLocaleString() })}
                            </span>
                          </div>
                        </td>
                        <td className="px-6 py-4" onClick={(e) => e.stopPropagation()}>
                          <div className="flex justify-center gap-1.5">
                            <button
                              onClick={() => openEditForm(c)}
                              className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                              title={t('customers:editar')}
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            {!c.isDefault && (
                              <button
                                onClick={() => handleDelete(c)}
                                className="p-1.5 text-rose-500 hover:bg-rose-50 rounded-lg transition-colors"
                                title={t('customers:eliminar')}
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Right Column: Customer Profile & Recommendation */}
      <div className="lg:col-span-1 space-y-6">
        {selectedCustomer ? (
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-6">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <h3 className="font-extrabold text-lg text-slate-800 flex items-center gap-2">
                <User className="w-5 h-5 text-blue-600" />
                {t('customers:detalle_del_cliente')}
              </h3>
              <button
                onClick={() => setSelectedCustomer(null)}
                className="text-slate-400 hover:bg-slate-100 p-1.5 rounded-xl transition-all"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Profile Info */}
            <div className="space-y-4">
              <div>
                <h4 className="text-xl font-black text-slate-900">{selectedCustomer.name}</h4>
                {selectedCustomer.nit && <p className="text-xs text-slate-500 font-bold">{t('customers:nit')}{' '}{selectedCustomer.nit}</p>}
              </div>

              {/* Quick statistics card */}
              <div className="grid grid-cols-2 gap-3 bg-slate-50 p-4 rounded-2xl border border-slate-200">
                <div className="text-center border-r border-slate-200">
                  <span className="block text-xs font-bold text-slate-500 uppercase tracking-wider">{t('customers:compras')}</span>
                  <span className="text-2xl font-black text-slate-900 tabular-nums">{selectedCustomer.visitCount}</span>
                </div>
                <div className="text-center">
                  <span className="block text-xs font-bold text-slate-500 uppercase tracking-wider">{t('customers:consumo_total')}</span>
                  <span className="text-base font-black text-emerald-600 block mt-1 tabular-nums">
                    ${selectedCustomer.totalSpent.toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Loyalty Stamps Card */}
              <div className="bg-gradient-to-br from-amber-500/10 via-orange-500/5 to-amber-500/10 border border-amber-200/80 p-4 rounded-2xl space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Award className="w-5 h-5 text-amber-600" />
                    <div>
                      <span className="font-extrabold text-sm text-amber-950 block">Tarjeta de Fidelidad</span>
                      <span className="text-[10px] text-amber-700">Meta: 10 sellos para premio gratis</span>
                    </div>
                  </div>
                  <span className="text-xs font-black bg-amber-500 text-white px-2.5 py-1 rounded-full tabular-nums shadow-sm">
                    {selectedCustomer.stampsCount ?? 0} / 10
                  </span>
                </div>

                {/* Progress mini dots */}
                <div className="grid grid-cols-10 gap-1 py-1">
                  {Array.from({ length: 10 }).map((_, i) => {
                    const active = i < (selectedCustomer.stampsCount ?? 0);
                    return (
                      <div
                        key={i}
                        className={`h-5 rounded-md transition-all flex items-center justify-center text-[10px] font-black ${
                          active
                            ? 'bg-amber-500 text-white shadow-sm'
                            : 'bg-amber-100/70 text-amber-500/60 border border-amber-200/50'
                        }`}
                      >
                        {active ? '✓' : i + 1}
                      </div>
                    );
                  })}
                </div>

                <div className="flex items-center justify-between pt-1 border-t border-amber-200/50">
                  <span className="text-[11px] text-amber-800 font-medium">
                    Histórico total: <b>{selectedCustomer.lifetimeStamps ?? 0}</b> sellos
                  </span>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      disabled={isAdjustingStamps || (selectedCustomer.stampsCount ?? 0) <= 0}
                      onClick={() => handleAdjustStamps(selectedCustomer, -1)}
                      className="px-2.5 py-1 rounded-lg border border-amber-300 bg-white hover:bg-amber-100 text-amber-900 text-xs font-bold transition-all disabled:opacity-40"
                      title="Restar 1 sello"
                    >
                      - 1
                    </button>
                    <button
                      type="button"
                      disabled={isAdjustingStamps}
                      onClick={() => handleAdjustStamps(selectedCustomer, 1)}
                      className="px-3 py-1 rounded-lg bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold transition-all shadow-sm disabled:opacity-40"
                      title="Sumar 1 sello"
                    >
                      + 1 Sello
                    </button>
                  </div>
                </div>
              </div>

              <div className="space-y-2.5 text-sm text-slate-700 font-medium">
                {selectedCustomer.phone && (
                  <div className="flex items-start gap-2.5">
                    <Phone className="w-4 h-4 text-blue-600 mt-0.5" />
                    <span>{selectedCustomer.phone}</span>
                  </div>
                )}
                {selectedCustomer.email && (
                  <div className="flex items-start gap-2.5">
                    <Mail className="w-4 h-4 text-blue-600 mt-0.5" />
                    <span className="break-all">{selectedCustomer.email}</span>
                  </div>
                )}
                {selectedCustomer.address && (
                  <div className="flex items-start gap-2.5">
                    <MapPin className="w-4 h-4 text-blue-600 mt-0.5" />
                    <span>{selectedCustomer.address}</span>
                  </div>
                )}
                {selectedCustomer.birthDate && (
                  <div className="flex items-start gap-2.5">
                    <Calendar className="w-4 h-4 text-blue-600 mt-0.5" />
                    <span>
                      {t('customers:cumpleanos')}{' '}
                      {new Date(selectedCustomer.birthDate).toLocaleDateString('es-ES', {
                        day: 'numeric',
                        month: 'long',
                        timeZone: 'UTC'
                      })}
                    </span>
                  </div>
                )}
                {selectedCustomer.notes && (
                  <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-100 text-xs font-normal">
                    <p className="font-bold text-slate-500 mb-1 flex items-center gap-1">
                      <FileText className="w-3.5 h-3.5" />{' '}{t('customers:notas')}
                    </p>
                    <p className="text-slate-600 italic">{selectedCustomer.notes}</p>
                  </div>
                )}
              </div>
            </div>

            {/* Recommendations */}
            <div className="border-t border-slate-100 pt-5 space-y-4">
              <h4 className="font-extrabold text-sm text-slate-800 flex items-center gap-2">
                <ShoppingBag className="w-4.5 h-4.5 text-blue-600" />
                {t('customers:productos_mas_comprados')}
              </h4>
              {isLoadingRecs ? (
                <div className="flex justify-center py-4">
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-600"></div>
                </div>
              ) : recommendedProducts.length === 0 ? (
                <p className="text-xs text-slate-400 italic font-medium">{t('customers:no_hay_compras_previas_registradas')}</p>
              ) : (
                <div className="space-y-2">
                  {recommendedProducts.map((p, idx) => (
                    <div
                      key={idx}
                      className="flex justify-between items-center bg-slate-50 p-3 rounded-xl border border-slate-100 text-xs font-semibold text-slate-800"
                    >
                      <div className="flex items-center gap-2">
                        <span className="w-5 h-5 rounded-full bg-blue-50 text-blue-700 flex items-center justify-center font-bold text-xs">
                          {idx + 1}
                        </span>
                        <div>
                          <p>{p.name}</p>
                          <p className="text-xs text-slate-400 font-normal">
                            {p.variantName !== 'Default' ? p.variantName : t('customers:general')}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="text-slate-900 font-bold tabular-nums">{p.count}{' '}{t('customers:unid')}</span>
                        <p className="text-xs text-slate-400 font-normal tabular-nums">${p.price.toLocaleString()}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm text-center py-16 flex flex-col items-center justify-center space-y-3">
            <div className="w-16 h-16 rounded-full bg-blue-50 flex items-center justify-center">
              <Award className="w-8 h-8 text-blue-600" />
            </div>
            <h3 className="font-extrabold text-slate-800 text-base">{t('customers:fidelizacion_de_clientes')}</h3>
            <p className="text-xs text-slate-500 max-w-[200px] leading-relaxed font-medium">
              {t('customers:selecciona_un_cliente_de_la_lista_para')}
            </p>
          </div>
        )}
      </div>

      {/* Customer Form Modal */}
      {isFormOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center z-[100] p-4">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
            <div className="bg-slate-900 px-6 py-5 flex justify-between items-center">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-blue-600 rounded-xl">
                  <User className="w-5 h-5 text-white" />
                </div>
                <h3 className="text-lg font-extrabold text-white">
                  {editingCustomer ? t('customers:editar_cliente') : t('customers:registrar_nuevo_cliente')}
                </h3>
              </div>
              <button
                onClick={() => setIsFormOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {error && (
                <div className="p-3.5 bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold rounded-xl">
                  {error}
                </div>
              )}

              <div className="space-y-1">
                <label className="text-xs font-extrabold text-slate-700 ml-1">{t('customers:nombre_completo')}</label>
                <input
                  type="text"
                  required
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder={t('customers:ej_juan_perez')}
                  className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-sm font-semibold text-slate-800 transition-all outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-extrabold text-slate-700 ml-1">{t('customers:nit_cedula_2')}</label>
                  <input
                    type="text"
                    value={form.nit}
                    onChange={(e) => setForm({ ...form, nit: e.target.value })}
                    placeholder={t('customers:ej_12345678')}
                    className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-sm font-semibold text-slate-800 transition-all outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-extrabold text-slate-700 ml-1">{t('customers:telefono')}</label>
                  <input
                    type="text"
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                    placeholder={t('customers:ej_3001234567')}
                    className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-sm font-semibold text-slate-800 transition-all outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-extrabold text-slate-700 ml-1">{t('customers:correo_electronico')}</label>
                  <input
                    type="email"
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    placeholder={t('customers:ej_juan_correo_com')}
                    className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-sm font-semibold text-slate-800 transition-all outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-extrabold text-slate-700 ml-1">{t('customers:fecha_de_nacimiento')}</label>
                  <input
                    type="date"
                    value={form.birthDate}
                    onChange={(e) => setForm({ ...form, birthDate: e.target.value })}
                    className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-sm font-semibold text-slate-800 transition-all outline-none"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-extrabold text-slate-700 ml-1">{t('customers:direccion')}</label>
                <input
                  type="text"
                  value={form.address}
                  onChange={(e) => setForm({ ...form, address: e.target.value })}
                  placeholder={t('customers:ej_calle_10_5_20')}
                  className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-sm font-semibold text-slate-800 transition-all outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-extrabold text-slate-700 ml-1">{t('customers:notas_observaciones')}</label>
                <textarea
                  value={form.notes}
                  onChange={(e) => setForm({ ...form, notes: e.target.value })}
                  placeholder={t('customers:informacion_adicional')}
                  rows={2}
                  className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 text-sm font-normal text-slate-800 transition-all outline-none"
                />
              </div>

              <div className="flex gap-3 pt-4 border-t border-slate-200">
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl font-bold shadow-sm shadow-blue-500/20 active:scale-[0.98] transition-all"
                >
                  {editingCustomer ? t('customers:actualizar_cliente') : t('customers:registrar_cliente')}
                </button>
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 py-3 rounded-xl font-bold active:scale-[0.98] transition-all"
                >
                  {t('customers:cancelar')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
