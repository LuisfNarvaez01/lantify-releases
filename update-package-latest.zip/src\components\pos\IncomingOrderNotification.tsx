// ============================================
// COMPONENTS - Floating Incoming Order Notification
// Displays live orders from Rappi, WhatsApp Bot, and Web Storefront
// includes customer contact card and one-click auto-kitchen print
// ============================================

import React, { useEffect } from 'react';
import { 
  ShoppingBag, 
  Printer, 
  X, 
  MapPin, 
  Phone, 
  User, 
  FileText, 
  CheckCircle2, 
  ExternalLink,
  MessageCircle,
  Zap
} from 'lucide-react';
import { formatCurrency } from '../../shared/formatUtils';
import { printService } from '../../services/printService';

import { t } from '../../i18n';
export interface IncomingOrder {
  id: string;
  saleNumber: string;
  channel: 'RAPPI' | 'WHATSAPP' | 'WEB' | 'POS';
  customerName?: string;
  customerPhone?: string;
  customerAddress?: string;
  deliveryNotes?: string;
  total: number;
  paymentMethod: string;
  notes?: string;
  items: Array<{
    id?: string;
    productName?: string;
    variantName?: string;
    quantity: number;
    unitPrice: number;
    total: number;
    productVariant?: {
      name: string;
      product: {
        name: string;
      };
    };
  }>;
}

interface IncomingOrderNotificationProps {
  order: IncomingOrder | null;
  onClose: () => void;
  onViewSales?: () => void;
}

export const IncomingOrderNotification: React.FC<IncomingOrderNotificationProps> = ({
  order,
  onClose,
  onViewSales
}) => {
  const [isCommanded, setIsCommanded] = React.useState(false);

  // Play pleasant digital chime when notification opens
  useEffect(() => {
    if (order) {
      setIsCommanded(false);
      try {
        const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const osc1 = ctx.createOscillator();
        const osc2 = ctx.createOscillator();
        const gain = ctx.createGain();

        osc1.type = 'sine';
        osc2.type = 'triangle';
        osc1.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
        osc1.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.15); // A5

        osc2.frequency.setValueAtTime(440, ctx.currentTime);
        osc2.frequency.exponentialRampToValueAtTime(659.25, ctx.currentTime + 0.15);

        gain.gain.setValueAtTime(0.3, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);

        osc1.connect(gain);
        osc2.connect(gain);
        gain.connect(ctx.destination);

        osc1.start();
        osc2.start();
        osc1.stop(ctx.currentTime + 0.4);
        osc2.stop(ctx.currentTime + 0.4);
      } catch {
        // audio optional
      }
    }
  }, [order]);

  if (!order) return null;

  const channelConfig = {
    RAPPI: {
      label: t('delivery:rappi_delivery'),
      color: 'from-orange-500 to-amber-600',
      badgeBg: 'bg-orange-100 text-orange-800 border-orange-200',
      icon: <Zap className="w-5 h-5 text-white" />
    },
    WHATSAPP: {
      label: t('delivery:whatsapp_bot'),
      color: 'from-emerald-500 to-teal-600',
      badgeBg: 'bg-emerald-100 text-emerald-800 border-emerald-200',
      icon: <MessageCircle className="w-5 h-5 text-white" />
    },
    WEB: {
      label: t('delivery:tienda_web_lantify'),
      color: 'from-sky-600 to-indigo-700',
      badgeBg: 'bg-sky-100 text-sky-800 border-sky-200',
      icon: <ShoppingBag className="w-5 h-5 text-white" />
    },
    POS: {
      label: t('delivery:mostrador_salon'),
      color: 'from-slate-800 to-slate-950',
      badgeBg: 'bg-slate-100 text-slate-800 border-slate-200',
      icon: <ShoppingBag className="w-5 h-5 text-white" />
    }
  }[order.channel || 'RAPPI'];

  const handleCommandToKitchen = () => {
    try {
      const config = JSON.parse(localStorage.getItem('posConfig') || '{}');
      const formattedItems = order.items.map(it => ({
        productVariant: it.productVariant || {
          name: it.variantName || t('delivery:estandar'),
          product: { name: it.productName || t('delivery:producto') }
        },
        quantity: it.quantity,
        total: it.total
      }));

      printService.printKitchenTicket(config, {
        items: formattedItems as any,
        tableNumber: t('delivery:delivery_channel_salenumber', { channel: order.channel, saleNumber: order.saleNumber.slice(-4) })
      });
      setIsCommanded(true);
    } catch (err) {
      console.error('Error printing kitchen ticket:', err);
      setIsCommanded(true);
    }
  };

  return (
    <div className="fixed bottom-5 right-5 z-50 w-full max-w-md animate-in slide-in-from-bottom-6 duration-300">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden ring-4 ring-black/5">
        {/* Header with Channel Banner */}
        <div className={`bg-gradient-to-r ${channelConfig.color} px-5 py-3.5 text-white flex items-center justify-between shadow-sm`}>
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-white/20 backdrop-blur-sm rounded-xl">
              {channelConfig.icon}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-sm tracking-wide uppercase">{t('delivery:nuevo_pedido')}</span>
                <span className="px-2 py-0.5 bg-white/25 rounded-full text-xs font-black uppercase tracking-wider">
                  {channelConfig.label}
                </span>
              </div>
              <p className="text-xs text-white/90 font-medium">#{order.saleNumber}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-white/20 rounded-full transition-colors text-white/90 hover:text-white"
            title={t('delivery:cerrar_notificacion')}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 space-y-4 max-h-[75vh] overflow-y-auto">
          {/* Tarjeta de Contacto del Cliente (Customer Card) */}
          <div className="bg-slate-50 rounded-2xl p-3.5 border border-slate-200 space-y-2">
            <div className="flex items-center justify-between border-b border-slate-200 pb-1.5">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-blue-600" />{' '}{t('delivery:datos_del_cliente')}
              </span>
              <span className="text-xs font-bold text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded-md">
                {order.paymentMethod.replace('_', ' ')}
              </span>
            </div>

            <div className="grid grid-cols-1 gap-1.5 text-xs text-slate-800">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-slate-500 w-16">{t('delivery:nombre')}</span>
                <span className="font-bold text-slate-900">{order.customerName || t('delivery:cliente_no_registrado')}</span>
              </div>

              {order.customerPhone && (
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-slate-500 w-16">{t('delivery:telefono')}</span>
                  <a 
                    href={`https://wa.me/57${order.customerPhone.replace(/\D/g, '')}`} 
                    target="_blank" 
                    rel="noreferrer"
                    className="font-bold text-emerald-700 hover:underline flex items-center gap-1"
                  >
                    <Phone className="w-3 h-3 text-emerald-600" />
                    {order.customerPhone}
                    <ExternalLink className="w-3 h-3 opacity-60" />
                  </a>
                </div>
              )}

              {order.customerAddress && (
                <div className="flex items-start gap-2">
                  <span className="font-semibold text-slate-500 w-16 pt-0.5">{t('delivery:direccion')}</span>
                  <span className="font-bold text-slate-900 flex items-start gap-1 flex-1">
                    <MapPin className="w-3.5 h-3.5 text-rose-500 flex-shrink-0 mt-0.5" />
                    {order.customerAddress}
                  </span>
                </div>
              )}

              {order.deliveryNotes && (
                <div className="flex items-start gap-2 bg-white p-2 rounded-xl border border-slate-200 mt-1">
                  <FileText className="w-3.5 h-3.5 text-blue-600 flex-shrink-0 mt-0.5" />
                  <p className="text-xs text-slate-800 font-medium italic">
                    "{order.deliveryNotes}"
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Items Preview */}
          <div className="space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block">
              {t('delivery:productos_solicitados_length', { length: order.items.length })}
            </span>
            <div className="space-y-1.5 max-h-32 overflow-y-auto pr-1">
              {order.items.map((it, idx) => {
                const name = it.productVariant?.product?.name 
                  ? `${it.productVariant.product.name} (${it.productVariant.name})`
                  : it.productName || t('delivery:producto');
                return (
                  <div key={idx} className="flex items-center justify-between text-xs py-1 border-b border-slate-100 last:border-none">
                    <div className="flex items-center gap-2 truncate pr-2">
                      <span className="w-5 h-5 bg-blue-50 text-blue-700 font-bold rounded flex items-center justify-center text-xs font-mono">
                        {it.quantity}x
                      </span>
                      <span className="font-medium text-slate-800 truncate">{name}</span>
                    </div>
                    <span className="font-bold text-slate-900 flex-shrink-0 font-mono tabular-nums">
                      {formatCurrency(it.total)}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Total & Action Buttons */}
          <div className="pt-2 border-t border-slate-100 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">{t('delivery:total_a_cobrar')}</span>
              <span className="text-lg font-black text-slate-900 font-mono tabular-nums">{formatCurrency(order.total)}</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCommandToKitchen}
                disabled={isCommanded}
                className={`flex-1 py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-sm ${
                  isCommanded 
                    ? 'bg-emerald-600 text-white shadow-emerald-200' 
                    : 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-200'
                }`}
              >
                {isCommanded ? (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    {t('delivery:comandado_a_cocina_2')}
                  </>
                ) : (
                  <>
                    <Printer className="w-4 h-4" />
                    {t('delivery:comandar_a_cocina')}
                  </>
                )}
              </button>

              {onViewSales && (
                <button
                  onClick={() => {
                    onViewSales();
                    onClose();
                  }}
                  className="py-2.5 px-3 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl font-bold text-xs transition-colors"
                  title={t('delivery:ver_en_historial_de_ventas')}
                >
                  {t('delivery:ver_pedido')}
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
