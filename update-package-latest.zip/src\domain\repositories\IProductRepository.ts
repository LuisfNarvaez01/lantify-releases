// ============================================
// DOMAIN REPOSITORIES - Product Repository Interface
// ============================================

export interface IProductRepository {
  // Category
  createCategory(data: any): Promise<any>;
  getCategoryById(id: string): Promise<any | null>;
  getAllCategories(): Promise<any[]>;
  updateCategory(id: string, data: any): Promise<any>;
  deleteCategory(id: string): Promise<void>;

  // Product
  create(data: any): Promise<any>;
  getById(id: string): Promise<any | null>;
  getAll(): Promise<any[]>;
  getByCategory(categoryId: string): Promise<any[]>;
  update(id: string, data: any): Promise<any>;
  delete(id: string): Promise<void>;

  // ProductVariant
  createVariant(data: any): Promise<any>;
  getVariantById(id: string): Promise<any | null>;
  getVariantBySku(sku: string): Promise<any | null>;
  getVariantsByProduct(productId: string): Promise<any[]>;
  updateVariant(id: string, data: any): Promise<any>;
  deleteVariant(id: string): Promise<void>;
  updateStock(id: string, quantity: number): Promise<any>;
  permanentDelete(id: string): Promise<void>;
  permanentDeleteVariant(id: string): Promise<void>;
}