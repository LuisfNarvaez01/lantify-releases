# Script para generar el paquete de actualizacion de Lantify POS
$ErrorActionPreference = "Stop"

$SrcDir = "c:\Users\Luis\Desktop\pos-system\pos-system"
$RelDir = "c:\Users\Luis\Desktop\pos-system\lantify-releases"
$ZipTarget = Join-Path $RelDir "update-package-latest.zip"

Write-Host "1. Verificando directorios..."
if (-not (Test-Path $RelDir)) {
    throw "No se encontro el directorio lantify-releases en $RelDir"
}

Write-Host "2. Copiando version.json a lantify-releases..."
Copy-Item (Join-Path $SrcDir "version.json") -Destination (Join-Path $RelDir "version.json") -Force

Write-Host "3. Eliminando paquete anterior si existe..."
if (Test-Path $ZipTarget) {
    Remove-Item $ZipTarget -Force
}

Write-Host "4. Creando archivo ZIP con la actualizacion..."
$ItemsToZip = @(
    (Join-Path $SrcDir "dist"),
    (Join-Path $SrcDir "src"),
    (Join-Path $SrcDir "frontend\dist"),
    (Join-Path $SrcDir "frontend\src"),
    (Join-Path $SrcDir "frontend\index.html"),
    (Join-Path $SrcDir "frontend\package.json"),
    (Join-Path $SrcDir "frontend\vite.config.ts"),
    (Join-Path $SrcDir "frontend\tsconfig.json"),
    (Join-Path $SrcDir "frontend\tailwind.config.js"),
    (Join-Path $SrcDir "frontend\postcss.config.js"),
    (Join-Path $SrcDir "prisma\schema.prisma"),
    (Join-Path $SrcDir "package.json"),
    (Join-Path $SrcDir "tsconfig.json"),
    (Join-Path $SrcDir "version.json"),
    (Join-Path $SrcDir "scripts"),
    (Join-Path $SrcDir "update.bat"),
    (Join-Path $SrcDir "start.bat"),
    (Join-Path $SrcDir "setup-remote-pos.bat")
)

Compress-Archive -Path $ItemsToZip -DestinationPath $ZipTarget -Force

$zipItem = Get-Item $ZipTarget
$sizeMb = [math]::Round($zipItem.Length / 1MB, 2)
Write-Host "✅ Paquete de actualizacion generado con exito: $($zipItem.Name) ($sizeMb MB)"
