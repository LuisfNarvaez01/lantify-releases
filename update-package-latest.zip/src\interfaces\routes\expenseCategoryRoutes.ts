// ============================================
// INTERFACES - ExpenseCategory Routes
// ============================================

import { Router } from 'express';
import { ExpenseCategoryController } from '../controllers/ExpenseCategoryController';

export const createExpenseCategoryRoutes = (controller: ExpenseCategoryController) => {
  const router = Router();

  router.get('/',       controller.getAll.bind(controller));
  router.post('/',      controller.create.bind(controller));
  router.put('/:id',    controller.update.bind(controller));
  router.delete('/:id', controller.deactivate.bind(controller));

  return router;
};
