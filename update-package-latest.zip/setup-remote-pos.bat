@echo off
setlocal enabledelayedexpansion

title LantifyPOS - Asistente de Instalacion de Actualizaciones en Terminal Remota

echo ====================================================================
echo        LANTIFY POS - INSTALADOR DE SISTEMA DE ACTUALIZACIONES      
echo ====================================================================
echo.
echo Este asistente prepara este equipo para contar con:
echo   1. Deteccion automatica de actualizaciones al iniciar sesion.
echo   2. Modulo de Inventario, Gastos en Excel y Arqueo Unificado.
echo   3. Protocolo de maxima seguridad para proteger tu base de datos.
echo.
echo ====================================================================
echo.

cd /d "%~dp0"

echo [PASO 1/5] Creando copia de seguridad ULTRA-SEGURA de tu base de datos actual...
if exist "prisma\dev.db" (
    if not exist "backups" mkdir "backups"
    
    set TIMESTAMP=%date:~6,4%-%date:~3,2%-%date:~0,2%_%time:~0,2%-%time:~3,2%-%time:~6,2%
    set TIMESTAMP=!TIMESTAMP: =0!
    
    copy /Y "prisma\dev.db" "backups\dev.db.migracion_inicial_!TIMESTAMP!" >nul
    
    REM Tambien crear copia de resguardo en el Escritorio del usuario
    if exist "%USERPROFILE%\Desktop" (
        if not exist "%USERPROFILE%\Desktop\RESPALDO_NATIVOSPOS" mkdir "%USERPROFILE%\Desktop\RESPALDO_NATIVOSPOS"
        copy /Y "prisma\dev.db" "%USERPROFILE%\Desktop\RESPALDO_NATIVOSPOS\dev.db.resguardo_!TIMESTAMP!" >nul
        echo      [OK] Copia preventiva de seguridad guardada en tu Escritorio:
        echo           Escritorio\RESPALDO_NATIVOSPOS\dev.db.resguardo_!TIMESTAMP!
    )
    echo      [OK] Respaldo interno guardado en backups\
) else (
    echo      [INFO] No se encontro base de datos previa, se inicializara una limpia.
)

echo.
echo [PASO 2/5] Asegurando proteccion en .gitignore...
findstr /C:"prisma/dev.db" .gitignore >nul 2>&1
if %errorlevel% neq 0 (
    echo prisma/dev.db>> .gitignore
    echo prisma/*.db>> .gitignore
    echo backups/>> .gitignore
    echo .env>> .gitignore
)
echo      [OK] Base de datos local blindada contra sobreescrituras.

echo.
echo [PASO 2.5] Verificando conexion con repositorio oficial en GitHub...
git --version >nul 2>&1
if %errorlevel% equ 0 (
    git remote get-url origin >nul 2>&1
    if !errorlevel! neq 0 (
        git remote add origin https://github.com/LuisfNarvaez01/NativosPOS.git >nul 2>&1
    )
    echo      [OK] Repositorio remoto LuisfNarvaez01/NativosPOS vinculado.
) else (
    echo      [INFO] Git no detectado en este equipo, continuando con archivos locales.
)

echo.
echo [PASO 3/5] Instalando dependencias necesarias (xlsx, prisma)...
call npm install --no-audit --no-fund
cd frontend
call npm install --no-audit --no-fund
cd ..
echo      [OK] Dependencias al dia.

echo.
echo [PASO 4/5] Aplicando cambios de base de datos sin alterar datos existentes...
call npx prisma db push
if %errorlevel% neq 0 (
    echo.
    echo ❌ [ERROR] Hubo un problema al sincronizar el esquema.
    echo Tus datos siguen intactos gracias a la copia preventiva.
    pause
    exit /b 1
)

call npx prisma generate
echo      [OK] Base de datos actualizada con soporte de inventario.

echo.
echo [PASO 5/5] Compilando el sistema optimizado...
call npm run build
cd frontend
call npm run build
cd ..

echo.
echo ====================================================================
echo   FELICITACIONES: Tu terminal Lantify POS ha sido configurada a v1.0.0
echo ====================================================================
echo.
echo A partir de ahora:
echo   - Cada vez que inicies sesion, el sistema revisara si hay versiones nuevas.
echo   - Si hay una version nueva, aparecera una ventana preguntandote si deseas
echo     aplicarla con un solo clic.
echo   - Todas tus ventas, arqueos y datos estan 100%% seguros y respaldados.
echo.
pause
