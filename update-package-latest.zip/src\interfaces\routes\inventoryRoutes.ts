// ============================================
// INTERFACES - Inventory Routes
// ============================================

import { Router } from 'express';
import { InventoryController } from '../controllers/InventoryController';

export const createInventoryRoutes = (controller: InventoryController) => {
  const router = Router();

  router.get('/', controller.getInventoryStatus.bind(controller));
  router.put('/:variantId/toggle', controller.toggleTrackInventory.bind(controller));
  router.post('/:variantId/adjust', controller.adjustStock.bind(controller));
  router.post('/:variantId/count', controller.submitInventoryCount.bind(controller));
  router.get('/:variantId/movements', controller.getStockMovements.bind(controller));
  router.get('/:variantId/counts', controller.getInventoryCountHistory.bind(controller));

  return router;
};
